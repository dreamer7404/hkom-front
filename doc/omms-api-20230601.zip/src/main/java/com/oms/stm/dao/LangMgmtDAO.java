package com.oms.stm.dao;

import java.util.List;

import com.oms.stm.dto.LangMgmtReqDTO;
import com.oms.stm.dto.LangMgmtResDTO;
import com.oms.stm.dto.NatlMgmtReqDTO;
import com.oms.stm.dto.NatlMgmtResDTO;
import com.oms.stm.dto.StmComReqDTO;
import com.oms.sys.dto.CodeMgmtReqDTO;


/**
 * <pre>
 * Statements
 * </pre>
 * @ClassName : LangMgmtDAO.java
 * @Description :
 * @author 김경훈
 * @since 2023. 3. 23.
 * @see
 */
public interface LangMgmtDAO {

    /**
     * Statements
     *
     * @param dto
     * @return
     */
    List<LangMgmtResDTO> selectLangList(StmComReqDTO dto);

    /**
     * Statements
     *
     * @param dto
     * @return
     */
    List<LangMgmtResDTO> selectVehlLangRegList(StmComReqDTO dto);

    /**
     * Statements
     *
     * @param dto
     * @return
     */
    List<LangMgmtResDTO> selectLangMstList(StmComReqDTO dto);

    /**
     * Statements
     *
     * @param dto
     * @return
     */
    List<LangMgmtResDTO> selectTotVehlCdList(StmComReqDTO dto);

    /**
     * Statements
     *
     * @param dto
     * @return
     */
    List<LangMgmtResDTO> selectVehlLangCpList(StmComReqDTO dto);

    /**
     * Statements
     *
     * @param dto
     * @return
     */
    String LangMstValidChk(LangMgmtReqDTO dto);

    /**
     * Statements
     *
     * @param dto
     * @return
     */
    int insertLangMst(LangMgmtReqDTO dto);

    /**
     * Statements
     *
     * @param dto
     * @return
     */
    int updateLangMst(LangMgmtReqDTO dto);

    /**
     * Statements
     *
     * @param dto
     * @return
     */
    int deleteLangMst(LangMgmtReqDTO dto);


    /**
     * Statements
     *
     * @param dto
     */
    void deleteLangCdList(LangMgmtReqDTO dto);

    /**
     * Statements
     *
     * @param dto
     * @return
     */
    int insertLangCdMgmt(LangMgmtReqDTO dto);

    /**
     * Statements
     *
     * @param dto
     * @return
     */
    String getLangMgmtChk(LangMgmtReqDTO dto);

    /**
     * Statements
     *
     * @param dto
     * @return
     */
    int insertLangCdOne(LangMgmtReqDTO dto);
    /**
     * Statements
     *
     * @param dto
     * @return
     */
    int updateLangCdMgmt(LangMgmtReqDTO dto);
    /**
     * Statements
     *
     * @param dto
     * @return
     */
    int deleteLangCdMgmt(LangMgmtReqDTO dto);

    /**
     * Statements
     *
     * @param dataSn
     * @return
     */
    LangMgmtResDTO selectLangDetail(String dataSn);

    /**
     * Statements
     *
     * @param dto
     * @return
     */
    LangMgmtResDTO selectLangMstInfo(StmComReqDTO dto);


}
