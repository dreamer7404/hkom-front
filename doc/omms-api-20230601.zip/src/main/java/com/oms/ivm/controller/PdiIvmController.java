package com.oms.ivm.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import able.cloud.core.web.HController;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.oms.cmm.global.Consts;
import com.oms.cmm.utils.Utils;
import com.oms.ivm.dto.ComIvmReqDTO;
import com.oms.ivm.dto.IvmRequestMonitorResDTO;
import com.oms.ivm.dto.PdiIvmReqDTO;
import com.oms.ivm.dto.PdiIvmResDTO;
import com.oms.ivm.dto.PdiPrndMonitorReqDTO;
import com.oms.ivm.dto.PdiPrndMonitorResDTO;
import com.oms.ivm.dto.PdiWhsnReqDTO;
import com.oms.ivm.dto.PdiWhsnResDTO;
import com.oms.ivm.dto.PdiWhsnStatResDTO;
import com.oms.ivm.service.PdiIvmService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;


/**
 * <pre>
 * PdiIvmController
 * </pre>
 *
 * @ClassName   : PdiIvmController.java
 * @Description : 재고관리 > PDI재고관리 컨트롤러
 * @author 김정웅
 * @since 2023.5.4
 * @see
 */
@Tag(name = "PdiIvmController", description = "")
@RequiredArgsConstructor
@RestController
@RequestMapping("/api")
public class PdiIvmController extends HController {

    /**
     * 클래스 Injection
     */
    private final HttpServletRequest request;
    private final PdiIvmService pdiIvmService;

    /**
     * 재고관리 > PDI재고관리 > PDI재고관리 현황
     */
    @Operation(summary = "총재고관리 조회")
    @GetMapping("/ivmPdiIvInfos")
    public List<PdiIvmResDTO> selectPdiIvmList(@ModelAttribute PdiIvmReqDTO reqDto) throws Exception {
        //사용자 ID, 회사코드 할당
        reqDto.setUserEeno(Utils.getUserEeno(request));
        reqDto.setDlExpdCoCd(Utils.getDlExpdCoCd(request));
        List<PdiIvmResDTO> result = pdiIvmService.selectPdiIvmList(reqDto);
        return result;
    }

    /**
     * 재고관리 > PDI재고관리 > 생산라인모니터링
     */
    @Operation(summary = "생산라인모니터링 조회")
    @GetMapping("/ivmPdiPrndMonitorInfo")
    public PdiPrndMonitorResDTO selectPdiPrndMonitor(@ModelAttribute PdiPrndMonitorReqDTO reqDto) throws Exception {
        //사용자 ID, 회사코드 할당
        reqDto.setUserEeno(Utils.getUserEeno(request));
        reqDto.setDlExpdCoCd(Utils.getDlExpdCoCd(request));
        PdiPrndMonitorResDTO result = pdiIvmService.selectPdiPrndMonitor(reqDto);

        return result;
    }

    /**
     * 재고관리 > PDI재고관리 > 입고확인
     */
    @Operation(summary = "PDI 입고확인 조회")
    @GetMapping("/ivmPdiWhsnInfo")
    public List<PdiWhsnResDTO> selectPdiWhsnList(@ModelAttribute ComIvmReqDTO reqDto) throws Exception {
        //사용자 ID, 회사코드 할당
        reqDto.setUserEeno(Utils.getUserEeno(request));
        reqDto.setDlExpdCoCd(Utils.getDlExpdCoCd(request));
        List<PdiWhsnResDTO> result = pdiIvmService.selectPdiWhsnList(reqDto);

        return result;
    }

    /**
     * 재고관리 > PDI재고관리 > 입고확인 저장
     */
    @Operation(summary = "PDI 입고확인 등록", description = "")
    @Parameter(in = ParameterIn.HEADER, name="_method", schema=@Schema(type="string"))
    @PostMapping(value = "/ivmPdiWhsnInfo")
    public Integer insertPdiWhsnInfos(@RequestBody List<PdiWhsnReqDTO> reqDto) throws Exception {
        String method = Utils.getMethod(request);
        String userEeno = Utils.getUserEeno(request);
        String dlExpdCoCd = Utils.getDlExpdCoCd(request);

        int result = 0;

        if(method.equals(Consts.INSERT)) {
            result = pdiIvmService.insertPdiWhsnInfos(reqDto, userEeno);
        }
        return result;
    }

    /**
     * 재고관리 > PDI재고관리 > 배송요청(to.세원)
     */
    @Operation(summary = "PDI의 배송요청", description = "")
    @Parameter(in = ParameterIn.HEADER, name="_method", schema=@Schema(type="string"))
    @PostMapping(value = "/ivmPdiDlvtRequest")
    public Integer insertPdiDlvtRequestInfos(@RequestBody List<ComIvmReqDTO> reqDto) throws Exception {
        String method = Utils.getMethod(request);
        String userEeno = Utils.getUserEeno(request);
        String dlExpdCoCd = Utils.getDlExpdCoCd(request);

        int result = 0;

        if(method.equals(Consts.INSERT)) {
            result = pdiIvmService.insertPdiDlvtRequestInfos(reqDto, userEeno, dlExpdCoCd);
        }
        return result;
    }

    /**
     * 재고관리 > PDI재고관리 > 발주요청(to.총재고)
     */
    @Operation(summary = "PDI의 발주요청", description = "")
    @Parameter(in = ParameterIn.HEADER, name="_method", schema=@Schema(type="string"))
    @PostMapping(value = "/ivmPdiOrderRequest")
    public Integer insertPdiOrderRequestInfos(@RequestBody List<ComIvmReqDTO> reqDto) throws Exception {
        String method = Utils.getMethod(request);
        String userEeno = Utils.getUserEeno(request);
        String dlExpdCoCd = Utils.getDlExpdCoCd(request);

        int result = 0;

        if(method.equals(Consts.INSERT)) {
            result = pdiIvmService.insertPdiOrderRequestInfos(reqDto, userEeno, dlExpdCoCd);
        }
        return result;
    }

    /**
     * 재고관리 > PDI재고관리 > 입고현황
     */
    @Operation(summary = "PDI 입고현황 조회")
    @GetMapping("/ivmPdiWhsnStatInfos")
    public List<PdiWhsnStatResDTO> selectPdiWhsnStatList(@ModelAttribute ComIvmReqDTO reqDto) throws Exception {
        //사용자 ID, 회사코드 할당
        reqDto.setUserEeno(Utils.getUserEeno(request));
        reqDto.setDlExpdCoCd(Utils.getDlExpdCoCd(request));
        List<PdiWhsnStatResDTO> result = pdiIvmService.selectPdiWhsnStatList(reqDto);

        return result;
    }

    /**
     * 재고관리 > PDI재고관리 > 요청현황
     */
    @Operation(summary = "PDI 요청현황")
    @GetMapping("/ivmPdiRequestInfos")
    public List<IvmRequestMonitorResDTO> selectIvmPdiReqStateList(@ModelAttribute ComIvmReqDTO reqDto) throws Exception {
        reqDto.setUserEeno(Utils.getUserEeno(request));
        reqDto.setDlExpdCoCd(Utils.getDlExpdCoCd(request));

        List<IvmRequestMonitorResDTO> result = pdiIvmService.selectIvmPdiReqStateList(reqDto);

        return result;
    }


}