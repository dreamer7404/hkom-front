package com.oms.ivm.dao;

import java.util.HashMap;
import java.util.List;

import com.oms.ivm.dto.BoardAffrReqDTO;
import com.oms.ivm.dto.ComIvmReqDTO;
import com.oms.ivm.dto.Ivm2WeekPlanReqDTO;
import com.oms.ivm.dto.Ivm2WeekPlanResDTO;
import com.oms.ivm.dto.Ivm3DayPlanReqDTO;
import com.oms.ivm.dto.Ivm3DayPlanResDTO;
import com.oms.ivm.dto.IvmPdiOrYongsanIvResDTO;
import com.oms.ivm.dto.IvmSewonIvResDTO;
import com.oms.ivm.dto.IvmThisMonTrwiResDTO;

/**
 * <pre>
 * BoardAffrDAO 인터페이스
 * </pre>
 *
 * @Class Name  : BoardAffrDAO.java
 * @Description : 재고관리 > 게시판
 * @author 안경수
 * @since 2023.6.1
 * @see
*/
public interface BoardAffrDAO {
    int insertBoardAffr(BoardAffrReqDTO boardAffrReqDTO);
}
