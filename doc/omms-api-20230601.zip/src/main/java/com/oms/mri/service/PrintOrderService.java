package com.oms.mri.service;

import java.util.List;

import com.oms.ivm.dto.TotIvmReqDTO;
import com.oms.ivm.dto.TotIvmResDTO;
import com.oms.mri.dto.ClcmInfosReqDTO;
import com.oms.mri.dto.ClcmInfosResDTO;
import com.oms.mri.dto.PrintOrderComDTO;
import com.oms.mri.dto.PrintOrderInfosResDTO;

/**
 * <pre>
 * PrintOrderService
 * </pre>
 * @ClassName : PrintOrderService.java
 * @Description : 제작준비 > O/M발주 서비스
 * @author 김정웅
 * @since 2023. 5. 11.
 * @see
 */

public interface PrintOrderService {

    List<PrintOrderInfosResDTO> selectPrintOrderList(PrintOrderComDTO reqDto);

    List<ClcmInfosResDTO> selectPrintOrderClcmInfos(PrintOrderComDTO reqDto) ;
}
