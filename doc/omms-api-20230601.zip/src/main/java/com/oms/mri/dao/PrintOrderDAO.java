package com.oms.mri.dao;

import java.util.List;

import com.oms.ivm.dto.TotIvmResDTO;
import com.oms.mri.dto.ClcmInfosReqDTO;
import com.oms.mri.dto.ClcmInfosResDTO;
import com.oms.mri.dto.PrintOrderComDTO;
import com.oms.mri.dto.PrintOrderInfosResDTO;


/**
 * <pre>
 * PrintOrderDAO
 * </pre>
 * @ClassName : PrintOrderDAO.java
 * @Description : 제작준비 > O/M발주  DAO
 * @author 김정웅
 * @since 2023. 5. 11.
 * @see
 */
public interface PrintOrderDAO {
    //O/M발주 목록
    List<PrintOrderInfosResDTO> selectPrintOrderList(PrintOrderComDTO reqDto) ;

    //O/M발주 개정정보
    List<ClcmInfosResDTO> selectPrintOrderClcmInfos(PrintOrderComDTO reqDto);
}
