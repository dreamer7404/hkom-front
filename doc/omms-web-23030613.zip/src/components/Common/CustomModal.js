/* eslint-disable react-hooks/exhaustive-deps */
import { useRef, useState, useEffect } from 'react';
import { Modal } from 'antd';
import {Button} from 'react-bootstrap';
import Draggable from 'react-draggable';

const CustomModal = ({ 
    open, title , size, 
    handleOk, 
    handleCancel,
    handleRemove,
    handleCustom,
    customText, 
    customVariant,
    children}) => {

    const [disabled, setDisabled] = useState(true);
    const [bounds, setBounds] = useState({left: 0, top: 0, bottom: 0,right: 0});
    
    const draggleRef = useRef(null);
    
    const onStart = (_event, uiData) => {
      const { clientWidth, clientHeight } = window.document.documentElement;
      const targetRect = draggleRef.current?.getBoundingClientRect();
      if (!targetRect) {
        return;
      }
      setBounds({
        left: -targetRect.left + uiData.x,
        right: clientWidth - (targetRect.right - uiData.x),
        top: -targetRect.top + uiData.y,
        bottom: clientHeight - (targetRect.bottom - uiData.y),
      });
    };

    const [width, setWidth] = useState(500);
    const [footer, setFooter] = useState([]);

    useEffect(() => {
        // width
        if(size === 'sm') setWidth(300);
        else if(size === 'lg') setWidth(800);
        else if(size === 'xl') setWidth(1140);
        else  setWidth(500); // md

        // footer
        let arr = [<Button variant="light" size="md" onClick={handleCancel}>취소</Button>]
        if(handleRemove){
            arr.push(<Button variant="outline-danger" size="md" onClick={handleRemove}>삭제</Button>);
        }
        if(handleCustom){
            arr.push(<Button variant={customVariant} size="md" onClick={handleCustom}>{customText}</Button>);
        }
        arr.push(<Button key="submit" variant="primary" size="md" onClick={handleOk}>확인</Button>);
        setFooter(arr);
    }, [])


    return(
        <Modal  
            className="modal-custom"
            title={
                <div 
                    style={{width: '100%', cursor: 'move', fontSize: '18px'}}
                    onMouseOver={() => disabled && setDisabled(false)}
                    onMouseOut={() => setDisabled(true)}
                    onFocus={() => {}}
                    onBlur={() => {}}>
                        {title}
                </div>
            }
            centered
            width={width}
            bodyStyle={{
                // borderTop: '1px solid #efefef',
                // borderBottom: '1px solid #efefef'
            }}
            maskStyle={{background: 'rgba(128,128,128, 0.2)'}}
            closable={true}
            maskClosable={false}
            open={open}
            onOk={handleOk}
            onCancel={handleCancel}
            footer={null}
            modalRender={(modal) => (
                <Draggable
                    disabled={disabled}
                    bounds={bounds}
                    onStart={(event, uiData) => onStart(event, uiData)}>
                    <div ref={draggleRef}>{modal}</div>
                </Draggable>
            )}>
            {children}
        </Modal>
    )
};
export default CustomModal;