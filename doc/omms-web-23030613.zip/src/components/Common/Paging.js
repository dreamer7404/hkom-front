import React, {useState} from 'react';
import {FlexboxGrid,  Pagination} from 'rsuite'

const Paging = ({total, limit, activePage, onChangePage, onChangeLimit}) => {

    const layout = ['total', '|', 'pager', '|', 'limit'];

    return(
        <FlexboxGrid justify="space-around" className='mt-3' >
            <Pagination
                layout={layout}
                prev
                last
                next
                first
                size="xs"
                maxButtons={10} 
                total={total} // rows number
                limit={limit}  // rows number per page.
                activePage={activePage}
                onChangePage={onChangePage}
                onChangeLimit={onChangeLimit}
            />
        </FlexboxGrid>
    )

}
export default Paging;