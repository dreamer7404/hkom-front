import React from 'react';
import {Tab,Tabs} from 'react-bootstrap';

import EmailHistory from './EmailHistory';
import EmailRcvList from './EmailRcvList';

const EmailConainer = () => {
    
    const [leftWidth, setLeftWidth] = React.useState('150px')
    React.useEffect(() => {
        const getTitle = document.getElementById('section-title-width');
        const titleWidth = getTitle.clientWidth + 40;
        setLeftWidth(titleWidth);
    }, []);

    return (
        <>
            <Tabs  defaultActiveKey="tab1" style={{left: leftWidth}} >
                <Tab eventKey="tab1" title="이력관리">
                    <EmailHistory />
                </Tab>
                <Tab eventKey="tab2" title="수신자관리">
                   <EmailRcvList />
                </Tab>
            </Tabs>
        </>
    );

};
export default EmailConainer;