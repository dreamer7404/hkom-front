import React, {useState, useMemo} from 'react';
import { AgGridReact } from 'ag-grid-react';
import {Button, Modal, Table} from 'react-bootstrap';
import {Form, SelectPicker} from 'rsuite';

const EmailRcvAdd = ({show, onHide}) => {

    const [rowData] = useState([
        {userId: "user-id-text",userNm:'user-name'},
        {userId: "user-id-text",userNm:'user-name'},
    ]);

    const columnDefs = [
        {
          checkboxSelection: true,
          headerCheckboxSelection: true,
          width:45,
          maxWidth:45,
          minWidth:45,
          sortable:false
        },
        {
            headerName: '아이디',
            field: 'userId',
            maxWidth:'150',
        },
        {
          headerName: '이름',
          field: 'userNm',
          maxWidth:'150',
        },
    ]

    const defaultColDef = useMemo(() => {
        return {
            initialWidth: 90,
            sortable: true,
            resizable:true,
        };
    }, []);

    const onFirstDataRendered = (params) => {
        params.api.sizeColumnsToFit();
    };

    return (
        <>
            <Form>
                <Modal show={show} onHide={onHide} backdrop="static" keyboard={false} centered size="md" className="modal-custom">
                    <Modal.Header closeButton>
                        <Modal.Title>수신자 등록</Modal.Title>
                    </Modal.Header>
                        <Modal.Body>
                            <Table className="tbl-hor" bordered>
                                <colgroup>
                                    <col style={{width:'30%'}}></col>
                                    <col style={{width:''}}></col>
                                </colgroup>
                                <tbody>
                                    <tr>
                                        <th className="essen">구분</th>
                                        <td>
                                            <SelectPicker size="sm" data={[{ label: "전체"}]} searchable={false} cleanable={false} />
                                        </td>
                                    </tr>
                                    <tr>
                                        <th className="essen">담당자</th>
                                        <td>
                                            <div className="ag-theme-alpine" style={{height:300, minWidth:300}}>
                                                <AgGridReact
                                                    rowData={rowData}
                                                    columnDefs={columnDefs}
                                                    defaultColDef={defaultColDef}
                                                    rowSelection={'multiple'}
                                                    suppressRowClickSelection= {true} 
                                                    onFirstDataRendered={onFirstDataRendered}
                                                    suppressSizeToFit={true}    
                                                    onGridSizeChanged={onFirstDataRendered}     
                                                    >
                                                </AgGridReact>
                                            </div>
                                        </td>
                                    </tr>
                                </tbody>
                            </Table>
                        </Modal.Body>

                        <Modal.Footer>
                            <Button variant="light" size="md" onClick={onHide} >취소</Button>
                            <Button variant="primary" size="md" onClick={onHide} >저장</Button>
                        </Modal.Footer>
                </Modal>
            </Form>
        </>
    );

};
export default EmailRcvAdd;