import React, {useState, useEffect} from 'react';
import {Modal, Button, Table} from 'react-bootstrap';
import {Form, SelectPicker, Checkbox} from 'rsuite';
import { API, CONSTANTS } from '../../../../utils/constants';
import { useQuery} from 'react-query';
import useStore from '../../../../utils/store';
import { getData,postData } from '../../../../utils/async';
const PrintArrayTable = ({data, show, onHide}) => {

    const queryResult = useQuery([API.prntAlgnPop,data], () => getData(API.prntAlgnPop, data));

    useEffect(()=>{
        if(queryResult.isSuccess){
            console.log("queryResult",queryResult);
        }

    },[queryResult.status])


    const onClickEvent = ()=>{


        queryResult.remove();
        onHide();

    }
    return (
        <>
            <Form>
                <Modal show={show} onHide={onHide} backdrop="static" keyboard={false} centered size="xl" className="modal-custom size-2xl">
                    <Modal.Header closeButton>
                        <Modal.Title>인쇄 배열표</Modal.Title>
                    </Modal.Header>
                    <Modal.Body>
                        <div className="grid-btn-wrap">
                            <div className="right-align">
                                <Button variant="outline-success" size="sm"><span className="excel-down"></span>{CONSTANTS.excelDownload}</Button>{' '}
                                <Button variant="outline-dark" size="sm"><span className="print"></span>{CONSTANTS.print}</Button>{' '}
                            </div>
                        </div>
                        <Table className="tbl-hor" bordered>
                            <colgroup>
                                <col style={{width:'10%'}}></col>
                                <col style={{width:'20%'}}></col>
                                <col style={{width:'10%'}}></col>
                                <col style={{width:'10%'}}></col>
                                <col style={{width:'10%'}}></col>
                                <col style={{width:'20%'}}></col>
                                <col style={{width:'10%'}}></col>
                                <col style={{width:'10%'}}></col>
                            </colgroup>
                            <tbody>
                                <tr>
                                    <th className="">발간번호</th>
                                    <td>
                                        <SelectPicker size="sm" data={[{ label: "TEST-PT-01"}]} searchable={false} cleanable={false} />
                                    </td>
                                    <th className="">수정</th>
                                    <td>
                                        0/500
                                    </td>
                                    <th className="">인쇄방법</th>
                                    <td>
                                        표지 1도
                                    </td>
                                    <th className="">인쇄부수</th>
                                    <td>
                                        500
                                    </td>
                                </tr>
                            </tbody>
                        </Table>
                        <div className="print-array-wrap">
                            <Table className="tbl-ver">
                                <tbody>
                                    <tr>
                                        <td className="print-array-td">
                                            <Table className="tbl-ver" bordered>
                                                <thead>
                                                    <tr>
                                                        <th><Checkbox disabled /></th>
                                                        <th>페이지</th>
                                                        <th>내용</th>
                                                        <th>교체</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <tr>
                                                        <td rowSpan="8">1</td>
                                                        <td>S3-33</td>
                                                        <td>1</td>
                                                        <td><Checkbox disabled/></td>
                                                    </tr>
                                                    <tr>
                                                        <td>2</td>
                                                        <td>S3-33</td>
                                                        <td><Checkbox disabled/></td>
                                                    </tr>
                                                     <tr>
                                                        <td>3</td>
                                                        <td>S3-33</td>
                                                        <td><Checkbox disabled/></td>
                                                    </tr>
                                                     <tr>
                                                        <td>4</td>
                                                        <td>S3-33</td>
                                                        <td><Checkbox disabled/></td>
                                                    </tr>
                                                     <tr>
                                                        <td>5</td>
                                                        <td>S3-33</td>
                                                        <td><Checkbox disabled/></td>
                                                    </tr>
                                                     <tr>
                                                        <td>6</td>
                                                        <td>S3-33</td>
                                                        <td><Checkbox disabled/></td>
                                                    </tr>
                                                     <tr>
                                                        <td>7</td>
                                                        <td>S3-33</td>
                                                        <td><Checkbox disabled/></td>
                                                    </tr>
                                                     <tr>
                                                        <td>8</td>
                                                        <td>S3-33</td>
                                                        <td><Checkbox disabled/></td>
                                                    </tr>
                                                    <tr>
                                                        <td rowSpan="8">8</td>
                                                        <td>S3-33</td>
                                                        <td>1</td>
                                                        <td><Checkbox disabled/></td>
                                                    </tr>
                                                    <tr>
                                                        <td>2</td>
                                                        <td>S3-33</td>
                                                        <td><Checkbox disabled/></td>
                                                    </tr>
                                                     <tr>
                                                        <td>3</td>
                                                        <td>S3-33</td>
                                                        <td><Checkbox disabled/></td>
                                                    </tr>
                                                     <tr>
                                                        <td>4</td>
                                                        <td>S3-33</td>
                                                        <td><Checkbox disabled/></td>
                                                    </tr>
                                                     <tr>
                                                        <td>5</td>
                                                        <td>S3-33</td>
                                                        <td><Checkbox disabled/></td>
                                                    </tr>
                                                     <tr>
                                                        <td>6</td>
                                                        <td>S3-33</td>
                                                        <td><Checkbox disabled/></td>
                                                    </tr>
                                                     <tr>
                                                        <td>7</td>
                                                        <td>S3-33</td>
                                                        <td><Checkbox disabled/></td>
                                                    </tr>
                                                     <tr>
                                                        <td>8</td>
                                                        <td>S3-33</td>
                                                        <td><Checkbox disabled/></td>
                                                    </tr>
                                                </tbody>
                                            </Table>
                                        </td>
                                        <td className="print-array-td">
                                            <Table className="tbl-ver" bordered>
                                                <thead>
                                                    <tr>
                                                        <th><Checkbox disabled /></th>
                                                        <th>페이지</th>
                                                        <th>내용</th>
                                                        <th>교체</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <tr>
                                                        <td rowSpan="8">9</td>
                                                        <td>S3-33</td>
                                                        <td>1</td>
                                                        <td><Checkbox disabled/></td>
                                                    </tr>
                                                    <tr>
                                                        <td>2</td>
                                                        <td>S3-33</td>
                                                        <td><Checkbox disabled/></td>
                                                    </tr>
                                                     <tr>
                                                        <td>3</td>
                                                        <td>S3-33</td>
                                                        <td><Checkbox disabled/></td>
                                                    </tr>
                                                     <tr>
                                                        <td>4</td>
                                                        <td>S3-33</td>
                                                        <td><Checkbox disabled/></td>
                                                    </tr>
                                                     <tr>
                                                        <td>5</td>
                                                        <td>S3-33</td>
                                                        <td><Checkbox disabled/></td>
                                                    </tr>
                                                     <tr>
                                                        <td>6</td>
                                                        <td>S3-33</td>
                                                        <td><Checkbox disabled/></td>
                                                    </tr>
                                                     <tr>
                                                        <td>7</td>
                                                        <td>S3-33</td>
                                                        <td><Checkbox disabled/></td>
                                                    </tr>
                                                     <tr>
                                                        <td>8</td>
                                                        <td>S3-33</td>
                                                        <td><Checkbox disabled/></td>
                                                    </tr>
                                                    <tr>
                                                        <td rowSpan="8">16</td>
                                                        <td>S3-33</td>
                                                        <td>1</td>
                                                        <td><Checkbox disabled/></td>
                                                    </tr>
                                                    <tr>
                                                        <td>2</td>
                                                        <td>S3-33</td>
                                                        <td><Checkbox disabled/></td>
                                                    </tr>
                                                     <tr>
                                                        <td>3</td>
                                                        <td>S3-33</td>
                                                        <td><Checkbox disabled/></td>
                                                    </tr>
                                                     <tr>
                                                        <td>4</td>
                                                        <td>S3-33</td>
                                                        <td><Checkbox disabled/></td>
                                                    </tr>
                                                     <tr>
                                                        <td>5</td>
                                                        <td>S3-33</td>
                                                        <td><Checkbox disabled/></td>
                                                    </tr>
                                                     <tr>
                                                        <td>6</td>
                                                        <td>S3-33</td>
                                                        <td><Checkbox disabled/></td>
                                                    </tr>
                                                     <tr>
                                                        <td>7</td>
                                                        <td>S3-33</td>
                                                        <td><Checkbox disabled/></td>
                                                    </tr>
                                                     <tr>
                                                        <td>8</td>
                                                        <td>S3-33</td>
                                                        <td><Checkbox disabled/></td>
                                                    </tr>
                                                </tbody>
                                            </Table>
                                        </td>
                                        <td className="print-array-td">
                                            <Table className="tbl-ver" bordered>
                                                <thead>
                                                    <tr>
                                                        <th><Checkbox disabled /></th>
                                                        <th>페이지</th>
                                                        <th>내용</th>
                                                        <th>교체</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <tr>
                                                        <td rowSpan="8">17</td>
                                                        <td>S3-33</td>
                                                        <td>1</td>
                                                        <td><Checkbox disabled/></td>
                                                    </tr>
                                                    <tr>
                                                        <td>2</td>
                                                        <td>S3-33</td>
                                                        <td><Checkbox disabled/></td>
                                                    </tr>
                                                     <tr>
                                                        <td>3</td>
                                                        <td>S3-33</td>
                                                        <td><Checkbox disabled/></td>
                                                    </tr>
                                                     <tr>
                                                        <td>4</td>
                                                        <td>S3-33</td>
                                                        <td><Checkbox disabled/></td>
                                                    </tr>
                                                     <tr>
                                                        <td>5</td>
                                                        <td>S3-33</td>
                                                        <td><Checkbox disabled/></td>
                                                    </tr>
                                                     <tr>
                                                        <td>6</td>
                                                        <td>S3-33</td>
                                                        <td><Checkbox disabled/></td>
                                                    </tr>
                                                     <tr>
                                                        <td>7</td>
                                                        <td>S3-33</td>
                                                        <td><Checkbox disabled/></td>
                                                    </tr>
                                                     <tr>
                                                        <td>8</td>
                                                        <td>S3-33</td>
                                                        <td><Checkbox disabled/></td>
                                                    </tr>
                                                    <tr>
                                                        <td rowSpan="8">24</td>
                                                        <td>S3-33</td>
                                                        <td>1</td>
                                                        <td><Checkbox disabled/></td>
                                                    </tr>
                                                    <tr>
                                                        <td>2</td>
                                                        <td>S3-33</td>
                                                        <td><Checkbox disabled/></td>
                                                    </tr>
                                                     <tr>
                                                        <td>3</td>
                                                        <td>S3-33</td>
                                                        <td><Checkbox disabled/></td>
                                                    </tr>
                                                     <tr>
                                                        <td>4</td>
                                                        <td>S3-33</td>
                                                        <td><Checkbox disabled/></td>
                                                    </tr>
                                                     <tr>
                                                        <td>5</td>
                                                        <td>S3-33</td>
                                                        <td><Checkbox disabled/></td>
                                                    </tr>
                                                     <tr>
                                                        <td>6</td>
                                                        <td>S3-33</td>
                                                        <td><Checkbox disabled/></td>
                                                    </tr>
                                                     <tr>
                                                        <td>7</td>
                                                        <td>S3-33</td>
                                                        <td><Checkbox disabled/></td>
                                                    </tr>
                                                     <tr>
                                                        <td>8</td>
                                                        <td>S3-33</td>
                                                        <td><Checkbox disabled/></td>
                                                    </tr>
                                                </tbody>
                                            </Table>
                                        </td>
                                        <td className="print-array-td">
                                            <Table className="tbl-ver" bordered>
                                                <thead>
                                                    <tr>
                                                        <th><Checkbox disabled /></th>
                                                        <th>페이지</th>
                                                        <th>내용</th>
                                                        <th>교체</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <tr>
                                                        <td rowSpan="8">25</td>
                                                        <td>S3-33</td>
                                                        <td>1</td>
                                                        <td><Checkbox disabled/></td>
                                                    </tr>
                                                    <tr>
                                                        <td>2</td>
                                                        <td>S3-33</td>
                                                        <td><Checkbox disabled/></td>
                                                    </tr>
                                                     <tr>
                                                        <td>3</td>
                                                        <td>S3-33</td>
                                                        <td><Checkbox disabled/></td>
                                                    </tr>
                                                     <tr>
                                                        <td>4</td>
                                                        <td>S3-33</td>
                                                        <td><Checkbox disabled/></td>
                                                    </tr>
                                                     <tr>
                                                        <td>5</td>
                                                        <td>S3-33</td>
                                                        <td><Checkbox disabled/></td>
                                                    </tr>
                                                     <tr>
                                                        <td>6</td>
                                                        <td>S3-33</td>
                                                        <td><Checkbox disabled/></td>
                                                    </tr>
                                                     <tr>
                                                        <td>7</td>
                                                        <td>S3-33</td>
                                                        <td><Checkbox disabled/></td>
                                                    </tr>
                                                     <tr>
                                                        <td>8</td>
                                                        <td>S3-33</td>
                                                        <td><Checkbox disabled/></td>
                                                    </tr>
                                                    <tr>
                                                        <td rowSpan="8">32</td>
                                                        <td>S3-33</td>
                                                        <td>1</td>
                                                        <td><Checkbox disabled/></td>
                                                    </tr>
                                                    <tr>
                                                        <td>2</td>
                                                        <td>S3-33</td>
                                                        <td><Checkbox disabled/></td>
                                                    </tr>
                                                     <tr>
                                                        <td>3</td>
                                                        <td>S3-33</td>
                                                        <td><Checkbox disabled/></td>
                                                    </tr>
                                                     <tr>
                                                        <td>4</td>
                                                        <td>S3-33</td>
                                                        <td><Checkbox disabled/></td>
                                                    </tr>
                                                     <tr>
                                                        <td>5</td>
                                                        <td>S3-33</td>
                                                        <td><Checkbox disabled/></td>
                                                    </tr>
                                                     <tr>
                                                        <td>6</td>
                                                        <td>S3-33</td>
                                                        <td><Checkbox disabled/></td>
                                                    </tr>
                                                     <tr>
                                                        <td>7</td>
                                                        <td>S3-33</td>
                                                        <td><Checkbox disabled/></td>
                                                    </tr>
                                                     <tr>
                                                        <td>8</td>
                                                        <td>S3-33</td>
                                                        <td><Checkbox disabled/></td>
                                                    </tr>
                                                </tbody>
                                            </Table>
                                        </td>
                                        <td className="print-array-td">
                                            <Table className="tbl-ver" bordered>
                                                <thead>
                                                    <tr>
                                                        <th><Checkbox disabled/></th>
                                                        <th>페이지</th>
                                                        <th>내용</th>
                                                        <th>교체</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <tr>
                                                        <td rowSpan="8">33</td>
                                                        <td>S3-33</td>
                                                        <td>1</td>
                                                        <td><Checkbox disabled/></td>
                                                    </tr>
                                                    <tr>
                                                        <td>2</td>
                                                        <td>S3-33</td>
                                                        <td><Checkbox disabled/></td>
                                                    </tr>
                                                     <tr>
                                                        <td>3</td>
                                                        <td>S3-33</td>
                                                        <td><Checkbox disabled/></td>
                                                    </tr>
                                                     <tr>
                                                        <td>4</td>
                                                        <td>S3-33</td>
                                                        <td><Checkbox disabled/></td>
                                                    </tr>
                                                     <tr>
                                                        <td>5</td>
                                                        <td>S3-33</td>
                                                        <td><Checkbox disabled/></td>
                                                    </tr>
                                                     <tr>
                                                        <td>6</td>
                                                        <td>S3-33</td>
                                                        <td><Checkbox disabled/></td>
                                                    </tr>
                                                     <tr>
                                                        <td>7</td>
                                                        <td>S3-33</td>
                                                        <td><Checkbox disabled/></td>
                                                    </tr>
                                                     <tr>
                                                        <td>8</td>
                                                        <td>S3-33</td>
                                                        <td><Checkbox disabled/></td>
                                                    </tr>
                                                    <tr>
                                                        <td rowSpan="8">40</td>
                                                        <td>S3-33</td>
                                                        <td>1</td>
                                                        <td><Checkbox disabled/></td>
                                                    </tr>
                                                    <tr>
                                                        <td>2</td>
                                                        <td>S3-33</td>
                                                        <td><Checkbox disabled/></td>
                                                    </tr>
                                                     <tr>
                                                        <td>3</td>
                                                        <td>S3-33</td>
                                                        <td><Checkbox disabled/></td>
                                                    </tr>
                                                     <tr>
                                                        <td>4</td>
                                                        <td>S3-33</td>
                                                        <td><Checkbox disabled/></td>
                                                    </tr>
                                                     <tr>
                                                        <td>5</td>
                                                        <td>S3-33</td>
                                                        <td><Checkbox disabled/></td>
                                                    </tr>
                                                     <tr>
                                                        <td>6</td>
                                                        <td>S3-33</td>
                                                        <td><Checkbox disabled/></td>
                                                    </tr>
                                                     <tr>
                                                        <td>7</td>
                                                        <td>S3-33</td>
                                                        <td><Checkbox disabled/></td>
                                                    </tr>
                                                     <tr>
                                                        <td>8</td>
                                                        <td>S3-33</td>
                                                        <td><Checkbox disabled/></td>
                                                    </tr>
                                                </tbody>
                                            </Table>
                                        </td>
                                        <td className="print-array-td">
                                            <Table className="tbl-ver" bordered>
                                                <thead>
                                                    <tr>
                                                        <th><Checkbox disabled/></th>
                                                        <th>페이지</th>
                                                        <th>내용</th>
                                                        <th>교체</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <tr>
                                                        <td rowSpan="8">41</td>
                                                        <td>S3-33</td>
                                                        <td>1</td>
                                                        <td><Checkbox readOnly defaultChecked/></td>
                                                    </tr>
                                                    <tr>
                                                        <td>2</td>
                                                        <td>S3-33</td>
                                                        <td><Checkbox readOnly defaultChecked/></td>
                                                    </tr>
                                                     <tr>
                                                        <td>3</td>
                                                        <td>S3-33</td>
                                                        <td><Checkbox readOnly defaultChecked/></td>
                                                    </tr>
                                                     <tr>
                                                        <td>4</td>
                                                        <td>S3-33</td>
                                                        <td><Checkbox readOnly defaultChecked/></td>
                                                    </tr>
                                                     <tr>
                                                        <td>5</td>
                                                        <td>S3-33</td>
                                                        <td><Checkbox disabled/></td>
                                                    </tr>
                                                     <tr>
                                                        <td>6</td>
                                                        <td>S3-33</td>
                                                        <td><Checkbox disabled/></td>
                                                    </tr>
                                                     <tr>
                                                        <td>7</td>
                                                        <td>S3-33</td>
                                                        <td><Checkbox disabled/></td>
                                                    </tr>
                                                     <tr>
                                                        <td>8</td>
                                                        <td>S3-33</td>
                                                        <td><Checkbox disabled/></td>
                                                    </tr>
                                                    <tr>
                                                        <td rowSpan="8">48</td>
                                                        <td>S3-33</td>
                                                        <td>1</td>
                                                        <td><Checkbox disabled/></td>
                                                    </tr>
                                                    <tr>
                                                        <td>2</td>
                                                        <td>S3-33</td>
                                                        <td><Checkbox disabled/></td>
                                                    </tr>
                                                     <tr>
                                                        <td>3</td>
                                                        <td>S3-33</td>
                                                        <td><Checkbox disabled/></td>
                                                    </tr>
                                                     <tr>
                                                        <td>4</td>
                                                        <td>S3-33</td>
                                                        <td><Checkbox disabled/></td>
                                                    </tr>
                                                     <tr>
                                                        <td>5</td>
                                                        <td>S3-33</td>
                                                        <td><Checkbox readOnly defaultChecked/></td>
                                                    </tr>
                                                    <tr>
                                                        <td>6</td>
                                                        <td>S3-33</td>
                                                        <td><Checkbox disabled/></td>
                                                    </tr>
                                                     <tr>
                                                        <td>7</td>
                                                        <td>S3-33</td>
                                                        <td><Checkbox readOnly defaultChecked/></td>
                                                    </tr>
                                                     <tr>
                                                        <td>8</td>
                                                        <td>S3-33</td>
                                                        <td><Checkbox readOnly defaultChecked/></td>
                                                    </tr>
                                                </tbody>
                                            </Table>
                                        </td>
                                        <td className="print-array-td">
                                            <Table className="tbl-ver" bordered>
                                                <thead>
                                                    <tr>
                                                        <th><Checkbox disabled/></th>
                                                        <th>페이지</th>
                                                        <th>내용</th>
                                                        <th>교체</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <tr>
                                                        <td rowSpan="8">49</td>
                                                        <td>S3-33</td>
                                                        <td>1</td>
                                                        <td><Checkbox disabled/></td>
                                                    </tr>
                                                    <tr>
                                                        <td>2</td>
                                                        <td>S3-33</td>
                                                        <td><Checkbox disabled/></td>
                                                    </tr>
                                                     <tr>
                                                        <td>3</td>
                                                        <td>S3-33</td>
                                                        <td><Checkbox disabled/></td>
                                                    </tr>
                                                     <tr>
                                                        <td>4</td>
                                                        <td>S3-33</td>
                                                        <td><Checkbox disabled/></td>
                                                    </tr>
                                                     <tr>
                                                        <td>5</td>
                                                        <td>S3-33</td>
                                                        <td><Checkbox disabled/></td>
                                                    </tr>
                                                     <tr>
                                                        <td>6</td>
                                                        <td>S3-33</td>
                                                        <td><Checkbox readOnly defaultChecked/></td>
                                                    </tr>
                                                     <tr>
                                                        <td>7</td>
                                                        <td>S3-33</td>
                                                        <td><Checkbox readOnly defaultChecked/></td>
                                                    </tr>
                                                     <tr>
                                                        <td>8</td>
                                                        <td>S3-33</td>
                                                        <td><Checkbox disabled/></td>
                                                    </tr>
                                                    <tr>
                                                        <td rowSpan="8">56</td>
                                                        <td>S3-33</td>
                                                        <td>1</td>
                                                        <td><Checkbox disabled/></td>
                                                    </tr>
                                                    <tr>
                                                        <td>2</td>
                                                        <td>S3-33</td>
                                                        <td><Checkbox disabled/></td>
                                                    </tr>
                                                     <tr>
                                                        <td>3</td>
                                                        <td>S3-33</td>
                                                        <td><Checkbox disabled/></td>
                                                    </tr>
                                                     <tr>
                                                        <td>4</td>
                                                        <td>S3-33</td>
                                                        <td><Checkbox disabled/></td>
                                                    </tr>
                                                     <tr>
                                                        <td>5</td>
                                                        <td>S3-33</td>
                                                        <td><Checkbox disabled/></td>
                                                    </tr>
                                                     <tr>
                                                        <td>6</td>
                                                        <td>S3-33</td>
                                                        <td><Checkbox disabled/></td>
                                                    </tr>
                                                     <tr>
                                                        <td>7</td>
                                                        <td>S3-33</td>
                                                        <td><Checkbox disabled/></td>
                                                    </tr>
                                                     <tr>
                                                        <td>8</td>
                                                        <td>S3-33</td>
                                                        <td><Checkbox disabled/></td>
                                                    </tr>
                                                </tbody>
                                            </Table>
                                        </td>
                                    </tr>
                                </tbody>
                            </Table>
                        </div>
                        
                    </Modal.Body>
                    <Modal.Footer>
                        <Button variant="primary" size="md" onClick={onClickEvent}>확인</Button>
                    </Modal.Footer>
                </Modal>
            </Form>
        </>
    );

};
export default PrintArrayTable;