// react
import React, {useState, useEffect, useCallback} from 'react';
import {Button} from 'react-bootstrap';

//--------------  서버데이터용 필수 -------------------------------
import { useQuery} from 'react-query';
import { API, CONSTANTS } from '../../../../utils/constants';
import useStore from '../../../../utils/store';
import { getData } from '../../../../utils/async';
//--------------// 서버데이터용 필수 -------------------------------

import GridLangMast from '../_Grid/GridLangMast';
import Paging from '../../../Common/Paging';
import { CustomInputGroup } from '../../../Common/CustomInputGroup';

import LangCodeAdd from '../Popup/LangCodeAdd';
import LangCodeUpdate from '../Popup/LangCodeUpdate';

const LangMast = () => {
    
    //------------------- 필수 공통 ------------------------------
    const {keyword } = useStore();  // 조회키워드 가져오기
    const {grpCd } = useStore();  // 권한필요(그룹정보가져오기)
    const [paramData, setParamData] = useState();    // 페이지번호
    const [activePage, setActivePage] = useState(1);    // 페이지번호
    const [limit, setLimit] = useState(50);             // 페이지행수
    const [filterValue, setFilterValue] = useState(''); // 필터값

    const onChangePage = val => {
        setActivePage(val);
    };
    const onChangeLimit = val => {
        setLimit(val);
    };
    useEffect(()=>{
        onChangePage(1); // 페이지번호 리셋
    },[keyword]);

    // 필터
    const onFilterTextBoxChanged = useCallback((e) => {
        setFilterValue(e.target.value);
    }, []);

    //-------------------// 필수 공통 ------------------------------


    //  requestState 조회
    const queryResult = useQuery([API.langMsts, {}], () => getData(API.langMsts, {}),{
        staleTime: 0,
    });
    // 셀 클릭
    const onCellClicked = e => {
        if(e.column.colId === 'langCd'){
            setLangCodeUpdatePop(true)
        }
        setParamData(e.data)
    };
    useEffect(()=>{
    if(queryResult.isSuccess) {
        console.log("queryResult", queryResult.data);
    }

    },[queryResult.status])

    const [langCodeAddPop, setLangCodeAddPop] = useState(false);
    const [langCodeUpdatePop, setLangCodeUpdatePop] = useState(false);

    return (
        <>
            <div className="grid-wrap" style={{paddingTop: '10px', borderTop: '2px solid var(--main-color)'}}>
                <div className="grid-btn-wrap">
                    <div className="left-align">
                        {/*--------- 필터 -----------*/}
                        <CustomInputGroup size="sm"   onInput={onFilterTextBoxChanged} />
                    </div>
                    <div className="right-align">
                        {/*--------- 버튼 -----------*/}
                        <Button variant="outline-secondary" size="sm" onClick={() => setLangCodeAddPop(true)}>언어코드 등록</Button>{' '}
                        <Button variant="outline-success" size="sm"><span className="excel-down"></span>{CONSTANTS.excelDownload}</Button>{' '}
                    </div>
                </div>
                {/*--------- Grid -----------*/}
                <GridLangMast 
                    filterValue={filterValue}
                    queryResult={queryResult}
                    limit={limit}
                    activePage={activePage}
                    onCellClicked={onCellClicked}
                    />

                {/*--------- 페이징 -----------*/}
                <Paging 
                    total={queryResult && queryResult.data && queryResult.data.length}
                    limit={limit}
                    activePage={activePage}
                    onChangePage={onChangePage}
                    onChangeLimit={onChangeLimit}
                />
            </div>

            {/* 팝업 */}
            {langCodeAddPop && <LangCodeAdd show={langCodeAddPop} onHide={() => setLangCodeAddPop(false)}  />}
            {langCodeUpdatePop && <LangCodeUpdate auth={grpCd} show={langCodeUpdatePop} onHide={() => setLangCodeUpdatePop(false)} data = {paramData}  />}
        </>
    )
};
export default LangMast;