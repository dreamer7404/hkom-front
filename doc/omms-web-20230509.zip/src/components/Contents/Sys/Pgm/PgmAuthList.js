// react
import React, {useState, useEffect} from 'react';

//--------------  서버데이터용 필수 -------------------------------
import { useQuery} from 'react-query';
import useStore from '../../../../utils/store';
//--------------// 서버데이터용 필수 -------------------------------

import GridPgmAuthList from '../_Grid/GridPgmAuthList';
import Total from '../../../Common/Total';

import PgmAuthAdd from '../Popup/PgmAuthAdd';

const PgmAuthList = () => {

    //------------------- 필수 공통 ------------------------------
    const {keyword } = useStore();  // 조회키워드 가져오기

    const [activePage, setActivePage] = useState(1);    // 페이지번호
    const [limit, setLimit] = useState(50);             // 페이지행수

    const onChangePage = val => {
        setActivePage(val);
    };
    const onChangeLimit = val => {
        setLimit(val);
    };
    useEffect(()=>{
        onChangePage(1); // 페이지번호 리셋
    },[keyword]);


    //-------------------// 필수 공통 ------------------------------

    const [rowData] = useState([
        {groupCd: "Group_Cd_01", groupNm:'테스트그룹1',order:'1', userCt:'40', useYn:'Y'},
        {groupCd: "Group_Cd_02", groupNm:'테스트그룹2',order:'2', userCt:'30', useYn:'Y'},
        {groupCd: "Group_Cd_03", groupNm:'테스트그룹3',order:'3', userCt:'20', useYn:'N'},
        {groupCd: "Group_Cd_04", groupNm:'테스트그룹4',order:'4', userCt:'10', useYn:'Y'},

    ]);

    //  requestState 조회
    const queryResult = useQuery(["PgmAuthList"], () => {return rowData});

    // 셀 클릭
    const onCellClicked = e => {
        if(e.column.colId === 'groupCd'){
            setPgmAuthAddPop(true)
        }
    };

    const [pgmAuthAddPop, setPgmAuthAddPop] = useState(false);

    return (
        <>
            <div className="grid-wrap" style={{paddingTop:'10px', borderTop:'2px solid var(--main-color)'}}>
                {/*--------- Grid -----------*/}
                <GridPgmAuthList 

                    queryResult={queryResult}
                    limit={limit}
                    activePage={activePage}
                    onCellClicked={onCellClicked}
                    />

                {/*--------- 페이징 -----------*/}
                <Total 
                    total={queryResult && queryResult.data && queryResult.data.length}
                    limit={limit}
                    activePage={activePage}
                    onChangePage={onChangePage}
                    onChangeLimit={onChangeLimit}
                />
            </div>

            <PgmAuthAdd show={pgmAuthAddPop} onHide={() => setPgmAuthAddPop(false)} />
        </>
    )
};
export default PgmAuthList;