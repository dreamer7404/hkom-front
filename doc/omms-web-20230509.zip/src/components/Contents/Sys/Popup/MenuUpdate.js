import React, {useEffect, useState} from 'react';
import {Button, Modal, Table} from 'react-bootstrap';
import {Form, SelectPicker, Schema, useToaster, Notification } from 'rsuite';

const { StringType, NumberType} = Schema.Types;
const model = Schema.Model({
    // grpNm: StringType().isRequired('그룹명를 입력해주세요.').pattern(/^[가-힣a-zA-Z]+$/, '한글, 영문만 입력사능합니다.'),
    // sortSn: NumberType().isRequired('정렬순서를 입력해주세요.').range(1, 99, '순서번호 범위는 1~99입니다'),
    // useYn: StringType().isRequired('사용유무를 선택해 주세요.'),
});

const MenuUpdate = ({show, onHide, grpCombo, data}) => {


    // const grpData = grpCombo
    useEffect(() => {
        console.log('formValue', formValue)
    },[]);

    // Form 정의
    const formRef = React.useRef();
    const [formError, setFormError] = React.useState({});
    const [formValue, setFormValue] = React.useState(data);

    return (
        <>
            <Form
              ref={formRef}
              checkTrigger="change"
              onChange={setFormValue}
              onCheck={setFormError}
              formValue={formValue}
              model={model}>
                <Modal show={show} onHide={onHide} backdrop="static" keyboard={false} centered size="md" className="modal-custom">
                    <Modal.Header closeButton>
                        <Modal.Title>메뉴 상세/수정</Modal.Title>
                    </Modal.Header>
                        <Modal.Body>
                            <Table className="tbl-hor" bordered>
                                <colgroup>
                                    <col style={{width:'30%'}}></col>
                                    <col style={{width:''}}></col>
                                </colgroup>
                                <tbody>
                                    <tr>
                                        <th className="essen">메뉴그룹</th>
                                        <td>
                                            <Form.Control name="grpNm" size="sm" 
                                                defaultValue={formValue.grpNm}
                                                accepter={SelectPicker} 
                                                searchable={false}
                                                cleanable={false}
                                                data={formValue.grpNm && grpCombo.filter(d=> d.value !== '')}
                                            ></Form.Control>
                                        </td>
                                    </tr>
                                    <tr>
                                        <th className="essen">메뉴명</th>
                                        <td colspan="3">
                                        <Form.Control size="sm" name="pgmNm" /> 
                                        </td>
                                    </tr>
                                    <tr>
                                        <th className="essen">순번</th>
                                        <td>
                                            <Form.Control size="sm" name="pgmIdSn" /> 
                                        </td>
                                    </tr>
                                    <tr>
                                        <th className="essen">URL</th>
                                        <td colspan="3">
                                        <Form.Control size="sm" name="pgmPathAdr"/> 
                                        </td>
                                    </tr>
                                    <tr>
                                        <th className="">사용여부</th>
                                        <td colspan="3">
                                            <Form.Control name="useYn" size="sm" 
                                                placeholder={'선택'}
                                                defaultValue={formValue.useYn}
                                                accepter={SelectPicker} 
                                                searchable={false}
                                                cleanable={false}
                                                data={[
                                                    {label: '사용', value: 'Y'},
                                                    {label: '미사용', value: 'N'},
                                                ]}
                                            ></Form.Control>
                                        </td>
                                    </tr>
                                </tbody>
                            </Table>
                        </Modal.Body>

                        <Modal.Footer>
                            <Button variant="light" size="md" onClick={onHide}>취소</Button>
                            <Button variant="outline-danger" size="md" onClick={onHide}>삭제</Button>
                            <Button variant="primary" size="md" onClick={onHide} >저장</Button>
                        </Modal.Footer>
                </Modal>
            </Form>
        </>
    );

};
export default MenuUpdate;