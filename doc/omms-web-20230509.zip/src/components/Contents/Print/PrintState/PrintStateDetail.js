// react
import React, {useState, useEffect, useCallback} from 'react';

import {Button, Table} from 'react-bootstrap';
import { CONSTANTS } from '../../../../utils/constants';

//--------------  서버데이터용 필수 -------------------------------
import { useQuery} from 'react-query';
import useStore from '../../../../utils/store';
//--------------// 서버데이터용 필수 -------------------------------

import GridPrintOrderAdd from '../_Grid/GridPrintOrderAdd';
import OutRequestChange from '../Popup/OutRequestChange';
import PrintArrayTable from '../Popup/PrintArrayTable';
import PrintCost from '../Popup/PrintCost';
import PrintCostInputNo from '../Popup/PrintCostInputNo';
import { useLocation } from 'react-router';
import qs from 'qs';
const PrintStateDetail = () => {

     //------------------- 필수 공통 ------------------------------
    const [open, setOpen] = useState(true); // 조건창 열기/닫기
    const {keyword } = useStore();  // 조회키워드 가져오기

    const [activePage, setActivePage] = useState(1);    // 페이지번호
    const [limit, setLimit] = useState(50);             // 페이지행수
    const [filterValue, setFilterValue] = useState(''); // 필터값
    const [newPrntPbcnNo, setNewPrntPbcnNo] = useState();
    const location = useLocation();
    const [query, setQuery] = useState(
        qs.parse(location.state, { ignoreQueryPrefix: true }),
    )
    
    // setNewPrntPbcnNo(param);
    useEffect(() => {
        console.log("here",query);
        // newPrntPbcnNo:"PJJO-UK31B"
    },[]);

    

    const onChangePage = val => {
        setActivePage(val);
    };
    const onChangeLimit = val => {
        setLimit(val);
    };
    useEffect(()=>{
        onChangePage(1); // 페이지번호 리셋
    },[keyword]);

    // 필터
    const onFilterTextBoxChanged = useCallback((e) => {
        setFilterValue(e.target.value);
    }, []);

    // 검색창 열기/닫기 > 페이지네이션 여부에 따라 +-20px
    const gridExpand = () =>{
        setOpen(!open);
    }

    //-------------------// 필수 공통 ------------------------------

    const listButton = () => {
        window.location.href="./PrintStateList"
    }

     const [rowData] = useState([
        {test1: "20", test2: "60", test3: "50", test4: '40', test5:'30', test6:'20', test7:'100', test8:'100', test9:'100', test10:'100', test11:'100', test12:'a', test13:'OK'},
    ]);

    //  requestState 조회
    const queryResult = useQuery(["PrintOrderAdd"], () => {return rowData});

    
    const [outRequestChange, setOutRequestChange] = useState(false);
    const [printCost, setPrintCost] = useState(false);
    const [printCostInputNo, setPrintCostInputNo] = useState(false);
    const [printArrayTablePop, setPrintArrayTablePop] = useState(false);

    return (
        <>
            <div className="grid-wrap">
                <div className="grid-btn-wrap">
                    <div className="left-align">
                        <div class="sub-title">
                            <ul>
                                <li>발간실적 기준정보</li>
                            </ul>
                        </div>
                    </div>
                    <div className="right-align">
                        <Button variant="outline-dark" size="sm"><span className="print"></span>{CONSTANTS.print}</Button>{' '}
                    </div>
                </div>
                {/*--------- Grid -----------*/}
                <GridPrintOrderAdd 
                    filterValue={filterValue}
                    queryResult={queryResult}
                    limit={limit}
                    activePage={activePage}
                />

                <div className="grid-btn-wrap mt-4">
                    <div className="left-align">
                        <div class="sub-title">
                            <ul>
                                <li>세부내역</li>
                            </ul>
                        </div>
                    </div>
                    <div className="right-align">
                        <Button variant="outline-secondary" size="sm" onClick={() => setOutRequestChange(true)}>납품요청일 변경</Button>{' '}
                        <Button variant="outline-secondary" size="sm" onClick={() => setPrintArrayTablePop(true)}>인쇄배열표</Button>{' '}
                    </div>
                </div>
                
                <Table className="tbl-hor" bordered>
                    <colgroup>
                        <col style={{width:'15%'}}></col>
                        <col style={{width:'15%'}}></col>
                        <col style={{width:''}}></col>
                        <col style={{width:'15%'}}></col>
                        <col style={{width:'15%'}}></col>
                        <col style={{width:'%'}}></col>
                    </colgroup>
                    <tbody>
                        <tr>
                            <th colspan="2">차종</th>
                            <td>(AD-20)AVANTE</td>
                            <th colspan="2">언어</th>
                            <td>EC(영어,불어/캐나다)</td>
                        </tr>
                        <tr>
                            <th colspan="2">인쇄부수</th>
                            <td>500</td>
                            <th rowspan="4">인쇄페이지</th>
                            <th>총 페이지</th>
                            <td>572</td>
                        </tr>
                        <tr>
                            <th rowspan="2">납품</th>
                            <th>납품일</th>
                            <td>2023-03-31</td>
                            <th>표지</th>
                            <td>4</td>
                        </tr>
                        <tr>
                            <th>납품장소</th>
                            <td>울산</td>
                            <th>설명서</th>
                            <td>500</td>
                        </tr>
                        <tr>
                            <th rowspan="2">발간번호</th>
                            <th>신규번호</th>
                            <td>AFD-EJKN</td>
                            <th>보증서/엽서</th>
                            <td>4</td>
                        </tr>
                        <tr>
                            <th>기존번호</th>
                            <td>AFD-NIE</td>
                            <th rowspan="2">옵셋(내지)</th>
                            <th>기존필름이용</th>
                            <td></td>
                        </tr>
                        <tr>
                            <th colspan="2">발행방법</th>
                            <td>신제작</td>
                            <th>신규필름제작(교정포함)</th>
                            <td>4</td>
                        </tr>
                        <tr>
                            <th colspan="2">제본</th>
                            <td>무선제본</td>
                            <th>디지털(내지)</th>
                            <th>디지털 인쇄</th>
                            <td>0</td>
                        </tr>
                        <tr>
                            <th colspan="2">규격</th>
                            <td>210*148mm</td>
                            <th colspan="2">외주편집페이지</th>
                            <td>4</td>
                        </tr>
                        <tr>
                            <th rowspan="2">지질</th>
                            <th>표지</th>
                            <td>250아트</td>
                            <th colspan="2">외주편집업체</th>
                            <td>없음</td>
                        </tr>
                        <tr>
                            <th>내지</th>
                            <td>80화인코드지</td>
                            <th colspan="2">커버수량</th>
                            <td>0</td>
                        </tr>
                        <tr>
                            <th rowspan="2">인쇄</th>
                            <th>표지</th>
                            <td>옵셋</td>
                            <th colspan="2">비고</th>
                            <td></td>
                        </tr>
                        <tr>
                            <th>내지</th>
                            <td></td>
                            <th colspan="2">표지코팅</th>
                            <td>무광코팅</td>
                        </tr>
                        <tr>
                            <th rowspan="2">인쇄도수</th>
                            <th>표지</th>
                            <td>1</td>
                            <th colspan="2">게시판 관리번호</th>
                            <td>
                                <a href="#">abc-test</a>
                            </td>
                        </tr>
                        <tr>
                            <th>내지</th>
                            <td></td>
                            <th colspan="2"></th>
                            <td></td>
                        </tr>
                        <tr>
                            <th colspan="2">메모</th>
                            <td colspan="4"></td>
                        </tr>
                        <tr>
                            <th colspan="2">발주자</th>
                            <td>홍길동</td>
                            <th colspan="2">발주일</th>
                            <td>2023-03-31</td>
                        </tr>
                    </tbody>
                </Table>

                <div className="grid-btn-wrap mt-4">
                    <div className="left-align">
                        <div class="sub-title">
                            <ul>
                                <li>인쇄비용</li>
                            </ul>
                        </div>
                    </div>
                    <div className="right-align">
                        <Button variant="outline-secondary" size="sm" onClick={() => setPrintCost(true)}>인쇄비 입력</Button>{' '}
                        <Button variant="outline-secondary" size="sm" onClick={() => setPrintCostInputNo(true)}>인쇄비 품의번호 입력</Button>{' '}
                    </div>
                </div>
                <Table className="tbl-ver" bordered>
                    <colgroup>
                        <col style={{width:'25%'}}></col>
                        <col style={{width:'25%'}}></col>
                        <col style={{width:'25%'}}></col>
                        <col style={{width:'25%'}}></col>
                    </colgroup>
                    <thead>
                        <tr>
                            <th>평균단가</th>
                            <th>소요예산</th>
                            <th>견적서</th>
                            <th>인쇄비 품의번호</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>5,000</td>
                            <td>150,000</td>
                            <td>첨부</td>
                            <td>15321</td>
                        </tr>
                    </tbody>
                </Table>


                <div className="grid-btn-wrap mt-4">
                    <div className="left-align">
                        <div class="sub-title">
                            <ul>
                                <li>개정내용</li>
                            </ul>
                        </div>
                    </div>
                </div>
                <Table className="tbl-ver" bordered>
                    <colgroup>
                        <col style={{width:'10%'}}></col>
                        <col style={{width:''}}></col>
                        <col style={{width:'10%'}}></col>
                    </colgroup>
                    <thead>
                        <tr>
                            <th>등록번호</th>
                            <th>개정내용</th>
                            <th>첨부</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>EF-001-as</td>
                            <td>개정내용입니다.</td>
                            <td></td>
                        </tr>
                    </tbody>
                </Table>

                <div className="btn-wrap">
                    <div className="left-align">
                        <Button variant="light" onClick={listButton}>목록</Button>{' '}
                    </div>
                </div>
            </div>

            <OutRequestChange show={outRequestChange} onHide={() => setOutRequestChange(false)}  />
            <PrintArrayTable show={printArrayTablePop} onHide={() => setPrintArrayTablePop(false)}  />
            <PrintCost show={printCost} onHide={() => setPrintCost(false)}  />
            <PrintCostInputNo show={printCostInputNo} onHide={() => setPrintCostInputNo(false)}  />
        </>
    )
};
export default PrintStateDetail;