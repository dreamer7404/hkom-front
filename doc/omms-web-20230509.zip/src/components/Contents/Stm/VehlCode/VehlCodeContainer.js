import React,{useState, useEffect} from 'react';
import {Tab,Tabs} from 'react-bootstrap';

import VehlCodeList from './VehlCodeList';
import VehlMdyList from './VehlMdyList';

const VehlCodeContainer = () => {

    const [leftWidth, setLeftWidth] = useState('150px')
   
    useEffect(() => {
        const getTitle = document.getElementById('section-title-width');
        const titleWidth = getTitle.clientWidth + 40;
        setLeftWidth(titleWidth)
    }, []);

    const [activeTab, setActiveTab] = React.useState('tab1');

    return (
        <>
            <Tabs  defaultActiveKey="tab1" onSelect={tab => setActiveTab(tab)} style={{left: leftWidth}} >
                <Tab eventKey="tab1" title={"차종코드관리"}>
                {activeTab === 'tab1' && <VehlCodeList /> }
                </Tab>
                <Tab eventKey="tab2" title="차종연식관리">
                {activeTab === 'tab2' && <VehlMdyList />}
                </Tab>
            </Tabs>
        </>
    );

};
export default VehlCodeContainer;