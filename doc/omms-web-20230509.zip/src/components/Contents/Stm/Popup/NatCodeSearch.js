import React, {useState, useMemo} from 'react';
import {Button, Modal, Table} from 'react-bootstrap';
import { AgGridReact } from 'ag-grid-react';

const NatCodeSearch = ({show, onHide}) => {

    const defaultColDef = useMemo(() => {
        return {
            initialWidth: 90,
            resizable:true,
            sortable:true,
        };
    }, []);

    const [rowData] = useState([
        {natCd:'A1', natNm:'AFGHANISTAN', region: "일반"},
    ]);

    const columnDefs = [
        {
            headerName: '국가코드',
            field: 'natCd',
            spanHeaderHeight: true,
            maxWidth:'100',
            sortable:true,
            filter: 'agTextColumnFilter',
            floatingFilter: true,
            suppressMenu: true,
            filterParams: {
                filterOptions: ['contains'],
            },
             cellStyle: () => ({textDecoration: 'underline', cursor: 'pointer', color:'#2589f5'}) 
        },
        {
            headerName: '국가명',
            field: 'natNm',
            spanHeaderHeight: true,
            sortable:true,
            filter: 'agTextColumnFilter',
            floatingFilter: true,
            suppressMenu: true,
            filterParams: {
                filterOptions: ['contains'],
            },
            cellStyle: () => ({textDecoration: 'underline', cursor: 'pointer', color:'#2589f5'}) 
        },
        {
            headerName: '지역',
            field: 'region',
            spanHeaderHeight: true,
            maxWidth:'100',
        },
    ]

    const onFirstDataRendered = (params) => {
        params.api.sizeColumnsToFit();
    };

    return (
        <>
            <Modal show={show} onHide={onHide} backdrop="static" backdropClassName="modal-in-backdrop" keyboard={false} centered size="md" className="modal-custom modal-in-modal">
                <Modal.Header closeButton>
                    <Modal.Title>국가코드 검색</Modal.Title>
                </Modal.Header>
                    <Modal.Body>
                          <div className="ag-theme-alpine" style={{height:300}}>
                                <AgGridReact
                                    rowData={rowData}
                                    columnDefs={columnDefs}
                                    defaultColDef={defaultColDef}
                                    
                                    rowSelection={'multiple'}
                                    suppressRowClickSelection= {true} 

                                    onFirstDataRendered={onFirstDataRendered}
                                    suppressSizeToFit={true}    
                                    onGridSizeChanged={onFirstDataRendered}     
                                    >
                                </AgGridReact>
                            </div>
                    </Modal.Body>
                    <Modal.Footer>
                        <Button variant="light" size="md" onClick={onHide}>취소</Button>
                    </Modal.Footer>
            </Modal>
        </>
    );

};
export default NatCodeSearch;