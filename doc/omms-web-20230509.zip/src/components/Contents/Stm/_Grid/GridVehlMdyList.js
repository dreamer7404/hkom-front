/* eslint-disable react-hooks/exhaustive-deps */
import React, {useEffect,useState, useMemo, useRef} from 'react';
import { AgGridReact } from 'ag-grid-react';
import { CONSTANTS } from '../../../../utils/constants';
import { escapeCharChangeForGrid, formatNumber } from '../../../../utils/commUtils';

const GridVehlMdyList = ({gridHeight, filterValue, queryResult, limit, activePage, onCellClicked}) => {

  
  const gridRef = useRef();

  const [columnDefs, setColumnDefs] = useState( [
    {
      headerName: '차종',
      children: [
        { headerName:'차종코드', field: 'qltyVehlCd'},
        { headerName:'차종명', field: 'qltyVehlNm',
          cellRenderer: data => escapeCharChangeForGrid(data),
          cellStyle: () => ({textDecoration: 'underline', cursor: 'pointer', color:'#2589f5',}) 
          
        },
      ],
    },
    {
      headerName: '지역',
      spanHeaderHeight: true,
      field: 'dlExpdPrvsNm',
    },
  ]);

  useEffect(()=>{
    if(queryResult.isSuccess && queryResult.data) {

     

      console.log('queryResult', queryResult.data);

      const item = queryResult.data.dateList;

      let uniqueValues = [];
      const colors = ['#ffe6cc', '#ccffe6', '#cce6ff'];

      const arr = item.map(p=>({
          minWidth:'90',
          headerName:p.value,
          field :p.value? p.key:null,
          cellStyle: (params) => {
            // 'col' 검색
            const keys = Object.keys(params.data).filter(m => m.substring(0, 3) === 'col').sort();
            let values = [];
            // 'col'값 목록
            for(let i=0; i<keys.length; i++){
              values.push(params.data[keys[i]]);
            }
            // 'col'값 목록 중복제거
            uniqueValues = [...new Set(values)];

            // 바탕색 지정
            if(params.value === uniqueValues[0]) return {backgroundColor: colors[0]};
            if(params.value === uniqueValues[1]) return {backgroundColor: colors[1]};
            if(params.value === uniqueValues[2]) return {backgroundColor: colors[2]};
          },
      }));

      setColumnDefs(columnDefs.filter(item => item.headerName !== '월팩')
        .concat({
          headerName: '월팩',
          children: arr,
        }
        ,{
          headerName: '종료미지정',
          children: [
            { 
              headerName:'9999', field: 'col13', minWidth:'120',
              cellStyle: (params) => {
                const index = uniqueValues.length-1;
                return params.value === uniqueValues[index] ? {backgroundColor: colors[index]} : {};
              }
            }
          ]
        }
      ))}
  },[queryResult.status]);


    
  const defaultColDef = useMemo(() => {
      return {
          initialWidth: 90,
          sortable: true,
          resizable:true,
      };
  }, []);

  const columnFunction =(params) =>{
    const yearMonth1 = params.data.col1;
    const yearMonth2 = params.data.col2;
        
      return yearMonth1 === yearMonth2 ? 2 : 1
  }


  const onFirstDataRendered = (params) => {
      params.api.sizeColumnsToFit();
  };

  useEffect(()=>{
    
    if(queryResult.status === 'loading' && gridRef && gridRef.current && gridRef.current.api){
        gridRef.current.api.showLoadingOverlay();
    }
    
  },[queryResult]);
  
  useEffect(()=> {
    if(gridRef && gridRef.current && gridRef.current.api){
      gridRef.current.api.setQuickFilter(filterValue);
    }
  },[filterValue]);

  useEffect(()=> {
    if(gridRef && gridRef.current && gridRef.current.api){
      gridRef.current.api.paginationGoToPage(activePage-1);
    }
  },[activePage]);


  return(
      <div className="ag-theme-alpine" style={{height: gridHeight, transition:'all ease .3s'}}>
        <AgGridReact
            ref={gridRef} 
            rowData={queryResult && queryResult.data.mdyList.slice(0,2)} 
            columnDefs={columnDefs}
            defaultColDef={defaultColDef}

            // paging
            pagination={true}
            paginationPageSize={limit} //
            suppressPaginationPanel={true} 
            // onPaginationChanged={onPaginationChanged}

            //  filter
            cacheQuickFilter={true}

            onCellClicked={onCellClicked}

            // overlay
            overlayLoadingTemplate={CONSTANTS.gridLoading}
            overlayNoRowsTemplate={CONSTANTS.gridNoRows}

            onFirstDataRendered={onFirstDataRendered}
            suppressSizeToFit={true}    
            onGridSizeChanged={onFirstDataRendered}    
            >
        </AgGridReact>
    </div>
  )


};
export default GridVehlMdyList;