import React from 'react';
import {Button} from 'react-bootstrap';

const ConfirmAlert = ({onClose, title,  msg, onOk}) => {
    return (
        <div className=''>
            <h1>{title}</h1>
            <p dangerouslySetInnerHTML={{__html: msg }}></p>
            <div className="btn-wrap">
            {onOk && <>
                <Button variant="light" size="md" onClick={onClose}>취소</Button>
                <Button variant="primary" size="md" onClick={()=> {onOk(); onClose();}}>확인</Button>
                </>}
            {!onOk && <Button variant="primary" size="md" onClick={onClose}>확인</Button>}    
            </div>
        </div>
        );
};
export default ConfirmAlert;
