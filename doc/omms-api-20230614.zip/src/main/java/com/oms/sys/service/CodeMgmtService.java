package com.oms.sys.service;

import java.util.HashMap;
import java.util.List;

import com.oms.common.dto.CommReqDTO;
import com.oms.stm.model.CodeMgmt;
import com.oms.sys.dto.CodeMgmtReqDTO;
import com.oms.sys.dto.CodeMgmtResDTO;


/**
 * <pre>
 * CodeMgmtService
 * </pre>
 *
 * @ClassName   : CodeMgmtService.java
 * @Description : 클래스 설명을 기술합니다.
 * @author 안경수
 * @since 2023.1.19
 * @see
 */


public interface CodeMgmtService {
    public Integer insertCodeMgmt(CodeMgmtReqDTO codeMgmtReqDTO) throws Exception;
    public Integer updateCodeMgmt(CodeMgmtReqDTO codeMgmtReqDTO) throws Exception;
    public Integer deleteCodeMgmt(CodeMgmtReqDTO codeMgmtReqDTO) throws Exception;
    public List<CodeMgmtResDTO> selectCodeMgmtList(CodeMgmtReqDTO codeMgmtReqDTO) throws Exception;



    /**
     * Statements
     *
     * @return
     */
    public List<HashMap<String, Object>> selectGrpCodeCombo();
    /**
     * Statements
     *
     * @param codeMgmtReqDTO
     * @return
     */
    public Integer insertCodeGrpMgmt(CodeMgmtReqDTO codeMgmtReqDTO);
    /**
     * Statements
     *
     * @param codeMgmtReqDTO
     * @return
     */
    public Integer updateCodeGrpMgmt(CodeMgmtReqDTO codeMgmtReqDTO);
    /**
     * Statements
     *
     * @param codeMgmtReqDTO
     * @return
     */
    public Integer deleteCodeGrpMgmt(CodeMgmtReqDTO codeMgmtReqDTO);
    /**
     * Statements
     *
     * @return
     */
    public HashMap<String, Object> selectNextGrpCode();
    /**
     * Statements
     *
     * @param codeMgmtReqDTO
     * @return
     */
    public String getCodeGrpChk(CodeMgmtReqDTO codeMgmtReqDTO);
}
