package com.oms.sys.dto;

import java.sql.Timestamp;

import org.apache.ibatis.type.Alias;

import lombok.AllArgsConstructor;
import lombok.Data;

/**
 * <pre>
 * 사용자 차종권한
 * </pre>
 *
 * @author 안경수
 * @since 2023. 4. 15.
 * @see
 */
@Alias("usrVehlResDTO")
@Data
public class UsrVehlResDTO {
    private String qltyVehlCd;  // TB_VEHL_MGMT.QLTY_VEHL_CD => 차종코드
    private String authVehl;    // TB_AUTH_VEHL(차종권한관리)에 있으면 'Y' or 'N'
    private String qltyVehlNm;  // MAX(TB_VEHL_MGMT.QLTY_VEHL_NM)=> 차종명
    private String clScnCd;     // MAX(TB_AUTH_VEHL.CL_SCN_CD) => 분류구분코드  수정용/조회용 ('U'/'R')
}
