package com.oms.sys.dao;

import java.util.List;

import com.oms.common.dto.CommReqDTO;
import com.oms.common.model.Mail;
import com.oms.sys.dto.AuthReqDTO;
import com.oms.sys.dto.AuthVehlSaveDTO;
import com.oms.sys.dto.UseYnReqDTO;
import com.oms.sys.dto.UsrMgmtReqDTO;
import com.oms.sys.dto.UsrMgmtResDTO;
import com.oms.sys.dto.UsrVehlResDTO;
import com.oms.sys.model.UsrMgmt;

/**
 * <pre>
 * UsrMgmt DAO 인터페이스
 * </pre>
 *
 * @Class Name  : UsrMgmtDAO.java
 * @Description :
 * @author 안경수
 * @since 2023.1.19
 * @see
*/
public interface UsrMgmtDAO {
    Integer insertUsrMgmt(UsrMgmtReqDTO usrMgmtReqDTO) throws Exception;
    Integer updateUsrMgmt(UsrMgmtReqDTO usrMgmtReqDTO) throws Exception;
    Integer deleteUsrMgmt(UsrMgmtReqDTO usrMgmtReqDTO) throws Exception;
    UsrMgmtResDTO selectUsrMgmt(String id) throws Exception;
    List<UsrMgmtResDTO> selectUsrMgmtList(UsrMgmtReqDTO usrMgmtReqDTO) throws Exception;
    Integer deleteVehlAuthList(AuthVehlSaveDTO dto);
    Integer insertVehlAuthList(List<AuthVehlSaveDTO> list);
    List<UsrVehlResDTO> selectUserVehlList(CommReqDTO commReqDTO) throws Exception;
    Integer deleteVehlAuthListByUserEeno(String userEeno) throws Exception;
    Integer updateUserPw(UsrMgmtReqDTO usrMgmtReqDTO) throws Exception;
    Integer updateUserUseYn(UseYnReqDTO useYnReqDTO ) throws Exception;
    Integer updateUserPwLock(String userEeno) throws Exception;
    Integer updateUserBlnsCoCd(AuthReqDTO authReqDTO) throws Exception;
    Integer updateUserPwErrOft(AuthReqDTO authReqDTO) throws Exception;
    Integer updateUserLoginOk(AuthReqDTO authReqDTO) throws Exception;
    UsrMgmt selectUsrMgmt4FindPw(UsrMgmtReqDTO usrMgmtReqDTO) throws Exception;

}
