package com.oms.common.service.impl;

import java.util.List;

import javax.mail.Message;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import org.apache.commons.text.StringEscapeUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.javamail.MimeMessageHelper;
//import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

import com.oms.common.dao.AttcFileDAO;
import com.oms.common.dto.AttcFileReqDTO;
import com.oms.common.dto.MailDTO;
import com.oms.common.model.Mail;
import com.oms.common.service.AttcFileService;

import lombok.RequiredArgsConstructor;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @author 안경수
 * @since 2023. 5. 16.
 * @see
 */

@RequiredArgsConstructor
@Service
public class AttcFileServiceImpl implements  AttcFileService {

    private final AttcFileDAO attcFileDao;

    @Override
    public int insertAttcFile(AttcFileReqDTO attcFileReqDTO) {
        return attcFileDao.insertAttcFile(attcFileReqDTO);
    }

    @Override
    public int updateAttcFile(List<AttcFileReqDTO> list) {
        return attcFileDao.updateAttcFile(list);
    }






}
