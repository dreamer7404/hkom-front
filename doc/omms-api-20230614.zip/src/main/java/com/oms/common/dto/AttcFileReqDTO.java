package com.oms.common.dto;

import java.sql.Timestamp;
import java.util.List;

import org.apache.ibatis.type.Alias;

import com.oms.common.model.Mail;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @author 안경수
 * @since 2023. 6. 13.
 * @see
 */
@NoArgsConstructor
@Data
@Alias("attcFileReqDTO")
public class AttcFileReqDTO {
    private Long attcSn;    // 첨부일련번호
    private String attcGbn; //항목구분(0040)
    private String gbnSn;  // 항목의게시물정보
    private Long blcSn;  // 업무게시물번호
    private String fileType;
    private String fileNm;
    private String fileReNm;
    private String filePath;
    private Integer fileSize;
    private String pprrEeno;
    private String framDtm;

    /**
     * Statements
     *
     * @param fileReNm
     * @param filePath
     */
    public AttcFileReqDTO(String fileReNm, String filePath) {
        super();
        this.fileReNm = fileReNm;
        this.filePath = filePath;
    }

    /**
     * Statements
     *
     * @param attcSn
     * @param attcGbn
     * @param gbnSn
     * @param blcSn
     * @param fileType
     * @param fileNm
     * @param fileSize
     * @param pprrEeno
     */
    public AttcFileReqDTO(Long attcSn, String attcGbn, String gbnSn, Long blcSn, String fileType, String fileNm,
            Integer fileSize, String pprrEeno) {
        super();
        this.attcSn = attcSn;
        this.attcGbn = attcGbn;
        this.gbnSn = gbnSn;
        this.blcSn = blcSn;
        this.fileType = fileType;
        this.fileNm = fileNm;
        this.fileSize = fileSize;
        this.pprrEeno = pprrEeno;
    }


}
