package com.oms.common.dto;

import java.sql.Timestamp;

import org.apache.ibatis.type.Alias;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;



/**
 * <pre>
 * Statements
 * </pre>
 * @ClassName : rcvrReqDTO.java
 * @Description :  TB_RCVR_MGMT 수신자관리 테이블 공통 DTO입니다.
 * @author 김경훈
 * @since 2023. 3. 13.
 * @see
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Alias("rcvrReqDTO")
public class RcvrReqDTO {
    private String rcvrGbn;
    private String gbnSn;
    private String rcvrEeno;
    @Schema(type = "string", example = "1")
    private String sortSn;
    private String popCkDtm;
    private String pprrEeno;
    private Timestamp framDtm;
    private String updrEeno;
    private Timestamp mdfyDtm;
}
