package com.oms.stm.dto;

import java.sql.Timestamp;
import java.util.List;

import org.apache.ibatis.type.Alias;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.oms.common.dto.CommReqDTO;
import com.oms.sys.dto.AuthVehlSaveDTO;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;





/**
 * <pre>
 * Statements
 * </pre>
 * @ClassName : VehlMgmtReqDTO.java
 * @Description :
 * @author 김경훈
 * @since 2023. 3. 13.
 * @see
 */
@Alias("vehlMgmtReqDTO")
@NoArgsConstructor
@Data
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown=true)
public class VehlMgmtReqDTO extends CommReqDTO {

    private String qltyVehlCd;
    private String mdlMdyCd;
    private String pdi;
    private String c2qltyVehlCd;
    private String c2qltyVehlNm;
    private String c1qltyVehlCd;
    private String dlExpdRegnCd;
    private String dlExpdNatCd;
    private String c1mdlMdyCd;

    private String pprrEeno;
    private String updrEeno;

    private String hmcchkVal;
    private String clScnCd;
    private String crgrEeno;
    private String blnsCoCd;
    private String kyungchkVal;
    private String sehwachkVal;
    private String pdichkVal;

    // 연계차종코드
    private String dytmPlnCd;   // aps
    private String prdnMstCd;   // 생산
    private String bomVehlCd;   // bom
    private String saleVehlCd;  // 판매

    private String chkVal;
    private String langCd;
    private String prvsScnCd;
    private String prdnVehlCd;
    private String jbMdyRelCd;
    private String dlExpdMdlMdyCd;
    private String chkMdy;
    private String nqltyVehlCd;
    private String nMonth;
    private String nmdlMdyCd;
    private String oriQltyVehlCd;
    private String oriMdlMdyCd;
    private String vehlCdByVehlReg;
    private String qltyVehlNm;
    private String lastMy;
    private String chkCpVehl;
    private String dlExpdPacScnCd;
    private String sYm;
    private String eYm;
    private String sdate;
    private String dlExpdPdiCd;
    private String useYn;
    private String mdlRelCd;
    private String regnCd;


    // 담당자
//    private List<AuthVehlSaveDTO> usrArray01; //hmc 담당자
//    private List<AuthVehlSaveDTO> usrArray02; //외주업체 담당자
//    private List<AuthVehlSaveDTO> usrArray03; //세원 담당자
//    private List<AuthVehlSaveDTO> usrArray04; //PDI 담당자

    private List<VehlMgmtReqDTO> regnDlpvList; // 연식관계 리스트

    /*
     * getQltyVehlCd
     * getMdlMdyCd
     */
    private List<String> usrList01; //hmc 담당자  userEeno array
    private List<String> usrList03; //외주업체 담당자  userEeno array
    private List<String> usrList04; //세원 담당자  userEeno array
    private List<String> usrList06; //PDI 담당자  userEeno array
    private List<VehlMgmtSaveDTO> natlList; // 국가별 차량코드,차량별 언어코드 등록

}
