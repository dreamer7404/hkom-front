package com.oms.mri.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import able.cloud.core.web.HController;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.oms.cmm.utils.Utils;
import com.oms.mri.dto.ClcmInfosResDTO;
import com.oms.mri.dto.PrintOrderComDTO;
import com.oms.mri.dto.PrintOrderInfosResDTO;
import com.oms.mri.dto.PrintOrderPageInfosResDTO;
import com.oms.mri.dto.PrintOrderPrntPbcnNoResDTO;
import com.oms.mri.dto.PrintOrderReqInfoResDTO;
import com.oms.mri.service.PrintOrderService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;


/**
 * <pre>
 * PrintOrderController
 * </pre>
 *
 * @ClassName   : PrintOrderController.java
 * @Description : 제작준비 > O/M발주 컨트롤러
 * @author 김정웅
 * @since 2023.5.11
 * @see
 */
@Tag(name = "PrintOrderController", description = "")
//@CrossOrigin(origins="*")
@RequiredArgsConstructor
@RestController
@RequestMapping("/api")
public class PrintOrderController extends HController {

    /**
     * 클래스 Injection
     */
    private final HttpServletRequest request;
    private final PrintOrderService printOrderService;

    /**
     * 제작준비 > O/M 발주
     */
    @Operation(summary = "O/M 발주 목록")
    @Parameter(in = ParameterIn.HEADER, name="_method")
    @PostMapping("/printOrderInfos")
    public List<PrintOrderInfosResDTO> selectPrintOrderList(@RequestBody PrintOrderComDTO reqDto) throws Exception {
        //사용자 ID, 회사코드 할당
        reqDto.setUserEeno(Utils.getUserEeno(request));
        reqDto.setDlExpdCoCd(Utils.getDlExpdCoCd(request));

        reqDto.setSDate(reqDto.getSsDate());
        reqDto.setEDate(reqDto.getEeDate());
        reqDto.setBDate(reqDto.getBbDate());
        reqDto.setIWayCd(reqDto.getIiWayCd());

        List<PrintOrderInfosResDTO> result = new ArrayList<PrintOrderInfosResDTO>();
        result = printOrderService.selectPrintOrderList(reqDto);

        return result;
    }

    /**
     * 제작준비 > O/M 발주 > 개정정보
     */
    @Operation(summary = "O/M발주 개정정보")
    @GetMapping("/printOrderClcmInfos")
    public List<ClcmInfosResDTO> selectPrintOrderClcmInfos(@ModelAttribute PrintOrderComDTO reqDto) throws Exception {
        //사용자 ID, 회사코드 할당
        reqDto.setUserEeno(Utils.getUserEeno(request));
        reqDto.setDlExpdCoCd(Utils.getDlExpdCoCd(request));

        List<ClcmInfosResDTO> result = new ArrayList<ClcmInfosResDTO>();
        result = printOrderService.selectPrintOrderClcmInfos(reqDto);

        return result;
    }

    /**
     * 제작준비 > O/M 발주 > 발간번호코드 조회
     */
    @Operation(summary = "O/M발주 발간번호코드정보")
    @GetMapping("/printOrderPrntPbcnNoInfos")
    public List<PrintOrderPrntPbcnNoResDTO> selectPrintOrderPrntPbcnNoInfos(@ModelAttribute PrintOrderComDTO reqDto) throws Exception {
        //사용자 ID, 회사코드 할당
        reqDto.setUserEeno(Utils.getUserEeno(request));
        reqDto.setDlExpdCoCd(Utils.getDlExpdCoCd(request));

        List<PrintOrderPrntPbcnNoResDTO> result = new ArrayList<PrintOrderPrntPbcnNoResDTO>();
        result = printOrderService.selectPrintOrderPrntPbcnNoInfos(reqDto);

        return result;
    }

    /**
     * 제작준비 > O/M 발주 > 발간번호별 세부내역
     */
    @Operation(summary = "O/M발주 발간번호별 세부내역")
    @GetMapping("/printOrderReqInfo")
    public PrintOrderReqInfoResDTO selectPrintOrderReqInfo(@ModelAttribute PrintOrderComDTO reqDto) throws Exception {
        //사용자 ID, 회사코드 할당
        reqDto.setUserEeno(Utils.getUserEeno(request));
        reqDto.setDlExpdCoCd(Utils.getDlExpdCoCd(request));

        reqDto.setSDate(reqDto.getSsDate());
        reqDto.setEDate(reqDto.getEeDate());
        reqDto.setBDate(reqDto.getBbDate());
        reqDto.setIWayCd(reqDto.getIiWayCd());

        PrintOrderReqInfoResDTO result = new PrintOrderReqInfoResDTO();
        result = printOrderService.selectPrintOrderReqInfo(reqDto);


        return result;
    }

    /**
     * 제작준비 > O/M 발주 > 발간번호별 인쇄배열표 셀렉트박스
     */
    @Operation(summary = "O/M발주 인쇄배열표 콤보박스")
    @GetMapping("/newPrntPbcnNoLrnkCdInfos")
    public List<HashMap<String, String>> selectNPrntPbcnNoLrnkCdList(@ModelAttribute PrintOrderComDTO reqDto) throws Exception {
        //사용자 ID, 회사코드 할당
        reqDto.setUserEeno(Utils.getUserEeno(request));
        reqDto.setDlExpdCoCd(Utils.getDlExpdCoCd(request));


        List<HashMap<String, String>> result = new ArrayList<HashMap<String, String>>();
        result = printOrderService.selectNPrntPbcnNoLrnkCdList(reqDto);
        return result;
    }

    /**
     * 제작준비 > O/M 발주 > 발간번호별 인쇄배열표 조회
     */
    @Operation(summary = "O/M발주 발간번호별 인쇄배열표")
    @GetMapping("/printOrderPageInfo")
    public PrintOrderPageInfosResDTO selectPrintOrderPageInfo(@ModelAttribute PrintOrderComDTO reqDto) throws Exception {
        //사용자 ID, 회사코드 할당
        reqDto.setUserEeno(Utils.getUserEeno(request));
        reqDto.setDlExpdCoCd(Utils.getDlExpdCoCd(request));

        reqDto.setSDate(reqDto.getSsDate());
        reqDto.setEDate(reqDto.getEeDate());
        reqDto.setBDate(reqDto.getBbDate());
        reqDto.setIWayCd(reqDto.getIiWayCd());

        PrintOrderPageInfosResDTO result = new PrintOrderPageInfosResDTO();
        result = printOrderService.selectPrintOrderPageInfo(reqDto);


        return result;
    }


}