package com.oms.ivm.dto;

import java.sql.Timestamp;

import org.apache.ibatis.type.Alias;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @author 김정웅
 * @since 2023. 3. 7.
 * @see
 */

@Alias("ivmRequestMonitorResDTO")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class IvmRequestMonitorResDTO {

    private String gubun;
    private String rqGbn;   //요청구분

    private String qltyVehlCd;
    private String qltyVehlNm;
    private String mdlMdyCd;
    private String dlExpdRegnCd;
    private String dlExpdPrvsNm;
    private String langCd;
    private String langCdNm;
    private String rqQty;
    private String userEeno;
    private String userNm;
    private String ordnRqstYmd;


}
