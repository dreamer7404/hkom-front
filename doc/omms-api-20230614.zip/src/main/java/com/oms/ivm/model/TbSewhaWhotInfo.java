package com.oms.ivm.model;

import com.oms.ivm.dto.ComIvmReqDTO;

import lombok.Data;

/**
 * <pre>
 * TbSewhaWhotInfo VO
 * </pre>
 *
 * @Class Name : TbSewhaWhotInfo.java
 * @Description : 세화출고정보 엔티티
 * @author 김정웅
 * @since 2023.3.29
 * @see
 */

@Data
public class TbSewhaWhotInfo extends ComIvmReqDTO{

    private String qltyVehlCd;      //QLTY_VEHL_CD              (TB_SEWHA_WHOT_INFO) varchar(4)
    private String dlExpdMdlMdyCd;  //DL_EXPD_MDL_MDY_CD        (TB_SEWHA_WHOT_INFO) varchar(2)
    private String langCd;          //LANG_CD                   (TB_SEWHA_WHOT_INFO) varchar(3)
    private String nPrntPbcnNo;     //N_PRNT_PBCN_NO            (TB_SEWHA_WHOT_INFO) varchar(100)
    private String dtlSn;           //DTL_SN                    (TB_SEWHA_WHOT_INFO) int1(2)
    private String whotYmd;         //WHOT_YMD                  (TB_SEWHA_WHOT_INFO) char(8)
    private String dlExpdRqScnCd;   //DL_EXPD_RQ_SCN_CD         (TB_SEWHA_WHOT_INFO) varchar(4)
    private String dlvgParrYmd;     //DLVG_PARR_YMD             (TB_SEWHA_WHOT_INFO) char(8)
    private String dlvgParrHhmm;    //DLVG_PARR_HHMM            (TB_SEWHA_WHOT_INFO) char(4)
    private String rqQty;           //RQ_QTY                    (TB_SEWHA_WHOT_INFO) int(6)
    private String pwtiEeno;        //PWTI_EENO                 (TB_SEWHA_WHOT_INFO) varchar2(0)
    private String prtlImtrSbc;     //PRTL_IMTR_SBC             (TB_SEWHA_WHOT_INFO) varchar(4000)
    private String crgrEeno;        //CRGR_EENO                 (TB_SEWHA_WHOT_INFO) varchar2(0)
    private String dlExpdBoxQty;    //DL_EXPD_BOX_QTY           (TB_SEWHA_WHOT_INFO) int1(0)
    private String cmplYn;          //CMPL_YN                   (TB_SEWHA_WHOT_INFO) char(1)
    private String whsnYmd;         //WHSN_YMD                  (TB_SEWHA_WHOT_INFO) char(8)
    private String pprrEeno;        //PPRR_EENO                 (TB_SEWHA_WHOT_INFO) varchar(20)
    private String framDtm;         //FRAM_DTM                  (TB_SEWHA_WHOT_INFO) datetime
    private String updrEeno;        //UPDR_EENO                 (TB_SEWHA_WHOT_INFO) varchar(20)
    private String mdfyDtm;         //MDFY_DTM                  (TB_SEWHA_WHOT_INFO) datetim(e)
    private String delYn;           //DEL_YN                    (TB_SEWHA_WHOT_INFO) char(1)
    private String pwtiNm;          //PWTI_NM                   (TB_SEWHA_WHOT_INFO) varchar2(0)
    private String mdlMdyCd;        //MDL_MDY_CD                (TB_SEWHA_WHOT_INFO) varchar(2)
    private String dlExpdWhotStCd;  //DL_EXPD_WHOT_ST_CD        (TB_SEWHA_WHOT_INFO) varchar(4)


}
