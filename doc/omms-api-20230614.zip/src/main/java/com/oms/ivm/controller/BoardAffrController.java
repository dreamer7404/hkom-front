package com.oms.ivm.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import able.cloud.core.web.HController;

import org.apache.commons.text.StringEscapeUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
//import io.swagger.v3.oas.annotations.parameters.RequestBody; 잊지 말자.. 스웨거의 RequestBody...
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.oms.cmm.global.Consts;
import com.oms.cmm.utils.Utils;
import com.oms.common.dto.AttcFileReqDTO;
import com.oms.common.dto.MailDTO;
import com.oms.common.model.Mail;
import com.oms.common.service.AttcFileService;
import com.oms.common.service.MailService;
import com.oms.ivm.dto.BoardAffrRcvUsersSaveDTO;
import com.oms.ivm.dto.BoardAffrReqDTO;
import com.oms.ivm.dto.BoardAffrResDTO;
import com.oms.ivm.service.BoardAffrService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;


/**
 * <pre>
 * BoardAffrController
 * </pre>
 *
 * @ClassName   : BoardAffrController.java
 * @Description : 재고관리 > 게시판
 * @author 안경수
 * @since 2023.3.13
 * @see
 */
@Tag(name = "BoardAffrController", description = "")
@RequiredArgsConstructor
@RestController
@RequestMapping("/api")
public class BoardAffrController extends HController {

    /**
     * 클래스 Injection
     */
    private final HttpServletRequest request;
    private final MailService mailService;
    private final BoardAffrService boardAffrService;
    private final AttcFileService attcFileService;

    /**
     * 재고관리 > 게시판
     */
    @Operation(summary = "게시판 목록", description = "")
    @GetMapping("/boardAffrMgmts")
    public List<BoardAffrResDTO> selectBoardAffrMgmtList() throws Exception{
        List<BoardAffrResDTO> list = boardAffrService.selectBoardAffrMgmtList();
        return list;
    }

    /**
     * 재고관리 > 게시판
     */
    @Operation(summary = "게시판 목록", description = "")
    @GetMapping("/boardAffrMgmt")
    public BoardAffrResDTO selectBoardAffrMgmt(@RequestParam Long blcSn) throws Exception{
        BoardAffrResDTO dto = boardAffrService.selectBoardAffrMgmt(blcSn);
//        dto.setBlcSbc(StringEscapeUtils.unescapeHtml4(dto.getBlcSbc()));
        return dto;
    }


    /**
     * 재고관리 > 게시판 등록, 수정, 삭제
     */
    @Operation(summary = "게시판 등록, 수정, 삭제", description = "")
    @Parameter(in = ParameterIn.HEADER, name="_method")
    @PostMapping("/boardAffrMgmt")
    public Long boardAffrMgmt(@RequestBody BoardAffrReqDTO boardAffrReqDTO) throws Exception {

        String method = Utils.getMethod(request);
        String userEeno = Utils.getUserEeno(request);
        String dlExpdCoCd = Utils.getDlExpdCoCd(request);
        int result = 0;

        if(method.equals(Consts.INSERT)) {

            // 등록자
            boardAffrReqDTO.setPprrEeno(userEeno);

            // [tb_Board_Affr_mgm]t 저장
            result = boardAffrService.insertBoardAffrMgmt(boardAffrReqDTO);

            if(result > 0) {
                boardAffrReqDTO.getLangCdByVehl().stream().forEach(item -> {
                        item.setBlcSn(boardAffrReqDTO.getBlcSn());
                        item.setPprrEeno(userEeno);
                });
                // [tb_Board_Affr_vehl] 저장
                result = boardAffrService.insertBoardAffrVehl(boardAffrReqDTO.getLangCdByVehl());

                // 첨부파일 나머지정보 저장
                if(boardAffrReqDTO.getAttcSn() != null && boardAffrReqDTO.getAttcSn().size() > 0 ) {

                    List<AttcFileReqDTO> attcFileList = new ArrayList<>();

                    for(int i=0; i<boardAffrReqDTO.getAttcSn().size(); i++) {
                        attcFileList.add(new AttcFileReqDTO(
                                Long.valueOf(boardAffrReqDTO.getAttcSn().get(i)),
                                "14",
                                "",
                                boardAffrReqDTO.getBlcSn(),
                                boardAffrReqDTO.getExtension().get(i),
                                boardAffrReqDTO.getOriginalName().get(i),
                                Integer.valueOf(boardAffrReqDTO.getSize().get(i)),
                                userEeno
                                ));
                    }
                    attcFileService.updateAttcFile(attcFileList);  // 업데이트
                }



                if(result > 0) {
                    //----------- 이메일발송 시작------------------------------------------------------------------------
                    // 수신자 이메일 조회
                    List<Mail> rcvList = mailService.selectEmlAdrList(boardAffrReqDTO.getRcvUsers());
                    if(rcvList.size() > 0) {

                        // 수신자정보 저장
                        boardAffrService.insertBoardAffrRcvUsers(new BoardAffrRcvUsersSaveDTO(boardAffrReqDTO.getBlcSn(), userEeno,rcvList ));

                        // 이메일 전송
                        MailDTO mailDTO = new MailDTO();
                        mailDTO.setEmlScdCd("14");                          // 이메일구분, 3: 비밀번호찾기, 14: 게시판, 15: 체크리스트
                        mailDTO.setSndrId(userEeno);                        // 발신자 사원번호
                        mailDTO.setEmlTitl(boardAffrReqDTO.getBlcTitlNm());  // 제목
                        mailDTO.setEmlSbc(boardAffrReqDTO.getBlcSbc());       // 내용
                        mailDTO.setRcvList(rcvList);                        // 수신자 리스트
                        mailService.send(mailDTO);

                        return boardAffrReqDTO.getBlcSn(); // tb_Board_Affr_mgm 의 PK
                    }else {
                        return -3L; // 이메일정보 없음
                    }
                    //-----------// 이메일발송 종료 ------------------------------------------------------------------------
                }else {
                    return -2L; // tb_Board_Affr_vehl 저장실패
                }
            }else {
                return -1L; //tb_Board_Affr_mgmt 저장실패
            }

        }
        return 0L;

    }




}