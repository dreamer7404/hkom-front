package com.oms.ivm.dto;

import java.util.List;

import org.apache.ibatis.type.Alias;

import com.oms.common.dto.VehlMdyLangReqDTO;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @author 안경수
 * @since 2023. 5. 26.
 * @see
 */
@NoArgsConstructor
@Alias("boardAffrReqDTO")
@Data
public class BoardAffrReqDTO {

    private Long blcSn;
    private String blcScnCd; //게시물구분코드(0039)

    private String blcRgstYmd;
    private String befmyTrwiYn;
    private String bbYn;
    private String bbVal;
    private String dtrwiYn;
    private String dtrwiRqYmd;
    private String dtrwiMidcsnYn;
    private String altrTrwiYn;
    private String nmtrwiRqYmd;
    private String nmtrwiMidcsnYn;

    private String blcTitlNm; //게시물제목명
    private String blcSbc;  // 게시물내용
    private String attcYn;   // 첨부여부

    private String replyYn; // 댓글여부
    private String delYn;   // 삭제여부
    private Long emlCd;     // 이메일 코드

    private String pprrEeno;

    private List<VehlMdyLangReqDTO> langCdByVehl; // 차종코드,년식, 언어코드
    private List<String> rcvUsers; // 수신인 eeno

    //-------- 첨부파일 정보 ---------------------
    private List<String> attcSn; // 첨부파일 저장 tb_attc_mgmt PK
    private List<String> size;
    private List<String> extension;
    private List<String> originalName;



}
