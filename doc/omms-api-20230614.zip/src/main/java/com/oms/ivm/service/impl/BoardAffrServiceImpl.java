package com.oms.ivm.service.impl;

import java.util.List;

import able.cloud.core.service.HService;

import org.apache.commons.text.StringEscapeUtils;
import org.springframework.stereotype.Service;

import com.oms.common.dto.VehlMdyLangReqDTO;
import com.oms.ivm.dao.BoardAffrDAO;
import com.oms.ivm.dto.BoardAffrRcvUsersSaveDTO;
import com.oms.ivm.dto.BoardAffrReqDTO;
import com.oms.ivm.dto.BoardAffrResDTO;
import com.oms.ivm.service.BoardAffrService;

import lombok.RequiredArgsConstructor;

/**
 * <pre>
 * BoardAffrServiceImpl
 * </pre>
 *
 * @author 안경수
 * @since 2023. 6. 1
 * @see
 */
@RequiredArgsConstructor
@Service("boardAffrService")
public class BoardAffrServiceImpl extends HService implements BoardAffrService {

    private final BoardAffrDAO boardAffrDAO;

    @Override
    public int insertBoardAffrMgmt(BoardAffrReqDTO boardAffrReqDTO) {

        return boardAffrDAO.insertBoardAffrMgmt(boardAffrReqDTO);
    }

    @Override
    public int insertBoardAffrVehl(List<VehlMdyLangReqDTO> list) {
        return boardAffrDAO.insertBoardAffrVehl(list);
    }

    @Override
    public int insertBoardAffrRcvUsers(BoardAffrRcvUsersSaveDTO boardAffrRcvUsersSaveDTO) {
        return boardAffrDAO.insertBoardAffrRcvUsers(boardAffrRcvUsersSaveDTO);
    }

    @Override
    public List<BoardAffrResDTO> selectBoardAffrMgmtList() {
        return boardAffrDAO.selectBoardAffrMgmtList();
    }

    @Override
    public BoardAffrResDTO selectBoardAffrMgmt(Long blcSn) {
        return boardAffrDAO.selectBoardAffrMgmt(blcSn);
    }







}
