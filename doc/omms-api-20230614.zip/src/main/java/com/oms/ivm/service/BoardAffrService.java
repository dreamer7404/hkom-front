package com.oms.ivm.service;

import java.util.List;

import com.oms.common.dto.VehlMdyLangReqDTO;
import com.oms.ivm.dto.BoardAffrRcvUsersSaveDTO;
import com.oms.ivm.dto.BoardAffrReqDTO;
import com.oms.ivm.dto.BoardAffrResDTO;


/**
 * <pre>
 * BoardAffrService
 * </pre>
 *
 * @ClassName   : BoardAffrService.java
 * @Description : 재고관리 > 게시판
 * @author 안경수
 * @since 2023.6.1
 * @see
 */

public interface BoardAffrService {
    List<BoardAffrResDTO> selectBoardAffrMgmtList();
    BoardAffrResDTO selectBoardAffrMgmt(Long blcSn);
   int insertBoardAffrMgmt(BoardAffrReqDTO boardAffrReqDTO);
   int insertBoardAffrVehl(List<VehlMdyLangReqDTO> list);
   int insertBoardAffrRcvUsers(BoardAffrRcvUsersSaveDTO boardAffrRcvUsersSaveDTO);
}
