// react
import React from 'react';
import { Suspense } from 'react';
import BaseRoutes from './components/Common/BaseRoutes';

const App = () => {
  return (
      <Suspense  fallback={<div>loading.....</div>}> 
        <BaseRoutes />
      </Suspense> 
  );
};
export default App;
