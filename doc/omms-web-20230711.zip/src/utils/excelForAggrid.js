//엑셀다운로드 테스트 김정웅
import * as ExcelJS from 'exceljs'
import { confirmAlert } from 'react-confirm-alert'; // Import
import ConfirmAlert from '../components/Common/ConfirmAlert';
import { formatNumber, escapeCharChange } from '../utils/commUtils';

const colDef = []
const rowData = [];
// 테두리 스타일 생성
const borderStyle = {
	style: 'thin',
	color: {
		argb: 'FF626262' // 테두리 색상 설정 (여기서는 검은색)
	}
};

let pinnedBottomRowCount = 0

/**
 * 
 * @param {useRef} gridRef 그리드Ref
 * @param {String} fileName 엑셀다운로드 파일명
 * @param {int} lastRowIndex 그리드 내 헤더의 로우길이
 * @param {String} bottomFlag 그리드 내에서 pinnedBottomRow를 쓸경우 플래그 값(ex. 'TOTAL')
 */
export const excelDownload = (gridRef, fileName, lastRowIndex, bottomFlag ) => {
	
	gridRef.current.api.getColumnDefs().forEach(item => {
		colDef.push(item)
	})
	
	gridRef.current.api.forEachNodeAfterFilterAndSort(node => {
		rowData.push(node.data)
	})

	if(gridRef.current.api.getPinnedBottomRowCount() > 0){
		pinnedBottomRowCount = gridRef.current.api.getPinnedBottomRowCount()
		for(let i=0; i< pinnedBottomRowCount; i++){
			rowData.push(gridRef.current.api.getPinnedBottomRow(i).data)
		}
	}
	
	// console.log(pinnedBottomRowCount)
	// console.log(colDef)
	// console.log(rowData)
	
	return handleDownload(rowData, colDef, lastRowIndex, fileName, bottomFlag)
	
}

export const excelDownload2 = (gridRef, fileName, lastRowIndex, bottomFlag ) => {
	
	// console.log('gridRef',gridRef)
	let colDefTmp = gridRef.current.props.columnDefs;
	colDefTmp.forEach(item => {
		colDef.push(item)
	})
	
	gridRef.current.api.forEachNodeAfterFilterAndSort(node => {
		rowData.push(node.data)
	})

	if(gridRef.current.api.getPinnedBottomRowCount() > 0){
		pinnedBottomRowCount = gridRef.current.api.getPinnedBottomRowCount()
		for(let i=0; i< pinnedBottomRowCount; i++){
			rowData.push(gridRef.current.api.getPinnedBottomRow(i).data)
		}
	}
	
	// console.log(pinnedBottomRowCount)
	// console.log(colDef)
	// console.log(rowData)
	
	return handleDownload(rowData, colDef, lastRowIndex, fileName, bottomFlag)
	
}

/**
 * @param {Array} rowData 컬럼수 대로 정리된 로우데이터
 * @param {Array} colDef 엑셀에서 사용될 헤더의 정보(agGrid의 columnDef의 양식과 같아야함)
 * @param {int} lastRowIndex 그리드 내 헤더의 로우길이
 * @param {String} fileName 파일명
 * @param {String} bottomFlag 테이블 내에서 pinnedBottomRow를 쓸경우 플래그 값(ex. 'TOTAL')
 * @param {Array} colSpan 테이블 내에서 colSpan 쓸경우 대상 컬럼의 값이 같은경우 colSpan처리한다. (ex. ['idxNm','wkYmd','dowNm'])
 */
export const excelDownloadTable = (rowData, colDef, lastRowIndex, fileName, bottomFlag, bottomRowCount, colSpan ) => {
	if(bottomFlag && bottomFlag !== '') {
		pinnedBottomRowCount=bottomRowCount ? bottomRowCount : 1
	}
	// console.log(pinnedBottomRowCount)
	// console.log(colDef)
	// console.log(rowData)

	return handleDownload(rowData, colDef, lastRowIndex, fileName, bottomFlag, colSpan)
}

const cleanRowData = () => {
	rowData.splice(0)
	colDef.splice(0)
	left = 1;
	right = 0;
	bottom = 1;
	pinnedBottomRowCount=0;
}

const handleDownload = (rowData, columnDefs, lastRowIndex, fileName, bottomFlag, colSpan) => {
	if(rowData.length <= 0){
		confirmAlert({
			closeOnClickOutside: false,
			customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}  title={"알림"} msg={"조회된 데이터가 없습니다."}  />
		})
		return false
	}

	// Ag-Grid 데이터 가져오기
	const columns = processColumns(columnDefs);

	// 엑셀 파일 생성
	const workbook = new ExcelJS.Workbook();
	const worksheet = workbook.addWorksheet('Sheet 1');

	// 1:컬럼정보, 2.ExcelJS, 3.lastRowIndex
	mergeCells(columnDefs, worksheet, lastRowIndex)

	// 헤더 열 추가
	// addHeaderColumns(worksheet, columns);
	// 데이터 행 추가
	addDataRows(worksheet, columns, rowData, lastRowIndex, bottomFlag, colSpan, fileName);

	// let rowIndex = 1;
	// let lastColIndex = 1;
	// columnDefs.forEach((item) => {
	//     if(!item.checkboxSelection) {
	//         if(item.children){
				
	//             for(let index2=0; index2 < item.children.length; index2++){
	//                 let item2 = item.children[index2]

	//                 if(item2.children){

	//                 } else {
	//                     if(index2 === 0){
	//                         //top, left, bottom, right
	//                         worksheet.mergeCells(rowIndex,lastColIndex,rowIndex,lastColIndex==1?item.children.length:lastColIndex+item.children.length-1);
	//                         //row, col
	//                         worksheet.getCell(rowIndex,lastColIndex).value = item.headerName;
	//                         worksheet.getCell(rowIndex,lastColIndex).font = { size: 10, bold: true };
	//                         worksheet.getCell(rowIndex,lastColIndex).alignment = { horizontal: 'center', vertical: 'middle',  wrapText: true };
	//                         worksheet.getCell(rowIndex,lastColIndex).fill = {
	//                             type: 'pattern',
	//                             pattern: 'solid',
	//                             fgColor: { argb: 'f8f8f8' },
	//                         };
	//                     }
						
	//                     //top, left, bottom, right
	//                     worksheet.mergeCells(rowIndex+1,lastColIndex+index2,lastRowIndex,lastColIndex+index2);
	//                     //row, col
	//                     worksheet.getCell(rowIndex+1,lastColIndex+index2).value = item2.headerName;
	//                     worksheet.getCell(rowIndex+1,lastColIndex+index2).font = { size: 10, bold: true };
	//                     worksheet.getCell(rowIndex+1,lastColIndex+index2).alignment = { horizontal: 'center', vertical: 'middle',  wrapText: true };
	//                     worksheet.getCell(rowIndex+1,lastColIndex+index2).fill = {
	//                         type: 'pattern',
	//                         pattern: 'solid',
	//                         fgColor: { argb: 'f8f8f8' },
	//                     };
	//                 }
	//             }

	//             lastColIndex += item.children.length;

	//         } else {
	//             //top, left, bottom, right
	//             worksheet.mergeCells(rowIndex,lastColIndex,lastRowIndex,lastColIndex);
	//             //row, col
	//             worksheet.getCell(rowIndex,lastColIndex).value = item.headerName;
	//             worksheet.getCell(rowIndex,lastColIndex).font = { size: 10, bold: true };
	//             worksheet.getCell(rowIndex,lastColIndex).alignment = { horizontal: 'center', vertical: 'middle',  wrapText: true };
	//             worksheet.getCell(rowIndex,lastColIndex).fill = {
	//                 type: 'pattern',
	//                 pattern: 'solid',
	//                 fgColor: { argb: 'f8f8f8' },
	//             };
				
	//             lastColIndex ++
	//         }
	//     }
	// })

	// worksheet.mergeCells(1,1,1,3);
	// worksheet.getCell(1,1).value = '차종';
	// worksheet.getCell(1,1).font = { size: 10, bold: true };
	// worksheet.getCell(1,1).alignment = { horizontal: 'center' };

	// worksheet.mergeCells(1,4,1,6);
	// worksheet.getCell(1,4).value = '언어';
	// worksheet.getCell(1,4).font = { size: 10, bold: true };
	// worksheet.getCell(1,4).alignment = { horizontal: 'center' };

	// worksheet.mergeCells(2,1,3,1);
	// worksheet.getCell(2,1).value = '차종코드';
	// worksheet.getCell(2,1).font = { size: 10, bold: true };
	// worksheet.getCell(2,1).alignment = { horizontal: 'center' };
	
	// worksheet.mergeCells('B2:B3');
	// worksheet.getCell('B2').value = '차종명';
	// worksheet.getCell('B2').font = { size: 10, bold: true };
	// worksheet.getCell('B2').alignment = { horizontal: 'center' };
	
	// worksheet.mergeCells('C2:C3');
	// worksheet.getCell('C2').value = '차종명';
	// worksheet.getCell('C2').font = { size: 10, bold: true };
	// worksheet.getCell('C2').alignment = { horizontal: 'center' };

	// worksheet.mergeCells('D1:D3');
	// worksheet.getCell('D1').value = '차종명';
	// worksheet.getCell('D1').font = { size: 10, bold: true };
	// worksheet.getCell('D1').alignment = { horizontal: 'center' };





	
	//엑셀 파일 다운로드
	workbook.xlsx.writeBuffer().then((buffer) => {
		const blob = new Blob([buffer], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
		const url = URL.createObjectURL(blob);
		const link = document.createElement('a');
		link.href = url;
		link.download = fileName + '.xlsx';
		link.click();
		URL.revokeObjectURL(url);
	})
	.catch((error) => {
		console.error('엑셀 파일 생성 중 오류가 발생했습니다:', error);
	})
	.finally(() => {
		cleanRowData()
		return false
	})
};

const processColumns = (columns) => {
	const processedColumns = [];
	columns.forEach((column) => {
		if(column.headerName){ //체크박스가 아닌경우만 처리한다.
			if (column.children) {
				processedColumns.push(...processColumns(column.children));
			} else {
				processedColumns.push(column);
			}
		}
	});
	return processedColumns;
};

// const addHeaderColumns = (worksheet, columns) => {
//     columns.forEach((column, index) => {
//         // worksheet.getCell(1, index + 1).value = column.headerName;
//         worksheet.getCell(1, index + 1).value = {
//             richText: [{ text: column.headerName, font: { size: 10, bold:true } }],
//         }
//     });
// };

const addDataRows = (worksheet, columns, rowData, lastRowIndex, bottomFlag, colSpan, fileName) => {
	
	//rowSpan이 있는 컬럼 찾기 시작
	let rowSpanCol = [];
	columns.forEach(col => {
		if(col.rowSpan){
			rowSpanCol.push(col.field)
		}
	})
	//rowSpan이 있는 컬럼 찾기 끝
	
	rowData.forEach((row, rowIndex) => {
		//row별 flag 값 찾기 시작
		let flag = 0
		if(row.flag) {
			if(row.flag !== 1){
				flag = parseInt(row.flag, 10) //간혹 flag값이 String인 경우가 있어서 처리해준다...(ex. "3")
			}
		}

		let rowSpanCheck = false
		if ((rowIndex+flag) % flag === 0){
			rowSpanCheck =  true
		}
		
		// pinnedBottomRow가 있는경우 colSpan해줄 컬럼의 수를 카운트 한다.
		let pinnedBottomRowColSpan = 0;
		// pinnedBottomRow가 있고, rowSpan까지 사용할 경우 데이터를 마지막 row까지 그린 후에 merge를 진행한다.
		let pinnedBottomRowStartRowIndex = 0;
		let pinnedBottomRowEndRowIndex = 0;
		//colSpan을 사용한경우 colSpan 의 시작점을 할당.
		let colSpanStart = 0;
		let colSpanDatas = []; //해당 row의 colSpan 대상 컬럼의 값을 담아놓고 중복제거하여 제거한 값이 1인경우만 컬럼을 합친다.
		let colSpanEnd = 0;
		

		//row별 flag 값 찾기 끝
		columns.forEach((column, colIndex) => {
			if(!column.checkboxSelection) {
				let value = row[column.field];

				if(fileName === '월간투입현황' && column.cellRenderer && column.field.indexOf('col') !== -1){ //월간투입현황을 위한 작업..
					let params = {data:row}
					value = column.cellRenderer(params)
				}
				
				if(column.aggFunc){ //해당 그리드에서 사용된 colDef에 커스텀펑션이 있는경우, 해당 CellValue를 펑션을 사용하여 파싱한다.
					value = column.aggFunc(value)
				}

				if(column.valueGetter){
					let params = {data:row, colDef:column} //colDef는 '법규 및 변경관리'목록에서 'X' 그릴때 필요하기때문에 필수로 넣어준다.. 다른 화면에서 문제발생시 분기 처리 필요..
					value = column.valueGetter(params)
				}
				
				if(column.valueFormatter){
					if(column.valueFormatter.name === 'currencyFormatter'){
						value = formatNumber(value)
					}
				} else if (value && value.length > 0) {
					value = escapeCharChange(value)
				}

				worksheet.getCell(rowIndex + lastRowIndex +1, colIndex + 1).value = value;

				if(rowData.length <= (pinnedBottomRowCount+rowIndex)){
					worksheet.getCell(rowIndex + lastRowIndex +1, colIndex + 1).font = { size: 10, bold: true };
					worksheet.getCell(rowIndex + lastRowIndex +1, colIndex + 1).alignment = { horizontal: 'center', vertical: 'middle',  wrapText: true };
					worksheet.getCell(rowIndex + lastRowIndex +1, colIndex + 1).fill = {
						type: 'pattern',
						pattern: 'solid',
						fgColor: { argb: 'f8f8f8' },
					};
					worksheet.getCell(rowIndex + lastRowIndex +1, colIndex + 1).border = {
						top: borderStyle,
						left: borderStyle,
						bottom: borderStyle,
						right: borderStyle
					};
					// pinnedBottomRow가 있는경우, bottomFlag와 colField가 같을경우 colSpan해줄 컬럼의 수 더해준다.
					if(value === bottomFlag){
						pinnedBottomRowColSpan ++
					}
				} else {
					
						if(colSpan && colSpan.length > 0 && colSpan.includes(column.field)){ //현재 작업하는 컬럼이 colSpan 대상 컬럼인 경우 
							colSpanDatas.push(value)

							if(colSpanStart > colIndex){
								colSpanStart = (colIndex+1);
							}
						}
					
						worksheet.getCell(rowIndex + lastRowIndex +1, colIndex + 1).font = { size: 9};
						worksheet.getCell(rowIndex + lastRowIndex +1, colIndex + 1).alignment = { horizontal: 'center', vertical: 'middle',  wrapText: true };					
					
				}

				if(rowSpanCol.length > 0){ //rowSpan을 해야하는 경우

					if(rowSpanCol.includes(column.field) && rowSpanCheck){
						if(pinnedBottomRowColSpan === 0){
							// top, left, bottom, right
							worksheet.mergeCells((rowIndex+1 + lastRowIndex),(colIndex+1),(rowIndex + lastRowIndex + flag),(colIndex+1 + pinnedBottomRowColSpan))
							
							pinnedBottomRowStartRowIndex = (rowIndex+1 + lastRowIndex)
							pinnedBottomRowEndRowIndex = (rowIndex + lastRowIndex + flag)
						}
					} else {
						if(pinnedBottomRowColSpan === 1 && pinnedBottomRowStartRowIndex === 0){
							pinnedBottomRowStartRowIndex = (rowIndex + lastRowIndex + flag)
						} else {
							pinnedBottomRowEndRowIndex = (rowIndex + lastRowIndex +1)
						}
					}

				} else { //rowSpan이 필요없는 경우
					if(pinnedBottomRowColSpan === 1 && pinnedBottomRowStartRowIndex === 0){
						pinnedBottomRowStartRowIndex = (rowIndex+ 1 + lastRowIndex + flag)
					} else {
						pinnedBottomRowEndRowIndex = (rowIndex+1 + lastRowIndex + flag )
					}
				}
			}
		}); // col forEach 끝

		//pinnedBottomRow 의 rowSpan과 colSpan을 처리해준다.
		if(pinnedBottomRowColSpan !== 0 && rowData.length === (rowIndex+1)){
			// top, left, bottom, right
			worksheet.mergeCells(pinnedBottomRowStartRowIndex, 1, pinnedBottomRowEndRowIndex, pinnedBottomRowColSpan)
		}



		//데이터Row에 사용된 colSpan을 처리해준다.
		const  findMaxDuplicateCount = (colSpanDatas) => {
			var duplicates = {};
			var maxDuplicateCount = 0;
		  
			colSpanDatas.forEach(item => {
				duplicates[item] = (duplicates[item] || 0) + 1;
				if (duplicates[item] > maxDuplicateCount) {
				maxDuplicateCount = duplicates[item];
				}
			});
		  
			return maxDuplicateCount;
		}
		if(colSpan && colSpan.length > 0 && colSpan.length === findMaxDuplicateCount(colSpanDatas)){
			// top, left, bottom, right
			// console.log((rowIndex + lastRowIndex +1), (colSpanStart+1), (rowIndex + lastRowIndex +1), (colSpanStart+colSpan.length))
			worksheet.mergeCells((rowIndex + lastRowIndex +1), (colSpanStart+1), (rowIndex + lastRowIndex +1), (colSpanStart+colSpan.length))
		}

	}); // row forEach 끝
};

// ExcelJS를 사용하여 셀 병합을 처리하는 함수
let left = 1;
let right = 0;
let bottom = 1;
const mergeCells = (columnDefs, worksheet, lastRowIndex, top) => {
	
	for(let i=0; i<columnDefs.length; i++){
		if(!top) top = 1

		let item = columnDefs[i]
		if(item.checkboxSelection) {
			continue;
		}
		
		if(!item.children){
			// console.log('children', item.headerName, 'left: '+left, 'right: '+left, 'top: '+top, 'bottom: '+lastRowIndex)
			makeCell(top, left, lastRowIndex, left, item.headerName, worksheet)
			left++

		} else {
			// parentColLength += item.children.length
			right += item.children.length
			// let childCheck = 0
			// item.children.forEach(item2 => {
			//     if(item2.children){
			//         childCheck++
			//     }
			// })
			// if(childCheck === 0){
				let colChildArr = processColumns(item.children)
				// console.log(colChildArr.length)
				// console.log('parent2', item.headerName, 'left: '+left, 'right: '+(colChildArr.length+left-1), 'top: '+top, 'bottom: '+top)
				makeCell(top, left, top, (colChildArr.length+left-1), item.headerName, worksheet)
			// } else {
				// let colChildArr = processColumns(item.children)
				// console.log(colChildArr.length)
				// console.log('어떡할까..', item.headerName, 'left: '+left, 'right: '+(colChildArr.length+left-1), 'top: '+top, 'bottom: '+top)
				// makeCell(top, left, top, (colChildArr.length+left-1))
			// }
			top++
			right += mergeCells(item.children, worksheet, lastRowIndex, top, left, bottom, right)
			top--
			right = 0
			// console.log('')
			
		}
		// console.log('')
		if(!top) top = 1
	}

	return right

}

const makeCell = (top, left, bottom, right, headerName, worksheet) => {
	// top, left, bottom, right
	worksheet.mergeCells(top,left,bottom,right);
	//row, col
	worksheet.getCell(top,left).value = headerName;
	worksheet.getCell(top,left).font = { size: 10, bold: true };
	worksheet.getCell(top,left).alignment = { horizontal: 'center', vertical: 'middle',  wrapText: true };
	worksheet.getCell(top,left).fill = {
		type: 'pattern',
		pattern: 'solid',
		fgColor: { argb: 'f8f8f8' },
	};
	
	worksheet.getCell(top,left).border = {
		top: borderStyle,
		left: borderStyle,
		bottom: borderStyle,
		right: borderStyle
	};
}

// 엑셀 다운로드 끝.. 나중에 공통으로 빼자.