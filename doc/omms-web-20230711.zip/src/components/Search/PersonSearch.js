import React, {useState, useMemo, useRef,useEffect, useCallback} from 'react';
import { Button, Modal,Col } from 'react-bootstrap';
import { DatePicker, Form, Input, InputGroup} from 'rsuite';
import SearchIcon from '@rsuite/icons/Search';
import { AgGridReact } from 'ag-grid-react';

import { utcToLocalDate } from '../../utils/commUtils'; //'../../../utils/commUtils';
//import VehlPerson from '../Contents/Stm/Popup/VehlPerson';

//--------------  서버데이터용 필수 -------------------------------
import useStore from '../../utils/store';
import { API} from '../../utils/constants';
import { getData } from '../../utils/async';
import { escapeCharChangeForGrid } from '../../utils/commUtils';
import { useQuery} from 'react-query';
//--------------// 서버데이터용 필수 -------------------------------

//아이콘
import {ArrowDownLine, ArrowUpLine, FileDownload} from '@rsuite/icons';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faFileExcel,faPrint } from '@fortawesome/free-solid-svg-icons'
//모달
import CustomModal from '../Common/CustomModal';

const GridPerson = ({show, onHide, param,chrgList, onChangeUsrList, onCellClicked, label, rmCheck, rmValue}) => {
    const usrGrid = useRef();
    const defaultColDef = useMemo(() => {
        return {
            initialWidth: 90,
            resizable:true,
            sortable:true,
        };
    }, []);

    // useEffect(() => {
    //     alert(param)
    // },[])

    //처음 팝업 들어왔을때는 빈값, 기존에 선택한 값이 있을 경우 chkYn을 'Y'로 바꿈
    //모달창 그리드 조회
    const usrData = useQuery([API.userMgmtPop, {blnsCoCd:param}], () => getData(API.userMgmtPop, {blnsCoCd:param}),{
        //select: data => data.map(item => ({...item, chkYn: chrgList.find(f => f === item.userEeno) ? 'Y' : 'N'}))
    })
        
    const columnDefs = [
        {
            checkboxSelection: true,
            headerCheckboxSelection: true,
            spanHeaderHeight: true,
            width:45,
            maxWidth:45,
            minWidth:45
        },
        {
            headerName: '회사구분',
            field: 'coNm',
            spanHeaderHeight: true,
        },
        {
            headerName: '부서명',
            field: 'deptNm',
            spanHeaderHeight: true,
            cellRenderer:"escapeCharChangeForGrid"
        },
        {
            headerName: '아이디',
            field: 'userEeno',
            cellStyle: () => ({textDecoration: 'underline', cursor: 'pointer', color:'#2589f5'}),
            spanHeaderHeight: true,
        },
        {
            headerName: '이름',
            field: 'userNm',
            spanHeaderHeight: true,
        }   
    ]

    const columnDefs2 = [
        {
            headerName: '회사구분',
            field: 'coNm',
            spanHeaderHeight: true,
        },
        {
            headerName: '부서명',
            field: 'deptNm',
            spanHeaderHeight: true,
            cellRenderer:"escapeCharChangeForGrid"
        },
        {
            headerName: '아이디',
            field: 'userEeno',
            cellStyle: () => ({textDecoration: 'underline', cursor: 'pointer', color:'#2589f5'}),
            spanHeaderHeight: true,
        },
        {
            headerName: '이름',
            field: 'userNm',
            spanHeaderHeight: true,
        }   
    ]

    const saveEvent = () =>{
        let selectedRows = usrGrid.current.api.getSelectedRows();
        onChangeUsrList(param.blnsCoCd, selectedRows);
        onHide();
    }


    const onFirstDataRendered = (params) => {
        params.api.sizeColumnsToFit();

        let grid = usrGrid.current.api;
        grid.forEachNode((node) =>
            // console.log(node.data.userEeno)
            node.setSelected(!!node.data && node.data.chkYn === 'Y' )
        )
    };

    return (
        <>
            <CustomModal open={show} 
                title={label?label+' 검색':'담당자 검색'}
                size='lg'
                // handleOk={handleSubmit}
                handleCancel={onHide} 
            >
            {/* <Modal show={show} onHide={onHide} backdrop="static" backdropClassName="modal-in-backdrop" keyboard={false} centered size="md" className="modal-custom modal-in-modal">
                <Modal.Header closeButton>
                    <Modal.Title>{label?label+' 검색':'담당자 검색'}</Modal.Title>
                </Modal.Header>
                    <Modal.Body> */}
                          <div className="ag-theme-alpine" style={{height:300}}>
                                <AgGridReact
                                    ref={usrGrid} 
                                    rowData={usrData && usrData.data}
                                    columnDefs={rmCheck ? columnDefs2 : columnDefs}
                                    defaultColDef={defaultColDef}
                                    rowSelection={'multiple'}
                                    suppressRowClickSelection= {true} 
                                    onFirstDataRendered={onFirstDataRendered}
                                    suppressSizeToFit={true}    
                                    onGridSizeChanged={onFirstDataRendered}     
                                    //escape 문자 처리 추가
                                    frameworkComponents={{
                                        escapeCharChangeForGrid
                                    }}
                                    onCellClicked={onCellClicked}
                                ></AgGridReact>
                            </div>
                <div className='modal-footer'>
                    <Button variant="light" size="md" onClick={rmValue}>취소</Button>
                    {!rmCheck && <Button variant="primary" size="md" onClick={()=>saveEvent()}>저장</Button>}
                </div>
            </CustomModal>
                    {/* </Modal.Body>
                    <Modal.Footer>
                        <Button variant="light" size="md" onClick={rmValue}>취소</Button>
                        {!rmCheck && <Button variant="primary" size="md" onClick={()=>saveEvent()}>저장</Button>}
                    </Modal.Footer>
            </Modal> */}
        </>
    );

};

const PersonSearch = ({label, rmCheck, onChangeCrgrEeno}) => {

    const {keyword, coCd } = useStore(); 

    const onHidePerson = () => {
        setVehlPersonPop(false);
    }

    const [crgrEeno, setCrgrEeno] = useState('')
    const [crgrEenoNm, setCrgrEenoNm] = useState('')

    // 셀 클릭
    const onCellClicked = e => {
        if(e.column.colId === 'userEeno'){
            // setCrgrEeno(e.data.userEeno)
            onChangeCrgrEeno(e.data.userEeno)
            setCrgrEenoNm(e.data.userNm)
            setVehlPersonPop(false);
        }
    };

    const rmValue = e => {
        onChangeCrgrEeno('ALL')
        setCrgrEenoNm('')
        setVehlPersonPop(false);
    };



    const [vehlPersonPop, setVehlPersonPop] = useState(false);
    const CustomInputGroupWidthButton = ({value}) => (
        <InputGroup inside >
            <Input style={{fontSize:'12px', height:'28px'}} value={value} readOnly/>
            <InputGroup.Button style={{height:'28px'}} onClick={() => setVehlPersonPop(true)}>
            <SearchIcon />
            </InputGroup.Button>
        </InputGroup>
    );

    return (
        <>
            <Form.Group>
                {label &&
                    <Form.ControlLabel column="sm">{label?label:'담당자'}</Form.ControlLabel>
                }
                <CustomInputGroupWidthButton size="sm" value={crgrEenoNm}/>
            </Form.Group>

            {vehlPersonPop&& 
            <GridPerson 
                show={vehlPersonPop} 
                onHide={onHidePerson} 
                setCrgrEeno={setCrgrEeno} 
                onCellClicked={onCellClicked} 
                rmValue={rmValue}
                label={label}
                rmCheck={rmCheck}
                param={coCd}
            />
            }
        </>
    );

};
export default PersonSearch;


