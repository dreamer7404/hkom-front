// react
import React, {useState, useEffect, useRef} from 'react';

//--------------  서버데이터용 필수 -------------------------------
import { useQuery,useMutation} from 'react-query';
import { API, CONSTANTS } from '../../../../utils/constants';
import { getData,postData } from '../../../../utils/async';
import useStore from '../../../../utils/store';
//--------------// 서버데이터용 필수 -------------------------------

import GridBatchList from '../_Grid/GridBatchList';
import Total from '../../../Common/Total';
import { confirmAlert } from 'react-confirm-alert'; // Import
import ConfirmAlert from '../../../Common/ConfirmAlert';

const BatchList = () => {

    //------------------- 필수 공통 ------------------------------
    const {keyword } = useStore();  // 조회키워드 가져오기
    
    const [activePage, setActivePage] = useState(1);    // 페이지번호
    const [limit, setLimit] = useState(50);             // 페이지행수
    let batchData = {};
    // const [data, setData] = useState();             // 페이지행수

    const onChangePage = val => {
        setActivePage(val);
    };
    const onChangeLimit = val => {
        setLimit(val);
    };
    useEffect(()=>{
        onChangePage(1); // 페이지번호 리셋
    },[keyword]);


    const onClickEvent=(item)=>{
        batchData= item.data
        console.log("dm",batchData);
        confirmAlert({
            closeOnClickOutside: false,
            customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}   title={"알림"}
            msg={"해당 Batch를 재실행 하시겠습니까?"} 
            onOk={onOk}  />
        });
    }
  

    const onOk = () => {
        console.log("batchData",batchData);
        batchSave.mutate(batchData);
    }
    const batchSave = useMutation((params => postData(API.batchSave, params, CONSTANTS.insert)),{
        onSuccess: res => {
            
            if(res>0){
            confirmAlert({
                closeOnClickOutside: false,
                customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}   title={"알림"}
                msg={"저장이 완료되었습니다."}   />
                
            });
           }
           else{
            confirmAlert({
                closeOnClickOutside: false,
                customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}   title={"알림"}
                msg={"에러가 발생했습니다 관리자에게 문의해주세요."}   />
                
            });
           }
        }
    });



    //-------------------// 필수 공통 ------------------------------

   
    //batch 조회
    const queryResult = useQuery([API.batchInfos, {}], () => getData(API.batchInfos, {}),{
        staleTime: 0,
    });    
   
   
    const onCellClicked=()=>{
        
    }

    return (
        <>
            <div className="grid-wrap" style={{paddingTop:'10px', borderTop:'2px solid var(--main-color)'}}>
                {/*--------- Grid -----------*/}
                <GridBatchList 

                    queryResult={queryResult}
                    limit={limit}
                    activePage={activePage}
                    onCellClicked={onCellClicked}
                    onClickEvent={onClickEvent}
                    />

                {/*--------- 페이징 -----------*/}
                <Total 
                    total={queryResult && queryResult.data && queryResult.data.length}
                    limit={limit}
                    activePage={activePage}
                    onChangePage={onChangePage}
                    onChangeLimit={onChangeLimit}
                />
            </div>
        </>
    )
};
export default BatchList;