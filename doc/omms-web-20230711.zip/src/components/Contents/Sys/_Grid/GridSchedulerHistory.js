import React, {useEffect, useMemo, useRef} from 'react';
import { AgGridReact } from 'ag-grid-react';
import { CONSTANTS } from '../../../../utils/constants';
import { escapeCharChangeForGrid} from '../../../../utils/commUtils';
const GridSchedulerHistory = ({gridHeight, filterValue, queryResult, limit, activePage}) => {

  const gridRef = useRef();

  const columnDefs = [
    
        {
          headerName: '스케줄러',
          field: 'schedNm',
          maxWidth:'150'
        },
        {
            headerName: '시작시간',
            field: 'startDtm',
            maxWidth:'150'
        },
        {
          headerName: '종료시간',
          field: 'endDtm',
          maxWidth:'150'
        },
        {
          headerName: 'URL',
          field: 'apiUrl',
          
          cellRenderer:"escapeCharChangeForGrid"
        },
        
        {
          headerName: '데이타 개수',
          field: 'getDataCnt',
          maxWidth:'300'
        },
        {
          headerName: '저장 개수',
          field: 'saveDataCnt',
          maxWidth:'300'
        },
        
  ]

  const defaultColDef = useMemo(() => {
      return {
          initialWidth: 90,
          sortable: true,
          resizable:true,
          minWidth:70
      };
  }, []);

  const onFirstDataRendered = (params) => {
      params.api.sizeColumnsToFit();
  };

  useEffect(()=>{
    if(queryResult.status === 'loading' && gridRef && gridRef.current && gridRef.current.api){
        gridRef.current.api.showLoadingOverlay();
    }
  },[queryResult]);

  useEffect(()=> {
    if(gridRef && gridRef.current && gridRef.current.api){
      gridRef.current.api.setQuickFilter(filterValue);
    }
  },[filterValue]);

  useEffect(()=> {
    if(gridRef && gridRef.current && gridRef.current.api){
      gridRef.current.api.paginationGoToPage(activePage-1);
    }
  },[activePage]);


  return(
      <div className="ag-theme-alpine" style={{height: gridHeight, transition:'all ease .3s'}}>
        <AgGridReact
            ref={gridRef} 
            rowData={queryResult && queryResult.data} 
            columnDefs={columnDefs}
            defaultColDef={defaultColDef}

            // paging
            pagination={true}
            paginationPageSize={limit} //
            suppressPaginationPanel={true} 
            // onPaginationChanged={onPaginationChanged}
            frameworkComponents={{
              escapeCharChangeForGrid
              
              }}
            //  filter
            cacheQuickFilter={true}

            // overlay
            overlayLoadingTemplate={CONSTANTS.gridLoading}
            overlayNoRowsTemplate={CONSTANTS.gridNoRows}

            onFirstDataRendered={onFirstDataRendered}
            suppressSizeToFit={true}    
            onGridSizeChanged={onFirstDataRendered}    
            >
        </AgGridReact>
    </div>
  )


};
export default GridSchedulerHistory;