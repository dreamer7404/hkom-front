// react
import React, {useState, useEffect, useCallback, useRef, useMemo} from 'react';
import { AgGridReact } from 'ag-grid-react';
import {Col, Modal, Button} from 'react-bootstrap';
import {Form, SelectPicker} from 'rsuite';

//--------------  서버데이터용 필수 -------------------------------
import { useQuery, useQueryClient, useMutation} from 'react-query';
import { getData, postData } from '../../../../utils/async';
import { API, CONSTANTS } from '../../../../utils/constants';
import useStore from '../../../../utils/store';
//--------------// 서버데이터용 필수 -------------------------------
import { confirmAlert } from 'react-confirm-alert'; 
import ConfirmAlert from   '../../../Common/ConfirmAlert'; 

import GridMenuGroupList from '../_Grid/GridMenuGroupList';
import Total from '../../../Common/Total';

import MenuGroupAdd from '../Popup/MenuGroupAdd';
import MenuGroupUpdate from '../Popup/MenuGroupUpdate';

const MenuGroupList = () => {

    //------------------- 필수 공통 ------------------------------
    const {keyword } = useStore();  // 조회키워드 가져오기
    const gridRef = useRef();
    const [activePage, setActivePage] = useState(1);    // 페이지번호
    const [limit, setLimit] = useState(50);             // 페이지행수
    const [data, setData] = useState();             // 페이지행수

    const onChangePage = val => {
        setActivePage(val);
    };
    const onChangeLimit = val => {
        setLimit(val);
    };
    useEffect(()=>{
        onChangePage(1); // 페이지번호 리셋
    },[keyword]);


    //-------------------// 필수 공통 ------------------------------

    // 메뉴그룹
    const queryResult = useQuery([API.pgmMgmtGrps], () => getData(API.pgmMgmtGrps));

    // 셀 클릭
    const onCellClicked = e => {
        if(e.column.colId === 'pgmNm'){
            setMenuGroupUpdatePop(true)
            const param = {
                menuId : e.data.menuId,
                pgmNm : e.data.pgmNm,
                pgmPathAdr : e.data.pgmPathAdr,
                useYn : e.data.useYn
            }
            setData(param)
        }
    };
    const groupAddPop = () =>{
        setMenuGroupAddPop(false)
        queryResult.refetch();
    }
    const groupUpdatePop = () =>{
        setMenuGroupUpdatePop(false)
        queryResult.refetch();
    }
    // 사용여부
    const onUseYn = useYn => {
    const rows = gridRef.current.api.getSelectedRows();
        if(rows.length > 0){
            changeUseYnMutate.mutate({useYn: useYn, list: rows.map(item => item.menuId)});
        } else {
            confirmAlert({
                closeOnClickOutside: false,
                customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}   title={"알림"}
                msg={"최소 한 개의 데이터를 선택해주세요."}   />
            });
        }

    };

    const changeUseYnMutate = useMutation((params => postData(API.changePgmMgmtUseYn, params, CONSTANTS.update)),{
        onSuccess: res => {
            if(res > 0){
                confirmAlert({
                    closeOnClickOutside: false,
                    customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}   title={"알림"}
                    msg={"저장되었습니다."}   />
                });
                 queryResult.refetch();
            }else{
                confirmAlert({
                    closeOnClickOutside: false,
                    customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}   title={"알림"}
                    msg={"에러가 발생했습니다 관리자에게 문의해주세요."}   />
                });
            }

        }
    });

    const [menuGroupAddPop, setMenuGroupAddPop] = useState(false);
    const [menuGroupUpdatePop, setMenuGroupUpdatePop] = useState(false);

    return (
        <>
            <div className="grid-wrap" style={{paddingTop:'10px', borderTop:'2px solid var(--main-color)'}}>
                <div className="grid-btn-wrap">
                    <div className="right-align">
                        {/*--------- 버튼 -----------*/}
                        <Button variant="outline-secondary" size="sm" onClick={() => setMenuGroupAddPop(true)}>메뉴그룹 등록</Button>{' '}
                        <Button variant="outline-secondary" size="sm" onClick={() => onUseYn('Y')}>사용</Button>{' '}
                        <Button variant="outline-secondary" size="sm" onClick={() => onUseYn('N')}>미사용</Button>{' '}
                    </div>
                </div>
                {/*--------- Grid -----------*/}
                <GridMenuGroupList 
                    gridRef={gridRef}
                    queryResult={queryResult}
                    limit={limit}
                    activePage={activePage}
                    onCellClicked={onCellClicked}
                />

                {/*--------- 페이징 -----------*/}
                <Total 
                    total={queryResult && queryResult.data && queryResult.data.length}
                    limit={limit}
                    activePage={activePage}
                    onChangePage={onChangePage}
                    onChangeLimit={onChangeLimit}
                />
            </div>

            {menuGroupAddPop && <MenuGroupAdd show={menuGroupAddPop} onHide={groupAddPop} />}
            {menuGroupUpdatePop && <MenuGroupUpdate show={menuGroupUpdatePop} onHide={groupUpdatePop}  data={data}/>}
        </>
    )
};
export default MenuGroupList;