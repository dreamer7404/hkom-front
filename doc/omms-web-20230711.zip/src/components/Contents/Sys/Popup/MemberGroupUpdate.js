import React from 'react';
import {Button, Modal, Table} from 'react-bootstrap';
import { Form, SelectPicker, Schema, useToaster, Notification } from 'rsuite';

//--------------  서버데이터용 필수 -------------------------------
import { useQuery, useMutation} from 'react-query';
import { getData, postData } from '../../../../utils/async';
import { API, CONSTANTS } from '../../../../utils/constants';
//--------------// 서버데이터용 필수 -------------------------------

import { escapeCharChange, formatNumber } from '../../../../utils/commUtils';

const { StringType, NumberType} = Schema.Types;
const model = Schema.Model({
    grpNm: StringType().isRequired('그룹명를 입력해주세요.').pattern(/^[가-힣a-zA-Z]+$/, '한글, 영문만 입력사능합니다.'),
    // sortSn: StringType().isRequired('정렬순서를 입력해주세요.').pattern(/^[0-9]+$/ ,'숫자로만 입력해주세요'),
    sortSn: NumberType().isRequired('정렬순서를 입력해주세요.').range(1, 99, '순서번호 범위는 1~99입니다'),
    useYn: StringType().isRequired('사용유무를 선택해 주세요.'),
});


const MemberGroupAdd = ({data, show, onHide}) => {

    const toaster = useToaster();

    // Form 정의
    const formRef = React.useRef();
    const [formError, setFormError] = React.useState({});
    const [formValue, setFormValue] = React.useState({
      grpCd: data.grpCd,      
      grpNm: data.grpNm,  
      sortSn: data.sortSn,     
      useYn:  data.useYn,     
      rem: escapeCharChange(data.rem),   
    });

    // 저장버튼 클릭
    const handleSubmit = () => {
        // validation 체크
        if (!formRef.current.check()) {
            return;
        }
        queryMutate.mutate(formValue);
    }

    // 사용자등록하기
    const queryMutate = useMutation((params => postData(API.usrGrpMgmt, params, CONSTANTS.update)),{
        onSuccess: res => {
            console.log(res);
            if(res === 1){
                toaster.push(<Notification type='success' header='등록성공' closable >
                    저장이 완료되었습니다.
                    </Notification>);
                onHide(true); // 창닫기 & refetch
            }else if(parseInt(res,10) === -1){
                toaster.push(<Notification type='error' header='등록실패' closable >그룹코드가 이미 사용중입니다..</Notification>);
            }else if(res === -2){
                toaster.push(<Notification type='error' header='등록실패' closable >정렬순서가 이미 사용중입니다..</Notification>);
            }else{
                toaster.push(<Notification type='error' header='등록실패' closable >
                    등록이 실패했습니다.<br /> 관리자에게 문의해주세요.
                    </Notification>);
               
            }
        }
    });

    return (
        <>
            <Form
             ref={formRef}
             checkTrigger="change"
             onChange={setFormValue}
             onCheck={setFormError}
             formValue={formValue}
             model={model}>
                <Modal show={show} onHide={onHide} backdrop="static" keyboard={false} centered size="lg" className="modal-custom">
                    <Modal.Header closeButton>
                        <Modal.Title>사용자그룹 상세/수정</Modal.Title>
                    </Modal.Header>
                        <Modal.Body>
                            <Table className="tbl-hor" bordered>
                                <colgroup>
                                    <col style={{width:'15%'}}></col>
                                    <col style={{width:'35%'}}></col>
                                    <col style={{width:'15%'}}></col>
                                    <col style={{width:'35%'}}></col>
                                </colgroup>
                                <tbody>
                                    <tr>
                                        <th className="">그룹코드</th>
                                        <td>
                                            {formValue.grpCd}
                                        </td>
                                        <th className="essen">그룹명</th>
                                        <td>
                                            <Form.Control size="sm" name="grpNm" />
                                        </td>
                                    </tr>
                                    <tr>
                                        <th className="essen">정렬순서</th>
                                        <td>
                                            <Form.Control size="sm" name="sortSn" maxLength={2} />
                                        </td>
                                        <th className="essen">사용여부</th>
                                        <td>
                                        <Form.Control name="useYn" size="sm" 
                                                placeholder={'선택'}
                                                defaultValue={''}
                                                accepter={SelectPicker} 
                                                searchable={false}
                                                cleanable={false}
                                                data={[
                                                    {label: '사용', value: 'Y'},
                                                    {label: '미사용', value: 'N'},
                                                ]}
                                            ></Form.Control>
                                        </td>
                                    </tr>
                                    <tr>
                                        <th>비고</th>
                                        <td colSpan="3">
                                        <Form.Control size="sm" name="rem"/> 
                                        </td>
                                    </tr>
                                </tbody>
                            </Table>
                        </Modal.Body>

                        <Modal.Footer>
                            <Button variant="light" size="md" onClick={onHide}>취소</Button>
                            <Button variant="primary" size="md" onClick={handleSubmit} >저장</Button>
                        </Modal.Footer>
                </Modal>
            </Form>
        </>
    );

};
export default MemberGroupAdd;