import React, {useState, useMemo, useRef,useEffect} from 'react';
import { AgGridReact } from 'ag-grid-react';
import {Col, Modal, Button} from 'react-bootstrap';
import {Form, SelectPicker,Schema} from 'rsuite';
import SearchIcon from '@rsuite/icons/Search';
import { API, CONSTANTS } from '../../../../utils/constants';
import { useQuery,useMutation} from 'react-query';
import { getData,postData } from '../../../../utils/async';
import { confirmAlert } from 'react-confirm-alert'; // Import
import ConfirmAlert from '../../../Common/ConfirmAlert';
import CustomModal from '../../../Common/CustomModal';
const { StringType} = Schema.Types;
const model = Schema.Model({
    
});

const SysCodeGroupDelete = ({show, onHide}) => {
    const gridRef = useRef();
    const formRef = useRef();
    const [formError, setFormError] = useState({});
    const [formValue, setFormValue] = useState({
        dlExpdGCd : '', //그룹코드
        dlExpdGNm : '', //그룹코드 명
    }); 
    const grpCodeCombo = useQuery([API.grpCodeCombo,{}], () => getData(API.grpCodeCombo,{}))  //그룹코드 그리드데이터

    const columnDefs = [
        {
          checkboxSelection: true,
          headerCheckboxSelection: true,
          width:35,
          maxWidth:35,
          minWidth:35,
          sortable:false
        },
        {
            headerName: '그룹코드',
            field: 'dlExpdGCd',
            maxWidth:'150',
        },
        {
          headerName: '그룹명',
          field: 'dlExpdGNm',
        },
    ]

    const defaultColDef = useMemo(() => {
        return {
            initialWidth: 90,
            sortable: true,
            resizable:true,
            minWidth:70
        };
    }, []);

    const onFirstDataRendered = (params) => {
        params.api.sizeColumnsToFit();
    };

    const handleSubmit = () => {
        let checkedItems = gridRef.current.api.getSelectedRows();
        if(checkedItems.length===0){
            confirmAlert({
                closeOnClickOutside: false,
                customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}   title={"알림"}
                msg={"최소 한 개의 데이터를 선택해주세요."} 
                
                />
                
            });
            return
        }
    
        confirmAlert({
            closeOnClickOutside: false,
            customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}   title={"알림"}
            msg={"선택하신 항목을 삭제하시겠습니까?"} 
            onOk={onOk}  />
        });
    }; 

    const codeGrpSave = useMutation((params => postData(API.codeGrpMgmt, params, CONSTANTS.delete)),{
        onSuccess: res => {
            if(res>0){
            confirmAlert({
                closeOnClickOutside: false,
                customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}   title={"알림"}
                msg={"삭제 완료되었습니다."}   />
                
            });
           }
           else{
            confirmAlert({
                closeOnClickOutside: false,
                customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}   title={"알림"}
                msg={"에러가 발생했습니다 관리자에게 문의해주세요."}   />
                
            });
           }
           grpCodeCombo.remove(); 
           onHide();
        }
    });


    const onOk = () => {
        console.log('grid',gridRef.current.api.getSelectedRows())
        const deleteList = {
            deleteList : gridRef.current.api.getSelectedRows()
        }
        codeGrpSave.mutate(deleteList);
    }
    return (
        <>
            <Form
                ref={formRef}
                checkTrigger="change"
                onChange={setFormValue}
                onCheck={setFormError}
                formValue={formValue}
                model={model}>
                <CustomModal open={show} 
                        title={'그룹코드 삭제'}
                        size='md'
                        // handleOk={handleSubmit}
                        handleCancel={onHide} >
                        <div className="ag-theme-alpine" style={{height:300, minWidth:300}}>
                            <AgGridReact
                               ref={gridRef} 
                                rowData={grpCodeCombo.data}
                                columnDefs={columnDefs}
                                defaultColDef={defaultColDef}
                                rowSelection={'multiple'}
                                suppressRowClickSelection= {true} 
                                onFirstDataRendered={onFirstDataRendered}
                                suppressSizeToFit={true}    
                                onGridSizeChanged={onFirstDataRendered}     
                                >
                            </AgGridReact>
                        </div>
                    
                    <div className='modal-footer'>
                        <Button variant="light" size="md" onClick={onHide}>취소</Button>
                        <Button variant="outline-danger" size="md" onClick={handleSubmit}>삭제</Button>
                    </div>
                </CustomModal>
            </Form>
        </>
    );

};
export default SysCodeGroupDelete;