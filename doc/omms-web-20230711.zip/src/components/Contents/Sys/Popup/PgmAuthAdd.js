import React, {useState, useEffect, useCallback, useRef, useMemo} from 'react';
import { AgGridReact } from 'ag-grid-react';
import {Col, Modal, Button} from 'react-bootstrap';
import {Form, SelectPicker} from 'rsuite';
import SearchIcon from '@rsuite/icons/Search';

import { formatNumber, escapeCharChange } from '../../../../utils/commUtils';

//--------------  서버데이터용 필수 -------------------------------
import { useQuery, useQueryClient, useMutation} from 'react-query';
import { getData, postData } from '../../../../utils/async';
import { API, CONSTANTS } from '../../../../utils/constants';
import useStore from '../../../../utils/store';
//--------------// 서버데이터용 필수 -------------------------------
import { confirmAlert } from 'react-confirm-alert'; 
import ConfirmAlert from   '../../../Common/ConfirmAlert'; 

const PgmAuthAdd = ({show, data, onHide}) => {

    const gridRef = useRef();

    const columnDefs = [
        {
          checkboxSelection: true,
          headerCheckboxSelection: true,
          width:35,
          maxWidth:35,
          minWidth:35,
          sortable:false
        },
        {
            headerName: '메뉴ID',
            field: 'menuId',
            maxWidth:'100',
        },
        {
            headerName: '메뉴명',
            field: 'pgmNm',
            maxWidth:'150',
            cellRenderer: param => {
              return !param.value  ? '공통' : param.value;
            }
        },
        {
            headerName: 'API URL',
            field: 'apiUrl',
            cellStyle: () => ({textAlign: 'left', textDecoration: 'underline', cursor: 'pointer', color:'#2589f5'})
        },
        {
          headerName: 'API 설명',
          spanHeaderHeight: true,
          field: 'apiNm',
          cellStyle: () => ({textAlign: 'left'}),
          cellRenderer: param => escapeCharChange(param.value)
        },
        {
          headerName: 'API 타입',
          field: 'method',
          maxWidth:'100'
        },
    ]

    const defaultColDef = useMemo(() => {
        return {
            initialWidth: 90,
            sortable: true,
            resizable:true,
            minWidth:70
        };
    }, []);

    const onFirstDataRendered = (params) => {
        params.api.sizeColumnsToFit();

         // 데이타에서 authVehl === 'Y'인것은 체크
         gridRef.current.api.forEachNode((node) =>
            node.setSelected(!!node.data && node.data.grpCd !== null)
        );
    };

    //  requestState 조회
    const params = {
        grpCd: data.grpCd
    };
    const queryResult = useQuery([API.apiMgmtsByApiAuth,  params], () => getData(API.apiMgmtsByApiAuth,  params));


    const selectData = ['전체', '재고관리', '제작준비', '발간현황', '선적현황', '운영관리', '시스템관리'].map(
        item => ({ label: item, value: item })
    );

    const updateMutate = useMutation((params => postData(API.apiAuth, params, CONSTANTS.update)),{
        onSuccess: res => {
            if(res === 1){
                confirmAlert({
                    closeOnClickOutside: false,
                    customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}  title={"알림"} msg={"저장이 완료되었습니다."}  />
                })
                queryResult.remove();
                onHide(); // 창닫기 & refetch
            }else{
                confirmAlert({
                    closeOnClickOutside: false,
                    customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}  title={"알림"} msg={"등록이 실패했습니다.<br /> 관리자에게 문의해주세요."}  />
                })
            }
        }
    }); 

    // 저장버튼 클릭
    const handleSubmit = () => {

        const selectedRows = gridRef.current.api.getSelectedRows();
      
        // API 등록 실행
        const params = {
            grpCd: data.grpCd,
            apiUrls: selectedRows.map(item => ({apiUrl: item.apiUrl, method: item.method})),
        }
        updateMutate.mutate(params);
    };



    return (
        <>
            <Form>
                <Modal show={show} onHide={onHide} backdrop="static" keyboard={false} centered size="lg" className="modal-custom">
                    <Modal.Header closeButton>
                        <Modal.Title>프로그램 권한등록</Modal.Title>
                    </Modal.Header>
                    <Modal.Body>
                        <div className="search-area">
                            <div className="form" id="example-collapse-text">
                                <div className="search-group">
                                    <div className="row">
                                        <Col sm={6} className=""> 
                                            <Form.ControlLabel column="sm" >메뉴그룹</Form.ControlLabel>
                                            <SelectPicker block size="sm" searchable={false} cleanable={false} data={selectData} defaultValue="전체" />
                                        </Col>
                                    </div>
                                    <div className="search-btn-wrap">
                                        <Button className="btn-search" variant="ou-primary" size="sm"><SearchIcon />조회</Button>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div className="grid-btn-wrap">
                            <div className="left-align">
                                <div className="sub-title">
                                    <ul>
                                        <li>{data.grpNm}</li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div className="ag-theme-alpine" style={{height:300, minWidth:300}}>
                            <AgGridReact
                                ref={gridRef}
                                rowData={queryResult && queryResult.data}
                                columnDefs={columnDefs}
                                defaultColDef={defaultColDef}
                                rowSelection={'multiple'}
                                suppressRowClickSelection= {true} 
                                onFirstDataRendered={onFirstDataRendered}
                                suppressSizeToFit={true}    
                                onGridSizeChanged={onFirstDataRendered}     
                                >
                            </AgGridReact>
                        </div>
                    </Modal.Body>
                    <Modal.Footer>
                        <Button variant="light" size="md" onClick={onHide}>취소</Button>
                        <Button variant="primary" size="md" onClick={handleSubmit}>저장</Button>
                    </Modal.Footer>
                </Modal>
            </Form>
        </>
    );

};
export default PgmAuthAdd;