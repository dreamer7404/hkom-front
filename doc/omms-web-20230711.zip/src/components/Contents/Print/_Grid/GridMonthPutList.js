import React, {useState, useEffect, useMemo, useRef} from 'react';
import { AgGridReact } from 'ag-grid-react';
import { CONSTANTS } from '../../../../utils/constants';
import { formatNumber } from '../../../../utils/commUtils';

const GridMonthPutList = ({gridHeight, filterValue, queryResult, limit, activePage, gridRef}) => {

  const rowSpan = (params) => {
        return params.data.flag? params.data.flag: 1;
    };

  class ShowCellRenderer {
      init(params) {  
      const cellBlank = !params.value;
      if (cellBlank) {
          return;
      }
  
      this.ui = document.createElement('div');
      this.ui.innerHTML = '<div class="rowspan-title" style="line-height:' + params.data.flag * '30' + 'px;">' + params.value + '</div>';
      
      }
  
      getGui() {
      return this.ui;
      }
  
      refresh() {
      return false;
      }
  }

  const [arrKeys, setArrKeys] = useState(['col0','col1','col2','col3','col4','col5','col6','col7','col8','col9','col10','col11','col12','col13']);
  const [hdName, setHdName] = useState({});
  const [queryResultRealDatas, setQueryResultRealDatas] = useState([]);
  useEffect(() => {
    if(queryResult.isSuccess){
      setHdName(
        queryResult.isSuccess && queryResult.data.filter(item => {
          return item.qltyVehlCd === 'MONTH'
        })[0]
      )
      setQueryResultRealDatas (
        queryResult.isSuccess && queryResult.data.filter(item => {
          return item.qltyVehlCd !== 'MONTH'
        })
      )
    }
  },[queryResult.data])


  useEffect(() => {
    if(hdName.langCd && hdName.langCd !== 'ALL'){
      setColumnDefs([
        {
          headerName: '차종',
          children: [
            { 
                headerName:'차종코드',
                field: 'qltyVehlCd',
                sortable: true,
                cellRenderer: ShowCellRenderer,
                rowSpan: rowSpan,
                cellClass: (rowSpan) => {
                  return rowSpan.data.flag >= 2 ? 'show-cell' : null;
                },
                minWidth:70
            },
            { headerName:'차종명',
              field: 'qltyVehlNm',
              sortable: true,
              cellRenderer: ShowCellRenderer,
              rowSpan: rowSpan,
              cellClass: (rowSpan) => {
                  return rowSpan.data.flag >= 2 ? 'show-cell' : null;
              },
              minWidth:130
            },
          ],
        },
        {
          headerName: '언어',
          children: [
            { 
              headerName:'지역', 
              minWidth:70,
              field: 'region', 
              sortable: true,
              cellRenderer: ShowCellRenderer,
              rowSpan: rowSpan,
              cellClass: (rowSpan) => {
                return rowSpan.data.flag >= 2 ? 'show-cell' : null;
              },
            },
            { 
              headerName:'언어코드',
              field: 'langCd',
              minWidth:70,
                sortable: true,
                cellRenderer: ShowCellRenderer,
                rowSpan: rowSpan,
                cellClass: (rowSpan) => {
                  return rowSpan.data.flag >= 2 ? 'show-cell' : null;
                },
              },
              {
                headerName:'언어명',
                sortable: true,
                minWidth:130,
                field: 'langCdNm',
                cellRenderer: ShowCellRenderer,
                rowSpan: rowSpan,
                cellClass: (rowSpan) => {
                  return rowSpan.data.flag >= 2 ? 'show-cell' : null;
                },
              },
            ],
          },
          {
            headerName: '항목',
            field: 'gubun',
            sortable: false,
            spanHeaderHeight: true,
          },]
          .concat(arrKeys.map((item, index) => {
          
            if (hdName['col'+index] !== null){
              return {
                headerName:hdName['col'+index] + '월',
                field:'col'+index,
                spanHeaderHeight: true,
                sortable: false,
                cellRenderer: data => {
                  if(data.data.gubun === '투입수량'){
                    console.log(data)
                    return formatNumber(data.data['col'+index])
                  }
                  if(data.data.gubun === '제작예산'){
                    console.log(data)
                    return formatNumber(data.data['pcol'+index])
                  }
                  if(data.data.gubun === '제작수량'){
                    console.log(data)
                    return formatNumber(data.data['qcol'+index])
                  }
                }
                
              }
            }
        }).filter(item => {
          return item !== undefined && item !== null
        }))
      )
    } else {
      setColumnDefs([
        {
          headerName: '차종',
          children: [
            { 
                headerName:'차종코드',
                field: 'qltyVehlCd',
                minWidth:70,
                sortable: true,
                cellRenderer: ShowCellRenderer,
                rowSpan: rowSpan,
                cellClass: (rowSpan) => {
                  return rowSpan.data.flag >= 2 ? 'show-cell' : null;
                },
            },
            { headerName:'차종명',
              field: 'qltyVehlNm',
              sortable: true,
              minWidth:130,
              cellRenderer: ShowCellRenderer,
              rowSpan: rowSpan,
              cellClass: (rowSpan) => {
                  return rowSpan.data.flag >= 2 ? 'show-cell' : null;
                },
            },
          ],
        },
        {
          headerName: '항목',
          field: 'gubun',
          sortable: false,
          spanHeaderHeight: true,
        },]
        .concat(arrKeys.map((item, index) => {
          if (hdName['col'+index] !== null){
            return {
              headerName:hdName['col'+index] + '월',
              field:'col'+index,
              spanHeaderHeight: true,
              sortable: false,
              cellRenderer: data => {
                if(data.data.gubun === '투입수량'){
                  return formatNumber(data.data['col'+index])
                }
                if(data.data.gubun === '제작예산'){
                  return formatNumber(data.data['pcol'+index])
                }
                if(data.data.gubun === '제작수량'){
                  return formatNumber(data.data['qcol'+index])
                }
              }
            }
          }
        }).filter(item => {
          return item !== undefined && item !== null
        }))
      )
    }
    
  }, [hdName])
  
  const [columnDefs, setColumnDefs] = useState([
      {
        headerName: '차종',
        children: [
          { 
              headerName:'차종코드',
              field: 'qltyVehlCd',
              minWidth:70,
              sortable: true,
              cellRenderer: ShowCellRenderer,
              rowSpan: rowSpan,
              cellClass: (rowSpan) => {
                return rowSpan.data.flag >= 2 ? 'show-cell' : null;
              },
          },
          { headerName:'차종명',
            field: 'qltyVehlNm',
            minWidth:130,
            sortable: true,
            cellRenderer: ShowCellRenderer,
            rowSpan: rowSpan,
            cellClass: (rowSpan) => {
                return rowSpan.data.flag >= 2 ? 'show-cell' : null;
              },
          },
        ],
      },
      {
        headerName: '언어',
        children: [
          { 
              headerName:'지역', 
              field: 'region', 
              minWidth:70,
              sortable: true,
              cellRenderer: ShowCellRenderer,
              rowSpan: rowSpan,
              cellClass: (rowSpan) => {
                return rowSpan.data.flag >= 2 ? 'show-cell' : null;
              },
          },
          { 
              headerName:'언어코드',
              field: 'langCd',
              sortable: true,
              minWidth:70,
              cellRenderer: ShowCellRenderer,
              rowSpan: rowSpan,
              cellClass: (rowSpan) => {
                return rowSpan.data.flag >= 2 ? 'show-cell' : null;
              },

          },
          {
              headerName:'언어명',
              minWidth:130,
              sortable: true,
              field: 'langCdNm',
              cellRenderer: ShowCellRenderer,
              rowSpan: rowSpan,
              cellClass: (rowSpan) => {
                return rowSpan.data.flag >= 2 ? 'show-cell' : null;
              },
          },
        ],
      },
      {
          headerName: '항목',
          field: 'gubun',
          spanHeaderHeight: true,
      },
      {
        headerName: '23.01월',
        field: 'col0',
        spanHeaderHeight: true,
        cellRenderer: data => {
          if(data.data.gubun === '투입수량'){
            return formatNumber(data.data.col0)
          }
          if(data.data.gubun === '제작예산'){
            return formatNumber(data.data.pcol0)
          }
          if(data.data.gubun === '제작수량'){
            return formatNumber(data.data.qcol0)
          }
        }
      },
      {
        headerName: '22.01월',
        field: 'col1',
        spanHeaderHeight: true,
        cellRenderer: data => {
          if(data.data.gubun === '투입수량'){
            return formatNumber(data.data.col1)
          }
          if(data.data.gubun === '제작예산'){
            return formatNumber(data.data.pcol1)
          }
          if(data.data.gubun === '제작수량'){
            return formatNumber(data.data.qcol1)
          }
        }
        },
        {
        headerName: '22.02월',
        field: 'col2',
        spanHeaderHeight: true,
        cellRenderer: data => {
          if(data.data.gubun === '투입수량'){
            return formatNumber(data.data.col2)
          }
          if(data.data.gubun === '제작예산'){
            return formatNumber(data.data.pcol2)
          }
          if(data.data.gubun === '제작수량'){
            return formatNumber(data.data.qcol2)
          }
        }
        },
        {
        headerName: '22.03월',
        field: 'col3',
        spanHeaderHeight: true,
        cellRenderer: data => {
          if(data.data.gubun === '투입수량'){
            return formatNumber(data.data.col3)
          }
          if(data.data.gubun === '제작예산'){
            return formatNumber(data.data.pcol3)
          }
          if(data.data.gubun === '제작수량'){
            return formatNumber(data.data.qcol3)
          }
        }
        },  
        {
        headerName: '22.04월',
        field: 'col4',
        spanHeaderHeight: true,
        cellRenderer: data => {
          if(data.data.gubun === '투입수량'){
            return formatNumber(data.data.col4)
          }
          if(data.data.gubun === '제작예산'){
            return formatNumber(data.data.pcol4)
          }
          if(data.data.gubun === '제작수량'){
            return formatNumber(data.data.qcol4)
          }
        }
        },  
        {
          headerName: '22.05월',
          field: 'col5',
          spanHeaderHeight: true,
          cellRenderer: data => {
            if(data.data.gubun === '투입수량'){
              return formatNumber(data.data.col5)
            }
            if(data.data.gubun === '제작예산'){
              return formatNumber(data.data.pcol5)
            }
            if(data.data.gubun === '제작수량'){
              return formatNumber(data.data.qcol5)
            }
          }
        },
        {
          headerName: '22.06월',
          field: 'col6',
          spanHeaderHeight: true,
          cellRenderer: data => {
            if(data.data.gubun === '투입수량'){
              return formatNumber(data.data.col6)
            }
            if(data.data.gubun === '제작예산'){
              return formatNumber(data.data.pcol6)
            }
            if(data.data.gubun === '제작수량'){
              return formatNumber(data.data.qcol6)
            }
          }
          },
          {
            headerName: '22.07월',
            field: 'col7',
            spanHeaderHeight: true,
            cellRenderer: data => {
              if(data.data.gubun === '투입수량'){
                return formatNumber(data.data.col7)
              }
              if(data.data.gubun === '제작예산'){
                return formatNumber(data.data.pcol7)
              }
              if(data.data.gubun === '제작수량'){
                return formatNumber(data.data.qcol7)
              }
            }
          },
          {
            headerName: '22.08월',
            field: 'col8',
            spanHeaderHeight: true,
            cellRenderer: data => {
              if(data.data.gubun === '투입수량'){
                return formatNumber(data.data.col8)
              }
              if(data.data.gubun === '제작예산'){
                return formatNumber(data.data.pcol8)
              }
              if(data.data.gubun === '제작수량'){
                return formatNumber(data.data.qcol8)
              }
            }
          },
          {
            headerName: '22.09월',
            field: 'col9',
            spanHeaderHeight: true,
            cellRenderer: data => {
              if(data.data.gubun === '투입수량'){
                return formatNumber(data.data.col9)
              }
              if(data.data.gubun === '제작예산'){
                return formatNumber(data.data.pcol9)
              }
              if(data.data.gubun === '제작수량'){
                return formatNumber(data.data.qcol9)
              }
            }
          },
          {
            headerName: '22.10월',
            field: 'col10',
            spanHeaderHeight: true,
            cellRenderer: data => {
              if(data.data.gubun === '투입수량'){
                return formatNumber(data.data.col10)
              }
              if(data.data.gubun === '제작예산'){
                return formatNumber(data.data.pcol10)
              }
              if(data.data.gubun === '제작수량'){
                return formatNumber(data.data.qcol10)
              }
            }
          },
          {
            headerName: '22.11월',
            field: 'col11',
            spanHeaderHeight: true,
            cellRenderer: data => {
              if(data.data.gubun === '투입수량'){
                return formatNumber(data.data.col11)
              }
              if(data.data.gubun === '제작예산'){
                return formatNumber(data.data.pcol11)
              }
              if(data.data.gubun === '제작수량'){
                return formatNumber(data.data.qcol11)
              }
            }
          },
          {
            headerName: '22.12월',
            field: 'col12',
            spanHeaderHeight: true,
            cellRenderer: data => {
              if(data.data.gubun === '투입수량'){
                return formatNumber(data.data.col12)
              }
              if(data.data.gubun === '제작예산'){
                return formatNumber(data.data.pcol12)
              }
              if(data.data.gubun === '제작수량'){
                return formatNumber(data.data.qcol12)
              }
            }
          },
          {
            headerName: '23.01월',
            field: 'col13',
            spanHeaderHeight: true,
            cellRenderer: data => {
              if(data.data.gubun === '투입수량'){
                return formatNumber(data.data.col13)
              }
              if(data.data.gubun === '제작예산'){
                return formatNumber(data.data.pcol13)
              }
              if(data.data.gubun === '제작수량'){
                return formatNumber(data.data.qcol13)
              }
            }
          },
  ])

  const defaultColDef = useMemo(() => {
      return {
          initialWidth: 90,
          sortable: true,
          resizable:true,
          minWidth:70
      };
  }, []);

  const onFirstDataRendered = (params) => {
      params.api.sizeColumnsToFit();
  };

  useEffect(()=>{
    if(queryResult.status === 'loading' && gridRef && gridRef.current && gridRef.current.api){
        gridRef.current.api.showLoadingOverlay();
    }
  },[queryResult]);

  useEffect(()=> {
    if(gridRef && gridRef.current && gridRef.current.api){
      gridRef.current.api.setQuickFilter(filterValue);
    }
  },[filterValue]);

  useEffect(()=> {
    if(gridRef && gridRef.current && gridRef.current.api){
      gridRef.current.api.paginationGoToPage(activePage-1);
    }
  },[activePage]);


  return(
      <div className="ag-theme-alpine" style={{height: gridHeight, transition:'all ease .3s'}}>
        <AgGridReact
            ref={gridRef} 
            rowData={queryResult && queryResult.data && queryResultRealDatas} 
            columnDefs={columnDefs}
            defaultColDef={defaultColDef}

            // paging
            pagination={true}
            paginationPageSize={limit} //
            suppressPaginationPanel={true} 
            // onPaginationChanged={onPaginationChanged}

            //  filter
            cacheQuickFilter={true}

            suppressRowTransform={true}

            // overlay
            overlayLoadingTemplate={CONSTANTS.gridLoading}
            overlayNoRowsTemplate={CONSTANTS.gridNoRows}

            onFirstDataRendered={onFirstDataRendered}
            suppressSizeToFit={true}    
            onGridSizeChanged={onFirstDataRendered}
            //동적 컬럼을 위해 추가
            onGridColumnsChanged={onFirstDataRendered}
            >
        </AgGridReact>
    </div>
  )


};
export default GridMonthPutList;