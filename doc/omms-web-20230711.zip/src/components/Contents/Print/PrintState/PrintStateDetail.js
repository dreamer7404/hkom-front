// react
import React, {useState, useEffect, useCallback} from 'react';

import {Button, Table} from 'react-bootstrap';
import { API,CONSTANTS } from '../../../../utils/constants';
import {Button as ButtonBoot} from 'react-bootstrap';
//--------------  서버데이터용 필수 -------------------------------
import { useQuery} from 'react-query';
import useStore from '../../../../utils/store';
import { getData,postData } from '../../../../utils/async';
import { escapeCharChange } from '../../../../utils/commUtils';
//--------------// 서버데이터용 필수 -------------------------------

import GridPrintOrderAdd from '../_Grid/GridPrintOrderAdd';
import OutRequestChange from '../Popup/OutRequestChange';
import PrintArrayTable from '../../Mri/Popup/PrintArrayTable';

import PrintCost from '../Popup/PrintCost';
import PrintCostInputNo from '../Popup/PrintCostInputNo';
import { useLocation } from 'react-router';
import { Link,useNavigate} from 'react-router-dom';
import { formatNumber } from '../../../../utils/commUtils';
import { confirmAlert } from 'react-confirm-alert'; // Import
import ConfirmAlert from '../../../Common/ConfirmAlert';import AttachmentIcon from '@rsuite/icons/Attachment';
import FileControl from  '../../../Common/FileControl';

import qs from 'qs';

import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faPrint } from '@fortawesome/free-solid-svg-icons'

const PrintStateDetail = () => {

     //------------------- 필수 공통 ------------------------------
    const [open, setOpen] = useState(true); // 조건창 열기/닫기
    const {keyword } = useStore();  // 조회키워드 가져오기
    const navigate = useNavigate();
    const [activePage, setActivePage] = useState(1);    // 페이지번호
    const [limit, setLimit] = useState(50);             // 페이지행수
    const [filterValue, setFilterValue] = useState(''); // 필터값
    const [newPrntPbcnNo, setNewPrntPbcnNo] = useState();
    const [data, setData] = useState();
    const [reversionList, setReversionList] = useState();
    
    const location = useLocation();
     // 수량 천단위 콤마 찍기
  const currencyFormatter = (params) => {
    return formatNumber(params.value);
  };  
    const [query, setQuery] = useState(
        qs.parse(location.state, { ignoreQueryPrefix: true }),
    )

    const [test, setTest] = useState();
    const [files, setFiles] = useState(null) // 파일리스트
    

 // 상세 조회 (세부내역, 인쇄비용, 개정내용)
    const queryResult = useQuery([API.printState, query], () => getData(API.printState, query));

    useEffect(()=>{
        console.log('queryResult.data',queryResult.data);
        if(queryResult.isSuccess){
            if(!queryResult.data.prntApvlInfoList){
                navigate('/printState');
                console.log('[ERROR] prntApvlInfoList is NULL!!!');
                return;
            }

            setData(queryResult.data.prntApvlInfoList)
            setReversionList(queryResult.data.reviceInfoList);
            setTest(p=>({...p,
                dlvgParrYmd : queryResult.data.prntApvlInfoList.dlvgParrYmd,//납품예정일(납품예정일 변경)
                rqQty : queryResult.data.prntApvlInfoList.rqQty, //인쇄부수 (인쇄비용 할당값)
                saleUnp : queryResult.data.prntApvlInfoList.saleUnp, 
                prntParrBgt : queryResult.data.prntApvlInfoList.prntParrBgt ,
                prtlImtrSbc3 : queryResult.data.prntApvlInfoList.prtlImtrSbc3,
                prntParrYmd :  queryResult.data.prntApvlInfoList.prntParrYmd,
                newPrntPbcnNo : queryResult.data.prntApvlInfoList.newPrntPbcnNo,

            }) )

            setFiles(queryResult.data.fileList);
            // console.log('queryResult.data.fileList',queryResult.data.fileList)
        }
    },[queryResult.status])

    
    
    useEffect(()=>{
       queryResult.remove();

    },[])
    const queryTotResult = useQuery([API.ivmTotIvInfos, query], () => getData(API.ivmTotIvInfos, query));
    useEffect(()=>{
        if(queryTotResult.isSuccess){
            console.log('queryTotResult',queryTotResult.data);
        }
        
    },[queryTotResult.status])
    const onChangePage = val => {
        setActivePage(val);
    };
    const onChangeLimit = val => {
        setLimit(val);
    };
    useEffect(()=>{
        onChangePage(1); // 페이지번호 리셋
    },[keyword]);

    // 필터
    const onFilterTextBoxChanged = useCallback((e) => {
        setFilterValue(e.target.value);
    }, []);

    // 검색창 열기/닫기 > 페이지네이션 여부에 따라 +-20px
    const gridExpand = () =>{
        setOpen(!open);
    }

    //-------------------// 필수 공통 ------------------------------

    const [openFileDownload, setOpenFileDownload] = useState(false);

    const listButton = () => {
        navigate('/printState',{ state: "" }); 
    }

    // 필터
    const hideEvent = () => {
        setOutRequestChange(false);
        setPrintCost(false);
        setPrintCostInputNo(false);
        setPrintArrayTablePop(false);
        queryResult.remove();
        queryResult.refetch();
    }

    const boardInfoEvent = () =>{
        navigate('../../../board/detail',{ state: '' }); 
    }
    //상세 페이지
    const handleDetail =(param)=>{
        const data ={
            dlExpdAltrNo : param
        }
        navigate('../../../clcm/detail',{ state: data }); 

    }
    const mdfyChange =()=>{
        let today = new Date();
        let dd = today.getDate();
        let mm = today.getMonth()+1;
        let yyyy = today.getFullYear();
        if(dd < 10){ dd = '0'+dd;}
        if(mm < 10){ mm = '0'+mm;}
        
        let date = yyyy+"-"+mm+"-"+dd;
        if(date > data.dlvgParrYmd){
            confirmAlert({
                closeOnClickOutside: false,
                customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}  title={"알림"} msg={'납품예정일이 오늘보다 이전이므로 변경할 수 없습니다.'}  />
            })
            
        }else{
            setOutRequestChange(true);
        }
    }

    const prntPageOpen =() =>{ 

        if(queryResult.data.prntPageYn==='Y'){
            setPrintArrayTablePop(true)
        }
        else{
            confirmAlert({
                closeOnClickOutside: false,
                customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}  title={"알림"} msg={'저장된 인쇄페이지가 없습니다.'}  />
            })
        }
    }

    const [outRequestChange, setOutRequestChange] = useState(false);
    const [printCost, setPrintCost] = useState(false);
    const [printCostInputNo, setPrintCostInputNo] = useState(false);
    const [printArrayTablePop, setPrintArrayTablePop] = useState(false);

    return (
        <>
            <div className="grid-wrap">
                <div className="grid-btn-wrap">
                    <div className="left-align">
                        <div className="sub-title">
                            <ul>
                                <li>발간실적 기준정보</li>
                            </ul>
                        </div>
                    </div>
                    <div className="right-align">
                    <Button variant="outline-dark btn-print" size="sm"onClick={() => window.print()}><FontAwesomeIcon icon={faPrint}/>{CONSTANTS.print}</Button>{' '}
                    </div>
                </div>
                {/*--------- Grid -----------*/}
                {queryTotResult &&<GridPrintOrderAdd 
                    filterValue={filterValue}
                    queryResult={queryTotResult}
                    limit={limit}
                    activePage={activePage}
                />}
               

                <div className="grid-btn-wrap mt-4">
                    <div className="left-align">
                        <div className="sub-title">
                            <ul>
                                <li>세부내역</li>
                            </ul>
                        </div>
                    </div>
                    <div className="right-align">
                        <Button variant="outline-secondary" size="sm" onClick={mdfyChange}>납품요청일 변경</Button>{' '}
                        <Button variant="outline-secondary" size="sm" onClick={prntPageOpen}>인쇄배열표</Button>{' '}
                    </div>
                </div>

               
                
                <Table className="tbl-hor" bordered>
                    <colgroup>
                        <col style={{width:'15%'}}></col>
                        <col style={{width:'15%'}}></col>
                        <col style={{width:''}}></col>
                        <col style={{width:'15%'}}></col>
                        <col style={{width:'15%'}}></col>
                        <col style={{width:'%'}}></col>
                    </colgroup>
                    <tbody>
                        <tr>
                            <th colSpan="2">차종</th>
                            <td>{data && data.qltyVehlCd}</td>
                            <th colSpan="2">언어</th>
                            <td>{data &&escapeCharChange( data.langCdNm)}</td>
                        </tr>
                        <tr>
                            <th colSpan="2">인쇄부수</th>
                            <td>{data && data.rqQty}</td>
                            <th rowSpan="4">인쇄페이지</th>
                            <th>총 페이지</th>
                            <td>{data && data.pgNl}</td>
                        </tr>
                        <tr>
                            <th rowSpan="2">납품</th>
                            <th>납품일</th>
                            <td>{data && data.dlvgParrYmd}</td>
                            <th>표지</th>
                            <td>{data && data.prntWayCd2=='04' || data &&data.prntWayCd2=='05' || data &&data.prntWayCd2=='06' || data &&data.prntWayCd2=='07'?  "0" : "4"}</td>
                        </tr>
                        <tr>
                            <th>납품장소</th>
                            <td>{data && data.dlExpdPrvsNm}</td>
                            <th>설명서</th>
                            <td>{data && data.expdNl}</td>
                        </tr>
                        <tr>
                            <th rowSpan="2">발간번호</th>
                            <th>신규번호</th>
                            <td>{data && data.newPrntPbcnNo}</td>
                            <th>보증서/엽서</th>
                            <td>{data && data.grnDocNl}</td>
                        </tr>
                        <tr>
                            <th>기존번호</th>
                            <td>{data && data.oldPrntPbcnNo}</td>
                            <th rowSpan="2">옵셋(내지)</th>
                            <th>기존필름이용</th>
                            <td>{data && data.prntWayCd2=='01' || data &&data.prntWayCd2=='02' || data &&data.prntWayCd2=='08'? 
                             (data && data.eofu1Nl==null? 0:data.eofu1Nl) : "0"}</td>
                        </tr>
                        <tr>
                            <th colSpan="2">발행방법</th>
                            <td>{data && data.iwayNm}</td>
                            <th>신규필름제작(교정포함)</th>
                            <td>{data && data.prntWayCd2=='01' || data &&data.prntWayCd2=='02' || data &&data.prntWayCd2=='08'?data && data.nrFlmMkoNl:'0' }</td>
                        </tr>
                        <tr>
                            <th colSpan="2">제본</th>
                            <td>{data && data.prntWayCd2=='04' || data &&data.prntWayCd2=='05' || data &&data.prntWayCd2=='06' || data &&data.prntWayCd2=='07'?  "" : "무선제본"}</td>
                            <th>디지털(내지)</th>
                            <th>디지털 인쇄</th>
                            <td>{data && data.prntWayCd2=='01' || data &&data.prntWayCd2=='02' || data &&data.prntWayCd2=='08'?'0':data &&data.nrFlmMkoNl }</td>
                        </tr>
                        <tr>
                            <th colSpan="2">규격</th>
                            <td>{data && escapeCharChange(data.pgMgnSbc)}</td>
                            
                            <th colSpan="2">외주편집페이지</th>
                            <td>{data && data.oordEditPgNl}</td>
                        </tr>
                        <tr>
                            <th rowSpan="2">지질</th>
                            <th>표지</th>
                            <td>{data && data.prntWayCd2=='04' || data &&data.prntWayCd2=='05' || data &&data.prntWayCd2=='06' || data &&data.prntWayCd2=='07'?   "" : "250아트"}</td>
                            <th colSpan="2">외주편집업체</th>
                            <td>{data && data.oordEditCoCd=="01"? "TLA"
                                :data && data.oordEditCoCd=="02"? "AST"
                                :data && data.oordEditCoCd=="03"? "FEEL"
                                :data && data.oordEditCoCd=="04"? "TEXTREE":"없음"}</td>
                        </tr>
                        <tr>
                            <th>내지</th>
                            <td>{data && data.deipq1Sbc=='01'? "80화인코드지":"70모조지"}</td>
                            <th colSpan="2">커버수량</th>
                            <td>{data && data.depc1Yn=='Y'? data&& data.depc1Qty:'0'}</td>
                        </tr>
                        <tr>
                            <th rowSpan="2">인쇄</th>
                            <th>표지</th>
                            <td>{data && data.prntWayCd2=='04' || data &&data.prntWayCd2=='05' || data &&data.prntWayCd2=='06' || data &&data.prntWayCd2=='07'?   "" : "옵셋"}</td>
                            <th colSpan="2">비고</th>
                            <td>{data && data.rem}</td>
                        </tr>
                        <tr>
                            <th>내지</th>
                            <td>{data && data.prntWayCd2=="01"||data && data.prntWayCd2=="02"||data && data.prntWayCd2=="08"? "옵셋"
                                :data && data.prntWayCd2=="03"? "디지털"
                                :data && data.prntWayCd2=="04"||data && data.prntWayCd2=="05"? "스티커"
                                :data && data.prntWayCd2=="06"||data && data.prntWayCd2=="07"? "리플렛":""}</td>
                            <th colSpan="2">표지코팅</th>
                            <td>무광코팅</td>
                        </tr>
                        <tr>
                            <th rowSpan="2">인쇄도수</th>
                            <th>표지</th>
                            <td>{data && data.prntWayCd!=''?
                                
                            data && data.prntWayCd2=='04' || data &&data.prntWayCd2=='05' || data &&data.prntWayCd2=='06' || data &&data.prntWayCd2=='07'?   "" 
                            : data && data.prntWayCd=="01"?"없음"
                            : data && data.prntWayCd=="02"?"1"
                            : data && data.prntWayCd=="03"?"2"
                            : data && data.prntWayCd=="04"?"3"
                            : data && data.prntWayCd=="05"?"4"
                            : data && data.prntWayCd=="06"?"5":""
                            :data&& data.cPrntCvrSbc}</td>
                            <th colSpan="2">게시판 관리번호</th>
                            <td>
                            <ButtonBoot variant="link" onClick={() => boardInfoEvent()} style={{padding:0}}>  {data && data.blcSn}  </ButtonBoot>
                            </td>
                        </tr>
                        <tr>
                            <th>내지</th>
                            <td>{data && data.prntWayCd2=="01"||data && data.prntWayCd2=="03"||data && data.prntWayCd2=="04"||data && data.prntWayCd2=="06"? "1"
                                :data && data.prntWayCd2=="02"||data && data.prntWayCd2=="05"||data && data.prntWayCd2=="07"? "2"
                                :data && data.prntWayCd2=="08"?"4":data && data.cPrntInsdPgSbc}</td>
                            <th colSpan="2"></th>
                            <td></td>
                        </tr>
                        <tr>
                            <th colSpan="2">메모</th>
                            <td colSpan="4">{data && escapeCharChange(escapeCharChange(data.prtlImtrSbc))}</td>
                        </tr>
                        <tr>
                            <th colSpan="2">발주자</th>
                            <td>{data && data.crgrNm}</td>
                            <th colSpan="2">발주일</th>
                            <td>{data && data.ordnRqstYmd}</td>
                        </tr>
                    </tbody>
                </Table>

                <div className="grid-btn-wrap mt-4">
                    <div className="left-align">
                        <div className="sub-title">
                            <ul>
                                <li>인쇄비용</li>
                            </ul>
                        </div>
                    </div>
                    <div className="right-align">
                        <Button variant="outline-secondary" size="sm" onClick={() => setPrintCost(true)}>인쇄비 입력</Button>{' '}
                        <Button variant="outline-secondary" size="sm" onClick={() => setPrintCostInputNo(true)}>인쇄비 품의번호 입력</Button>{' '}
                    </div>
                </div>
                <Table className="tbl-ver" bordered>
                    <colgroup>
                        <col style={{width:'25%'}}></col>
                        <col style={{width:'25%'}}></col>
                        <col style={{width:'25%'}}></col>
                        <col style={{width:'25%'}}></col>
                    </colgroup>
                    <thead>
                        <tr>
                            <th>평균단가</th>
                            <th>소요예산</th>
                            <th>견적서</th>
                            <th>인쇄비 품의번호</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                        
                            <td>{data && Math.floor(data.saleUnp).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")}</td>
                            <td>{data && Math.floor(data.prntParrBgt).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")}</td>
                            <td>{files && files.length > 0 && <Link onClick={()=>setOpenFileDownload(true)}><AttachmentIcon style={{fontSize:'14px'}} /></Link>}</td>
                            <td>{data && data.prtlImtrSbc3}</td>
                        </tr>
                    </tbody>
                </Table>


                <div className="grid-btn-wrap mt-4">
                    <div className="left-align">
                        <div className="sub-title">
                            <ul>
                                <li>개정내용</li>
                            </ul>
                        </div>
                    </div>
                </div>
                <Table className="tbl-ver" bordered>
                    <colgroup>
                        <col style={{width:'33%'}}></col>
                        <col style={{width:'33%'}}></col>
                        <col style={{width:'33%'}}></col>
                    </colgroup>
                    <thead>
                        <tr>
                            <th>등록번호</th>
                            <th>제목</th>
                            {/* <th>개정내용</th> */}
                            <th>첨부</th>
                        </tr>
                    </thead>
                    <tbody>
                        {reversionList && reversionList.map((item,index)=>(
                       <tr key = {index}>
                            <td>{item.dlExpdAltrNo}</td>
                            <td><ButtonBoot variant="link" onClick={()=>handleDetail(item.dlExpdAltrNo)}> {item.altrTitl}   </ButtonBoot></td>
                            <td></td>
                        </tr>
                        ))}
                    </tbody>
                </Table>

                <div className="btn-wrap">
                    <div className="left-align">
                        <Button variant="light" onClick={listButton}>목록</Button>{' '}
                    </div>
                </div>
            </div>

            {outRequestChange && <OutRequestChange data ={test} show={outRequestChange} onHide={hideEvent}  />}
            {printArrayTablePop && <PrintArrayTable  show={printArrayTablePop} onHide={hideEvent} param = {query} readOnly={true}  />}
            {printCost && <PrintCost data ={test} files={files}  show={printCost} onHide={hideEvent}  />}
            {printCostInputNo && <PrintCostInputNo data ={test} show={printCostInputNo} onHide={hideEvent}  />}
            
            {openFileDownload && <FileControl mode={'V'} keyValue={data.newPrntPbcnNo} gubun={'P'} onHide={()=>setOpenFileDownload(false) } />}
        </>
    )
};
export default PrintStateDetail;