// react
import React, {useState, useEffect, useCallback, useRef} from 'react';
import { Button, Collapse} from 'react-bootstrap';
import {Grid, Row,Form, Col ,Input, SelectPicker} from 'rsuite';
import SearchIcon from '@rsuite/icons/Search';
import { useNavigate} from 'react-router-dom';
import { escapeCharChange } from '../../../../utils/commUtils';
//--------------  서버데이터용 필수 -------------------------------
import { useQuery} from 'react-query';
import { API,CONSTANTS } from '../../../../utils/constants';
import useStore from '../../../../utils/store';
import VehlType from '../../../Search/VehlType';
// import LangMulti from '../../../Search/LangMulti';
import IWayCdCombo from '../../../Search/IWayCdCombo';
import Lang from '../../../Search/Lang';
import SeDate from '../../../Search/SeDate';
//--------------// 서버데이터용 필수 -------------------------------
import { utcToLocalDate } from '../../../../utils/commUtils';
import { getData,postData } from '../../../../utils/async';
import GridPrintStateList from '../_Grid/GridPrintStateList';
import Paging from '../../../Common/Paging';
import { CustomInputGroup } from '../../../Common/CustomInputGroup';
import {ArrowDownLine, ArrowUpLine} from '@rsuite/icons';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faFileExcel,faPrint } from '@fortawesome/free-solid-svg-icons'
import { excelDownload as excelDownloadAggrid } from '../../../../utils/excelForAggrid';

const PrintStateList = () => {

    //------------------- 필수 공통 ------------------------------
    const [open, setOpen] = useState(true); // 조건창 열기/닫기
    const {keyword } = useStore();  // 조회키워드 가져오기
    const gridRef = useRef();
    // const [langCds, setLangCds] = useState({});
    const [activePage, setActivePage] = useState(1);    // 페이지번호
    const [iWayCd, setIwayCd] = useState({});    
    const [pbncNo, setPbncNo] = useState({});    
    const [limit, setLimit] = useState(50);             // 페이지행수
    const [filterValue, setFilterValue] = useState(''); // 필터값
    const [printStatus, setPrintStatus] = useState(false);
    const navigate = useNavigate();
    const onChangePage = val => {
        setActivePage(val);
    };
    const onChangeLimit = val => {
        setLimit(val);
    };
    useEffect(()=>{
        onChangePage(1); // 페이지번호 리셋
    },[keyword]);

    // 필터
    const onFilterTextBoxChanged = useCallback((e) => {
        setFilterValue(e.target.value);
    }, []);

    // 검색창 열기/닫기 > 페이지네이션 여부에 따라 +-20px
    const [gridHeight, setGridHeight] = useState(575);
    const gridExpand = () =>{
        setOpen(!open);
        if(open){
            setTimeout(() => setGridHeight(650), 250);
        }else{
            setGridHeight(575)
        }
    }

    const [excelStatus, setExcelStatus] = useState(false);
    useEffect(() => {
        if(excelStatus) {
            setTimeout(() =>setExcelStatus(excelDownloadAggrid(gridRef, '발간현황', 2)), 1000)
        }
    }, [excelStatus])

   

    //-------------------// 필수 공통 ------------------------------
    //발행구분
    const iwayCdParam = {dlExpdGCd: CONSTANTS.grpCdIway};
    const iWayCdCombo = useQuery([API.codeCombo,iwayCdParam], () => getData(API.codeCombo,iwayCdParam)) 
   
    const param = {
        
        dlExpdPdiCd: keyword.dlExpdPdiCd=='ALL'?"":keyword.dlExpdPdiCd,
        qltyVehlCd: keyword.qltyVehlCd=='ALL'?"":keyword.qltyVehlCd,
        mdlMdyCd: keyword.mdlMdyCd=='ALL'?"":keyword.mdlMdyCd,
        sDate: keyword.sDate,
        eDate: keyword.eDate,
        dlExpdRegnCd: keyword.dlExpdRegnCd=='ALL'?"":keyword.dlExpdRegnCd,
        langCd:keyword.langCd=='ALL'?"":keyword.langCd,
        subCd: keyword.subCd,
        iWayCd: iWayCd,
        newPrntPbcnNo : pbncNo,


    }
    const queryResult = useQuery([API.printStates, param], () => getData(API.printStates, param));

    // 셀 클릭
    const onCellClicked = e => {
        if(e.column.colId === 'newPrntPbcnNo'){
            detailButton(e.data)
        }
    };
    const onChangeIwayCombo = val => {
        setIwayCd(val);
    };
    const onChangePbcnNo = val => {
        setPbncNo(val);

    };

   
    
    const detailButton = (data) => {
        let param = {
            newPrntPbcnNo: data.newPrntPbcnNo,
            qltyVehlCd : data.qltyVehlCd,
            mdlMdyCd : data.mdlMdyCd,
            langCd : data.langCd,
            dlExpdPdiCd: data.dlExpdPdiCd,
            subCd: 'ALL',
            dlExpdRegnCd: data.dlExpdRegnCd,
            bDate: utcToLocalDate(new Date()),
        }
        
        navigate('/printState/detail',{ state: param }); 
    }

    // 조회버튼
    const onSearch = () => {
        queryResult.refetch(); // 수동쿼리실행
    };

    const handlePrint=()  =>{
        
    }
  
    return (
        <>
         
            <div className="search-area">
                <Collapse in={open}>
                    <div className="form" id="example-collapse-text">
                        <div className="search-group">
                            <div className="row">
                            <Grid fluid>
                                <Row className="show-grid">
                                <Col sm={5} className=""> 
                                    <SeDate />
                                </Col>
                                <Col sm={7} className="" >
                                    <VehlType  />
                                </Col>
                                <Col sm={6} className="" >
                                    <Lang  />
                                </Col>
                                <Col sm={2} className="" >
                                    <IWayCdCombo  />
                                </Col>
                                <Col sm={3} className="" >
                                    <Form.ControlLabel column="sm" >발간번호</Form.ControlLabel>
                                    <Input size="sm" type="text" onChange={onChangePbcnNo} />
                                </Col>
                                </Row>
                            </Grid>
                            </div>

                            <div className="search-btn-wrap">
                                <Button className="btn-search" variant="outline-primary" size="sm" onClick={onSearch}><SearchIcon />조회</Button>
                            </div>
                        </div>
                    </div>
                </Collapse>
                <Button size="sm" variant="outline-dark" className="search-control" aria-controls="example-collapse-text" 
                    aria-expanded={open} onClick={gridExpand}>
                    {/* <span className={open === true ? "search-area-close" : "search-area-open"}>{open === true ? CONSTANTS.closeSearch : CONSTANTS.openSearch}</span> */}
                    {open ? <span className="search-area-close"><ArrowUpLine style={{marginRight: '5px', fontSize: '2em'}} />{CONSTANTS.closeSearch}</span> :
                    <span className="search-area-open"><ArrowDownLine style={{marginRight: '5px', fontSize: '2em'}} />{CONSTANTS.openSearch}</span>}
                </Button>
            </div>
            
            <div className="grid-wrap">
                <div className="grid-btn-wrap">
                    <div className="left-align">
                        {/*--------- 필터 -----------*/}
                        <CustomInputGroup size="sm"   onInput={onFilterTextBoxChanged} />
                    </div>
                    <div className="right-align">
                        {/*--------- 버튼 -----------*/}
                        <Button variant="outline-success btn-excel" size="sm" disabled={excelStatus} onClick={() => setExcelStatus(true)}>
                            <FontAwesomeIcon icon={faFileExcel}/>
                            {CONSTANTS.excelDownload}
                        </Button>{' '}
                        <Button variant="outline-dark btn-print" size="sm" onClick={() => handlePrint()}><FontAwesomeIcon icon={faPrint}/>{CONSTANTS.print}</Button>{' '}
                    </div>
                </div>
                {/*--------- Grid -----------*/}
              <GridPrintStateList 
                    gridRef = {gridRef}
                    gridHeight={gridHeight}
                    filterValue={filterValue}
                    queryResult={queryResult}
                    limit={limit}
                    activePage={activePage}
                    onCellClicked={onCellClicked}
                    />
               

                {/*--------- 페이징 -----------*/}
                <Paging 
                    total={queryResult && queryResult.data && queryResult.data.length}
                    limit={limit}
                    activePage={activePage}
                    onChangePage={onChangePage}
                    onChangeLimit={onChangeLimit}
                />
            </div>
        </>
    )
};
export default PrintStateList;