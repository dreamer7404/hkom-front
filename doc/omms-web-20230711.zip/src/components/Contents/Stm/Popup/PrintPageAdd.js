import React, {useEffect, useMemo, useRef,useState} from 'react';
import {Button, Modal, Table, Row, Col} from 'react-bootstrap';
import { InputGroup, Form, SelectPicker, Schema, TagGroup,Tag,DatePicker } from 'rsuite';
import { getData,postData } from '../../../../utils/async';
import { useQuery,useMutation} from 'react-query';
import { escapeCharChange} from '../../../../utils/commUtils';
import { API,CONSTANTS} from '../../../../utils/constants';
import { confirmAlert } from 'react-confirm-alert'; // Import
import ConfirmAlert from '../../../Common/ConfirmAlert';
import CustomModal from '../../../Common/CustomModal';
const { StringType} = Schema.Types;

const model = Schema.Model({
    qltyVehlCd: StringType().isRequired('차종을 선택해주세요'),
    mdlMdyCd : StringType().isRequired('연식을 선택해주세요'),
    dlExpdRegnCd : StringType().isRequired('지역을 선택해주세요'),
    langCd : StringType().isRequired('언어를 선택해주세요'),
    newPrntPbcnNo :  StringType().isRequired('발간번호를 작성해주세요')
    .pattern(/[A-Z0-9]{4}-[A-Z0-9]{5}/, '형식에 맞게 입력해주세요 ex) AAAA-AB12C'),
    // lrnkCd : StringType().pattern(/[0-9]{2}/, '숫자만입력해주세요'),
});
let pageArr = [];
const PrintPageAdd = ({show, onHide}) => {
    const containerRef = useRef();
    
    const formRef = React.useRef();
    const [dlExpdRegnCd, setDlExpdRegnCd] = useState();
    
    const [formError, setFormError] = React.useState({});
    const [htmlLength, setHtmlLength] = useState([1]);
    const [formValue, setFormValue] = React.useState({
        qltyVehlCd : '',
        mdlMdyCd : '',
        dlExpdRegnCd: '',
        langCd : '',
        newPrntPbcnNo : '',
        lrnkCd : '',
        rgstYmd : '',
        pageArr  :[],
    }); 

    const vehlCombo = useQuery([API.vehlCombo, {}], () => getData(API.vehlCombo, {}), {
        select: data =>  data.map((item) => ({ label: escapeCharChange(item.qltyVehlNm), value: item.qltyVehlCd }))
        }); 
    const mdyCombo = useQuery([API.mdyCombo], () => getData(API.mdyCombo), {
        select: data => data.map((item) => ({ label: item, value: item }))
    });
    const paramsCo = {dlExpdGCd: CONSTANTS.grpCdRegn};
    
    const regnCombo = useQuery([API.codeCombo,paramsCo], () => getData(API.codeCombo,paramsCo)) 


    const langParam = {dlExpdRegnCd: dlExpdRegnCd};
    const langCombo = useQuery([API.langCombo, langParam], () => getData(API.langCombo, langParam), {
        select: data => data.map((item) => ({ label: escapeCharChange(item.langCdNm), value: item.langCd }))
    }); 
    const onChangeRegnCombo = val =>{
        setDlExpdRegnCd(val);
    }

    const addHtml = () => {
        setHtmlLength(htmlLength.concat(1));
    };

    const delHtml = () => {
        const test = [...htmlLength];
        test.pop();
        setHtmlLength(test);
        
    };


    const handleSubmit = () => {
        if (!formRef.current.check()) { //validation chk
            return;
        }
        
        confirmAlert({
            closeOnClickOutside: false,
            customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}   title={"알림"}
            msg={"입력하신 내용으로 저장하시겠습니까?"} 
            
            onOk={onOk}  />
            
        });
        
    };
    const prntPageSave = useMutation((params => postData(API.prntPageMgmt, params, CONSTANTS.insert)),{
        onSuccess: res => {
           if(res>0){
                confirmAlert({
                    closeOnClickOutside: false,
                    customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}   title={"알림"}
                    msg={"저장이 완료되었습니다."}   />
                    
                });
           }else if(res==-1){
                confirmAlert({
                    closeOnClickOutside: false,
                    customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}   title={"알림"}
                    msg={"중복된 발간번호가 있습니다."}   />
                    
                });
           }else{
                confirmAlert({
                    closeOnClickOutside: false,
                    customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}   title={"알림"}
                    msg={"에러가 발생했습니다 관리자에게 문의해주세요."}   />
                    
                });
           }
           onHide();
        }
    });

    const dateChangeEvent = (e) =>{
       setFormValue(p=>({...p,rgstYmd : e}))
    }


    const onOk = () => {
        
        prntPageSave.mutate(formValue);
    }


    const onChangeEvent=(value,idx)=>{
 
        console.log(idx,value);
        pageArr[idx]={endPgSn : value};
        console.log("여기",pageArr);
        setFormValue(p => ({...p, pageArr: pageArr}));
    }



    return (
        <>
         
             <Form
                ref={formRef}
                checkTrigger="change"
                onChange={setFormValue}
                onCheck={setFormError}
                formValue={formValue}
                model={model}>

                        <CustomModal open={show}  title={'인쇄페이지 등록'}
                        size='lg'
                        // handleOk={handleSubmit}
                        handleCancel={onHide} 
                        >
                            <Table className="tbl-hor" bordered>
                                <colgroup>
                                    <col style={{width:'15%'}}></col>
                                    <col style={{width:'35%'}}></col>
                                    <col style={{width:'15%'}}></col>
                                    <col style={{width:'35%'}}></col>
                                </colgroup>
                                <tbody>
                                    <tr>
                                        <th className="essen">차종</th>
                                        <td>
                                            <Row className="select-wrap">
                                                <Col sm={8}>
                                                    <Form.Control container={()=> containerRef.current}  name="qltyVehlCd" size="sm" style={{zIndex: 0}} 
                                                            placeholder={'선택'}
                                                            defaultValue={''}
                                                            accepter={SelectPicker} 
                                                            searchable={false}
                                                            cleanable={false}
                                                            data={vehlCombo && vehlCombo.data ? vehlCombo.data : []}  
                                                    ></Form.Control>
                                                </Col>
                                                <Col sm={4}>
                                                    <Form.Control container={()=> containerRef.current}  name="mdlMdyCd" size="sm" style={{zIndex: 0}} 
                                                            placeholder={'선택'}
                                                            defaultValue={''}
                                                            accepter={SelectPicker} 
                                                            searchable={false}
                                                            cleanable={false}
                                                            data={mdyCombo && mdyCombo.data ? mdyCombo.data : []}  
                                                    ></Form.Control>
                                                </Col>
                                            </Row>
                                        </td>
                                        <th className="essen">언어</th>
                                        <td>
                                            <Row className="select-wrap">
                                                <Col sm={4}>
                                                {regnCombo.isSuccess &&
                                                    <Form.Control container={()=> containerRef.current}  name="dlExpdRegnCd" size="sm" style={{zIndex: 0}} 
                                                        value={dlExpdRegnCd}
                                                        placeholder={'선택'}
                                                        defaultValue={''}
                                                        accepter={SelectPicker} 
                                                        searchable={false}
                                                        cleanable={false}
                                                        data={regnCombo.isFetched && regnCombo.data}
                                                        onChange={onChangeRegnCombo}
                                                    ></Form.Control>
                                                }
                                                </Col>
                                                <Col sm={8}>
                                                    <Form.Control container={()=> containerRef.current}  name="langCd" size="sm" style={{zIndex: 0}} 
                                                        
                                                        placeholder={'선택'}
                                                        defaultValue={''}
                                                        accepter={SelectPicker} 
                                                        searchable={false}
                                                        cleanable={false}
                                                        data={langCombo && langCombo.data ? langCombo.data : []}  
                                                        
                                                    ></Form.Control>
                                                </Col>
                                            </Row>
                                        </td>
                                    </tr>
                                    <tr>
                                        <th className="essen">발간번호</th>
                                        <td>
                                            <Row className="select-wrap">
                                                <Col sm={8}>
                                                    <Form.Control name="newPrntPbcnNo" size="sm" type="text"/> 
                                                </Col>
                                                <Col sm={4}>
                                                    <Form.Control name="lrnkCd" size="sm" type="text"/> 
                                                </Col>
                                            </Row>
                                        </td>
                                        <th>등록일</th>
                                        <td>
                                            
                                            <DatePicker oneTap block size="sm"
                                                cleanable={false}
                                                searchable="true"
                                                name='rgstYmd'
                                                defaultValue={new Date()}
                                                ranges={[
                                                    {
                                                        label: '오늘',
                                                        value: new Date()
                                                    }
                                                ]}
                                                onChange={dateChangeEvent}
                                            />
                                        </td>
                                    </tr>
                                    <tr>
                                        <th className="essen">마지막페이지 구분</th>
                                        <td colSpan="3">
                                            <div className="grid-btn-wrap" style={{marginBottom:'5px'}}>
                                                <div className="right-align">
                                                    {/*--------- 버튼 -----------*/}
                                                    <Button variant="outline-secondary" size="sm" onClick={addHtml}>추가</Button>{' '}
                                                    <Button variant="outline-secondary" size="sm" onClick={delHtml}>삭제</Button>{' '}
                                                </div>
                                            </div>
                                            <div className="print-page-set">
                                                <Row className="select-wrap">
                                                    <Col sm={1}>서문1</Col>
                                                    <Col sm={2}><Form.Control size="sm" name="a01" type="text"defaultValue='0'/></Col>
                                                    <Col sm={1}>서문2</Col>
                                                    <Col sm={2}><Form.Control size="sm" name="a02" type="text"defaultValue='0'/></Col>
                                                    <Col sm={1}>서문3</Col>
                                                    <Col sm={2}><Form.Control size="sm" name="a03" type="text"defaultValue='0'/></Col>
                                                    {htmlLength.map((data,idx)=>
                                                    <>
                                                    <Col sm={1} key={idx+1}>{idx+1}장</Col>
                                                    <Col sm={2}><Form.Control size="sm" name={"endPgSn"+idx} type="text"  key={idx} defaultValue='0'onChange={(e)=>onChangeEvent(e,idx)} /></Col></>
                                                                                                            
                                                    )}
                                                    
                                                    <Col sm={1} >색인</Col>
                                                    <Col sm={2}><Form.Control size="sm" name="endPgSnE" defaultValue='0' type="text"/></Col>
                                                </Row>
                                            </div>
                                                
                                        </td>
                                    </tr>
                                </tbody>
                            </Table>

                            <div className='modal-footer'>
                                <Button variant="light" size="md" onClick={onHide}>취소</Button>
                                <Button variant="primary" size="md" onClick={handleSubmit} >저장</Button>
                            </div>
                            </CustomModal>
                       
            </Form>

        </>
    );

};
export default PrintPageAdd;