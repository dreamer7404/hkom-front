import React, {useEffect, useMemo, useRef} from 'react';
import { AgGridReact } from 'ag-grid-react';
import { CONSTANTS } from '../../../../utils/constants';

const GridShipInfo = ({gridRef, gridHeight, filterValue, queryResult, limit, activePage, onCellClicked}) => {

  

  const columnDefs = [
        {
            headerName: 'V.I.N',
            field: 'vin',
            cellStyle: () => ({textDecoration: 'underline', cursor: 'pointer', color:'#2589f5'}),
            minWidth:'150'
        },
        {
            headerName: '모델코드',
            field: 'mdlCd',
        },
        {
          headerName: 'Body No.',
          field: 'shipDt3',
        },
        {
          headerName: '국가코드',
          field: 'shipDt4',
        },
        {
          headerName: '목적국',
          field: 'shipDt5',
        },  
        {
          headerName: '국가명',
          field: 'shipDt6',
        },  
        {
          headerName: 'PDI/IN',
          field: 'shipDt7',
        },  
        {
          headerName: 'PDI/OUT',
          field: 'shipDt8',
        },  
        {
          headerName: 'MP/IN',
          field: 'shipDt9',
        },  
        {
          headerName: 'MP/OUT',
          field: 'shipDt10',
        },  
        {
          headerName: 'PORT IN',
          field: 'shipDt11',
        }
    ]

    const defaultColDef = useMemo(() => {
        return {
            initialWidth: 90,
            sortable: true,
            resizable:true,
            minWidth:70
        };
    }, []);

  const onFirstDataRendered = (params) => {
      params.api.sizeColumnsToFit();
  };

  useEffect(()=>{
    if(queryResult.status === 'loading' && gridRef && gridRef.current && gridRef.current.api){
        gridRef.current.api.showLoadingOverlay();
    }
  },[queryResult]);

  useEffect(()=> {
    if(gridRef && gridRef.current && gridRef.current.api){
      gridRef.current.api.setQuickFilter(filterValue);
    }
  },[filterValue]);

  useEffect(()=> {
    if(gridRef && gridRef.current && gridRef.current.api){
      gridRef.current.api.paginationGoToPage(activePage-1);
    }
  },[activePage]);


  return(
      <div className="ag-theme-alpine" style={{height: gridHeight, transition:'all ease .3s'}}>
        <AgGridReact
            ref={gridRef} 
            rowData={queryResult && queryResult.data} 
            columnDefs={columnDefs}
            defaultColDef={defaultColDef}

            // paging
            pagination={true}
            paginationPageSize={limit} //
            suppressPaginationPanel={true} 
            // onPaginationChanged={onPaginationChanged}

            //  filter
            cacheQuickFilter={true}

             // click column
              onCellClicked={onCellClicked} //

            // overlay
            overlayLoadingTemplate={CONSTANTS.gridLoading}
            overlayNoRowsTemplate={CONSTANTS.gridNoRows}

            onFirstDataRendered={onFirstDataRendered}
            suppressSizeToFit={true}    
            onGridSizeChanged={onFirstDataRendered}    
            >
        </AgGridReact>
    </div>
  )


};
export default GridShipInfo;