import React, {useEffect, useMemo, useRef, useCallback} from 'react';
import { AgGridReact } from 'ag-grid-react';
import { CONSTANTS } from '../../../../utils/constants';
import { formatNumber, escapeCharChangeForGrid } from '../../../../utils/commUtils';

const GridRequestState = ({gridHeight, filterValue, queryResult, limit, activePage, checkRow, gridRef}) => {

  // 수량 천단위 콤마 찍기 시작
  const currencyFormatter = (params) => {
    return formatNumber(params.value);
  };

  const columnDefs = [
        {
          checkboxSelection: true,
          headerCheckboxSelection: true,
          spanHeaderHeight: true,
          width:35,
          maxWidth:35,
          minWidth:35,
        },
        {
          headerName: '차종코드',
          field: 'qltyVehlCd',
          spanHeaderHeight: true,
          minWidth:70
        },  
        {
          headerName: '품번',
          field: 'langCdNm',
          spanHeaderHeight: true,
          valueGetter: (params) => {
            return '(' + params.data.langCd + ')' + params.data.langCdNm
          }
        },  
        {
          headerName: '품명',
          field: 'mtrlCd',
          spanHeaderHeight: true
        },  
        {
          headerName: '차량재고\n(오전09시 기준)',
          field: 'vehlStock',
          spanHeaderHeight: true,
          valueFormatter: currencyFormatter
        }, 
        {
          headerName: '당월투입\n(누적)',
          field: 'currMthTrwiQty',
          spanHeaderHeight: true,
          valueFormatter: currencyFormatter
        }, 
        {
          headerName: '용산(계)',
          children: [
            { headerName:'합계', field: 'stockSum', valueFormatter: currencyFormatter},
            { headerName:'이동중재고', field: 'stockOnMove', valueFormatter: currencyFormatter},
            { headerName:'원올단품', field: 'stockOneAllItem', valueFormatter: currencyFormatter },
            { headerName:'원올KIT', field: 'stockOneAllKit', valueFormatter: currencyFormatter },
            { headerName:'지역재고', field: 'stockOnLocal', valueFormatter: currencyFormatter },
          ],
        },
        {
          headerName: '출고대수\n(3일평균)',
          field: 'deliverVehlCnt',
          spanHeaderHeight: true,
          valueFormatter: currencyFormatter
        }, 
        {
          headerName: '대응일수',
          field: 'responseDays',
          spanHeaderHeight: true,
          valueFormatter: currencyFormatter
        }, 
        {
          headerName: '발주',
          field: 'orderAmount',
          spanHeaderHeight: true,
          valueFormatter: currencyFormatter
        }, 
        {
          headerName: '입고잔량',
          field: 'restAmount',
          spanHeaderHeight: true,
          valueFormatter: currencyFormatter
        }, 
    ]

  const defaultColDef = useMemo(() => {
      return {
          initialWidth: 90,
          sortable: true,
          resizable:true,
          minWidth:70
      };
  }, []);

  const onFirstDataRendered = (params) => {
      params.api.sizeColumnsToFit();
  };

  useEffect(()=>{
    if(queryResult.status === 'loading' && gridRef && gridRef.current && gridRef.current.api){
        gridRef.current.api.showLoadingOverlay();
    }
  },[queryResult]);

  useEffect(()=> {
    if(gridRef && gridRef.current && gridRef.current.api){
      gridRef.current.api.setQuickFilter(filterValue);
    }
  },[filterValue]);

  useEffect(()=> {
    if(gridRef && gridRef.current && gridRef.current.api){
      gridRef.current.api.paginationGoToPage(activePage-1);
    }
  },[activePage]);

  const onSelectionChanged = useCallback(() => {
    const selectedRows = gridRef.current.api.getSelectedRows();
    checkRow(selectedRows)
  }, []);

  return(
      <div className="ag-theme-alpine" style={{height: gridHeight, transition:'all ease .3s'}}>
        <AgGridReact
            ref={gridRef} 
            rowData={queryResult && queryResult.data} 
            columnDefs={columnDefs}
            defaultColDef={defaultColDef}

            // paging
            pagination={true}
            paginationPageSize={limit} //
            suppressPaginationPanel={true} 
            // onPaginationChanged={onPaginationChanged}

            //  filter
            cacheQuickFilter={true}

            // multi select
            rowSelection={'multiple'}
            suppressRowClickSelection= {true}

            // checkedRowDatas by Woong
            onSelectionChanged={onSelectionChanged}

            // overlay
            overlayLoadingTemplate={CONSTANTS.gridLoading}
            overlayNoRowsTemplate={CONSTANTS.gridNoRows}

            onFirstDataRendered={onFirstDataRendered}
            suppressSizeToFit={true}    
            onGridSizeChanged={onFirstDataRendered}    
            >
        </AgGridReact>
    </div>
  )


};
export default GridRequestState;