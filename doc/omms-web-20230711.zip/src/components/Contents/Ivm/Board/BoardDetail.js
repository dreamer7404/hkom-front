// react
import React, {useState, useMemo, useEffect} from 'react';
import { useLocation } from "react-router";
import { AgGridReact } from 'ag-grid-react';

import {Form, Button, Table, Row, Col} from 'react-bootstrap';
import { useNavigate } from 'react-router-dom';

//--------------  서버데이터용 필수 -------------------------------
import { useQuery, useQueryClient, useMutation} from 'react-query';
import { getData, postData } from '../../../../utils/async';
import { API, CONSTANTS } from '../../../../utils/constants';
import useStore from '../../../../utils/store';
//--------------// 서버데이터용 필수 -------------------------------
import { confirmAlert } from 'react-confirm-alert'; 
import ConfirmAlert from   '../../../Common/ConfirmAlert'; 
import moment from 'moment';

import { DEXT5Editor } from 'dext5editor-react';
import { DEXT5Upload } from 'dext5upload-react';

import {unescapeHtml, escapeCharChange, convertYmd} from '../../../../utils/commUtils';

import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faPenToSquare,faTrashCan } from '@fortawesome/free-solid-svg-icons'

const BoardDetail = () => {

    const navigate = useNavigate();


    const { state } = useLocation();
    const [data, setData] = useState(null)
    const [files, setFiles] = useState(null)
    const [users, setUsers] = useState(null)
    const [vehls, setVehls] = useState(null)
    const [replyData, setReplyData] = useState([])

    // 게시판 목록
    const queryParam = {blcSn: state};
    const queryResult = useQuery([API.boardAffrMgmt, queryParam], () => getData(API.boardAffrMgmt, queryParam));

    // 게시판댓글 목록
    const queryReplyResult = useQuery([API.boardAffrMgmtReplys, queryParam], () => getData(API.boardAffrMgmtReplys, queryParam));

    useEffect(()=> {
       if(queryResult.isFetched){
           console.log('queryResult', queryResult.data);
           setData(queryResult.data.detail);
           setFiles(queryResult.data.files);
           setUsers(queryResult.data.users.map(item => ({...item, deptNm: item.coNm + '(' + item.deptNm + ')'})));
           setVehls(queryResult.data.vehls);
       }
    },[queryResult.status])

    useEffect(()=> {
        if(queryReplyResult.data){
            console.log('queryReplyResult', queryReplyResult.data);
            const data = queryReplyResult.data.map(p=>({...p,show: true}))
            setReplyData(data);
        }

     },[queryReplyResult.status])

     useEffect(()=>{
        console.log("replyData",replyData);
     },[replyData])





    const columnDefs = [
        {
            headerName: '차종',
            field: 'qltyVehlNm',
        },
        {
            headerName: '연식',
            field: 'mdlMdyCd',
        },
        {
            headerName: '언어',
            field: 'langCdNm',
        },
    ]

    // const [rowData2] = useState([
    //         {userPart: "현대자동차", userName: "홍길동"},
    //         {userPart: "현대자동차", userName: "김삼순"},
    //         {userPart: "현대자동차", userName: "김삼순"},
    //         {userPart: "현대자동차", userName: "김삼순"},
    // ]);

    const columnDefs2 = [
        {
          headerName: '소속',
          field: 'deptNm',
        },
        {
          headerName: '이름',
          field: 'userNm',
        },
    ]

    const defaultColDef = useMemo(() => {
        return {
            initialWidth: 90,
            sortable: true,
        };
    }, []);


    const onFirstDataRendered = (params) => {
        params.api.sizeColumnsToFit();
    };

    const updateButton = () => {
        navigate('/board/update', {state: state});
    }
    const deleteButton = () => {
        
        confirmAlert({
            closeOnClickOutside: false,
            customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}   title={"알림"} 
            msg={"삭제하시겠습니까?"}  
            onOk={delOk}
            />
        });
    }
    const listButton = () => {
        navigate('/board');
    }

    const delOk = () => {
        delBoardData.mutate(queryParam);
    }
    const delBoardData = useMutation((params => postData(API.boardAffrMgmt, params, CONSTANTS.delete)),{
        onSuccess: res => {
            if(res > 0){
                confirmAlert({
                    closeOnClickOutside: false,
                    customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}  title={"알림"} msg={"삭제되었습니다."}   />
                });
            }else{
                confirmAlert({
                    closeOnClickOutside: false,
                    customUI: ({ onClose }) => <ConfirmAlert onClose={onClose} title={"알림"} msg={"삭제실패했습니다"}   />
                });
            }
            navigate('/board');
        }
    });



    const [showEditor, setShowEditor ] = useState(false)
    const [showEditorUpdate, setShowEditorUpdate ] = useState(false)

    // 기존업로드된 파일리스트 (수정화면에서 사용)
    const onCreationComplete = e => {
        if(files){
            for(let i=0; i<files.length; i++){
                DEXT5UPLOAD.AddUploadedFile(''+(i+1), escapeCharChange(files[i].fileNm), '', files[i].fileSize, files[i].attcSn, 'dext5upload1');
            }
        }
    }
    
    //  댓글등록                                             
    const replyMudate = useMutation((params => postData(API.boardAffrMgmtReply, params, CONSTANTS.insert)),{
        onSuccess: res => {
            if(res === 1){
                // 댓글 리플래시
                queryReplyResult.remove();
                queryReplyResult.refetch();
                DEXT5.setBodyValue('', 'editor1');
                setShowEditor(false);
            }else{
                confirmAlert({
                    closeOnClickOutside: false,
                    customUI: ({ onClose }) => <ConfirmAlert onClose={onClose} title={"알림"} msg={"저장실패했습니다"}   />
                });
            }
        }
    });

     //  댓글수정                                            
     const replyUpdateMutate = useMutation((params => postData(API.boardAffrMgmtReply, params, CONSTANTS.update)),{
        onSuccess: res => {
            if(res === 1){
                // 댓글 리플래시
                queryReplyResult.remove();
                queryReplyResult.refetch();
                
            }else{
                confirmAlert({
                    closeOnClickOutside: false,
                    customUI: ({ onClose }) => <ConfirmAlert onClose={onClose} title={"알림"} msg={"저장실패했습니다"}   />
                });
            }
        }
    }); 


       //  댓글수정                                            
       const replyDeleteMutate = useMutation((params => postData(API.boardAffrMgmtReply, params, CONSTANTS.delete)),{
        onSuccess: res => {
            if(res === 1){
                // 댓글 리플래시
                queryReplyResult.remove();
                queryReplyResult.refetch();
                
            }else{
                confirmAlert({
                    closeOnClickOutside: false,
                    customUI: ({ onClose }) => <ConfirmAlert onClose={onClose} title={"알림"} msg={"삭제 실패했습니다"}   />
                });
            }
        }
    }); 
    const [updateReplyParam, setUpdReplyParam ] = useState({}) //답변 updateparam
    //답변 수정, 취소 이벤트
    const replyUpdate = (e) =>{
        setShowEditorUpdate(true)
        setUpdReplyParam(e);
        setTimeout(() =>  DEXT5.setBodyValue(unescapeHtml(e.blcReplySbc), 'editor2'), 500);
        setReplyData(replyData.map(item=>({...item, show : item.blcReplySn ===e.blcReplySn?false : item.show})))
    }
      
    const replyUpdateCancle = (e)=>{
        setReplyData(replyData.map(item=>({...item, show : item.blcReplySn ===e?true : true})))
        setShowEditorUpdate(false)
    }


    const onSaveReply = () => {
       // 내용
       const textValue = DEXT5.getBodyTextValue();
       if(DEXT5.getBodyTextValue().length === 0){
           confirmAlert({
               closeOnClickOutside: false,
               customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}  title={"알림"} msg={"댓글내용을 입력해주세요."}  />
           })
           return;
       }

       const replyParam = {
            blcSn: state,
            blcReplySn: replyData.length === 0 ? 1 : parseInt(replyData[0].blcReplySn)+1,
            blcReplySbc: DEXT5.getBodyValue(),
       };
       replyMudate.mutate(replyParam);
    }


    const onUpdateReply = () => {
        // 내용
        const textValue = DEXT5.getBodyTextValue();
        if(DEXT5.getBodyTextValue().length === 0){
            confirmAlert({
                closeOnClickOutside: false,
                customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}  title={"알림"} msg={"댓글내용을 입력해주세요."}  />
            })
            return;
        }
 
        const replyParam = {
             blcSn: state,
             blcReplySn: updateReplyParam.blcReplySn,
             blcReplySbc: DEXT5.getBodyValue(),
        };
        replyUpdateMutate.mutate(replyParam);
        setShowEditorUpdate(false);
 
     }
     const onDeleteReply = (e) => {
        // 내용
 
        const replyParam = {
             blcSn: state,
             blcReplySn: e.blcReplySn,
        };
        replyDeleteMutate.mutate(replyParam);
     }
    if(!data) return;

    return (
        <>
            <div className="write-wrap">
               
                <Table className="tbl-hor" bordered>
                    <colgroup>
                        <col style={{width:'15%'}}></col>
                        <col style={{width:'35%'}}></col>
                        <col style={{width:'15%'}}></col>
                        <col style={{width:'35%'}}></col>
                    </colgroup>
                    <tbody>
                        <tr>
                            <th>분류</th>
                            <td>{data.blcScnCdNm}</td>
                            <th>등록자</th>
                            <td>{data.regnNm}</td>
                        </tr>
                        <tr>
                            <th>적용 차종 및 언어</th>
                            <td>
                                <div className="ag-theme-alpine" style={{height: 130, transition:'all ease .3s'}}>
                                    <AgGridReact
                                        rowData={vehls && vehls}
                                        columnDefs={columnDefs}
                                        defaultColDef={defaultColDef}
                                        onFirstDataRendered={onFirstDataRendered}
                                        suppressSizeToFit={true}    
                                        onGridSizeChanged={onFirstDataRendered}    
                                        >
                                    </AgGridReact>
                                </div>
                            </td>
                            <th>수신인</th>
                            <td>
                                <div className="ag-theme-alpine" style={{height: 130, transition:'all ease .3s'}}>
                                    <AgGridReact
                                        rowData={users && users}
                                        columnDefs={columnDefs2}
                                        defaultColDef={defaultColDef}
                                        onFirstDataRendered={onFirstDataRendered}
                                        suppressSizeToFit={true}    
                                        onGridSizeChanged={onFirstDataRendered}    
                                        >
                                    </AgGridReact>
                                </div>
                            </td>
                        </tr>
                        <tr>
                            <th>전 MY 투입가능</th>
                            <td>{data.befmyTrwiYn === 'Y' ? '예' : '아니오'}</td>
                            <th>책등 유무</th>
                            <td>{data.bbYn === 'Y' ? data.bbVal : '아니오'}</td>
                        </tr>
                        <tr>
                            <th>분리투입 여부</th>
                            <td>{data.dtrwiYn === 'Y' ? '예' : '아니오'}</td>
                            <th>분리투입 요청일</th>
                            <td>{convertYmd(data.dtrwiRqYmd)}</td>
                        </tr>
                        <tr>
                            <th>교체투입 여부(이전매뉴얼 폐기)</th>
                            <td>{data.altrTrwiYn === 'Y' ? '예' : '아니오'}</td>
                            <th>신규매뉴얼 투입 요청일</th>
                            <td>{convertYmd(data.nmtrwiRqYmd)}</td>
                        </tr>
                        <tr>
                            <th>제목</th>
                            <td colSpan="3">
                                {data.blcTitlNm}
                            </td>
                        </tr>
                        <tr>
                            <th>내용</th>
                            <td colSpan="3">
                                <div dangerouslySetInnerHTML={{__html: unescapeHtml(data.blcSbc)}} /> 
                            </td>
                        </tr>
                        <tr>
                            <th>첨부파일</th>
                            <td colSpan="3">
                                {files && files.length > 0 && <DEXT5Upload
                                        onCreationComplete={onCreationComplete}
                                        // onTransferStart={onTransferStart}
                                        // onTransferComplete={onTransferComplete}
                                        // onBeforeAddItem={onBeforeAddItem}
                                        debug={false}
                                        id="dext5upload1"
                                        // mode='edit' 
                                        mode='view'  // view Mode
                                        runtimes='html5'
                                        componentUrl="/dext5upload/js/dext5upload.js"
                                        config={{MaxTotalFileSize:'100MB', MaxOneFileSize:'30MB', DevelopLangage:'NONE',Width:'100%',
                                            ButtonBarView: 'download,download_all', // view Mode
                                            HandlerUrl:  process.env.REACT_APP_DEXT5UPLOAD_HANDLER_URL,
                                            DownloadHandlerUrl: process.env.REACT_APP_DEXT5UPLOAD_HANDLER_URL
                                        }}
                                        
                                />}
                            </td>
                        </tr>
                    </tbody>
                </Table>
                <div className="reply-wrap">
                    <div className="reply-write">
                        {/* <Form.Control as="textarea" placeholder="내용을 입력해주세요"></Form.Control> */}
                        {showEditor && <DEXT5Editor
                            debug={true}
                            id="editor1"
                            componentUrl="/dext5editor/js/dext5editor.js"
                            config={{ DevelopLangage:'NONE', Width:'100%', Height: '300px' }}
                        />} 
                    </div>
                        <div >
                            <div className="mt-2" style={{ textAlign: 'right'}}>
                                {!showEditor && <Button variant="primary" size="sm" style={{marginRight: '6px'}} onClick={()=>setShowEditor(true)}>댓글 쓰기</Button>}
                                {showEditor && <Button variant="light" size="sm" onClick={()=>setShowEditor(false)}>취소</Button>}
                                {showEditor && <Button className="ms-1" variant="primary" size="sm" onClick={onSaveReply}>댓글 등록</Button>}
                            </div>
                        </div>
                    <p className="reply-count">댓글 <span>{replyData && replyData.length}</span>건</p>
                    <div className="reply-body">
                        {replyData && replyData.map((item, index) => (
                        <div className="reply-detail" key={index} style={{display : item.show===true? "block":"none"}}>
                                <ul>
                                    <li >
                                        <div className="reply-user">{item.deptNm}{' '}{item.userNm}</div>
                                        <div className="reply-cont"><div dangerouslySetInnerHTML={{__html: unescapeHtml(item.blcReplySbc)}} /> </div>
                                        <div className="reply-date">{moment(item.mdfyDtm).format('YYYY-MM-DD HH:mm')}</div>
                                        <div className="reply-util">
                                            {item.modChk==='Y' &&<span className="reply-modify" onClick={()=>replyUpdate(item)}><FontAwesomeIcon icon={faPenToSquare} />수정</span>}
                                            {item.modChk==='Y' &&<span className="reply-delete"  onClick={()=>onDeleteReply(item)}><FontAwesomeIcon icon={faTrashCan} />삭제</span>}
                                        </div>
                                    </li>
                                </ul>
                         </div>
                         ))}
                    </div>

                    {/* 0629 댓글 수정 버튼 클릭 시*/}
                    <div className="reply-body" style={{marginTop:"20px"}}>
                        <div className="reply-detail" >
                            <ul >
                                {showEditorUpdate &&
                                    <li>
                                    <div className="reply-user">{updateReplyParam.deptNm} {updateReplyParam.userNm}</div>
                                    <div className="reply-cont">
                                        <DEXT5Editor
                                            debug={true}
                                            id="editor2"
                                            componentUrl="/dext5editor/js/dext5editor.js"
                                            config={{ DevelopLangage:'NONE', Width:'100%', Height: '300px' }}
                                        />
                                        <div className="reply-modify-com">
                                            <Button variant="light" size="md" onClick={()=>replyUpdateCancle(updateReplyParam.blcReplySn)}>취소</Button>
                                            <Button variant="primary" size="md" onClick={onUpdateReply}>댓글수정</Button>
                                        </div>
                                    </div>
                                </li>}
                            </ul>
                        </div>
                    </div>
                    {/* 0629 댓글 수정 버튼 클릭 시  end ///*/}
            </div>
                <div className="btn-wrap">
                    <div className="left-align"><Button variant="light" onClick={listButton}>목록</Button>{' '}</div>
                    <div className="right-align">
                        <Button variant="outline-danger" onClick={deleteButton}>삭제</Button>{' '}
                        <Button className="" variant="primary" size="md" onClick={updateButton}>수정</Button>
                    </div>
                </div>
            </div>
        </>
    )
};
export default BoardDetail;