import React from 'react';
import {Tab,Tabs} from 'react-bootstrap';

import SewonIvmTot from './SewonIvmTot';
import SewonIvmPrint from './SewonIvmPrint';
import OutState from './OutState';
import RequestState from './RequestState';
import CarStock from '../TotalStock/CarStock';
import ProductPlan from '../TotalStock/ProductPlan';

const SewonIvmContainer = () => {

    const [leftWidth, setLeftWidth] = React.useState('150px')
    // const element = React.useRef(null);
   
    React.useEffect(() => {
        const getTitle = document.getElementById('section-title-width');
        const titleWidth = getTitle.clientWidth + 40;
        setLeftWidth(titleWidth)
    }, []);

    const [activeTab, setActiveTab] = React.useState('tab1');

    return (
        <>
            <Tabs  defaultActiveKey={activeTab} onSelect={tab => setActiveTab(tab)} style={{left: leftWidth}} >
              
                <Tab eventKey="tab1" title="세원재고관리 현황">
                    {activeTab === 'tab1' && <SewonIvmTot />}
                </Tab>
                <Tab eventKey="tab2" title="인쇄현황">
                    {activeTab === 'tab2' && <SewonIvmPrint />}
                </Tab>
                <Tab eventKey="tab3" title="출고현황">
                    {activeTab === 'tab3' && <OutState />}
                </Tab>
                <Tab eventKey="tab5" title="국가별 생산계획">
                    {activeTab === 'tab5' && <ProductPlan />}
                </Tab>
                <Tab eventKey="tab6" title="차종별 재고분석">
                    {activeTab === 'tab6' && <CarStock />}
                </Tab>
                <Tab eventKey="tab4" title="요청현황">
                    {activeTab === 'tab4' && <RequestState />}
                </Tab>
            </Tabs>
        </>
    );

};
export default SewonIvmContainer;