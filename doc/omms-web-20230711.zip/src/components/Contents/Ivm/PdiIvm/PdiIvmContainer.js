import React from 'react';
import {Tab,Tabs} from 'react-bootstrap';

// component
import PdiIvmTot from './PdiIvmTot';
import InputState from './InputState';
import RequestState from './RequestState';
import CarStock from '../TotalStock/CarStock';
import ProductPlan from '../TotalStock/ProductPlan';

const PdiIvmContainer = () => {

    const [leftWidth, setLeftWidth] = React.useState('150px')
    // const element = React.useRef(null);
   
    React.useEffect(() => {
        const getTitle = document.getElementById('section-title-width');
        const titleWidth = getTitle.clientWidth + 40;
        setLeftWidth(titleWidth)
    }, []);

    const [activeTab, setActiveTab] = React.useState('tab1');

    return (
        <>
             <Tabs  defaultActiveKey={activeTab} onSelect={tab => setActiveTab(tab)} style={{left: leftWidth}} >
                <Tab eventKey="tab1" title="PDI재고관리 현황">
                    {activeTab === 'tab1' && <PdiIvmTot />}
                </Tab>
                <Tab eventKey="tab2" title="입고현황">
                    {activeTab === 'tab2' && <InputState />}
                </Tab>
                <Tab eventKey="tab4" title="국가별 생산계획">
                    {activeTab === 'tab4' && <ProductPlan />}
                </Tab>
                <Tab eventKey="tab5" title="차종별 재고분석">
                    {activeTab === 'tab5' && <CarStock />}
                </Tab>
                <Tab eventKey="tab3" title="요청현황">
                    {activeTab === 'tab3' && <RequestState />}
                </Tab>
            </Tabs>
        </>
    )

};
export default PdiIvmContainer;