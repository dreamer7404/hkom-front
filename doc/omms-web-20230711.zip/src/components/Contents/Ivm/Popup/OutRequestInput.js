import React, {useState, useMemo, useEffect, useCallback, useRef} from 'react';
import { AgGridReact } from 'ag-grid-react';

import {Button, Modal} from 'react-bootstrap';
import {Form, SelectPicker, MaskedInput, Tooltip, Whisper, Popover, Notification, toaster } from 'rsuite';
import { escapeCharChange, escapeCharChangeForGrid, formatNumber, utcToLocalDate } from '../../../../utils/commUtils';
import moment from 'moment';
import useStore from '../../../../utils/store';


// //--------------  서버데이터용 필수 -------------------------------
import { useMutation, useQuery} from 'react-query';
import { postData, getData } from '../../../../utils/async';
import { API, CONSTANTS } from '../../../../utils/constants';
// //--------------// 서버데이터용 필수 -------------------------------


import { confirmAlert } from 'react-confirm-alert'; // Import
import ConfirmAlert from '../../../Common/ConfirmAlert';

//아이콘
import {ArrowDownLine, ArrowUpLine, FileDownload} from '@rsuite/icons';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faFileExcel,faPrint } from '@fortawesome/free-solid-svg-icons'
//모달
import CustomModal from '../../../Common/CustomModal';
import { excelDownload as excelDownloadAggrid } from '../../../../utils/excelForAggrid';

const OutRequestInput = ({show, onHide, checkedRows}) => {

    // 수량 천단위 콤마 찍기
    const currencyFormatter = (params) => {
        return formatNumber(params.value);
    };

    //데이터 조회 파라미터 세팅
    const {keyword } = useStore();  // 조회키워드 가져오기
    const param = {'bDate':keyword.bDate, 'dataSns' : checkedRows.map(item=> {return item['dataSn']}).reduce((dataSns, dataSn, idx, all) => { return idx === 0 ? dataSns+=''+dataSn : dataSns+=','+dataSn },'')};
    
    //데이터 조회(get)
    const queryResult = useQuery([API.ivmSewonWhotInfos, param], () => getData(API.ivmSewonWhotInfos, param),{
        staleTime:0
        ,select : data => {
            return data.map(item => ({...item, dlvgParrHhmm:escapeCharChange(item.dlvgParrHhmm)}))
        }
    });

    

    const [formValue, setFormValue] = useState();
    useEffect(() => {
      if(queryResult.isSuccess)  {
        setFormValue(queryResult.data)
      }
    },[queryResult.status])

    if(show && checkedRows.length <= 0){  
        show=false
        onHide=true
    }
    
    

    const gridRef = useRef();
    const columnDefs = [
        {
            checkboxSelection: true,
            headerCheckboxSelection: true,
            spanHeaderHeight: true,
            width:35,
            maxWidth:35,
            minWidth:35,
            sortable: false
        },
        {
            headerName: '구분',
            field: 'dlExpdRqScnCd',
            spanHeaderHeight: true,
            cellRenderer:'SelectComponent',
            minWidth:'100',
            aggFunc: params => { //엑셀다운로드 할 때 해당 Cell의 데이터를 매핑하기위한 작업(해당 Cell이 셀렉트 박스인경우, label이 나오도록 하기위함..)
                if(params === '01'){
                    return '일반';
                } else {
                    return '별도';
                }
            }
        },  
        {
          headerName: '차종',
          children: [
            { headerName:'차종코드', field: 'qltyVehlCd', minWidth:70,},
            { headerName:'차종명', field: 'qltyVehlNm',minWidth:130, cellRenderer:"escapeCharChangeForGrid" },
            { headerName:'연식', field: 'mdlMdyCd' , minWidth:50,},
          ],
        },
        {
          headerName: '언어',
          children: [
            { headerName:'지역', field: 'dlExpdPrvsNm', minWidth:70,},
            { headerName:'언어코드', field: 'langCd',minWidth:70, },
            { headerName:'언어명', field: 'langCdNm',minWidth:130, cellRenderer:"escapeCharChangeForGrid"},
          ],
        },
        {
          headerName: '발간번호',
          field: 'newPrntPbcnNo',
          spanHeaderHeight: true,
          minWidth:110,
        },  
        {
          headerName: '보유재고',
          field: 'ivQty',
          spanHeaderHeight: true,
          minWidth:70,
          valueFormatter: currencyFormatter
        },  
        {
            headerName: '수량',
            field: 'rqQty',
            spanHeaderHeight: true,
            cellRenderer:'NumberComponent',
            minWidth:100,
        },  
        {
            headerName: 'Box 수',
            field: 'dlExpdBoxQty',
            spanHeaderHeight: true,
            cellRenderer:'NumberComponent',
            minWidth:70,
        },  
        {
            headerName: '납품일',
            field: 'dlvgParrYmd',
            spanHeaderHeight: true,
            cellRenderer:'dateComponent',
            minWidth:120,
        },  
        {
            headerName: '출하시간',
            field: 'dlvgParrHhmm',
            spanHeaderHeight: true,
            cellRenderer:'timeComponent',
            minWidth:70,
        },  
        {
            headerName: '담당자',
            field: 'pwtiNm',
            spanHeaderHeight: true,
            cellRenderer:'inputComponent',
            minWidth:80,
        },  
        {
            headerName: '비고',
            field: 'testDt8',
            minWidth:80,
            spanHeaderHeight: true,
            cellRenderer:'inputComponent'
        },  
    ]

    const defaultColDef = useMemo(() => {
        return {
            initialWidth: 90,
            sortable: true,
            resizable:true,
        };
    }, []);

    const dateComponent = props => {
        const option = 
            {
              name: 'Date',
              mask: [/\d/, /\d/, /\d/, /\d/, '-', /\d/, /\d/, '-', /\d/, /\d/],
              placeholder: 'yyyy-mm-dd'
            }

        const onChangeInput = (newValue, oldValue) => {
            props.node.setDataValue(props.colDef.field, newValue)
        };

        return (
            <MaskedInput
                value={props.value && escapeCharChange(props.value)}
                mask={option.mask}
                guide={true}
                showMask={true}
                onChange={e => onChangeInput(e, props.value)}
                readOnly={true}
            />
        )
    }

    const timeComponent = props => {
        const option = 
            {
              name: 'Date',
              mask: [/\d/, /\d/, ':', /\d/, /\d/],
              placeholder: 'HH:MI'
            }

        const onChangeInput = (newValue, oldValue) => {
            props.node.setDataValue(props.colDef.field, newValue)
        };

        return (
            <MaskedInput
                value={props.value && escapeCharChange(props.value)}
                mask={option.mask}
                guide={true}
                showMask={true}
                onChange={e => onChangeInput(e, props.value)}
            />
        )
    }

    const NumberComponent = props => {
        const option = 
            {
              mask: [/\d/, /\d/, /\d/, /\d/, /\d/, /\d/, /\d/]
            }

        const [message , setMessage] = useState('')
        const [errCheck, setErrCheck] = useState(false)

        const onChangeInput = (newValue, oldValue) => {
            
            // if(newValue === '0') {
            //     props.column.colDef.cellStyle = { 'backgroundColor': 'red' }
            //     setMessage('수량을 입력하세요')
            //     setErrCheck(true)
            // } else {
            //     props.column.colDef.cellStyle = { 'backgroundColor': '' }
            //     setMessage('')
            //     setErrCheck(false)
            // } 
            // console.log(parseInt(newValue) > parseInt(props.data.ivQty))
            if(parseInt(newValue) > parseInt(props.data.ivQty)){
                props.node.setDataValue(props.colDef.field, props.data.ivQty)
            } else {
                props.node.setDataValue(props.colDef.field, newValue.replace(/(^0+)/, ""))
            }
        };

        return (
            <div className="grid-form-wrap">
                    <MaskedInput
                        value={props.value ? props.value : 0}
                        mask={option.mask}
                        guide={false}
                        showMask={false}
                        onChange={e => onChangeInput(e, props.value)}
                        maxLength={props.data.ivQty.length}
                    />
            </div>
        )
    }

    const inputComponent = (props) => {
        const onChangeInput = (newValue, oldValue) => {
            props.node.setDataValue(props.colDef.field, newValue)
        };
        return (
          <div className="grid-form-wrap">
            <Form.Control size="sm" placeholder="" onChange={e => onChangeInput(e, props.value)} value={props.value && escapeCharChange(props.value)}/>
          </div>
        );
    }


    const SelectComponent = (props) => {
        
        let selectMenuGroup = [{value: '01',label: '일반',}, {value: '02',label: '별도',}];
        const [selectedValue, setSelectedValue] = useState(props.value);
        const onChangeSelectDt = value => {
            setSelectedValue(value);
        };
        useEffect(() => {
            selectedValue 
            ? props.node.setDataValue('dlExpdRqScnCd',selectedValue)
            : props.node.setDataValue('dlExpdRqScnCd','01')
        })
        return (
            <div className='grid-form-wrap'>
                
                <SelectPicker
                    // disabled={isCurrentRowEditing ? true : false}
                    size="sm"
                    searchable={false}
                    cleanable={false}
                    value={selectedValue?selectedValue:'01'}
                    onChange={onChangeSelectDt}
                    data={selectMenuGroup}
                />
            </div>
        );
    }

    const onFirstDataRendered = (props) => {
        props.api.sizeColumnsToFit();
    };

    // 그리드 내에서 체크된 rows by Woong
    const [checkedRowsForOutReqInput, setCheckedRowsForOutReqInput] = useState([]);    
    const [checkedNodesForOutReqInput, setCheckedNodesForOutReqInput] = useState([]);    
    const onSelectionChanged = useCallback(() => {
        setCheckedRowsForOutReqInput(gridRef.current.api.getSelectedRows())
        setCheckedNodesForOutReqInput(gridRef.current.api.getSelectedNodes())
    }, []);

    const onBodyScrollEnd = () => {
        // onSubmit({}, true)
    }

    //데이터 등록(post)
    const submitResult = useMutation([API.ivmSewonWhotInfos, checkedRowsForOutReqInput], () => postData(API.ivmSewonWhotInfos, checkedRowsForOutReqInput, CONSTANTS.update),{
		onSuccess: res => {
		    if(res > 0){
		        toaster.push(
                    <Notification type='success' header='요청성공' closable >출고입력이 완료되었습니다.</Notification>
                );
                show=false;
                onHide(); // 창닫기
		    }else{
		        toaster.push(
                    <Notification type='error' header='요청실패' closable >출고입력을 실패했습니다.</Notification>
                );
		    }
		}
	});
    const saveButtonFirst = (e, scrollCheck) =>{
        gridRef.current.api.redrawRows()
        setTimeout(onSubmit(e, scrollCheck), 1000)
    }
    //저장 버튼 클릭시
    const onSubmit = (e, scrollCheck) => {
        
        let errMessage = '';
        if(checkedRowsForOutReqInput.length === 0 && !scrollCheck){
            scrollCheck = true
            confirmAlert({
                closeOnClickOutside: false,
                customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}  title={"알림"} msg={"대상을 선택해주세요."}  />
            })
            return false
        }
        // gridRef.current.api.redrawRows()

        for(let i = 0; i < checkedNodesForOutReqInput.length; i ++){
            if(checkedNodesForOutReqInput[i].data.rqQty === '0' || checkedNodesForOutReqInput[i].data.rqQty === '' || checkedNodesForOutReqInput[i].data.rqQty === 0) {
                errMessage = '수량을 입력하세요.'
                if(scrollCheck !== true) {
                    gridRef.current.api.ensureIndexVisible(checkedNodesForOutReqInput[i].rowIndex)
                    confirmAlert({
                        closeOnClickOutside: false,
                        customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}  title={"알림"} msg={errMessage}  />
                    })
                }
                gridRef.current.api.flashCells({ rowNodes: [checkedNodesForOutReqInput[i]], columns: ['rqQty'], fadeDelay: 400000, flashDelay:10 });
                scrollCheck = true
                break
            }

            if(checkedNodesForOutReqInput[i].data.dlExpdBoxQty === '0' || checkedNodesForOutReqInput[i].data.dlExpdBoxQty === '') {
                errMessage = 'Box 수를 입력하세요.'
                if(scrollCheck !== true) {
                    gridRef.current.api.ensureIndexVisible(checkedNodesForOutReqInput[i].rowIndex)
                    confirmAlert({
                        closeOnClickOutside: false,
                        customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}  title={"알림"} msg={errMessage}  />
                    })
                }
                gridRef.current.api.flashCells({ rowNodes: [checkedNodesForOutReqInput[i]], columns: ['dlExpdBoxQty'], fadeDelay: 100000, flashDelay:10 });        
                scrollCheck = true
                break
            }

            if(!moment(checkedNodesForOutReqInput[i].data.dlvgParrHhmm, "hh:mm").isValid()) {
                gridRef.current.api.flashCells({ rowNodes: [checkedNodesForOutReqInput[i]], columns: ['dlvgParrHhmm'], fadeDelay: 100000, flashDelay:10 });        
                errMessage = '출하시간을 확인해주세요.'
                if(scrollCheck !== true) {
                    gridRef.current.api.ensureIndexVisible(checkedNodesForOutReqInput[i].rowIndex)
                    confirmAlert({
                        closeOnClickOutside: false,
                        customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}  title={"알림"} msg={errMessage}  />
                    })
                }
                scrollCheck = true
                break
            }

            
        }

        if(scrollCheck) {
            return false
        } else {
            const onOk = () => {
                submitResult.mutate(checkedRowsForOutReqInput)
            }
            confirmAlert({
                closeOnClickOutside: false,
                customUI: ({ onClose }) => <ConfirmAlert 
                                                onClose={onClose} 
                                                title={"알림"}
                                                msg={"입력하신 내용으로 출고하시겠습니까?"} 
                                                onOk={onOk}  
                                            />
            })
        }
    };
    //저장 버튼 클릭시 끝

    //데이터 삭제(post)
    const deleteResult = useMutation([API.ivmSewonWhotInfos, checkedRowsForOutReqInput], () => postData(API.ivmSewonWhotInfos, checkedRowsForOutReqInput, CONSTANTS.delete),{
		onSuccess: res => {
		    if(res > 0){
		        toaster.push(
                    <Notification type='success' header='요청성공' closable >출고취소가 완료되었습니다.</Notification>
                );
                show=false;
                onHide(); // 창닫기
		    }else{
		        toaster.push(
                    <Notification type='error' header='요청실패' closable >출고취소를 실패했습니다.</Notification>
                );
		    }
		}
	});
    const onDelete = (e) => {
        if(checkedRowsForOutReqInput.length === 0){
            confirmAlert({
                closeOnClickOutside: false,
                customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}  title={"알림"} msg={"대상을 선택해주세요."}  />
            })
            return false
        } else {
            const onOk = () => {
                deleteResult.mutate(checkedRowsForOutReqInput)
            }
            confirmAlert({
                closeOnClickOutside: false,
                customUI: ({ onClose }) => <ConfirmAlert 
                                                onClose={onClose} 
                                                title={"알림"}
                                                msg={"선택하신 항목을 출고취소하시겠습니까?"} 
                                                onOk={onOk}  
                                            />
            })
            
        }
    }

    //엑셀다운로드
    const [excelStatus, setExcelStatus] = useState(false);
    useEffect(() => {
        if(excelStatus) {
            setExcelStatus(excelDownloadAggrid(gridRef, '세원재고 출고입력', 2))
        }
    }, [excelStatus])



    return (
        <>
            <Form>
                <CustomModal open={show} 
                    title={'출고입력'}
                    size='xl'
                    handleCancel={onHide} 
                >
                {/* <Modal show={show} onHide={onHide} backdrop="static" keyboard={false} centered size="xl" className="modal-custom size-2xl">
                    <Modal.Header closeButton>
                        <Modal.Title>출고입력</Modal.Title>
                    </Modal.Header>
                    <Modal.Body> */}
                        <div className="grid-btn-wrap">
                            <div className="left-align">
                                <div className="sub-title">
                                    <ul>
                                {/* <li>2023-03-21</li> */}
                                <li>{utcToLocalDate(new Date())}</li>
                            </ul>
                                </div>
                            </div>
                            <div className="right-align">
                                <Button variant="outline-secondary" size="sm" onClick={onDelete}>출고취소</Button>{' '}
                                <Button variant="outline-success btn-excel" size="sm" disabled={excelStatus} onClick={() => setExcelStatus(true)}>
                                    <FontAwesomeIcon icon={faFileExcel}/>
                                    {CONSTANTS.excelDownload}
                                </Button>{' '}
                                <Button variant="outline-dark btn-print" size="sm"onClick={() => window.print()}><FontAwesomeIcon icon={faPrint}/>{CONSTANTS.print}</Button>{' '}
                            </div>
                        </div>
                        {queryResult &&
                        <div className="ag-theme-alpine" style={{height:300, minWidth:300}}>
                            <AgGridReact
                                ref={gridRef} 
                                // rowData={queryResult && queryResult.data}
                                rowData={formValue}
                                
                                columnDefs={columnDefs}
                                rowSelection={'multiple'}
                                suppressRowClickSelection= {true} 
                                defaultColDef={defaultColDef}

                                // checkedRowDatas by Woong
                                onSelectionChanged={onSelectionChanged}
                                
                                overlayLoadingTemplate={CONSTANTS.gridLoading}
                                overlayNoRowsTemplate={CONSTANTS.gridNoRows}
                                
                                //escape 문자 처리 추가
                                frameworkComponents={{
                                    dateComponent,
                                    timeComponent,
                                    NumberComponent,
                                    inputComponent,
                                    SelectComponent,
                                    escapeCharChangeForGrid
                                }}
                                onFirstDataRendered={onFirstDataRendered}
                                suppressSizeToFit={true}    
                                onGridSizeChanged={onFirstDataRendered}     
                                onGridColumnsChanged={onFirstDataRendered}

                                onBodyScrollEnd={onBodyScrollEnd}

                                // onCellValueChanged={onCellValueChanged}

                                // onRowEditingStarted = { params => {
                                //     params.api.refreshCells({
                                //       columns: ['selectDt'],
                                //       rowNodes: [params.node],
                                //       force: true,
                                //     });
                                //   }
                                // }
                                // onRowEditingStopped = { params => {
                                //     params.api.refreshCells({
                                //         columns: ['selectDt'],
                                //         rowNodes: [params.node],
                                //         force: true,
                                //     });
                                // }}

                                >
                            </AgGridReact>
                        </div>
                        }
                    {/* </Modal.Body>
                    <Modal.Footer>
                        <Button variant="light" size="md" onClick={onHide}>취소</Button>
                        <Button variant="primary" size="md" onClick={e => {onSubmit(e, false)}}>저장</Button>
                    </Modal.Footer>
                </Modal> */}
                    <div className='modal-footer'>
                        <Button variant="light" size="md" onClick={onHide}>취소</Button>
                        <Button variant="primary" size="md" onClick={e => {saveButtonFirst(e, false)}} >저장</Button>
                    </div>
                </CustomModal>
            </Form>
        </>
    );

};
export default OutRequestInput;