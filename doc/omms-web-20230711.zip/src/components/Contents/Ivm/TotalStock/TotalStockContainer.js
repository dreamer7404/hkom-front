import React,{useState, useEffect} from 'react';
import {Tab,Tabs} from 'react-bootstrap';

import TotalStock from './TotalStock';
import RequestState from './RequestState';
import NoapimInfo from './NoapimInfo';
import MonthOrder from './MonthOrder';
import ProductPlan from './ProductPlan';
import CarStock from './CarStock';

const TotalStockContainer = () => {

    const [leftWidth, setLeftWidth] = useState('150px')
   
    useEffect(() => {
        const getTitle = document.getElementById('section-title-width');
        const titleWidth = getTitle.clientWidth + 40;
        setLeftWidth(titleWidth)
    }, []);

    const [activeTab, setActiveTab] = React.useState('tab1');

    return (
        <>
            <Tabs  defaultActiveKey={activeTab} onSelect={tab => setActiveTab(tab)} style={{left: leftWidth}} >
                <Tab eventKey="tab1" title={"총재고관리 현황"}>
                    {activeTab === 'tab1' && <TotalStock />}
                </Tab>
                <Tab eventKey="tab3" title="월간 오더/생산 정보">
                    {activeTab === 'tab3' && <MonthOrder />}
                </Tab>
                <Tab eventKey="tab4" title="국가별 생산계획">
                    {activeTab === 'tab4' && <ProductPlan />}
                </Tab>
                <Tab eventKey="tab5" title="차종별 재고분석">
                    {activeTab === 'tab5' && <CarStock />}
                </Tab>
                <Tab eventKey="tab2" title="요청현황">
                    {activeTab === 'tab2' && <RequestState />}
                </Tab>
                <Tab eventKey="tab6" title="미연계 정보">
                    {activeTab === 'tab6' && <NoapimInfo />}
                </Tab>
            </Tabs>
        </>
    );

};
export default TotalStockContainer;