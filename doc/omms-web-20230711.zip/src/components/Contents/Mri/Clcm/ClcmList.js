// react
import React, {useState, useEffect, useCallback, useRef} from 'react';
import {Button, Collapse} from 'react-bootstrap';
import SearchIcon from '@rsuite/icons/Search';
import {Form, Input, InputGroup, Grid, Row, Col ,SelectPicker, Notification, toaster } from 'rsuite';
import PersonSearch from '../../../Search/PersonSearch';
import { escapeCharChange} from '../../../../utils/commUtils';
import { confirmAlert } from 'react-confirm-alert'; // Import
import ConfirmAlert from '../../../Common/ConfirmAlert';


//--------------  서버데이터용 필수 -------------------------------
import { useQuery,useMutation} from 'react-query';
import { getData,postData } from '../../../../utils/async';
import { API, CONSTANTS } from '../../../../utils/constants';
import useStore from '../../../../utils/store';
//--------------// 서버데이터용 필수 -------------------------------

import VehlType from '../../../Search/VehlType';
import BDate from '../../../Search/SeDate';

import { useNavigate  } from 'react-router-dom';
import GridClcmList from '../_Grid/GridClcmList';
import Paging from '../../../Common/Paging';
import { CustomInputGroup } from '../../../Common/CustomInputGroup';
//아이콘
import {ArrowDownLine, ArrowUpLine, FileDownload} from '@rsuite/icons';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faFileExcel,faPrint } from '@fortawesome/free-solid-svg-icons'
import { excelDownload as excelDownloadAggrid } from '../../../../utils/excelForAggrid';

const ClcmList = () => {
    
    //------------------- 필수 공통 ------------------------------
    const [open, setOpen] = useState(true); // 조건창 열기/닫기
    const {keyword } = useStore();  // 조회키워드 가져오기
    const navigate = useNavigate();
    const [activePage, setActivePage] = useState(1);    // 페이지번호
    const [limit, setLimit] = useState(50);             // 페이지행수
    const [filterValue, setFilterValue] = useState(''); // 필터값

    const onChangePage = val => {
        setActivePage(val);
    };
    const onChangeLimit = val => {
        setLimit(val);
    };
    useEffect(()=>{
        onChangePage(1); // 페이지번호 리셋
    },[keyword]);

    // 필터
    const onFilterTextBoxChanged = useCallback((e) => {
        setFilterValue(e.target.value);
    }, []);

    // 검색창 열기/닫기 > 페이지네이션 여부에 따라 +-20px
    const [gridHeight, setGridHeight] = useState(575);
    const gridExpand = () =>{
        setOpen(!open);
        if(open){
            setTimeout(() => setGridHeight(650), 250);
        }else{
            setGridHeight(575)
        }
    }
    //-------------------// 필수 공통 ------------------------------


    //등록번호
    const [dlExpdAltrNo, setDlExpdAltrNo] = useState('ALL');
    //제목
    const [altrTitl, setAltrTitl] = useState('ALL');
    const onChangeAltrTitl = e => {
        setAltrTitl(e)
    }

    const [gridLangHeader, setGridLangHeader] = useState([
        { headerName:'AR', field: 'ar', minWidth:'65'},
        { headerName:'AS', field: 'as', minWidth:'65' },
        { headerName:'BS', field: 'bs', minWidth:'65' },
        { headerName:'AR', field: 'ar', minWidth:'65'},
        { headerName:'AS', field: 'as', minWidth:'65' },
        { headerName:'BS', field: 'bs', minWidth:'65' },
        { headerName:'AR', field: 'ar', minWidth:'65'},
        { headerName:'AS', field: 'as', minWidth:'65' },
        { headerName:'BS', field: 'bs', minWidth:'65' },
        { headerName:'AS', field: 'as', minWidth:'65' },
        { headerName:'BS', field: 'bs', minWidth:'65' },
        { headerName:'AS', field: 'as', minWidth:'65' },
        { headerName:'BS', field: 'bs', minWidth:'65' },
    ])

    // langCd 가져오기
    const langParams = {
        bDate: keyword.bDate && keyword.bDate.replace(/-/gi, ''),
        dlExpdPdiCd: 'ALL', 
        qltyVehlCd: 'ALL', 
        mdlMdyCd: 'ALL', 
        dlExpdRegnCd: 'ALL'
    };
    const langCombo = useQuery([API.langCombo, langParams], () => getData(API.langCombo, langParams), {
        select: data => data.map((item) => ({ headerName: item.langCd, field: item.langCd, minWidth:'65' 
        ,valueGetter: (params) => {
            if(
                params.data.langCd.split(',').filter(item => {
                    if(params.colDef) {
                        return item === params.colDef.headerName
                    }
                }).length === 0
            ) {return 'X'}
          },
        }))
    }); 

    useEffect(() => {
        if(langCombo.isSuccess){
            setGridLangHeader(langCombo.data)
        }
    }, [langCombo.status])

    const param = {
        ssDate: keyword.sDate,
        eeDate: keyword.eDate,
        dlExpdPdiCd: keyword.dlExpdPdiCd,
        qltyVehlCd: keyword.qltyVehlCd,
        mdlMdyCd: keyword.mdlMdyCd,
        dlExpdAltrNo:'ALL',
        altrTitl:'',
        crgrEeno: 'ALL'
    }
    //  requestState 조회
    const queryResult = useQuery([API.mriClcmInfos, param], () => getData(API.mriClcmInfos, param));

    const onChangeCrgrEeno = value => {
        param.crgrEeno =  value
    }

    const gridRef = useRef();
    
    // 셀 클릭
    const onCellClicked = e => {
        if(e.column.colId === 'altrTitl'){
            goDetail(e)
        }
    };

    const CustomInputGroupWidthButton = () => (
        <InputGroup inside >
            <Input style={{fontSize:'12px',height:'28px'}}/>
            <InputGroup.Button style={{height:'28px'}}>
            <SearchIcon />
            </InputGroup.Button>
        </InputGroup>
    );

    const goDetail = (param) => {
        // console.log(param.data)
        navigate('/clcm/detail',{ state: param.data }); 
    }

    const addButton = () => {
        
        navigate('/clcm/add',{ state: '' }); 
    }

    // 그리드 내에서 체크된 rows by Woong
    const [checkedRows, setCheckedRows] = useState([]);    
    const checkRow = e => {
        setCheckedRows(e)
    };
    //데이터 삭제(post)
    const deleteResult = useMutation((params => postData(API.mriDelClcmInfo, params, CONSTANTS.delete)),{
        onSuccess: res => {
		    if(res > 0){
                toaster.push(
                    <Notification type='success' header='요청성공' closable >삭제가 완료되었습니다.</Notification>
                );
                setTimeout(() => queryResult.refetch(), 1000);
            }else{
                toaster.push(
                    <Notification type='error' header='요청실패' closable >삭제를 실패했습니다.</Notification>
                );
            }
        }
    });
    const delButton = () => {
        if(checkedRows.length == 0){
            confirmAlert({
                closeOnClickOutside: false,
                customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}  title={"알림"} msg={"대상을 선택해주세요."}  />
            })
            return false
        } else {
            const onOk = () => {
                deleteResult.mutate(checkedRows)
            }
            confirmAlert({
                closeOnClickOutside: false,
                customUI: ({ onClose }) => <ConfirmAlert 
                                                onClose={onClose} 
                                                title={"알림"}
                                                msg={"해당 게시물을 삭제하시겠습니까?"} 
                                                onOk={onOk}  
                                            />
            })
        }
    }

    

    // 조회버튼
    const onSearch = () => {
        param.altrTitl = altrTitl
        param.dlExpdAltrNo = dlExpdAltrNo
        setTimeout(() => queryResult.refetch(), 1000);
        //queryResult.refetch(); // 수동쿼리실행
    };

    const [excelStatus, setExcelStatus] = useState(false);
    useEffect(() => {
        if(excelStatus) {
            setExcelStatus(excelDownloadAggrid(gridRef, '법규 및 변경관리 현황', 2))
        }
    }, [excelStatus])


    return (
        <>
            <div className="search-area">
                <Collapse in={open}>
                    <div className="form" id="example-collapse-text">
                        <div className="search-group">
                            <div className="row">
                                <Grid fluid>
                                    <Row className="show-grid">
                                        <Col sm={5} className=""> 
                                            <BDate />
                                        </Col>
                                        <Col sm={6} className="" >
                                            <VehlType  />
                                        </Col>
                                        <Col sm={3} className=""> 
                                            <Form.ControlLabel column="sm">등록번호</Form.ControlLabel>
                                            <Input size="sm" type="text" onChange={e => setDlExpdAltrNo(e)}/>
                                        </Col>
                                        <Col sm={4} className=""> 
                                            {/* <Form.Group>
                                                <Form.ControlLabel column="sm">등록자</Form.ControlLabel>
                                                <CustomInputGroupWidthButton size="sm" placeholder="Small" />
                                            </Form.Group> */}
                                            <PersonSearch label={'등록자'} rmCheck={true} onChangeCrgrEeno={onChangeCrgrEeno} />
                                        </Col>
                                        <Col sm={6} className=""> 
                                            <Form.ControlLabel column="sm">제목</Form.ControlLabel>
                                            <Input size="sm" type="text"  onChange={onChangeAltrTitl}/>
                                        </Col>
                                   </Row>
                                </Grid>
                            </div>
                            <div className="search-btn-wrap">
                                <Button className="btn-search" variant="outline-primary" size="sm" onClick={onSearch}><SearchIcon />조회</Button>
                            </div>
                        </div>
                    </div>
                </Collapse>
                <Button size="sm" variant="outline-dark" className="search-control" aria-controls="example-collapse-text" 
                    aria-expanded={open} onClick={gridExpand}>
                    {open 
                        ? 
                        <span className="search-area-close">
                            <ArrowUpLine style={{marginRight: '5px', fontSize: '2em'}} />
                            {CONSTANTS.closeSearch}
                        </span> 
                        :
                        <span className="search-area-open">
                            <ArrowDownLine style={{marginRight: '5px', fontSize: '2em'}} />
                            {CONSTANTS.openSearch}
                        </span>
                    }
                </Button>
            </div>
            
            <div className="grid-wrap">
                <div className="grid-btn-wrap">
                    <div className="left-align">
                        {/*--------- 필터 -----------*/}
                        <CustomInputGroup size="sm"   onInput={onFilterTextBoxChanged} />
                    </div>
                    <div className="right-align">
                        <Button variant="outline-secondary" size="sm" onClick={addButton}>법규 및 변경 등록</Button>{' '}
                        <Button variant="outline-secondary" size="sm" onClick={delButton}>삭제</Button>{' '}
                        <Button variant="outline-success btn-excel" size="sm" disabled={excelStatus} onClick={() => setExcelStatus(true)}>
                            <FontAwesomeIcon icon={faFileExcel}/>
                            {CONSTANTS.excelDownload}
                        </Button>{' '}
                    </div>
                </div>
                
                {/*--------- Grid -----------*/}
                {langCombo && queryResult &&

                    <GridClcmList 
                    gridHeight={gridHeight}
                    filterValue={filterValue}
                    queryResult={queryResult}
                    limit={limit}
                    activePage={activePage}
                    onCellClicked={onCellClicked}
                    gridLangHeader={gridLangHeader}
                    checkRow={checkRow}
                    gridRef={gridRef}
                    />
                }

                {/*--------- 페이징 -----------*/}
                <Paging 
                    total={queryResult && queryResult.data && queryResult.data.length}
                    limit={limit}
                    activePage={activePage}
                    onChangePage={onChangePage}
                    onChangeLimit={onChangeLimit}
                />
            </div>
        </>
    )
};
export default ClcmList;