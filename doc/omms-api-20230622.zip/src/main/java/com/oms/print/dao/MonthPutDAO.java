package com.oms.print.dao;

import java.util.List;

import com.oms.print.dto.MonthPutInfosResDTO;
import com.oms.print.dto.MonthPutReqDTO;


/**
 * <pre>
 * Statements
 * </pre>
 * @ClassName : MonthPutDAO.java
 * @Description :
 * @author 김정웅
 * @since 2023. 6. 16.
 * @see
 */
public interface MonthPutDAO {

    List<MonthPutInfosResDTO> selectMonthPutList(MonthPutReqDTO dto);



}
