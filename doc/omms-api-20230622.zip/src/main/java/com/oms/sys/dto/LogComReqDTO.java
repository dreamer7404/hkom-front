package com.oms.sys.dto;

import org.apache.ibatis.type.Alias;

import com.oms.common.dto.CommReqDTO;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * <pre>
 * Statements
 * </pre>
 * @ClassName : LogComReqDTO.java
 * @Description :
 * @author 김경훈
 * @since 2023. 6. 19.
 * @see
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Alias("logComReqDTO")

public class LogComReqDTO   extends CommReqDTO{


    private String sDate;
    private String eDate;


}
