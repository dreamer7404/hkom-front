package com.oms.sys.service;

import java.util.List;

import com.oms.sys.dto.TestIvmTotalReqDTO;
import com.oms.sys.dto.TestIvmTotalResDTO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @author Windows ≫c¿eAU
 * @since 2023. 3. 13.
 * @see
 */

public interface TestService {
    public String testBatch() throws Exception;
    public List<TestIvmTotalResDTO> selectTotalIvmList(TestIvmTotalReqDTO testIvmTotalReqDTO) throws Exception;
}
