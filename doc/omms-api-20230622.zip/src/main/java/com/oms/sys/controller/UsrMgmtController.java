package com.oms.sys.controller;

import java.io.File;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import able.cloud.core.web.HController;

import org.apache.commons.validator.routines.EmailValidator;
import org.springframework.http.ResponseEntity;
import org.springframework.util.ResourceUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.util.HtmlUtils;

import com.oms.cmm.global.Consts;
import com.oms.cmm.utils.AES128;
import com.oms.cmm.utils.Utils;
import com.oms.common.dto.CommReqDTO;
import com.oms.common.dto.MailDTO;
import com.oms.common.model.Mail;
import com.oms.common.service.MailService;
import com.oms.sys.dto.AuthReqDTO;
import com.oms.sys.dto.AuthVehlSaveDTO;
import com.oms.sys.dto.UseYnReqDTO;
import com.oms.sys.dto.UsrMgmtReqDTO;
import com.oms.sys.dto.UsrMgmtResDTO;
import com.oms.sys.dto.UsrVehlResDTO;
import com.oms.sys.service.UsrMgmtService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;


/**
 * <pre>
 * UsrMgmt Controller
 * </pre>
 *
 * @ClassName   : UsrMgmtController.java
 * @Description : 클래스 설명을 기술합니다.
 * @author 안경수
 * @since 2023.1.19
 * @see
 */
@Slf4j
@Tag(name = "UsrMgmtController", description = "")
@RequiredArgsConstructor
@RestController
@RequestMapping("/api")
public class UsrMgmtController extends HController {

    private final HttpServletRequest request;
	private final UsrMgmtService usrMgmtService;
	private final MailService mailService;


	/**
     * 사용자 정보 등록, 수정, 삭제
     */
	@Operation(summary = "사용자 정보 등록,수정,삭제", description = "")
	@PostMapping(value = "/usrmgmt")
    public Integer insertUsrMgmt(@RequestBody UsrMgmtReqDTO usrMgmtReqDTO) {
	    int result = 0;
	    String pprrEeno = Utils.getUserEeno(request);
        String method = Utils.getMethod(request);
        String dlExpdCoCd = Utils.getDlExpdCoCd(request);
        try {
            // 등록
    	    if(method.equals(Consts.INSERT)) { // dto

    	        // 임시비번
    	        String userPw = Utils.createPassword();
    	        usrMgmtReqDTO.setUserPw(AES128.SHA256(userPw));

    	        // 이메일 인코딩
    	        usrMgmtReqDTO.setUserEmlAdr(usrMgmtReqDTO.getUserEmlAdr().replace("&#64;", "@"));

    	        // 작성자
    	        usrMgmtReqDTO.setPprrEeno(pprrEeno);

    	        // 사용자정보 등록(TB_USR_MGMT)
    	        result = usrMgmtService.insertUsrMgmt(usrMgmtReqDTO);

    	        if(result == 1  && usrMgmtReqDTO.getUsrVehls().size() > 0) {


        	        // 사용자에대한 차량권한정보 리스트 등록(TB_AUTH_VEHL)
        	        List<AuthVehlSaveDTO> list = new ArrayList<>();

//        	        list = usrMgmtReqDTO.getUsrVehls().stream()
//        	                .map(item -> item.getUserEeno()


        	        for(int i=0; i<usrMgmtReqDTO.getUsrVehls().size(); i++) {
        	            AuthVehlSaveDTO dto = usrMgmtReqDTO.getUsrVehls().get(i);
        	            list.add(new AuthVehlSaveDTO(usrMgmtReqDTO.getUserEeno(),  dto.getQltyVehlCd(),  dlExpdCoCd, pprrEeno));
        	        }
    	            result = usrMgmtService.insertVehlAuthList(list);
    	        }
    	    }
    	    // 수정
    	    else if(method.equals(Consts.UPDATE)) {

    	        // 이메일 인코딩
                usrMgmtReqDTO.setUserEmlAdr(usrMgmtReqDTO.getUserEmlAdr().replace("&#64;", "@"));

                // 작성자
                usrMgmtReqDTO.setPprrEeno(pprrEeno);

                // 사용자정보 수정(TB_USR_MGMT)
                result = usrMgmtService.updateUsrMgmt(usrMgmtReqDTO);
                if(result == 1 && usrMgmtReqDTO.getUsrVehls() != null) {

                    AuthVehlSaveDTO authDto = new AuthVehlSaveDTO();
                    authDto.setUserEeno(usrMgmtReqDTO.getUserEeno());
                    authDto.setUserEeno(dlExpdCoCd);
                    // 기존 권한차종 삭제
                    result = usrMgmtService.deleteVehlAuthList(authDto);

                    // 새로운 권한차종 등록
                    List<AuthVehlSaveDTO> list = new ArrayList<>();
                    for(int i=0; i<usrMgmtReqDTO.getUsrVehls().size(); i++) {
                        AuthVehlSaveDTO dto = usrMgmtReqDTO.getUsrVehls().get(i);
                        list.add(new AuthVehlSaveDTO(usrMgmtReqDTO.getUserEeno(), dto.getQltyVehlCd(), dlExpdCoCd, pprrEeno));
                    }
                    result = usrMgmtService.insertVehlAuthList(list);
                }

            }
    	    // 삭제
    	    else if(method.equals(Consts.DELETE)) {

            }
        }catch(Exception e) {

        }
	    return result;
    }

	@Operation(summary = "사용자 정보 조회")
	@GetMapping(value = "/usrmgmt/{id}")
	public UsrMgmtResDTO selectUsrMgmtById(@PathVariable("id") String id) throws Exception {
	    return usrMgmtService.selectUsrMgmt(id);
	}

	@Operation(summary = "사용자 정보 조회 - 본인")
    @GetMapping(value = "/usrmgmt")
    public UsrMgmtResDTO selectUsrMgmt() throws Exception {
	    return usrMgmtService.selectUsrMgmt(Utils.getUserEeno(request));
    }

	@Operation(summary = "사용자아이디 중복조회")
    @GetMapping(value = "/checkUserEeno/{id}")
    public Integer selectUsrMgmtEeno(@PathVariable("id") String id) throws Exception {
        UsrMgmtResDTO usr = usrMgmtService.selectUsrMgmt(id);
        return usr == null ? 1 : 0;
    }

	@Operation(summary = "사용자 목록을 조회")
	@GetMapping("/usrmgmts")
	public List<UsrMgmtResDTO> selectUsrMgmtList(@ModelAttribute UsrMgmtReqDTO usrMgmtReqDTO) throws Exception {
	    // 그룹코드 입력
	    String grpCd = Utils.getDlExpdGCd(request);
	    usrMgmtReqDTO.setGrpCd(grpCd);

	    // 관리자가 아니면 본인구분(회사코드, 현제/기아)를 입력한다.
	    if(!grpCd.equals("100")) {
	        usrMgmtReqDTO.setBlnsCoCd(Utils.getDlExpdCoCd(request));
	    }

	    List<UsrMgmtResDTO> list = usrMgmtService.selectUsrMgmtList(usrMgmtReqDTO);
	    return list;
	}

	@Operation(summary = "사용자 차종권한 리스트")
    @GetMapping(value = "/userVehls")
    public List<UsrVehlResDTO> selectUserVehlList() throws Exception {
	    CommReqDTO commReqDTO = new CommReqDTO();
	    commReqDTO.setUserEeno(Utils.getUserEeno(request));
	    commReqDTO.setDlExpdCoCd(Utils.getDlExpdCoCd(request));

        return usrMgmtService.selectUserVehlList(commReqDTO);
    }

	@Operation(summary = "사용자 & 차종권한 리스트")
    @GetMapping(value = "/usrAndVehls")
    public Map<String, Object> selectUserAndVehlList(@ModelAttribute CommReqDTO commReqDTO) throws Exception {
	    String coCd = Utils.getDlExpdCoCd(request);
	    commReqDTO.setDlExpdCoCd(coCd);

	    UsrMgmtResDTO usr = usrMgmtService.selectUsrMgmt(commReqDTO.getUserEeno());
        List<UsrVehlResDTO> list = usrMgmtService.selectUserVehlList(commReqDTO);

        Map<String, Object> map = new HashMap<>();
        map.put("user", usr);
        map.put("vehl", list);
        return map;
    }

	@GetMapping(value = "/testEmail")
	public int testEmail() {

	    int sendResult = 0;

	    try {
            //-------------- 이메일전송 ---------------------------------------
            MailDTO mailDTO = new MailDTO();
    //        mailDTO.setEmlId(usrMgmtReqDTO.getUserEeno()); // 이메일ID
            List<String> emlIds = new ArrayList<>();
            emlIds.add("9426036@ict-companion.com");
//            mailDTO.setEmlIds(emlIds);

            mailDTO.setSndrId("9426036"); // 발신자 사번
            mailDTO.setEmlTitl("[Owner’s Manual System] 초기화된 비밀번호입니다."); // 제목

            String content = Utils.getEmailContent("password");
            String body = HtmlUtils.htmlEscape(content.replace("{password}",  "1234"));
            mailDTO.setEmlSbc(body);  // 본문

            mailDTO.setAdreEml("9426036@ict-companion.com"); // 발신자 주소


            sendResult = mailService.send(mailDTO);
            //--------------// 이메일전송 ---------------------------------------

	    }catch(Exception e) {
	        e.printStackTrace();
	    }
	    return sendResult;

	}

	@Operation(summary = "비번 초기화 - 비밀번호 찾기")
    @PostMapping(value = "/initUserPw")
	public ResponseEntity<Map> updateUserPw(@RequestBody UsrMgmtReqDTO usrMgmtReqDTO)throws Exception {

	    Map<String, Object> resultMap = new HashMap<>();

	    // method 틀림
	    if(!Utils.getMethod(request).equals(Consts.UPDATE)) {
	        resultMap.put("result", -1); //
	        return ResponseEntity.ok().body(resultMap);
	    }

	    // 아이디 체크
	    UsrMgmtResDTO usrMgmtResDTO = usrMgmtService.selectUsrMgmt(usrMgmtReqDTO.getUserEeno());
	    if(usrMgmtResDTO == null) {
	        resultMap.put("result", -1); // 아이디틀림
            return ResponseEntity.ok().body(resultMap);
	    }

	    // 이름 체크(로그인전 비번 재발급시)
	    if(usrMgmtReqDTO.getUserNm() != null && !usrMgmtReqDTO.getUserNm().equals(usrMgmtResDTO.getUserNm())) {
	        resultMap.put("result", -1); // 이름틀림
            return ResponseEntity.ok().body(resultMap);
	    }

	    // 임시비번생성
        String userPw = Utils.createPassword();
        // 비번암호화
        usrMgmtReqDTO.setUserPw(AES128.SHA256(userPw));


        //-------------- 이메일전송 ---------------------------------------
        MailDTO mailDTO = new MailDTO();
//        mailDTO.setEmlId(usrMgmtReqDTO.getUserEeno()); // 이메일ID
        List<String> emlIds = new ArrayList<>();
        emlIds.add("9426036@ict-companion.com");
//        mailDTO.setEmlIds(emlIds);

        mailDTO.setSndrId(usrMgmtReqDTO.getUserEeno()); // 발신자 사번
        mailDTO.setEmlTitl("[Owner’s Manual System] 초기화된 비밀번호입니다."); // 제목

        String content = Utils.getEmailContent("password");
        String body = HtmlUtils.htmlEscape(content.replace("{password}",  userPw));
        mailDTO.setEmlSbc(body);  // 본문

        mailDTO.setAdreEml("9426036@ict-companion.com"); // 발신자 주소
        int sendResult = mailService.send(mailDTO);
        //--------------// 이메일전송 ---------------------------------------


        // 임시비번 DB저장
//        int result = usrMgmtService.updateUsrMgmt(usrMgmtReqDTO);
        resultMap.put("result", sendResult);
        return ResponseEntity.ok().body(resultMap);
	}

	@Operation(summary = "비번변경")
    @PostMapping(value = "/changeUserPw")
    public Integer changeUserPw(@RequestBody AuthReqDTO authReqDTO)throws Exception {

	    String userEeno = Utils.getUserEeno(request);
	    int result = 0;

	    if(Utils.getMethod(request).equals(Consts.UPDATE)) {

    	    // 사용자아이디 저장
            authReqDTO.setUserEeno(userEeno);

    	    // 기존 비밀번호 암호화
    	    String userPw = AES128.SHA256(authReqDTO.getUserPw());

    	    // get from db
            UsrMgmtResDTO usrMgmtResDTO = usrMgmtService.selectUsrMgmt(userEeno);
            if(usrMgmtResDTO == null) {
                   return -1; // 사용자 없음
            }

    	    // 비밀번호 비교
    	    if(!usrMgmtResDTO.getUserPw().equals(userPw)) {
    	        return -2; // 기존비번 틀림
    	    }

            // 새로운 비번암호화
    //        authReqDTO.setUserPw(AES128.SHA256(authReqDTO.getUserPw()));
            UsrMgmtReqDTO usrMgmtReqDTO = new UsrMgmtReqDTO();
            usrMgmtReqDTO.setUserEeno(authReqDTO.getUserEeno());
            usrMgmtReqDTO.setUserPw(AES128.SHA256(authReqDTO.getUserPwNew()));
            result = usrMgmtService.updateUsrMgmt(usrMgmtReqDTO);




            //메일 로직
        MailDTO mailDTO = new MailDTO(); //메일 DTO
//          List<String> emlIds = new ArrayList<>();
          List<Mail> rcvList = new ArrayList<Mail>();
          Mail mail = new Mail();
//          emlIds.add("9430105@ict-companion.com");
          mailDTO.setSndrId(usrMgmtReqDTO.getUserEeno()); // 발신자 사번
          mailDTO.setEmlTitl("[Owner’s Manual System] 내  계정의 최근 변경 사항."); // 제목

          String content = Utils.getEmailContent("password"); //바뀐 비밀번호 내용
          String body = HtmlUtils.htmlEscape(content.replace("{password}",  authReqDTO.getUserPwNew())); //비밀번호 html pharsing


          mailDTO.setEmlSbc(body);  // 본문 내용
          mailDTO.setAdreEml("9430105@ict-companion.com"); // 발신자 주소
          mailDTO.setEmlScdCd("13");


          //비밀번호 변경은 본인에게 메일이 날라감
          mail.setEmlId(Utils.getUserEeno(request)); //수신자는 현재 본인
          mail.setEmlAdr(usrMgmtResDTO.getUserEmlAdr()); //수신자는 본인 이메일
          rcvList.add(mail); //수신자 리스트에 담아서 넘김
          mailDTO.setRcvList(rcvList);


          int sendResult = mailService.send(mailDTO); //메일 로직 //dto에 수신자 array를 받아야함

          if(sendResult!=1) {
              result = -3; // 메일 발송에 문제가 있습니다.
          }
	    }

        return result;
    }

	@Operation(summary = "사용여부 변경")
    @PostMapping(value = "/changeUserUseYn")
    public Integer updateUserUseYn(@RequestBody UseYnReqDTO useYnReqDTO)throws Exception {
	    return usrMgmtService.updateUserUseYn(useYnReqDTO);
    }




}