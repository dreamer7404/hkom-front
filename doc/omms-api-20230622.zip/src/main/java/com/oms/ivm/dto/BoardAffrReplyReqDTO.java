package com.oms.ivm.dto;

import java.util.List;

import org.apache.ibatis.type.Alias;

import com.oms.common.dto.VehlMdyLangReqDTO;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @author 안경수
 * @since 2023. 6. 15.
 * @see
 */
@NoArgsConstructor
@Alias("boardAffrReplyReqDTO")
@Data
public class BoardAffrReplyReqDTO {

    private Long blcSn;
    private Long blcReplySn;
    private String blcReplySbc;
    private String delYn;
    private String pprrEeno;
    private String updrEeno;

}
