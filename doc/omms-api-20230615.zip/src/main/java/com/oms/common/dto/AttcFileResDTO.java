package com.oms.common.dto;

import java.sql.Timestamp;
import java.util.List;

import org.apache.ibatis.type.Alias;

import com.oms.common.model.Mail;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @author 안경수
 * @since 2023. 6. 13.
 * @see
 */
@NoArgsConstructor
@Data
@Alias("attcFileResDTO")
public class AttcFileResDTO {
    private Long attcSn;    // 첨부일련번호
//    private String attcGbn; //항목구분(0040)
//    private String gbnSn;  // 항목의게시물정보
//    private Long blcSn;  // 업무게시물번호
//    private String fileType;
    private String fileNm;
//    private String fileReNm;
//    private String filePath;
    private Integer fileSize;
//    private String pprrEeno;
//    private String framDtm;



}
