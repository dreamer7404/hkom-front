package com.oms.common.dto;

import org.apache.ibatis.type.Alias;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @author 안경수
 * @since 2023. 6. 7.
 * @see
 */
@NoArgsConstructor
@Alias("vehlMdyLangReqDTO")
@Data
public class VehlMdyLangReqDTO {
    private Long blcSn; // 게시판 pk
    private String qltyVehlCd;  // 차종코드
    private String mdlMdyCd;    // 연식
    private String langCd;      // 언어코드
    private String pprrEeno;

    public VehlMdyLangReqDTO(String qltyVehlCd, String mdlMdyCd, String langCd) {
        this.qltyVehlCd = qltyVehlCd;
        this.mdlMdyCd = mdlMdyCd;
        this.langCd = langCd;
    }
}
