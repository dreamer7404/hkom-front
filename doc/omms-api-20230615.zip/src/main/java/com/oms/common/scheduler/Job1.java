package com.oms.common.scheduler;

import java.util.Date;

import org.springframework.stereotype.Component;

import net.javacrumbs.shedlock.spring.annotation.EnableSchedulerLock;
import net.javacrumbs.shedlock.spring.annotation.SchedulerLock;

@Component
@EnableSchedulerLock(defaultLockAtMostFor = "PT4S")
public class Job1 {
//    @Scheduled(fixedRate = 5000)
    @SchedulerLock(name="SchedulerLock",lockAtMostFor = "PT4S", lockAtLeastFor = "PT4S")
    public void SchedulerTest() {
        System.out.println("1번 스케줄러"+new Date());
    }

}
