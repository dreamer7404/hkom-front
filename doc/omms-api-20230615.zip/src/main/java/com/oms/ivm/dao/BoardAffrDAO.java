package com.oms.ivm.dao;

import java.util.List;

import com.oms.common.dto.VehlMdyLangReqDTO;
import com.oms.common.dto.VehlMdyLangResDTO;
import com.oms.ivm.dto.BoardAffrRcvUsersSaveDTO;
import com.oms.ivm.dto.BoardAffrReplyReqDTO;
import com.oms.ivm.dto.BoardAffrReplyResDTO;
import com.oms.ivm.dto.BoardAffrReqDTO;
import com.oms.ivm.dto.BoardAffrResDTO;
import com.oms.ivm.dto.BoardRcvUsersResDTO;

/**
 * <pre>
 * BoardAffrDAO 인터페이스
 * </pre>
 *
 * @Class Name  : BoardAffrDAO.java
 * @Description : 재고관리 > 게시판
 * @author 안경수
 * @since 2023.6.1
 * @see
*/
public interface BoardAffrDAO {
    List<BoardAffrResDTO> selectBoardAffrMgmtList();
    BoardAffrResDTO selectBoardAffrMgmt(Long blcSn);
    int insertBoardAffrMgmt(BoardAffrReqDTO boardAffrReqDTO);
    int insertBoardAffrVehl(List<VehlMdyLangReqDTO> list);
    int insertBoardAffrRcvUsers(BoardAffrRcvUsersSaveDTO boardAffrRcvUsersSaveDTO);
    List<VehlMdyLangResDTO> selectBoardAffrVehl(Long blcSn);
    List<BoardRcvUsersResDTO> selectBoardAffrRcvUsers(Long blcSn);
    int insertBoardAffrReply(BoardAffrReplyReqDTO boardAffrReplyReqDTO);
    List<BoardAffrReplyResDTO> selectBoardAffrMgmtReplyList(Long blcSn);
}
