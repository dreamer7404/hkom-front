package com.oms.ivm.model;

import lombok.Data;

/**
 * <pre>
 * TotIvm VO
 * </pre>
 *
 * @Class Name : TotIvm.java
 * @Description : 총재고관리 엔티티
 * @author 김정웅
 * @since 2023.3.9
 * @see
 */

@Data
public class TotIvm{

    private String clScnCd;
    private String dataSn;
    private String qltyVehlCd;
    private String mdlMdyCd;
    private String langCd;
    private String langSortSn;
    private String dlExpdRegnCd;
    private String qltyVehlNm;
    private String langCdNm;
    private String dlExpdRegnNm;
    private String currOrdQty;
    private String prevOrdQty;
    private String mth3TrwiQty;
    private String day3PlanQty;
    private String wek2PlanQty;
    private String currMthTrwiQty;
    private String prev1DayTrwiQty;
    private String sewhaIvQty;
    private String sewhaPrntYn;
    private String pdiIvQty;
    private String dsid14Qty;
    private String wek2AftrIvQty;
    private String prntState;
    private String prntStateNm;
    private String ivSum;
    private String nPrntPbcnNo;
    private String plntDay3QtyText;
    private String plntWek2QtyText;
    private String plntYn;
    private String prdnPlntCd;
    private String chkState;


}
