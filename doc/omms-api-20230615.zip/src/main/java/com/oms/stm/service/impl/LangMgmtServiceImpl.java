package com.oms.stm.service.impl;

import java.util.List;

import able.cloud.core.service.HService;

import org.springframework.stereotype.Service;

import com.oms.stm.dao.LangMgmtDAO;
import com.oms.stm.dao.NatlMgmtDAO;
import com.oms.stm.dto.LangMgmtReqDTO;
import com.oms.stm.dto.LangMgmtResDTO;
import com.oms.stm.dto.NatlMgmtReqDTO;
import com.oms.stm.dto.NatlMgmtResDTO;
import com.oms.stm.dto.StmComReqDTO;
import com.oms.stm.service.LangMgmtService;
import com.oms.stm.service.NatlMgmtService;

import lombok.RequiredArgsConstructor;


/**
 * <pre>
 * Statements
 * </pre>
 * @ClassName : LangMgmtServiceImpl.java
 * @Description :
 * @author 김경훈
 * @since 2023. 5. 18.
 * @see
 */
@RequiredArgsConstructor
@Service("langMgmtService")
public class LangMgmtServiceImpl extends HService implements LangMgmtService {

    private final LangMgmtDAO langMgmtDAO;

    /*
     * @see com.oms.stm.service.LangMgmtService#selectLangList(com.oms.stm.dto.StmComReqDTO)
     */
    @Override
    public List<LangMgmtResDTO> selectLangList(StmComReqDTO dto) {

        return langMgmtDAO.selectLangList(dto);
    }

    /*
     * @see com.oms.stm.service.LangMgmtService#selectVehlLangRegList(com.oms.stm.dto.StmComReqDTO)
     */
    @Override
    public List<LangMgmtResDTO> selectVehlLangRegList(StmComReqDTO dto) {
        // TODO Auto-generated method stub
        return langMgmtDAO.selectVehlLangRegList(dto);
    }

    /*
     * @see com.oms.stm.service.LangMgmtService#selectLangMstList(com.oms.stm.dto.StmComReqDTO)
     */
    @Override
    public List<LangMgmtResDTO> selectLangMstList(StmComReqDTO dto) {
        // TODO Auto-generated method stub
        return langMgmtDAO.selectLangMstList(dto);
    }

    /*
     * @see com.oms.stm.service.LangMgmtService#selectTotVehlCdList(com.oms.stm.dto.StmComReqDTO)
     */
    @Override
    public List<LangMgmtResDTO> selectTotVehlCdList(StmComReqDTO dto) {
        // TODO Auto-generated method stub
        return langMgmtDAO.selectTotVehlCdList(dto);
    }

    /*
     * @see com.oms.stm.service.LangMgmtService#selectVehlLangCpList(com.oms.stm.dto.StmComReqDTO)
     */
    @Override
    public List<LangMgmtResDTO> selectVehlLangCpList(StmComReqDTO dto) {
        // TODO Auto-generated method stub
        return langMgmtDAO.selectVehlLangCpList(dto);
    }

    /*
     * @see com.oms.stm.service.LangMgmtService#LangMstValidChk(com.oms.stm.dto.LangMgmtReqDTO)
     */
    @Override
    public String LangMstValidChk(LangMgmtReqDTO dto) {
        // TODO Auto-generated method stub
        return langMgmtDAO.LangMstValidChk(dto);
    }

    /*
     * @see com.oms.stm.service.LangMgmtService#insertLangMst(com.oms.stm.dto.LangMgmtReqDTO)
     */
    @Override
    public int insertLangMst(LangMgmtReqDTO dto) {
       return langMgmtDAO.insertLangMst(dto);

    }

    /*
     * @see com.oms.stm.service.LangMgmtService#updateLangMst(com.oms.stm.dto.LangMgmtReqDTO)
     */
    @Override
    public int updateLangMst(LangMgmtReqDTO dto) {
        return langMgmtDAO.updateLangMst(dto);

    }

    @Override
    public int deleteLangMst(LangMgmtReqDTO dto) {
        return   langMgmtDAO.deleteLangMst(dto);

    }



    /*
     * @see com.oms.stm.service.LangMgmtService#deleteLangCdList(com.oms.stm.dto.LangMgmtReqDTO)
     */
    @Override
    public void deleteLangCdList(LangMgmtReqDTO dto) {
        langMgmtDAO.deleteLangCdList(dto);

    }

    /*
     * @see com.oms.stm.service.LangMgmtService#insertLangCdMgmt(com.oms.stm.dto.LangMgmtReqDTO)
     */
    @Override
    public int insertLangCdMgmt(LangMgmtReqDTO dto) {

        return langMgmtDAO.insertLangCdMgmt(dto);


    }

    /*
     * @see com.oms.stm.service.LangMgmtService#getLangMgmtChk(com.oms.stm.dto.LangMgmtReqDTO)
     */
    @Override
    public String getLangMgmtChk(LangMgmtReqDTO dto) {
        // TODO Auto-generated method stub
        return  langMgmtDAO.getLangMgmtChk(dto);
    }

    /*
     * @see com.oms.stm.service.LangMgmtService#insertLangCdOne(com.oms.stm.dto.LangMgmtReqDTO)
     */
    @Override
    public int insertLangCdOne(LangMgmtReqDTO dto) {

        return langMgmtDAO.insertLangCdOne(dto);

    }
    /*
     * @see com.oms.stm.service.LangMgmtService#updateLangCdMgmt(com.oms.stm.dto.LangMgmtReqDTO)
     */
    @Override
    public int updateLangCdMgmt(LangMgmtReqDTO dto) {

        return  langMgmtDAO.updateLangCdMgmt(dto);

    }

    /*
     * @see com.oms.stm.service.LangMgmtService#deleteLangCdMgmt(com.oms.stm.dto.LangMgmtReqDTO)
     */
    @Override
    public int deleteLangCdMgmt(LangMgmtReqDTO dto) {

        return langMgmtDAO.deleteLangCdMgmt(dto);
    }

    /*
     * @see com.oms.stm.service.LangMgmtService#selectLangDetail(java.lang.String)
     */
    @Override
    public LangMgmtResDTO selectLangDetail(String dataSn) {
        // TODO Auto-generated method stub
        return langMgmtDAO.selectLangDetail(dataSn);
    }

    /*
     * @see com.oms.stm.service.LangMgmtService#selectLangMstInfo(com.oms.stm.dto.StmComReqDTO)
     */
    @Override
    public LangMgmtResDTO selectLangMstInfo(StmComReqDTO dto) {
        // TODO Auto-generated method stub
        return langMgmtDAO.selectLangMstInfo(dto);
    }









}
