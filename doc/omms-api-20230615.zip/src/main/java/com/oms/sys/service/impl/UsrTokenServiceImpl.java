package com.oms.sys.service.impl;

import able.cloud.core.service.HService;

import org.springframework.stereotype.Service;

import com.oms.sys.dao.UsrTokenDAO;
import com.oms.sys.dto.UsrTokenReqDTO;
import com.oms.sys.dto.UsrTokenResDTO;
import com.oms.sys.service.UsrTokenService;

import lombok.RequiredArgsConstructor;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @author 안경수
 * @since 2023. 2. 24.
 * @see
 */
@RequiredArgsConstructor
@Service("usrTokenService")
public class UsrTokenServiceImpl extends HService implements UsrTokenService {

    private final UsrTokenDAO usrTokenDAO;

    @Override
    public UsrTokenResDTO selectUsrToken(UsrTokenReqDTO usrTokenReqDTO) throws Exception {
        return usrTokenDAO.selectUsrToken(usrTokenReqDTO);
    }

    @Override
    public Integer insertUsrToken(UsrTokenReqDTO usrTokenReqDTO) throws Exception {
        return usrTokenDAO.insertUsrToken(usrTokenReqDTO);
    }

    @Override
    public Integer updateUsrToken(UsrTokenReqDTO usrTokenReqDTO) throws Exception {
        return usrTokenDAO.updateUsrToken(usrTokenReqDTO);
    }


}
