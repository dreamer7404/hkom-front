package com.oms.sys.service;

import java.util.List;

import com.oms.sys.dto.UsrGrpMgmtReqDTO;
import com.oms.sys.dto.UsrGrpMgmtResDTO;
import com.oms.sys.dto.UsrMgmtReqDTO;


/**
 * <pre>
 * UsrGrpMgmtService
 * </pre>
 *
 * @ClassName   : UsrGrpMgmtService.java
 * @Description :
 * @author 안경수
 * @since 2023.4.18
 * @see
 */


public interface UsrGrpMgmtService {

    public List<UsrGrpMgmtResDTO> selectUsrGrpMgmtList() throws Exception;
    public Integer insertUsrGrpMgmt(UsrGrpMgmtReqDTO usrGrpMgmtReqDTO ) throws Exception;
    public Integer updateUsrGrpMgmt(UsrGrpMgmtReqDTO usrGrpMgmtReqDTO ) throws Exception;
    public UsrGrpMgmtResDTO selectUsrGrpMgmt(UsrGrpMgmtReqDTO usrGrpMgmtReqDTO ) throws Exception;
}
