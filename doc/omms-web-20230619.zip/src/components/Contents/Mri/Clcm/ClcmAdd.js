// react
import React, {useState, useMemo, useCallback, useRef} from 'react';
import { AgGridReact } from 'ag-grid-react';
import {Button,Modal, Row, Col, Table} from 'react-bootstrap';
// rsuite
import {Form, SelectPicker, Schema, Notification, toaster } from 'rsuite';
import { escapeCharChange} from '../../../../utils/commUtils';
import PersonSearch from '../../../Search/PersonSearch';
import VehlLangCascader from '../../../Search/VehlLangCascader'
import { confirmAlert } from 'react-confirm-alert'; // Import
import ConfirmAlert from '../../../Common/ConfirmAlert';

import { DEXT5Editor } from 'dext5editor-react';
import { DEXT5Upload } from 'dext5upload-react';


//--------------  서버데이터용 필수 -------------------------------
import { useQuery, useMutation} from 'react-query';
import { getData, postData } from '../../../../utils/async';
import { API, CONSTANTS } from '../../../../utils/constants';
import useStore from '../../../../utils/store';
import { useEffect } from 'react';
//--------------// 서버데이터용 필수 -------------------------------

const { StringType, NumberType,  ArrayType, ObjectType, BooleanType } = Schema.Types;
const model = Schema.Model({
    dsppNm: StringType().isRequired('발신처를 입력해주세요.')
                            .rangeLength(2, 30, '2-30자로 입력해주세요'),
    crgrNm: StringType().isRequired('담당자를 입력해주세요.')
                            .rangeLength(2, 30, '2-30자로 입력해주세요'),    
    altrTitl:StringType().isRequired('제목을 입력해주세요.')
                            .rangeLength(2, 30, '2-30자로 입력해주세요'),
    altrSbc:StringType().isRequired('내용을 입력해주세요.'),
    langCdByVehlListVali: StringType().pattern(/^[ok]+$/, '차종 및 언어를 선택해주세요.'),
    senderListVali: StringType().pattern(/^[ok]+$/, '송부인을 선택해주세요.'),
});



const ClcmAdd = () => {
    
    const gridRef = useRef();

    //수신형태 
    const rcpmShapParam = {dlExpdGCd: '0010'};
    const rcpmShapCombo = useQuery([API.codeCombo,rcpmShapParam], () => getData(API.codeCombo,rcpmShapParam), {
        select: data => data.map((item) => (item&&{ label: item.label, value: item.value }))
    })
    const [selectedRcpmShapCombo, setSelectedRcpmShapCombo] = useState('01')
    const onChangeRcpmShapCombo = e => {
        setSelectedRcpmShapCombo(e)
    }
    
    //등록자
    const usrmgmt = useQuery([API.usrmgmt], () => getData(API.usrmgmt));

    //발신처
    const [dsppNm, setDsppNm] = useState('')
    const onChangeDsppNm = e =>{
        setDsppNm(e)
    }

    //담당자
    const [crgrNm, setCrgrNm] = useState('')
    const onChangeCrgrNm = e =>{
        setCrgrNm(e)
    }
        
    
    //차종 및 언어
    const [selectedLangCdByVehl, setSelectedLangCdByVehl] = useState([]);
    const columnDefs = [
        {
          headerName: '차종',
          field: 'qltyVehlNm',
        },
        {
          headerName: '언어',
          field: 'langCdNm',
        },
    ]
    const [firstRender, setFirstRender] = useState(false)
    useEffect(() => {
        if(selectedLangCdByVehl.length > 0){
            setFirstRender(true)
            setFormValue(formValue => ({...formValue, langCdByVehlListVali:'ok'}))
            setFormError(formError => ({...formError, langCdByVehlListVali:''}))
        } else {
            setFormValue(formValue => ({...formValue, langCdByVehlListVali:'no'}))
            setFormError(formError => ({...formError, langCdByVehlListVali:'차종 및 언어를 선택해주세요.'}))
        }
    }, [selectedLangCdByVehl])

    //송부인
    const usrData = useQuery([API.userMgmtPop,{blnsCoCd:'01'}], () => getData(API.userMgmtPop, {blnsCoCd:'01'}), {
        select: data => data.map(item => ({...item, coDeptNm: item.coNm+'('+item.deptNm+')'}))
    })
    //송부인 그리드 내에서 클릭된 RowData by Woong
    const [checkedRowData, setCheckedRowData] = useState();
    const onSelectionChanged = useCallback(() => {
        const selectedRows = gridRef.current.api.getSelectedRows();
        setCheckedRowData(selectedRows)
        if(selectedRows.length > 0){
            setFormValue(formValue => ({...formValue, senderListVali:'ok'}))
            setFormError(formError => ({...formError, senderListVali:''}))
        } else {
            setFormValue(formValue => ({...formValue, senderListVali:'no'}))
            setFormError(formError => ({...formError, senderListVali:'송부인을 선택해주세요.'}))
            // formRef.current.check()
        }
    }, []);

    //제목
    const [altrTitl, setAltrTitl] = useState('')
    const onChangeAltrTitl = e => {
        setAltrTitl(e)
    }

    //내용
    const [altrSbc, setAltrSbc] = useState('')
    const onChangeAltrSbc = e => {
        setAltrSbc(e)
    }

    const columnDefs2 = [
        {
          checkboxSelection: true,
          headerCheckboxSelection: true,
          width:45,
          maxWidth:45,
          minWidth:45
        },
        {
          headerName: '소속',
          field: 'coDeptNm',
        },
        {
          headerName: '이름',
          field: 'userNm',
        },
    ]

    const onFirstDataRendered = (params) => {
        params.api.sizeColumnsToFit();
    };

    // Form 정의 (for validation..)
    const formRef = React.useRef();
    const [formError, setFormError] = React.useState({});
    const [formValue, setFormValue] = React.useState({
        rcpmShapCd: '',               // 수신형태
        userEeno: '',                 // 등록자
        dsppNm: '',                   // 발신처
        crgrNm: '',                   // 담당자
        langCdByVehlListVali: 'no',   // 선택한 차종및언어 리스트(mutate 하기전에 가공필요..)
        senderListVali: 'no',         // 선택한 송부인 리스트
        altrTitl:'',                   // 제목
        altrSbc:'',                   // 내용
    });
    
    const reqBody = {
        rcpmShapCd: selectedRcpmShapCombo,          // 수신형태
        chgrEeno: usrmgmt.data&& usrmgmt.data.userEeno,            // 등록자
        dsppNm: dsppNm,                             // 발신처
        crgrNm: crgrNm,                             // 담당자
        langCdByVehlList: selectedLangCdByVehl,     // 선택한 차종및언어 리스트(mutate 하기전에 가공필요..)
        senderList: checkedRowData,                 // 선택한 송부인 리스트
        altrTitl:altrTitl,                          // 제목
        altrSbc:altrSbc,                            // 내용
    };

    //데이터 등록(post)
    const submitResult = useMutation((params => postData(API.mriClcmInfoPop, params, CONSTANTS.insert)),{
        onSuccess: res => {
		    if(res > 0){
                toaster.push(
                    <Notification type='success' header='요청성공' closable >저장이 완료되었습니다.</Notification>
                );
                // window.location.href="./ClcmDetail"
                setTimeout(() => listButton(), 1000)
            }else{
                toaster.push(
                    <Notification type='error' header='요청실패' closable >저장을 실패했습니다.</Notification>
                );
            }
        }
    });

    const saveButton = () => {
        setFirstRender(true)
        if (!formRef.current.check()) {
            return;
        } else {
            const onOk = () => {
                submitResult.mutate(reqBody)
            }
            confirmAlert({
                closeOnClickOutside: false,
                customUI: ({ onClose }) => <ConfirmAlert 
                                                onClose={onClose} 
                                                title={"알림"}
                                                msg={"입력하신 내용으로 저장하시겠습니까?"} 
                                                onOk={onOk}  
                                            />
            })
        }
    }

    const listButton = () => {
        // window.location.href="./clcmList"
        window.location.href="."
    }

     // DEXT5UPLOAD component 로드 지연
     const [showLoad, setShowLoad ] = useState(false)
     useEffect(() => {
         setTimeout(() => setShowLoad(true), 500);
     },[]);
 
     // 파일업로드후 리턴값
     const onTransferComplete = e => {
         const fileList = DEXT5UPLOAD.GetAllFileListForJson("dext5upload1");
         setFileInfo(fileList)
     }
 
     // 파일추가 전 처리할 내용
     const onBeforeAddItem = e => {
         if(!checkUploadFileType(e.eventInfo.paramObj)){
             confirmAlert({
                 closeOnClickOutside: false,
                 customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}  title={"알림"} msg={"업로드 할 수 없는 파일형식 입니다."}  />
             });
             return false;
         }
         return true;
     }

    return (
        <>
                        
            {/* <h2>{JSON.stringify(formError)}</h2>
            <br></br>
            <h2>{JSON.stringify(formValue)}</h2> */}
            
            <div className="grid-wrap">
                <Form
                    ref={formRef}
                    checkTrigger="change"
                    onChange={setFormValue}
                    onCheck={setFormError}
                    formValue={formValue}
                    model={model}
                >
                    <Table className="tbl-hor" bordered>
                        <colgroup>
                            <col style={{width:'15%'}}></col>
                            <col style={{width:'35%'}}></col>
                            <col style={{width:'15%'}}></col>
                            <col style={{width:'35%'}}></col>
                        </colgroup>
                        <tbody>
                            <tr>
                                <th>수신형태</th>
                                <td>
                                    {rcpmShapCombo && selectedRcpmShapCombo &&
                                    <SelectPicker 
                                        size="sm" 
                                        data={rcpmShapCombo&&rcpmShapCombo.data}
                                        onChange={onChangeRcpmShapCombo} 
                                        value={selectedRcpmShapCombo!==undefined?selectedRcpmShapCombo:'01'} 
                                        searchable={false} 
                                        cleanable={false} 
                                    />
                                    }
                                </td>
                                <th>등록자</th>
                                <td>{usrmgmt.isSuccess && usrmgmt.data && usrmgmt.data.userNm}</td>
                            </tr>
                            <tr>
                                <th>발신처</th>
                                <td>
                                    <Form.Control name="dsppNm" onChange={onChangeDsppNm} size="sm" type="text" placeholder="발신처를 입력해주세요" value={dsppNm} />
                                </td>
                                <th>담당자</th>
                                <td>
                                    <Form.Control name="crgrNm" onChange={onChangeCrgrNm} size="sm" type="text" placeholder="담당자를 입력해주세요" value={crgrNm} />
                                    {/* <PersonSearch rmCheck={true} onChangeCrgrEeno={onChangeCrgrEeno} /> */}
                                </td>
                            </tr>
                            <tr>
                                <th>차종 및 언어</th>
                                <td colSpan="3">
                                    {/* <MultiCascader className="multi-cascader"
                                    size="sm"
                                    menuWidth={250}
                                    style={{fontSize:'12px', width:'100%'}}
                                    placeholder="차종 및 언어를 선택해주세요"
                                    // data={options}
                                    data={langCdByVehlCombo}
                                    renderMenu={(children, menu, parentNode, layer) => {
                                    return (
                                        <div>
                                        <div
                                            style={{
                                            background: '#f8f8f8',
                                            padding: '4px 10px',
                                            color: ' #000',
                                            textAlign: 'center',
                                            fontSize:'12px',
                                            fontWeight:600
                                            }}
                                        >
                                            {headers[layer]}
                                        </div>
                                        {menu}
                                        </div>
                                    );
                                    }} 
                                    /> */}
                                    
                                    <VehlLangCascader setSelectedLangCdByVehl={setSelectedLangCdByVehl} formErrorStatus={formError.langCdByVehlListVali} firstRender={firstRender} />
                                </td>
                            </tr>
                            <tr>
                                <th>적용 차종 및 언어</th>
                                <td>
                                    <div className="ag-theme-alpine" style={{height: 230, transition:'all ease .3s'}}>
                                        <AgGridReact
                                            initialWidth={90}
                                            sortable={true}
                                            // defaultColDef={defaultColDef}
                                            columnDefs={columnDefs}
                                            rowData={selectedLangCdByVehl}
                                            onFirstDataRendered={onFirstDataRendered}
                                            suppressSizeToFit={true}    
                                            onGridSizeChanged={onFirstDataRendered}    
                                            overlayNoRowsTemplate={'적용차종 및 언어를 선택하세요.'}
                                            >
                                        </AgGridReact>
                                    </div>
                                </td>
                                <th>
                                    송부인
                                    <Form.ErrorMessage show={formError.senderListVali} style={{fontWeight: 400}}>
                                        {formError.senderListVali}
                                    </Form.ErrorMessage>
                                </th>
                                
                                <td>
                                    <div className="ag-theme-alpine" style={{height: 230, transition:'all ease .3s'}}>
                                        {usrData && usrData.isSuccess &&
                                            <AgGridReact
                                            ref={gridRef}
                                            initialWidth={90}
                                            sortable={true}
                                            // defaultColDef={defaultColDef}
                                            rowData={usrData && usrData.isSuccess &&usrData.data}
                                            columnDefs={columnDefs2}
                                            rowSelection={'multiple'}
                                            suppressRowClickSelection= {true} 
                                            onFirstDataRendered={onFirstDataRendered}
                                            suppressSizeToFit={true}    
                                            onGridSizeChanged={onFirstDataRendered}
                                            // checkedRowDatas by Woong
                                            onSelectionChanged={onSelectionChanged}
                                            
                                            >
                                            </AgGridReact>
                                        }
                                    </div>
                                </td>
                            </tr>
                            <tr>
                                <th>제목</th>
                                <td colSpan="3">
                                    <Form.Control size="sm" name="altrTitl" type="text" placeholder="제목을 입력해주세요" value={altrTitl} onChange={onChangeAltrTitl} />
                                </td>
                            </tr>
                            <tr>
                                <th>내용</th>
                                <td colSpan="3">
                                    {/* <Form.Control size="sm" name="altrSbc" placeholder="DEXT5Editor 적용전.." value={altrSbc} onChange={onChangeAltrSbc} /> */}

                                    <DEXT5Editor
                                        debug={true}
                                        id="editor1"
                                        componentUrl="/dext5editor/js/dext5editor.js"
                                        config={{ DevelopLangage:'NONE', Width:'100%' }}
                                    />
                                </td>
                            </tr>
                            <tr>
                                <th>첨부파일</th>
                                <td colSpan="3">
                                    {showLoad && <DEXT5Upload
                                        // onCreationComplete={onCreationComplete}
                                        onTransferComplete={onTransferComplete}
                                        onBeforeAddItem={onBeforeAddItem}
                                        debug={false}
                                        id="dext5upload1"
                                        mode='edit' 
                                        // mode='view'  // view Mode
                                        runtimes='html5'
                                        componentUrl="/dext5upload/js/dext5upload.js"
                                        config={{MaxTotalFileSize:'100MB', MaxOneFileSize:'30MB', DevelopLangage:'NONE',
                                        ButtonBarEdit: "add,remove,remove_all",
                                        // ButtonBarView: 'download,download_all', // view Mode
                                        Width:'100%'}}
                                        
                                    />}
                                </td>
                            </tr>
                        </tbody>
                    </Table>
                </Form>
                <div className="btn-wrap">
                    <div className="right-align">
                        <Button variant="light" onClick={listButton}>취소</Button>{' '}
                        <Button className="" variant="primary" size="md" onClick={saveButton}>저장</Button>
                    </div>
                </div>
            </div>
        </>
    )
};
export default ClcmAdd;