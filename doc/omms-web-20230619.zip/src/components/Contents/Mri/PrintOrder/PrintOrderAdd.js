import React, {useState, useEffect, useCallback} from 'react';
import {Row, Col, Button, Collapse, Table} from 'react-bootstrap';
import {Form, CustomProvider, DatePicker, InputGroup, Input, SelectPicker, Schema, Notification, toaster} from 'rsuite';
import SearchIcon from '@rsuite/icons/Search';
import AttachmentIcon from '@rsuite/icons/Attachment';
import { utcToLocalDate } from '../../../../utils/commUtils';
import { confirmAlert } from 'react-confirm-alert'; // Import
import ConfirmAlert from '../../../Common/ConfirmAlert';
import { formatNumber, escapeCharChange } from '../../../../utils/commUtils';
import isBefore from 'date-fns/isBefore';
import qs from 'qs';
import { useLocation } from 'react-router';

import ko from 'rsuite/locales/ko_KR';

//--------------  서버데이터용 필수 -------------------------------
import { useQuery, useMutation} from 'react-query';
import { getData, postData } from '../../../../utils/async';
import { API,CONSTANTS } from '../../../../utils/constants';
import useStore from '../../../../utils/store';
import VehlTypeForPop from '../../../Search/VehlTypeForPop';
import LangForPop from '../../../Search/LangForPop';
import ComCombo from '../../../Search/ComCombo';
import OutsourcingCombo from '../../../Search/OutsourcingCombo';

//--------------// 서버데이터용 필수 -------------------------------

import GridPrintOrderAdd from '../_Grid/GridPrintOrderAdd';
import GridPrintOrderClcmList from '../_Grid/GridPrintOrderClcmList';
import PrintArrayTable from '../Popup/PrintArrayTable';
// import PrintArrayTableTest from '../Popup/PrintArrayTableTest';
// import PrintArrayTableTest2 from '../Popup/PrintArrayTableTest2';
import PrintPbcn from '../Popup/PrintPbcn';


const { StringType, NumberType, MixedType } = Schema.Types;
const model = Schema.Model({
    qltyVehlCd: StringType().isRequired('차종(연식)은 기존번호 선택을 통해 입력가능합니다.'),
    langCd: StringType().isRequired('언어는 기존번호 선택을 통해 입력가능합니다.'),
    prntParrQty: NumberType('숫자만 입력해주세요.').isRequired('인쇄부수를 입력해주세요.'),
    newPrntPbcnNo: StringType().isRequired('신규번호를 입력하세요.')
                            .pattern(/[A-Z0-9]{4}-[A-Z0-9]{5}/, '형식에 맞게 입력해주세요 ex) AAAA-AB12C')
                            .addRule((value, data) => {
                                return value!==data.oldPrntPbcnNo;
                            }, '신규번호와 기존번호를 다르게 입력하세요.'),
    prtlImtrSbc: StringType().isRequired('메모를 입력해주세요.')
                            .rangeLength(0, 500, '최대 500자로 입력해주세요'), 
    pgMgnSbc: StringType().isRequired('사이즈를 입력해주세요.'),
    pgNl: NumberType('숫자만 입력해주세요.').isRequired('내지 총 페이지를 입력해주세요.'),
    oordEditPgNl: NumberType('숫자만 입력해주세요.').isRequired('외주 편집수량을 입력해주세요.'),
    grnDocNl: NumberType('숫자만 입력해주세요.').isRequired('보증서/엽서 수량을 입력해주세요.'),
});

const PrintOrderAdd = () => {
    
    //------------------- 필수 공통 ------------------------------
    const [open, setOpen] = useState(true); // 조건창 열기/닫기
    const {keyword } = useStore();  // 조회키워드 가져오기

    const [activePage, setActivePage] = useState(1);    // 페이지번호
    const [limit, setLimit] = useState(50);             // 페이지행수
    const [filterValue, setFilterValue] = useState(''); // 필터값

    const onChangePage = val => {
        setActivePage(val);
    };
    const onChangeLimit = val => {
        setLimit(val);
    };
    useEffect(()=>{
        onChangePage(1); // 페이지번호 리셋
    },[keyword]);

    // 필터
    const onFilterTextBoxChanged = useCallback((e) => {
        setFilterValue(e.target.value);
    }, []);

    // 검색창 열기/닫기 > 페이지네이션 여부에 따라 +-20px
    const gridExpand = () =>{
        setOpen(!open);
    }

    // 차종콤보 컴포넌트 내에서 선택된 파라미터
    const [vehlParams, setVehlParams] = useState({
        dlExpdPdiCd: '',
        qltyVehlCd: '',
        mdlMdyCd: ''
    });    
    const onChangeVehlParam = e => {
        setVehlParams(e)
    };

    // 언어콤보 컴포넌트 내에서 선택된 파라미터
    const [langParams, setLangParams] = useState({
        dlExpdRegnCd : '',
        langCd : ''
    });    
    const onChangeLangParam = e => {
        setLangParams(e)
    };
    
    const param = {
        bDate: utcToLocalDate(new Date()),
        dlExpdPdiCd: vehlParams.dlExpdPdiCd,
        qltyVehlCd: vehlParams.qltyVehlCd,
        mdlMdyCd: vehlParams.mdlMdyCd,
        dlExpdRegnCd: langParams.dlExpdRegnCd,
        langCd: langParams.langCd
    }
    //  ivmTotal 조회
    const paramIvmTotal = {
        bDate: utcToLocalDate(new Date()),
        dlExpdPdiCd: vehlParams.dlExpdPdiCd,
        qltyVehlCd: vehlParams.qltyVehlCd,
        mdlMdyCd: vehlParams.mdlMdyCd,
        dlExpdRegnCd: langParams.dlExpdRegnCd,
        langCd: langParams.langCd,
        subCd: 'ALL',
    }
    const queryTotResult = useQuery([API.ivmTotIvInfos, paramIvmTotal], () => getData(API.ivmTotIvInfos, paramIvmTotal),{
        enabled: false
    });
    const queryClcmResult = useQuery([API.printOrderClcmInfos, paramIvmTotal], () => getData(API.printOrderClcmInfos, paramIvmTotal),{
        enabled: false,
        select: data => data.map(item => ({...item, altrSbc:escapeCharChange(item.altrSbc)}))
    });
    const queryPrntPbcnNoResult = useQuery([API.printOrderPrntPbcnNoInfos, paramIvmTotal], () => getData(API.printOrderPrntPbcnNoInfos, paramIvmTotal),{
        enabled: false
    });
    //-------------------// 필수 공통 ------------------------------

    // 차종 및 언어선택 유효성검사
    const searchParamVali = () => {
        let check = false
        let msg = '';
        if(paramIvmTotal.dlExpdPdiCd === 'ALL') {
            msg = '차종을 선택하세요.';
        } else if(paramIvmTotal.qltyVehlCd === 'ALL') {
            msg = '차종을 선택하세요.';
        } else if(paramIvmTotal.mdlMdyCd === 'ALL') {
            msg = '연식을 선택하세요.';
        } else if(paramIvmTotal.dlExpdRegnCd === 'ALL') {
            msg = '언어지역을 선택하세요.';
        } else if(paramIvmTotal.langCd === 'ALL') {
            msg = '언어를 선택하세요.';
        } else {
            check = true
        }

        if(check){
            return true
        } else {
            confirmAlert({
                closeOnClickOutside: false,
                customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}  title={"알림"} msg={msg}  />
            })
            return false
        }
    }
    const listButton = () => {
        window.location.href="."
    }

    // 조회버튼
    const onSearch = () => {
        if(searchParamVali()){
            queryTotResult.refetch(); // 수동쿼리실행
            queryClcmResult.refetch();  
        }
    };

    const location = useLocation();
    const [query, setQuery] = useState(
        qs.parse(location.state, { ignoreQueryPrefix: true }),
    )
    useEffect(() => {
        if(query && Object.keys(query).length > 0){
            setSelectedPrntPbcnNo(query)
            setTimeout((onSearch), 500)
        }
    }, [query])

    // 그리드 내에서 체크된 rows by Woong
    const [checkedRows, setCheckedRows] = useState([]);    
    const checkRow = e => {
        setCheckedRows(e)
    };
    useEffect(() => {
        setReqBody(reqBody => ({...reqBody, checkedRows:checkedRows}))
    }, [checkedRows])
    // 셀 클릭
    const onCellClicked = e => {
        if(e.column.colId === 'altrTitl'){
            alert('첨부 클릭')
        }
    };

    const CustomInputGroupWidthButton = () => (
        <InputGroup inside >
            <Input 
                style={{fontSize:'12px'}} 
                name="oldPrntPbcnNo" 
                value={
                    selectedPrntPbcnNo && selectedPrntPbcnNo.trtmRstCd 
                    ?
                    selectedPrntPbcnNo.trtmRstCd === '05'
                        ? selectedPrntPbcnNo.oldPrntPbcnNo
                        : selectedPrntPbcnNo.newPrntPbcnNo
                    :
                    selectedPrntPbcnNo.newPrntPbcnNo
                } 
                readOnly
            />
            <InputGroup.Button style={{height:'24px'}} onClick={() => printPbcnPopVali()}>
            <SearchIcon />
            </InputGroup.Button>
        </InputGroup>
    );
    
    //인쇄배열표 검색
    const [printArrayTablePop, setPrintArrayTablePop] = useState(false);
    const printArrayTablePopVali = e => {
        if(searchParamVali()){
            if(reqBody.newPrntPbcnNo === ''){
                confirmAlert({
                    closeOnClickOutside: false,
                    customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}  title={"알림"} msg={'신규번호를 입력해주세요.'}  />
                })
                return false            
            } else {
                setPrintArrayTablePop(true)
            }
        }
    }

    //발간번호 검색
    const [printPbcnPop, setPrintPbcnPop] = useState(false);
    const printPbcnPopVali = e => {
        if(searchParamVali()){
            queryPrntPbcnNoResult.refetch();
            setPrintPbcnPop(true)
        }
    }

    //발간번호 별 세부내역
    const [selectedPrntPbcnNo, setSelectedPrntPbcnNo] = useState({});
    const queryPrintOrderDetailResult = useQuery([API.printOrderReqInfo, selectedPrntPbcnNo], () => getData(API.printOrderReqInfo, selectedPrntPbcnNo),{
        enabled: false
    });
    useEffect(() => {
        queryPrintOrderDetailResult.remove()
        if(Object.keys(selectedPrntPbcnNo).length > 0){
            queryPrintOrderDetailResult.refetch();
        }
    }, [selectedPrntPbcnNo])

    // Form 정의 (for validation..)
    const formRef = React.useRef();
    const [formError, setFormError] = React.useState({});
    /** reqBody */
    const [reqBody, setReqBody] = useState({
        qltyVehlCd : ''
        , langCd : ''
        , mdlMdyCd: ''
        , prntParrYmd : param.bDate
        , dlvgParrYmd : param.bDate
        , iwayCd : ''               //발행구분
        , prntParrQty : ''          //인쇄부수
        , prntWayCd : ''            //인쇄방법(3도 등..)
        , prntWayCd2 : ''           //인쇄방법(옵셋1도 등..)
        , depq1Cd: ''               //인쇄방법(73재생지 등..)
        , newPrntPbcnNo: ''         //신규번호
        , oldPrntPbcnNo: ''         //기존번호
        , prtlImtrSbc: ''           //메모
        , pgMgnSbc: ''              //SIZE
        , pgNl: ''                  //내지 총 페이지
        , oordEditPgNl: ''          //외주업체(외주편집)
        , oordEditCoCd: ''          //외주편집 업체
        , grnDocNl: ''              //보증서/엽서 수량
        , mdfyPgNl: ''              //수정페이지
        , depc1Yn: ''               //커버 사용유무
        , state: ''                //임시저장, O/M발주 구분값(S:임시저장, Q:O/M발주)

    })
    //납품요청일 입력
    const onChangeDlvgParrYmd = val => {
        setReqBody(reqBody => ({...reqBody, dlvgParrYmd : utcToLocalDate(val) }))
    }
    useEffect(() => {
        if(queryPrintOrderDetailResult.isSuccess){
            setReqBody(reqBody => ({...reqBody
                , qltyVehlCd : queryPrintOrderDetailResult.data.qltyVehlCd          //차종코드
                , langCd : queryPrintOrderDetailResult.data.langCd                  //언어코드
                , mdlMdyCd : queryPrintOrderDetailResult.data.mdlMdyCd              //연식
                , iwayCd : queryPrintOrderDetailResult.data.iwayCd                  //발행구분
                , prntParrQty : queryPrintOrderDetailResult.data.prntParrQty        //인쇄부수
                , prntWayCd : queryPrintOrderDetailResult.data.prntWayCd            //인쇄방법(3도 등..)
                , prntWayCd2 : queryPrintOrderDetailResult.data.prntWayCd2          //인쇄방법(옵셋1도 등..)
                , depq1Cd: queryPrintOrderDetailResult.data.depq1Cd                 //인쇄방법(73재생지 등..)
                , newPrntPbcnNo: selectedPrntPbcnNo && selectedPrntPbcnNo.trtmRstCd && selectedPrntPbcnNo.trtmRstCd === '05' ? selectedPrntPbcnNo.newPrntPbcnNo :''                                                //신규번호
                , oldPrntPbcnNo: selectedPrntPbcnNo && selectedPrntPbcnNo.trtmRstCd && selectedPrntPbcnNo.trtmRstCd === '05' ? selectedPrntPbcnNo.oldPrntPbcnNo :queryPrintOrderDetailResult.data.newPrntPbcnNo     //기존번호
                , prtlImtrSbc: escapeCharChange(queryPrintOrderDetailResult.data.prtlImtrSbc)         //메모
                , pgMgnSbc: escapeCharChange(queryPrintOrderDetailResult.data.pgMgnSbc)               //SIZE
                , pgNl: queryPrintOrderDetailResult.data.pgNl                       //내지 총 페이지
                , oordEditPgNl: queryPrintOrderDetailResult.data.oordEditPgNl       //외주업체(외주편집)
                , oordEditCoCd: queryPrintOrderDetailResult.data.oordEditCoCd       //외주편집 업체
                , grnDocNl: queryPrintOrderDetailResult.data.grnDocNl               //보증서/엽서수량
                , mdfyPgNl: queryPrintOrderDetailResult.data.mdfyPgNl               //수정페이지
                , depc1Yn: queryPrintOrderDetailResult.data.depc1Yn                 //커버 사용유무
                , blcSn: queryPrintOrderDetailResult.data.blcSn                     //게시판 관리번호
                , dataSn: queryPrintOrderDetailResult.data.dataSn
                , state: ''                                                        //임시저장, O/M발주 구분값(S:임시저장, Q:O/M발주)
            }))
        }
    }, [queryPrintOrderDetailResult.status])

    const onChangeReqBody = (e, colName) => {
        //입력된 값과 컬럼명을 받아서 reqBody 값을 갱신한다.
        setReqBody(reqBody => ({...reqBody, [colName]:e}))
    }
    const parentCompSetValue = (value, mainCd) => {
        if(mainCd === '0024'){
            onChangeReqBody(value, 'iwayCd')  //발행구분
        }
        if(mainCd === '0025'){
            onChangeReqBody(value, 'prntWayCd') //인쇄방법(3도 등..)
        }
        if(mainCd === '0029'){
            onChangeReqBody(value, 'prntWayCd2') //인쇄방법(옵셋1도 등..)
        }
        if(mainCd === '0026'){
            onChangeReqBody(value, 'depq1Cd') //인쇄방법(73재생지 등..)
        }
        if(mainCd === '0011'){
            onChangeReqBody(value, 'oordEditCoCd') //외주편집업체
        }
    }

    //데이터 등록(post)
    const submitResult = useMutation((params => postData(API.printOrderInfo, params, CONSTANTS.insert)),{
        onSuccess: res => {
		    if(res !== 99 && res > 0){
                toaster.push(
                    <Notification type='success' header='요청성공' closable >저장이 완료되었습니다.</Notification>
                );
                // window.location.href="./ClcmDetail"
                setTimeout(() => listButton(), 1000)
            }else if(res === 99){
                toaster.push(
                    <Notification type='error' header='요청실패' closable >중복된 신규번호입니다.</Notification>
                );
            }else{
                toaster.push(
                    <Notification type='error' header='요청실패' closable >저장을 실패했습니다.</Notification>
                );
            }
        }
    });
    const saveButton = (state) => {
        let newReqBody = reqBody;
        newReqBody.state = state;
        let msg = '';
        if(state === 'S'){
            msg = '입력하신 내용을 임시저장 하시겠습니까?'
            
        } else {
            msg = '입력하신 내용을 O/M발주 하시겠습니까?'
        }
        // validation 체크
        if (!formRef.current.check()) {
            return;
        }
        const onOk = () => {
            setTimeout(submitResult.mutate(newReqBody), 500)
        }
        confirmAlert({
            closeOnClickOutside: false,
            customUI: ({ onClose }) => <ConfirmAlert 
                                            onClose={onClose} 
                                            title={"알림"}
                                            msg={msg} 
                                            onOk={onOk}  
                                        />
        })
    }

    return (
        <>
            <div className="search-area">
                <Collapse in={open}>
                    <div className="form" id="example-collapse-text">
                        <div className="search-group">
                            <div className="row">
                                <Col sm={5} className="" >
                                    <VehlTypeForPop onChangeVehlParam={onChangeVehlParam} preVehlParam={query} />
                                </Col>
                                <Col sm={4} className="" >
                                    <LangForPop onChangeLangParam={onChangeLangParam} vehlParams={vehlParams} preLangParam={query}/>
                                </Col>
                            </div>
                            <div className="search-btn-wrap">
                                <Button className="btn-search" variant="outline-primary" size="sm" onClick={onSearch}><SearchIcon />조회</Button>
                            </div>
                        </div>
                    </div>
                </Collapse>
                <Button size="sm" variant="outline-dark" className="search-control" aria-controls="example-collapse-text" 
                    aria-expanded={open} onClick={gridExpand}>
                    <span className={open === true ? "search-area-close" : "search-area-open"}>{open === true ? CONSTANTS.closeSearch : CONSTANTS.openSearch}</span>
                </Button>
            </div>
            
            <div className="grid-wrap">
                <div className="grid-btn-wrap">
                    <div className="left-align">
                        <div className="sub-title">
                            <ul>
                                <li>발간실적 기준정보</li>
                            </ul>
                        </div>
                    </div>
                </div>
                {/*--------- Grid -----------*/}
                {queryTotResult && 
                    <GridPrintOrderAdd 
                    filterValue={filterValue}
                    queryResult={queryTotResult}
                    limit={limit}
                    activePage={activePage}
                    />
                }


                <div className="write-wrap">
                    <Form
                        ref={formRef}
                        checkTrigger="change"
                        // onChange={(a,b,c,d) => {console.log(a,b,c,d)}}
                        onCheck={setFormError}
                        formValue={reqBody}
                        model={model}
                    >
                        <div className="grid-btn-wrap mt-4">
                            <div className="left-align">
                                <div className="sub-title">
                                    <ul>
                                        <li>세부내역</li>
                                    </ul>
                                </div>
                            </div>
                            <div className="right-align">
                                <Button className="" variant="outline-secondary" size="sm" onClick={printArrayTablePopVali}>인쇄배열표</Button>
                            </div>
                        </div>

                        <Table className="tbl-ver" bordered>
                            <colgroup>
                                <col style={{width:'6%'}}></col>
                                <col style={{width:'9%'}}></col>
                                <col style={{width:'6%'}}></col>
                                <col style={{width:'6%'}}></col>
                                <col style={{width:'6%'}}></col>
                                <col style={{width:'6%'}}></col>
                                <col style={{width:'9%'}}></col>
                                <col style={{width:'6%'}}></col>
                                <col style={{width:'8%'}}></col>
                                <col style={{width:'9%'}}></col>
                                <col style={{width:'30%'}}></col>
                            </colgroup>
                            <tbody>
                                <tr className="thead-row">
                                    <th className="essen" colSpan="2">차종/언어</th>
                                    <th className="essen" colSpan="2"> 의뢰일/납품요청일</th>
                                    <th className="essen" colSpan="2">발행구분/인쇄부수</th>
                                    <th className="essen" colSpan="2">인쇄방법</th>
                                    <th className="essen" colSpan="2">발간번호</th>
                                    <th>메모</th>
                                </tr>
                                <tr className="thead-row">
                                    <td colSpan="2">
                                        {Object.keys(selectedPrntPbcnNo).length !== 0 && selectedPrntPbcnNo.qltyVehlCd +'(' + selectedPrntPbcnNo.qltyVehlNm + ')-' +selectedPrntPbcnNo.mdlMdyCd}
                                        <div style={{color: 'red'}}>{formError && formError.qltyVehlCd}</div>
                                    </td>
                                    
                                    {/* <td colSpan="2">{queryPrintOrderDetailResult && queryPrintOrderDetailResult.data && queryPrintOrderDetailResult.data.prntParrYmd
                                    ?queryPrintOrderDetailResult.data.prntParrYmd:param.bDate}</td> */}
                                    <td colSpan="2">{param.bDate}</td>
                                    <td colSpan="2">
                                        {/* <SelectPicker size="sm" data={[{ label: "신제작"}]} searchable={false} cleanable={false} /> */}
                                        <ComCombo
                                            title={''}
                                            mainCd={'0024'}
                                            useAll={false}
                                            updatedValue={queryPrintOrderDetailResult && queryPrintOrderDetailResult.data && queryPrintOrderDetailResult.data.iwayCd}
                                            parentCompSetValue={parentCompSetValue}

                                        />
                                        {/* 옵션 >> 신제작, 개정발행, 추가제작, 스티커, 리플렛, 퀵가이드, 기타 */}
                                    </td>
                                    <td colSpan="2">
                                        <Row className="select-wrap">
                                            <Col>
                                                {/* <SelectPicker size="sm" data={[{ label: "없음"}]} searchable={false} cleanable={false} /> */}
                                                <ComCombo
                                                    title={''}
                                                    mainCd={'0025'}
                                                    useAll={false}
                                                    updatedValue={queryPrintOrderDetailResult && queryPrintOrderDetailResult.data && queryPrintOrderDetailResult.data.prntWayCd}
                                                    parentCompSetValue={parentCompSetValue}
                                                />
                                                {/* 옵션 >> 없음, 1도, 2도, 3도, 4도, 5도 */}
                                            </Col>
                                            <Col>
                                                {/* <SelectPicker size="sm" data={[{ label: "옵셋1도"}]} searchable={false} cleanable={false} /> */}
                                                <ComCombo
                                                    title={''}
                                                    mainCd={'0029'}
                                                    useAll={false}
                                                    updatedValue={queryPrintOrderDetailResult && queryPrintOrderDetailResult.data && queryPrintOrderDetailResult.data.prntWayCd2}
                                                    parentCompSetValue={parentCompSetValue}
                                                />
                                                {/* 옵션 >> 옵셋1도, 옵셋2도, 디지털1도, 스티커1도, 스티커2도, 리플렛1도, 리플렛2도, 옵셋4도, 인디고 */}
                                            </Col>
                                        </Row>
                                    </td>
                                    <th className="essen">신규번호</th>
                                    <td>
                                        <Form.Control 
                                            size="sm" 
                                            type="text" 
                                            name="newPrntPbcnNo" 
                                            onChange={e => onChangeReqBody(e, 'newPrntPbcnNo')} 
                                            placeholder={reqBody.oldPrntPbcnNo==='' && '기존번호 선택 후 입력'} 
                                            disabled={reqBody.oldPrntPbcnNo===''}
                                            defaultValue={
                                                selectedPrntPbcnNo && selectedPrntPbcnNo.trtmRstCd && selectedPrntPbcnNo.trtmRstCd === '05'
                                                ? selectedPrntPbcnNo.newPrntPbcnNo
                                                : ''
                                            }
                                        />
                                    </td>
                                    <td rowSpan="2">
                                        {/* <Form.Control name="textarea" accepter={Textarea} style={{height:'100%'}} /> */}
                                        <Input as="textarea" name="prtlImtrSbc" rows={3} style={{height:'100%'}} value={reqBody.prtlImtrSbc && escapeCharChange(reqBody.prtlImtrSbc)} onChange={e => onChangeReqBody(e, 'prtlImtrSbc')}/>
                                        
                                    </td>
                                </tr>
                                <tr className="thead-row">
                                    <td colSpan="2">
                                        {Object.keys(selectedPrntPbcnNo).length !== 0 && selectedPrntPbcnNo.langCd +'(' + selectedPrntPbcnNo.langCdNm + ')'}
                                        <div style={{color: 'red'}}>{formError && formError.langCd}</div>
                                    </td>
                                    <td colSpan="2">
                                        <CustomProvider locale={ko}>
                                                <DatePicker disabledDate={date => {let now = new Date(); return isBefore(date, new Date(now.setDate(now.getDate() - 1)))}} oneTap onChange={onChangeDlvgParrYmd} cleanable={false} size="sm" defaultValue={new Date()} className="inline-block" style={{width:'150px'}}/>
                                        </CustomProvider>
                                    </td>
                                    <td colSpan="2">
                                        <Form.Control 
                                            size="sm" type="text" name="prntParrQty" onChange={e => onChangeReqBody(e, 'prntParrQty')} value={reqBody.prntParrQty} />
                                    </td>
                                    <td colSpan="2">
                                        <ComCombo
                                            title={''}
                                            mainCd={'0026'}
                                            useAll={false}
                                            updatedValue={queryPrintOrderDetailResult && queryPrintOrderDetailResult.data && queryPrintOrderDetailResult.data.depq1Cd}
                                            parentCompSetValue={parentCompSetValue}
                                        />
                                        {/* <SelectPicker size="sm" data={[{ label: "80화인코드지"}]} searchable={false} cleanable={false} /> */}
                                        {/* 옵션 >> 80화인코드지, 70모조지, 73그린매트지 */}
                                    </td>
                                    <th>기존번호</th>
                                    <td><CustomInputGroupWidthButton size="sm" /></td>
                                </tr>
                                <tr className="thead-row">
                                    <th>의뢰자</th>
                                    <th>SIZE</th>
                                    <th>표지</th>
                                    <th>내지</th>
                                    <th>내지 총 페이지</th>
                                    <th>외주업체</th>
                                    <th>외주편집 업체</th>
                                    <th>보증서/엽서</th>
                                    <th>수정페이지</th>
                                    {/* <th>커버{queryPrintOrderDetailResult && queryPrintOrderDetailResult.data && queryPrintOrderDetailResult.data.depc1Yn}</th> */}
                                    <th>커버</th>
                                    <th>게시판 관리번호</th>
                                </tr>
                                <tr className="thead-row">
                                    <td>{queryPrintOrderDetailResult && queryPrintOrderDetailResult.data && escapeCharChange(queryPrintOrderDetailResult.data.crgrEenoNm)}</td>
                                    <td>
                                        <Form.Control name="pgMgnSbc" size="sm" type="text" placeholder="예) 210*148mm" onChange={e => onChangeReqBody(e, 'pgMgnSbc')} value={reqBody.pgMgnSbc} />
                                    </td>
                                    <td>
                                        첨부파일
                                    </td>
                                    <td>
                                        첨부파일
                                    </td>
                                    <td>
                                        <Form.Control name="pgNl" size="sm" type="text" placeholder="" onChange={e => onChangeReqBody(e, 'pgNl')} value={reqBody.pgNl}/>
                                    </td>
                                    <td>
                                        <Form.Control name="oordEditPgNl" size="sm" type="text" placeholder="" onChange={e => onChangeReqBody(e, 'oordEditPgNl')} value={reqBody.oordEditPgNl}/>
                                    </td>
                                    <td>
                                        <OutsourcingCombo 
                                            title=''
                                            updatedValue={queryPrintOrderDetailResult && queryPrintOrderDetailResult.data && queryPrintOrderDetailResult.data.oordEditCoCd}
                                            parentCompSetValue={parentCompSetValue}
                                        />
                                        {/* <SelectPicker size="sm" data={[{ label: "없음"}]} searchable={false} cleanable={false} /> */}
                                        {/* 옵션 >> TLA 등... */}
                                    </td>
                                    <td>
                                        <Form.Control size="sm" name="grnDocNl" type="text" placeholder="" onChange={e => onChangeReqBody(e, 'grnDocNl')} value={reqBody.grnDocNl}/>
                                    </td>
                                    <td>
                                        {queryPrintOrderDetailResult && queryPrintOrderDetailResult.data && '총 '+escapeCharChange(queryPrintOrderDetailResult.data.mdfyPgNl) + ' page'}
                                    </td>
                                    <td>
                                        <SelectPicker 
                                            size="sm" 
                                            data={[{ label: "사용", value: "Y"}, { label: "사용안함", value: "N"}]} 
                                            onChange={depc1Yn => onChangeReqBody(depc1Yn, 'depc1Yn')} 
                                            //defaultValue={reqBody && reqBody.depc1Yn !== ''?queryPrintOrderDetailResult.data.depc1Yn:'N'}
                                            searchable={false} 
                                            cleanable={false} 
                                            //value={queryPrintOrderDetailResult && queryPrintOrderDetailResult.data && queryPrintOrderDetailResult.data.depc1Yn}
                                            value={reqBody.depc1Yn !== ''?reqBody.depc1Yn:'N'}
                                        />
                                        {/* 옵션 >> 사용:Y, 사용안함:N */}
                                    </td>
                                    <td>
                                        <Form.Control size="sm" type="text" placeholder="" onChange={e => onChangeReqBody(e, 'blcSn')} value={reqBody.blcSn}/>
                                    </td>
                                </tr>
                            </tbody>
                        </Table>

                        <div className="grid-btn-wrap mt-4">
                            <div className="left-align">
                                <div className="sub-title">
                                    <ul>
                                        <li>개정내용</li>
                                    </ul>
                                </div>
                            </div>
                        </div>

                        <GridPrintOrderClcmList 
                            queryResult={queryClcmResult}
                            limit={limit}
                            activePage={activePage}
                            onCellClicked={onCellClicked}
                            checkRow={checkRow}
                            thisNewPrntPbcnNo={
                                selectedPrntPbcnNo && selectedPrntPbcnNo.trtmRstCd && selectedPrntPbcnNo.trtmRstCd === '05'
                                    ? selectedPrntPbcnNo.newPrntPbcnNo
                                    : ''
                            }
                        />
                        
                    </Form>
                </div>

                <div className="btn-wrap">
                    <div className="left-align">
                        <Button variant="light" onClick={() => listButton()}>목록</Button>{' '}
                    </div>
                    <div className="right-align">
                        <Button variant="outline-secondary" size="md" onClick={() => saveButton('S')}>임시저장</Button>{' '}
                        <Button className="" variant="primary" size="md" onClick={() => saveButton('Q')}>O/M발주</Button>
                    </div>
                </div>

            </div>
            {queryPrntPbcnNoResult &&
                // 아래 인쇄배열표(PrintArrayTable) 컴포넌트 호출시 필수값 : newPrntPbcnNo, lrnkCd, qltyVehlCd, mdlMdyCd, langCd 총 5개 파라미터(param={필수값Obj})가 넘어가야함..
                // readOnly 여부에 따라 인쇄배열표 內에서 '체크박스' 및 '저장' 버튼 제어함. (true : 수정불가, false, 수정가능)
                <PrintArrayTable show={printArrayTablePop} onHide={() => setPrintArrayTablePop(false)} param={reqBody} readOnly={false}  />
            }
            {queryPrntPbcnNoResult && 
                <PrintPbcn show={printPbcnPop} onHide={() => setPrintPbcnPop(false)} queryResult={queryPrntPbcnNoResult} setSelectedPrntPbcnNo={setSelectedPrntPbcnNo} />
            }
        </>
    )
};
export default PrintOrderAdd;