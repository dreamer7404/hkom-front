import React, {useState, useMemo, useEffect} from 'react';
import { AgGridReact } from 'ag-grid-react';
import {Button, Modal, Table} from 'react-bootstrap';
import {Form} from 'rsuite';
import CustomModal from '../../../Common/CustomModal';
import * as XLSX from 'xlsx';
import { API, CONSTANTS } from '../../../../utils/constants';
import { useMutation} from 'react-query';
import { postData } from '../../../../utils/async';
import { confirmAlert } from 'react-confirm-alert'; // Import
import ConfirmAlert from '../../../Common/ConfirmAlert';
const NatLangUpload = ({show, onHide}) => {
    
    
    const [files,setFiles] = useState(null);
    const [rowData, setRowData] = useState();
    
   
    const columnDefs = [
        {
          headerName: '국가코드',
          field: 'dlExpdNatCd',
        },
        {
          headerName: '차종코드',
          field: 'qltyVehlCd',
        },
        {
          headerName: '연식',
          field: 'mdlMdyCd',
        },
        {
          headerName: '언어코드',
          field: 'langCd',
          maxWidth:'80',
        },
        {
          headerName: '사용여부',
          field: 'useYn',
          maxWidth:'80',
        },
    ]

    const defaultColDef = useMemo(() => {
        return {
            initialWidth: 90,
            sortable: true,
            resizable:true,
        };
    }, []);

    const onFirstDataRendered = (params) => {
        params.api.sizeColumnsToFit();
    };


    //에러시 초기화 
    const reFresh=()=>{
        setFiles(null);
        setRowData();
        
    }
    //파일 업로드
    const onChangeEvent=(e)=>{
        console.log("test",e);
        console.log("e.target.files",e.target.files);
        setFiles(e);
        
        var file = e.target.value;
        var ext = file.substring(file.lastIndexOf(".") + 1);

        if(file == "" || file == null){
            alert("파일을 선택해 주세요.");       
            e.target.value="";     
            reFresh();
            return;
     
        }else if(!(ext == "xls" || ext == "xlsx")){
            
            alert("엑셀 파일만 업로드해 주세요.");
            reFresh();
            e.target.value="";
            return;                
        }
    
        
    }


    //엑셀 업로드
    const uploadExcel= ()=>{
        const reader = new FileReader();
        reader.onload = (evt) => {
            const bstr = evt.target.result;
            const wb = XLSX.read(bstr, { type: "binary" });
            const wsname = wb.SheetNames[0];
            const ws = wb.Sheets[wsname];
            const data = XLSX.utils.sheet_to_json(ws); //시트내용 json으로 치환
            

            //헤더가 한글이기때문에 바꿈
            setRowData(data.map(p=>({
                dlExpdNatCd : p.국가코드,
                qltyVehlCd : p.차종코드,
                useYn : p.사용여부,
                langCd : p.언어코드,
                mdlMdyCd : p.연식
                })
            ))
        }
        reader.readAsBinaryString(files.target.files[0])

    }

     // 저장버튼 클릭
     const handleSubmit = () => {

        if(files == "" || files == null){
            confirmAlert({
                closeOnClickOutside: false,
                customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}  title={"알림"} msg={"업로드할 데이터가 없습니다."}  />
            });
        }
        else{
            confirmAlert({
                closeOnClickOutside: false,
                customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}   title={"알림"}
                msg={"저장하시겠습니까?"} 
                onOk={onOk}  />
            });
        }
      
    };
    const excelUpload = useMutation((params => postData(API.natlExcelUpload, params, CONSTANTS.insert)),{
        onSuccess: res => {
           if(res>0){
                confirmAlert({
                    closeOnClickOutside: false,
                    customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}   title={"알림"}
                    msg={"저장이 완료되었습니다."}   />
                    
                });
           }else{
            confirmAlert({
                closeOnClickOutside: false,
                customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}   title={"알림"}
                msg={"에러가 발생했습니다 관리자에게 문의해주세요."}   />
                
            });
           }
           onHide();
        }
    });


    const onOk = () => {
        const excelDataList = {excelDataList : rowData}
       
        excelUpload.mutate(excelDataList);
    }
   

    return (
        <>
            <Form>
             
                        <CustomModal open={show} 
                            title={'국가별 언어등록(액셀 업로드)'}
                            size='lg'
                            // handleOk={handleSubmit}
                            handleCancel={onHide} 
                        >
                            <div className="grid-btn-wrap">
                                <div className="right-align">
                                    {/*--------- 버튼 -----------*/}
                                    <Button variant="outline-secondary" size="sm">Sample</Button>{' '}
                                    <Button variant="outline-secondary" size="sm" onClick={uploadExcel}>업로드</Button>{' '}
                                </div>
                            </div>
                            <Table className="tbl-hor" bordered>
                                <colgroup>
                                    <col style={{width:'30%'}}></col>
                                    <col style={{width:''}}></col>
                                </colgroup>
                                <tbody>
                                    <tr>
                                        <th className="essen">첨부파일</th>
                                        <td>
                                            <input type="file" multiple={true} id="fileUpload" onChange={onChangeEvent}/>
                                        </td>
                                    </tr>
                                </tbody>
                            </Table>
                            <div className="ag-theme-alpine mt-10" style={{height:300, minWidth:300}}>
                            <AgGridReact
                                rowData={rowData}
                                columnDefs={columnDefs}
                                defaultColDef={defaultColDef}
                                rowSelection={'multiple'}
                                suppressRowClickSelection= {true} 
                                onFirstDataRendered={onFirstDataRendered}
                                suppressSizeToFit={true}    
                                onGridSizeChanged={onFirstDataRendered}     
                                >
                            </AgGridReact>
                        </div>
                        <div className='modal-footer'>
                            <Button variant="light" size="md" onClick={onHide}>취소</Button>
                            <Button variant="primary" size="md" onClick={handleSubmit} >저장</Button>
                        </div> 
                    </CustomModal>
            </Form>
        </>
    );

};
export default NatLangUpload;