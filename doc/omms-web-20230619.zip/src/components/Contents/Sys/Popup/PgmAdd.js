import React, {useState, useEffect} from 'react';
import {Button, Modal, Table} from 'react-bootstrap';
import {Form, SelectPicker, Schema} from 'rsuite';
//--------------  서버데이터용 필수 -------------------------------
import { useQuery, useQueryClient, useMutation} from 'react-query';
import { getData, postData } from '../../../../utils/async';
import { API, CONSTANTS } from '../../../../utils/constants';
import useStore from '../../../../utils/store';
//--------------// 서버데이터용 필수 -------------------------------
import { confirmAlert } from 'react-confirm-alert'; 
import ConfirmAlert from   '../../../Common/ConfirmAlert';  

const { StringType} = Schema.Types;
const model = Schema.Model({
    apiUrl: StringType().isRequired('API URL을 입력해주세요.')
                            .maxLength(30, '30자로 이내로 입력해주세요'),
    apiNm: StringType().isRequired('API설명을 입력해주세요.')
                            .maxLength(30, '30자로 이내로 입력해주세요'),
    menuId: StringType().isRequired('해당되는 메뉴를 선택해주세요.'),
    method: StringType().isRequired('API타입을 선택해주세요.'),
});

const PgmAdd = ({show, onHide}) => {

    const [menuData, setMenuData] = useState([]);

    const queryResult = useQuery([API.pgmMgmtsAll], () => getData(API.pgmMgmtsAll));

    useEffect(() => {
        if(queryResult.data){
            const grpList = queryResult.data.grpList;
            setMenuData(
                [{label: '공통', value: '9999', group: '공통'}].concat(
                queryResult.data.menuList
                .map(item => ({
                    label: item.pgmNm, 
                    value: item.menuId, 
                    group: grpList.find(f => f.pgmId === item.pgmId).pgmNm }))));
        }
    },[queryResult.data]);

     // Form 정의
     const formRef = React.useRef();
     const [formError, setFormError] = React.useState({});
     const [formValue, setFormValue] = React.useState({
        apiUrl: '',
        apiNm: '',
        menuId: '',
        method: '',
     });


    const addMutate = useMutation((params => postData(API.apiMgmt, params, CONSTANTS.insert)),{
        onSuccess: res => {
            if(res === 1){
                confirmAlert({
                    closeOnClickOutside: false,
                    customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}  title={"알림"} msg={"저장이 완료되었습니다."}  />
                })
                onHide(); // 창닫기 & refetch
            }else if(res === -2){
                confirmAlert({
                    closeOnClickOutside: false,
                    customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}  title={"알림"} msg={"해당 API URL은 이미 등록되었습니다."}  />
                })
            }else{
                confirmAlert({
                    closeOnClickOutside: false,
                    customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}  title={"알림"} msg={"등록이 실패했습니다.<br /> 관리자에게 문의해주세요."}  />
                })
            }
        }
    }); 

     // 저장버튼 클릭
    const handleSubmit = () => {
        console.log('asdfasdfasdfasdf')
        // validation 체크
        if (!formRef.current.check()) {
            return;
        }
        console.log('formValue', formValue)
        // API 등록 실행
        addMutate.mutate(formValue);
    };
 


    return (
        <>
            <Form
             ref={formRef}
             checkTrigger="change"
             onChange={setFormValue}
             onCheck={setFormError}
             formValue={formValue}
             model={model}>
                <Modal show={show} onHide={onHide} backdrop="static" keyboard={false} centered size="md" className="modal-custom">
                    <Modal.Header closeButton>
                        <Modal.Title>프로그램(API) 등록</Modal.Title>
                    </Modal.Header>
                        <Modal.Body>
                            <Table className="tbl-hor" bordered>
                                <colgroup>
                                    <col style={{width:'30%'}}></col>
                                    <col style={{width:''}}></col>
                                </colgroup>
                                <tbody>
                                    <tr>
                                        <th className="essen">API URL</th>
                                        <td>
                                            <Form.Control name="apiUrl" size="sm" type="text"/> 
                                        </td>
                                    </tr>
                                    <tr>
                                        <th className="essen">API 설명</th>
                                        <td colSpan="3">
                                            <Form.Control name="apiNm" size="sm" type="text"/> 
                                        </td>
                                    </tr>
                                    <tr>
                                        <th className="essen">메뉴명</th>
                                        <td>
                                        <Form.Control name="menuId" size="sm" 
                                                placeholder={'선택'}
                                                accepter={SelectPicker} 
                                                searchable={false}
                                                cleanable={false}
                                                data={menuData && menuData}
                                                groupBy="group"
                                                renderMenuGroup={(label, item) => {
                                                    return (
                                                      <div>
                                                        <i className="rs-icon rs-icon-group" /> <strong>{label}</strong> - ({item.children.length}개)
                                                      </div>
                                                    );
                                                  }}
                                            ></Form.Control>
                                        </td>
                                    </tr>
                                    <tr>
                                        <th className="essen">API 타입</th>
                                        <td colSpan="3">
                                        <Form.Control name="method" size="sm" 
                                                placeholder={'선택'}
                                                accepter={SelectPicker} 
                                                searchable={false}
                                                cleanable={false}
                                                data={[
                                                    {label: 'GET', value: 'GET'},
                                                    {label: 'POST', value: 'POST'},
                                                ]}
                                            ></Form.Control>
                                        </td>
                                    </tr>
                                </tbody>
                            </Table>
                        </Modal.Body>


                        <Modal.Footer>
                            <Button variant="light" size="md" onClick={onHide}>취소</Button>
                            <Button variant="primary" size="md" onClick={handleSubmit} >저장</Button>
                        </Modal.Footer>
                </Modal>
            </Form>
        </>
    );

};
export default PgmAdd;