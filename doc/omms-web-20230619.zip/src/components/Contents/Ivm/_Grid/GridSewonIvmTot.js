import React, {useEffect, useMemo, useRef, useCallback} from 'react';
import { AgGridReact } from 'ag-grid-react';
import { CONSTANTS } from '../../../../utils/constants';
import { formatNumber, escapeCharChangeForGrid } from '../../../../utils/commUtils';

const GridSewonIvmTot = ({gridHeight, filterValue, queryResult, limit, activePage, onCellClicked, checkRow}) => {

  const gridRef = useRef();

  // 수량 천단위 콤마 찍기 시작
  const currencyFormatter = (params) => {
    return formatNumber(params.value);
  };

  const columnDefs = [
    {
      checkboxSelection: true,
      headerCheckboxSelection: true,
      spanHeaderHeight: true,
      width:45,
      maxWidth:45,
      minWidth:45,
      sortable: false
    },
    {
      headerName: '차종',
      headerClass: 'rowSpan-2T rowSpan',
      rowspan: 2,
      children: [
        { headerName:'차종코드', field: 'qltyVehlCd', spanHeaderHeight: true},
        { headerName:'차종명', field: 'qltyVehlNm', spanHeaderHeight: true, cellRenderer:"escapeCharChangeForGrid", cellStyle:() => ({textAlign: 'left'})},
        { headerName:'연식', field: 'mdlMdyCd', spanHeaderHeight: true },
      ],
    },
    {
      headerName: '언어',
      children: [
        { headerName:'지역', field: 'dlExpdRegnNm', spanHeaderHeight: true},
        { headerName:'언어코드', field: 'langCd', spanHeaderHeight: true },
        { headerName:'언어명', field: 'langCdNm', spanHeaderHeight: true, cellStyle:() => ({textAlign: 'left'}) },
      ],
    },
    {
      headerName: '생산계획\n(2주)',
      field: 'wek2PlanQty',
      spanHeaderHeight: true,
      cellStyle: () => ({textDecoration: 'underline', cursor: 'pointer', color:'#2589f5'}),
      valueFormatter: currencyFormatter
    },  
    {
      headerName: '단기계획\n(3일)',
      field: 'day3PlanQty',
      spanHeaderHeight: true,
      cellStyle: () => ({textDecoration: 'underline', cursor: 'pointer', color:'#2589f5'}),
      valueFormatter: currencyFormatter
    },  
    {
      headerName: '당월투입\n(누적)',
      field: 'currMthTrwiQty',
      spanHeaderHeight: true,
      cellStyle: () => ({textDecoration: 'underline', cursor: 'pointer', color:'#2589f5'}),
      valueFormatter: currencyFormatter
    },
    {
      headerName: '전일투입\n(D-1)',
      field: 'prev1dayTrwiQty',
      spanHeaderHeight: true,
      valueFormatter: currencyFormatter
    },
    {
      headerName: '재고현황',
      children: [
        { headerName:'세원',
          children: [
              { headerName:'인쇄중', field: 'dlExpdTmpIvQty',  cellRenderer: "LinkComponent", cellStyle: () => ({textDecoration: 'underline', cursor: 'pointer', color:'#2589f5'}), valueFormatter: currencyFormatter},
              { headerName:'보유재고', field: 'sewonIvQty', cellRenderer: "LinkComponent", cellStyle: () => ({textDecoration: 'underline', cursor: 'pointer', color:'#2589f5'}), valueFormatter: currencyFormatter },
              { headerName:'배송중', field: 'sewonDlvyQty', valueFormatter: currencyFormatter },
          ],
        },
        { headerName:'PDI/용산', field: 'pdiDeei1Qty', spanHeaderHeight: true,  cellRenderer: "LinkComponent", cellStyle: () => ({textDecoration: 'underline', cursor: 'pointer', color:'#2589f5'}) ,valueFormatter: currencyFormatter },
        { headerName:'입고확인', field: 'expdWhsnStNm', spanHeaderHeight: true, },
      ],
    },
    {
        headerName: '예상재고\n(3일)',
        field: 'dsid3Qty',
        spanHeaderHeight: true,
        valueFormatter: currencyFormatter
    },
    {
        headerName: '예상재고\n(2주)',
        field: 'wek2AftrIvQty',
        spanHeaderHeight: true,
        valueFormatter: currencyFormatter
    },
    {
        headerName: '재고상태',
        field: 'prntStateNm',
        spanHeaderHeight: true,
        cellRenderer: "statusComonent"
    }
  ];

  const defaultColDef = useMemo(() => {
      return {
          initialWidth: 90,
          sortable: true,
          resizable:true
      };
  }, []);

  //aggrid 재고상태
  const statusComonent = (props) => {
        
    if(props.value === "OK"){
      return(
          <div className="status-title status-1">
          {props.value}
          </div>
      )
    }else if(props.value === "준비"){
      return(
          <div className="status-title status-2">
          {props.value}
          </div>
      )
    }else if(props.value === "발주필요"){
      return(
          <div className="status-title status-3">
          {props.value}
          </div>
      )
    }else{
      return(
          <div className="status-title status-4" style={{cursor:'pointer'}}>
          {props.value}
          </div>
      )
    }

  }

  useEffect(()=>{
    if(queryResult.status === 'loading' && gridRef && gridRef.current && gridRef.current.api){
        gridRef.current.api.showLoadingOverlay();
    }
  },[queryResult]);

  useEffect(()=> {
    if(gridRef && gridRef.current && gridRef.current.api){
      gridRef.current.api.setQuickFilter(filterValue);
    }
  },[filterValue]);

  useEffect(()=> {
    if(gridRef && gridRef.current && gridRef.current.api){
      gridRef.current.api.paginationGoToPage(activePage-1);
    }
  },[activePage]);

  const onSelectionChanged = useCallback(() => {
    const selectedRows = gridRef.current.api.getSelectedRows();
    checkRow(selectedRows)
  }, []);


  //그리드 리사이즈
  const onFirstDataRendered = (params) => {
      params.api.sizeColumnsToFit();
  };

  return (
    <div className="ag-theme-alpine" style={{height: gridHeight, transition:'all ease .3s'}}>
          <AgGridReact
              ref={gridRef} //
              rowData={queryResult && queryResult.data} //
              columnDefs={columnDefs}
              defaultColDef={defaultColDef}

              // paging
              pagination={true}
              paginationPageSize={limit} //
              suppressPaginationPanel={true} 
              // onPaginationChanged={onPaginationChanged}

              // checkedRowDatas by Woong
              onSelectionChanged={onSelectionChanged}

              //  filter
              cacheQuickFilter={true}

              // click column
              onCellClicked={onCellClicked} //
              
              // multi select
              rowSelection={'multiple'}
              suppressRowClickSelection= {true} 

              // overlay
              overlayLoadingTemplate={CONSTANTS.gridLoading}
              overlayNoRowsTemplate={CONSTANTS.gridNoRows}

              frameworkComponents={{
                statusComonent,
                escapeCharChangeForGrid
              }}

              /*그리드리사이즈*/
              onFirstDataRendered={onFirstDataRendered}
              suppressSizeToFit={true}    
              onGridSizeChanged={onFirstDataRendered}
              >
          </AgGridReact>
      </div>
  );

};
export default GridSewonIvmTot;