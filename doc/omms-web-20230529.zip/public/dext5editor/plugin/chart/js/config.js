﻿// 병합된 테이블 차트 변환 허용
G_DEPlugin["chart"].allowMergedTableToChart = false;
