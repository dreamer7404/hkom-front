﻿/*
Copyright (c) 2013, Raonwiz Technology Inc. All rights reserved.
 - document domain config (cross domain)
*/

//var dext5EnforceDocumentDomain = true;
//document.domain = "dext5.com";