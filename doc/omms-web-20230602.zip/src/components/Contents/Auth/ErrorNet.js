// react
import React from 'react';
import {Button, Card } from "react-bootstrap";
import {Form} from 'rsuite';
import RemindOutlineIcon from '@rsuite/icons/RemindOutline';

const ErrorPage = () => {

    return (
        <>
           <div className="error-wrap">
                <Form>
                    <Card className="shadow">
                        <Card.Body>
                            <RemindOutlineIcon />
                            <h4>
                                <p className="error-type">Error Connection</p>
                                서버에서 응답이 없습니다.
                            </h4>
                            <div className="button-wrap">
                                <Button variant="secondary">메인 페이지</Button>
                            </div>
                        </Card.Body>
                    </Card>
                </Form>
           </div>
        </>
    )
};
export default ErrorPage;