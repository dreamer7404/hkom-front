import React,{useState,useEffect,useRef} from 'react';
import {Row, Col, Button, Modal, Table} from 'react-bootstrap';
import {Form, SelectPicker } from 'rsuite';
import { API, CONSTANTS } from '../../../../utils/constants';
import { useQuery, useMutation} from 'react-query';
import { getData, postData } from '../../../../utils/async';
import { confirmAlert } from 'react-confirm-alert'; // Import
import ConfirmAlert from '../../../Common/ConfirmAlert';
const NatCarRegion = ({updRegnParam, show, onHide}) => {
    const containerRef = useRef();
    const [dlExpdRegnCd, setDlExpdRegnCd] = useState();
    
    const paramsCo = {dlExpdGCd: CONSTANTS.grpCdRegn};
    
    const regnCombo = useQuery([API.codeCombo,paramsCo], () => getData(API.codeCombo,paramsCo)) 
    const onChangeRegnCombo = val =>{
        setDlExpdRegnCd(val);
    }
    const handleSubmit = () => {
        confirmAlert({
            closeOnClickOutside: false,
            customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}   title={"알림"}
            msg={"입력하신 내용으로 저장하시겠습니까?"} 
            
            onOk={onOk}  />
            
        });
    }

    const onOk = () => {
       
        updRegnParam.dlExpdRegnCd = dlExpdRegnCd
        updateRegnCd.mutate(updRegnParam);
    }
    const updateRegnCd = useMutation((params => postData(API.updRegnCd, params, CONSTANTS.update)),{
        onSuccess: res => {
           if(res>0){
                confirmAlert({
                    closeOnClickOutside: false,
                    customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}   title={"알림"}
                    msg={"저장이 완료되었습니다."}   />
                    
                });
           }else{
            confirmAlert({
                closeOnClickOutside: false,
                customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}   title={"알림"}
                msg={"에러가 발생했습니다 관리자에게 문의해주세요."}   />
                
            });
           }
           onHide();
        }
    });

   
    const natlVehlRegn = useQuery([API.natlVehlRegn,updRegnParam], () => getData(API.natlVehlRegn,updRegnParam),{
        enabled: false,
    }) 

    useEffect(()=>{
        natlVehlRegn.refetch();
    },[updRegnParam])

    useEffect(()=>{
        if(natlVehlRegn.isSuccess&& natlVehlRegn.data){
            setDlExpdRegnCd(natlVehlRegn.data.natlVehlRegn.dlExpdRegnCd)
        }
    },[natlVehlRegn.status])




    return (
        <>
            <Form>
                <Modal show={show} onHide={onHide} backdrop="static" keyboard={false} centered size="md" className="modal-custom">
                    <Modal.Header closeButton>
                        <Modal.Title>국가/차종별 적용지역</Modal.Title>
                    </Modal.Header>
                        <Modal.Body>
                            <Table className="tbl-hor" bordered>
                                <colgroup>
                                    <col style={{width:'30%'}}></col>
                                    <col style={{width:''}}></col>
                                </colgroup>
                                <tbody>
                                    <tr>
                                        <th className="essen">적용지역</th>
                                        <td>
                                                 {regnCombo.isSuccess &&
                                                    <Form.Control container={()=> containerRef.current}  name="dlExpdRegnCd" size="sm" style={{zIndex: 0}} 
                                                        value={dlExpdRegnCd}
                                                        placeholder={'선택'}
                                                        defaultValue={''}
                                                        accepter={SelectPicker} 
                                                        searchable={false}
                                                        cleanable={false}
                                                        data={regnCombo.isFetched && regnCombo.data}
                                                        onChange={onChangeRegnCombo}
                                                    ></Form.Control>
                                                }
                                        </td>
                                    </tr>
                                </tbody>
                            </Table>
                        </Modal.Body>

                        <Modal.Footer>
                            <Button variant="light" size="md" onClick={onHide}>취소</Button>
                            <Button variant="primary" size="md" onClick={handleSubmit} >저장</Button>
                        </Modal.Footer>
                </Modal>
            </Form>

        </>
    );

};
export default NatCarRegion;