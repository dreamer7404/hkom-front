import React, {useEffect, useMemo, useRef} from 'react';
import { AgGridReact } from 'ag-grid-react';
import { CONSTANTS } from '../../../../utils/constants';

const GridPrintPageList = ({gridHeight, filterValue, queryResult, limit, activePage, onCellClicked}) => {

  const gridRef = useRef();

  const columnDefs = [
        {
          checkboxSelection: true,
          headerCheckboxSelection: true,
          spanHeaderHeight: true,
          width:45,
          maxWidth:45,
          minWidth:45,
          pinned:'left'
        },
        {
          headerName: '차종',
          children: [
            { headerName:'차종코드', field: 'carCd', minWidth:'80',pinned:'left'},
            { headerName:'차종명', field: 'carName', minWidth:'150',pinned:'left', cellStyle: () => ({textDecoration: 'underline', cursor: 'pointer', color:'#2589f5'}) },
            { headerName:'연식', field: 'monthYear', minWidth:'80',pinned:'left'},
          ],
        },
        {
          headerName: '언어',
          children: [
            { headerName:'지역', field: 'region', minWidth:'80',pinned:'left'},
            { headerName:'언어코드', field: 'langCd', minWidth:'80',pinned:'left'},
            { headerName:'언어명', field: 'langName', minWidth:'150',pinned:'left'},
          ],
        },
        {
          headerName: '발간번호',
          spanHeaderHeight: true,
          field: 'printNum',
          minWidth:'150',
          pinned:'left',
        },
        {
          headerName: '등록일',
          spanHeaderHeight: true,
          field: 'addDate',
          minWidth:'100',
          pinned:'left',
        },
        {
          headerName: '마지막 페이지 구분',
          children: [
            { headerName:'서문1', field: 'page1', minWidth:'60'},
            { headerName:'서문2', field: 'page2', minWidth:'60' },
            { headerName:'서문3', field: 'page3', minWidth:'60' },
            { headerName:'1장', field: 'page4', minWidth:'60' },
            { headerName:'2장', field: 'page5', minWidth:'60' },
            { headerName:'3장', field: 'page6', minWidth:'60' },
            { headerName:'4장', field: 'page7', minWidth:'60' },
            { headerName:'5장', field: 'page8', minWidth:'60' },
            { headerName:'6장', field: 'page9', minWidth:'60' },
            { headerName:'8장', field: 'page10', minWidth:'60' },
            { headerName:'9장', field: 'page11', minWidth:'60' },
            { headerName:'10장', field: 'page12', minWidth:'60' },
            { headerName:'11장', field: 'page13', minWidth:'60' },
            { headerName:'12장', field: 'page14', minWidth:'60' },
            { headerName:'13장', field: 'page15', minWidth:'60' },
            { headerName:'색인', field: 'page16', minWidth:'60' },
          ],
        },
  ]

  const defaultColDef = useMemo(() => {
      return {
          initialWidth: 90,
          sortable: true,
          resizable:true,
      };
  }, []);

  const onFirstDataRendered = (params) => {
      params.api.sizeColumnsToFit();
  };

  useEffect(()=>{
    if(queryResult.status === 'loading' && gridRef && gridRef.current && gridRef.current.api){
        gridRef.current.api.showLoadingOverlay();
    }
  },[queryResult]);

  useEffect(()=> {
    if(gridRef && gridRef.current && gridRef.current.api){
      gridRef.current.api.setQuickFilter(filterValue);
    }
  },[filterValue]);

  useEffect(()=> {
    if(gridRef && gridRef.current && gridRef.current.api){
      gridRef.current.api.paginationGoToPage(activePage-1);
    }
  },[activePage]);


  return(
      <div className="ag-theme-alpine" style={{height: gridHeight, transition:'all ease .3s'}}>
        <AgGridReact
            ref={gridRef} 
            rowData={queryResult && queryResult.data} 
            columnDefs={columnDefs}
            defaultColDef={defaultColDef}

            // paging
            pagination={true}
            paginationPageSize={limit} //
            suppressPaginationPanel={true} 
            // onPaginationChanged={onPaginationChanged}

            rowSelection={'multiple'}
            suppressRowClickSelection= {true} 

            //  filter
            cacheQuickFilter={true}

            onCellClicked={onCellClicked}

            // overlay
            overlayLoadingTemplate={CONSTANTS.gridLoading}
            overlayNoRowsTemplate={CONSTANTS.gridNoRows}

            onFirstDataRendered={onFirstDataRendered}
            suppressSizeToFit={true}    
            onGridSizeChanged={onFirstDataRendered}    
            >
        </AgGridReact>
    </div>
  )


};
export default GridPrintPageList;