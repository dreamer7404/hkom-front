import React, {useEffect, useMemo, useRef} from 'react';
import { AgGridReact } from 'ag-grid-react';
import { CONSTANTS } from '../../../../utils/constants';
import { escapeCharChange, escapeCharChangeForGrid, formatNumber, utcToLocalDate } from '../../../../utils/commUtils';

const GridRequestState = ({gridHeight, filterValue, queryResult, limit, activePage}) => {
  // 수량 천단위 콤마 찍기
  const currencyFormatter = (params) => {
      return formatNumber(params.value);
  };

  const gridRef = useRef();

  const columnDefs = [
        {
          headerName: '차종',
          children: [
            { headerName:'차종코드', field: 'qltyVehlCd', minWidth:80,},
            { headerName:'차종명', field: 'qltyVehlNm',minWidth:80, cellRenderer:"escapeCharChangeForGrid" },
            { headerName:'연식', field: 'mdlMdyCd' , minWidth:50,},
          ],
        },
        {
          headerName: '언어',
          children: [
            { headerName:'지역', field: 'dlExpdPrvsNm', minWidth:80,},
            { headerName:'언어코드', field: 'langCd',minWidth:80, },
            { headerName:'언어명', field: 'langCdNm',minWidth:80, cellRenderer:"escapeCharChangeForGrid"},
          ],
        },
        {
            headerName: '발간번호',
            field: 'newPrntPbcnNo',
            spanHeaderHeight: true,
        },
        {
            headerName: '입고상태',
            field: 'expdWhsnStNm',
            spanHeaderHeight: true,
        },
        {
            headerName: '입고Box',
            field: 'dlExpdBoxQty',
            spanHeaderHeight: true,
          },
        {
          headerName: '입고수량',
          field: 'rqQty',
          spanHeaderHeight: true,
        },
        {
            headerName: '과부족',
            field: 'deei1Qty',
            spanHeaderHeight: true,
          },
        {
          headerName: '입고일',
          field: 'whsnYmd',
          spanHeaderHeight: true,
        },  
        {
          headerName: '담당자',
          field: 'crgrNm',
          spanHeaderHeight: true,
        }
    ]

    const defaultColDef = useMemo(() => {
        return {
            initialWidth: 90,
            sortable: true,
            resizable:true,
        };
    }, []);

  const onFirstDataRendered = (params) => {
      params.api.sizeColumnsToFit();
  };

  useEffect(()=>{
    if(queryResult.status === 'loading' && gridRef && gridRef.current && gridRef.current.api){
        gridRef.current.api.showLoadingOverlay();
    }
  },[queryResult]);

  useEffect(()=> {
    if(gridRef && gridRef.current && gridRef.current.api){
      gridRef.current.api.setQuickFilter(filterValue);
    }
  },[filterValue]);

  useEffect(()=> {
    if(gridRef && gridRef.current && gridRef.current.api){
      gridRef.current.api.paginationGoToPage(activePage-1);
    }
  },[activePage]);


  return(
      <div className="ag-theme-alpine" style={{height: gridHeight, transition:'all ease .3s'}}>
        <AgGridReact
            ref={gridRef} 
            rowData={queryResult && queryResult.data} 
            columnDefs={columnDefs}
            defaultColDef={defaultColDef}

            frameworkComponents={{
              escapeCharChangeForGrid,
              currencyFormatter
              }}

            // paging
            pagination={true}
            paginationPageSize={limit} //
            suppressPaginationPanel={true} 
            // onPaginationChanged={onPaginationChanged}

            //  filter
            cacheQuickFilter={true}

            // overlay
            overlayLoadingTemplate={CONSTANTS.gridLoading}
            overlayNoRowsTemplate={CONSTANTS.gridNoRows}

            onFirstDataRendered={onFirstDataRendered}
            suppressSizeToFit={true}    
            onGridSizeChanged={onFirstDataRendered}    
            >
        </AgGridReact>
    </div>
  )


};
export default GridRequestState;