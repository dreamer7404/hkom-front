// react
import React, {useState, useEffect, useCallback} from 'react';
import {Col, Button, Collapse} from 'react-bootstrap';
import {Form, SelectPicker} from 'rsuite';
import SearchIcon from '@rsuite/icons/Search';

//--------------  서버데이터용 필수 -------------------------------
import { useQuery} from 'react-query';
import { CONSTANTS } from '../../../../utils/constants';
import useStore from '../../../../utils/store';
//--------------// 서버데이터용 필수 -------------------------------

import GridSysCodeList from '../_Grid/GridSysCodeList';
import Paging from '../../../Common/Paging';
import { CustomInputGroup } from '../../../Common/CustomInputGroup';

import SysCodeGroupAdd from '../Popup/SysCodeGroupAdd';
import SysCodeGroupDelete from '../Popup/SysCodeGroupDelete';
import SysCodeAdd from '../Popup/SysCodeAdd';
import SysCodeAddAll from '../Popup/SysCodeAddAll';
import SysCodeUpdate from '../Popup/SysCodeUpdate';

const SysCodeList = () => {

    //------------------- 필수 공통 ------------------------------
    const [open, setOpen] = useState(true); // 조건창 열기/닫기
    const {keyword } = useStore();  // 조회키워드 가져오기

    const [activePage, setActivePage] = useState(1);    // 페이지번호
    const [limit, setLimit] = useState(50);             // 페이지행수
    const [filterValue, setFilterValue] = useState(''); // 필터값

    const onChangePage = val => {
        setActivePage(val);
    };
    const onChangeLimit = val => {
        setLimit(val);
    };
    useEffect(()=>{
        onChangePage(1); // 페이지번호 리셋
    },[keyword]);

    // 필터
    const onFilterTextBoxChanged = useCallback((e) => {
        setFilterValue(e.target.value);
    }, []);

    // 검색창 열기/닫기 > 페이지네이션 여부에 따라 +-20px
    const [gridHeight, setGridHeight] = useState(575);
    const gridExpand = () =>{
        setOpen(!open);
        if(open){
            setTimeout(() => setGridHeight(650), 250);
        }else{
            setGridHeight(575)
        }
    }
    //-------------------// 필수 공통 ------------------------------

    const [rowData] = useState([
        {groupCd: "001", groupNm: "테스트그룹1", itemCd: "01", itemNm: "테스트항목1", order:'1', useYn:'Y', addUser:'관리자', addDate:'2023-03-03'},
        {groupCd: "002", groupNm: "테스트그룹2", itemCd: "02", itemNm: "테스트항목2", order:'2', useYn:'Y', addUser:'관리자', addDate:'2023-03-03'},
        {groupCd: "003", groupNm: "테스트그룹3", itemCd: "03", itemNm: "테스트항목3", order:'3', useYn:'N', addUser:'관리자', addDate:'2023-03-03'},
        {groupCd: "004", groupNm: "테스트그룹4", itemCd: "04", itemNm: "테스트항목4", order:'4', useYn:'Y', addUser:'관리자', addDate:'2023-03-03'},
        {groupCd: "005", groupNm: "테스트그룹5", itemCd: "05", itemNm: "테스트항목5", order:'5', useYn:'Y', addUser:'관리자', addDate:'2023-03-03'},
    ]);

    //  requestState 조회
    const queryResult = useQuery(["SysCodeList"], () => {return rowData});

    // 셀 클릭
    const onCellClicked = e => {
        // console.log(e);
        // alert(e.column.colId + ',' + e.value)

        if(e.column.colId === 'groupNm'){
            setSysCodeUpdatePop(true)
        }

    };

    const [sysCodeGroupAddPop, setSysCodeGroupAddPop] = useState(false);
    const [sysCodeGroupDeletePop, setSysCodeGroupDeletePop] = useState(false);
    const [sysCodeAddPop, setSysCodeAddPop] = useState(false);
    const [sysCodeAddAllPop, setSysCodeAddAllPop] = useState(false);
    const [sysCodeUpdatePop, setSysCodeUpdatePop] = useState(false);


    // 조회버튼
    const onSearch = () => {
        queryResult.refetch(); // 수동쿼리실행
    };

    return (
        <>
            <div className="search-area">
                <Collapse in={open}>
                    <div className="form" id="example-collapse-text">
                        <div className="search-group">
                            <div className="row">
                                <Col sm={3} className=""> 
                                    <Form.ControlLabel column="sm" >그룹명</Form.ControlLabel>
                                    <SelectPicker size="sm" data={[{ label: "전체" }]} searchable={false} cleanable={false} />
                                </Col>
                                <Col sm={3} className=""> 
                                    <Form.ControlLabel column="sm" >항목명</Form.ControlLabel>
                                    <SelectPicker size="sm" data={[{ label: "전체" }]} searchable={false} cleanable={false} />
                                </Col>
                                <Col sm={3} className=""> 
                                    <Form.ControlLabel column="sm" >사용여부</Form.ControlLabel>
                                    <SelectPicker size="sm" data={[{ label: "전체" }]} searchable={false} cleanable={false} />
                                </Col>
                            </div>

                            <div className="search-btn-wrap">
                                <Button className="btn-search" variant="outline-primary" size="sm" onClick={onSearch}><SearchIcon />조회</Button>
                            </div>
                        </div>
                    </div>
                </Collapse>
                <Button size="sm" variant="outline-dark" className="search-control" aria-controls="example-collapse-text" 
                    aria-expanded={open} onClick={gridExpand}>
                    <span className={open === true ? "search-area-close" : "search-area-open"}>{open === true ? CONSTANTS.closeSearch : CONSTANTS.openSearch}</span>
                </Button>
            </div>
            
            <div className="grid-wrap">
                <div className="grid-btn-wrap">
                    <div className="left-align">
                        {/*--------- 필터 -----------*/}
                        <CustomInputGroup size="sm"   onInput={onFilterTextBoxChanged} />
                    </div>
                    <div className="right-align">
                        {/*--------- 버튼 -----------*/}
                        <Button variant="outline-secondary" size="sm" onClick={() => setSysCodeGroupAddPop(true)}>그룹코드 등록</Button>{' '}
                        <Button variant="outline-secondary" size="sm" onClick={() => setSysCodeGroupDeletePop(true)}>그룹코드 삭제</Button>{' '}
                        <Button variant="outline-secondary" size="sm" onClick={() => setSysCodeAddPop(true)}>코드 등록</Button>{' '}
                        <Button variant="outline-secondary" size="sm" onClick={() => setSysCodeAddAllPop(true)}>코드 등록(일괄)</Button>{' '}
                        <Button variant="outline-secondary" size="sm" >코드 삭제</Button>{' '}
                        <Button variant="outline-success" size="sm"><span className="excel-down"></span>{CONSTANTS.excelDownload}</Button>{' '}
                    </div>
                </div>
                {/*--------- Grid -----------*/}
                <GridSysCodeList 
                    gridHeight={gridHeight}
                    filterValue={filterValue}
                    queryResult={queryResult}
                    limit={limit}
                    activePage={activePage}
                    onCellClicked={onCellClicked}
                    />

                {/*--------- 페이징 -----------*/}
                <Paging 
                    total={queryResult && queryResult.data && queryResult.data.length}
                    limit={limit}
                    activePage={activePage}
                    onChangePage={onChangePage}
                    onChangeLimit={onChangeLimit}
                />
            </div>

            <SysCodeGroupAdd show={sysCodeGroupAddPop} onHide={() => setSysCodeGroupAddPop(false)} />
            <SysCodeGroupDelete show={sysCodeGroupDeletePop} onHide={() => setSysCodeGroupDeletePop(false)} />
            <SysCodeAdd show={sysCodeAddPop} onHide={() => setSysCodeAddPop(false)} />
            <SysCodeAddAll show={sysCodeAddAllPop} onHide={() => setSysCodeAddAllPop(false)} />
            <SysCodeUpdate show={sysCodeUpdatePop} onHide={() => setSysCodeUpdatePop(false)} />
        </>
    )
};
export default SysCodeList;