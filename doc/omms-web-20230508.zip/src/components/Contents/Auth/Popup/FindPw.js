import React, {useState, useMemo} from 'react';
import {Button, Modal, Row, Col, Table} from 'react-bootstrap';
import { Form , Schema} from 'rsuite';

//--------------  서버데이터용 필수 -------------------------------
import { useQuery, useMutation} from 'react-query';
import { getData, postData } from '../../../../utils/async';
import { API, CONSTANTS } from '../../../../utils/constants';
//--------------// 서버데이터용 필수 -------------------------------

const { StringType} = Schema.Types;
const model = Schema.Model({
    userEeno: StringType().isRequired('아이디를 입력해주세요.'),
                            // .pattern(/^[a-zA-Z0-9]*$/, '영문자,숫자로 입력해주세요')
                            // .rangeLength(7, 20, '7-20자로 입력해주세요'),
    userNm: StringType().isRequired('이름을 입력해주세요.')
                            // .pattern(/^(?=.*[A-Za-z])(?=.*\d)(?=.*[$@$!%*#?&])[A-Za-z\d$@$!%*#?&]{7,}$/, 
                            //     '최소 7자리이며, 숫자,문자,특수문자는 최소1개이상 입력해주세요')
                            // .rangeLength(7, 20, '7-20자로 입력해주세요'),
});

const FindPw = ({show, onHide}) => {

    // Form 정의
    const formRef = React.useRef();
    const [formError, setFormError] = React.useState({});
    const [formValue, setFormValue] = React.useState({
      userEeno: '',     // 아이디
      userNm: '',       // 이름
    });


    // 회사목록 가져오기
     
    const params = {
        userEeno: formValue.userEeno, 
        userNm: formValue.userNm
    };
    const queryResult = useQuery([API.initUserPw, params], () => getData(API.initUserPw, params), {
        enabled: false,
        onSuccess: rv => {
            if(rv === 1){ // 이메일전송 성공



                onHide(); // 모달닫기
            }else{ // 이메일전송 실패



            }
        }
    });

    const onFind = () => {
        if (!formRef.current.check()) {
            return;
        }
        queryResult.refetch();
        
    }



    return (
        <Form
            ref={formRef}
            checkTrigger="change"
            onChange={setFormValue}
            onCheck={setFormError}
            formValue={formValue}
            model={model}>
                <Modal show={show} onHide={onHide} backdrop="static" backdropClassName="modal-in-backdrop" keyboard={false} centered size="md" className="modal-custom modal-in-modal">
                    <Modal.Header closeButton>
                        <Modal.Title>비밀번호 찾기</Modal.Title>
                    </Modal.Header>
                        <Modal.Body>
                            <Table className="tbl-hor" bordered>
                                <tbody>
                                    <tr>
                                        <th className="essen">아이디</th>
                                        <td>
                                            <Form.Control name="userEeno" size="sm" type="text" placeholder="아이디를 입력해주세요" />
                                        </td>
                                    </tr>
                                    <tr>
                                        <th className="essen">이름</th>
                                        <td>
                                            <Form.Control name="userNm" size="sm" type="text" placeholder="이름을 입력해주세요" />
                                        </td>
                                    </tr>
                                </tbody>
                            </Table>

                        </Modal.Body>
                        <Modal.Footer>
                            <Button variant="light" size="md" onClick={onHide}>취소</Button>
                            <Button variant="primary" size="md" onClick={onFind}>확인</Button>
                        </Modal.Footer>
                </Modal>
        </Form>
    );

};
export default FindPw;