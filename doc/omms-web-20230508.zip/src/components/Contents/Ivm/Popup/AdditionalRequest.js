import React, {useState, useEffect} from 'react';
import {Button, Modal, Table} from 'react-bootstrap';
import {Form, Radio, RadioGroup, Schema, Input, Notification, useToaster} from 'rsuite';
import { escapeCharChange } from '../../../../utils/commUtils';

// import { useForm } from "react-hook-form";
// //--------------  서버데이터용 필수 -------------------------------
import { useMutation} from 'react-query';
import { postData } from '../../../../utils/async';
import { API, CONSTANTS } from '../../../../utils/constants';
// //--------------// 서버데이터용 필수 -------------------------------

import { confirmAlert } from 'react-confirm-alert'; // Import
import ConfirmAlert from '../../../Common/ConfirmAlert';

//-------------------------------- accepter validation 시작 -------------------------------------
const { StringType, ArrayType, ObjectType, NumberType } = Schema.Types;
const model = Schema.Model({
    // radioType: StringType().addRule(value => {
    //     return value !== '';
    //   }, '현재고부문을 선택하세요'),
    radioType: StringType().isRequired('현재고부문을 선택하세요'),
    list: ArrayType().of(
        ObjectType().shape({
            rqQty: NumberType('숫자만 입력해주세요.').isRequired('수량을 입력해주세요.'),
        })
    )
});
//-------------------------------- accepter validation 끝 -------------------------------------

//-------------------------------- accepter 컨트롤 시작 -------------------------------------
const ListControl =  ({ value = [], onChange, fieldError }) => {

    const errors = fieldError ? fieldError.array : [];
    const [list, setList] = React.useState(value); 

    const onChangeRqQty = (idx, val) => {
        const arr = list.map((item, index) => (idx === index) ? {...item, rqQty: val} : item);
        setList(arr)
        onChange(arr);
    };

    return (
        
        <Table className="tbl-hor" bordered>
            <colgroup>
                <col style={{width:'35%'}}></col>
                <col style={{width:'35%'}}></col>
                <col style={{width:'%'}}></col>
            </colgroup>
            <tbody>
            {list.map((item, index) => (
                <tr key={index}>
                    <td>({item.qltyVehlCd} / {item.mdlMdyCd}) {escapeCharChange(item.qltyVehlNm)}</td>
                    <td>({item.langCd}){item.langCdNm}</td>
                    <td>
                        <Input size="sm" placeholder="수량"  value={item.rqQty || ''} onChange={(val)=>onChangeRqQty(index, val)} />
                        <div style={{color: 'red'}}>{(errors.length > 0 && errors[index].hasError) && errors[index].object.rqQty.errorMessage }</div>
                    </td>
                </tr>
            ))}
            </tbody>
        </Table>
    )
}
//-------------------------------- accepter 컨트롤 끝 -------------------------------------



const AdditionalRequest = ({show, onHide, checkedRows}) => {
    if(show && checkedRows.length <= 0){  
        show=false
        onHide=true
    }
    const [reqBody, setReqBody] = useState([]);
    const toaster = useToaster();
    const submitResult = useMutation([API.ivmSeparatelyRequest, reqBody], () => postData(API.ivmSeparatelyRequest, reqBody, CONSTANTS.insert),{
		onSuccess: res => {
		    if(res > 0){
		        toaster.push(
                    <Notification type='success' header='요청성공' closable >별도요청이 완료되었습니다.</Notification>
                );
                show=false;
                onHide(); // 창닫기
		    }else{
		        toaster.push(
                    <Notification type='error' header='요청실패' closable >별도요청을 실패했습니다.</Notification>
                );
		    }
		}
	});

    // Form 정의
    const formRef = React.useRef();
    const [formError, setFormError] = React.useState({});
    const [formValue, setFormValue] = React.useState({
        radioType:'sewon',
        list: [],
        content:''
    });
    //체크된 rows 변경시 form 초기화 (최초 열릴때)
    useEffect(()=> {
        setFormValue(item => ({...item, radioType:'sewon', list: checkedRows, content:''}))
        setRadioType('sewon')
        setContent('')
        // eslint-disable-next-line react-hooks/exhaustive-deps
    },[checkedRows]);
    
    //라디오버튼
    const [radioType, setRadioType] = useState('sewon');
    useEffect(()=> {
        formValue.radioType = radioType
        // eslint-disable-next-line react-hooks/exhaustive-deps
    },[radioType]);
    //사유
    const [content, setContent] = useState('');
    useEffect(()=> {
        formValue.content = content
        // eslint-disable-next-line react-hooks/exhaustive-deps
    },[content]);

    //팝업을 닫을 경우 에러 초기화
    useEffect(() => {
        setFormError([])
        setFormValue(item => ({...item, radioType:'sewon', list: checkedRows, content:''}))
        setRadioType('sewon')
        setContent('')
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [show])

    //formValue가 바뀔때마다 reqBody 세팅
    useEffect(()=> {
        if(show){
            setReqBody(formValue.list.map(item => ({...item, radioType: formValue.radioType, content: formValue.content})))
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    },[formValue]);

    // 저장버튼 클릭
    const handleSubmit = () => {
        // validation 체크
        if (!formRef.current.check()) {
            return;
        }
        console.log(reqBody)
        //submitResult.mutate(reqBody)
        
        // toaster.push(<Notification type='info' header='' closable>
        //     asdasddasd
        //     <hr />
        //     {/* <Uploader action="#" /> */}
        //   </Notification>, 'topCenter')

        const onOk = () => {
            // console.log(checkedRowsForOutReqInput)
            // submitResult.mutate(checkedRowsForOutReqInput)
            submitResult.mutate(reqBody)  
        }
        confirmAlert({
            closeOnClickOutside: false,
            customUI: ({ onClose }) => <ConfirmAlert 
                                            onClose={onClose} 
                                            title={"알림"}
                                            msg={"입력하신 내용으로 별도요청하시겠습니까?"} 
                                            onOk={onOk}  
                                        />
        })
        
        // if(window.confirm('입력하신 내용으로\n별도요청하시겠습니까?')){
        //     submitResult.mutate(reqBody)  
        // } 
    };

    return (
        <>
        <Form  
            ref={formRef}
            checkTrigger="change"
            onChange={setFormValue}
            onCheck={setFormError}
            formValue={formValue}
            model={model} >
            <Modal show={show} onHide={onHide} backdrop="static" keyboard={false} centered size="lg" className="modal-custom">
                <Modal.Header closeButton>
                    <Modal.Title>별도 요청</Modal.Title>
                </Modal.Header>
                    <Modal.Body>
                          <Table className="tbl-hor" bordered>
                            <colgroup>
                                <col style={{width:'20%'}}></col>
                                <col style={{width:''}}></col>
                            </colgroup>
                            <tbody>
                                <tr>
                                    <th>현 재고 부문</th>
                                    <td>
                                    {/* 
                                        <RadioGroup 
                                            name="radioType" 
                                            inline 
                                            onChange={value => setRadioType(value)}
                                            accepter={RadioGroup}
                                        >
                                            <Radio value="sewon">세원</Radio>
                                            <Radio value="pdi">PDI/용산</Radio>
                                        </RadioGroup> */}

                                        <Form.Control 
                                            name="radioType" 
                                            accepter={RadioGroup} 
                                            onChange={value => setRadioType(value)}
                                            inline
                                            value={radioType}
                                        >
                                            <Radio value="sewon">세원</Radio>
                                            <Radio value="pdi">PDI/용산</Radio>
                                        </Form.Control>
                                    </td>
                                </tr>
                                <tr>
                                    <th>언어/수량</th>
                                    <td>
                                    <Form.Group >
                                        <Form.Control 
                                            name="list" 
                                            accepter={ListControl} 
                                            fieldError={formError.list}
                                            />
                                    </Form.Group>
                                    </td>
                                </tr>
                                <tr>
                                    <th>사유</th>
                                    <td>
                                        <Form.Control size="sm" id="reason" name="reason" type="text" placeholder="사유를 입력해주세요" value={content} onChange={value => setContent(value)} />
                                    </td>
                                </tr>
                            </tbody>
                          </Table>
                    </Modal.Body>

                    <Modal.Footer>
                        <Button variant="light" size="md" onClick={onHide}>취소</Button>
                        <Button variant="primary" size="md" onClick={handleSubmit} >저장</Button>
                    </Modal.Footer>
                </Modal>
            </Form>
        </>
    );

};
export default AdditionalRequest;