import React, {useState, useMemo} from 'react';
import {Modal, Button} from 'react-bootstrap';
import {Form, SelectPicker} from 'rsuite';
import { AgGridReact } from 'ag-grid-react';
import { CONSTANTS } from '../../../../utils/constants';

const InputConfirm = ({show, onHide}) => {

    const defaultColDef = useMemo(() => {
        return {
            initialWidth: 90,
            resizable:true,
        };
    }, []);

    const [rowData] = useState([
        {carCd: "AD",country:'asdf', carName: "AVANTE", monthYear: '23MY', region:'유럽', langCd:'AR', langName:'영어,불어/캐나다', recevingDt1:'DVCEW-SED5', recevingDt2:'', recevingDt3:'10', recevingDt4:'100', recevingDt5:''},
        {carCd: "AD",country:'asdf', carName: "AVANTE", monthYear: '23MY', region:'유럽', langCd:'AR', langName:'영어,불어/캐나다', recevingDt1:'DFSE-SED5', recevingDt2:'', recevingDt3:'15', recevingDt4:'150', recevingDt5:''},
        {carCd: "AD",country:'asdf', carName: "AVANTE", monthYear: '23MY', region:'유럽', langCd:'AR', langName:'영어,불어/캐나다', recevingDt1:'ASDW-SED5', recevingDt2:'', recevingDt3:'13', recevingDt4:'130', recevingDt5:''},
    ]);

    const columnDefs = [
        {
            checkboxSelection: true,
            headerCheckboxSelection: true,
            spanHeaderHeight: true,
            width:45,
            maxWidth:45,
            minWidth:45
        },
        {
          headerName: '차종',
          children: [
            { headerName:'차종코드', field: 'carCd',sortable:true},
            { headerName:'차종명', field: 'carName',width:'120',sortable:true },
            { headerName:'연식', field: 'monthYear',sortable:true },
          ],
        },
        {
          headerName: '언어',
          children: [
            { headerName:'지역', field: 'region',sortable:true},
            { headerName:'언어코드', field: 'langCd',sortable:true },
            { headerName:'언어명', field: 'langName', width:'120',sortable:true },
          ],
        },
        {
          headerName: '발간번호',
          field: 'recevingDt1',
          spanHeaderHeight: true,
          sortable:true
        },  
        {
          headerName: '입고상태',
          field: 'recevingDt2',
          cellRenderer:'selectComponent',
          spanHeaderHeight: true,
          width:80,
        },  
        {
            headerName: '입고Box',
            field: 'recevingDt3',
            spanHeaderHeight: true,
            width:65,
            sortable:true
        },  
        {
            headerName: '입고수량',
            field: 'recevingDt4',
            spanHeaderHeight: true,
            width:80,
            sortable:true
        },  
        {
            headerName: '과부족',
            field: 'recevingDt5',
            spanHeaderHeight: true,
            cellRenderer:'inputComponent'
        },  
    ]

    const inputComponent = (props) => {
        return (
          <div className="grid-form-wrap">
            <Form.Control size="sm" type="text" placeholder="" defaultValue={props.value} />
          </div>
        );
    }

    const selectComponent = (props) => {
        return (
          <div className="grid-form-wrap">
            {/* <Form.Select size="sm">
                <option value="">정상</option>
                <option value="">부족</option>
                <option value="">추가입고</option>
            </Form.Select>  */}
            <SelectPicker size="sm" data={[{ label: "test"}]} searchable={false} cleanable={false} />
          </div>
        );
    }

    const onFirstDataRendered = (params) => {
        params.api.sizeColumnsToFit();
    };

    
    return (
        <>
            <Form>
                <Modal show={show} onHide={onHide} backdrop="static" keyboard={false} centered size="xl" className="modal-custom size-2xl">
                    <Modal.Header closeButton>
                        <Modal.Title>입고확인</Modal.Title>
                    </Modal.Header>
                    <Modal.Body>
                        <div className="grid-btn-wrap">
                            <div className="right-align">
                                <Button variant="outline-dark" size="sm"><span className="print"></span>{CONSTANTS.print}</Button>{' '}
                            </div>
                        </div>
                        <div className="ag-theme-alpine" style={{height:300, minWidth:300}}>
                            <AgGridReact
                                rowData={rowData}
                                columnDefs={columnDefs}
                                defaultColDef={defaultColDef}
                                rowSelection={'multiple'}
                                suppressRowClickSelection= {true} 
                                frameworkComponents={{
                                inputComponent,
                                selectComponent
                                }}
                                onFirstDataRendered={onFirstDataRendered}
                                suppressSizeToFit={true}    
                                onGridSizeChanged={onFirstDataRendered}     
                                >
                            </AgGridReact>
                        </div>
                    </Modal.Body>
                    <Modal.Footer>
                        <Button variant="light" size="md" onClick={onHide}>취소</Button>
                        <Button variant="primary" size="md" onClick={onHide}>저장</Button>
                    </Modal.Footer>
                </Modal>
            </Form>
        </>
    );

};
export default InputConfirm;