import React from 'react';
import {Button, Modal, Table} from 'react-bootstrap';
import {Form} from 'rsuite';

const PrintCost = ({show, onHide}) => {

    return (
        <>
            <Form>
                <Modal show={show} onHide={onHide} backdrop="static" keyboard={false} centered size="md" className="modal-custom">
                    <Modal.Header closeButton>
                        <Modal.Title>인쇄비 입력</Modal.Title>
                    </Modal.Header>
                        <Modal.Body>
                            <Table className="tbl-hor" bordered>
                                <colgroup>
                                    <col style={{width:'35%'}}></col>
                                    <col style={{width:''}}></col>
                                </colgroup>
                                <tbody>
                                    <tr>
                                        <th>인쇄부수</th>
                                        <td>150</td>
                                    </tr>
                                    <tr>
                                        <th className="essen">평균단가</th>
                                        <td>
                                            <Form.Control size="sm" type="text" placeholder="평균단가" />
                                        </td>
                                    </tr>
                                    <tr>
                                        <th>소요예산</th>
                                        <td>
                                            <Form.Control size="sm" type="text" readOnly placeholder="0" />
                                            </td>
                                    </tr>
                                    <tr>
                                        <th>견적서</th>
                                        <td>
                                            파일선택
                                        </td>
                                    </tr>
                                </tbody>
                            </Table>
                        </Modal.Body>

                        <Modal.Footer>
                            <Button variant="light" size="md" onClick={onHide}>취소</Button>
                            <Button variant="primary" size="md" onClick={onHide}>저장</Button>
                        </Modal.Footer>
                </Modal>
            </Form>
        </>
    );

};
export default PrintCost;