import React from 'react';
import {Button, Modal, Table} from 'react-bootstrap';
import { DatePicker, Form} from 'rsuite';

const OutRequestChange = ({show, onHide}) => {

    return (
        <>
            <Form>
                <Modal show={show} onHide={onHide} backdrop="static" keyboard={false} centered size="md" className="modal-custom">
                    <Modal.Header closeButton>
                        <Modal.Title>납품요청일 변경</Modal.Title>
                    </Modal.Header>
                        <Modal.Body>
                            <Table className="tbl-hor" bordered>
                                <colgroup>
                                    <col style={{width:'35%'}}></col>
                                    <col style={{width:''}}></col>
                                </colgroup>
                                <tbody>
                                    <tr>
                                        <th>납품요청일</th>
                                        <td>2023-03-31</td>
                                    </tr>
                                    <tr>
                                        <th className="essen">변경 납품요청일</th>
                                        <td>
                                            <DatePicker oneTap block size="sm"
                                                value={new Date()} 
                                                cleanable={false}
                                                searchable="true"
                                                ranges={[
                                                    {
                                                    label: '오늘',
                                                    value: new Date()
                                                    }
                                                ]}
                                            />
                                        </td>
                                    </tr>
                                </tbody>
                            </Table>
                        </Modal.Body>
                        <Modal.Footer>
                            <Button variant="light" size="md" onClick={onHide}>취소</Button>
                            <Button variant="primary" size="md" onClick={onHide}>저장</Button>
                        </Modal.Footer>
                </Modal>
            </Form>
        </>
    );

};
export default OutRequestChange;