import React from 'react';
import {Button, Modal, Table} from 'react-bootstrap';
import {Form} from 'rsuite';

const PrintCostInputNo = ({show, onHide}) => {

    return (
        <>
            <Form>
                <Modal show={show} onHide={onHide} backdrop="static" keyboard={false} centered size="md" className="modal-custom">
                    <Modal.Header closeButton>
                        <Modal.Title>인쇄비 품의번호 입력</Modal.Title>
                    </Modal.Header>
                        <Modal.Body>
                            <Table className="tbl-hor" bordered>
                                <colgroup>
                                    <col style={{width:'35%'}}></col>
                                    <col style={{width:''}}></col>
                                </colgroup>
                                <tbody>
                                    <tr>
                                        <th className="essen">인쇄비 품의번호</th>
                                        <td>
                                            <Form.Control size="sm" type="text" placeholder="평균단가" />
                                        </td>
                                    </tr>
                                </tbody>
                            </Table>
                        </Modal.Body>
                        <Modal.Footer>
                            <Button variant="light" size="md" onClick={onHide}>취소</Button>
                            <Button variant="primary" size="md" onClick={onHide}>저장</Button>
                        </Modal.Footer>
                </Modal>
            </Form>
        </>
    );

};
export default PrintCostInputNo;