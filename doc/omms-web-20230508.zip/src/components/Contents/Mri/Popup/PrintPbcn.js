import React, { useState, useMemo } from 'react';
import {Button, Modal} from 'react-bootstrap';
import { AgGridReact } from 'ag-grid-react';
import { CONSTANTS } from '../../../../utils/constants';

const PrintPbcn = ({show, onHide}) => {
    
    const defaultColDef = useMemo(() => {
    return {
        sortable: true,
        minWidth:100,
        resizable:true,
    };
    }, []);

    const onFirstDataRendered = (params) => {
        params.api.sizeColumnsToFit();
    };

    // 셀 클릭
    const onCellClicked = e => {
        // console.log(e);
        // alert(e.column.colId + ',' + e.value)

        if(e.column.colId === 'printNewNum'){
            alert('선택한 발간번호에 해당되는 정보 o/m발주 화면에 자동 입력')
        }

    };
   

    const [rowData] = useState([
        {printNewNum:'POAO-EC32G', printOldNum:'POAO-EC31G', qltyVehlCd:'AD', qltyVehlNm:'AVANTE',mdlMdyCd:'23', dlExpdRegnNm:'북미', langCd:'EC', langCdNm:'영어,불어/캐나다', printSt:'발주완료'},
        {printNewNum:'POAO-EC31G', printOldNum:'POAO-EC30G', qltyVehlCd:'AD', qltyVehlNm:'AVANTE',mdlMdyCd:'23', dlExpdRegnNm:'북미', langCd:'EC', langCdNm:'영어,불어/캐나다', printSt:'발주완료'},
    ]);

    const columnDefs = [

        {
        headerName: '신규번호',
        field: 'printNewNum',
        spanHeaderHeight: true,
        cellStyle: () => ({textDecoration: 'underline', cursor: 'pointer', color:'#2589f5'})
        },
        {
        headerName: '기존번호',
        field: 'printOldNum',
        spanHeaderHeight: true
        },
        {
        headerName: '차종',
        children: [
            { headerName:'차종코드', field: 'qltyVehlCd' },
            { headerName:'차종명', field: 'qltyVehlNm', cellStyle:() => ({textAlign: 'left'})},
            { headerName:'연식', field: 'mdlMdyCd', },
        ],
        },
        {
        headerName: '언어',
        children: [
            { headerName:'지역', field: 'dlExpdRegnNm'},
            { headerName:'언어코드', field: 'langCd', },
            { headerName:'언어명', field: 'langCdNm',  cellStyle:() => ({textAlign: 'left'}) },
        ],
        }, 
        {
        headerName: '발주상태',
        field: 'printSt',
        spanHeaderHeight: true
        },
    ]
    return (
        <>
            <Modal show={show} onHide={onHide} backdrop="static" keyboard={false} centered size="xl" className="modal-custom">
                <Modal.Header closeButton>
                    <Modal.Title>발간번호 검색</Modal.Title>
                </Modal.Header>
                <Modal.Body>
                    <div className="ag-theme-alpine" style={{height:300}}>
                        <AgGridReact
                            rowData={rowData}
                            columnDefs={columnDefs}
                            defaultColDef={defaultColDef}
                            onFirstDataRendered={onFirstDataRendered}
                            suppressSizeToFit={true}    
                            onGridSizeChanged={onFirstDataRendered}   

                            onCellClicked={onCellClicked}
                            >
                        </AgGridReact>
                    </div>
                </Modal.Body>
                <Modal.Footer>
                    <Button variant="primary" size="md" onClick={onHide}>확인</Button>
                </Modal.Footer>
            </Modal>
        </>
    )
};
export default PrintPbcn;