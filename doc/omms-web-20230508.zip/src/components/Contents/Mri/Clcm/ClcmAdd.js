// react
import React, {useState, useMemo} from 'react';
import { AgGridReact } from 'ag-grid-react';
import {Button, Table} from 'react-bootstrap';
// rsuite
import {Form, SelectPicker, MultiCascader } from 'rsuite';

const ClcmAdd = () => {
    const headers = ['차종', '언어'];
        const options = [
            {
            "label": "(AA)AA-CAR",
            "value": 1,
            "children": [
                {
                "label": "(EE)영어/유럽",
                "value": 2
                },
                {
                "label": "(KO)한글/국내",
                "value": 3,
                },
            ]
        }
    ]

    const [rowData] = useState([
        {selectCar: "(AA)AA-CAR", selectLang: "(EE)영어/유럽" },
        {selectCar: "(AA)AA-CAR", selectLang: "(EE)영어/유럽" },
        {selectCar: "(AA)AA-CAR", selectLang: "(EE)영어/유럽" },
        {selectCar: "(AA)AA-CAR", selectLang: "(EE)영어/유럽" },
        {selectCar: "(AA)AA-CAR", selectLang: "(EE)영어/유럽" },
    ]);

    const columnDefs = [
        {
          headerName: '차종',
          field: 'selectCar',
        },
        {
          headerName: '언어',
          field: 'selectLang',
        },
    ]

    const [rowData2] = useState([
        {userPart: "현대자동차", userName: "홍길동"},
        {userPart: "현대자동차", userName: "김삼순"},
        {userPart: "현대자동차", userName: "김삼순"},
        {userPart: "현대자동차", userName: "김삼순"},
    ]);

    const columnDefs2 = [
        {
          checkboxSelection: true,
          headerCheckboxSelection: true,
          width:45,
          maxWidth:45,
          minWidth:45
        },
        {
          headerName: '소속',
          field: 'userPart',
        },
        {
          headerName: '이름',
          field: 'userName',
        },
    ]

    const defaultColDef = useMemo(() => {
        return {
            initialWidth: 90,
            sortable: true,
        };
    }, []);


    const onFirstDataRendered = (params) => {
        params.api.sizeColumnsToFit();
    };

    const saveButton = () => {
        window.location.href="./ClcmDetail"
    }

    const listButton = () => {
        window.location.href="./ClcmList"
    }

    return (
        <>
            <div className="grid-wrap">
                <Form>
                    <Table className="tbl-hor" bordered>
                        <colgroup>
                            <col style={{width:'15%'}}></col>
                            <col style={{width:'35%'}}></col>
                            <col style={{width:'15%'}}></col>
                            <col style={{width:'35%'}}></col>
                        </colgroup>
                        <tbody>
                            <tr>
                                <th>수신형태</th>
                                <td>
                                    {/* <Form.Select size="sm" xs={4}>
                                        <option value="">수신형태를 선택해주세요</option>
                                        <option value="">협조전</option>
                                        <option value="">우편함</option>
                                        <option value="">정보</option>
                                        <option value="">EO/제사위</option>
                                        <option value="">법규1</option>
                                        <option value="">법규2</option>
                                    </Form.Select>  */}
                                    <SelectPicker size="sm" data={[{ label: "test"}]} searchable={false} cleanable={false} />
                                </td>
                                <th>등록자</th>
                                <td>홍길동</td>
                            </tr>
                            <tr>
                                <th>발신처</th>
                                <td>
                                    <Form.Control size="sm" type="text" placeholder="발신처를 입력해주세요" />
                                </td>
                                <th>담당자</th>
                                <td>
                                    <Form.Control size="sm" type="text" placeholder="담당자를 입력해주세요" />
                                </td>
                            </tr>
                            <tr>
                                <th>차종 및 언어</th>
                                <td colSpan="3">
                                    <MultiCascader className="multi-cascader"
                                    size="sm"
                                    menuWidth={250}
                                    style={{fontSize:'12px', width:'100%'}}
                                    placeholder="차종 및 언어를 선택해주세요"
                                    data={options}
                                    renderMenu={(children, menu, parentNode, layer) => {
                                    return (
                                        <div>
                                        <div
                                            style={{
                                            background: '#f8f8f8',
                                            padding: '4px 10px',
                                            color: ' #000',
                                            textAlign: 'center',
                                            fontSize:'12px',
                                            fontWeight:600
                                            }}
                                        >
                                            {headers[layer]}
                                        </div>
                                        {menu}
                                        </div>
                                    );
                                    }}
                                />
                                </td>
                            </tr>
                            <tr>
                                <th>적용 차종 및 언어</th>
                                <td>
                                    <div className="ag-theme-alpine" style={{height: 130, transition:'all ease .3s'}}>
                                        <AgGridReact
                                            rowData={rowData}
                                            columnDefs={columnDefs}
                                            defaultColDef={defaultColDef}
                                            onFirstDataRendered={onFirstDataRendered}
                                            suppressSizeToFit={true}    
                                            onGridSizeChanged={onFirstDataRendered}    
                                            >
                                        </AgGridReact>
                                    </div>
                                </td>
                                <th>송부인</th>
                                <td>
                                    <div className="ag-theme-alpine" style={{height: 130, transition:'all ease .3s'}}>
                                        <AgGridReact
                                            rowData={rowData2}
                                            columnDefs={columnDefs2}
                                            defaultColDef={defaultColDef}
                                            rowSelection={'multiple'}
                                            suppressRowClickSelection= {true} 
                                            onFirstDataRendered={onFirstDataRendered}
                                            suppressSizeToFit={true}    
                                            onGridSizeChanged={onFirstDataRendered}    
                                            >
                                        </AgGridReact>
                                    </div>
                                </td>
                            </tr>
                            <tr>
                                <th>제목</th>
                                <td colSpan="3">
                                    <Form.Control size="sm" type="text" placeholder="제목을 입력해주세요" />
                                </td>
                            </tr>
                            <tr>
                                <th>내용</th>
                                <td colSpan="3">
                                    <Form.Control size="sm"  placeholder="내용을 입력해주세요" />
                                </td>
                            </tr>
                            <tr>
                                <th>첨부파일</th>
                                <td colSpan="3">
                                    
                                </td>
                            </tr>
                        </tbody>
                    </Table>
                </Form>
                <div className="btn-wrap">
                    <div className="right-align">
                        <Button variant="light" onClick={listButton}>취소</Button>{' '}
                        <Button className="" variant="primary" size="md" onClick={saveButton}>저장</Button>
                    </div>
                </div>
            </div>
        </>
    )
};
export default ClcmAdd;