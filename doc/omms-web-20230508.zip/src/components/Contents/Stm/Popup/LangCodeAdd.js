import React from 'react';
import {Button, Modal, Table} from 'react-bootstrap';
import {Form, SelectPicker} from 'rsuite';

const LangCodeAdd = ({show, onHide}) => {

    return (
        <>
            <Form>
                <Modal show={show} onHide={onHide} backdrop="static" keyboard={false} centered size="md" className="modal-custom">
                    <Modal.Header closeButton>
                        <Modal.Title>언어코드 등록</Modal.Title>
                    </Modal.Header>
                        <Modal.Body>
                            <Table className="tbl-hor" bordered>
                                <colgroup>
                                    <col style={{width:'30%'}}></col>
                                    <col style={{width:''}}></col>
                                </colgroup>
                                <tbody>
                                    <tr>
                                        <th className="essen">언어코드</th>
                                        <td>
                                            <Form.Control size="sm" type="text"/> 
                                        </td>
                                    </tr>
                                    <tr>
                                        <th className="essen">언어명</th>
                                        <td>
                                            <Form.Control size="sm" type="text"/> 
                                        </td>
                                    </tr>
                                    <tr>
                                        <th className="essen">지역</th>
                                        <td>
                                            <SelectPicker size="sm" data={[{ label: "지역"}]} searchable={false} cleanable={false} />
                                        </td>
                                    </tr>
                                    <tr>
                                        <th className="">사용여부</th>
                                        <td>
                                            <SelectPicker size="sm" data={[{ label: "사용"}]} searchable={false} cleanable={false} />
                                        </td>
                                    </tr>
                                </tbody>
                            </Table>
                        </Modal.Body>

                        <Modal.Footer>
                            <Button variant="light" size="md" onClick={onHide}>취소</Button>
                            <Button variant="primary" size="md" onClick={onHide} >저장</Button>
                        </Modal.Footer>
                </Modal>
            </Form>

        </>
    );

};
export default LangCodeAdd;