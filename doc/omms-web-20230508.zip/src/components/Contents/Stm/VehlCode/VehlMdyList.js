// react
import React, {useState, useEffect, useCallback} from 'react';
import {Table, Col, Button, Collapse} from 'react-bootstrap';
import { Form, SelectPicker, Schema,Notification,useToaster } from 'rsuite';
import SearchIcon from '@rsuite/icons/Search';

//--------------  서버데이터용 필수 -------------------------------
import { useQuery,useMutation} from 'react-query';
import { getData,postData } from '../../../../utils/async';
import { API, CONSTANTS } from '../../../../utils/constants';
import useStore from '../../../../utils/store';
import VehlTypeB from '../../../Search/VehlTypeB';
import Region from '../../../Search/Region';
import SeMonth from '../../../Search/SeMonth';
//--------------// 서버데이터용 필수 -------------------------------

import GridVehlMdyList from '../_Grid/GridVehlMdyList';
import Paging from '../../../Common/Paging';
import { CustomInputGroup } from '../../../Common/CustomInputGroup';

import { escapeCharChange } from '../../../../utils/commUtils';
import VehlMdyUpdate from '../Popup/VehlMdyUpdate';
import { confirmAlert } from 'react-confirm-alert'; // Import
import ConfirmAlert from '../../../Common/ConfirmAlert';


const { StringType, NumberType,  ArrayType, ObjectType } = Schema.Types;
const model = Schema.Model({
    qltyVehlCd: StringType().isRequired('차종을 선택해주세요.'),
    dlExpdRegnCd: StringType().isRequired('지역을 선택해주세요.'),
    desmp1Cd: StringType().isRequired('시작월팩을 입력해주세요.').pattern(/^[0-9]*$/, '숫자로 입력해주세요') .rangeLength(4, 4, '4자리 숫자로 입력해주세요.'),
    defmp1Cd: StringType().pattern(/^[0-9]*$/, '숫자로 입력해주세요') .rangeLength(4, 4, '4자리 숫자로 입력해주세요.'),
    mdlMdyCd: StringType().isRequired('연식을 입력해주세요.')
});
const VehlMdyList = () => {
    const formRef = React.useRef();
    const [formError, setFormError] = React.useState({});
    const [formValue, setFormValue] = React.useState({
        qltyVehlCd : '', //차종코드
        dlExpdRegnCd : '',  // 지역
        desmp1Cd : '',  //시작 월팩
        defmp1Cd : '',  //종료 월팩
        mdlMdyCd : ''   //연식
    });  
    //------------------- 필수 공통 ------------------------------
    const [open, setOpen] = useState(true); // 조건창 열기/닫기
    const {keyword } = useStore();  // 조회키워드 가져오기
    const toaster = useToaster();
    const [activePage, setActivePage] = useState(1);    // 페이지번호
    const [limit, setLimit] = useState(50);             // 페이지행수
    const [filterValue, setFilterValue] = useState(''); // 필터값

    const onChangePage = val => {
        setActivePage(val);
    };
    const onChangeLimit = val => {
        setLimit(val);
    };
    useEffect(()=>{
        onChangePage(1); // 페이지번호 리셋
    },[keyword]);

    // 필터
    const onFilterTextBoxChanged = useCallback((e) => {
        setFilterValue(e.target.value);
    }, []);

    // 검색창 열기/닫기 > 페이지네이션 여부에 따라 +-20px
    const [gridHeight, setGridHeight] = useState(275);
    const gridExpand = () =>{
        setOpen(!open);
        if(open){
            setTimeout(() => setGridHeight(350), 250);
        }else{
            setGridHeight(275)
        }
    }
    //-------------------// 필수 공통 ------------------------------

    const paramsCo = {dlExpdGCd: CONSTANTS.grpCdRegn};
    const regnList = useQuery([API.codeCombo,paramsCo], () => getData(API.codeCombo,paramsCo)) 

  
    const qltyVehlNm = useQuery([API.vehlCombo, {}], () => getData(API.vehlCombo, {}), {
            select: data => [{label: CONSTANTS.labelAll, value: CONSTANTS.valueAll}].concat(data.map((item) => ({ label: escapeCharChange(item.qltyVehlNm), value: item.qltyVehlCd })))
    }); 
    const param = {
        sYm: keyword.sMonth,
        eYm: keyword.eMonth,
        dlExpdPdiCd: keyword.dlExpdPdiCd,
        qltyVehlCd: keyword.qltyVehlCd,
        mdlMdyCd: keyword.mdlMdyCd,
        dlExpdRegnCd: keyword.dlExpdRegnCd,
    }
    //  requestState 조회
    // const queryResult = useQuery(["VehlMdyList"], () => {return rowData});
    const queryResult = useQuery([API.vehlMdyMgmts, param], () => getData(API.vehlMdyMgmts, param));
    // 셀 클릭
    const onCellClicked = e => {
        if(e.column.colId === 'qltyVehlNm'){
            setVehlMdyUpdatePop(true)
        }
    };
    const handleSubmit = () => { //신규 연식 등록 누를경우
        confirmAlert({
            closeOnClickOutside: false,
            customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}  msg={"입력하신 내용으로 저장하시겠습니까?"} onOk={onOk} />
        });
       

    };
    const onOk = () => {
        if (!formRef.current.check()) { //validation chk
            return;
        }
        //연식 등록
        mdyMgmtMutate.mutate(formValue);
    }


    //차종코드 저장
    const mdyMgmtMutate = useMutation((params => 
        
        postData(API.vehlMdyMgmt, params, CONSTANTS.insert)),{
            
        onSuccess: res => {
            
            if(res.msg=='ok'){
                toaster.push(<Notification type='success' header='등록성공' closable >
                저장이 완료되었습니다.
             </Notification>);
            }else if(res.msg=='err1'){ //신규 시작월팩이 현시작월팩 보다 보다 커야 합니다.
                toaster.push(<Notification type='error' header='등록실패' closable >
                중복된 기간의 시작월팩이 있습니다 다시 확인해주세요
             </Notification>);
            }else if(res.msg=='err2'){//현 시작월팩이  이전 종료월팩 보다 작은경우 알림
                toaster.push(<Notification type='error' header='등록실패' closable >
                중복된 기간의 시작월팩이 있습니다 다시 확인해주세요
             </Notification>);
            }else if(res.msg=='dup'){//차종 + 연식 + 지역 중복발생
                toaster.push(<Notification type='error' header='등록실패' closable >
                중복된 연식이 있습니다. 다시 확인해주세요
             </Notification>);
            }
                
                // onHide(true); // 창닫기 & refetch
            
        }
    });

  



    const [vehlMdyUpdatePop, setVehlMdyUpdatePop] = useState(false);

    // 조회버튼
    const onSearch = () => {
        queryResult.refetch(); // 수동쿼리실행
    };

    return (
        <>
            <div className="search-area">
                <Collapse in={open}>
                    <div className="form" id="example-collapse-text">
                        <div className="search-group">
                            <div className="row">
                                <Col sm={2} className=""> 
                                    <SeMonth />
                                </Col>
                                <Col sm={2} className="" >
                                    <Region  />
                                </Col>
                                <Col sm={4} className="" >
                                    <VehlTypeB  />
                                </Col>
                            </div>

                            <div className="search-btn-wrap">
                                <Button className="btn-search" variant="outline-primary" size="sm" onClick={onSearch}><SearchIcon />조회</Button>
                            </div>
                        </div>
                    </div>
                </Collapse>
                <Button size="sm" variant="outline-dark" className="search-control" aria-controls="example-collapse-text" 
                    aria-expanded={open} onClick={gridExpand}>
                    <span className={open === true ? "search-area-close" : "search-area-open"}>{open === true ? CONSTANTS.closeSearch : CONSTANTS.openSearch}</span>
                </Button>
            </div>
            
            <div className="grid-wrap">
                <div className="grid-btn-wrap">
                    <div className="left-align">
                        {/*--------- 필터 -----------*/}
                        <CustomInputGroup size="sm"   onInput={onFilterTextBoxChanged} />
                    </div>
                </div>
                {/*--------- Grid -----------*/}
                {queryResult.data &&<GridVehlMdyList 
                    gridHeight={gridHeight}
                    filterValue={filterValue}
                    queryResult={queryResult}
                    limit={limit}
                    activePage={activePage}
                    onCellClicked={onCellClicked}
                    />
                }
                {/*--------- 페이징 -----------*/}
                <Paging 
                    total={queryResult && queryResult.data && queryResult.data.length}
                    limit={limit}
                    activePage={activePage}
                    onChangePage={onChangePage}
                    onChangeLimit={onChangeLimit}
                />

                <div className="grid-btn-wrap mt-3">
                    <div className="left-align">
                        <div className="sub-title">
                            <ul>
                                <li>신규연식 등록</li>
                            </ul>
                        </div>
                    </div>
                    <div className="right-align">
                        {/*--------- 버튼 -----------*/}
                        <Button variant="outline-secondary" size="sm" onClick={handleSubmit}>신규연식 등록</Button>{' '}
                    </div>
                </div>
                <Form ref={formRef}
                checkTrigger="change"
                onChange={setFormValue}
                onCheck={setFormError}
                formValue={formValue}
                model={model}>
                    <Table className="tbl-ver" bordered>
                        <colgroup>
                            <col style={{width:'20%'}}></col>
                            <col style={{width:'20%'}}></col>
                            <col style={{width:'20%'}}></col>
                            <col style={{width:'20%'}}></col>
                            <col style={{width:'20%'}}></col>
                        </colgroup>
                        <thead>
                            <tr>
                                <th className="essen">차종</th>
                                <th className="essen">지역</th>
                                <th className="essen">시작월팩</th>
                                <th className="essen">종료월팩</th>
                                <th className="essen">연식</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>
                                {qltyVehlNm.isSuccess&&
                                    <Form.Control name="qltyVehlCd"  size="sm" style={{zIndex: 0}} 
                                        placeholder={'선택'}
                                        defaultValue={''}
                                        accepter={SelectPicker} 
                                        searchable={false}
                                        cleanable={false}
                                        data={qltyVehlNm.isFetched && qltyVehlNm.data}
                                    ></Form.Control>
                                    }
                                </td>
                                <td>
                                    {regnList.isSuccess&&
                                    <Form.Control name="dlExpdRegnCd"  size="sm" style={{zIndex: 0}} 
                                        placeholder={'선택'}
                                        defaultValue={''}
                                        accepter={SelectPicker} 
                                        searchable={false}
                                        cleanable={false}
                                        data={regnList.isFetched && regnList.data}
                                    ></Form.Control>
                                    }
                                </td>
                                <td><Form.Control size="sm" name = "desmp1Cd" type="text" placeholder=""/></td>
                                <td><Form.Control size="sm" name = "defmp1Cd" type="text" placeholder="9999"/></td>
                                <td><Form.Control size="sm" name = "mdlMdyCd" type="text" placeholder=""/></td>
                            </tr>
                        </tbody>
                    </Table>
                </Form>
            </div>

            {/* 팝업 */}
            {vehlMdyUpdatePop && <VehlMdyUpdate show={vehlMdyUpdatePop} data={""} onHide={() => setVehlMdyUpdatePop(false)}  />}
        </>
    )
};
export default VehlMdyList;