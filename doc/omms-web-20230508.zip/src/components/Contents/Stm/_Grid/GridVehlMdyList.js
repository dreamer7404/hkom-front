import React, {useEffect,useState, useMemo, useRef} from 'react';
import { AgGridReact } from 'ag-grid-react';
import { CONSTANTS } from '../../../../utils/constants';
import { escapeCharChangeForGrid, formatNumber } from '../../../../utils/commUtils';

const GridVehlMdyList = ({gridHeight, filterValue, queryResult, limit, activePage, onCellClicked}) => {

  
  const gridRef = useRef();

  const [columnDefs, setColumnDefs] = useState( [
        {
          headerName: '차종',
          children: [
            { headerName:'차종코드', field: 'qltyVehlCd'},
            { headerName:'차종명', field: 'qltyVehlNm',
              cellRenderer: "escapeCharChangeForGrid",
             cellStyle: () => ({textDecoration: 'underline', cursor: 'pointer', color:'#2589f5',}) 
             
            },
          ],
          
        },
        {
          headerName: '지역',
          spanHeaderHeight: true,
          field: 'dlExpdPrvsNm',
        },
        // {
        //   headerName: '월팩',
        //   children: [
        //     { headerName:'2201', field: 'col1',
        //     colSpan: (params) => {

              
              
        //     },},
        //     { headerName:'2202', field: 'col2',
        //     colSpan: (params) => { columnFunction(params);
        //     },},
        //     { headerName:'2203', field: 'col3', minWidth:'100'},
        //     { headerName:'2204', field: 'col4', minWidth:'100'},
        //     { headerName:'2205', field: 'col5', minWidth:'100'},
        //     { headerName:'2206', field: 'col6', minWidth:'100'},
        //     { headerName:'2207', field: 'col7', minWidth:'100'},
        //     { headerName:'2208', field: 'col8', minWidth:'100'},
        //     { headerName:'2209', field: 'col9', minWidth:'100'},
        //     { headerName:'2210', field: 'col10', minWidth:'100'},
        //     { headerName:'2211', field: 'col11', minWidth:'100'},
        //     { headerName:'2212', field: 'col12', minWidth:'100'},
            
        //   ],
        // },
     
      ]);

      useEffect(()=>{
        if(queryResult.isSuccess && queryResult.data!=undefined) {
          const item = queryResult.data.dateList;
          console.log('item',item);

          const arr = item.map(p=>({headerName:p.value,
            field :p.value? p.key:null,
            minWidth:'90'}));

            console.log(">>>>>",arr);

            setColumnDefs(columnDefs.filter(item => item.headerName !== '월팩').concat({
              headerName: '월팩',
              children: arr,
            }
            ,{
              headerName: '종료미지정',
              children: [
                { headerName:'9999', field: 'col13', minWidth:'120'}
              ]
            }
            )
          )
        }

        
      },[queryResult.status]);
    
  const defaultColDef = useMemo(() => {
      return {
          initialWidth: 90,
          sortable: true,
          resizable:true,
      };
  }, []);

  const columnFunction =(params) =>{
    const yearMonth1 = params.data.col1;
    const yearMonth2 = params.data.col2;
        
      return yearMonth1 === yearMonth2 ? 2 : 1
  }


  const onFirstDataRendered = (params) => {
      params.api.sizeColumnsToFit();
  };

  useEffect(()=>{
    
    if(queryResult.status === 'loading' && gridRef && gridRef.current && gridRef.current.api){
        gridRef.current.api.showLoadingOverlay();
    }
    
    
  },[queryResult]);
  
  useEffect(()=> {
    if(gridRef && gridRef.current && gridRef.current.api){
      gridRef.current.api.setQuickFilter(filterValue);
    }
  },[filterValue]);

  useEffect(()=> {
    if(gridRef && gridRef.current && gridRef.current.api){
      gridRef.current.api.paginationGoToPage(activePage-1);
    }
  },[activePage]);


  return(
      <div className="ag-theme-alpine" style={{height: gridHeight, transition:'all ease .3s'}}>
        <AgGridReact
            ref={gridRef} 
            rowData={queryResult && queryResult.data.mdyList} 
            columnDefs={columnDefs}
            defaultColDef={defaultColDef}

            // paging
            pagination={true}
            paginationPageSize={limit} //
            suppressPaginationPanel={true} 
            // onPaginationChanged={onPaginationChanged}

            //  filter
            cacheQuickFilter={true}

            onCellClicked={onCellClicked}

            // overlay
            overlayLoadingTemplate={CONSTANTS.gridLoading}
            overlayNoRowsTemplate={CONSTANTS.gridNoRows}

            onFirstDataRendered={onFirstDataRendered}
            suppressSizeToFit={true}    
            onGridSizeChanged={onFirstDataRendered}    
            >
        </AgGridReact>
    </div>
  )


};
export default GridVehlMdyList;