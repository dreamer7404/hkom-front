import React, {useEffect, useMemo, useRef} from 'react';
import { AgGridReact } from 'ag-grid-react';
import { CONSTANTS } from '../../../../utils/constants';

const GridVehlLangList = ({gridHeight, filterValue, queryResult, limit, activePage, onCellClicked}) => {

  const gridRef = useRef();

  const columnDefs = [
        {
          checkboxSelection: true,
          headerCheckboxSelection: true,
          spanHeaderHeight: true,
          width:45,
          maxWidth:45,
          minWidth:45
        },
        {
          headerName: '차종',
          children: [
            { headerName:'차종코드', field: 'carCd',},
            { headerName:'차종명', field: 'carName'},
            { headerName:'연식', field: 'monthYear' },
          ],
        },
        {
          headerName: '언어',
          children: [
            { headerName:'지역', field: 'region'},
            { headerName:'언어코드', field: 'langCd', cellStyle: () => ({textDecoration: 'underline', cursor: 'pointer', color:'#2589f5'}) },
            { headerName:'언어명', field: 'langName'},
          ],
        },
        {
            headerName: 'A코드',
            field: 'aCd',
            spanHeaderHeight: true,
            maxWidth:'120'
        },
        {
            headerName: '정렬순서',
            field: 'order',
            spanHeaderHeight: true,
            maxWidth:'120'
        },
        {
            headerName: '사용여부',
            field: 'useYn',
            spanHeaderHeight: true,
            cellRenderer: "statusComonent",
            maxWidth:'80'
        },
        {
          headerName: '등록자',
          field: 'addUser',
          spanHeaderHeight: true,
          maxWidth:'150'
        },
        {
            headerName: '등록일',
            field: 'addDate',
            spanHeaderHeight: true,
            maxWidth:'150'
        },
  ]

  const defaultColDef = useMemo(() => {
      return {
          initialWidth: 90,
          sortable: true,
          resizable:true,
      };
  }, []);

  //사용여부
  const statusComonent = (props) => {
    if(props.value === "Y"){
      return(
          <div style={{color:'#2589f5'}}>
          {props.value}
          </div>
      )
    }else if(props.value === "N"){
      return(
          <div style={{color:'#dc3545'}}>
          {props.value}
          </div>
      )
    }
  }

  const onFirstDataRendered = (params) => {
      params.api.sizeColumnsToFit();
  };

  useEffect(()=>{
    if(queryResult.status === 'loading' && gridRef && gridRef.current && gridRef.current.api){
        gridRef.current.api.showLoadingOverlay();
    }
  },[queryResult]);

  useEffect(()=> {
    if(gridRef && gridRef.current && gridRef.current.api){
      gridRef.current.api.setQuickFilter(filterValue);
    }
  },[filterValue]);

  useEffect(()=> {
    if(gridRef && gridRef.current && gridRef.current.api){
      gridRef.current.api.paginationGoToPage(activePage-1);
    }
  },[activePage]);


  return(
      <div className="ag-theme-alpine" style={{height: gridHeight, transition:'all ease .3s'}}>
        <AgGridReact
            ref={gridRef} 
            rowData={queryResult && queryResult.data} 
            columnDefs={columnDefs}
            defaultColDef={defaultColDef}

            // paging
            pagination={true}
            paginationPageSize={limit} //
            suppressPaginationPanel={true} 
            // onPaginationChanged={onPaginationChanged}

            // multi select
            rowSelection={'multiple'}
            suppressRowClickSelection= {true}

            //  filter
            cacheQuickFilter={true}

            onCellClicked={onCellClicked}

            frameworkComponents={{
                statusComonent
            }}

            // overlay
            overlayLoadingTemplate={CONSTANTS.gridLoading}
            overlayNoRowsTemplate={CONSTANTS.gridNoRows}

            onFirstDataRendered={onFirstDataRendered}
            suppressSizeToFit={true}    
            onGridSizeChanged={onFirstDataRendered}    
            >
        </AgGridReact>
    </div>
  )


};
export default GridVehlLangList;