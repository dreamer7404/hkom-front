// react
import React from 'react';

// react-bootstrap
import Container from 'react-bootstrap/Container';


const SitePath = () => {
    return (
        <div style={{marginTop: '70px'}} >
            <Container fluid>
            site path...
           </Container>
        </div>
    );
};
export default SitePath;