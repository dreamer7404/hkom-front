/* eslint-disable react-hooks/exhaustive-deps */
import React ,{useState, useRef, useEffect, useMemo, useCallback} from 'react';
import {Button,Modal, Row, Col, Table} from 'react-bootstrap';
import {Schema, Form, SelectPicker, CustomProvider, DatePicker, Field, Radio, RadioGroup, Checkbox} from 'rsuite';
import { AgGridReact } from 'ag-grid-react';

//--------------  서버데이터용 필수 -------------------------------
import { useQuery, useQueryClient, useMutation} from 'react-query';
import { getData, postData } from '../../../../utils/async';
import { API, CONSTANTS } from '../../../../utils/constants';
import useStore from '../../../../utils/store';
//--------------// 서버데이터용 필수 -------------------------------
import { confirmAlert } from 'react-confirm-alert'; 
import ConfirmAlert from   '../../../Common/ConfirmAlert'; 

import VehlLangCascader from '../../../Search/VehlLangCascader'

import { DEXT5Editor, useDEXT5Editor } from 'dext5editor-react';
import { DEXT5Upload } from 'dext5upload-react';

import ko from 'rsuite/locales/ko_KR';

const { StringType} = Schema.Types;
const model = Schema.Model({
    gubun: StringType().isRequired('분류를 선택해주세요.'),
    // crgrNm: StringType().isRequired('담당자를 입력해주세요.')
    //                         .rangeLength(2, 30, '2-30자로 입력해주세요'),    
    // altrTitl:StringType().isRequired('제목을 입력해주세요.')
    //                         .rangeLength(2, 30, '2-30자로 입력해주세요'),
    // altrSbc:StringType().isRequired('내용을 입력해주세요.'),
    // langCdByVehlListVali: StringType().pattern(/^[ok]+$/, '차종 및 언어를 선택해주세요.'),
    // senderListVali: StringType().pattern(/^[ok]+$/, '송부인을 선택해주세요.'),
});


const BoardAdd = () => {

    const gridRef = useRef();
    const {token, coCd} = useStore();

    // 구분
    const params = {
        dlExpdGCd: '0039' // 게시판 구분 (불용재고, 교체투입, 분리투입, 기타)
    };
    const gubunCombo = useQuery([API.codeCombo, params], () => getData(API.codeCombo, params));

    //등록자
    const usrmgmt = useQuery([API.usrmgmt], () => getData(API.usrmgmt));

    useEffect(() => {
        console.log('usrmgmt', usrmgmt.isFetched && usrmgmt.data.userNm);
    },[usrmgmt])

    //차종 및 언어
    const [selectedLangCdByVehl, setSelectedLangCdByVehl] = useState([]);
    const columnDefs = [
        {
          headerName: '차종',
          field: 'qltyVehlNm',
        },
        {
          headerName: '언어',
          field: 'langCdNm',
        },
    ]
    const [firstRender, setFirstRender] = useState(false)
    useEffect(() => {
        if(selectedLangCdByVehl.length > 0){
            setFirstRender(true)
        } 

        if(firstRender){
            setFormError(formError => ({...formError, senderListVali: selectedLangCdByVehl.length === 0 ? true : false}));
        }
    }, [selectedLangCdByVehl, firstRender]);

    // 수신인
    const paramsUsr = {
        blnsCoCd: coCd
    }
    const usrData = useQuery([API.userMgmtPop,paramsUsr], () => getData(API.userMgmtPop, paramsUsr), {
        select: data => data.map(item => ({...item, coDeptNm: item.coNm+'('+item.deptNm+')'}))
    })
    //수신인 그리드 내에서 클릭된 RowData by Woong
    const [checkedRowData, setCheckedRowData] = useState();
    const onSelectionChanged = useCallback(() => {
        const selectedRows = gridRef.current.api.getSelectedRows();
        setCheckedRowData(selectedRows)
    }, []);

    useEffect(() => {
        console.log('usrData',usrData)
    },[usrData]);



    // Form 정의 (for validation..)
    const formRef = React.useRef();
    const [formError, setFormError] = React.useState({});
    const [formValue, setFormValue] = React.useState({
        // rcpmShapCd: '',               // 수신형태
        // userEeno: '',                 // 등록자
        // dsppNm: '',                   // 발신처
        // crgrNm: '',                   // 담당자
        // langCdByVehlListVali: 'no',   // 선택한 차종및언어 리스트(mutate 하기전에 가공필요..)
        // senderListVali: 'no',         // 선택한 송부인 리스트
        // altrTitl:'',                   // 제목
        // altrSbc:'',                   // 내용
    });



    

    const [rowData] = useState([
        {selectCar: "(AA)AA-CAR", selectYear: "23MY", selectLang: "(EE)영어/유럽" },
        {selectCar: "(AA)AA-CAR", selectYear: "23MY", selectLang: "(EE)영어/유럽" },
        {selectCar: "(AA)AA-CAR", selectYear: "23MY", selectLang: "(EE)영어/유럽" },
        {selectCar: "(AA)AA-CAR", selectYear: "23MY", selectLang: "(EE)영어/유럽" },
        {selectCar: "(AA)AA-CAR", selectYear: "23MY", selectLang: "(EE)영어/유럽" },
    ]);

 

    const [rowData2] = useState([
        {userPart: "현대자동차", userName: "홍길동"},
        {userPart: "현대자동차", userName: "김삼순"},
        {userPart: "현대자동차", userName: "김삼순"},
        {userPart: "현대자동차", userName: "김삼순"},
    ]);

    const columnDefs2 = [
        {
          checkboxSelection: true,
          headerCheckboxSelection: true,
          width:45,
          maxWidth:45,
          minWidth:45
        },
        {
          headerName: '소속',
          field: 'coDeptNm',
        },
        {
          headerName: '이름',
          field: 'userNm',
        },
    ]

    const defaultColDef = useMemo(() => {
        return {
            initialWidth: 90,
            sortable: true,
        };
    }, []);


    const onFirstDataRendered = (params) => {
        params.api.sizeColumnsToFit();
    };


    

    // 이메일 테스트
    const insertMutate = useMutation((params => postData(API.boardAffrMgmt, params, CONSTANTS.insert)),{
        onSuccess: res => {

        }
    });

    const ref = useRef();


    const [flag, setFlag ] = useState(false)
    useEffect(() => {
        setTimeout(() => {
             
            setFlag(true);
        
        }, 500)
    },[])

   

    
    const saveButton = () => {

        if (!formRef.current.check()) {
            return;
        }

        setFormError(formError => ({...formError, senderListVali: selectedLangCdByVehl.length === 0 ? true : false}));

        // console.log('##############################' + DEXT5.getBodyValue());
        // console.log('##############################' + DEXT5.getBodyTextValue());

        // var textCount = DEXT5Editor.getBodyTextLength('editor1');
        // console.log('textCount', textCount);

        // console.log('data', DEXT5.data);

        // const params = {
        //     emlTitl: 'title test',
        //     emlSbc: 'content test',
        //     rcvrIds: ['H2212238', 'H2212239'],
        // };
        // insertMutate(params);


        // 파일업로드 실행
        // DEXT5UPLOAD.Transfer();
        

    }

    // 기존업로드된 파일리스트 (수정화면에서 사용)
    const onCreationComplete = e => {

        DEXT5UPLOAD.AddUploadedFile( 100, "메뉴.PNG", "", "", token, 'dext5upload1' );
        // DEXT5UPLOAD.AddUploadedFileEx( 100, "메뉴.PNG", "", "", token, "'홍길동|2016-01-04", 'dext5upload1' );
    }

    // 파일업로드후 리턴값
    const onTransferComplete = e => {
        console.log(e)

        // const list = DEXT5UPLOAD.GetNewUploadListForText("dext5upload1");
        

        const list = DEXT5UPLOAD.GetAllFileListForJson("dext5upload1");
        console.log('list', list)
    }


    return (
        <>
            <div className="write-wrap">
                <Form
                        ref={formRef}
                        checkTrigger="change"
                        onChange={setFormValue}
                        onCheck={setFormError}
                        formValue={formValue}
                        model={model}
                    >
                    <Table className="tbl-hor" bordered>
                        <colgroup>
                            <col style={{width:'15%'}}></col>
                            <col style={{width:'35%'}}></col>
                            <col style={{width:'15%'}}></col>
                            <col style={{width:'35%'}}></col>
                        </colgroup>
                        <tbody>
                            <tr>
                                <th>분류</th>
                                <td>
                                    <Form.Control name="gubun" size="sm" 
                                        placeholder={'선택'}
                                        defaultValue={''}
                                        accepter={SelectPicker} 
                                        searchable={false}
                                        cleanable={false}
                                        data={gubunCombo.data}
                                    ></Form.Control>

                                </td>
                                <th>등록자</th>
                                <td>{usrmgmt.isFetched && usrmgmt.data.userNm}</td>
                            </tr>
                            <tr>
                                <th>차종 및 언어</th>
                                <td colSpan="3">
                                    <VehlLangCascader 
                                        setSelectedLangCdByVehl={setSelectedLangCdByVehl} 
                                        formErrorStatus={formError.langCdByVehlListVali} 
                                        firstRender={firstRender} />
                                    {formError.senderListVali && <Form.ErrorMessage show={true} >
                                        {'차종 및 언어를 선택해주세요.'}
                                    </Form.ErrorMessage>}
                                </td>
                            </tr>
                            <tr>
                                <th>적용 차종 및 언어</th>
                                <td>
                                    <div className="ag-theme-alpine" style={{height: 130, transition:'all ease .3s'}}>
                                        <AgGridReact
                                            initialWidth={90}
                                            sortable={true}
                                            // defaultColDef={defaultColDef}
                                            columnDefs={columnDefs}
                                            rowData={selectedLangCdByVehl}
                                            onFirstDataRendered={onFirstDataRendered}
                                            suppressSizeToFit={true}    
                                            onGridSizeChanged={onFirstDataRendered}    
                                            overlayNoRowsTemplate={'적용차종 및 언어를 선택하세요.'}
                                            >
                                        </AgGridReact>
                                    </div>
                                </td>
                                <th>수신인</th>
                                <td>
                                    <div className="ag-theme-alpine" style={{height: 130, transition:'all ease .3s'}}>
                                        {usrData && usrData.isSuccess &&
                                            <AgGridReact
                                            ref={gridRef}
                                            initialWidth={90}
                                            sortable={true}
                                            // defaultColDef={defaultColDef}
                                            rowData={usrData && usrData.isSuccess &&usrData.data}
                                            columnDefs={columnDefs2}
                                            rowSelection={'multiple'}
                                            suppressRowClickSelection= {true} 
                                            onFirstDataRendered={onFirstDataRendered}
                                            suppressSizeToFit={true}    
                                            onGridSizeChanged={onFirstDataRendered}
                                            // checkedRowDatas by Woong
                                            onSelectionChanged={onSelectionChanged}
                                            
                                            >
                                            </AgGridReact>
                                        }
                                    </div>
                                </td>
                            </tr>
                            <tr>
                                <th>전 MY 투입가능</th>
                                <td>
                                    <RadioGroup name="radioList" inline>
                                        <Radio value="A">Y</Radio>
                                        <Radio value="B">N</Radio>
                                    </RadioGroup>
                                </td>
                                <th>책등 유무</th>
                                <td>
                                    <div className="form-group">
                                         <Form.Control inline name="radio" accepter={RadioGroup} defaultValue={'N'}>
                                            <Radio value="Y">Y</Radio>
                                            <Radio value="N">N</Radio>
                                        </Form.Control>
                                        <Form.Control name="" className="inline-block ml-10" size="sm" style={{width:'130px'}} type="text" placeholder="색상을 입력해주세요" />
                                    </div>
                                </td>
                            </tr>
                            <tr>
                                <th>분리투입 여부</th>
                                <td>
                                    <RadioGroup name="radioList2" inline>
                                        <Radio value="A">Y</Radio>
                                        <Radio value="B">N</Radio>
                                    </RadioGroup>
                                </td>
                                <th>분리투입 요청일</th>
                                <td>
                                    <CustomProvider locale={ko}>
                                        <DatePicker oneTap cleanable={false} size="sm" defaultValue={new Date()} className="inline-block" style={{width:'150px'}}/>
                                    </CustomProvider>
                                    <Checkbox value="" className="ml-10">미확정</Checkbox>
                                </td>
                            </tr>
                            <tr>
                                <th>교체투입 여부(이전매뉴얼 폐기)</th>
                                <td>
                                    <RadioGroup name="radioList2" inline>
                                        <Radio value="A">Y</Radio>
                                        <Radio value="B">N</Radio>
                                    </RadioGroup>
                                </td>
                                <th>신규매뉴얼 투입 요청일</th>
                                <td>
                                    <CustomProvider locale={ko}>
                                        <DatePicker oneTap cleanable={false} size="sm" defaultValue={new Date()} className="inline-block" style={{width:'150px'}}/>
                                    </CustomProvider>
                                    <Checkbox value="" className="ml-10">미확정</Checkbox>
                                </td>
                            </tr>
                            <tr>
                                <th>제목</th>
                                <td colSpan="3">
                                    <Form.Control size="sm" type="text" placeholder="제목을 입력해주세요" />
                                </td>
                            </tr>
                            <tr>
                                <th>내용</th>
                                <td colSpan="3">
                                    <DEXT5Editor
                                        debug={true}
                                        id="editor1"
                                        componentUrl="/dext5editor/js/dext5editor.js"
                                        config={{ DevelopLangage:'NONE', Width:'100%' }}
                                        initData="<p>Hello <strong>DEXT5 Editor</strong> world!</p>"
                                    />
                                </td>
                            </tr>
                            <tr>
                                <th>첨부파일</th>
                                <td colSpan="3">
                                    {flag && <DEXT5Upload
                                        onCreationComplete={onCreationComplete}
                                        onTransferComplete={onTransferComplete}
                                        debug={true}
                                        id="dext5upload1"
                                        mode='edit' 
                                        // mode='view'  // view Mode
                                        runtimes='html5'
                                        componentUrl="/dext5upload/js/dext5upload.js"
                                        config={{MaxTotalFileSize:'100MB', MaxOneFileSize:'30MB', DevelopLangage:'NONE',
                                        ButtonBarEdit: "add,remove,remove_all,download",
                                        // ButtonBarView: 'download,download_all', // view Mode
                                        Width:'100%'}}
                                        
                                    />}
                                </td>
                            </tr>
                        </tbody>
                    </Table>
                </Form>


        
                <div className="btn-wrap">
                    <div className="right-align">
                        <Button variant="light" >취소</Button>{' '}
                        <Button className="" variant="primary" size="md" onClick={saveButton}>저장</Button>
                    </div>
                </div>
            </div>
        </>
    )
};
export default BoardAdd;