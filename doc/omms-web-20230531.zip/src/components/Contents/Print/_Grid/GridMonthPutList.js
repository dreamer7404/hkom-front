import React, {useState, useEffect, useMemo, useRef} from 'react';
import { AgGridReact } from 'ag-grid-react';
import { CONSTANTS } from '../../../../utils/constants';

const GridMonthPutList = ({gridHeight, filterValue, queryResult, limit, activePage}) => {

  const gridRef = useRef();

  const rowSpan = (params) => {
        return params.data.flag? params.data.flag: 1;
    };

  class ShowCellRenderer {
      init(params) {  console.log(params.data.flag)
      const cellBlank = !params.value;
      if (cellBlank) {
          return;
      }
  
      this.ui = document.createElement('div');
      this.ui.innerHTML = '<div class="rowspan-title" style="line-height:' + params.data.flag * '30' + 'px;">' + params.value + '</div>';
      
      }
  
      getGui() {
      return this.ui;
      }
  
      refresh() {
      return false;
      }
  }
  
  const [columnDefs] = useState([
      {
        headerName: '차종',
        children: [
          { 
              headerName:'차종코드',
              field: 'carCd',
              sortable: true,
              cellRenderer: ShowCellRenderer,
              rowSpan: rowSpan,
              cellClass: (rowSpan) => {
                return rowSpan.data.flag >= 2 ? 'show-cell' : null;
              },
          },
          { headerName:'차종명',
            field: 'carName',
            sortable: true,
            cellRenderer: ShowCellRenderer,
            rowSpan: rowSpan,
            cellClass: (rowSpan) => {
                return rowSpan.data.flag >= 2 ? 'show-cell' : null;
              },
          },
        ],
      },
      {
        headerName: '언어',
        children: [
          { 
              headerName:'지역', 
              field: 'region', 
              sortable: true,
              cellRenderer: ShowCellRenderer,
              rowSpan: rowSpan,
              cellClass: (rowSpan) => {
                return rowSpan.data.flag >= 2 ? 'show-cell' : null;
              },
          },
          { 
              headerName:'언어코드',
              field: 'langCd',
              sortable: true,
              cellRenderer: ShowCellRenderer,
              rowSpan: rowSpan,
              cellClass: (rowSpan) => {
                return rowSpan.data.flag >= 2 ? 'show-cell' : null;
              },

          },
          {
              headerName:'언어명',
              sortable: true,
              field: 'langName',
              cellRenderer: ShowCellRenderer,
              rowSpan: rowSpan,
              cellClass: (rowSpan) => {
                return rowSpan.data.flag >= 2 ? 'show-cell' : null;
              },
          },
        ],
      },
      {
          headerName: '항목',
          field: 'whotPart',
          spanHeaderHeight: true,
      },
      {
        headerName: '22.01월',
        field: 'month1',
        spanHeaderHeight: true,
      },
      {
        headerName: '22.02월',
        field: 'month2',
        spanHeaderHeight: true,
      },
      {
        headerName: '22.03월',
        field: 'month3',
        spanHeaderHeight: true,
      },  
      {
        headerName: '22.04월',
        field: 'month4',
        spanHeaderHeight: true,
      },  
      {
        headerName: '22.05월',
        field: 'month5',
        spanHeaderHeight: true,
      },
      {
        headerName: '22.06월',
        field: 'month6',
        spanHeaderHeight: true,
      },
      {
          headerName: '22.07월',
          field: 'month7',
          spanHeaderHeight: true,
      },
      {
          headerName: '22.08월',
          field: 'month8',
          spanHeaderHeight: true,
      },
      {
          headerName: '22.09월',
          field: 'month9',
          spanHeaderHeight: true,
      },
      {
          headerName: '22.10월',
          field: 'month10',
          spanHeaderHeight: true,
      },
      {
          headerName: '22.11월',
          field: 'month11',
          spanHeaderHeight: true,
      },
      {
          headerName: '22.12월',
          field: 'month12',
          spanHeaderHeight: true,
      },
      {
          headerName: '23.01월',
          field: 'month13',
          spanHeaderHeight: true,
      },
  ])

  const defaultColDef = useMemo(() => {
      return {
          initialWidth: 90,
          sortable: true,
          resizable:true,
      };
  }, []);

  const onFirstDataRendered = (params) => {
      params.api.sizeColumnsToFit();
  };

  useEffect(()=>{
    if(queryResult.status === 'loading' && gridRef && gridRef.current && gridRef.current.api){
        gridRef.current.api.showLoadingOverlay();
    }
  },[queryResult]);

  useEffect(()=> {
    if(gridRef && gridRef.current && gridRef.current.api){
      gridRef.current.api.setQuickFilter(filterValue);
    }
  },[filterValue]);

  useEffect(()=> {
    if(gridRef && gridRef.current && gridRef.current.api){
      gridRef.current.api.paginationGoToPage(activePage-1);
    }
  },[activePage]);


  return(
      <div className="ag-theme-alpine" style={{height: gridHeight, transition:'all ease .3s'}}>
        <AgGridReact
            ref={gridRef} 
            rowData={queryResult && queryResult.data} 
            columnDefs={columnDefs}
            defaultColDef={defaultColDef}

            // paging
            pagination={true}
            paginationPageSize={limit} //
            suppressPaginationPanel={true} 
            // onPaginationChanged={onPaginationChanged}

            //  filter
            cacheQuickFilter={true}

            suppressRowTransform={true}

            // overlay
            overlayLoadingTemplate={CONSTANTS.gridLoading}
            overlayNoRowsTemplate={CONSTANTS.gridNoRows}

            onFirstDataRendered={onFirstDataRendered}
            suppressSizeToFit={true}    
            onGridSizeChanged={onFirstDataRendered}    
            >
        </AgGridReact>
    </div>
  )


};
export default GridMonthPutList;