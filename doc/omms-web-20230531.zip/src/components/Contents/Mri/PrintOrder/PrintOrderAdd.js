import React, {useState, useEffect, useCallback} from 'react';
import {Row, Col, Button, Collapse, Table} from 'react-bootstrap';
import {Form, CustomProvider, DatePicker, InputGroup, Input, SelectPicker, Radio, RadioGroup, Checkbox} from 'rsuite';
import SearchIcon from '@rsuite/icons/Search';
import AttachmentIcon from '@rsuite/icons/Attachment';

import ko from 'rsuite/locales/ko_KR';
//--------------  서버데이터용 필수 -------------------------------
import { useQuery} from 'react-query';
import { CONSTANTS } from '../../../../utils/constants';
import useStore from '../../../../utils/store';
import VehlType from '../../../Search/VehlType';
import Lang from '../../../Search/Lang';
//--------------// 서버데이터용 필수 -------------------------------

import GridPrintOrderAdd from '../_Grid/GridPrintOrderAdd';
import PrintArrayTable from '../Popup/PrintArrayTable';
import PrintPbcn from '../Popup/PrintPbcn';

const PrintOrderAdd = () => {
    
    //------------------- 필수 공통 ------------------------------
    const [open, setOpen] = useState(true); // 조건창 열기/닫기
    const {keyword } = useStore();  // 조회키워드 가져오기

    const [activePage, setActivePage] = useState(1);    // 페이지번호
    const [limit, setLimit] = useState(50);             // 페이지행수
    const [filterValue, setFilterValue] = useState(''); // 필터값

    const onChangePage = val => {
        setActivePage(val);
    };
    const onChangeLimit = val => {
        setLimit(val);
    };
    useEffect(()=>{
        onChangePage(1); // 페이지번호 리셋
    },[keyword]);

    // 필터
    const onFilterTextBoxChanged = useCallback((e) => {
        setFilterValue(e.target.value);
    }, []);

    // 검색창 열기/닫기 > 페이지네이션 여부에 따라 +-20px
    const gridExpand = () =>{
        setOpen(!open);
    }

    //-------------------// 필수 공통 ------------------------------

     const [rowData] = useState([
        {test1: "20", test2: "60", test3: "50", test4: '40', test5:'30', test6:'20', test7:'100', test8:'100', test9:'100', test10:'100', test11:'100', test12:'a', test13:'OK'},
    ]);

    //  requestState 조회
    const queryResult = useQuery(["PrintOrderAdd"], () => {return rowData});

    // 로딩중...
    // useEffect(()=>{
    //     if(ivmTotal.status === 'loading' && gridRef && gridRef.current && gridRef.current.api){
    //         gridRef.current.api.showLoadingOverlay();
    //     }
    // },[ivmTotal]);

    // 조회버튼
    const onSearch = () => {
        queryResult.refetch(); // 수동쿼리실행
    };

    const CustomInputGroupWidthButton = () => (
        <InputGroup inside >
            <Input style={{fontSize:'12px'}}/>
            <InputGroup.Button style={{height:'24px'}} onClick={() => setPrintPbcnPop(true)}>
            <SearchIcon />
            </InputGroup.Button>
        </InputGroup>
    );

    const Textarea = React.forwardRef((props, ref) => <Input {...props} as="textarea" ref={ref} />);

    const [printArrayTablePop, setPrintArrayTablePop] = useState(false);
    const [printPbcnPop, setPrintPbcnPop] = useState(false);

    return (
        <>
            <div className="search-area">
                <Collapse in={open}>
                    <div className="form" id="example-collapse-text">
                        <div className="search-group">
                            <div className="row">
                                <Col sm={5} className="" >
                                    <VehlType  />
                                </Col>
                                <Col sm={4} className="" >
                                    <Lang />
                                </Col>
                            </div>
                            <div className="search-btn-wrap">
                                <Button className="btn-search" variant="outline-primary" size="sm" onClick={onSearch}><SearchIcon />조회</Button>
                            </div>
                        </div>
                    </div>
                </Collapse>
                <Button size="sm" variant="outline-dark" className="search-control" aria-controls="example-collapse-text" 
                    aria-expanded={open} onClick={gridExpand}>
                    <span className={open === true ? "search-area-close" : "search-area-open"}>{open === true ? CONSTANTS.closeSearch : CONSTANTS.openSearch}</span>
                </Button>
            </div>
            
            <div className="grid-wrap">
                <div className="grid-btn-wrap">
                    <div className="left-align">
                        <div class="sub-title">
                            <ul>
                                <li>발간실적 기준정보</li>
                            </ul>
                        </div>
                    </div>
                </div>
                {/*--------- Grid -----------*/}
                <GridPrintOrderAdd 
                    filterValue={filterValue}
                    queryResult={queryResult}
                    limit={limit}
                    activePage={activePage}
                />


                <div className="write-wrap">
                    <Form>
                        <div className="grid-btn-wrap mt-4">
                            <div className="left-align">
                                <div class="sub-title">
                                    <ul>
                                        <li>세부내역</li>
                                    </ul>
                                </div>
                            </div>
                            <div className="right-align">
                                <Button className="" variant="outline-secondary" size="sm" onClick={() => setPrintArrayTablePop(true)}>인쇄배열표</Button>
                            </div>
                        </div>

                        <Table className="tbl-ver" bordered>
                            <colgroup>
                                <col style={{width:'10%'}}></col>
                                <col style={{width:'10%'}}></col>
                                <col style={{width:'7%'}}></col>
                                <col style={{width:'7%'}}></col>
                                <col style={{width:'7%'}}></col>
                                <col style={{width:'7%'}}></col>
                                <col style={{width:'16%'}}></col>
                                <col style={{width:'10%'}}></col>
                                <col style={{width:'10%'}}></col>
                                <col style={{width:'16%'}}></col>
                            </colgroup>
                            <tbody>
                                <tr className="thead-row">
                                    <th className="essen" colSpan="2">차종/언어</th>
                                    <th className="essen" colSpan="2">인쇄의뢰일/납품요청일</th>
                                    <th className="essen" colSpan="2">발행구분/인쇄부수</th>
                                    <th className="essen">인쇄방법</th>
                                    <th className="essen" colSpan="2">발간번호</th>
                                    <th>메모</th>
                                </tr>
                                <tr className="thead-row">
                                    <td colSpan="2"></td>
                                    <td colSpan="2">2023-04-20</td>
                                    <td colSpan="2">
                                        <SelectPicker size="sm" data={[{ label: "신제작"}]} searchable={false} cleanable={false} />
                                        {/* 옵션 >> 신제작, 개정발행, 추가제작, 스티커, 리플렛, 퀵가이드, 기타 */}
                                    </td>
                                    <td>
                                        <Row className="select-wrap">
                                            <Col>
                                                <SelectPicker size="sm" data={[{ label: "없음"}]} searchable={false} cleanable={false} />
                                                {/* 옵션 >> 없음, 1도, 2도, 3도, 4도, 5도 */}
                                            </Col>
                                            <Col>
                                                <SelectPicker size="sm" data={[{ label: "옵셋1도"}]} searchable={false} cleanable={false} />
                                                {/* 옵션 >> 옵셋1도, 옵셋2도, 디지털1도, 스티커1도, 스티커2도, 리플렛1도, 리플렛2도, 옵셋4도, 인디고 */}
                                            </Col>
                                        </Row>
                                    </td>
                                    <th className="essen">신규번호</th>
                                    <td>
                                        <Form.Control size="sm" type="text" placeholder="" />
                                    </td>
                                    <td rowSpan="2">
                                        <Form.Control name="textarea" accepter={Textarea} style={{height:'100%'}}/>
                                    </td>
                                </tr>
                                <tr className="thead-row">
                                    <td colSpan="2"></td>
                                    <td colSpan="2">
                                        <CustomProvider locale={ko}>
                                            <DatePicker oneTap cleanable={false} size="sm" defaultValue={new Date()} className="inline-block" style={{width:'150px'}}/>
                                        </CustomProvider>
                                    </td>
                                    <td colSpan="2">
                                        <Form.Control size="sm" type="text" placeholder="" />
                                    </td>
                                    <td>
                                        <SelectPicker size="sm" data={[{ label: "80화인코드지"}]} searchable={false} cleanable={false} />
                                        {/* 옵션 >> 80화인코드지, 70모조지, 73그린매트지 */}
                                    </td>
                                    <th>기존번호</th>
                                    <td><CustomInputGroupWidthButton size="sm" /></td>
                                </tr>
                                <tr className="thead-row">
                                    <th>의뢰자</th>
                                    <th>SIZE</th>
                                    <th>표지</th>
                                    <th>내지</th>
                                    <th>내지 총 페이지</th>
                                    <th>외주업체</th>
                                    <th>외주편집 업체</th>
                                    <th>수정페이지</th>
                                    <th>커버</th>
                                    <th>게시판 관리번호</th>
                                </tr>
                                <tr className="thead-row">
                                    <td>김수영</td>
                                    <td>
                                        <Form.Control size="sm" type="text" placeholder="" />
                                    </td>
                                    <td>
                                        첨부파일
                                    </td>
                                    <td>
                                        첨부파일
                                    </td>
                                    <td>
                                        <Form.Control size="sm" type="text" placeholder="" />
                                    </td>
                                    <td>
                                        <Form.Control size="sm" type="text" placeholder="" />
                                    </td>
                                    <td>
                                        <SelectPicker size="sm" data={[{ label: "없음"}]} searchable={false} cleanable={false} />
                                        {/* 옵션 >> TLA 등... */}
                                    </td>
                                    <td>
                                        121
                                    </td>
                                    <td>
                                        <SelectPicker size="sm" data={[{ label: "사용"}]} searchable={false} cleanable={false} />
                                        {/* 옵션 >> 사용, 사용안함 */}
                                    </td>
                                    <td>
                                        <Form.Control size="sm" type="text" placeholder="" />
                                    </td>
                                </tr>
                            </tbody>
                        </Table>

                        <div className="grid-btn-wrap mt-4">
                            <div className="left-align">
                                <div class="sub-title">
                                    <ul>
                                        <li>개정내용</li>
                                    </ul>
                                </div>
                            </div>
                        </div>

                        <Table className="tbl-ver" bordered>
                            <colgroup>
                                <col style={{width:'10%'}}></col>
                                <col style={{width:'10%'}}></col>
                                <col style={{width:'10%'}}></col>
                                <col style={{width:'10%'}}></col>
                                <col style={{width:'5%'}}></col>
                                <col style={{width:'%'}}></col>
                                <col style={{width:'5%'}}></col>
                                <col style={{width:'5%'}}></col>
                            </colgroup>
                            <thead>
                                <tr>
                                    <th>등록번호</th>
                                    <th>수신형태</th>
                                    <th>수신일</th>
                                    <th>발신처</th>
                                    <th>담당자</th>
                                    <th>개정 내용</th>
                                    <th>첨부</th>
                                    <th>적용 여부</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td>ABC-123</td>
                                    <td>협조전</td>
                                    <td>2023-04-20</td>
                                    <td>안전기술전략팀</td>
                                    <td>홍길동</td>
                                    <td>개정내용입니다.</td>
                                    <td>
                                        <AttachmentIcon className="attach-func" />
                                    </td>
                                    <td className="no-label-chk">
                                        <Checkbox value="" />
                                    </td>
                                </tr>
                            </tbody>
                        </Table>
                        
                    </Form>
                </div>

                <div className="btn-wrap">
                    <div className="left-align">
                        <Button variant="light">목록</Button>{' '}
                    </div>
                    <div className="right-align">
                        <Button variant="outline-secondary" size="md">임시저장</Button>{' '}
                        <Button className="" variant="primary" size="md">O/M발주</Button>
                    </div>
                </div>

            </div>

            <PrintArrayTable show={printArrayTablePop} onHide={() => setPrintArrayTablePop(false)}  />
            <PrintPbcn show={printPbcnPop} onHide={() => setPrintPbcnPop(false)}  />
        </>
    )
};
export default PrintOrderAdd;