import React,{useState,useEffect} from 'react';
import {Row, Col, Button, Modal, Table} from 'react-bootstrap';
import {Form, SelectPicker } from 'rsuite';
import { API, CONSTANTS } from '../../../../utils/constants';
import useStore from '../../../../utils/store';
import { useQuery} from 'react-query';
import { getData } from '../../../../utils/async';
import { escapeCharChange, formatNumber } from '../../../../utils/commUtils';


const LangCopy = ({show, onHide,langCopyEvent}) => {
    

    const [qltyVehlCd, setQltyVehlCd] = useState(); //  차종코드
    const [mdlMdyCd, setMdlMdyCd] = useState();     // 차량Mdy코드

    const onChangeVehlCombo = val => {
        console.log("차종",val);
        setQltyVehlCd(val);
    };
    const onChangeVehlMdyCombo = value => {
        console.log("연식",value);
        setMdlMdyCd(value);
        searchData();
       
    };
 
    const vehlCombo = useQuery([API.vehlCombo, {}], () => getData(API.vehlCombo, {}), {
        select: data => [{label: CONSTANTS.labelAll, value: CONSTANTS.valueAll}]
            .concat(data.map((item) => ({ label: escapeCharChange(item.qltyVehlNm), value: item.qltyVehlCd })))
    }); 
    
    const mdlMdyParams={
        // qltyVehlCd : keyword.qltyVehlCd.replace('ALL','')
        qltyVehlCd: qltyVehlCd
    }
    const qltyVehlMdyCombo = useQuery([API.qltyVehlMdyCombo,mdlMdyParams], () => getData(API.qltyVehlMdyCombo,mdlMdyParams), {
        select: data => data.map(item => ({ label: escapeCharChange(item.TOT_NM), value: item.MDL_MDY_CD })) 
    });

    

    const langCopyParams = {
        qltyVehlCd : qltyVehlCd,
        mdlMdyCd : mdlMdyCd
    }
    const queryResult =  useQuery([API.langCopys, langCopyParams], () => getData(API.langCopys, langCopyParams));


    const searchData = () =>{
        queryResult.refetch();
        
    }

    useEffect(()=>{
        if(queryResult.isSuccess && mdlMdyCd && qltyVehlCd ){
            console.log("데이터 : " ,queryResult.data)
            langCopyEvent(queryResult.data.copyLangList)
        }

    },queryResult.status)
    return (
        <>
            <Form>
                <Modal show={show} onHide={onHide} backdrop="static" backdropClassName="modal-in-backdrop" keyboard={false} centered size="md" className="modal-custom modal-in-modal">
                    <Modal.Header closeButton>
                        <Modal.Title>언어복사</Modal.Title>
                    </Modal.Header>
                        <Modal.Body>
                            <Table className="tbl-hor" bordered>
                                <tbody>
                                    <tr>
                                        <th>기존차종</th>
                                        <td>
                                            <Row className="select-wrap">
                                                <Col sm={8}>
                                                    <SelectPicker size="sm" 
                                                        // value={keyword.qltyVehlCd} 
                                                        value={qltyVehlCd} 
                                                        data={vehlCombo && vehlCombo.data ? vehlCombo.data : []}  
                                                        onChange={onChangeVehlCombo}
                                                        searchable={false} 
                                                        cleanable={false} 

                                                    />
                                                </Col>
                                                <Col sm={4}>
                                                    <SelectPicker size="sm" 
                                                        // value={keyword.valCd}
                                                        placeholder="선택"
                                                        value={mdlMdyCd}
                                                        searchable={false}
                                                        onChange={onChangeVehlMdyCombo}
                                                        data={qltyVehlMdyCombo && qltyVehlMdyCombo.data ? qltyVehlMdyCombo.data : []}  
                                                        cleanable={false} 

                                                    />
                                                </Col>
                                            </Row>
                                        </td>
                                    </tr>
                                </tbody>
                            </Table>
                        </Modal.Body>

                        <Modal.Footer>
                            <Button variant="light" size="md" onClick={onHide}>취소</Button>
                            <Button variant="primary" size="md" onClick={onHide}>저장</Button>
                        </Modal.Footer>
                </Modal>
            </Form>
        </>
    );

};
export default LangCopy;