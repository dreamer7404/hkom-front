import React from 'react';
import {Button, Modal, Table} from 'react-bootstrap';
import {  Form, SelectPicker, Schema } from 'rsuite';
import {CONSTANTS, API } from '../../../../utils/constants';
import { getData, postData } from '../../../../utils/async';
import { useQuery,useMutation} from 'react-query';
import { useEffect } from 'react';
import { confirmAlert } from 'react-confirm-alert'; // Import
import ConfirmAlert from '../../../Common/ConfirmAlert';


const { StringType} = Schema.Types;

const model = Schema.Model({
    langCdNm: StringType().isRequired('언어명을 입력해주세요.'),
});
const LangCodeUpdate = ({auth, show, onHide,data}) => {
    const containerRef = React.useRef();
    const formRef = React.useRef();
    const [formError, setFormError] = React.useState({});
    const [formValue, setFormValue] = React.useState({
        langCd : '',
        langCdNm : '',
        useYn:'',                   // 사용유무
        dlExpdRegnCd: ''
        
        
    }); 

    const paramsCo = {dlExpdGCd: CONSTANTS.grpCdRegn};
    const regnCombo = useQuery([API.codeCombo,paramsCo], () => getData(API.codeCombo,paramsCo)) 

    const param = {
        langCd : data.langCd
    }
    const queryResult = useQuery([API.langMst, param], () => getData(API.langMst, param),{
        staleTime: 0,
        
    });
    useEffect(()=>{
        if(queryResult.isSuccess){
    
            const dataInfo = queryResult.data;
    
            setFormValue({
                langCd : dataInfo.langCd,               // 사용여부
                langCdNm : dataInfo.langCdNm,             // A코드
                dlExpdRegnCd : dataInfo.dlExpdRegnCd, // 지역코드
                useYn : dataInfo.useYn
            })
        }
    },[queryResult.status])

    const handleSubmit = () => {
        if (!formRef.current.check()) { //validation chk
            return;
        }
        confirmAlert({
            closeOnClickOutside: false,
            customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}   title={"알림"}
            msg={"입력하신 내용으로 저장하시겠습니까?"} 
            onOk={onOk}  />
        });
    };
    const handleSubmitDel = () => {
        confirmAlert({
            closeOnClickOutside: false,
            customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}   title={"알림"}
            msg={"삭제하시겠습니까?"} 
            onOk={onDelete}  />
        });
    };
    const onOk = () => {
       
        vehlLangSave.mutate(formValue);
    }
    const onDelete = () => {
       
        vehlLangDelete.mutate(formValue);
    }

    const vehlLangSave = useMutation((params => postData(API.langMst, params, CONSTANTS.update)),{
        onSuccess: res => {
           if(res>0){
                confirmAlert({
                    closeOnClickOutside: false,
                    customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}   title={"알림"}
                    msg={"저장이 완료되었습니다."}   />
                    
                });
           }
           else{
            confirmAlert({
                closeOnClickOutside: false,
                customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}   title={"알림"}
                msg={"에러가 발생했습니다 관리자에게 문의해주세요."}   />
                
            });
           }
           onHide();
        }
    });
    const vehlLangDelete = useMutation((params => postData(API.langMst, params, CONSTANTS.delete)),{
        onSuccess: res => {
           if(res>0){
                confirmAlert({
                    closeOnClickOutside: false,
                    customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}   title={"알림"}
                    msg={"삭제가 완료되었습니다."}   />
                    
                });
           }
           else{
            confirmAlert({
                closeOnClickOutside: false,
                customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}   title={"알림"}
                msg={"에러가 발생했습니다 관리자에게 문의해주세요."}   />
                
            });
           }
           onHide();
        }
    });

    
    return (
        <>
           <Form
                ref={formRef}
                checkTrigger="change"
                onChange={setFormValue}
                onCheck={setFormError}
                formValue={formValue}
                model={model}>
                <Modal show={show} onHide={onHide} backdrop="static" keyboard={false} centered size="md" className="modal-custom">
                    <Modal.Header closeButton>
                        <Modal.Title>언어코드 상세/수정</Modal.Title>
                    </Modal.Header>
                        <Modal.Body>
                            <Table className="tbl-hor" bordered>
                                <colgroup>
                                    <col style={{width:'30%'}}></col>
                                    <col style={{width:''}}></col>
                                </colgroup>
                                <tbody>
                                    <tr>
                                        <th className="essen">언어코드</th>
                                        <td name = "langCd">
                                             {queryResult.data && queryResult.data.langCd}
                                        </td>
                                    </tr>
                                    <tr>
                                        <th className="essen">언어명</th>
                                        <td>
                                            <Form.Control name = "langCdNm" size="sm" type="text"/> 
                                        </td>
                                    </tr>
                                    <tr>
                                        <th className="essen">지역</th>
                                        <td>
                                        {regnCombo.isSuccess &&
                                                    <Form.Control container={()=> containerRef.current}  name="dlExpdRegnCd" size="sm" style={{zIndex: 0}} 
                                                        placeholder={'선택'}
                                                        defaultValue={''}
                                                        accepter={SelectPicker} 
                                                        searchable={false}
                                                        cleanable={false}
                                                        data={regnCombo.isFetched && regnCombo.data}
                                                        
                                                    ></Form.Control>
                                                }
                                        </td>
                                    </tr>
                                    <tr>
                                        <th className="">사용여부</th>
                                        <td>
                                        <Form.Control name="useYn" size="sm"   
                                                    container={()=> containerRef.current}
                                                    placeholder={'선택'}
                                                    defaultValue={''}
                                                    accepter={SelectPicker} 
                                                    searchable={false}
                                                    cleanable={false}
                                                    data={[
                                                        {label: '사용', value: 'Y'},
                                                        {label: '미사용', value: 'N'},
                                                    ]}
                                            ></Form.Control>
                                        </td>
                                    </tr>
                                </tbody>
                            </Table>
                        </Modal.Body>

                        <Modal.Footer>
                            <Button variant="light" size="md" onClick={onHide}>취소</Button>
                            {auth && auth==='100' && <Button variant="outline-danger" size="md" onClick={handleSubmitDel}>삭제</Button>}
                            <Button variant="primary" size="md" onClick={handleSubmit} >저장</Button>
                        </Modal.Footer>
                </Modal>
            </Form>

        </>
    );

};
export default LangCodeUpdate;