/* eslint-env node */

const path = require( 'path' );
const CopyPlugin = require( 'copy-webpack-plugin' );
const HtmlWebpackPlugin = require( 'html-webpack-plugin' );

module.exports = {
	entry: './src/index.js',
	mode: 'development',
	devtool: 'source-map',
	output: {
		// path: path.resolve( __dirname, './public' ),
		path: path.resolve( __dirname, './build' ),
		filename: 'bundle.js'
	},
    devServer: {
        port: 3000, 
        historyApiFallback: true,
    },
	resolve: {
		extensions: [ '.js', '.jsx' ],
		alias: {
			react$: path.resolve( __dirname, './node_modules/react' ),
			'react-dom$': path.resolve( __dirname, './node_modules/react-dom' )
		}
	},
	module: {
		rules: [
			{
				test: /\.(js|jsx)$/,
				exclude: /node_modules/,
				use: {
					loader: 'babel-loader',
					options: {
						presets: ["@babel/preset-env", ["@babel/preset-react", {"runtime": "automatic"}]]
          }
        }
      },
      {
        test: /\.css$/,
        use:['style-loader','css-loader'] 
      },
      {
        test: /\.(jpe?g|png|gif|svg|ico)$/i,
        use: [
          {
            loader: 'url-loader',
            options: {
              limit: 8192,
              name: 'assets/images/[name].[hash:8].[ext]',
            }
          }
        ]
      },
      {
        test: /\.svg$/,
        use: ['@svgr/webpack'],
      },
      {
        test: /\.(woff|woff2|eot|ttf|otf)$/i,
        use: [
          {
            loader: 'file-loader',
            options: {
              name: 'assets/fonts/[name].[hash:8].[ext]',
            },
          },
        ],
      },
             
		]
	},
	plugins: [
		new HtmlWebpackPlugin( {
			title: 'omms-web',
			// template: 'src/index.html'
			template: 'public/index.html',
      favicon: "./public/favicon.ico",
      manifest: "./public/manifest.json"
		} )
	]
};
