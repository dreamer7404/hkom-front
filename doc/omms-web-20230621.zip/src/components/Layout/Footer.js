// react
import React from 'react';

// react-bootstrap
import Container from 'react-bootstrap/Container';
import Nav from 'react-bootstrap/Nav';
import Navbar from 'react-bootstrap/Navbar';

const Footer = () => {
    return (
        <div className='footer' >
            <Container fluid>
                Footer...
            </Container>
        </div>
    );
};
export default Footer;