/* eslint-disable react-hooks/exhaustive-deps */
import React, {useState} from 'react';
import {Row, Col} from 'react-bootstrap';
import { SelectPicker, Form } from 'rsuite';

//--------------  서버데이터용 필수 -------------------------------
import { useQuery} from 'react-query';
import { getData } from '../../utils/async';
import { API, CONSTANTS } from '../../utils/constants';
import useStore from '../../utils/store';
//--------------// 서버데이터용 필수 -------------------------------
import { escapeCharChange} from '../../utils/commUtils';

const hdList = ['02', '03', '04', '05', '06', '07', '08', '09', '10' , '11'];
const kiaList = ['02', '03', '04', '05', '06',  '11'];

const CoDept = () => {
    
    const {
        coCd,
        deptCd,
        setDeptCd,
    } = useStore(); 


    const onChangeDept = val => {
        setDeptCd(val);
    };


    // 업무/회사
    const paramsDept = {
        dlExpdGCd: '0011',
    };
    const deptCombo = useQuery([API.codeCombo, paramsDept], () => getData(API.codeCombo, paramsDept), {
            select: data => [{label: CONSTANTS.labelAll, value: CONSTANTS.valueAll}]
                .concat(data)
                .filter(item => (coCd === 'ALL' && item)
                    || (coCd === '01' && hdList.indexOf(item.value) > -1)
                    || (coCd === '02' && kiaList.indexOf(item.value) > -1))
                .map(item => ({label: escapeCharChange(item.label), value: item.value}))
    });

    return (
        <>
            <Form.ControlLabel column="sm" >업무/회사</Form.ControlLabel>
            <Row className="select-wrap">
                <Col> 
                    <SelectPicker size="sm" style={{width: '100%'}}
                        value={deptCd} 
                        data={deptCombo && deptCombo.data ? deptCombo.data : []} 
                        onChange={onChangeDept}
                        placeholder={CONSTANTS.labelAll}
                        cleanable={false}
                        searchable={false}
                        block={true}
                    />
                </Col>
            </Row>
            
        </>
    );

};
export default CoDept;