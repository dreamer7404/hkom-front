import React, {useState, useRef,useEffect} from 'react';
import {Button, Modal, Table} from 'react-bootstrap';
import {Form,Schema} from 'rsuite';
import { API, CONSTANTS } from '../../../../utils/constants';
import { useQuery,useMutation} from 'react-query';
import { getData,postData } from '../../../../utils/async';
import { confirmAlert } from 'react-confirm-alert'; // Import
import ConfirmAlert from '../../../Common/ConfirmAlert';

const { StringType} = Schema.Types;
const model = Schema.Model({
    dlExpdGNm: StringType().isRequired('그룹코드명을 입력해주세요.')
    
});
const SysCodeGroupAdd = ({show, onHide}) => {
    const formRef = useRef();
    const [formError, setFormError] = useState({});
    const [formValue, setFormValue] = useState({
        dlExpdGCd : '',
        dlExpdGNm : '',
    }); 
    const nextGrpCode = useQuery([API.nextGrpCode,{}], () => getData(API.nextGrpCode,{})) 


    const handleSubmit = () => {
        if (!formRef.current.check()) { //validation chk
            return;
        }
        confirmAlert({
            closeOnClickOutside: false,
            customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}   title={"알림"}
            msg={"입력하신 내용으로 저장하시겠습니까?"} 
            onOk={onOk}  />
        });
        
        
    }; 
    const codeGrpSave = useMutation((params => postData(API.codeGrpMgmt, params, CONSTANTS.insert)),{
        onSuccess: res => {
            if(res===999){
                confirmAlert({
                    closeOnClickOutside: false,
                    customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}   title={"알림"}
                    msg={"중복된 그룹코드가 있습니다."}   />
                    
                })
            }
           else if(res>0){
            confirmAlert({
                closeOnClickOutside: false,
                customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}   title={"알림"}
                msg={"저장이 완료되었습니다."}   />
                
            });
           }
           else{
            confirmAlert({
                closeOnClickOutside: false,
                customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}   title={"알림"}
                msg={"에러가 발생했습니다 관리자에게 문의해주세요."}   />
                
            });
           }
           onHide();
        }
    });


    const onOk = () => {
       
        codeGrpSave.mutate(formValue);
    }


    useEffect(()=>{
        if(nextGrpCode.data){
            setFormValue(p=>({...p,dlExpdGCd : nextGrpCode.data.dlExpdGCd}))
        }

    },[nextGrpCode.data])
    return (
        <>
            <Form
                ref={formRef}
                checkTrigger="change"
                onChange={setFormValue}
                onCheck={setFormError}
                formValue={formValue}
                model={model}>
                <Modal show={show} onHide={onHide} backdrop="static" keyboard={false} centered size="md" className="modal-custom">
                    <Modal.Header closeButton>
                        <Modal.Title>그룹코드 등록</Modal.Title>
                    </Modal.Header>
                        <Modal.Body>
                            <Table className="tbl-hor" bordered>
                                <colgroup>
                                    <col style={{width:'30%'}}></col>
                                    <col style={{width:''}}></col>
                                </colgroup>
                                <tbody>
                                    <tr>
                                        <th className="">그룹코드</th>
                                        <td>
                                            {nextGrpCode.data && nextGrpCode.data.dlExpdGCd}
                                        </td>
                                    </tr>
                                    <tr>
                                        <th className="essen">그룹명</th>
                                        <td>
                                            <Form.Control size="sm" name = "dlExpdGNm" type="text"/>
                                        </td>
                                    </tr>
                                </tbody>
                            </Table>
                        </Modal.Body>

                        <Modal.Footer>
                            <Button variant="light" size="md" onClick={onHide}>취소</Button>
                            <Button variant="primary" size="md" onClick={handleSubmit} >저장</Button>
                        </Modal.Footer>
                </Modal>
            </Form>
        </>
    );

};
export default SysCodeGroupAdd;