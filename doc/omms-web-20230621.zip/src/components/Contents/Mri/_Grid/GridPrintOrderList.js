import React, {useEffect, useMemo, useRef, useCallback} from 'react';
import { AgGridReact } from 'ag-grid-react';
import { CONSTANTS } from '../../../../utils/constants';
import { formatNumber, escapeCharChangeForGrid } from '../../../../utils/commUtils';

const GridPrintOrderList = ({gridHeight, filterValue, queryResult, limit, activePage, onCellClicked, checkRow}) => {

  const gridRef = useRef();

  // 수량 천단위 콤마 찍기 시작
  const currencyFormatter = (params) => {
    return formatNumber(params.value);
  };

  const columnDefs = [
        {
            checkboxSelection: true,
            spanHeaderHeight: true,
            headerCheckboxSelection: true,
            width:'45',
            maxWidth:45,
            minWidth:45,
            sortable:false
        },
        {
            headerName: '발행구분',
            field: 'iiWayCdNm',
            spanHeaderHeight: true,
        },
        {
            headerName: '발간번호',
            field: 'newPrntPbcnNo',
            spanHeaderHeight: true,
            cellStyle: () => ({textDecoration: 'underline', cursor: 'pointer', color:'#2589f5'})
        },
        {
          headerName: '차종',
          children: [
            { headerName:'차종코드', field: 'qltyVehlCd', spanHeaderHeight: true},
        { headerName:'차종명', field: 'qltyVehlNm', spanHeaderHeight: true, cellRenderer:"escapeCharChangeForGrid", cellStyle:() => ({textAlign: 'center'})},
        { headerName:'연식', field: 'mdlMdyCd', spanHeaderHeight: true },
          ],
        },
        {
          headerName: '언어',
          children: [
            { headerName:'지역', field: 'dlExpdRegnNm', spanHeaderHeight: true},
            { headerName:'언어코드', field: 'langCd', spanHeaderHeight: true },
            { headerName:'언어명', field: 'langCdNm', spanHeaderHeight: true, cellStyle:() => ({textAlign: 'center'}) },
          ],
        },
        {
          headerName: '납품 요청일',
          spanHeaderHeight: true,
          field: 'ordnRqstYmd',
        },
        {
          headerName: '인쇄부수',
          spanHeaderHeight: true,
          field: 'prntParrQty',
          valueFormatter: currencyFormatter
        },  
        {
          headerName: '발주자',
          spanHeaderHeight: true,
          field: 'userNm',
        },  
        {
          headerName: '발주상태',
          spanHeaderHeight: true,
          field: 'trtmRst',
          cellRenderer:'statusComponent'
        },
        {
          headerName: '발주상태코드',
          spanHeaderHeight: true,
          field: 'trtmRstCd',
          cellRenderer:'statusComponent'
        }, 
        {
          headerName: '발주일',
          spanHeaderHeight: true,
          field: 'ordnRqstYmd',
        },  
    ]

    const defaultColDef = useMemo(() => {
        return {
            initialWidth: 90,
            sortable: true,
            resizable:true,
        };
    }, []);

  const statusComponent = (props) => {
        
      if(props.value === "발주완료"){
        return(
            <div className="status-title status-1">
            {props.value}
            </div>
        )
      }else if(props.value === "임시저장"){
        return(
            <div className="status-title status-2">
            {props.value}
            </div>
        )
      }else{
        return(
            <div className="status-title status-4" style={{cursor:'pointer'}}>
            {props.value}
            </div>
        )
      }

  }

  const onFirstDataRendered = (params) => {
      params.api.sizeColumnsToFit();
  };

  const onSelectionChanged = useCallback(() => {
    const selectedRows = gridRef.current.api.getSelectedRows();
    checkRow(selectedRows)
  }, []);


  useEffect(()=>{
    if(queryResult.status === 'loading' && gridRef && gridRef.current && gridRef.current.api){
        gridRef.current.api.showLoadingOverlay();
    }
  },[queryResult]);

  useEffect(()=> {
    if(gridRef && gridRef.current && gridRef.current.api){
      gridRef.current.api.setQuickFilter(filterValue);
    }
  },[filterValue]);

  useEffect(()=> {
    if(gridRef && gridRef.current && gridRef.current.api){
      gridRef.current.api.paginationGoToPage(activePage-1);
    }
  },[activePage]);


  return(
      <div className="ag-theme-alpine" style={{height: gridHeight, transition:'all ease .3s'}}>
        <AgGridReact
            ref={gridRef} 
            rowData={queryResult && queryResult.data} 
            columnDefs={columnDefs}
            defaultColDef={defaultColDef}

            // paging
            pagination={true}
            paginationPageSize={limit} //
            suppressPaginationPanel={true} 
            // onPaginationChanged={onPaginationChanged}

            //  filter
            cacheQuickFilter={true}

            onCellClicked={onCellClicked}

            rowSelection={'multiple'}
            suppressRowClickSelection= {true} 

            frameworkComponents={{
                statusComponent,
                escapeCharChangeForGrid
            }}
            // overlay
            overlayLoadingTemplate={CONSTANTS.gridLoading}
            overlayNoRowsTemplate={CONSTANTS.gridNoRows}

            // checkedRowDatas by Woong
            onSelectionChanged={onSelectionChanged}

            onFirstDataRendered={onFirstDataRendered}
            suppressSizeToFit={true}    
            onGridSizeChanged={onFirstDataRendered}    
            >
        </AgGridReact>
    </div>
  )


};
export default GridPrintOrderList;