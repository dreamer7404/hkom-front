import React, {useEffect, useMemo, useState} from 'react';
import { AgGridReact } from 'ag-grid-react';
import { CONSTANTS } from '../../../../utils/constants';

const GridNatLangList = ({gridRef, gridHeight, filterValue, queryResult, limit, activePage, onCellClicked}) => {



  const [columnDefs, setColumnDefs] = useState( []);

  const defaultColDef = useMemo(() => {
      return {
          initialWidth: 90,
          sortable: true,
          resizable:true,
      };
  }, []);

  //사용여부
  const statusComonent = (props) => {
    if(props.value === "Y"){
      return(
          <div style={{color:'#2589f5'}}>
          {props.value}
          </div>
      )
    }else if(props.value === "N"){
      return(
          <div style={{color:'#dc3545'}}>
          {props.value}
          </div>
      )
    }
  }

  const onFirstDataRendered = (params) => {
      params.api.sizeColumnsToFit();
  };


  

  useEffect(()=>{
    if(queryResult.data) {
      console.log("data",queryResult.data)
      const item = queryResult.data.qltyCodeList;
      
      const arr = item.map(p=>({headerName:p.qltyVehlCd+'-'+p.mdlMdyCd,
                                field : p.col,
                                minWidth:'90',
                                flag : "qltyVehlCd",
                                cellStyle: () => ({textDecoration: 'underline', cursor: 'pointer', color:'#2589f5'})
                            }));

      setColumnDefs([
        {
          headerName: '국가코드',
          spanHeaderHeight: true,
          field: 'dlExpdNatCd',
          pinned:'left',
          minWidth:'100'
        },
        {
          headerName: '국가명',
          spanHeaderHeight: true,
          field: 'natNm',
          pinned:'left',
          minWidth:'150',
          cellStyle: () => ({textDecoration: 'underline', cursor: 'pointer', color:'#2589f5'})
        },
        {
          headerName: '지역',
          spanHeaderHeight: true,
          field: 'regnNm',
          pinned:'left',
          minWidth:'100',
        },
        {
          headerName: '제외대리점',
          spanHeaderHeight: true,
          field: 'dytmPlnNatCd',
          pinned:'left',
          minWidth:'150',
        },
        {
          headerName: '차종별 언어 (X:차기반영불요)',
          children: arr,
          minWidth:'80',
        }
    ])
     
    }

    
  },[queryResult.data]);

  useEffect(()=>{
    if(queryResult.status === 'loading' && gridRef && gridRef.current && gridRef.current.api){
        gridRef.current.api.showLoadingOverlay();
    }
  },[queryResult]);

  useEffect(()=> {
    if(gridRef && gridRef.current && gridRef.current.api){
      gridRef.current.api.setQuickFilter(filterValue);
    }
  },[filterValue]);

  useEffect(()=> {
    if(gridRef && gridRef.current && gridRef.current.api){
      gridRef.current.api.paginationGoToPage(activePage-1);
    }
  },[activePage]);


  return(
      <div className="ag-theme-alpine" style={{height: gridHeight, transition:'all ease .3s'}}>
        <AgGridReact
            ref={gridRef} 
            rowData={queryResult && queryResult.data && queryResult.data.natlLangList} 
            columnDefs={columnDefs}
            defaultColDef={defaultColDef}

            // paging
            pagination={true}
            paginationPageSize={limit} //
            suppressPaginationPanel={true} 
            // onPaginationChanged={onPaginationChanged}

            //  filter
            cacheQuickFilter={true}

            onCellClicked={onCellClicked}

            frameworkComponents={{
                statusComonent
            }}

            // overlay
            overlayLoadingTemplate={CONSTANTS.gridLoading}
            overlayNoRowsTemplate={CONSTANTS.gridNoRows}

            onFirstDataRendered={onFirstDataRendered}
            suppressSizeToFit={true}    
            onGridSizeChanged={onFirstDataRendered}    
            >
        </AgGridReact>
    </div>
  )


};
export default GridNatLangList;