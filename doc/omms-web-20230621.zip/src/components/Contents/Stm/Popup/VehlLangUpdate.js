import React from 'react';
import {Button, Modal, Table} from 'react-bootstrap';
import {  Form, SelectPicker, Schema } from 'rsuite';
import {CONSTANTS, API } from '../../../../utils/constants';
import { getData, postData } from '../../../../utils/async';
import { useQuery,useMutation} from 'react-query';
import { useEffect } from 'react';
import { confirmAlert } from 'react-confirm-alert'; // Import
import ConfirmAlert from '../../../Common/ConfirmAlert';
import CustomModal from '../../../Common/CustomModal';

const { StringType} = Schema.Types;

const model = Schema.Model({
   
});
const VehlLangUpdate = ({show, onHide,data}) => {
    const containerRef = React.useRef();
    const formRef = React.useRef();
    const [formError, setFormError] = React.useState({});
    const [formValue, setFormValue] = React.useState({
        qltyVehlCd: '',             // 차종코드
        mdlMdyCd:'',
        aaCode : '',
        useYn:'',                   // 사용유무
        sortSn : '',
    });  
    const paramsCo = {dlExpdGCd: CONSTANTS.grpCdRegn};
    const regnCombo = useQuery([API.codeCombo,paramsCo], () => getData(API.codeCombo,paramsCo)) 


    const param = {
        dataSn : data.dataSn
    }
    const queryResult = useQuery([API.langMgmt, param], () => getData(API.langMgmt, param),{
        staleTime: 0,
        
    });



    useEffect(()=>{
    if(queryResult.isSuccess){

        const dataInfo = queryResult.data;

        setFormValue({
            dlExpdRegnCd : dataInfo.dlExpdRegnCd, // 지역코드
            useYn : dataInfo.useYn,               // 사용여부
            aaCode : dataInfo.aaCode,             // A코드
            sortSn : dataInfo.sortSn,              // 정렬순서
            dataSn : data.dataSn
        })




    }



    },[queryResult.status])




    const handleSubmit = () => {
        if (!formRef.current.check()) { //validation chk
            return;
        }
        
        
        confirmAlert({
            closeOnClickOutside: false,
            customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}   title={"알림"}
            msg={"입력하신 내용으로 저장하시겠습니까?"} 
            
            onOk={onOk}  />
            
        });
        
        
    };
    const vehlLangSave = useMutation((params => postData(API.langMgmt, params, CONSTANTS.update)),{
        onSuccess: res => {
           if(res>0){
                confirmAlert({
                    closeOnClickOutside: false,
                    customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}   title={"알림"}
                    msg={"저장이 완료되었습니다."}   />
                    
                });
           }else{
            confirmAlert({
                closeOnClickOutside: false,
                customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}   title={"알림"}
                msg={"에러가 발생했습니다 관리자에게 문의해주세요."}   />
                
            });
           }
           onHide();
        }
    });


    const onOk = () => {
       
        vehlLangSave.mutate(formValue);
    }
    return (
        <>
                <Form
                ref={formRef}
                checkTrigger="change"
                onChange={setFormValue}
                onCheck={setFormError}
                formValue={formValue}
                model={model}>
                   <CustomModal open={show} 
                        title={'차종별 언어 상세/수정'}
                        size='md'
                        // handleOk={handleSubmit}
                        handleCancel={onHide} 
                        
                        >
             
                            <Table className="tbl-hor" bordered>
                                <colgroup>
                                    <col style={{width:'30%'}}></col>
                                    <col style={{width:''}}></col>
                                </colgroup>
                                <tbody>
                                    <tr>
                                        <th>차종코드</th>
                                        <td>
                                            {queryResult.data && queryResult.data.qltyVehlCd}
                                        </td>
                                    </tr>
                                    <tr>
                                        <th className="essen">지역</th>
                                        <td>
                                                {regnCombo.isSuccess &&
                                                    <Form.Control container={()=> containerRef.current}  name="dlExpdRegnCd" size="sm" style={{zIndex: 0}} 
                                                        placeholder={'선택'}
                                                        defaultValue={''}
                                                        accepter={SelectPicker} 
                                                        searchable={false}
                                                        cleanable={false}
                                                        data={regnCombo.isFetched && regnCombo.data}
                                                        
                                                    ></Form.Control>
                                                }
                                                
                                        </td>
                                    </tr>
                                    <tr>
                                        <th>언어코드</th>
                                        <td>
                                        {queryResult.data && queryResult.data.langCd}
                                        </td>
                                    </tr>
                                    <tr>
                                        <th>언어명</th>
                                        <td>
                                            {queryResult.data && queryResult.data.langCdNm}
                                        </td>
                                    </tr>
                                    <tr>
                                        <th className="">A코드</th>
                                        <td>
                                            <Form.Control size="sm" type="text" name = 'aaCode'/> 
                                        </td>
                                    </tr>
                                    <tr>
                                        <th className="">정렬순서</th>
                                        <td>
                                            <Form.Control size="sm" type="text" name = 'sortSn'/> 
                                        </td>
                                    </tr>
                                    <tr>
                                        <th className="">사용여부</th>
                                        <td>
                                        <Form.Control name="useYn" size="sm"   
                                                    container={()=> containerRef.current}
                                                    placeholder={'선택'}
                                                    defaultValue={''}
                                                    accepter={SelectPicker} 
                                                    searchable={false}
                                                    cleanable={false}
                                                    data={[
                                                        {label: '사용', value: 'Y'},
                                                        {label: '미사용', value: 'N'},
                                                    ]}
                                            ></Form.Control>
                                        </td>
                                    </tr>
                                </tbody>
                            </Table>
                            <div className='modal-footer'>
                                <Button variant="light" size="md" onClick={onHide}>취소</Button>
                                <Button variant="primary" size="md" onClick={handleSubmit} >저장</Button>
                            </div>
                            </CustomModal>
            </Form>

        </>
    );

};
export default VehlLangUpdate;