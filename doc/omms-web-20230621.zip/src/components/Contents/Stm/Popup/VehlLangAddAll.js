import React, {useState, useMemo ,useEffect, useRef} from 'react';
import { AgGridReact } from 'ag-grid-react';
import {Button, Modal, Table, Row, Col} from 'react-bootstrap';
import {Form, SelectPicker,Schema} from 'rsuite';
import { API, CONSTANTS } from '../../../../utils/constants';
import VehlCopy from './VehlCopy';
import { useQuery,useMutation} from 'react-query';
import { getData,postData } from '../../../../utils/async';
import { escapeCharChange} from '../../../../utils/commUtils';
import { confirmAlert } from 'react-confirm-alert'; // Import
import ConfirmAlert from '../../../Common/ConfirmAlert';
import CustomModal from '../../../Common/CustomModal';
const { StringType} = Schema.Types;

const model = Schema.Model({
    qltyVehlCd: StringType().isRequired('차종코드를 선택해 주세요.'),
    mdlMdyCd: StringType().isRequired('연식을 선택해 주세요.'),
    
    useYn: StringType().isRequired('사용유무를 선택해 주세요.')
});
const VehlLangAddAll = ({show, onHide}) => {

    const langGrid = useRef();
    const containerRef = React.useRef();
    
    const formRef = React.useRef();
    const [copyQltyVehlCd, setCopyQltyVehlCd] = useState();
    const [formError, setFormError] = React.useState({});
    const [formValue, setFormValue] = React.useState({
        qltyVehlCd: '',             // 차종코드
        mdlMdyCd:'',
        aaCode : '',
        useYn:'',                   // 사용유무
        sortSn : '',

        multiGbn : 'MULTI',
        langList : [],
        
        
    });  
    
 
    const onChangeVehlCombo= (val)=>{
        setCopyQltyVehlCd(val)
    }
 
    const langCopyEvent = (copyData) => {//언어복사
        
        if(copyData){

            copyData.map(item=>
                (langGrid.current.api.forEachNode((node,index)=>{
                    
                        if(node.data.langCd ==item.langCd){

                        node.setSelected(true)
                        }

                }
                    
                
                )) )
          
           
            
        }

            // const copyLangList = copyData;
            // 국가코드목록에 언어코드목록 넣기
           
            // setNatlList(natlCd.data);
            
            // // 언어코드목록
            // setLangList(langCd.data);
            // setFilteredLangList(langCd.data); 
        
    }


   const vehlCombo = useQuery([API.vehlCombo, {}], () => getData(API.vehlCombo, {}), {
        select: data => [{label: CONSTANTS.labelAll, value: CONSTANTS.valueAll}]
            .concat(data.map((item) => ({ label: escapeCharChange(item.qltyVehlNm), value: item.qltyVehlCd })))
    }); 
    const mdyCombo = useQuery([API.mdyCombo], () => getData(API.mdyCombo), {
        select: data => data.map((item) => ({ label: item, value: item }))
    });

   // 언어코드 리스트
   const langGridList = useQuery([API.langMsts,{}], () => getData(API.langMsts, {}), {
    select: data => { 
        return data.map(item => ({
            
            langCd: item.langCd, 
            langCdNm: item.langCdNm
            
        })); 
    },
});
const [langList, setLangList] = useState();
useEffect(()=>{
    if(langGridList.data){
        setLangList(langGridList.data);
    }
})
    const columnDefs = [
        {
          checkboxSelection: true,
          headerCheckboxSelection: true,
          width:45,
          maxWidth:45,
          minWidth:45,
          sortable:false
        },
        {
          headerName: '언어',
          children: [
            { 
                headerName:'언어코드', 
                field: 'langCd',
                filter: 'agTextColumnFilter',
                floatingFilter: true,
                suppressMenu: true,
                filterParams: {
                    filterOptions: ['contains'],
                },
                maxWidth:'150'
             },
            { 
                headerName:'언어명', 
                field: 'langCdNm',
                filter: 'agTextColumnFilter',
                floatingFilter: true,
                suppressMenu: true,
                filterParams: {
                    filterOptions: ['contains'],
                },
            },
          ],
        },
        
    ]

    const defaultColDef = useMemo(() => {
        return {
            initialWidth: 90,
            sortable: true,
            resizable:true,
        };
    }, []);

    const onFirstDataRendered = (params) => {
        params.api.sizeColumnsToFit();
    };
    
    // 저장버튼 클릭
    const handleSubmit = () => {
        if (!formRef.current.check()) { //validation chk
            return;
        }
        const langRows = langGrid.current.api.getSelectedRows();
        if(langRows.length === 0 ){
            confirmAlert({
                closeOnClickOutside: false,
                customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}  title={"알림"} msg={"적용언어를 선택해주세요"}  />
            });
            
        }else{
            formValue.langList = langRows;
            confirmAlert({
                closeOnClickOutside: false,
                customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}   title={"알림"}
                msg={"입력하신 내용으로 저장하시겠습니까?"} 
                
                onOk={onOk}  />
                
            });
           
            
        }
    };
    const vehlLangSave = useMutation((params => postData(API.langMgmt, params, CONSTANTS.insert)),{
        onSuccess: res => {
           if(res>0){
                confirmAlert({
                    closeOnClickOutside: false,
                    customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}   title={"알림"}
                    msg={"저장이 완료되었습니다."}   />
                    
                });
           }else{
            confirmAlert({
                closeOnClickOutside: false,
                customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}   title={"알림"}
                msg={"에러가 발생했습니다 관리자에게 문의해주세요."}   />
                
            });
           }
           onHide();
        }
    });


    const onOk = () => {
       
        vehlLangSave.mutate(formValue);
    }

    const [vehlCopyPop, setVehlCopyPop] = useState(false);

    return (
        <>
             <Form
                ref={formRef}
                checkTrigger="change"
                onChange={setFormValue}
                onCheck={setFormError}
                formValue={formValue}
                model={model}>
                 <CustomModal open={show} 
                        title={'차종별 언어등록(일괄)'}
                        size='lg'
                        // handleOk={handleSubmit}
                        handleCancel={onHide} 
                        
                        >
                            <Table className="tbl-hor" bordered>
                                <colgroup>
                                    <col style={{width:'20%'}}></col>
                                    <col style={{width:''}}></col>
                                    <col style={{width:'20%'}}></col>
                                    <col style={{width:''}}></col>
                                </colgroup>
                                <tbody>
                                    <tr>
                                        <th className="essen">차종코드</th>
                                        <td>
                                            <Row className="select-wrap">
                                            <Col sm={8}>
                                                
                                                <Form.Control container={()=> containerRef.current}  name="qltyVehlCd" size="sm" style={{zIndex: 0}} 
                                                           placeholder={'선택'}
                                                           defaultValue={''}
                                                           accepter={SelectPicker} 
                                                           searchable={false}
                                                           cleanable={false}
                                                            data={vehlCombo && vehlCombo.data ? vehlCombo.data : []}  
                                                            onChange={onChangeVehlCombo}
                                                    ></Form.Control>
                                                </Col>
                                                <Col sm={4}>
                                               
                                                    <Form.Control container={()=> containerRef.current}  name="mdlMdyCd" size="sm" style={{zIndex: 0}} 
                                                           placeholder={'선택'}
                                                           defaultValue={''}
                                                           accepter={SelectPicker} 
                                                           searchable={false}
                                                           cleanable={false}
                                                            data={mdyCombo && mdyCombo.data ? mdyCombo.data : []}  
                                                    ></Form.Control>
                                                </Col>
                                            </Row>
                                        </td>
                                        <th className="">A코드</th>
                                        <td>
                                            <Form.Control size="sm" type="text" name='aaCode'/> 
                                        </td>
                                    </tr>
                                    <tr>
                                        <th className="">정렬순서</th>
                                        <td>
                                            <Form.Control size="sm" type="text" name='sortSn'/> 
                                        </td>
                                        <th className="">사용여부</th>
                                        <td>
                                                <Form.Control name="useYn" size="sm"   
                                                    container={()=> containerRef.current}
                                                    placeholder={'선택'}
                                                    defaultValue={''}
                                                    accepter={SelectPicker} 
                                                    searchable={false}
                                                    cleanable={false}
                                                    data={[
                                                        {label: '사용', value: 'Y'},
                                                        {label: '미사용', value: 'N'},
                                                    ]}
                                            ></Form.Control>
                                        </td>
                                    </tr>
                                    <tr>
                                        <th className="essen">적용언어</th>
                                        <td colSpan="3">
                                            <div className="grid-btn-wrap" style={{marginBottom:'5px'}}>
                                                <div className="right-align">
                                                    <Button variant="outline-secondary" size="sm" onClick={() => setVehlCopyPop(true)}>차종복사</Button>{' '}
                                                </div>
                                            </div>
                                            <div className="ag-theme-alpine" style={{height:300, minWidth:300}}>
                                                <AgGridReact
                                                    ref={langGrid} 
                                                    rowData={langGridList && langGridList.data}
                                                    columnDefs={columnDefs}
                                                    defaultColDef={defaultColDef}
                                                    rowSelection={'multiple'}
                                                    suppressRowClickSelection= {true} 
                                                    onFirstDataRendered={onFirstDataRendered}
                                                    suppressSizeToFit={true}    
                                                    onGridSizeChanged={onFirstDataRendered}     
                                                    
                                                    >
                                                </AgGridReact>
                                            </div>
                                        </td>
                                    </tr>
                                </tbody>
                            </Table>
                            <div className='modal-footer'>
                                <Button variant="light" size="md" onClick={onHide}>취소</Button>
                                <Button variant="primary" size="md"  onClick={handleSubmit} >저장</Button>
                            </div>
                       </CustomModal>
            </Form>

            {vehlCopyPop && <VehlCopy show={vehlCopyPop} onHide={() => setVehlCopyPop(false)} data={copyQltyVehlCd} langCopyEvent={langCopyEvent} />}
        </>
    );

};
export default VehlLangAddAll;