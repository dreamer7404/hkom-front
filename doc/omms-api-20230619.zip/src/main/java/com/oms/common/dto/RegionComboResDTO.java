package com.oms.common.dto;

import org.apache.ibatis.type.Alias;

import lombok.Data;

/**
 * <pre>
 * 지역코드 콤보용
 * </pre>
 *
 * @author 안경수
 * @since 2023. 3. 24.
 * @see
 */
@Data
@Alias("regionComboResDTO")
public class RegionComboResDTO {
    private String dlExpdRegnCd;
    private String dlExpdRegnNm;
}
