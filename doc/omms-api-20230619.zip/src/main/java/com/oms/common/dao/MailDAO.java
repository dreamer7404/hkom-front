package com.oms.common.dao;

import java.util.List;

import com.oms.common.dto.CommReqDTO;
import com.oms.common.dto.MailDTO;
import com.oms.common.model.Mail;
import com.oms.common.model.YongsanIv;
import com.oms.common.model.YongsanVehl;
import com.oms.stm.dto.LangMgmtResDTO;
import com.oms.stm.dto.VehlMgmtResDTO;
import com.oms.sys.dto.UsrMgmtReqDTO;
import com.oms.sys.dto.UsrMgmtResDTO;


/**
 * <pre>
 * Statements
 * </pre>
 * @ClassName : MailDAO.java
 * @Description :
 * @author 안경수
 * @since 2023. 5. 26.
 * @see
 */
public interface MailDAO {

    int insertLogEml(MailDTO mailDTO);
    List<Mail> selectEmlAdrList(List<String> list);

}
