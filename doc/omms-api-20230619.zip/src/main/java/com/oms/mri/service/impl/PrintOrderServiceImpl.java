package com.oms.mri.service.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import able.cloud.core.service.HService;

import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.oms.mri.dao.PrintOrderDAO;
import com.oms.mri.dto.ClcmInfosResDTO;
import com.oms.mri.dto.PrintOrderComDTO;
import com.oms.mri.dto.PrintOrderInfoReqDTO;
import com.oms.mri.dto.PrintOrderInfosResDTO;
import com.oms.mri.dto.PrintOrderPageInfosResDTO;
import com.oms.mri.dto.PrintOrderPageReqDTO;
import com.oms.mri.dto.PrintOrderPrntPbcnNoResDTO;
import com.oms.mri.dto.PrintOrderReqInfoResDTO;
import com.oms.mri.service.PrintOrderService;

import lombok.RequiredArgsConstructor;


/**
 * <pre>
 * PrintOrderServiceImpl
 * </pre>
 * @ClassName : PrintOrderServiceImpl.java
 * @Description : 제작준비 > O/M발주 서비스
 * @author 김정웅
 * @since 2023. 5. 11.
 * @see
 */
@RequiredArgsConstructor
@Service("PrintOrderService")
public class PrintOrderServiceImpl extends HService implements PrintOrderService {

    private final PrintOrderDAO printOrderDao;

    @Override
    public List<PrintOrderInfosResDTO> selectPrintOrderList(PrintOrderComDTO reqDto) {
        List<PrintOrderInfosResDTO> result = new ArrayList<PrintOrderInfosResDTO>();
        result = printOrderDao.selectPrintOrderList(reqDto);
        return result;
    }

    @Override
    public List<ClcmInfosResDTO> selectPrintOrderClcmInfos(PrintOrderComDTO reqDto) {
        List<ClcmInfosResDTO> result = new ArrayList<ClcmInfosResDTO>();
        result = printOrderDao.selectPrintOrderClcmInfos(reqDto);
        return result;
    }

    @Override
    public List<PrintOrderPrntPbcnNoResDTO> selectPrintOrderPrntPbcnNoInfos(PrintOrderComDTO reqDto) {
        List<PrintOrderPrntPbcnNoResDTO> result = new ArrayList<PrintOrderPrntPbcnNoResDTO>();
        result = printOrderDao.selectPrintOrderPrntPbcnNoInfos(reqDto);
        return result;
    }

    @Override
    public PrintOrderReqInfoResDTO selectPrintOrderReqInfo(PrintOrderComDTO reqDto) {
        PrintOrderReqInfoResDTO result = new PrintOrderReqInfoResDTO();
        result = printOrderDao.selectPrintOrderReqInfo(reqDto);
        return result;
    }

    @Override
    public List<HashMap<String, String>> selectNPrntPbcnNoLrnkCdList(PrintOrderComDTO reqDto) {
        List<HashMap<String, String>> result = new ArrayList<HashMap<String,String>>();
        result = printOrderDao.selectNPrntPbcnNoLrnkCdList(reqDto);
        return result;
    }


    @Override
    public PrintOrderPageInfosResDTO selectPrintOrderPageInfo(PrintOrderComDTO reqDto) {
        int pageCount = 0;
        int algnCount = 0;
        int count = 0; // 수정페이지 수
        int maxDeppc1Sn = 0; // 목차일련번호 최대값
        String newPrntPbcnNo = "";
        PrintOrderPageInfosResDTO result = new PrintOrderPageInfosResDTO();
        List<Object> pageResult = new ArrayList<Object>();




        ///////////////////

        /** 발간번호에 맞는 인쇄배열표 체크된 수정페이지 카운트 조회 */
        HashMap<String, String> tmpCount = printOrderDao.getMdfyPageCount(reqDto);
        count = Integer.parseInt(String.valueOf(tmpCount.get("PAGE_COUNT")));

        /** 목차일련번호 최대값 조회 */
        HashMap<String, String> tmpCount2 = printOrderDao.selectMaxDeppc1Sn(reqDto);
        maxDeppc1Sn = Integer.parseInt(String.valueOf(tmpCount2.get("MAX_DEPPC1_SN")));

        List<HashMap<String, String>> pageInfoList = printOrderDao.selectPageInfoList(reqDto);

        List<HashMap<String, String>> algnInfoList = printOrderDao.selectAlgnInfoList(reqDto);

        pageCount = pageInfoList.size();
        algnCount = algnInfoList.size();

        if (pageCount == 0) {
           return null;
        }
        /** 제작의뢰 내역조회(인쇄방법코드, 특이사항 조회) */
        result = printOrderDao.selectPrntApvlInfo(reqDto).orElse(new PrintOrderPageInfosResDTO()) ;

//        mv.addObject("prntApvlInfo", prntApvlInfo);
//        if (prntApvlInfo != null) {
//            mv.addObject("prntWayCd", prntApvlInfo.get("prntWayCd")); // 표지인쇄방법코드
//            mv.addObject("prntWayCd2", prntApvlInfo.get("prntWayCd2")); // 내지인쇄방법코드
//            mv.addObject("prtlImtrSbc", prntApvlInfo.get("prtlImtrSbc")); // 특이사항
//            mv.addObject("prntParrQty", prntApvlInfo.get("prntParrQty")); // 인쇄부수
//        }

        int mdfyCount1 = 0; // 수정된 페이지 수
        int deppc1Sn = 0; // 취급설명서 인쇄페이지 목차 일련번호
        int deppc2Sn = 0; // 취급설명서 인쇄페이지 목차 일련번호2
        int endPgSn = 0; // 끝페이지 일련번호
        int deppc1Sn2 = 0; // 취급설명서 인쇄페이지 목차 일련번호
        int deppc2Sn2 = 0; // 취급설명서 인쇄페이지 목차 일련번호2
        int dlExpdPrntPgSn = 0; // 취급설명서 인쇄페이지 일련번호

        int finalCount = 0; // 인쇄관리페이지에 저장된 총 페이지 수
        int sortCount = 0; // 마지막페이지 홀,짝 판별 카운트
        double n = 7; // 실제로 생성될 테이블 갯수(1~64행 생성)

        double nCount = 0; //

        String tmpText = "";
        String currentText = "";
        String currentText2 = "";

        if (pageCount > 0) { // 인쇄페이지 관리에 저장된 값
            for (int i = 0; i < pageInfoList.size(); i++) {
                // HMap iMap = pageInfoList.get(i);
                newPrntPbcnNo = (String) pageInfoList.get(i).get("N_PRNT_PBCN_NO").toString().replace("&#40;", "(").replace("&#41;", ")");;
                finalCount += Integer.parseInt(String.valueOf(pageInfoList.get(i).get("END_PG_SN")));
                if (Integer.parseInt(String.valueOf(pageInfoList.get(i).get("END_PG_SN"))) % 2 == 1) {
                    sortCount++;
                }
            }
            finalCount += sortCount;
        }

        if (Math.ceil(finalCount / 64.0) > n) {
            n = Math.ceil(finalCount / 64.0);
        }

        List<HashMap<String, Object>> allTest = new ArrayList<HashMap<String, Object>>(); /////////////@@@@@@@@@
        List<HashMap<String, Object>> resultAllTest = new ArrayList<HashMap<String, Object>>(); /////////////@@@@@@@@@

        int groupNo = 1; /////////////@@@@@@@@@
        int pageNo = 1;/////////////@@@@@@@@@
        if (pageCount > 0) { // 인쇄페이지 관리에 저장된 값
            for (int i = 0; i < pageInfoList.size(); i++) {
                deppc1Sn = Integer.parseInt(String.valueOf(pageInfoList.get(i).get("DEPPC1_SN")));
                deppc2Sn = Integer.parseInt(String.valueOf(pageInfoList.get(i).get("DEPPC2_SN")));
                endPgSn = Integer.parseInt(String.valueOf(pageInfoList.get(i).get("END_PG_SN")));
                nCount = 64 * n - finalCount;
                for (int j = 0; j < endPgSn; j++) {
                    HashMap<String, Object> rowTest = new HashMap<String, Object>(); /////////////@@@@@@@@@
                    if (deppc1Sn == maxDeppc1Sn - 1) {
                        //색인 세팅
                        currentText += "I" + "-" + (j + 1) + ",";
                        rowTest.put("page", pageNo);
                        rowTest.put("pageContent", "I" + "-" + (j + 1));
                        rowTest.put("deppc1Sn", deppc1Sn);
                        rowTest.put("deppc2Sn", deppc2Sn);

                        pageNo++;
                    } else {
                        if (deppc1Sn == 0){
                            if(deppc2Sn == 1){
                                currentText += "S1" + "-" + (j + 1) + ",";

                                rowTest.put("page", pageNo);
                                rowTest.put("pageContent", "S1" + "-" + (j + 1));
                                rowTest.put("deppc1Sn", deppc1Sn);
                                rowTest.put("deppc2Sn", deppc2Sn);
                                pageNo++;
                            }else if (deppc2Sn == 2){
                                currentText += "S2" + "-" + (j + 1) + ",";

                                rowTest.put("page", pageNo);
                                rowTest.put("pageContent", "S2" + "-" + (j + 1));
                                rowTest.put("deppc1Sn", deppc1Sn);
                                rowTest.put("deppc2Sn", deppc2Sn);
                                pageNo++;
                            }else{
                                currentText += "S3" + "-" + (j + 1) + ",";

                                rowTest.put("page", pageNo);
                                rowTest.put("pageContent", "S3" + "-" + (j + 1));
                                rowTest.put("deppc1Sn", deppc1Sn);
                                rowTest.put("deppc2Sn", deppc2Sn);
                                pageNo++;
                            }
                        }else{
                            currentText += deppc1Sn + "-" + (j + 1) + ",";

                            rowTest.put("page", pageNo);
                            rowTest.put("pageContent", deppc1Sn + "-" + (j + 1));
                            rowTest.put("deppc1Sn", deppc1Sn);
                            rowTest.put("deppc2Sn", deppc2Sn);
                            pageNo++;
                        }
                    }
                    allTest.add(rowTest);
                }
                if (endPgSn % 2 == 1) {
                    HashMap<String, Object> rowTest = new HashMap<String, Object>(); /////////////@@@@@@@@@

                    currentText += " " + ",";

                    rowTest.put("page", pageNo);
                    rowTest.put("pageContent", "");
                    pageNo++;
                    allTest.add(rowTest);
                }
            }
            for (int k = 0; k < nCount; k++) {
                currentText += " " + ",";

                HashMap<String, Object> rowTest = new HashMap<String, Object>(); /////////////@@@@@@@@@
                rowTest.put("page", pageNo);
                rowTest.put("pageContent", "");
                rowTest.put("deppc1Sn", deppc1Sn);
                rowTest.put("deppc2Sn", deppc2Sn);
                pageNo++;
                allTest.add(rowTest);
            }
        }
        // log.debug("currentText" + ">>>" + currentText);
         String arr[] = currentText.split(",");
        if (algnCount > 0) { // 인쇄배열 정보에 저장된 값
            List<String> tmpAlgnSaveList = new ArrayList<String>();
            mdfyCount1 = algnCount;
            for (int y = 0; y < algnCount; y++) {
                deppc1Sn2 = Integer.parseInt(String.valueOf(algnInfoList.get(y).get("DEPPC1_SN")));
                deppc2Sn2 = Integer.parseInt(String.valueOf(algnInfoList.get(y).get("DEPPC2_SN")));
                dlExpdPrntPgSn = Integer.parseInt(String.valueOf(algnInfoList.get(y).get("DL_EXPD_PRNT_PG_SN")));
                if (deppc1Sn2 == maxDeppc1Sn - 1) {
                    // tmpText += "I" + "-" + dlExpdPrntPgSn + "&,";
                    tmpAlgnSaveList.add("I" + "-" + dlExpdPrntPgSn);
                } else {
                    if (deppc1Sn2 == 0){
                        if(deppc2Sn2 == 1){
                            tmpAlgnSaveList.add("S1" + "-" + dlExpdPrntPgSn);
                        }else if (deppc2Sn2 == 2){
                            tmpAlgnSaveList.add("S2" + "-" + dlExpdPrntPgSn);
                        }else{
                            tmpAlgnSaveList.add("S3" + "-" + dlExpdPrntPgSn);
                        }
                    }else{
                        tmpAlgnSaveList.add(deppc1Sn2 + "-" + dlExpdPrntPgSn);
                    }
                }
            }
            for (int z = 0; z < arr.length; z++) {
                if (tmpAlgnSaveList.contains(arr[z])) {
                    currentText2 += arr[z] + ",";
                } else {
                    currentText2 += " " + ",";
                }
                /*
                 * if(tmpText.lastIndexOf(arr[z] + "&") > -1){
                 * currentText2 += arr[z] + ",";
                 * }else{
                 * currentText2 += " " + ",";
                 * }
                 */
            }

            //////////////@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@

//            int colGroupIndex = 1;
            int rowGroupIndex = 1;
            int index = 1;
            String[] currentText2Arr = currentText2.split(",");
            for(HashMap<String, Object> row : allTest) {
//                for(String checkedRow : tmpAlgnSaveList) {
                    if(currentText2Arr[index-1].equals(row.get("pageContent"))) {
                        if((double) (index+7) % 8 == 0) {
                            row.put("groupIndex", rowGroupIndex);
                        }
                        row.put("checked", "Y");
                        row.put("dlExpdPrntPgSn", currentText2Arr[index-1]);

                        resultAllTest.add(row);
                    } else {
                        if((double) (index+7) % 8 == 0) {
                            row.put("groupIndex", rowGroupIndex);
                        }
                        row.put("checked", "N");
                        row.put("dlExpdPrntPgSn", currentText2Arr[index-1]);
                        resultAllTest.add(row);
                    }
                    if((double) index % 8 == 0) {
                        rowGroupIndex++;
                    }
                    if((double) index % 64 == 0) {
                        pageResult.add(resultAllTest);
                        resultAllTest = new ArrayList<HashMap<String, Object>>();
                    }
                    index++;
//                }
            }

        } else {
            for (int y = 0; y < arr.length; y++) {
                currentText2 += " " + ",";
            }

            int rowGroupIndex = 1;
            int index = 1;
            for(HashMap<String, Object> row : allTest) {
                if((double) (index+7) % 8 == 0) {
                    row.put("groupIndex", rowGroupIndex);
                }
                row.put("checked", "N");
                resultAllTest.add(row);

                if((double) index % 8 == 0) {
                    rowGroupIndex++;
                }
                if((double) index % 64 == 0) {
                    pageResult.add(resultAllTest);
                    resultAllTest = new ArrayList<HashMap<String, Object>>();
                }
                index++;
            }
        }

        ////////////////////
        result.setFinalCount(finalCount); //인쇄배열표 총  row수
        result.setModifyCount(algnCount); //인쇄배열표 교체 체크건수
        result.setPageList(pageResult);
        return result;
    }

    @Transactional
    @Override
    public Integer insertPrintOrderPageInfo(PrintOrderPageReqDTO reqDto) {

        int result = 0;

        PrintOrderComDTO newReqDto = new PrintOrderComDTO();
        BeanUtils.copyProperties(reqDto, newReqDto);

        List<String> checkedValues = reqDto.getCheckedValues();
        List<HashMap<String, String>> convertedCheckedValues = new ArrayList<HashMap<String, String>>();

        int maxDeppc1Sn = 0; // 목차일련번호 최대값

        printOrderDao.deletePrntAlgn(reqDto);


        /** 목차일련번호 최대값 조회 */
        HashMap<String, String> tmpCount2 = printOrderDao.selectMaxDeppc1Sn(newReqDto);
        maxDeppc1Sn = Integer.parseInt(String.valueOf(tmpCount2.get("MAX_DEPPC1_SN")));

        List<HashMap<String, Object>> checkedValuesTmp = new ArrayList<HashMap<String, Object>>();

        for (String checkedValue: checkedValues) {
            //DTO를 HashMap으로 변환하여 파라미터 할당..
            ObjectMapper objectMapper = new ObjectMapper();
            HashMap<String, Object> checkedValueTmp = objectMapper.convertValue(reqDto, HashMap.class);

            if (checkedValue.split("-")[0].equals("I")) {
                checkedValueTmp.put("deppc1Sn", maxDeppc1Sn - 1);
                checkedValueTmp.put("deppc2Sn", 1);
                checkedValueTmp.put("prntInsdPgSbc",((maxDeppc1Sn - 1)+ "-" + checkedValue.split("-")[1]).toString());
            }else if(checkedValue.split("-")[0].equals("S1")){
                checkedValueTmp.put("deppc1Sn", 0);
                checkedValueTmp.put("deppc2Sn", 1);
                checkedValueTmp.put("prntInsdPgSbc", "0-1-" + checkedValue.split("-")[1]);
            }else if(checkedValue.split("-")[0].equals("S2")){
                checkedValueTmp.put("deppc1Sn", 0);
                checkedValueTmp.put("deppc2Sn", 2);
                checkedValueTmp.put("prntInsdPgSbc", "0-2-" + checkedValue.split("-")[1]);
            }else if(checkedValue.split("-")[0].equals("S3")){
                checkedValueTmp.put("deppc1Sn", 0);
                checkedValueTmp.put("deppc2Sn", 3);
                checkedValueTmp.put("prntInsdPgSbc", "0-3-" + checkedValue.split("-")[1]);
            } else {
                checkedValueTmp.put("deppc1Sn", Integer.parseInt(checkedValue.split("-")[0]));
                checkedValueTmp.put("deppc2Sn", 1);
                checkedValueTmp.put("prntInsdPgSbc", checkedValue);
            }
            checkedValueTmp.put("dlExpdPrntPgSn", Integer.parseInt(checkedValue.split("-")[1]));
            checkedValueTmp.put("deppr1Yn", "Y");
            checkedValueTmp.put("rgnEeno", reqDto.getUserEeno());
            checkedValueTmp.put("updrEeno", reqDto.getUserEeno());

            checkedValuesTmp.add(checkedValueTmp);
        }
        if(checkedValuesTmp.size() > 0) {
            result = printOrderDao.insertPrntAlgn(checkedValuesTmp);
        } else {
            result = 1;
        }

        return result;
    }

    @Transactional
    @Override
    public Integer insertPrintOrderInfo(PrintOrderInfoReqDTO reqDto) {
        String state = reqDto.getState(); //S: 임시저장, Q:O/M발주
        String iWayCd = reqDto.getIwayCd();
        int result = 0;

        //신규 발간번호 중복체크
        String dupChk = printOrderDao.selectPrntPbcnNoDupChk(reqDto);
        //DTO를 HashMap으로 변환
        ObjectMapper objectMapper = new ObjectMapper();

        if("Y".equals(dupChk)){

            result = printOrderDao.insertPrntReqInfo2(reqDto); //발간물제작의뢰정보 저장

            //그룹코드:0009  01:발주 전, 02:발주완료, 03:발주취소, 04:재발주, 05:저장

            if("S".equals(state)){
                reqDto.setDlExpdRdcsStCd("05"); // 임시저장 클릭시 -> 저장
            } else if("Q".equals(state)){
                reqDto.setDlExpdRdcsStCd("02"); // O/M발주 클릭시 -> 발주완료
            }

            result = printOrderDao.insertPrntBkgdInfo2(reqDto); //발간물이력정보 저장

            //발주시 세원재고 추가 작업 Start
            // (04:스티커, 05:리플렛, 06:퀵가이드) 가 아닌 경우에만 세원제고 업데이트
            if("Q".equals(state) && !"04".equals(iWayCd)  && !"05".equals(iWayCd) && !"06".equals(iWayCd)){
                printOrderDao.spSewonWhsnInfoSave(reqDto);  // 세원재고 업데이트 --> 이게 인쇄중 데이터..
            }
            //발주시 세원재고 추가 작업 End

            /** 현재 입력된 신발간번호로 저장된 체크리스트 수정*/
            printOrderDao.deleteChklistDtlInfo(reqDto);

            /** 체크리스트 저장 */
            reqDto.getCheckedRows().forEach(item -> {
                HashMap<String, Object> reqDtoTmp = objectMapper.convertValue(reqDto, HashMap.class);
                //법규 등록번호 세팅
                reqDtoTmp.put("dlExpdAltrNo", item.getDlExpdAltrNo());
                printOrderDao.updateChklistDtlInfo(reqDtoTmp);
            });

        } else {
            return 99;
        }

        return result;
    }




}





