package com.oms.mri.dto;

import java.util.Set;

import org.apache.ibatis.type.Alias;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * <pre>
 * PrintOrderComDTO
 * </pre>
 *
 * @author 김정웅
 * @since 2023. 5. 11.
 * @see
 */
@Alias("printOrderComDTO")
@Data
@AllArgsConstructor
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown =true)
public class PrintOrderComDTO {

    private String userEeno;        //사용자 ID
    private String crgrEeno;        //담당자 ID (검색용)
    private String dlExpdCoCd;      //사용자 회사코드
    private String vehlCd;          //차종코드
    private String qltyVehlCd;      //차종코드
    private String qltyVehlNm;      //차종코드명
    private String vehlCds;         //차종코드(다중 선택)
    private String ssDate;           //검색조건 시작일
    private String eeDate;           //검색조건 종료일
    private String bbDate;           //검색조건 기준일

    private String sDate;           //검색조건 시작
    private String eDate;           //검색조건 종료일
    private String bDate;           //검색조건 기준일

    private String dlExpdPrvsNm;    //언어지역명
    private String language;        //언어코드 ex) EU(영어/미국) 등..
    private String langCd;          //언어코드 ex) EU(영어/미국) 등..
    private String langCdNm;        //언어코드명
    private Set<String> langCds;    //언어코드 다중 선택
    private String mdlMdyCd;        //연식
    private String dlExpdMdlMdyCd;  //연식
    private String dlExpdPdiCd;     //공장코드 ex) 아산, 광주2 등..
    private String dlExpdRegnCd;    //지역코드 ex) 유럽, 북미 등..
    private String dataSn;          //dataSn
    private String newPrntPbcnNo;   //신발간번호
    private String lrnkCd;          //발간번호별 인쇄배열표 시퀀스
    private String oldPrntPbcnNo;   //구발간번호
    private String dlExpdRdcsStCd;  //취급설명서결재상태코드
    private String iWayCd;          //발행구분
    private String iiWayCd;          //발행구분


}
