package com.oms.sys.dto;

import java.util.List;

import org.apache.ibatis.type.Alias;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @author 안경수
 * @since 2023. 4. 24.
 * @see
 */
@Alias("usrGrpMgmtReqDTO")
@Data
@NoArgsConstructor
//@AllArgsConstructor
public class UsrGrpMgmtReqDTO {
    private String grpCd;
    private String grpNm;
    private Integer sortSn;
    private String rem;
    private String useYn;
    private String pprrEeno;
    private String updrEeno;
}
