package com.oms.sys.dto;

import java.sql.Timestamp;

import org.apache.ibatis.type.Alias;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName : EmailResDTO.java
 * @Description :
 * @author 김경훈
 * @since 2023. 6. 15.
 * @see
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Alias("emailLogResDTO")
public class EmailLogResDTO {

    private String emlCd;
    private String emlScdCd;
    private String emlId;
    private String sndrId;
    private String emlTitl;
    private String emlSbc;
    private String fsSndDate;
    private String emlNm;
    private String sndrNm;

}
