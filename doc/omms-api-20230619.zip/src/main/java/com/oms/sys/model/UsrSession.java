package com.oms.sys.model;

import java.sql.Timestamp;

import org.apache.ibatis.type.Alias;

import lombok.Data;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @author Windows ≫c¿eAU
 * @since 2023. 2. 24.
 * @see
 */
@Data
public class UsrSession {
    private String userEeno;        // 사용자번호
    private String remoteIp;        // 접속IP
    private Long accessDtm;         // 접속일시
    private String accessToken;     // access 토큰
    private String refreshToken;    // refresh 토큰
    private Timestamp mdfyDtm;      // 수정일시
}
