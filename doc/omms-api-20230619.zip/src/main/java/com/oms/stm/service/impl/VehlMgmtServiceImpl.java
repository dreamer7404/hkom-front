package com.oms.stm.service.impl;
import java.util.HashMap;
import java.util.List;

import able.cloud.core.service.HService;

import org.springframework.stereotype.Service;

import com.oms.stm.dao.VehlMgmtDAO;
import com.oms.stm.dto.StmComReqDTO;
import com.oms.stm.dto.VehlCrgrMgmtSaveDTO;
import com.oms.stm.dto.VehlMdyMgmtReqDTO;
import com.oms.stm.dto.VehlMdyMgmtResDTO;
import com.oms.stm.dto.VehlMgmtCrgDTO;
import com.oms.stm.dto.VehlMgmtReqDTO;
import com.oms.stm.dto.VehlMgmtResDTO;
import com.oms.stm.dto.VehlMgmtSaveDTO;
import com.oms.stm.service.VehlMgmtService;

import lombok.RequiredArgsConstructor;


/**
 * <pre>
 * Statements
 * </pre>
 * @ClassName : VehlMgmtServiceImpl.java
 * @Description :
 * @author 김경훈
 * @since 2023. 3. 13.
 * @see
 */
@RequiredArgsConstructor
@Service("vehlMgmtService")
public class VehlMgmtServiceImpl extends HService implements VehlMgmtService {

    private final VehlMgmtDAO vehlMgmtDAO;


    /*
     * @see com.oms.stm.service.VehlMgmtService#selectCpyTgVehl(com.oms.stm.dto.VehlMgmtReqDTO)
     */
    @Override
    public List<VehlMgmtResDTO> selectCpyTgVehl(StmComReqDTO dto) {
        //
        return vehlMgmtDAO.selectCpyTgVehl(dto);
    }

    /*
     * @see com.oms.stm.service.VehlMgmtService#selectNatlVehlChk(com.oms.stm.dto.VehlMgmtReqDTO)
     */
    @Override
    public String selectNatlVehlChk(VehlMgmtReqDTO vehlReqDTO) {
        // TODO Auto-generated method stub
        return vehlMgmtDAO.selectNatlVehlChk(vehlReqDTO);
    }

    /*
     * @see com.oms.stm.service.VehlMgmtService#insertNatlVehlMgmt(com.oms.stm.dto.VehlMgmtReqDTO)
     */
    @Override
    public int insertNatlVehlMgmt(VehlMgmtSaveDTO vehlMgmtSaveDTO) {
        return vehlMgmtDAO.insertNatlVehlMgmt(vehlMgmtSaveDTO);
    }

    /*
     * @see com.oms.stm.service.VehlMgmtService#deleteVehlLangCp(com.oms.stm.dto.VehlMgmtReqDTO)
     */
    @Override
    public void deleteVehlLangCp(VehlMgmtReqDTO vehlReqDTO) {
        vehlMgmtDAO.deleteVehlLangCp(vehlReqDTO);
    }

    /*
     * @see com.oms.stm.service.VehlMgmtService#insertVehlLangCopy(com.oms.stm.dto.VehlMgmtReqDTO)
     */
    @Override
    public void insertVehlLangCopy(VehlMgmtReqDTO vehlReqDTO) {
        vehlMgmtDAO.insertVehlLangCopy(vehlReqDTO);

    }

    /*
     * @see com.oms.stm.service.VehlMgmtService#deleteVehlNatlLang(com.oms.stm.dto.VehlMgmtReqDTO)
     */
    @Override
    public void deleteVehlNatlLang(VehlMgmtReqDTO vehlReqDTO) {
        vehlMgmtDAO.deleteVehlNatlLang(vehlReqDTO);

    }

    /*
     * @see com.oms.stm.service.VehlMgmtService#insertVehlNatlLangCpy(com.oms.stm.dto.VehlMgmtReqDTO)
     */
    @Override
    public void insertVehlNatlLangCpy(VehlMgmtReqDTO vehlReqDTO) {
        vehlMgmtDAO.insertVehlNatlLangCpy(vehlReqDTO);

    }

    /*
     * @see com.oms.stm.service.VehlMgmtService#selectCpyTgNatlVehl(com.oms.stm.dto.VehlMgmtReqDTO)
     */
    @Override
    public List<VehlMgmtResDTO> selectCpyTgNatlVehl(VehlMgmtReqDTO dto) {
        return vehlMgmtDAO.selectCpyTgNatlVehl(dto);
    }

    /*
     * @see com.oms.stm.service.VehlMgmtService#selectVehlMgmtNatlLangList(com.oms.stm.dto.VehlMgmtReqDTO)
     */
    @Override
    public List<HashMap<String, Object>> selectVehlMgmtNatlLangList(StmComReqDTO dto) {
        // TODO Auto-generated method stub
        return vehlMgmtDAO.selectVehlMgmtNatlLangList(dto);
    }

    /*
     * @see com.oms.stm.service.VehlMgmtService#deleteVehlMgmtCrgr(com.oms.stm.dto.VehlMgmtReqDTO)
     */
    @Override
    public int deleteVehlMgmtCrgr(VehlMgmtReqDTO vehlReqDTO) {
        return vehlMgmtDAO.deleteVehlMgmtCrgr(vehlReqDTO);
    }

    /*
     * @see com.oms.stm.service.VehlMgmtService#insertVehlMgmtCrgr(com.oms.stm.dto.VehlMgmtReqDTO)
     */
    @Override
    public int insertVehlMgmtCrgr(List<VehlCrgrMgmtSaveDTO> list) {
        return vehlMgmtDAO.insertVehlMgmtCrgr(list);
    }

    /*
     * @see com.oms.stm.service.VehlMgmtService#deleteVehlMgmtRegnRelCd(com.oms.stm.dto.VehlMgmtReqDTO)
     */
    @Override
    public void deleteVehlMgmtRegnRelCd(VehlMgmtReqDTO vehlReqDTO) {

         vehlMgmtDAO.deleteVehlMgmtRegnRelCd(vehlReqDTO);
    }

    /*
     * @see com.oms.stm.service.VehlMgmtService#deleteVehlDlExpdMdyMgmt(com.oms.stm.dto.VehlMgmtReqDTO)
     */
    @Override
    public void deleteVehlDlExpdMdyMgmt(VehlMgmtReqDTO vehlReqDTO) {
        vehlMgmtDAO.deleteVehlDlExpdMdyMgmt(vehlReqDTO);

    }

    /*
     * @see com.oms.stm.service.VehlMgmtService#insertVehlMgmtRegnRelCd(com.oms.stm.dto.VehlMgmtReqDTO)
     */
    @Override
    public void insertVehlMgmtRegnRelCd(VehlMgmtReqDTO vehlReqDTO) {
        vehlMgmtDAO.insertVehlMgmtRegnRelCd(vehlReqDTO);

    }

    /*
     * @see com.oms.stm.service.VehlMgmtService#insertVehlDlExpdMdyMgmt(com.oms.stm.dto.VehlMgmtReqDTO)
     */
    @Override
    public void insertVehlDlExpdMdyMgmt(VehlMgmtReqDTO vehlReqDTO) {
        vehlMgmtDAO.insertVehlDlExpdMdyMgmt(vehlReqDTO);

    }

    /*
     * @see com.oms.stm.service.VehlMgmtService#deleteVehlMgmtAltn(com.oms.stm.dto.VehlMgmtReqDTO)
     */
    @Override
    public void deleteVehlMgmtAltn(VehlMgmtReqDTO vehlReqDTO) {
        vehlMgmtDAO.deleteVehlMgmtAltn(vehlReqDTO);

    }

    /*
     * @see com.oms.stm.service.VehlMgmtService#insertVehlMgmtAltn(com.oms.stm.dto.VehlMgmtReqDTO)
     */
    @Override
    public void insertVehlMgmtAltn(VehlMgmtReqDTO vehlReqDTO) {
        vehlMgmtDAO.insertVehlMgmtAltn(vehlReqDTO);

    }

    /*
     * @see com.oms.stm.service.VehlMgmtService#deleteNatlVehlLang(com.oms.stm.dto.VehlMgmtReqDTO)
     */
    @Override
    public void deleteNatlVehlLang(VehlMgmtReqDTO vehlReqDTO) {
        vehlMgmtDAO.deleteNatlVehlLang(vehlReqDTO);

    }

    /*
     * @see com.oms.stm.service.VehlMgmtService#insertNatlVehlLang(com.oms.stm.dto.VehlMgmtReqDTO)
     */
    @Override
    public int insertNatlVehlLang(VehlMgmtSaveDTO vehlMgmtSaveDTO) {
        return vehlMgmtDAO.insertNatlVehlLang(vehlMgmtSaveDTO);

    }

    /*
     * @see com.oms.stm.service.VehlMgmtService#updateVehlMgmtMain(com.oms.stm.dto.VehlMgmtReqDTO)
     */
    @Override
    public void updateVehlMgmtMain(VehlMgmtReqDTO vehlReqDTO) {
        vehlMgmtDAO.updateVehlMgmtMain(vehlReqDTO);

    }

    /*
     * @see com.oms.stm.service.VehlMgmtService#selectDlExpdMdyPreList(com.oms.stm.dto.VehlMgmtReqDTO)
     */
    @Override
    public List<VehlMgmtResDTO> selectDlExpdMdyPreList(VehlMgmtReqDTO dto) {
        // TODO Auto-generated method stub
        return vehlMgmtDAO.selectDlExpdMdyPreList(dto);
    }

    /*
     * @see com.oms.stm.service.VehlMgmtService#selectDlExpdMdyNextList(com.oms.stm.dto.VehlMgmtReqDTO)
     */
    @Override
    public List<VehlMgmtResDTO> selectDlExpdMdyNextList(VehlMgmtReqDTO dto) {
        // TODO Auto-generated method stub
        return vehlMgmtDAO.selectDlExpdMdyNextList(dto);
    }

    /*
     * @see com.oms.stm.service.VehlMgmtService#selectVehlLangList(com.oms.stm.dto.VehlMgmtReqDTO)
     */
    @Override
    public List<VehlMgmtResDTO> selectVehlLangList(VehlMgmtReqDTO dto) {
        // TODO Auto-generated method stub
        return vehlMgmtDAO.selectVehlLangList(dto);
    }

    /*
     * @see com.oms.stm.service.VehlMgmtService#deleteVehlLang(com.oms.stm.dto.VehlMgmtReqDTO)
     */
    @Override
    public void deleteVehlLang(VehlMgmtReqDTO vo) {
        vehlMgmtDAO.deleteVehlLang(vo);

    }

    /*
     * @see com.oms.stm.service.VehlMgmtService#insertVehlLangInfo(com.oms.stm.dto.VehlMgmtReqDTO)
     */
    @Override
    public void insertVehlLangInfo(VehlMgmtReqDTO vo) {
        vehlMgmtDAO.insertVehlLangInfo(vo);

    }

    /*
     * @see com.oms.stm.service.VehlMgmtService#selectVehlMgmtCnt(com.oms.stm.dto.VehlMgmtReqDTO)
     */
    @Override
    public String selectVehlMgmtCnt(VehlMgmtReqDTO vehlReqDTO) {
        // TODO Auto-generated method stub
        return vehlMgmtDAO.selectVehlMgmtCnt(vehlReqDTO);
    }

    /*
     * @see com.oms.stm.service.VehlMgmtService#insertVehlMgmtMain(com.oms.stm.dto.VehlMgmtReqDTO)
     */
    @Override
    public void insertVehlMgmtMain(VehlMgmtReqDTO vehlReqDTO) {
         vehlMgmtDAO.insertVehlMgmtMain(vehlReqDTO);

    }

    /*
     * @see com.oms.stm.service.VehlMgmtService#selectPreVehlMdyChk(com.oms.stm.dto.VehlMgmtReqDTO)
     */
    @Override
    public List<VehlMgmtResDTO> selectPreVehlMdyChk(VehlMgmtReqDTO vehlReqDTO) {
        // TODO Auto-generated method stub
        return vehlMgmtDAO.selectPreVehlMdyChk(vehlReqDTO);
    }

    /*
     * @see com.oms.stm.service.VehlMgmtService#selectMdyMonth(com.oms.stm.dto.VehlMgmtReqDTO)
     */
    @Override
    public List<VehlMgmtReqDTO> selectMdyMonth(StmComReqDTO reqDto) {
        // TODO Auto-generated method stub
        return vehlMgmtDAO.selectMdyMonth(reqDto);
    }

    /*
     * @see com.oms.stm.service.VehlMgmtService#getVehlCombo(com.oms.stm.dto.VehlMgmtReqDTO)
     */
    @Override
    public List<VehlMgmtResDTO> getVehlCombo(StmComReqDTO dto) {
        // TODO Auto-generated method stub
        return vehlMgmtDAO.getVehlCombo(dto);
    }

    /*
     * @see com.oms.stm.service.VehlMgmtService#getPdiCombo(com.oms.stm.dto.VehlMgmtReqDTO)
     */
    @Override
    public List<VehlMgmtResDTO> getPdiCombo(StmComReqDTO dto) {
        // TODO Auto-generated method stub
        return vehlMgmtDAO.getPdiCombo(dto);
    }

    /*
     * @see com.oms.stm.service.VehlMgmtService#selectDlExpdPacScnCdList(com.oms.stm.dto.StmComReqDTO)
     */
    @Override
    public List<VehlMgmtResDTO> selectDlExpdPacScnCdList(StmComReqDTO dto) {
        return vehlMgmtDAO.selectDlExpdPacScnCdList(dto);
    }

    /*
     * @see com.oms.stm.service.VehlMgmtService#selectVehlMgmtList(java.util.HashMap)
     */
    @Override
    public List<VehlMgmtResDTO> selectVehlMgmtList(HashMap<String, Object> map) {
        return vehlMgmtDAO.selectVehlMgmtList(map);
    }

    /*
     * @see com.oms.stm.service.VehlMgmtService#selectVehlMdyChk(com.oms.stm.dto.VehlMgmtReqDTO)
     */
    @Override
    public String selectVehlMdyChk(VehlMgmtReqDTO vehlReqDTO) {
        // TODO Auto-generated method stub
        return vehlMgmtDAO.selectVehlMdyChk(vehlReqDTO);
    }

    /*
     * @see com.oms.stm.service.VehlMgmtService#selectVehlMgmtInfo(java.util.HashMap)
     */
    @Override
    public VehlMgmtResDTO selectVehlMgmtInfo(HashMap<String, Object> map) {
        // TODO Auto-generated method stub
        return vehlMgmtDAO.selectVehlMgmtInfo(map);
    }

    /*
     * @see com.oms.stm.service.VehlMgmtService#selectVehlChrgList(java.util.HashMap)
     */
    @Override
    public List<VehlMgmtCrgDTO> selectVehlChrgList(HashMap<String, Object> map) {
        // TODO Auto-generated method stub
        return vehlMgmtDAO.selectVehlChrgList(map);
    }

    /*
     * @see com.oms.stm.service.VehlMgmtService#insertHmcVehlAuth(com.oms.stm.dto.VehlMgmtReqDTO)
     */
    @Override
    public int insertHmcVehlAuth(VehlMgmtCrgDTO vehlReqDTO) {
        // TODO Auto-generated method stub
        return vehlMgmtDAO.insertHmcVehlAuth(vehlReqDTO);
    }

    /*
     * @see com.oms.stm.service.VehlMgmtService#selectVehlMdyList(com.oms.stm.dto.VehlMdyMgmtReqDTO)
     */
    @Override
    public List<HashMap<String, Object>> selectVehlMdyList(HashMap<String, Object> hmap) {
        // TODO Auto-generated method stub
        return vehlMgmtDAO.selectVehlMdyList(hmap);
    }

    /*
     * @see com.oms.stm.service.VehlMgmtService#selectMdyChk1(com.oms.stm.dto.VehlMdyMgmtReqDTO)
     */
    @Override
    public VehlMdyMgmtResDTO selectMdyChk1(VehlMdyMgmtReqDTO dto) {
        // TODO Auto-generated method stub
        return vehlMgmtDAO.selectMdyChk1(dto);
    }

    /*
     * @see com.oms.stm.service.VehlMgmtService#selectMdyChk2(com.oms.stm.dto.VehlMdyMgmtReqDTO)
     */
    @Override
    public VehlMdyMgmtResDTO selectMdyChk2(VehlMdyMgmtReqDTO dto) {
        // TODO Auto-generated method stub
        return vehlMgmtDAO.selectMdyChk2(dto);
    }

    /*
     * @see com.oms.stm.service.VehlMgmtService#selectMdyChk3(com.oms.stm.dto.VehlMdyMgmtReqDTO)
     */
    @Override
    public String selectMdyChk3(VehlMdyMgmtReqDTO dto) {
        // TODO Auto-generated method stub
        return vehlMgmtDAO.selectMdyChk3(dto);
    }

    /*
     * @see com.oms.stm.service.VehlMgmtService#insertVehlMdyInfo(com.oms.stm.dto.VehlMdyMgmtReqDTO)
     */
    @Override
    public int insertVehlMdyInfo(VehlMdyMgmtReqDTO dto) {

        return vehlMgmtDAO.insertVehlMdyInfo(dto);
    }

    /*
     * @see com.oms.stm.service.VehlMgmtService#updateVehlMdyInfo(com.oms.stm.dto.VehlMdyMgmtReqDTO)
     */
    @Override
    public int updateVehlMdyInfo(VehlMdyMgmtReqDTO dto) {
        // TODO Auto-generated method stub
        return vehlMgmtDAO.updateVehlMdyInfo(dto);
    }

    /*
     * @see com.oms.stm.service.VehlMgmtService#updateVehlMdyEndInfo(com.oms.stm.dto.VehlMdyMgmtReqDTO)
     */
    @Override
    public int updateVehlMdyEndInfo(VehlMdyMgmtReqDTO dto) {
        // TODO Auto-generated method stub
        return vehlMgmtDAO.updateVehlMdyEndInfo(dto);
    }

    /*
     * @see com.oms.stm.service.VehlMgmtService#updateVehlPreMdyInfo(com.oms.stm.dto.VehlMdyMgmtReqDTO)
     */
    @Override
    public int updateVehlPreMdyInfo(VehlMdyMgmtReqDTO dto) {
        // TODO Auto-generated method stub
        return vehlMgmtDAO.updateVehlPreMdyInfo(dto);
    }

    /*
     * @see com.oms.stm.service.VehlMgmtService#spRecalculateSewhaIvDtl3(com.oms.stm.dto.VehlMgmtReqDTO)
     */
    @Override
    public void spRecalculateSewonIvDtl3(VehlMgmtReqDTO vehlReqDTO) {
        vehlMgmtDAO.spRecalculateSewonIvDtl3(vehlReqDTO);

    }

    /*
     * @see com.oms.stm.service.VehlMgmtService#spRecalculatePdiIvDtl3(com.oms.stm.dto.VehlMgmtReqDTO)
     */
    @Override
    public void spRecalculatePdiIvDtl3(VehlMgmtReqDTO vehlReqDTO) {
        vehlMgmtDAO.spRecalculatePdiIvDtl3(vehlReqDTO);

    }

    /*
     * @see com.oms.stm.service.VehlMgmtService#selectVehlMdyMgmt(com.oms.stm.dto.VehlMdyMgmtReqDTO)
     */
    @Override
    public VehlMdyMgmtResDTO selectVehlMdyMgmt(VehlMdyMgmtReqDTO mdyDto) {
        // TODO Auto-generated method stub
        return vehlMgmtDAO.selectVehlMdyMgmt(mdyDto);
    }

    /*
     * @see com.oms.stm.service.VehlMgmtService#prvsVehlMdyInfo(com.oms.stm.dto.VehlMdyMgmtReqDTO)
     */
    @Override
    public VehlMdyMgmtReqDTO prvsVehlMdyInfo(VehlMdyMgmtReqDTO dto) {
        // TODO Auto-generated method stub
        return vehlMgmtDAO.prvsVehlMdyInfo(dto);
    }

    /*
     * @see com.oms.stm.service.VehlMgmtService#nextVehlMdyInfo(com.oms.stm.dto.VehlMdyMgmtReqDTO)
     */
    @Override
    public VehlMdyMgmtReqDTO nextVehlMdyInfo(VehlMdyMgmtReqDTO dto) {
        // TODO Auto-generated method stub
        return  vehlMgmtDAO.nextVehlMdyInfo(dto);
    }

    /*
     * @see com.oms.stm.service.VehlMgmtService#updateVehlNextMdyInfo(com.oms.stm.dto.VehlMdyMgmtReqDTO)
     */
    @Override
    public void updateVehlNextMdyInfo(VehlMdyMgmtReqDTO dto) {
        vehlMgmtDAO.updateVehlNextMdyInfo(dto);
    }




}
