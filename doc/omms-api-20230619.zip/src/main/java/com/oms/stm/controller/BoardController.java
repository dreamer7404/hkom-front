package com.oms.stm.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import able.cloud.core.web.HController;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.oms.cmm.global.Consts;
import com.oms.cmm.utils.Utils;
import com.oms.common.dto.AttcFileReqDTO;
import com.oms.common.dto.AttcFileResDTO;
import com.oms.common.dto.RcvrResDTO;
import com.oms.common.service.AttcFileService;
import com.oms.stm.dto.BoardReqDTO;
import com.oms.stm.dto.BoardResDTO;
import com.oms.stm.service.BoardService;
import com.oms.sys.dto.UsrMgmtResDTO;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;


/**
 * <pre>
 * BoardController
 * </pre>
 *
 * @ClassName   : BoardController.java
 * @Description : 클래스 설명을 기술합니다.
 * @author 김경훈
 * @since 2023.3,8
 * @see
 */
@Tag(name = "BoardController", description = "")
@RequiredArgsConstructor
@RestController
@RequestMapping("/api")
public class BoardController extends HController {

    /**
     * 클래스 Injection
     */
    private final BoardService boardService;
    private final HttpServletRequest request;
    private final AttcFileService attcFileService;
	/**
     * 게시판 조회
     */
    @Operation(summary = "게시판 조회")
    @GetMapping("/boardMgmts")
    public  List<BoardResDTO> boardMgmts(@ModelAttribute BoardReqDTO boardReqDTO) throws Exception {
        List<BoardResDTO> list =  boardService.selectBoardList(boardReqDTO);
        return list;
    }


    @Operation(summary = "게시판 추가 모달")
    @GetMapping("/selectBoardModal")
    public  List<BoardResDTO> selectBoardModal(@ModelAttribute BoardReqDTO boardReqDTO) throws Exception {

        List<BoardResDTO> list = boardService.selectBoardGrpList(boardReqDTO);  // 게시 그룹 조회


        boardReqDTO.setUserEeno(Utils.getUserEeno(request));
        return  list;

    }



    @Operation(summary = "게시판 조회")
    @GetMapping("/boardMgmt")
    public  HashMap<String,Object> boardMgmtDetail(@ModelAttribute BoardReqDTO boardReqDTO) throws Exception {

        HashMap<String,Object> resultMap = new HashMap<String, Object>();

        BoardResDTO boardInfo = boardService.selectBoardOne(boardReqDTO);
        List<UsrMgmtResDTO> rcvrList = boardService.selectRcvrList(boardReqDTO);

        List<RcvrResDTO> rcvrChkList = boardService.selectRcvrChkList(boardReqDTO);


        // 첨부파일정보
        AttcFileReqDTO attcFileReqDTO = new AttcFileReqDTO();
//        attcFileReqDTO.setBlcSn(blcSn);
        attcFileReqDTO.setBlcSn(Long.valueOf(boardReqDTO.getBlcSn()));
        attcFileReqDTO.setAttcGbn("B"); // 게시판구분(공지사항)
        List<AttcFileResDTO> fileList = attcFileService.selectAttcFileList(attcFileReqDTO);

        resultMap.put("boardInfo", boardInfo);
        resultMap.put("rcvrList", rcvrList);
        resultMap.put("rcvrChkList",rcvrChkList);
        resultMap.put("files",fileList);

        return resultMap;

    }

  /**
  * 코드정보 등록, 수정, 삭제
  */
 @Operation(summary = "공지사항 등록", description = "")
 @PostMapping(value = "/boardMgmt")
    public Integer  boardMgmt(@RequestBody BoardReqDTO boardReqDTO) throws Exception {
     String method = Utils.getMethod(request);
        int result = 0;

        boardReqDTO.setUserEeno(Utils.getUserEeno(request));

       if (method.equals(Consts.INSERT)) {
           boardReqDTO.setBulStrtYmd(boardReqDTO.getBulStrtYmd().substring(0, 10));
           boardReqDTO.setBulFnhYmd(boardReqDTO.getBulFnhYmd().substring(0, 10));

            result = boardService.insertBoard(boardReqDTO); //게시물 등록
            for(int i=0; i<boardReqDTO.getUsrList().size(); i++) {
                boardReqDTO.getUsrList().get(i).setGbnSn(boardReqDTO.getGbnSn());
                boardReqDTO.getUsrList().get(i).setSortSn(String.valueOf(i+1));
                boardReqDTO.getUsrList().get(i).setRcvrEeno( boardReqDTO.getUsrList().get(i).getUserEeno());
                boardReqDTO.getUsrList().get(i).setPprrEeno( boardReqDTO.getUserEeno());
            }
            result = boardService.insertRcvrMgmt(boardReqDTO); //게시대상 유저 리스트 등록

            // 첨부파일 나머지정보 저장
            if(boardReqDTO.getAttcSn() != null && boardReqDTO.getAttcSn().size() > 0 ) {

                List<AttcFileReqDTO> attcFileList = new ArrayList<>();

                for(int i=0; i<boardReqDTO.getAttcSn().size(); i++) {
                    attcFileList.add(new AttcFileReqDTO(
                            Long.valueOf(boardReqDTO.getAttcSn().get(i)),
                            "B",                                    // 공지사항첨부
                            boardReqDTO.getGbnSn(),                 // 공지사항게시판 PK
                            Long.valueOf(boardReqDTO.getGbnSn()),   // 공지사항게시판 PK
                            boardReqDTO.getExtension().get(i),
                            boardReqDTO.getOriginalName().get(i),
                            Integer.valueOf(boardReqDTO.getSize().get(i)),
                            boardReqDTO.getUserEeno()
                            ));
                }
                attcFileService.updateAttcFile(attcFileList);  // tb_attc_mgmt 업데이트
            }



//
//        String mailSend = request.getParameter("mailSend");
//        boardReqDTO.setTitle(boardReqDTO.getBlcTitlNm());
//        boardReqDTO.setContents(boardReqDTO.getBlcSbc());
//        boardReqDTO.setSendemail("jayu49@hyundai.com");// 관리자 이메일로 하드코딩
//        boardReqDTO.setSendEeno(Utils.getUserEeno(request).trim()); //토큰 사용자 // 보내는 사람 아이디
//        boardReqDTO.setSendNm(boardReqDTO.getLoginNm()); // 보내는 사람 이름
//
//        String subj = request.getParameter("bulSubjCdchkVal");//받는 사람 아이디
//        String subjNm = request.getParameter("bulSubjCd"); // 받는 사람 이름
        } else if (method.equals(Consts.UPDATE)) {
            boardReqDTO.setBulStrtYmd(boardReqDTO.getBulStrtYmd().substring(0, 10));
            boardReqDTO.setBulFnhYmd(boardReqDTO.getBulFnhYmd().substring(0, 10));
            result = boardService.updateBoard(boardReqDTO);
            result = boardService.deleteBoardRecvr(boardReqDTO);

            for(int i=0; i<boardReqDTO.getUsrList().size(); i++) {
                boardReqDTO.getUsrList().get(i).setGbnSn(boardReqDTO.getBlcSn());
                boardReqDTO.getUsrList().get(i).setSortSn(String.valueOf(i+1));
                boardReqDTO.getUsrList().get(i).setRcvrEeno( boardReqDTO.getUsrList().get(i).getUserEeno());
                boardReqDTO.getUsrList().get(i).setPprrEeno( boardReqDTO.getUserEeno());
            }
            result = boardService.insertRcvrMgmt(boardReqDTO); //게시대상 유저 리스트 등록



        } else if(method.equals(Consts.DELETE)) {

            if( boardReqDTO.getDeleteList()!=null) {
                result = boardService.deleteBoardMulti(boardReqDTO);
                result = boardService.deleteBoardRecvrMulti(boardReqDTO);
            }

            else {
                result = boardService.deleteBoard(boardReqDTO);
                result = boardService.deleteBoardRecvr(boardReqDTO);
            }
        }
        return result;

    }



}