// react
import React, {useState, useEffect, useCallback} from 'react';
import {Col, Button, Collapse} from 'react-bootstrap';
import SearchIcon from '@rsuite/icons/Search';

//--------------  서버데이터용 필수 -------------------------------
import { useQuery} from 'react-query';
import { CONSTANTS } from '../../../../utils/constants';
import useStore from '../../../../utils/store';
import VehlType from '../../../Search/VehlType';
import Lang from '../../../Search/Lang';
//--------------// 서버데이터용 필수 -------------------------------

import GridPrintPageList from '../_Grid/GridPrintPageList';
import Paging from '../../../Common/Paging';
import { CustomInputGroup } from '../../../Common/CustomInputGroup';

import PrintPageAdd from '../Popup/PrintPageAdd';
import PrintPageUpdate from '../Popup/PrintPageUpdate';

const PrintPageList = () => {
    
    //------------------- 필수 공통 ------------------------------
    const [open, setOpen] = useState(true); // 조건창 열기/닫기
    const {keyword } = useStore();  // 조회키워드 가져오기

    const [activePage, setActivePage] = useState(1);    // 페이지번호
    const [limit, setLimit] = useState(50);             // 페이지행수
    const [filterValue, setFilterValue] = useState(''); // 필터값

    const onChangePage = val => {
        setActivePage(val);
    };
    const onChangeLimit = val => {
        setLimit(val);
    };
    useEffect(()=>{
        onChangePage(1); // 페이지번호 리셋
    },[keyword]);

    // 필터
    const onFilterTextBoxChanged = useCallback((e) => {
        setFilterValue(e.target.value);
    }, []);

    // 검색창 열기/닫기 > 페이지네이션 여부에 따라 +-20px
    const [gridHeight, setGridHeight] = useState(575);
    const gridExpand = () =>{
        setOpen(!open);
        if(open){
            setTimeout(() => setGridHeight(650), 250);
        }else{
            setGridHeight(575)
        }
    }
    //-------------------// 필수 공통 ------------------------------

    const [rowData] = useState([
        { carCd: "AD", carName: "AVANTE", monthYear: '23MY', region:'일반', langCd:'EE', langName:'영어/유럽', printNum:'POAO-AR31F-01', addDate:'2023-03-31', page1:'0', page2:'0', page3:'0' },
        { carCd: "AD", carName: "AVANTE", monthYear: '23MY', region:'일반', langCd:'EE', langName:'영어/유럽', printNum:'POAO-AR31F-01', addDate:'2023-03-31', page1:'0', page2:'0', page3:'0' },
    ]);

    //  requestState 조회
    const queryResult = useQuery(["PrintPageList"], () => {return rowData});

    // 셀 클릭
    const onCellClicked = e => {
        if(e.column.colId === 'carName'){
            setPrintPageUpdatePop(true)
        }
    };

    const [printPageAddPop, setPrintPageAddPop] = useState(false);
    const [printPageUpdatePop, setPrintPageUpdatePop] = useState(false);

    // 조회버튼
    const onSearch = () => {
        queryResult.refetch(); // 수동쿼리실행
    };

    return (
        <>
            <div className="search-area">
                <Collapse in={open}>
                    <div className="form" id="example-collapse-text">
                        <div className="search-group">
                            <div className="row">
                                <Col sm={4} className="" >
                                    <VehlType  />
                                </Col>
                                <Col sm={4} className="" >
                                    <Lang  />
                                </Col>
                            </div>

                            <div className="search-btn-wrap">
                                <Button className="btn-search" variant="outline-primary" size="sm" onClick={onSearch}><SearchIcon />조회</Button>
                            </div>
                        </div>
                    </div>
                </Collapse>
                <Button size="sm" variant="outline-dark" className="search-control" aria-controls="example-collapse-text" 
                    aria-expanded={open} onClick={gridExpand}>
                    <span className={open === true ? "search-area-close" : "search-area-open"}>{open === true ? CONSTANTS.closeSearch : CONSTANTS.openSearch}</span>
                </Button>
            </div>
            
            <div className="grid-wrap">
                <div className="grid-btn-wrap">
                    <div className="left-align">
                        {/*--------- 필터 -----------*/}
                        <CustomInputGroup size="sm"   onInput={onFilterTextBoxChanged} />
                    </div>
                    <div className="right-align">
                        {/*--------- 버튼 -----------*/}
                        <Button variant="outline-secondary" size="sm" onClick={() => setPrintPageAddPop(true)}>인쇄페이지 등록</Button>{' '}
                        <Button variant="outline-secondary" size="sm">삭제</Button>{' '}
                        <Button variant="outline-success" size="sm"><span className="excel-down"></span>{CONSTANTS.excelDownload}</Button>{' '}
                    </div>
                </div>
                {/*--------- Grid -----------*/}
                <GridPrintPageList 
                    gridHeight={gridHeight}
                    filterValue={filterValue}
                    queryResult={queryResult}
                    limit={limit}
                    activePage={activePage}
                    onCellClicked={onCellClicked}
                    />

                {/*--------- 페이징 -----------*/}
                <Paging 
                    total={queryResult && queryResult.data && queryResult.data.length}
                    limit={limit}
                    activePage={activePage}
                    onChangePage={onChangePage}
                    onChangeLimit={onChangeLimit}
                />
            </div>

            {/* 팝업 */}
            <PrintPageAdd show={printPageAddPop} onHide={() => setPrintPageAddPop(false)}  />
            <PrintPageUpdate show={printPageUpdatePop} onHide={() => setPrintPageUpdatePop(false)}  />
        </>
    )
};
export default PrintPageList;