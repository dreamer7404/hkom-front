import React, {useEffect, useMemo, useRef} from 'react';
import { AgGridReact } from 'ag-grid-react';
import { CONSTANTS } from '../../../../utils/constants';

const GridRequestState = ({gridHeight, filterValue, queryResult, limit, activePage}) => {

  const gridRef = useRef();

  const columnDefs = [
        {
          checkboxSelection: true,
          headerCheckboxSelection: true,
          spanHeaderHeight: true,
          width:45,
          maxWidth:45,
          minWidth:45,
        },
        {
          headerName: '차종코드',
          field: 'yongsanIvm1',
          spanHeaderHeight: true
        },  
        {
          headerName: '품번',
          field: 'yongsanIvm2',
          spanHeaderHeight: true
        },  
        {
          headerName: '품명',
          field: 'yongsanIvm3',
          spanHeaderHeight: true
        },  
        {
          headerName: '차량재고\n(오전09시 기준)',
          field: 'yongsanIvm4',
          spanHeaderHeight: true
        }, 
        {
          headerName: '당월투입\n(누적)',
          field: 'yongsanIvm5',
          spanHeaderHeight: true
        }, 
        {
          headerName: '용산(계)',
          children: [
            { headerName:'합계', field: 'yongsanIvm6',},
            { headerName:'이동중재고', field: 'yongsanIvm7'},
            { headerName:'원올단품', field: 'yongsanIvm8' },
            { headerName:'원올KIT', field: 'yongsanIvm9' },
            { headerName:'지역재고', field: 'yongsanIvm10' },
          ],
        },
        {
          headerName: '출고대수\n(3일평균)',
          field: 'yongsanIvm11',
          spanHeaderHeight: true
        }, 
        {
          headerName: '대응일수',
          field: 'yongsanIvm12',
          spanHeaderHeight: true
        }, 
        {
          headerName: '발주',
          field: 'yongsanIvm13',
          spanHeaderHeight: true
        }, 
        {
          headerName: '입고잔량',
          field: 'yongsanIvm14',
          spanHeaderHeight: true
        }, 
    ]

  const defaultColDef = useMemo(() => {
      return {
          initialWidth: 90,
          sortable: true,
          resizable:true,
      };
  }, []);

  const onFirstDataRendered = (params) => {
      params.api.sizeColumnsToFit();
  };

  useEffect(()=>{
    if(queryResult.status === 'loading' && gridRef && gridRef.current && gridRef.current.api){
        gridRef.current.api.showLoadingOverlay();
    }
  },[queryResult]);

  useEffect(()=> {
    if(gridRef && gridRef.current && gridRef.current.api){
      gridRef.current.api.setQuickFilter(filterValue);
    }
  },[filterValue]);

  useEffect(()=> {
    if(gridRef && gridRef.current && gridRef.current.api){
      gridRef.current.api.paginationGoToPage(activePage-1);
    }
  },[activePage]);


  return(
      <div className="ag-theme-alpine" style={{height: gridHeight, transition:'all ease .3s'}}>
        <AgGridReact
            ref={gridRef} 
            rowData={queryResult && queryResult.data} 
            columnDefs={columnDefs}
            defaultColDef={defaultColDef}

            // paging
            pagination={true}
            paginationPageSize={limit} //
            suppressPaginationPanel={true} 
            // onPaginationChanged={onPaginationChanged}

            //  filter
            cacheQuickFilter={true}

            // multi select
            rowSelection={'multiple'}
            suppressRowClickSelection= {true}

            // overlay
            overlayLoadingTemplate={CONSTANTS.gridLoading}
            overlayNoRowsTemplate={CONSTANTS.gridNoRows}

            onFirstDataRendered={onFirstDataRendered}
            suppressSizeToFit={true}    
            onGridSizeChanged={onFirstDataRendered}    
            >
        </AgGridReact>
    </div>
  )


};
export default GridRequestState;