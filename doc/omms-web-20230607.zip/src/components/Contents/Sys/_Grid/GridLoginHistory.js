import React, {useEffect, useMemo, useRef} from 'react';
import { AgGridReact } from 'ag-grid-react';
import { CONSTANTS } from '../../../../utils/constants';

const GridLoginHistory = ({gridHeight, filterValue, queryResult, limit, activePage}) => {

  const gridRef = useRef();

  const columnDefs = [
        {
          headerName: '사용자ID',
          field: 'userId',
        },
        {
          headerName: '사용자명',
          field: 'userNm',
        },  
        {
          headerName: '성공여부',
          field: 'sucYn',
          maxWidth:'150'
        },  
        {
          headerName: '사용자IP',
          field: 'userIp',
        },  
        {
          headerName: '세션ID',
          field: 'sessionId',
        },  
        {
          headerName: '로그아웃 일시',
          field: 'logoutTime',
        },  
        {
          headerName: '로그아웃 방법',
          field: 'logoutType',
        },  
  ]

  const defaultColDef = useMemo(() => {
      return {
          initialWidth: 90,
          sortable: true,
          resizable:true,
      };
  }, []);

  const onFirstDataRendered = (params) => {
      params.api.sizeColumnsToFit();
  };

  useEffect(()=>{
    if(queryResult.status === 'loading' && gridRef && gridRef.current && gridRef.current.api){
        gridRef.current.api.showLoadingOverlay();
    }
  },[queryResult]);

  useEffect(()=> {
    if(gridRef && gridRef.current && gridRef.current.api){
      gridRef.current.api.setQuickFilter(filterValue);
    }
  },[filterValue]);

  useEffect(()=> {
    if(gridRef && gridRef.current && gridRef.current.api){
      gridRef.current.api.paginationGoToPage(activePage-1);
    }
  },[activePage]);


  return(
      <div className="ag-theme-alpine" style={{height: gridHeight, transition:'all ease .3s'}}>
        <AgGridReact
            ref={gridRef} 
            rowData={queryResult && queryResult.data} 
            columnDefs={columnDefs}
            defaultColDef={defaultColDef}

            // paging
            pagination={true}
            paginationPageSize={limit} //
            suppressPaginationPanel={true} 
            // onPaginationChanged={onPaginationChanged}

            //  filter
            cacheQuickFilter={true}

            // overlay
            overlayLoadingTemplate={CONSTANTS.gridLoading}
            overlayNoRowsTemplate={CONSTANTS.gridNoRows}

            onFirstDataRendered={onFirstDataRendered}
            suppressSizeToFit={true}    
            onGridSizeChanged={onFirstDataRendered}    
            >
        </AgGridReact>
    </div>
  )


};
export default GridLoginHistory;