import React, {useEffect, useMemo, useRef} from 'react';
import {Form} from 'rsuite';
import { AgGridReact } from 'ag-grid-react';
import { CONSTANTS } from '../../../../utils/constants';

const GridPrintOrderAdd = ({filterValue, queryResult, limit, activePage, onCellClicked}) => {

  const gridRef = useRef();

  const columnDefs = [
    {
      headerName: '월평균\n수출오더',
      field: 'test1',
      spanHeaderHeight: true,
    },
    {
      headerName: '수출오더\n(당월)',
      field: 'test2',
      spanHeaderHeight: true,
    },
    {
      headerName: '월평균 생산량',
      field: 'test3',
      spanHeaderHeight: true,
    },
    {
      headerName: '생산계획\n(2주)',
      field: 'test4',
      spanHeaderHeight: true,      
      cellStyle: () => ({textDecoration: 'underline', cursor: 'pointer', color:'#2589f5'}),
    },  
    {
      headerName: '단기계획\n(3일)',
      field: 'test5',
      spanHeaderHeight: true,
      cellStyle: () => ({textDecoration: 'underline', cursor: 'pointer', color:'#2589f5'}),
    },  
    {
      headerName: '당월투입\n(누적)',
      field: 'test6',
      spanHeaderHeight: true,
      cellStyle: () => ({textDecoration: 'underline', cursor: 'pointer', color:'#2589f5'}),
    },
    {
      headerName: '전일투입\n(D-1)',
      field: 'test7',
      spanHeaderHeight: true,
    },
    {
      headerName: '재고현황',
      children: [
        { headerName:'세원',
          children: [
              { headerName:'인쇄중', field: 'test8',  cellRenderer: "LinkComponent", cellStyle: () => ({textDecoration: 'underline', cursor: 'pointer', color:'#2589f5'}) },
              { headerName:'보유재고', field: 'test9', cellRenderer: "LinkComponent", cellStyle: () => ({textDecoration: 'underline', cursor: 'pointer', color:'#2589f5'})},
          ],
        },
        { headerName:'PDI/용산', field: 'test10', spanHeaderHeight: true,  cellRenderer: "LinkComponent", cellStyle: () => ({textDecoration: 'underline', cursor: 'pointer', color:'#2589f5'})},
        { headerName:'합계', field: 'test11', spanHeaderHeight: true },
      ],
    },
    {
          headerName: '예상재고\n(2주)',
          field: 'test12',
          spanHeaderHeight: true,
    },
    {
          headerName: '재고상태',
          field: 'test13',
          spanHeaderHeight: true,
          cellRenderer: "statusComonent"
    }
  ];

    const defaultColDef = useMemo(() => {
        return {
            initialWidth: 90,
            sortable: true,
            resizable:true,
        };
    }, []);

    const onFirstDataRendered = (params) => {
        params.api.sizeColumnsToFit();
    };

    //aggrid 재고상태
  const statusComonent = (props) => {
        
    if(props.value === "OK"){
      return(
          <div className="status-title status-1">
          {props.value}
          </div>
      )
    }else if(props.value === "준비"){
      return(
          <div className="status-title status-2">
          {props.value}
          </div>
      )
    }else if(props.value === "발주필요"){
      return(
          <div className="status-title status-3">
          {props.value}
          </div>
      )
    }else{
      return(
          <div className="status-title status-4" style={{cursor:'pointer'}}>
          {props.value}
          </div>
      )
    }

  }

  useEffect(()=>{
    if(queryResult.status === 'loading' && gridRef && gridRef.current && gridRef.current.api){
        gridRef.current.api.showLoadingOverlay();
    }
  },[queryResult]);

  useEffect(()=> {
    if(gridRef && gridRef.current && gridRef.current.api){
      gridRef.current.api.setQuickFilter(filterValue);
    }
  },[filterValue]);

  useEffect(()=> {
    if(gridRef && gridRef.current && gridRef.current.api){
      gridRef.current.api.paginationGoToPage(activePage-1);
    }
  },[activePage]);


  return(
    <Form>
      <div className="ag-theme-alpine" style={{height: 123.5, transition:'all ease .3s'}}>
        <AgGridReact
            ref={gridRef} 
            rowData={queryResult && queryResult.data} 
            columnDefs={columnDefs}
            defaultColDef={defaultColDef}

            // paging
            pagination={true}
            paginationPageSize={limit} //
            suppressPaginationPanel={true} 
            // onPaginationChanged={onPaginationChanged}

            //  filter
            cacheQuickFilter={true}

            // overlay
            overlayLoadingTemplate={CONSTANTS.gridLoading}
            overlayNoRowsTemplate={CONSTANTS.gridNoRows}

            frameworkComponents={{
                statusComonent
            }}

            // click column
            onCellClicked={onCellClicked} //
            
            onFirstDataRendered={onFirstDataRendered}
            suppressSizeToFit={true}    
            onGridSizeChanged={onFirstDataRendered}    
            >
        </AgGridReact>
        
      </div>
    </Form>
  )


};
export default GridPrintOrderAdd;