
export const utcToLocalDate = utc => {
    return new Date(utc).toLocaleString('en-CA').substring(0, 10);
}

export const getBreadCrumbs = (menu, pathname) => {
    let obj = {home: 'Home', first: '', second: ''};
    
    const idx = pathname.lastIndexOf('/');
    if(idx !== 0){
        pathname = pathname.substring(0, idx);
    }

    if(menu && menu.length > 0){
        const findIndex = menu.findIndex(d => (d.pgmIdSn !== 0 && d.pgmPathAdr === pathname));
        if(findIndex > -1){
            const findObj = menu[findIndex];
            obj.second = findObj.pgmNm;
            obj.first =  menu[findIndex-findObj.pgmIdSn].pgmNm;
        }
    }
    return obj;
}

export const formatNumber = (number) => {
	// this puts commas into the number eg 1000 goes to 1,000,
	// i pulled this from stack overflow, i have no idea how it works
	return Math.floor(number)
			   .toString()
			   .replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1,');
};

//escape 문자 처리 그리드용
export const escapeCharChangeForGrid = (props) => {
	if(!props.value) return false;
	
    return props.value.replace(/&#39;/g,"\'")
					  .replace(/&quot;/g,"\"")
					  .replace(/&#58;/g,":")
					  .replace(/&#59;/g,";")
					  .replace(/&#40;/g,"(")
					  .replace(/&#40;/g,"(")
					  .replace(/&#41;/g,")")
					  .replace(/&lt;/g,"<")
					  .replace(/&gt;/g,">")
					  .replace(/&#123;/g,"{")
					  .replace(/&#125;/g,"}")
					  .replace(/&#35;/g,"#")
					  .replace(/&#36;/g,"$")
					  .replace(/&#37;/g,"%")
					  .replace(/&#64;/g,"@")
					  .replace(/&amp;/g,"&")
					  .replace(/&#63;/g,"?")
					  .replace(/&#33;/g,"!")
					  .replace(/&#42;/g,"*")
					  .replace(/&#124;/g,"|")
					  .replace(/&#42;/g,"*")
					  .replace(/&#58;/g,":")
					  .replace(/&#35;/g,"#")
					  .replace(/&amp;/g,"&")
					  ;
}

//escape 문자 처리 그리드용
export const escapeCharChange = (data) => {
	if(!data) return false;
    return data.replace(/&#39;/g,"\'")
			   .replace(/&quot;/g,"\"")
			   .replace(/&#58;/g,":")
			   .replace(/&#59;/g,";")
			   .replace(/&#40;/g,"(")
			   .replace(/&#41;/g,")")
			   .replace(/&lt;/g,"<")
			   .replace(/&gt;/g,">")
			   .replace(/&#123;" /g,"{")
			   .replace(/&#125;/g,"}")
			   .replace(/&#35;/g,"#")
			   .replace(/&#36;/g,"$")
			   .replace(/&#37;/g,"%")
			   .replace(/&#64;/g,"@")
			   .replace(/&amp;/g,"&")
			   .replace(/&#63;/g,"?")
			   .replace(/&#33;/g,"!")
			   .replace(/&#42;/g,"*")
			   .replace(/&#124;/g,"|")
			   .replace(/&#42;/g,"*")
			   .replace(/&#58;/g,":")
			   .replace(/&#35;/g,"#")
			   .replace(/&amp;/g,"&")
			   ;
}

//escape 문자 처리 그리드용
export const changeCharToEscape = (data) => {
	if(!data) return false;
    return data.replace(/&#39;/g,"\'")
			   .replace(/&quot;/g,"\"")
			   .replace(/:/g,"&#58;")
			   .replace(/;/g,"&#59;")
			   .replace(/&#40;/g,"(")
			   .replace(/&#41;/g,")")
			   .replace(/</g,"&lt;")
			   .replace(/>/g,"&gt;")
			   .replace(/&#123;" /g,"{")
			   .replace(/&#125;/g,"}")
			   .replace(/&#35;/g,"#")
			   .replace(/&#36;/g,"$")
			   .replace(/&#37;/g,"%")
			   .replace(/&#64;/g,"@")
			   .replace(/&amp;/g,"&")
			   .replace(/&#63;/g,"?")
			   .replace(/&#33;/g,"!")
			   .replace(/&#42;/g,"*")
			   .replace(/&#124;/g,"|")
			   .replace(/&#42;/g,"*")
			   .replace(/&#58;/g,":")
			   .replace(/&#35;/g,"#")
			   .replace(/&amp;/g,"&")
			   ;
}


