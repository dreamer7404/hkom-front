(function(){var a={};try{G_DEPlugin&&(G_DEPlugin.intelligent.lang=a,dext5_lang.plugins.intelligent=a)}catch(b){}})();
