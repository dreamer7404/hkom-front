(function(){var a={};try{G_DEPlugin&&(G_DEPlugin.lazyload.lang=a,dext5_lang.plugins.lazyload=a)}catch(b){}})();
