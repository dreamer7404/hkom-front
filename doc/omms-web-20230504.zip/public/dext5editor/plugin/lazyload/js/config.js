﻿G_DEPlugin["lazyload"].options = {
    srcAttr: 'dext-src',
    lazyClass: 'dext_lazyload'
};
