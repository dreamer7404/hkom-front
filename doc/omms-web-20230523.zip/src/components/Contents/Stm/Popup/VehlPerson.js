import React, {useState, useMemo, useRef,useEffect, useCallback} from 'react';
import {Button, Modal, Table} from 'react-bootstrap';
import { AgGridReact } from 'ag-grid-react';
import { API} from '../../../../utils/constants';
import { getData } from '../../../../utils/async';
import { useQuery} from 'react-query';
import { GridApi } from 'ag-grid-community';
const VehlPerson = ({show, onHide, param,chrgList, onChangeUsrList}) => {
    const usrGrid = useRef();
    const defaultColDef = useMemo(() => {
        return {
            initialWidth: 90,
            resizable:true,
            sortable:true,
        };
    }, []);

    useEffect(() => {
        console.log('chrgList', chrgList)
    },[])

    //처음 팝업 들어왔을때는 빈값, 기존에 선택한 값이 있을 경우 chkYn을 'Y'로 바꿈
    //모달창 그리드 조회
    const usrData = useQuery([API.userMgmtPop,param], () => getData(API.userMgmtPop, param),{
        select: data => data.map(item => ({...item, chkYn: chrgList.find(f => f === item.userEeno) ? 'Y' : 'N'}))
    })
        
    const columnDefs = [
        {
            checkboxSelection: true,
            headerCheckboxSelection: true,
            spanHeaderHeight: true,
            width:45,
            maxWidth:45,
            minWidth:45
        },
        {
            headerName: '회사구분',
            field: 'coNm',
            spanHeaderHeight: true,
        },
        {
            headerName: '부서명',
            field: 'deptNm',
            spanHeaderHeight: true,
        },
        {
            headerName: '아이디',
            field: 'userEeno',
            spanHeaderHeight: true,
        },
        {
            headerName: '이름',
            field: 'userNm',
            spanHeaderHeight: true,
        }   
    ]

    


    const saveEvent = () =>{
        let selectedRows = usrGrid.current.api.getSelectedRows();
        onChangeUsrList(param.blnsCoCd, selectedRows);
        onHide();
    }


    const onFirstDataRendered = (params) => {
        params.api.sizeColumnsToFit();

        let grid = usrGrid.current.api;
        grid.forEachNode((node) =>
            // console.log(node.data.userEeno)
            node.setSelected(!!node.data && node.data.chkYn === 'Y' )
        )
    };

    return (
        <>
            <Modal show={show} onHide={onHide} backdrop="static" backdropClassName="modal-in-backdrop" keyboard={false} centered size="md" className="modal-custom modal-in-modal">
                <Modal.Header closeButton>
                    <Modal.Title>담당자 검색</Modal.Title>
                </Modal.Header>
                    <Modal.Body>
                          <div className="ag-theme-alpine" style={{height:300}}>
                                <AgGridReact
                                    ref={usrGrid} 
                                    rowData={usrData && usrData.data}
                                    columnDefs={columnDefs}
                                    defaultColDef={defaultColDef}
                                    rowSelection={'multiple'}
                                    suppressRowClickSelection= {true} 
                                    onFirstDataRendered={onFirstDataRendered}
                                    suppressSizeToFit={true}    
                                    onGridSizeChanged={onFirstDataRendered}     
                                ></AgGridReact>
                            </div>
                    </Modal.Body>
                    <Modal.Footer>
                        <Button variant="light" size="md" onClick={onHide}>취소</Button>
                        <Button variant="primary" size="md" onClick={()=>saveEvent()}>저장</Button>
                    </Modal.Footer>
            </Modal>
        </>
    );

};
export default VehlPerson;