import React from 'react';
import {Row, Col, Button, Modal, Table} from 'react-bootstrap';
import {Form, SelectPicker } from 'rsuite';

const NatLangCopy = ({show, onHide}) => {

    return (
        <>
            <Form>
                <Modal show={show} onHide={onHide} backdrop="static" backdropClassName="modal-in-backdrop" keyboard={false} centered size="md" className="modal-custom modal-in-modal">
                    <Modal.Header closeButton>
                        <Modal.Title>국가언어복사</Modal.Title>
                    </Modal.Header>
                        <Modal.Body>
                            <Table className="tbl-hor" bordered>
                                <tbody>
                                    <tr>
                                        <th className="essen">대상국가</th>
                                        <td>
                                            <Row className="select-wrap">
                                                <Col sm={8}>
                                                    <SelectPicker size="sm" data={[{ label: "선택"}]} searchable={false} cleanable={false} />
                                                </Col>
                                                <Col sm={4}>
                                                    <SelectPicker size="sm" data={[{ label: "MY"}]} searchable={false} cleanable={false} />
                                                </Col>
                                            </Row>
                                        </td>
                                    </tr>
                                </tbody>
                            </Table>
                        </Modal.Body>

                        <Modal.Footer>
                            <Button variant="light" size="md" onClick={onHide}>취소</Button>
                            <Button variant="primary" size="md" onClick={onHide}>저장</Button>
                        </Modal.Footer>
                </Modal>
            </Form>
        </>
    );

};
export default NatLangCopy;