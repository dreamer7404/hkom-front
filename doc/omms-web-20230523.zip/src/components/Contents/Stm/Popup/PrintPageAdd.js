import React from 'react';
import {Button, Modal, Table, Row, Col} from 'react-bootstrap';
import {Form, SelectPicker, DatePicker} from 'rsuite';

const PrintPageAdd = ({show, onHide}) => {

    return (
        <>
            <Form>
                <Modal show={show} onHide={onHide} backdrop="static" keyboard={false} centered size="lg" className="modal-custom">
                    <Modal.Header closeButton>
                        <Modal.Title>인쇄페이지 등록</Modal.Title>
                    </Modal.Header>
                        <Modal.Body>
                            <Table className="tbl-hor" bordered>
                                <colgroup>
                                    <col style={{width:'15%'}}></col>
                                    <col style={{width:'35%'}}></col>
                                    <col style={{width:'15%'}}></col>
                                    <col style={{width:'35%'}}></col>
                                </colgroup>
                                <tbody>
                                    <tr>
                                        <th className="essen">차종</th>
                                        <td>
                                            <Row className="select-wrap">
                                                <Col sm={8}>
                                                    <SelectPicker size="sm" data={[{ label: "차종"}]} searchable={false} cleanable={false} />
                                                </Col>
                                                <Col sm={4}>
                                                    <SelectPicker block style={{width:'100%'}} size="sm" data={[{ label: "MY"}]} searchable={false} cleanable={false} />
                                                </Col>
                                            </Row>
                                        </td>
                                        <th className="essen">언어</th>
                                        <td>
                                            <Row className="select-wrap">
                                                <Col sm={4}>
                                                    <SelectPicker size="sm" data={[{ label: "지역"}]} searchable={false} cleanable={false} />
                                                </Col>
                                                <Col sm={8}>
                                                    <SelectPicker block style={{width:'100%'}} size="sm" data={[{ label: "언어"}]} searchable={false} cleanable={false} />
                                                </Col>
                                            </Row>
                                        </td>
                                    </tr>
                                    <tr>
                                        <th className="essen">발간번호</th>
                                        <td>
                                            <Row className="select-wrap">
                                                <Col sm={8}>
                                                    <Form.Control size="sm" type="text"/> 
                                                </Col>
                                                <Col sm={4}>
                                                    <Form.Control size="sm" type="text"/> 
                                                </Col>
                                            </Row>
                                        </td>
                                        <th className="essen">등록일</th>
                                        <td>
                                            <DatePicker oneTap block size="sm"
                                            cleanable={false}
                                            searchable="true"
                                            ranges={[
                                                {
                                                label: '오늘',
                                                value: new Date()
                                                }
                                            ]}
                                            />
                                        </td>
                                    </tr>
                                    <tr>
                                        <th className="essen">마지막페이지 구분</th>
                                        <td colSpan="3">
                                            <div className="grid-btn-wrap" style={{marginBottom:'5px'}}>
                                                <div className="right-align">
                                                    {/*--------- 버튼 -----------*/}
                                                    <Button variant="outline-secondary" size="sm">추가</Button>{' '}
                                                    <Button variant="outline-secondary" size="sm">삭제</Button>{' '}
                                                </div>
                                            </div>
                                            <Table className="tbl-hor" bordered>
                                                <colgroup>
                                                    <col style={{width:'60px'}}></col>
                                                    <col style={{width:''}}></col>
                                                    <col style={{width:'60px'}}></col>
                                                    <col style={{width:''}}></col>
                                                    <col style={{width:'60px'}}></col>
                                                    <col style={{width:''}}></col>
                                                    <col style={{width:'60px'}}></col>
                                                    <col style={{width:''}}></col>
                                                </colgroup>
                                                <tbody>
                                                    <tr>
                                                        <th>서문1</th>
                                                        <td><Form.Control size="sm" type="text"/> </td>
                                                        <th>서문2</th>
                                                        <td><Form.Control size="sm" type="text"/> </td>
                                                        <th>서문3</th>
                                                        <td><Form.Control size="sm" type="text"/> </td>
                                                        <th>1장</th>
                                                        <td><Form.Control size="sm" type="text"/> </td>
                                                    </tr>
                                                    <tr>
                                                        <th>2장</th>
                                                        <td><Form.Control size="sm" type="text"/> </td>
                                                        <th>3장</th>
                                                        <td><Form.Control size="sm" type="text"/> </td>
                                                        <th>4장</th>
                                                        <td><Form.Control size="sm" type="text"/> </td>
                                                        <th>5장</th>
                                                        <td><Form.Control size="sm" type="text"/> </td>
                                                    </tr>
                                                    <tr>
                                                        <th>6장</th>
                                                        <td><Form.Control size="sm" type="text"/> </td>
                                                        <th>7장</th>
                                                        <td><Form.Control size="sm" type="text"/> </td>
                                                        <th>8장</th>
                                                        <td><Form.Control size="sm" type="text"/> </td>
                                                        <th>9장</th>
                                                        <td><Form.Control size="sm" type="text"/> </td>
                                                    </tr>
                                                    <tr>
                                                        <th>10장</th>
                                                        <td><Form.Control size="sm" type="text"/> </td>
                                                        <th>11장</th>
                                                        <td><Form.Control size="sm" type="text"/> </td>
                                                        <th>12장</th>
                                                        <td><Form.Control size="sm" type="text"/> </td>
                                                        <th>색인</th>
                                                        <td><Form.Control size="sm" type="text"/> </td>
                                                    </tr>
                                                </tbody>
                                            </Table>
                                        </td>
                                    </tr>
                                </tbody>
                            </Table>
                        </Modal.Body>

                        <Modal.Footer>
                            <Button variant="light" size="md" onClick={onHide}>취소</Button>
                            <Button variant="primary" size="md" onClick={onHide} >저장</Button>
                        </Modal.Footer>
                </Modal>
            </Form>

        </>
    );

};
export default PrintPageAdd;