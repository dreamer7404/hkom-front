// react
import React, {useState, useEffect, useCallback, useRef} from 'react';
import {Col, Button, Collapse} from 'react-bootstrap';
import {Form, SelectPicker, Input} from 'rsuite';
import SearchIcon from '@rsuite/icons/Search';

//--------------  서버데이터용 필수 -------------------------------
import { useQuery, useQueryClient, useMutation} from 'react-query';
import { getData, postData } from '../../../../utils/async';
import { API, CONSTANTS } from '../../../../utils/constants';
import useStore from '../../../../utils/store';
//--------------// 서버데이터용 필수 -------------------------------
import { confirmAlert } from 'react-confirm-alert'; 
import ConfirmAlert from   '../../../Common/ConfirmAlert';  

import GridPgmList from '../_Grid/GridPgmList';
import Paging from '../../../Common/Paging';
import { CustomInputGroup } from '../../../Common/CustomInputGroup';

import PgmAdd from '../Popup/PgmAdd';
import PgmUpdate from '../Popup/PgmUpdate';
import PgmUpload from '../Popup/PgmUpload';

const PgmList = () => {

    //------------------- 필수 공통 ------------------------------
    const [open, setOpen] = useState(true); // 조건창 열기/닫기
    const {keyword, coCd, deptCd } = useStore();  // 조회키워드 가져오기

    const [activePage, setActivePage] = useState(1);    // 페이지번호
    const [limit, setLimit] = useState(50);             // 페이지행수
    const [filterValue, setFilterValue] = useState(''); // 필터값

    const onChangePage = val => {
        setActivePage(val);
    };
    const onChangeLimit = val => {
        setLimit(val);
    };
    useEffect(()=>{
        onChangePage(1); // 페이지번호 리셋
    },[keyword]);

    // 필터
    const onFilterTextBoxChanged = useCallback((e) => {
        setFilterValue(e.target.value);
    }, []);

    // 검색창 열기/닫기 > 페이지네이션 여부에 따라 +-20px
    const [gridHeight, setGridHeight] = useState(575);
    const gridExpand = () =>{
        setOpen(!open);
        if(open){
            setTimeout(() => setGridHeight(650), 250);
        }else{
            setGridHeight(575)
        }
    }
    //-------------------// 필수 공통 ------------------------------

    const gridRef = useRef();

    //  requestState 조회
    const queryResult = useQuery([API.apiMgmts], () => getData(API.apiMgmts));

    useEffect(()=> {
        if(queryResult.data){
            console.log('queryResult.data',queryResult.data);
        }
    },[queryResult.data])

    const [data, setData] = useState({})
    // 셀 클릭
    const onCellClicked = e => {
        setData(e.data)
        setPgmUpdatePop(true)
    };

    const [pgmAddPop, setPgmAddPop] = useState(false);
    const [pgmUpdatePop, setPgmUpdatePop] = useState(false);
    const [pgmUploadPop, setPgmUploadPop] = useState(false);

    // 조회버튼
    const onSearch = () => {
        setTimeout(()=> queryResult.refetch(), 100); // 수동쿼리실행
    };

    const selectData = ['전체', '재고관리', '제작준비', '발간현황', '선적현황', '운영관리', '시스템관리'].map(
        item => ({ label: item, value: item })
    );

    const onHidePgmAddPop = () => {
        setPgmAddPop(false);
        onSearch();
    }

    const onHidePgmUpdatePop = () => {
        setPgmUpdatePop(false);
        onSearch();
    }

    const deleteMutate = useMutation((params => postData(API.apiMgmt, params, CONSTANTS.delete)),{
        onSuccess: res => {
            if(res === 1){
                
                onSearch();
            }else{
                confirmAlert({
                    closeOnClickOutside: false,
                    customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}  title={"알림"} msg={"삭제 실패했습니다.<br /> 관리자에게 문의해주세요."}  />
                })
            }
        }
    }); 

    const onOk =() => {
        const selectedRows = gridRef.current.api.getSelectedRows();
        // 삭제
        deleteMutate.mutate({apiUrls: selectedRows.map(item => item.apiUrl)});
    };

    const deletePgm = () => {
        const selectedRows = gridRef.current.api.getSelectedRows();
        if(selectedRows.length === 0){
            confirmAlert({
                closeOnClickOutside: false,
                customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}  title={"알림"} msg={"삭제할 프로그램을 선택해주세요."}  />
            })
        }else{
            confirmAlert({
                closeOnClickOutside: false,
                customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}  title={"알림"} msg={"삭제하시겠습니까?"} onOk={onOk}  />
            });
        }
    }

    return (
        <>
            <div className="search-area">
                <Collapse in={open}>
                    <div className="form" id="example-collapse-text">
                        <div className="search-group">
                            <div className="row">
                                <Col sm={3} className=""> 
                                    <Form.ControlLabel column="sm" >메뉴그룹</Form.ControlLabel>
                                    <SelectPicker  block size="sm" searchable={false} cleanable={false} data={selectData} defaultValue="전체" />
                                </Col>
                                <Col sm={3} className="" >
                                    <Form.ControlLabel>프로그램아이디/프로그램명</Form.ControlLabel>
                                    <Input type="text" size="sm" />
                                </Col>
                            </div>

                            <div className="search-btn-wrap">
                                <Button className="btn-search" variant="outline-primary" size="sm" onClick={onSearch}><SearchIcon />조회</Button>
                            </div>
                        </div>
                    </div>
                </Collapse>
                <Button size="sm" variant="outline-dark" className="search-control" aria-controls="example-collapse-text" 
                    aria-expanded={open} onClick={gridExpand}>
                    <span className={open === true ? "search-area-close" : "search-area-open"}>{open === true ? CONSTANTS.closeSearch : CONSTANTS.openSearch}</span>
                </Button>
            </div>
            
            <div className="grid-wrap">
                <div className="grid-btn-wrap">
                    <div className="left-align">
                        {/*--------- 필터 -----------*/}
                        <CustomInputGroup size="sm"   onInput={onFilterTextBoxChanged} />
                    </div>
                    <div className="right-align">
                        {/*--------- 버튼 -----------*/}
                        <Button variant="outline-secondary" size="sm" onClick={() => setPgmAddPop(true)}>프로그램 등록</Button>{' '}
                        <Button variant="outline-secondary" size="sm" onClick={deletePgm}>삭제</Button>{' '}
                        <Button variant="outline-secondary" size="sm" onClick={() => setPgmUploadPop(true)}>액셀 업로드</Button>{' '}
                    </div>
                </div>
                {/*--------- Grid -----------*/}
                <GridPgmList 
                    gridRef={gridRef}
                    gridHeight={gridHeight}
                    filterValue={filterValue}
                    queryResult={queryResult}
                    limit={limit}
                    activePage={activePage}
                    onCellClicked={onCellClicked}
                    />

                {/*--------- 페이징 -----------*/}
                <Paging 
                    total={queryResult && queryResult.data && queryResult.data.length}
                    limit={limit}
                    activePage={activePage}
                    onChangePage={onChangePage}
                    onChangeLimit={onChangeLimit}
                />
            </div>

            {pgmAddPop && <PgmAdd show={pgmAddPop} onHide={onHidePgmAddPop} />}
            {pgmUpdatePop && <PgmUpdate show={pgmUpdatePop} data={data} onHide={onHidePgmUpdatePop} />}
            {pgmUploadPop && <PgmUpload show={pgmUploadPop} onHide={() => setPgmUploadPop(false)} />}
        </>
    )
};
export default PgmList;