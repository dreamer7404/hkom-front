import React, {useEffect, useMemo, useRef} from 'react';
import {Form} from 'rsuite';
import { AgGridReact } from 'ag-grid-react';
import { CONSTANTS } from '../../../../utils/constants';

const GridRequestState = ({gridHeight, filterValue, queryResult, limit, activePage}) => {

  const gridRef = useRef();

  const columnDefs = [
        {
            checkboxSelection: true,
            headerCheckboxSelection: true,
            spanHeaderHeight: true,
            width:45,
            maxWidth:45,
            minWidth:45
        },
        {
            headerName: '발간번호',
            field: 'printNum',
            spanHeaderHeight: true,
          },
        {
          headerName: '차종',
          children: [
            { headerName:'차종코드', field: 'carCd',},
            { headerName:'차종명', field: 'carName' },
            { headerName:'연식', field: 'monthYear' },
          ],
        },
        {
          headerName: '언어',
          children: [
            { headerName:'지역', field: 'region'},
            { headerName:'언어코드', field: 'langCd' },
            { headerName:'언어명', field: 'langName'},
          ],
        },
        {
            headerName: '발주일',
            field: 'date',
            spanHeaderHeight: true,
          },
        {
          headerName: '납품일',
          field: 'date2',
          spanHeaderHeight: true,
        },
        {
          headerName: '인쇄 부수',
          field: 'printTot',
          spanHeaderHeight: true,
        },
        {
          headerName: '잔여 부수',
          field: 'printRemain',
          spanHeaderHeight: true,
        },  
        {
          headerName: '완료 부수',
          field: 'PrintCom',
          spanHeaderHeight: true,
          cellRenderer:'inputComponent'
        }
    ]

    const defaultColDef = useMemo(() => {
        return {
            initialWidth: 90,
            sortable: true,
            resizable:true,
        };
    }, []);

    const onFirstDataRendered = (params) => {
        params.api.sizeColumnsToFit();
    };

    const inputComponent = (props) => {
        return (
          <div className="grid-form-wrap">
            <Form.Control size="sm" type="text" placeholder="" defaultValue={props.value} />
          </div>
        );
    }


  useEffect(()=>{
    if(queryResult.status === 'loading' && gridRef && gridRef.current && gridRef.current.api){
        gridRef.current.api.showLoadingOverlay();
    }
  },[queryResult]);

  useEffect(()=> {
    if(gridRef && gridRef.current && gridRef.current.api){
      gridRef.current.api.setQuickFilter(filterValue);
    }
  },[filterValue]);

  useEffect(()=> {
    if(gridRef && gridRef.current && gridRef.current.api){
      gridRef.current.api.paginationGoToPage(activePage-1);
    }
  },[activePage]);


  return(
    <Form>
      <div className="ag-theme-alpine" style={{height: gridHeight, transition:'all ease .3s'}}>
        <AgGridReact
            ref={gridRef} 
            rowData={queryResult && queryResult.data} 
            columnDefs={columnDefs}
            defaultColDef={defaultColDef}

            // paging
            pagination={true}
            paginationPageSize={limit} //
            suppressPaginationPanel={true} 
            // onPaginationChanged={onPaginationChanged}

            //  filter
            cacheQuickFilter={true}

            // overlay
            overlayLoadingTemplate={CONSTANTS.gridLoading}
            overlayNoRowsTemplate={CONSTANTS.gridNoRows}

            frameworkComponents={{
                inputComponent,
            }}
            
            rowSelection={'multiple'}
            suppressRowClickSelection= {true} 
            
            onFirstDataRendered={onFirstDataRendered}
            suppressSizeToFit={true}    
            onGridSizeChanged={onFirstDataRendered}    
            >
        </AgGridReact>
        
      </div>
    </Form>
  )


};
export default GridRequestState;