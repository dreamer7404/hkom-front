import React, {useEffect, useMemo, useRef} from 'react';
import { AgGridReact } from 'ag-grid-react';
import { CONSTANTS } from '../../../../utils/constants';

const GridRequestState = ({gridHeight, filterValue, queryResult, limit, activePage}) => {

  const gridRef = useRef();

  const columnDefs = [
        {
          headerName: '차종',
          children: [
            { headerName:'차종코드', field: 'carCd',},
            { headerName:'차종명', field: 'carName' },
            { headerName:'연식', field: 'monthYear' },
          ],
        },
        {
          headerName: '언어',
          children: [
            { headerName:'지역', field: 'region'},
            { headerName:'언어코드', field: 'langCd' },
            { headerName:'언어명', field: 'langName'},
          ],
        },
        {
            headerName: '발간번호',
            field: 'receiveing1',
            spanHeaderHeight: true,
        },
        {
            headerName: '입고상태',
            field: 'receiveing2',
            spanHeaderHeight: true,
        },
        {
            headerName: '입고Box',
            field: 'receiveing3',
            spanHeaderHeight: true,
          },
        {
          headerName: '입고수량',
          field: 'receiveing4',
          spanHeaderHeight: true,
        },
        {
            headerName: '과부족',
            field: 'receiveing5',
            spanHeaderHeight: true,
          },
        {
          headerName: '입고일',
          field: 'receiveing6',
          spanHeaderHeight: true,
        },  
        {
          headerName: '담당자',
          field: 'receiveing7',
          spanHeaderHeight: true,
        }
    ]

    const defaultColDef = useMemo(() => {
        return {
            initialWidth: 90,
            sortable: true,
            resizable:true,
        };
    }, []);

  const onFirstDataRendered = (params) => {
      params.api.sizeColumnsToFit();
  };

  useEffect(()=>{
    if(queryResult.status === 'loading' && gridRef && gridRef.current && gridRef.current.api){
        gridRef.current.api.showLoadingOverlay();
    }
  },[queryResult]);

  useEffect(()=> {
    if(gridRef && gridRef.current && gridRef.current.api){
      gridRef.current.api.setQuickFilter(filterValue);
    }
  },[filterValue]);

  useEffect(()=> {
    if(gridRef && gridRef.current && gridRef.current.api){
      gridRef.current.api.paginationGoToPage(activePage-1);
    }
  },[activePage]);


  return(
      <div className="ag-theme-alpine" style={{height: gridHeight, transition:'all ease .3s'}}>
        <AgGridReact
            ref={gridRef} 
            rowData={queryResult && queryResult.data} 
            columnDefs={columnDefs}
            defaultColDef={defaultColDef}

            // paging
            pagination={true}
            paginationPageSize={limit} //
            suppressPaginationPanel={true} 
            // onPaginationChanged={onPaginationChanged}

            //  filter
            cacheQuickFilter={true}

            // overlay
            overlayLoadingTemplate={CONSTANTS.gridLoading}
            overlayNoRowsTemplate={CONSTANTS.gridNoRows}

            onFirstDataRendered={onFirstDataRendered}
            suppressSizeToFit={true}    
            onGridSizeChanged={onFirstDataRendered}    
            >
        </AgGridReact>
    </div>
  )


};
export default GridRequestState;