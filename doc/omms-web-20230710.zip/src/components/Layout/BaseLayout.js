// react
import React, {useEffect} from 'react';

// react-bootstrap
import {  CustomProvider } from 'rsuite';
import ko from 'rsuite/locales/ko_KR'; // => rsuite/cjs/locales/ko_KR.js

// components
import Header from "./Header";
import Section from './Section';

const BaseLayout = ({children}) => {

    useEffect(() => {
        console.log('BaseLayout...')
    },[]);

    return (
        <CustomProvider locale={ko}>
        <div id="wrapper" className="hd">
            <Header  />
            {/* <SitePath  /> */}
            <Section children={children} />
            {/* <Footer /> */}
        </div>
        </CustomProvider>
    );
};
export default BaseLayout;