// react
import React, {useState, useEffect, useCallback,useRef} from 'react';
import {Col, Button, Collapse} from 'react-bootstrap';
import SearchIcon from '@rsuite/icons/Search';
import { Input, InputGroup, Form } from 'rsuite';
import Total from '../../../Common/Total';
//--------------  서버데이터용 필수 -------------------------------
import { useQuery,useMutation} from 'react-query';
import { API, CONSTANTS } from '../../../../utils/constants';
import useStore from '../../../../utils/store';
import VehlType from '../../../Search/VehlType';
import Lang from '../../../Search/Lang';
import { getData,postData } from '../../../../utils/async';
//--------------// 서버데이터용 필수 -------------------------------

import GridPrintPageList from '../_Grid/GridPrintPageList';
import Paging from '../../../Common/Paging';
import { CustomInputGroup } from '../../../Common/CustomInputGroup';

import PrintPageAdd from '../Popup/PrintPageAdd';
import PrintPageUpdate from '../Popup/PrintPageUpdate';
import { confirmAlert } from 'react-confirm-alert'; // Import
import ConfirmAlert from '../../../Common/ConfirmAlert';
import {ArrowDownLine, ArrowUpLine} from '@rsuite/icons';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faFileExcel,faPrint } from '@fortawesome/free-solid-svg-icons'
const PrintPageList = () => {
    
    //------------------- 필수 공통 ------------------------------
    const gridRef = useRef();
    const [open, setOpen] = useState(true); // 조건창 열기/닫기
    const {keyword } = useStore();  // 조회키워드 가져오기
    const [detailParam, setDetailParam] = useState(); //상세컬럼
    const [activePage, setActivePage] = useState(1);    // 페이지번호
    const [limit, setLimit] = useState(50);             // 페이지행수
    const [filterValue, setFilterValue] = useState(''); // 필터값
    

    const onChangePage = val => {
        setActivePage(val);
    };
    const onChangeLimit = val => {
        setLimit(val);
    };
    useEffect(()=>{
        onChangePage(1); // 페이지번호 리셋
    },[keyword]);

    // 필터
    const onFilterTextBoxChanged = useCallback((e) => {
        setFilterValue(e.target.value);
    }, []);

    // 검색창 열기/닫기 > 페이지네이션 여부에 따라 +-20px
    const [gridHeight, setGridHeight] = useState(575);
    const gridExpand = () =>{
        setOpen(!open);
        if(open){
            setTimeout(() => setGridHeight(650), 250);
        }else{
            setGridHeight(575)
        }
    }
    //-------------------// 필수 공통 ------------------------------

    const param = {
        dlExpdPdiCd: keyword.dlExpdPdiCd,
        qltyVehlCd: keyword.qltyVehlCd==="ALL"?"":keyword.qltyVehlCd,
        mdlMdyCd: keyword.mdlMdyCd,
        dlExpdRegnCd: keyword.dlExpdRegnCd==="ALL"?"":keyword.dlExpdRegnCd,
        langCd: keyword.langCd==="ALL"?"":keyword.langCd,
    }
    const queryResult = useQuery([API.prntPageMgmts, param], () => getData(API.prntPageMgmts, param),{
        staleTime: 0,
    });

    // //  requestState 조회
    // const queryResult = useQuery(["PrintPageList"], () => {return rowData});

    // 셀 클릭
    const onCellClicked = e => {
        if(e.column.colId === 'qltyVehlNm'){
            setDetailParam({
                newPrntPbcnNo : e.data.newPrntPbcnNo,
                lrnkCd : e.data.lrnkCd,
            })
            setPrintPageUpdatePop(true)
        }
    };
    const prntPageDelete = useMutation((params => postData(API.prntPageMgmt, params, CONSTANTS.delete)),{
        onSuccess: res => {
           if(res>0){
                confirmAlert({
                    closeOnClickOutside: false,
                    customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}   title={"알림"}
                    msg={"삭제 완료되었습니다."}   />
                    
                });
           
           }else{
                confirmAlert({
                    closeOnClickOutside: false,
                    customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}   title={"알림"}
                    msg={"에러가 발생했습니다 관리자에게 문의해주세요."}   />
                    
                });
           }
           queryResult.refetch();
        }
    });
    const handleSubmit = () => {
       let checkedItems = gridRef.current.api.getSelectedRows();
       if(checkedItems.length===0){
        confirmAlert({
            closeOnClickOutside: false,
            customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}   title={"알림"}
            msg={"최소 한 개의 데이터를 선택해주세요."} 
            
            />
            
        });
        return
       }

        
        confirmAlert({
            closeOnClickOutside: false,
            customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}   title={"알림"}
            msg={"선택하신 항목을 삭제하시겠습니까?"} 
            
            onOk={onDelete}  />
            
        });
        
    };
    const onDelete = () => {
        console.log('grid',gridRef.current.api.getSelectedRows())
        const pageArr = {
            pageArr : gridRef.current.api.getSelectedRows()
        }

        prntPageDelete.mutate(pageArr);

    }
    const [printPageAddPop, setPrintPageAddPop] = useState(false);
    const [printPageUpdatePop, setPrintPageUpdatePop] = useState(false);

    // 조회버튼
    const onSearch = () => {
        queryResult.refetch(); // 수동쿼리실행
    };
    const onHideAdd = () => {
        setPrintPageAddPop(false)
        setTimeout(() => queryResult.refetch(), 100);
    }

    const onHideUpdate = () => {
        setPrintPageUpdatePop(false)
        setTimeout(() => queryResult.refetch(), 100);
    }
    useEffect(()=>{
        console.log("detailParam",detailParam);
    },[detailParam])
    return (
        <>
            <div className="search-area">
                <Collapse in={open}>
                    <div className="form" id="example-collapse-text">
                        <div className="search-group">
                            <div className="row">
                                <Col sm={4} className="" >
                                    <VehlType  />
                                </Col>
                                <Col sm={4} className="" >
                                    <Lang  />
                                </Col>
                            </div>

                            <div className="search-btn-wrap">
                                <Button className="btn-search" variant="outline-primary" size="sm" onClick={onSearch}><SearchIcon />조회</Button>
                            </div>
                        </div>
                    </div>
                </Collapse>
                <Button size="sm" variant="outline-dark" className="search-control" aria-controls="example-collapse-text" 
                    aria-expanded={open} onClick={gridExpand}>
                    {/* <span className={open === true ? "search-area-close" : "search-area-open"}>{open === true ? CONSTANTS.closeSearch : CONSTANTS.openSearch}</span> */}
                    {open ? <span className="search-area-close"><ArrowUpLine style={{marginRight: '5px', fontSize: '2em'}} />{CONSTANTS.closeSearch}</span> :
                    <span className="search-area-open"><ArrowDownLine style={{marginRight: '5px', fontSize: '2em'}} />{CONSTANTS.openSearch}</span>}
                </Button>
            </div>
            
            <div className="grid-wrap">
                <div className="grid-btn-wrap">
                    <div className="left-align">
                        {/*--------- 필터 -----------*/}
                        <CustomInputGroup size="sm"   onInput={onFilterTextBoxChanged} />
                    </div>
                    <div className="right-align">
                        {/*--------- 버튼 -----------*/}
                        <Button variant="outline-secondary" size="sm" onClick={() => setPrintPageAddPop(true)}>인쇄페이지 등록</Button>{' '}
                        <Button variant="outline-secondary" size="sm"  onClick={handleSubmit}>삭제</Button>{' '}
                        <Button variant="outline-success btn-excel" size="sm" ><FontAwesomeIcon icon={faFileExcel}/>{CONSTANTS.excelDownload}</Button>{' '}
                    </div>
                </div>
                {/*--------- Grid -----------*/}
                <GridPrintPageList 
                    gridRef = {gridRef}
                    gridHeight={gridHeight}
                    filterValue={filterValue}
                    queryResult={queryResult}
                    limit={limit}
                    activePage={activePage}
                    onCellClicked={onCellClicked}
                    />

                {/*--------- 페이징 -----------*/}
                <Paging 
                    total={queryResult && queryResult.data && queryResult.data.prntPageList.length}
                    limit={limit}
                    activePage={activePage}
                    onChangePage={onChangePage}
                    onChangeLimit={onChangeLimit}
                />
            </div>

            {/* 팝업 */}
            {printPageAddPop && <PrintPageAdd show={printPageAddPop} onHide={onHideAdd}  />}
            {printPageUpdatePop && <PrintPageUpdate show={printPageUpdatePop} onHide={onHideUpdate}  data={detailParam}/>}
        </>
    )
};
export default PrintPageList;