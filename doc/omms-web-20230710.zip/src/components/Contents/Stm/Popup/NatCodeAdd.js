import React, {useState, useRef} from 'react';
import {Button, Modal, Table, Row, Col} from 'react-bootstrap';
import {Form, SelectPicker,Schema} from 'rsuite';
import { API, CONSTANTS } from '../../../../utils/constants';
import { useQuery,useMutation} from 'react-query';
import { getData,postData } from '../../../../utils/async';
import { escapeCharChange} from '../../../../utils/commUtils';
import { confirmAlert } from 'react-confirm-alert'; // Import
import ConfirmAlert from '../../../Common/ConfirmAlert';
import CustomModal from '../../../Common/CustomModal';
const { StringType} = Schema.Types;
const model = Schema.Model({
    dlExpdNatCd: StringType().isRequired('국가코드를 입력해주세요.').rangeLength(1, 3, '1-3자로 입력해주세요'),
    natNm: StringType().isRequired('국가명을 입력해주세요.'),
    dlExpdRegnCd: StringType().isRequired('지역을 선택해주세요.'),
});
const NatCodeAdd = ({show, onHide}) => {
    const containerRef = useRef();
    
    const formRef = useRef();
    const [formError, setFormError] = useState({});
    const [formValue, setFormValue] = useState({
        dlExpdNatCd : '',
        natNm : '',
        dlExpdRegnCd : '',
        useYn:'',                   // 사용유무
    }); 

    const paramsCo = {dlExpdGCd: CONSTANTS.grpCdRegn};
    const regnCombo = useQuery([API.codeCombo,paramsCo], () => getData(API.codeCombo,paramsCo)) 
    const handleSubmit = () => {
        if (!formRef.current.check()) { //validation chk
            return;
        }
        
        
        confirmAlert({
            closeOnClickOutside: false,
            customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}   title={"알림"}
            msg={"입력하신 내용으로 저장하시겠습니까?"} 
            
            onOk={onOk}  />
            
        });
        
        
    }; 
    const natMstsSave = useMutation((params => postData(API.natlMst, params, CONSTANTS.insert)),{
        onSuccess: res => {
            if(res===999){
                confirmAlert({
                    closeOnClickOutside: false,
                    customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}   title={"알림"}
                    msg={"중복된 국가코드가 있습니다."}   />
                    
                })
            }
           else if(res>0){
            confirmAlert({
                closeOnClickOutside: false,
                customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}   title={"알림"}
                msg={"저장이 완료되었습니다."}   />
                
            });
           }
           else{
            confirmAlert({
                closeOnClickOutside: false,
                customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}   title={"알림"}
                msg={"에러가 발생했습니다 관리자에게 문의해주세요."}   />
                
            });
           }
           onHide();
        }
    });


    const onOk = () => {
       
        natMstsSave.mutate(formValue);
    }


    
    return (
        <>
            <Form
                ref={formRef}
                checkTrigger="change"
                onChange={setFormValue}
                onCheck={setFormError}
                formValue={formValue}
                model={model}>

                <CustomModal open={show} 
                        title={'국가코드 등록'}
                        size='md'
                        // handleOk={handleSubmit}
                        handleCancel={onHide} >
                        
                            <Table className="tbl-hor" bordered>
                                <colgroup>
                                    <col style={{width:'30%'}}></col>
                                    <col style={{width:''}}></col>
                                </colgroup>
                                <tbody>
                                    <tr>
                                        <th className="essen">국가코드</th>
                                        <td>
                                            <Form.Control size="sm" type="text" name='dlExpdNatCd'/> 
                                        </td>
                                    </tr>
                                    <tr>
                                        <th className="essen">국가명</th>
                                        <td>
                                            <Form.Control size="sm" type="text" name='natNm'/> 
                                        </td>
                                    </tr>
                                    <tr>
                                        <th className="essen">지역</th>
                                        <td>
                                        {regnCombo.isSuccess &&
                                                    <Form.Control container={()=> containerRef.current}  name="dlExpdRegnCd" size="sm" style={{zIndex: 0}} 
                                                        
                                                        placeholder={'선택'}
                                                        defaultValue={''}
                                                        accepter={SelectPicker} 
                                                        searchable={false}
                                                        cleanable={false}
                                                        data={regnCombo.isFetched && regnCombo.data}
                                                        
                                                    ></Form.Control>
                                                }
                                        </td>
                                    </tr>
                                </tbody>
                            </Table>
                        

                            <div className='modal-footer'>
                            <Button variant="light" size="md" onClick={onHide}>취소</Button>
                            <Button variant="primary" size="md" onClick={handleSubmit} >저장</Button>
                        </div>

                </CustomModal>
            </Form>

        </>
    );

};
export default NatCodeAdd;