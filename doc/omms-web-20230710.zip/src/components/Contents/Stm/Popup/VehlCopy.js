import React,{useState,useEffect} from 'react';
import {Button, Modal, Table} from 'react-bootstrap';
import {Form, SelectPicker } from 'rsuite';
import { API } from '../../../../utils/constants';
import { useQuery} from 'react-query';
import { getData } from '../../../../utils/async';
import { escapeCharChange } from '../../../../utils/commUtils';
import CustomModal from '../../../Common/CustomModal';

const VelhCopy = ({show, onHide,data,langCopyEvent}) => {

    const [copyParam , setCopyParam] = useState();
    


    const param = {qltyVehlCd :data }

    const vehlCombo = useQuery([API.langMgmtsCopy, param], () => getData(API.langMgmtsCopy, param), {
        select: data => data.map((item) => ({
             label: escapeCharChange(item.qltyVehlNm),
              value: item.qltyVehlCd+','+item.mdlMdyCd,
        }))
    });

    const queryResult =  useQuery([API.langMgmts, copyParam], () => getData(API.langMgmts, copyParam),{

        enabled:false
        
    });
   
    


    const searchData = () =>{
        queryResult.refetch();
        
    }
    useEffect(()=>{
        if(queryResult.isSuccess){
            langCopyEvent(queryResult.data);
        }

    },[queryResult.status])

    const onChangeVehlCombo = val => {
        if(val && val!=null){
            
            let test = val.split(',');
            
            setCopyParam({
                qltyVehlCd :test[0],
                mdlMdyCd : test[1]
            })
            
        }
    };

    useEffect(()=>{
        if(copyParam){
            searchData(); 
        }

        
    },[copyParam])
    return (
        <>
          <Form>
                        <CustomModal open={show} 
                            title={'차종복사'}
                            size='md'
                            // handleOk={handleSubmit}
                            handleCancel={onHide} 
                        
                        >
                            <Table className="tbl-hor" bordered>
                                <tbody>
                                    <tr>
                                        <th className="essen">대상차종</th>
                                        <td>
                                        <SelectPicker size="sm" 
                                            placeholder={'선택'}
                                            defaultValue={''}
                                            accepter={SelectPicker} 
                                            searchable={false}
                                            cleanable={false}
                                             data={vehlCombo && vehlCombo.data ? vehlCombo.data : []}  
                                             onChange={onChangeVehlCombo}

                                        />
                                        </td>
                                    </tr>
                                </tbody>
                            </Table>
                            <div className='modal-footer'>
                                <Button variant="light" size="md" onClick={onHide}>취소</Button>
                                <Button variant="primary" size="md" onClick={onHide} >저장</Button>
                            </div>
                        </CustomModal>
            </Form>
        </>
    );

};
export default VelhCopy;