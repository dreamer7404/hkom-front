import React from 'react';
import {Button, Modal, Table} from 'react-bootstrap';
import { Input, InputGroup, Form, SelectPicker, Schema,Notification,useToaster,TagGroup,Tag } from 'rsuite';
import { escapeCharChange } from '../../../../utils/commUtils';
import { useQuery,useMutation} from 'react-query';
import {CONSTANTS, API } from '../../../../utils/constants';
import { getData, postData } from '../../../../utils/async';
import { useEffect } from 'react';
import { confirmAlert } from 'react-confirm-alert'; // Import
import ConfirmAlert from '../../../Common/ConfirmAlert';
import CustomModal from '../../../Common/CustomModal';
const { StringType, NumberType,  ArrayType, ObjectType } = Schema.Types;
const model = Schema.Model({
    
    mdlMdyCd: StringType().isRequired('연식을 입력해주세요.'),
    desmp1Cd : StringType().isRequired('시작월팩을 입력해주세요.'),
    defmp1Cd : StringType().isRequired('종료월팩을 입력해주세요.'),
    
});
const VehlMdyUpdate = ({show,data, onHide}) => {
const formRef = React.useRef();
const [formError, setFormError] = React.useState({});
const [formValue, setFormValue] = React.useState({
    qltyVehlCd: '',             // 차종코드
    mdlMdyCd : '',
    dlExpdRegnCd : '',
    desmp1Cd: '',
    defmp1Cd : ''
    
}); 
const [delGbn , setDelGbn] = React.useState({});




const queryResult = useQuery([API.vehlMdyMgmt, data], () => getData(API.vehlMdyMgmt, data),{
    staleTime: 0,
});

useEffect(()=>{
    if(queryResult.isSuccess){
        console.log("queryResult.data",queryResult.data);
        const dataInfo = queryResult.data.detailInfo;
        setFormValue({
            qltyVehlCd: dataInfo.qltyVehlCd,             // 차종코드
            mdlMdyCd : dataInfo.mdlMdyCd,
            dlExpdRegnCd : dataInfo.dlExpdRegnCd,
            desmp1Cd: dataInfo.desmp1Cd,
            defmp1Cd :dataInfo.defmp1Cd
        })
        setDelGbn(queryResult.data.maxInfoYn);
    }
},[queryResult.status])




const handleSubmit = () => { //신규 연식 등록 누를경우
    if (!formRef.current.check()) { //validation chk
        return;
    }
    confirmAlert({
        closeOnClickOutside: false,
        customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}  msg={"입력하신 내용으로 저장하시겠습니까?"} onOk={onOk} />
    });
};
const onOk = () => {
    //연식 등록
    mdyMgmtMutate.mutate(formValue);
}


//차종코드 저장
const mdyMgmtMutate = useMutation((params => 
    
    postData(API.vehlMdyMgmt, params, CONSTANTS.update)),{
        
    onSuccess: res => {
        
        if(res.msg=='ok'){
           confirmAlert({
            closeOnClickOutside: false,
            customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}   title={"알림"}
            msg={" 저장이 완료되었습니다."}   />
            
        });
        }else if(res.msg=='err2'){//현 시작월팩이  이전 종료월팩 보다 작은경우 알림
           
            confirmAlert({
                closeOnClickOutside: false,
                customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}   title={"알림"}
                msg={"중복된 기간의 시작월팩이 있습니다 다시 확인해주세요."}   />
            
            });
        }else{
            confirmAlert({
                closeOnClickOutside: false,
                customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}   title={"알림"}
                msg={" 에러가 발생했습니다."}   />
            });
        }
            
            onHide(true); // 창닫기 & refetch
        
    }
});

const handleDelSubmit=() =>{
    confirmAlert({
        closeOnClickOutside: false,
        customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}  msg={"삭제하시겠습니까?"} onOk={onDelOk} />
    });
}

const onDelOk = () => {
    //연식 등록
    mdyMgmtDelMutate.mutate(formValue);
}

const mdyMgmtDelMutate = useMutation((params => 
    
    postData(API.vehlMdyMgmt, params, CONSTANTS.delete)),{
        
    onSuccess: res => {
        
        if(res.msg=='ok'){
           confirmAlert({
            closeOnClickOutside: false,
            customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}   title={"알림"}
            msg={" 삭제가 완료되었습니다."}   />
            
        });
        }else{
            confirmAlert({
                closeOnClickOutside: false,
                customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}   title={"알림"}
                msg={" 에러가 발생했습니다."}   />
            });
        }
            
            onHide(true); // 창닫기 & refetch
        
    }
});


useEffect(()=>{
    console.log("formValue", formValue);
    },[formValue])




    return (
        <>
            <Form
                ref={formRef}
                checkTrigger="change"
                onChange={setFormValue}
                onCheck={setFormError}
                formValue={formValue}
                model={model}>
                  <CustomModal open={show} 
                        title={'차종연식 상세/수정'}
                        size='md'
                        // handleOk={handleSubmit}
                        handleCancel={onHide} 
                        // handleRemove={handleCustom}
                        >
                            <Table className="tbl-hor" bordered>
                                <colgroup>
                                    <col style={{width:'30%'}}></col>
                                    <col style={{width:''}}></col>
                                </colgroup>
                                <tbody>
                                    <tr>
                                        <th>차종</th>
                                        <td>
                                            {queryResult.data && escapeCharChange(queryResult.data.detailInfo.qltyVehlNm)}
                                        </td>
                                    </tr>
                                    <tr>
                                        <th>지역</th>
                                        <td>
                                            {queryResult.data && escapeCharChange(queryResult.data.detailInfo.dlExpdPrvsNm)}
                                        </td>
                                    </tr>
                                    <tr>
                                        <th className="essen">시작월팩</th>
                                        <td>
                                            <Form.Control name = "desmp1Cd" size="sm" type="text"/> 
                                        </td>
                                    </tr>
                                    <tr>
                                        <th>종료월팩</th>
                                        <td>
                                            <Form.Control name = "defmp1Cd" size="sm" type="text" /> 
                                        </td>
                                    </tr>
                                    <tr>
                                        <th className="essen">연식</th>
                                        <td>
                                            <Form.Control name = "mdlMdyCd" size="sm" type="text"/> 
                                        </td>
                                    </tr>
                                </tbody>
                            </Table>

                            <div className='modal-footer'>
                                <Button variant="light" size="md" onClick={onHide}>취소</Button>
                                {delGbn && delGbn==='Y'&&<Button variant="outline-danger" size="md" onClick={handleDelSubmit}>삭제</Button>}
                                <Button variant="primary" size="md" onClick={handleSubmit} >저장</Button>
                            </div>
                            </CustomModal>
            </Form>

        </>
    );

};
export default VehlMdyUpdate;