// react
import React from 'react';
import {Button, Card } from "react-bootstrap";
import {Form} from 'rsuite';
import RemindOutlineIcon from '@rsuite/icons/RemindOutline';
import { Link } from 'react-router-dom';
import useStore from '../../../utils/store';

const ErrorPage = () => {

    const { svrErrCd, svrErrMsg, loginUrl } = useStore();

    return (
        <>
           <div className="error-wrap">
                <Form>
                    <Card className="shadow">
                        <Card.Body>
                            <RemindOutlineIcon />
                            <h4>
                                <p className="error-type">401 Error</p>
                                {Number(svrErrCd) === 2 && '다른브라우저에서 정보를 요청했습니다.(' + svrErrMsg + ')'}
                                {Number(svrErrCd) === 3 && '사용시간내에 사용이 없었습니다.'}
                                {Number(svrErrCd) === 4 && '토큰정보가 무효합니다.'}
                                {Number(svrErrCd) === 5 && '토큰이 만료되었습니다.'}
                                {Number(svrErrCd) === 6 && '사용권한이 없는 요청입니다.(' + svrErrMsg + ')'}
                            </h4>
                            <div className="button-wrap">
                                <Link to={loginUrl}><Button variant="secondary">로그인 페이지</Button></Link>
                            </div>
                        </Card.Body>
                    </Card>
                </Form>
           </div>
        </>
    )
};
export default ErrorPage;