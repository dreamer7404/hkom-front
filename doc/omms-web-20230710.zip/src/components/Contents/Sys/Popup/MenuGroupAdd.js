import React from 'react';
import {Button, Modal, Table} from 'react-bootstrap';
import {Schema, Form, SelectPicker,  Notification, useToaster} from 'rsuite';
import { AgGridReact } from 'ag-grid-react';

//--------------  서버데이터용 필수 -------------------------------
import { useQuery, useMutation} from 'react-query';
import { getData, postData } from '../../../../utils/async';
import { API, CONSTANTS } from '../../../../utils/constants';
import CustomModal from '../../../Common/CustomModal';
import { confirmAlert } from 'react-confirm-alert'; // Import
import ConfirmAlert from '../../../Common/ConfirmAlert';
//--------------// 서버데이터용 필수 -------------------------------

const { StringType } = Schema.Types;
const model = Schema.Model({
    pgmNm: StringType().isRequired('그룹명을 입력해주세요.').rangeLength(2, 20, '2-20자로 입력해주세요'),
    pgmPathAdr : StringType().isRequired('URL을 입력해주세요.'),
    useYn: StringType().isRequired('사용유무를 선택해주세요.'),
});

const MenuGruopAdd = ({show, onHide}) => {

    // Form 정의
    const formRef = React.useRef();
    const [formError, setFormError] = React.useState({});
    const [formValue, setFormValue] = React.useState({
        pgmNm: '',     // 아이디
        pgmPathAdr : '', //URL
        useYn:'Y',         // 사용유무
    });

    // 저장버튼 클릭
    const handleSubmit = () => {
        if (!formRef.current.check()) { //validation chk
            return;
        }
        confirmAlert({
            closeOnClickOutside: false,
            customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}   title={"알림"}
            msg={"입력하신 내용으로 저장하시겠습니까?"} 
            onOk={onOk}  />
        });
    };


    const onOk = () => {
        menuGrpAddSave.mutate(formValue);
    }


    const menuGrpAddSave = useMutation((params => postData(API.pgmMgmtGrp, params, CONSTANTS.insert)),{
        onSuccess: res => {
           if(res>0){
                confirmAlert({
                    closeOnClickOutside: false,
                    customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}   title={"알림"}
                    msg={"저장이 완료되었습니다."}   />
                    
                });
           }else{
                confirmAlert({
                    closeOnClickOutside: false,
                    customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}   title={"알림"}
                    msg={"에러가 발생했습니다 관리자에게 문의해주세요."}   />
                });
           }
           onHide();
        }
    });

    return (
        <>
            <Form
            ref={formRef}
            checkTrigger="change"
            onChange={setFormValue}
            onCheck={setFormError}
            formValue={formValue}
            model={model}>
            
                    <CustomModal open={show} 
                        title={'메뉴그룹 등록'}
                        size='md'
                        handleCancel={onHide} 
                    >
                            <Table className="tbl-hor" bordered>
                                <colgroup>
                                    <col style={{width:'30%'}}></col>
                                    <col style={{width:''}}></col>
                                </colgroup>
                                <tbody>
                                    <tr>
                                        <th className="essen">그룹명</th>
                                        <td colSpan="3">
                                            <Form.Control name="pgmNm" size="sm" type="text"/> 
                                        </td>
                                    </tr>
                                    <tr>
                                        <th className="essen">URL</th>
                                        <td colSpan="3">
                                            <Form.Control size="sm" name = "pgmPathAdr" type="text"/> 
                                        </td>
                                    </tr>
                                    <tr>
                                        <th className="">사용여부</th>
                                        <td colSpan="3">
                                            <Form.Control name="useYn" size="sm"   
                                                    placeholder={'선택'}
                                                    defaultValue={''}
                                                    accepter={SelectPicker} 
                                                    searchable={false}
                                                    cleanable={false}
                                                    data={[
                                                        {label: '사용', value: 'Y'},
                                                        {label: '미사용', value: 'N'},
                                                    ]}
                                            ></Form.Control>
                                        </td>
                                    </tr>
                                </tbody>
                            </Table>
                        <div className='modal-footer'>
                            <Button variant="light" size="md" onClick={onHide}>취소</Button>
                            <Button variant="primary" size="md" onClick={handleSubmit} >저장</Button>
                        </div>
                </CustomModal>
            </Form>
        </>
    );

};
export default MenuGruopAdd;