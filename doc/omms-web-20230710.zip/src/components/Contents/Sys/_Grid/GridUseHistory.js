import React, {useEffect, useMemo, useRef} from 'react';
import { AgGridReact } from 'ag-grid-react';
import { CONSTANTS } from '../../../../utils/constants';
import { escapeCharChangeForGrid, escapeCharChange} from '../../../../utils/commUtils';

const GridUseHistory = ({gridRef, gridHeight, queryResult, onSortChanged}) => {


  const columnDefs = [
    {
      headerName: '순번',
      field: 'useLogSn',
      minWidth:'30'
    },
      {
        headerName: '사용일시',
        field: 'useDtm',
        minWidth:'180',
        cellRenderer: props => escapeCharChange(props.value) 
      }, 
      {
        headerName: '사용자ID',
        field: 'useEeno',
        maxWidth:'200'
      },
        {
          headerName: '메뉴',
          field: 'pgmNm',
          maxWidth:'200'
        },
        
        {
          headerName: 'API URL',
          field: 'apiUrl',
          maxWidth:'200',
          cellStyle:() => ({textAlign: 'left'}),
        },
        {
          headerName: 'API 설명',
          field: 'apiNm',
          maxWidth:'200'
        },
        {
          headerName: '종류',
          field: 'cmd',
          minWidth:'80',
        },
        {
          headerName: 'class명',
          field: 'classNm',
          minWidth:'180',
          cellStyle:() => ({textAlign: 'left'}),
        },
        {
          headerName: 'method명',
          field: 'methodNm',
          minWidth:'180',
          cellStyle:() => ({textAlign: 'left'}),
        },
       
        {
          headerName: '소요시간(ms)',
          field: 'processTime',
          maxWidth:'200'
        },
        
       
        
  ]

  const defaultColDef = useMemo(() => {
      return {
          initialWidth: 90,
          sortable: true,
          resizable:true,
          minWidth:70
      };
  }, []);

  const onFirstDataRendered = (params) => {
      params.api.sizeColumnsToFit();
  };

  useEffect(()=>{
    if(queryResult.status === 'loading' && gridRef && gridRef.current && gridRef.current.api){
        gridRef.current.api.showLoadingOverlay();
    }
  },[queryResult]);

  // useEffect(()=> {
  //   if(gridRef && gridRef.current && gridRef.current.api){
  //     gridRef.current.api.setQuickFilter(filterValue);
  //   }
  // },[filterValue]);

  // useEffect(()=> {
  //   if(gridRef && gridRef.current && gridRef.current.api){
  //     gridRef.current.api.paginationGoToPage(activePage-1);
  //   }
  // },[activePage]);


  return(
      <div className="ag-theme-alpine" style={{height: gridHeight, transition:'all ease .3s'}}>
        <AgGridReact
            ref={gridRef} 
            rowData={queryResult && queryResult.data} 
            columnDefs={columnDefs}
            defaultColDef={defaultColDef}

            // paging
            // pagination={true}
            // paginationPageSize={limit} //
            // suppressPaginationPanel={true} 
            // onPaginationChanged={onPaginationChanged}

            //  filter
            // cacheQuickFilter={true}

            // overlay
            overlayLoadingTemplate={CONSTANTS.gridLoading}
            overlayNoRowsTemplate={CONSTANTS.gridNoRows}

            onFirstDataRendered={onFirstDataRendered}
            suppressSizeToFit={true}    
            onGridSizeChanged={onFirstDataRendered}    

            onSortChanged={onSortChanged}
            >
        </AgGridReact>
    </div>
  )


};
export default GridUseHistory;