import React, {useEffect, useMemo, useRef} from 'react';
import { AgGridReact } from 'ag-grid-react';
import { CONSTANTS } from '../../../../utils/constants';
import { formatNumber, escapeCharChangeForGrid } from '../../../../utils/commUtils';

const GridProductPlan = ({gridHeight, filterValue, queryResult, limit, activePage, onCellClicked, gridRef}) => {

    // 수량 천단위 콤마 찍기 시작
    const currencyFormatter = (params) => {
        return formatNumber(params.value);
    };

    const columnDefs = [
        {
        headerName: '차종',
        children: [
            { headerName:'차종코드', field: 'qltyVehlCd',minWidth:70,cellRenderer:"escapeCharChangeForGrid",},
            { headerName:'차종명', field: 'qltyVehlNm',minWidth:130 ,cellRenderer:"escapeCharChangeForGrid",},
            { headerName:'연식', field: 'mdlMdyCd',minWidth:50 ,cellRenderer:"escapeCharChangeForGrid",},
        ],
        },
        {
        headerName: '언어',
        children: [
            { headerName:'지역', field: 'dlExpdPrvsNm',sortable: true,minWidth:70 ,cellRenderer:"escapeCharChangeForGrid", },
            { headerName:'언어코드', field: 'langCd',sortable: true,minWidth:70,cellRenderer:"escapeCharChangeForGrid",},
            { headerName:'언어명', field: 'langCdNm',sortable: true,minWidth:130,cellRenderer:"escapeCharChangeForGrid",},
        ],
        },
        {
            headerName: '국가코드',
            field: 'dlExpdNatCd',
            spanHeaderHeight: true,
            minWidth:70,
        },
        {
            headerName: '국가명',
            field: 'natNm',
            spanHeaderHeight: true,
            minWidth:130,
            cellRenderer:"escapeCharChangeForGrid", 
        },
        {
            headerName: '생산계획\n(2주)',
            field: 'prodPlan2week',
            spanHeaderHeight: true,
            minWidth:70,
            valueFormatter: currencyFormatter,
        },  
        {
            headerName: '단기계획\n(3일)',
            field: 'prodPlan3Day',
            spanHeaderHeight: true,
            minWidth:70,
            valueFormatter: currencyFormatter,
        },  
        {
            headerName: 'D+1',
            field: 'a01',
            spanHeaderHeight: true,
            valueFormatter: currencyFormatter,
        },
        {
            headerName: 'D+2',
            field: 'a02',
            spanHeaderHeight: true,
            valueFormatter: currencyFormatter,
        },
        {
            headerName: 'D+3',
            field: 'a03',
            spanHeaderHeight: true,
            valueFormatter: currencyFormatter,
        },
        {
            headerName: 'D+4',
            field: 'a04',
            spanHeaderHeight: true, 
            valueFormatter: currencyFormatter,
        },
        {
            headerName: 'D+5',
            field: 'a05',
            spanHeaderHeight: true,
            valueFormatter: currencyFormatter,
        },
        {
            headerName: 'D+6',
            field: 'a06',
            spanHeaderHeight: true,
            valueFormatter: currencyFormatter,
        },
        {
            headerName: 'D+7',
            field: 'a07',
            spanHeaderHeight: true,
            valueFormatter: currencyFormatter,
        },
        {
            headerName: 'D+8',
            field: 'a08',
            spanHeaderHeight: true,
            valueFormatter: currencyFormatter,
        },
        {
            headerName: 'D+9',
            field: 'a09',
            spanHeaderHeight: true,
            valueFormatter: currencyFormatter,
        },
        {
            headerName: 'D+10',
            field: 'a10',
            spanHeaderHeight: true,
            valueFormatter: currencyFormatter,
        },
        {
            headerName: 'D+11',
            field: 'a11',
            spanHeaderHeight: true,
            valueFormatter: currencyFormatter,
        },
        {
            headerName: 'D+12',
            field: 'a12',
            spanHeaderHeight: true,
            valueFormatter: currencyFormatter,
        },
        {
            headerName: 'D+13',
            field: 'a13',
            spanHeaderHeight: true,
            valueFormatter: currencyFormatter,
        },
        {
            headerName: 'D+14',
            field: 'a14',
            spanHeaderHeight: true,
            valueFormatter: currencyFormatter,
        }
    ];

  const defaultColDef = useMemo(() => {
      return {
          initialWidth: 90,
          sortable: true,
          resizable:true,
          minWidth:50,
      };
  }, []);

  const onFirstDataRendered = (params) => {
      params.api.sizeColumnsToFit();
  };

  useEffect(()=>{
    if(queryResult.status === 'loading' && gridRef && gridRef.current && gridRef.current.api){
        gridRef.current.api.showLoadingOverlay();
    }
  },[queryResult]);

  useEffect(()=> {
    if(gridRef && gridRef.current && gridRef.current.api){
      gridRef.current.api.setQuickFilter(filterValue);
    }
  },[filterValue]);

  useEffect(()=> {
    if(gridRef && gridRef.current && gridRef.current.api){
      gridRef.current.api.paginationGoToPage(activePage-1);
    }
  },[activePage]);


  return(
      <div className="ag-theme-alpine" style={{height: gridHeight, transition:'all ease .3s'}}>
        <AgGridReact
            ref={gridRef} 
            rowData={queryResult && queryResult.data} 
            columnDefs={columnDefs}
            defaultColDef={defaultColDef}

            // paging
            pagination={true}
            paginationPageSize={limit} //
            suppressPaginationPanel={true} 

            //  filter
            cacheQuickFilter={true}

            // overlay
            overlayLoadingTemplate={CONSTANTS.gridLoading}
            overlayNoRowsTemplate={CONSTANTS.gridNoRows}

            onFirstDataRendered={onFirstDataRendered}
            suppressSizeToFit={true}    
            onGridSizeChanged={onFirstDataRendered}    
            frameworkComponents={{
                escapeCharChangeForGrid
              }}
            >
        </AgGridReact>
    </div>
  )


};
export default GridProductPlan;