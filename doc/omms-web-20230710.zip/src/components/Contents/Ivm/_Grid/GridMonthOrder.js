import React, {useEffect, useMemo, useRef, useState} from 'react';
import { AgGridReact } from 'ag-grid-react';
import { CONSTANTS } from '../../../../utils/constants';
import { formatNumber } from '../../../../utils/commUtils';

const GridMonthOrder = ({mode, gridHeight, filterValue, queryResult, activePage, qltyVehlCd, gridRef}) => {
  
  // 수량 천단위 콤마 찍기
  const currencyFormatter = (params) => {
    return formatNumber(params.value);
  };  
 

  const numberValueParser = (params) => {
    return Number(params.newValue);
  };

  const [arrKeys, setArrKeys] = useState(['col0','col1','col2','col3','col4','col5','col6','col7','col8','col9','col10','col11','col12','col13']);
  const [hdName, setHdName] = useState({});
  const [total, setTotal] = useState({});
  const [total2, setTotal2] = useState([]);
  const [queryResultRealDatas, setQueryResultRealDatas] = useState([]);
  useEffect(() => {
    if(queryResult.isSuccess){
      setHdName(
        queryResult.isSuccess && queryResult.data.filter(item => {
          return item.langCd === 'MONTH'
        })[0]
      )
      setTotal(
        queryResult.isSuccess && queryResult.data.filter(item => {
          return item.langCd === 'TOTAL'
        })[0]
      )
      setTotal2(
        queryResult.isSuccess && queryResult.data.filter(item => {
          return item.langCd === 'TOTAL'
        })
      )
      setQueryResultRealDatas (
        queryResult.isSuccess && queryResult.data.filter(item => {
          return item.langCd !== 'TOTAL' && item.langCd !== 'MONTH'
        })
      )
    }
  },[queryResult.data])
  
  useEffect(() => {
  
    setColumnDefs([
      {
        headerName: '언어',
        children: [
          { headerName:'지역', field: 'regnNm', minWidth:90,
            colSpan: (params) => {
                const region = params.data.regnNm;
                if (region === 'TOTAL') {
                  // have all Russia age columns width 2
                  return 3;
                }else{
                  return 1;
                }
            },
            sortable: true,
          },
          { headerName:'언어코드', field: 'langCd', minWidth:80,
            sortable: true 
          },
          { headerName:'언어명', field: 'langCdNm' , minWidth:140,
            sortable: true
          },
        ],
      },]
      .concat(arrKeys.map((item, index) => {
        
        if (hdName['col'+index] !== null){
          return {
            headerName:hdName['col'+index],
            field:'col'+index,
            spanHeaderHeight: true,
            valueFormatter: currencyFormatter,
            minWidth:80,
          }
        }
      }).filter(item => {
        return item !== undefined && item !== null
      }))
      .concat(
        {
          headerName: '평균',
          valueGetter: (params) => {
            
            return arrKeys.filter((item, index) => {
              return hdName['col'+index] !== null
            }).map(item => {
              return Number(params.data[item])
            }).reduce((acc, cur, idx, all) => { return all.length === (idx+1) ? (acc+cur)/all.length : acc+=cur; }, 0)
            
          },
          valueFormatter: currencyFormatter,
          spanHeaderHeight: true,
          cellRenderer: 'agAnimateSlideCellRenderer',
          minWidth:80,
        },
      )
      )


      setColumnDefs2([
        {
          headerName: '언어',

          children: [
            { headerName:'지역', field: 'regnNm', minWidth:90,
              colSpan: (params) => {
                const region = params.data.regnNm;
                if (region === 'TOTAL') {
                  // have all Russia age columns width 2
                  return 3;
                  
                } else {
                  // all other rows should be just normal
                  return 1;
                }
              },
              cellRenderer: ShowCellRenderer,
              rowSpan:rowSpan,
              cellClass: (rowSpan) => {
                return rowSpan.data.flag >= 2 ? 'show-cell-total' : null;
              },
              sortable: true,
            },
            { 
              headerName:'언어코드', 
              field: 'langCd',
              sortable: true,
              minWidth:80,
              cellRenderer: ShowCellRenderer,
              rowSpan:rowSpan,
              cellClass: (rowSpan) => {
                return rowSpan.data.flag >= 2 ? 'show-cell' : null;
              },
            },
            { 
              headerName:'언어명', 
              field: 'langCdNm', 
              sortable: true, 
              minWidth:140,
              cellRenderer: ShowCellRenderer,
              rowSpan:rowSpan,
              cellClass: (rowSpan) => {
                return rowSpan.data.flag >= 2 ? 'show-cell' : null;
              },
            },
          ],
        },
        {
            headerName: '구분',
            field: 'gubun',
            spanHeaderHeight: true,
            minWidth:80,
        },
        ].concat(arrKeys.map((item, index) => {
          if (hdName['col'+index] !== null){
            return {
              headerName:hdName['col'+index],
              field:'col'+index,
              spanHeaderHeight: true,
              valueParser: numberValueParser,
              valueFormatter: currencyFormatter,
              minWidth:80,
            }
          }
        }).filter(item => {
          return item !== undefined && item !== null
        }))
        .concat(
          {
            headerName: '평균',
            valueGetter: (params) => {
              
              return arrKeys.filter((item, index) => {
                return hdName['col'+index] !== null
              }).map(item => {
                return Number(params.data[item])
              }).reduce((acc, cur, idx, all) => { return all.length === (idx+1) ? (acc+cur)/all.length : acc+=cur; }, 0)
              
            },
            valueFormatter: currencyFormatter,
            spanHeaderHeight: true,
            cellRenderer: 'agAnimateSlideCellRenderer',
            minWidth:80,
          },
        )
      )
  }, [hdName])

    // const gridRef = useRef();

    const [columnDefs, setColumnDefs]  = useState([
        {
          headerName: '언어',
          children: [
            { headerName:'지역', field: 'regnNm',minWidth:70,
                colSpan: (params) => {
                const region = params.data.regnNm;
                if (region === 'TOTAL') {
                  // have all Russia age columns width 2
                  return 3;
                }else{
                  return 1;
                }
              },
              sortable: true,
            },
            { headerName:'언어코드', field: 'langCd',minWidth:70,
              
              sortable: true 
            },
            { headerName:'언어명', field: 'langCdNm' ,minWidth:130,
              sortable: true
            },
          ],
        },
        
    ]);

  const pinnedBottomRowData = [total];
  const pinnedBottomRowData2 = total2;

  const rowSpan = (params) => {
        return params.data.flag? params.data.flag: 1;
  };

  class ShowCellRenderer {
        init(params) {  //console.log(params.data.flag)
        const cellBlank = !params.value;
        if (cellBlank) {
            return;
        }
    
        this.ui = document.createElement('div');
        this.ui.innerHTML = '<div class="rowspan-title" style="line-height:' + params.data.flag * '30' + 'px;">' + params.value + '</div>';
        
        }
    
        getGui() {
        return this.ui;
        }
    
        refresh() {
        return false;
        }
    }

    const [columnDefs2, setColumnDefs2]  = useState([
        {
          headerName: '언어',

          children: [
            { headerName:'지역', field: 'regnNm',
              colSpan: (params) => {
                const region = params.data.regnNm;
                if (region === 'TOTAL') {
                  // have all Russia age columns width 2
                  return 3;
                  
                } else {
                  // all other rows should be just normal
                  return 1;
                }
              },
              cellRenderer: ShowCellRenderer,
              rowSpan:rowSpan,
              cellClass: (rowSpan) => {
                return rowSpan.data.flag >= 2 ? 'show-cell-total' : null;
              },
              sortable: true,
              minWidth:70,
            },
            { 
              headerName:'언어코드', 
              minWidth:70,
              field: 'langCd',
              sortable: true,
              cellRenderer: ShowCellRenderer,
              rowSpan:rowSpan,
              cellClass: (rowSpan) => {
                return rowSpan.data.flag >= 2 ? 'show-cell' : null;
              },
            },
            { 
              headerName:'언어명', 
              field: 'langCdNm', 
              minWidth:130,
              sortable: true, 
              cellRenderer: ShowCellRenderer,
              rowSpan:rowSpan,
              cellClass: (rowSpan) => {
                return rowSpan.data.flag >= 2 ? 'show-cell' : null;
              },
            },
          ],
        },
        {
            headerName: '구분',
            field: 'gubun',
            spanHeaderHeight: true
        },
        
  ])

  const defaultColDef = useMemo(() => {
      return {
          initialWidth: 90,
          sortable: true,
          resizable:true,
          minWidth:70,
      };
  }, []);

  const onFirstDataRendered = (params) => {
      params.api.sizeColumnsToFit();
  };


  useEffect(()=>{
    if(queryResult.status === 'loading' && gridRef && gridRef.current && gridRef.current.api){
        gridRef.current.api.showLoadingOverlay();
    }
  },[queryResult]);

  useEffect(()=> {
    if(gridRef && gridRef.current && gridRef.current.api){
      gridRef.current.api.setQuickFilter(filterValue);
    }
  },[filterValue]);

  useEffect(()=> {
    if(gridRef && gridRef.current && gridRef.current.api){
      gridRef.current.api.paginationGoToPage(activePage-1);
    }
  },[activePage]);


  


  return(
    <>
    
    {(mode === 'monPrd' || mode === 'monOrd')&&
      <div className="ag-theme-alpine" style={{height: gridHeight, transition:'all ease .3s'}}>
        <AgGridReact
            ref={gridRef} 
            // rowData={queryResult && queryResult.data} 
            rowData={queryResult && queryResultRealDatas} 
            columnDefs={columnDefs}
            defaultColDef={defaultColDef}

            //  filter
            cacheQuickFilter={true}

            // overlay
            overlayLoadingTemplate={CONSTANTS.gridLoading}
            overlayNoRowsTemplate={qltyVehlCd==='ALL'?'<span style="padding: 10px; border: 1px solid #ccc;">차종을 선택하세요.</span>':CONSTANTS.gridNoRows}

            onFirstDataRendered={onFirstDataRendered}
            suppressSizeToFit={true}    
            onGridSizeChanged={onFirstDataRendered}
            onGridColumnsChanged={onFirstDataRendered}

            pinnedBottomRowData={pinnedBottomRowData}
            >
        </AgGridReact>
    </div>
  }

  {mode === 'monOrdPrd' &&
      <div className="ag-theme-alpine" style={{height: gridHeight, transition:'all ease .3s'}}>
        <AgGridReact
            ref={gridRef} 
            // rowData={rowData2} 
            columnDefs={columnDefs2}
            rowData={queryResult && queryResultRealDatas} 
            // columnDefs={columnDefs}
            defaultColDef={defaultColDef}

            //  filter
            cacheQuickFilter={true}

            // overlay
            overlayLoadingTemplate={CONSTANTS.gridLoading}
            overlayNoRowsTemplate={qltyVehlCd==='ALL'?'<span style="padding: 10px; border: 1px solid #ccc;">차종을 선택하세요.</span>':CONSTANTS.gridNoRows}

            onFirstDataRendered={onFirstDataRendered}
            suppressSizeToFit={true}    
            onGridSizeChanged={onFirstDataRendered}
            onGridColumnsChanged={onFirstDataRendered}

            pinnedBottomRowData={pinnedBottomRowData2}

            suppressRowTransform={true}

            >
        </AgGridReact>
    </div>
  }

  </>
  )


};
export default GridMonthOrder;