import { Input, InputGroup} from 'rsuite';
import SearchIcon from '@rsuite/icons/Search';

export const CustomInputGroup = ({ placeholder, ...props }) => (
    <InputGroup {...props} style={{marginBottom: 10}}>
      <Input placeholder={placeholder} />
      <InputGroup.Addon>
        <SearchIcon />
      </InputGroup.Addon>
    </InputGroup>
);