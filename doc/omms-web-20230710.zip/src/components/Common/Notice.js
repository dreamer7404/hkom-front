import React,{useEffect,useState} from 'react';
import {Modal, Button, Table} from 'react-bootstrap';
import { useQuery} from 'react-query';
import {Form, Checkbox,Notification,useToaster } from 'rsuite';
import { getData} from '../../utils/async';
import { API, CONSTANTS } from '../../utils/constants';
import {unescapeHtml} from '../../utils/commUtils';
import moment from 'moment';
import { useCookies } from 'react-cookie';

const Notice = ({show, onHide}) => {
    const queryResult = useQuery([API.noticeList, {}], () => getData(API.noticeList, {}),{  
        staleTime: 0,
    });
    const [cookies, setCookie] = useCookies([]);
    const [popupList, setPopupList] = useState([]);

    useEffect(()=>{
        if(queryResult.isSuccess){
            console.log("queryResult.data",queryResult.data)
            let arr = [];
            const w = 900;
            let index = 0;
            for(let i=0; i<queryResult.data.length; i++){
                const notice = queryResult.data[i];
  
                if(cookies['popup_'+notice.blcSn]) continue;
                const left = 10 + ((w-380)*index++);
      
                arr.push({id: notice.blcSn, title: notice.blcTitlNm, contents: notice.blcSbc, show: true, left: left+'px'});
                console.log("arr",arr);
            }
            setPopupList(arr)
        }
    },[queryResult.status])


useEffect(()=>{
console.log("popUpList",popupList);
},[popupList])

    
    const closePopup = id => {
        console.log("id",id);
        setPopupList(popupList.map(item => ({...item, show: item.id === id ? false: item.show})));
    };


    const stopPopup = id => {
        closePopup(id);
        const expires = moment().add(24, 'hours').toDate();
        setCookie('popup_'+id, 'done', {expires});
    };
    
    return (
        <>
            {popupList.map((item,idx)=>
                <Form key={idx} className="notice-pop-wrap" style={{position:"absolute",zIndex:"888",left : item.left, display:item.show===true?"block":"none"}}>
                    <Notification type='info' header='공지사항' closable style={{width:"500px"}}>
                        <Table className="tbl-hor" bordered>
                            <colgroup>
                                <col style={{width:'20%'}}></col>
                                <col style={{width:''}}></col>
                            </colgroup>
                                <tbody>
                                    <tr>
                                        <th className="">제목</th>
                                        <td colSpan="3">{item.title}</td>
                                    </tr>
                                    <tr>
                                        <th className="">내용</th>
                                        <td colSpan="3">
                                            <div dangerouslySetInnerHTML={{__html: unescapeHtml(item.contents)}} /> 
                                        </td>
                                    </tr>
                                    <tr>
                                        <th>첨부파일</th>
                                        <td colSpan="3">
                                            
                                        </td>
                                    </tr>
                                </tbody>
                        </Table>
                        <div className="notice-pop-bottom">
                            <Checkbox  onClick={() => stopPopup(item.id)}>하루동안 공지사항 띄우지 않음</Checkbox>
                            <Button key={idx} variant="primary" size="sm" onClick={() => closePopup(item.id)}>닫기</Button>
                        </div>
                    </Notification>
                </Form>
                )
            } 
                       
            
            
            {/* 공지사항이 여러개인 경우 2번째 modal부터 style left값 할당 
            2개인 경우 2번째 modal에 1번 modal 넓이값 +20px
            3개인 경우 3번째 modal에 1번 modal 넓이값 + 2번 modal 넓이값 + 40px */}

            {/* <Form>
                <Modal show={show} onHide={onHide} backdrop={false} keyboard={false} size="md" className="modal-custom modal-notice" style={{left:'520px'}}>
                    <Modal.Header closeButton>
                        <Modal.Title>공지사항</Modal.Title>
                    </Modal.Header>
                    <Modal.Body>
                            <Form>
                                <Table className="tbl-hor" bordered>
                                    <colgroup>
                                        <col style={{width:'20%'}}></col>
                                        <col style={{width:''}}></col>
                                    </colgroup>
                                    <tbody>
                                        <tr>
                                            <th className="">제목</th>
                                            <td colSpan="3">공지사항입니다.</td>
                                        </tr>
                                        <tr>
                                            <th className="">내용</th>
                                            <td colSpan="3">공지사항 내용입니다.</td>
                                        </tr>
                                        <tr>
                                            <th>첨부파일</th>
                                            <td colSpan="3">
                                                
                                            </td>
                                        </tr>
                                    </tbody>
                                </Table>
                            </Form>
                    </Modal.Body>

                    <Modal.Footer>
                        <Checkbox value="" className="">하루동안 공지사항 띄우지 않음</Checkbox>
                        <Button variant="primary" size="md" onClick={onHide}>확인</Button>
                    </Modal.Footer>
                </Modal>
            </Form> */}
        </>
    );

};
export default Notice;