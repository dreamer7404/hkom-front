//엑셀다운로드 테스트 김정웅
import * as ExcelJS from 'exceljs'
import { confirmAlert } from 'react-confirm-alert'; // Import
import ConfirmAlert from '../components/Common/ConfirmAlert';
import { formatNumber } from './commUtils';

const colDef = []
const rowData = [];

let pinnedBottomRowCount = 0


/**
 * @param {Array} rowData 컬럼수 대로 정리된 로우데이터
 * @param {Array} colDef 엑셀에서 사용될 헤더의 정보(agGrid의 columnDef의 양식과 같아야함)
 * @param {int} lastRowIndex 그리드 내 헤더의 로우길이
 * @param {String} fileName 파일명
 * @param {String} bottomFlag 테이블 내에서 pinnedBottomRow를 쓸경우 플래그 값(ex. 'TOTAL')
 * @param {Array} colSpan 테이블 내에서 colSpan 쓸경우 대상 컬럼의 값이 같은경우 colSpan처리한다. (ex. ['idxNm','wkYmd','dowNm'])
 */
export const excelDownloadTable = (rowData, colDef, lastRowIndex, fileName, bottomFlag, bottomRowCount, colSpan ) => {
	if(bottomFlag && bottomFlag !== '') {
		pinnedBottomRowCount=bottomRowCount
	}
	// console.log(pinnedBottomRowCount)
	console.log(colDef)
	console.log(rowData)

	return handleDownload(rowData, colDef, lastRowIndex, fileName, bottomFlag, colSpan)
}

const cleanRowData = () => {
	rowData.splice(0)
	colDef.splice(0)
	left = 1;
	right = 0;
	bottom = 1;
	pinnedBottomRowCount=0;
}

const handleDownload = (rowData, columnDefs, lastRowIndex, fileName, bottomFlag, colSpan) => {
	if(rowData.length <= 0){
		confirmAlert({
			closeOnClickOutside: false,
			customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}  title={"알림"} msg={"조회된 데이터가 없습니다."}  />
		})
		return false
	}

	// Ag-Grid 데이터 가져오기
	const columns = processColumns(columnDefs);

	// 엑셀 파일 생성
	const workbook = new ExcelJS.Workbook();
	const worksheet = workbook.addWorksheet('Sheet 1');

	// 1:컬럼정보, 2.ExcelJS, 3.lastRowIndex
	mergeCells(columnDefs, worksheet, lastRowIndex)
	addDataRows(worksheet, columns, rowData, lastRowIndex, bottomFlag, colSpan);

	
	//엑셀 파일 다운로드
	workbook.xlsx.writeBuffer().then((buffer) => {
		const blob = new Blob([buffer], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
		const url = URL.createObjectURL(blob);
		const link = document.createElement('a');
		link.href = url;
		link.download = fileName + '.xlsx';
		link.click();
		URL.revokeObjectURL(url);
	})
	.catch((error) => {
		console.error('엑셀 파일 생성 중 오류가 발생했습니다:', error);
	})
	.finally(() => {
		cleanRowData()
		return false
	})
};

const processColumns = (columns) => {
	const processedColumns = [];
	columns.forEach((column) => {
		if(column.headerName){ //체크박스가 아닌경우만 처리한다.
			if (column.children) {
				processedColumns.push(...processColumns(column.children));
			} else {
				processedColumns.push(column);
			}
		}
	});
	return processedColumns;
};

const addDataRows = (worksheet, columns, rowData, lastRowIndex, bottomFlag, colSpan) => {
	
	//rowSpan이 있는 컬럼 찾기 시작
	let rowSpanCol = [];
	columns.forEach(col => {
		if(col.rowSpan){
			rowSpanCol.push(col.field)
		}
	})
	//rowSpan이 있는 컬럼 찾기 끝
	
	rowData.forEach((row, rowIndex) => {
		//row별 flag 값 찾기 시작
		let flag = 0
		if(row.flag) {
			if(row.flag !== 1){
				flag = row.flag
			}
		}

		let rowSpanCheck = false
		if ((rowIndex+flag) % flag === 0){
			rowSpanCheck =  true
		}
		
		// pinnedBottomRow가 있는경우 colSpan해줄 컬럼의 수를 카운트 한다.
		let pinnedBottomRowColSpan = 0;
		// pinnedBottomRow가 있고, rowSpan까지 사용할 경우 데이터를 마지막 row까지 그린 후에 merge를 진행한다.
		let pinnedBottomRowStartRowIndex = 0;
		let pinnedBottomRowEndRowIndex = 0;
		//colSpan을 사용한경우 colSpan 의 시작점을 할당.
		let colSpanStart = 0;
		let colSpanDatas = []; //해당 row의 colSpan 대상 컬럼의 값을 담아놓고 중복제거하여 제거한 값이 1인경우만 컬럼을 합친다.
		let colSpanEnd = 0;
		

		//row별 flag 값 찾기 끝
		columns.forEach((column, colIndex) => {
			if(!column.checkboxSelection) {
				let value = row[column.field];
				
				if(column.valueGetter){
					let params = {data:row}
					value = column.valueGetter(params)
				}
				
				if(column.valueFormatter){
					value = formatNumber(value)
				}

				worksheet.getCell(rowIndex + lastRowIndex +1, colIndex + 1).value = value;

				if(rowData.length <= (pinnedBottomRowCount+rowIndex)){
					worksheet.getCell(rowIndex + lastRowIndex +1, colIndex + 1).font = { size: 10, bold: true };
					worksheet.getCell(rowIndex + lastRowIndex +1, colIndex + 1).alignment = { horizontal: 'center', vertical: 'middle',  wrapText: true };
					worksheet.getCell(rowIndex + lastRowIndex +1, colIndex + 1).fill = {
						type: 'pattern',
						pattern: 'solid',
						fgColor: { argb: 'f8f8f8' },
					};
					// pinnedBottomRow가 있는경우, bottomFlag와 colField가 같을경우 colSpan해줄 컬럼의 수 더해준다.
					if(value === bottomFlag){
						pinnedBottomRowColSpan ++
					}
				} else {
					
						if(colSpan && colSpan.length > 0 && colSpan.includes(column.field)){ //현재 작업하는 컬럼이 colSpan 대상 컬럼인 경우 
							colSpanDatas.push(value)

							if(colSpanStart > colIndex){
								colSpanStart = (colIndex+1);
							}
						}
					
						worksheet.getCell(rowIndex + lastRowIndex +1, colIndex + 1).font = { size: 9};
						worksheet.getCell(rowIndex + lastRowIndex +1, colIndex + 1).alignment = { horizontal: 'center', vertical: 'middle',  wrapText: true };					
					
				}

				if(rowSpanCol.length > 0){ //rowSpan을 해야하는 경우

					if(rowSpanCol.includes(column.field) && rowSpanCheck){
						if(pinnedBottomRowColSpan === 0){
							// top, left, bottom, right
							worksheet.mergeCells((rowIndex+1 + lastRowIndex),(colIndex+1),(rowIndex + lastRowIndex + flag),(colIndex+1 + pinnedBottomRowColSpan))
							
							pinnedBottomRowStartRowIndex = (rowIndex+1 + lastRowIndex)
							pinnedBottomRowEndRowIndex = (rowIndex + lastRowIndex + flag)
						}
					} else {
						if(pinnedBottomRowColSpan === 1 && pinnedBottomRowStartRowIndex === 0){
							pinnedBottomRowStartRowIndex = (rowIndex + lastRowIndex + flag)
						} else {
							pinnedBottomRowEndRowIndex = (rowIndex + lastRowIndex +1)
						}
					}

				} else { //rowSpan이 필요없는 경우
					if(pinnedBottomRowColSpan === 1 && pinnedBottomRowStartRowIndex === 0){
						pinnedBottomRowStartRowIndex = (rowIndex+ 1 + lastRowIndex + flag)
					} else {
						pinnedBottomRowEndRowIndex = (rowIndex+1 + lastRowIndex + flag )
					}
				}
			}
		}); // col forEach 끝

		//pinnedBottomRow 의 rowSpan과 colSpan을 처리해준다.
		if(pinnedBottomRowColSpan !== 0 && rowData.length === (rowIndex+1)){
			// top, left, bottom, right
			worksheet.mergeCells(pinnedBottomRowStartRowIndex, 1, pinnedBottomRowEndRowIndex, pinnedBottomRowColSpan)

			//단기계획 (3일) 팝업을 위한 조치
			worksheet.mergeCells(pinnedBottomRowStartRowIndex, 4, pinnedBottomRowStartRowIndex, 5)
			worksheet.mergeCells(pinnedBottomRowEndRowIndex, 4, pinnedBottomRowEndRowIndex, 5)
		}



		//데이터Row에 사용된 colSpan을 처리해준다.
		const  findMaxDuplicateCount = (colSpanDatas) => {
			var duplicates = {};
			var maxDuplicateCount = 0;
		  
			colSpanDatas.forEach(item => {
				duplicates[item] = (duplicates[item] || 0) + 1;
				if (duplicates[item] > maxDuplicateCount) {
				maxDuplicateCount = duplicates[item];
				}
			});
		  
			return maxDuplicateCount;
		}
		if(colSpan && colSpan.length > 0 && colSpan.length === findMaxDuplicateCount(colSpanDatas)){
			// top, left, bottom, right
			// console.log((rowIndex + lastRowIndex +1), (colSpanStart+1), (rowIndex + lastRowIndex +1), (colSpanStart+colSpan.length))
			worksheet.mergeCells((rowIndex + lastRowIndex +1), (colSpanStart+1), (rowIndex + lastRowIndex +1), (colSpanStart+colSpan.length))
		}

	}); // row forEach 끝
};

// ExcelJS를 사용하여 셀 병합을 처리하는 함수
let left = 1;
let right = 0;
let bottom = 1;
const mergeCells = (columnDefs, worksheet, lastRowIndex, top) => {
	
	for(let i=0; i<columnDefs.length; i++){
		if(!top) top = 1

		let item = columnDefs[i]
		if(item.checkboxSelection) {
			continue;
		}
		
		if(!item.children){
			// console.log('children', item.headerName, 'left: '+left, 'right: '+left, 'top: '+top, 'bottom: '+lastRowIndex)
			makeCell(top, left, lastRowIndex, left, item.headerName, worksheet)
			left++

		} else {
			right += item.children.length
				let colChildArr = processColumns(item.children)
				makeCell(top, left, top, (colChildArr.length+left-1), item.headerName, worksheet)
			top++
			right += mergeCells(item.children, worksheet, lastRowIndex, top, left, bottom, right)
			top--
			right = 0
			
		}
		if(!top) top = 1
	}
	return right

}

const makeCell = (top, left, bottom, right, headerName, worksheet) => {
	// top, left, bottom, right
	worksheet.mergeCells(top,left,bottom,right);
	//row, col
	worksheet.getCell(top,left).value = headerName;
	worksheet.getCell(top,left).font = { size: 10, bold: true };
	worksheet.getCell(top,left).alignment = { horizontal: 'center', vertical: 'middle',  wrapText: true };
	worksheet.getCell(top,left).fill = {
		type: 'pattern',
		pattern: 'solid',
		fgColor: { argb: 'f8f8f8' },
	};
}

// 엑셀 다운로드 끝.. 나중에 공통으로 빼자.