package com.oms.print.dto;


import org.apache.ibatis.type.Alias;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;



/**
 * <pre>
 * Statements
 * </pre>
 * @ClassName : PrintStateResDTO.java
 * @Description :
 * @author 김경훈
 * @since 2023. 5. 3.
 * @see
 */
@Alias("PrintStateComDTO")
@Data
@NoArgsConstructor
@AllArgsConstructor

public class PrintStateComDTO {

private String qltyVehlCd;           //차종코드
private String userEeno;             //사번
private String mdlMdyCd;            //연식
private String expdPdiCd;           //공정코드
private String dlExpdRegnCd;        //지역코드
private String langCd;                  //언어코드
private String oldPrntPbcnNo;       //구발간번호
private String newPrntPbcnNo;       //신발간번호
private String dlExpdPdiCd;             //공정코드
private String iWayCd;                  //인쇄구분
private String dlExpdCoCd;              //회사코드
private String bDate;
private String lrnkCd;          //발간번호 구분

}
