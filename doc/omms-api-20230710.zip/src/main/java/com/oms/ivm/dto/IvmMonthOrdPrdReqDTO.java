package com.oms.ivm.dto;

import org.apache.ibatis.type.Alias;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @author 김정웅
 * @since 2023. 3. 7.
 * @see
 */
@Alias("ivmMonthOrdPrdReqDTO")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class IvmMonthOrdPrdReqDTO extends ComIvmReqDTO {

    private String sMonth;  //시작월
    private String eMonth;  //종료월

    private String col0;
    private String col1;
    private String col2;
    private String col3;
    private String col4;
    private String col5;
    private String col6;
    private String col7;
    private String col8;
    private String col9;
    private String col10;
    private String col11;
    private String col12;
    private String col13;
    private String vFramYmd;
    private String firstYm;
    private String lastYm;

//    private String chkVal;
//    private String csrf;
//    private String page;
//    private String pgmId;
//    private String menuId;
//    private String pdiNm;
//    private String langCombo;
//
//    private String vFramYmd;
//    private String vPlnFramYmd;
//
//    private String firstYm;
//    private String lastYm;
//
//    private String col0;
//    private String col1;
//    private String col2;
//    private String col3;
//    private String col4;
//    private String col5;
//    private String col6;
//    private String col7;
//    private String col8;
//    private String col9;
//    private String col10;
//    private String col11;
//    private String col12;
//    private String col13;
}
