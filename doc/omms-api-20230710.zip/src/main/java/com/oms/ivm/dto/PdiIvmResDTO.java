package com.oms.ivm.dto;

import org.apache.ibatis.type.Alias;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * <pre>
 * pdiIvmResDTO
 * </pre>
 *
 * @author 김정웅
 * @since 2023. 5. 5.
 * @see
 */

@Alias("pdiIvmResDTO")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class PdiIvmResDTO {

    private String clScnCd;
    private String dataSn;
    private String qltyVehlCd;
    private String mdlMdyCd;
    private String langCd;
    private String dlExpdRegnCd;
    private String qltyVehlNm;
    private String langCdNm;
    private String dlExpdRegnNm;
    private String wek2PlanQty;
    private String day3PlanQty;
    private String currMthTrwiQty;
    private String prev1dayTrwiQty;
    private String prntQty;         // 인쇄중
    private String sewonIvQty;
    private String sewonPrntYn;
    private String sewonDlvyQty;
    private String pdiDeei1Qty;
    private String expdWhsnStNm;
    private String pdiIvQty;
    private String dsid3Qty;
    private String day3AftrIvQty;
    private String wek2AftrIvQty;
    private String prntState;
    private String prntStateNm;

}
