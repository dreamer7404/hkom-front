package com.oms.ivm.dao;

import java.util.List;

import com.oms.ivm.dto.ComIvmReqDTO;
import com.oms.ivm.dto.IvmRequestMonitorResDTO;
import com.oms.ivm.dto.YsnIvmResDTO;

/**
 * <pre>
 * YsnIvmDAO 인터페이스
 * </pre>
 *
 * @Class Name  : YsnIvmDAO.java
 * @Description : 재고관리 > 용산재고관리 DAO
 * @author 김정웅
 * @since 2023.6.26
 * @see
*/
public interface YsnIvmDAO {

    //용산재고관리 현황 조회
    List<YsnIvmResDTO> selectYongsanIvmList(ComIvmReqDTO reqDto);

    List<IvmRequestMonitorResDTO> selectIvmYsnReqStateList(ComIvmReqDTO reqDto);
}
