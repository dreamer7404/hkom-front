package com.oms.common.dto;

import org.apache.ibatis.type.Alias;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;



/**
 * <pre>
 * Statements
 * </pre>
 * @ClassName : CommLangComboResDTO.java
 * @Description : 언어코드 공통 호출 결과 DTO
 * @author 김정웅
 * @since 2023. 3. 21.
 * @see
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Alias("commLangComboResDTO")
public class CommLangComboResDTO {
    private String langCd;
    private String langCdNm;
}
