package com.oms.sys.dto;

import java.util.Objects;

import org.apache.ibatis.type.Alias;

import lombok.Getter;
import lombok.Setter;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @author 안경수
 * @since 2023. 4. 26.
 * @see
 */
@Alias("authAffrMgmtResDTO")
@Getter
@Setter
public class AuthAffrMgmtResDTO {
    private String grpCd;
    private String menuId;
    private String menuAuthCd; // U,R
    private String useYn;
    private String grpNm;
    private String pgmNm;
    private Integer pgmIdSn;
    private String pgmId;

    private String grpPgmNm;


}
