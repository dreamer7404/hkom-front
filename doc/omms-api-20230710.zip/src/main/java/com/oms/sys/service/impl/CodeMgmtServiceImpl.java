package com.oms.sys.service.impl;

import java.util.HashMap;
import java.util.List;

import able.cloud.core.service.HService;

import org.springframework.stereotype.Service;

import com.oms.sys.dao.CodeMgmtDAO;
import com.oms.sys.dto.CodeMgmtReqDTO;
import com.oms.sys.dto.CodeMgmtResDTO;
import com.oms.sys.service.CodeMgmtService;

import lombok.RequiredArgsConstructor;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @author 안경수
 * @since 2023. 2. 24.
 * @see
 */

@RequiredArgsConstructor
@Service("codeMgmtService")
public class CodeMgmtServiceImpl extends HService implements CodeMgmtService {

    private final CodeMgmtDAO codeMgmtDAO;

    @Override
    public Integer insertCodeMgmt(CodeMgmtReqDTO codeMgmtReqDTO) throws Exception {
        return codeMgmtDAO.insertCodeMgmt(codeMgmtReqDTO);
    }

    @Override
    public Integer updateCodeMgmt(CodeMgmtReqDTO codeMgmtReqDTO) throws Exception {
        return codeMgmtDAO.updateCodeMgmt(codeMgmtReqDTO);
    }

    @Override
    public Integer deleteCodeMgmt(CodeMgmtReqDTO codeMgmtReqDTO) throws Exception {
        return codeMgmtDAO.deleteCodeMgmt(codeMgmtReqDTO);
    }


    @Override
    public List<CodeMgmtResDTO> selectCodeMgmtList(CodeMgmtReqDTO codeMgmtReqDTO) throws Exception {
        return codeMgmtDAO.selectCodeMgmtList(codeMgmtReqDTO);
    }

    /*
     * @see com.oms.sys.service.CodeMgmtService#selectGrpCodeCombo(com.oms.sys.dto.CodeMgmtReqDTO)
     */
    @Override
    public List<HashMap<String,Object>> selectGrpCodeCombo(){
        // TODO Auto-generated method stub
        return codeMgmtDAO.selectGrpCodeCombo();
    }

    /*
     * @see com.oms.sys.service.CodeMgmtService#insertCodeGrpMgmt(com.oms.sys.dto.CodeMgmtReqDTO)
     */
    @Override
    public Integer insertCodeGrpMgmt(CodeMgmtReqDTO codeMgmtReqDTO) {
        // TODO Auto-generated method stub
        return codeMgmtDAO.insertCodeGrpMgmt(codeMgmtReqDTO);
    }

    /*
     * @see com.oms.sys.service.CodeMgmtService#updateCodeGrpMgmt(com.oms.sys.dto.CodeMgmtReqDTO)
     */
    @Override
    public Integer updateCodeGrpMgmt(CodeMgmtReqDTO codeMgmtReqDTO) {
        // TODO Auto-generated method stub
        return codeMgmtDAO.updateCodeGrpMgmt(codeMgmtReqDTO);
    }

    /*
     * @see com.oms.sys.service.CodeMgmtService#deleteCodeGrpMgmt(com.oms.sys.dto.CodeMgmtReqDTO)
     */
    @Override
    public Integer deleteCodeGrpMgmt(CodeMgmtReqDTO codeMgmtReqDTO) {
        // TODO Auto-generated method stub
        return codeMgmtDAO.deleteCodeGrpMgmt(codeMgmtReqDTO);
    }

    /*
     * @see com.oms.sys.service.CodeMgmtService#selectNextGrpCode()
     */
    @Override
    public HashMap<String, Object> selectNextGrpCode() {
        // TODO Auto-generated method stub
        return codeMgmtDAO.selectNextGrpCode();
    }

    /*
     * @see com.oms.sys.service.CodeMgmtService#getCodeGrpChk(com.oms.sys.dto.CodeMgmtReqDTO)
     */
    @Override
    public String getCodeGrpChk(CodeMgmtReqDTO codeMgmtReqDTO) {
        // TODO Auto-generated method stub
        return codeMgmtDAO.getCodeGrpChk(codeMgmtReqDTO);
    }

    /*
     * @see com.oms.sys.service.CodeMgmtService#getCodeChk(com.oms.sys.dto.CodeMgmtReqDTO)
     */
    @Override
    public String getCodeChk(CodeMgmtReqDTO codeMgmtReqDTO) {
        // TODO Auto-generated method stub
        return codeMgmtDAO.getCodeChk(codeMgmtReqDTO);
    }

    /*
     * @see com.oms.sys.service.CodeMgmtService#insertExcelSysCode(com.oms.sys.dto.CodeMgmtReqDTO)
     */
    @Override
    public int insertExcelSysCode(CodeMgmtReqDTO dto) {
        // TODO Auto-generated method stub
          return codeMgmtDAO.insertExcelSysCode(dto);
    }
}
