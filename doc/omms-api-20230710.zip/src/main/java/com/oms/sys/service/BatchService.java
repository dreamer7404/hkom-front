package com.oms.sys.service;

import java.util.List;

import com.oms.sys.dto.BatchLogResDTO;
import com.oms.sys.dto.BatchReqDTO;
import com.oms.sys.dto.BatchResDTO;
/* * <pre>
 * Statements
 * </pre>
 * @ClassName : BatchService.java
 * @Description :
 * @author 김경훈
 * @since 2023. 6. 14.
 * @see
 */
public interface BatchService {
        List<BatchResDTO> selectBatchInfos();
        List<BatchLogResDTO> selectBatchLogs(BatchReqDTO dto);
        Integer selectBatchLogsTot(BatchReqDTO dto);



}
