package com.oms.sys.service.impl;

import java.util.List;

import org.springframework.stereotype.Service;

import com.oms.sys.dao.LogDAO;
import com.oms.sys.dao.LogLgiDAO;
import com.oms.sys.dto.LogComReqDTO;
import com.oms.sys.dto.LogLgiResDTO;
import com.oms.sys.dto.LogUseReqDTO;
import com.oms.sys.dto.LogUseResDTO;
import com.oms.sys.dto.SchedLogDTO;
import com.oms.sys.model.LogUse;
import com.oms.sys.service.LogLgiService;
import com.oms.sys.service.LogService;

import lombok.RequiredArgsConstructor;



/**
 * <pre>
 * Statements
 * </pre>
 * @ClassName : LogLgiServiceImpl.java
 * @Description :
 * @author 김경훈
 * @since 2023. 6. 16.
 * @see
 */
@RequiredArgsConstructor
@Service("logLgiService")
public class LogLgiServiceImpl implements LogLgiService {

    private final LogLgiDAO logLgiDAO;

    /*
     * @see com.oms.sys.service.LogLgiService#selectLogLgiHistorys(com.oms.sys.dto.LogLgiReqDTO)
     */
    @Override
    public List<LogLgiResDTO> selectLogLgiHistorys(LogComReqDTO dto) {
        // TODO Auto-generated method stub
        return logLgiDAO.selectLogLgiHistorys(dto);
    }

    /*
     * @see com.oms.sys.service.LogLgiService#selectLogLgiHistoryTots(com.oms.sys.dto.LogLgiReqDTO)
     */
    @Override
    public Integer selectLogLgiHistoryTots(LogComReqDTO dto) {
        // TODO Auto-generated method stub
        return logLgiDAO.selectLogLgiHistoryTots(dto);
    }




}
