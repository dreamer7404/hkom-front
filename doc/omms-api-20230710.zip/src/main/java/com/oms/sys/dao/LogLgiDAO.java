package com.oms.sys.dao;

import java.util.List;

import com.oms.sys.dto.BatchLogResDTO;
import com.oms.sys.dto.BatchReqDTO;
import com.oms.sys.dto.BatchResDTO;
import com.oms.sys.dto.LogComReqDTO;
import com.oms.sys.dto.LogLgiResDTO;
/**
 * <pre>
 * Statements
 * </pre>
 * @ClassName : BatchDAO.java
 * @Description :
 * @author 김경훈
 * @since 2023. 6. 14.
 * @see
 */
public interface LogLgiDAO {

    /**
     * Statements
     *
     * @param dto
     * @return
     */
    List<LogLgiResDTO> selectLogLgiHistorys(LogComReqDTO dto);

    /**
     * Statements
     *
     * @param dto
     * @return
     */
    Integer selectLogLgiHistoryTots(LogComReqDTO dto);

}
