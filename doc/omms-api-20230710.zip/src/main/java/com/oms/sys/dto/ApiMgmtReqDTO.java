package com.oms.sys.dto;

import java.util.List;

import org.apache.ibatis.type.Alias;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @author 안경수
 * @since 2023. 5. 23.
 * @see
 */
@Alias("apiMgmtReqDTO")
@NoArgsConstructor
@Data
public class ApiMgmtReqDTO {
    private String apiUrl;
    private String apiNm;
    private String method;
    private String menuId;

    private String userEeno;
    private List<String> apiUrls;

    private List<ApiMgmtReqDTO> excelDataList; //엑셀 업로드 저장

    /**
     * Statements
     *
     * @param apiUrl
     * @param userEeno
     */
    public ApiMgmtReqDTO(String apiUrl, String method, String userEeno) {
        super();
        this.method = method;
        this.apiUrl = apiUrl;
        this.userEeno = userEeno;
    }




}
