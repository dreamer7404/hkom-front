package com.oms.sys.controller;

import java.util.List;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


import com.oms.sys.dto.AuthChangeLogResDTO;
import com.oms.sys.dto.FileUploadLogResDTO;
import com.oms.sys.dto.LogComReqDTO;
import com.oms.sys.dto.SchedulerLogResDTO;
import com.oms.sys.service.AuthChangeLogService;
import com.oms.sys.service.FileUploadLogService;
import com.oms.sys.service.SchedulerLogService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;


/**
 * <pre>
 * Statements
 * </pre>
 * @ClassName : SchedulerLogController.java
 * @Description :
 * @author 김경훈
 * @since 2023. 6. 19.
 * @see
 */
@Tag(name = "SchedulerLogController", description = "")
@RequiredArgsConstructor
@RestController
@RequestMapping("/api")
public class SchedulerLogController {

    /**
     * 클래스 Injection
     */
    private final SchedulerLogService schedulerService;
        /**
     * Batch 목록을 조회
     */
    @Operation(summary = "권한변경 목록 조회 ")
    @GetMapping("/schedulerHistorys")
    public List<SchedulerLogResDTO> schedulerHistorys(@ModelAttribute LogComReqDTO dto) throws Exception {
        return schedulerService.schedulerHistorys(dto);
    }


    /**
     * Batch 목록을 조회
     */
    @Operation(summary = "권한변경 목록 Row수 ")
    @GetMapping("/schedulerHistoryTots")
    public Integer schedulerHistoryTots(@ModelAttribute LogComReqDTO dto) throws Exception {
        return schedulerService.schedulerHistoryTots(dto);
    }



}
