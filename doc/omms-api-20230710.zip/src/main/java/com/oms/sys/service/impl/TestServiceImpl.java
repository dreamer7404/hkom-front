package com.oms.sys.service.impl;

import java.util.List;

import able.cloud.core.service.HService;

import org.springframework.stereotype.Service;

import com.oms.sys.dao.TestDAO;
import com.oms.sys.dto.TestIvmTotalReqDTO;
import com.oms.sys.dto.TestIvmTotalResDTO;
import com.oms.sys.service.TestService;

import lombok.RequiredArgsConstructor;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @author Windows ≫c¿eAU
 * @since 2023. 3. 13.
 * @see
 */

@RequiredArgsConstructor
@Service
public class TestServiceImpl extends HService implements TestService {

     private final TestDAO testDAO;

    @Override
    public String testBatch() throws Exception {
        return testDAO.testBatch();
    }

//    @Override
//    public List<TestIvmTotalResDTO> selectTotalIvmList(TestIvmTotalReqDTO testIvmTotalReqDTO) throws Exception {
//        return testDAO.selectTotalIvmList(testIvmTotalReqDTO);
//    }


}
