package com.oms.mri.service.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import able.cloud.core.service.HService;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.oms.mri.dao.ClcmDAO;
import com.oms.mri.dto.ClcmInfoPopReqDTO;
import com.oms.mri.dto.ClcmInfoResDTO;
import com.oms.mri.dto.ClcmInfosReqDTO;
import com.oms.mri.dto.ClcmInfosResDTO;
import com.oms.mri.service.ClcmService;

import lombok.RequiredArgsConstructor;


/**
 * <pre>
 * ClcmServiceImpl
 * </pre>
 * @ClassName : ClcmServiceImpl.java
 * @Description : 제작준비 > 법규및변경관리 서비스
 * @author 김정웅
 * @since 2023. 5. 22.
 * @see
 */
@RequiredArgsConstructor
@Service("ClcmService")
public class ClcmServiceImpl extends HService implements ClcmService {

    private final ClcmDAO clcmDAO;

    @Override
    public List<ClcmInfosResDTO> selectClcmInfoList(ClcmInfosReqDTO reqDto) {
        List<ClcmInfosResDTO> result = new ArrayList<ClcmInfosResDTO>();
        result = clcmDAO.selectClcmInfoList(reqDto);
        return result;
    }

    @Transactional
    @Override
    public Integer insertClcmInfoPop(ClcmInfoPopReqDTO reqDto) throws Exception {
        int result = 0;
        //취급설명서변경번호 (PK) 생성하기
        String dlExpdAltrNo = clcmDAO.getDlExpdAltrNo(reqDto);
        reqDto.setDlExpdAltrNo(dlExpdAltrNo);

        /**
         * @TODO 첨부파일이 있는경우 처리
         * @TODO 메일 전송 후 `reqDto.etYn("Y")` 처리 필요.
         */

        //첨부파일 여부(있음:Y, 없음:N)
//        reqDto.setAttcYn("N");
        //메일전송 여부(완료:Y, 없음:NULL)
        //reqDto.etYn("Y");

        //insert TB_CHKLIST_INFO
        result += clcmDAO.insertClcmInfo(reqDto);

        //insert TB_CHKLIST_DTL_INFO
        List<HashMap<String, String>> langCdByCarList = reqDto.getLangCdByVehlList();
        for(HashMap<String, String> langCdByCar : langCdByCarList) {
            reqDto.setQltyVehlCd(langCdByCar.get("qltyVehlCd"));
            reqDto.setLangCd(langCdByCar.get("langCd"));
            clcmDAO.insertClcmInfoDtl(reqDto);
        }

        return result;
    }

    @Transactional
    @Override
    public Integer updateClcmInfoPop(ClcmInfoPopReqDTO reqDto) throws Exception {
        int result = 0;

        /**
         * @TODO 첨부파일이 있는경우 처리
         * @TODO 메일 전송 후 `reqDto.etYn("Y")` 처리 필요.
         */

        //첨부파일 여부(있음:Y, 없음:N)
//        reqDto.setAttcYn("N");
        //메일전송 여부(완료:Y, 없음:NULL)
        //reqDto.etYn("Y");

        //update TB_CHKLIST_INFO
        result = clcmDAO.updateClcmInfo(reqDto);

        //delete TB_CHKLIST_DTL_INFO
        int rv = clcmDAO.deleteClcmInfoDtl(reqDto);

        //update TB_CHKLIST_DTL_INFO
        List<HashMap<String, String>> langCdByCarList = reqDto.getLangCdByVehlList();
        for(HashMap<String, String> langCdByCar : langCdByCarList) {
            reqDto.setQltyVehlCd(langCdByCar.get("qltyVehlCd"));
            reqDto.setLangCd(langCdByCar.get("langCd"));
            clcmDAO.insertClcmInfoDtl(reqDto);
        }

        return result;
    }

    @Transactional
    @Override
    public Integer deleteClcmInfoPop(List<ClcmInfoPopReqDTO> reqDto, String userEeno, String dlExpdCoCd) throws Exception {
        int result = 0;

        //delete TB_CHKLIST_DTL_INFO
        for(ClcmInfoPopReqDTO param : reqDto) {
            param.setUserEeno(userEeno);
            param.setDlExpdCoCd(dlExpdCoCd);
            result += clcmDAO.deleteClcmInfoDtl(param);
        }

        //TB_CHKLIST_DTL_INFO 에 해당 등록번호의 데이터가 남아 있는경우 TB_CHKLIST_INFO는 삭제하지 않는다.
        Set<String> dlExpdAltrNos = new HashSet<String>(reqDto.stream().map(ClcmInfoPopReqDTO::getDlExpdAltrNo).collect(Collectors.toList()));
        for(String dlExpdAltrNo : dlExpdAltrNos) {
            int cnt = clcmDAO.selectClcmInfoDtlCount(dlExpdAltrNo);
            if(cnt == 0) {
                clcmDAO.deleteClcmInfo(dlExpdAltrNo);
            }
        }

        return result;
    }

    @Override
    public ClcmInfoResDTO selectClcmInfo(ClcmInfosReqDTO reqDto) throws Exception {
        ClcmInfoResDTO result = new ClcmInfoResDTO();
        result = clcmDAO.selectClcmInfo(reqDto);

        List<HashMap<String, String>> langCdByVehlList = clcmDAO.selectClcmInfoDtl(reqDto);
        result.setLangCdByVehlList(langCdByVehlList);
        return result;
    }

    @Override
    public List<HashMap<String, String>> selectClcmLangCdList(String qltyVehlCd) throws Exception {
        List<HashMap<String, String>> result = new ArrayList<HashMap<String, String>>();
        result = clcmDAO.selectClcmLangCdList(qltyVehlCd);
        return result;
    }


}





