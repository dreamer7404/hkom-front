package com.oms.stm.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import able.cloud.core.web.HController;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.oms.cmm.global.Consts;
import com.oms.cmm.utils.Utils;

import com.oms.stm.dto.PrntPageMgmtReqDTO;
import com.oms.stm.dto.PrntPageMgmtResDTO;
import com.oms.stm.dto.StmComReqDTO;
import com.oms.stm.service.PrntPageMgmtService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;



/**
 * <pre>
 * Statements
 * </pre>
 * @ClassName : PrntPageMgmtController.java
 * @Description :
 * @author 김경훈
 * @since 2023. 4. 4.
 * @see
 */
@Tag(name = "PrntPageMgmtController", description = "")
@RequiredArgsConstructor
@RestController
@RequestMapping("/api")
public class PrntPageMgmtController extends HController {

    /**
     * 클래스 Injection
     */
    private final PrntPageMgmtService prntPageMgmtService;
    private final HttpServletRequest request;


    /**
     * 인쇄페이지관리 조회
     */
    @Operation(summary = "인쇄페이지관리 조회")
    @GetMapping("/prntPageMgmts")
    public  List<PrntPageMgmtResDTO> prntPageMgmts(@ModelAttribute StmComReqDTO dto) throws Exception {

        int nCnt = prntPageMgmtService.selectMaxDeppc1Sn(dto); //인쇄부수 몇개 찍을지 판단, max +1,


        List<Integer> vCnt = new ArrayList<Integer>();
        for (int i = 1; i < nCnt; i++) {
            vCnt.add(i);
        }

//        dto.setVCnt(vCnt);
        return prntPageMgmtService.selectPrntPageList(dto);

    }

    /**
     * 인쇄페이지 관리 저장
     */
    @Operation(summary = "인쇄페이지 관리 저장", description = "")
    @Parameter(in = ParameterIn.HEADER, name="_method")
    @PostMapping(value = "/prntPageMgmt")
       public Integer prntPageMgmt(@RequestBody PrntPageMgmtReqDTO dto) throws Exception {
        int result = 0;
        dto.setUserEeno(Utils.getUserEeno(request));
        String method = Utils.getMethod(request);
        String  chk = prntPageMgmtService.validChk(dto);

        List<PrntPageMgmtReqDTO> chkGridData = dto.getChkGridData();
        if(method.equals(Consts.INSERT)) {
            if("Y".equals(chk)) {
                if(dto.getA1()!=null && !"".equals(dto.getA1())) {
                    dto.setDeppc1Sn(0);
                    dto.setDeppc2Sn(1);
                    dto.setEndPgSn(Integer.parseInt(dto.getA1()));
                    result = prntPageMgmtService.insertPrntPage(dto);
                }
                else {
                    dto.setDeppc1Sn(0);
                    dto.setDeppc2Sn(1);
                    dto.setEndPgSn(0);
                    result = prntPageMgmtService.insertPrntPage(dto);
                }
                if(dto.getA2()!=null && !"".equals(dto.getA2())) {
                    dto.setDeppc1Sn(0);
                    dto.setDeppc2Sn(2);
                    dto.setEndPgSn(Integer.parseInt(dto.getA2()));
                    result =  prntPageMgmtService.insertPrntPage(dto);
                }
                else {
                    dto.setDeppc1Sn(0);
                    dto.setDeppc2Sn(2);
                    dto.setEndPgSn(0);
                    result =  prntPageMgmtService.insertPrntPage(dto);
                }
                if(dto.getA3()!=null && !"".equals(dto.getA3())) {
                    dto.setDeppc1Sn(0);
                    dto.setDeppc2Sn(3);
                    dto.setEndPgSn(Integer.parseInt(dto.getA3()));
                    result =  prntPageMgmtService.insertPrntPage(dto);
                }
                else {
                    dto.setDeppc1Sn(0);
                    dto.setDeppc2Sn(3);
                    dto.setEndPgSn(0);
                    result =  prntPageMgmtService.insertPrntPage(dto);
                }
            }
      }  else if (method.equals(Consts.UPDATE)) {
          result =prntPageMgmtService.deletePrntPage(dto);

          if(dto.getA1()!=null && !"".equals(dto.getA1())) {
              dto.setDeppc1Sn(0);
              dto.setDeppc2Sn(1);
              dto.setEndPgSn(Integer.parseInt(dto.getA1()));
              result = prntPageMgmtService.insertPrntPage(dto);
          }
          else {
              dto.setDeppc1Sn(0);
              dto.setDeppc2Sn(1);
              dto.setEndPgSn(0);
              result = prntPageMgmtService.insertPrntPage(dto);
          }
          if(dto.getA2()!=null && !"".equals(dto.getA2())) {
              dto.setDeppc1Sn(0);
              dto.setDeppc2Sn(2);
              dto.setEndPgSn(Integer.parseInt(dto.getA2()));
              result =  prntPageMgmtService.insertPrntPage(dto);
          }
          else {
              dto.setDeppc1Sn(0);
              dto.setDeppc2Sn(2);
              dto.setEndPgSn(0);
              result =  prntPageMgmtService.insertPrntPage(dto);
          }
          if(dto.getA3()!=null && !"".equals(dto.getA3())) {
              dto.setDeppc1Sn(0);
              dto.setDeppc2Sn(3);
              dto.setEndPgSn(Integer.parseInt(dto.getA3()));
              result =  prntPageMgmtService.insertPrntPage(dto);
          }
          else {
              dto.setDeppc1Sn(0);
              dto.setDeppc2Sn(3);
              dto.setEndPgSn(0);
              result =  prntPageMgmtService.insertPrntPage(dto);
          }

      }   else if (method.equals(Consts.DELETE)) {
          for(int i=0; i<chkGridData.size(); i++) {
              result =prntPageMgmtService.deletePrntPage(chkGridData.get(i));
          }
      }
    return result;
    }
}