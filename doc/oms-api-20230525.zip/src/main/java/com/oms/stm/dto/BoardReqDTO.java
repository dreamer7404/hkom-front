package com.oms.stm.dto;

import org.apache.ibatis.type.Alias;

import com.oms.common.dto.RcvrReqDTO;


import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @author 안경수
 * @since 2023. 2. 9.
 * @see
 */

@Alias("boardReqDTO")
@Data
@AllArgsConstructor
public class BoardReqDTO extends RcvrReqDTO {
    @Schema(type = "string", example = " ")
    private String  scrnSn;                       //화면일련번호
    @Schema(type = "string", example = " ")
    private String  affrScnCd;                 //업무구분코드
    @Schema(type = "string", example = " ")
    private String  rgnEeno;                     //등록자사원번호
    @Schema(type = "string", example = " ")
    private String  blcRgstYmd;               //게시물등록년월일
    @Schema(type = "string", example = " ")
    private String  pprrEeno;                   //작성자사원번호
    @Schema(type = "string", example = " ")
    private String  updrEeno;                  //수정자사원번호
    @Schema(type = "string", example = "테스트")
    private String  blcTitlNm;                  //게시물 제목명
    @Schema(type = "string", example = " ")
    private String  blcSbc;                  //게시물 내용
    @Schema(type = "string", example = "N")
    private String  attcYn;                  //첨부 여부
    @Schema(type = "string", example = " ")
    private String  n1afp2Adr;            //1차첨부파일경로주소
    @Schema(type = "string", example = "Y")
    private String bulYn;
    @Schema(type = "string", example = " ")
    private String bulFnhYmd;
    @Schema(type = "string", example = " ")
    private String bulStrtYmd;


    //조건
    @Schema(type = "string", example = " ")
    private String userId;                      //사용자 ID
    @Schema(type = "string", example = " ")
    private String loginNm;                 //로그인중인 사용자
    @Schema(type = "string", example = " ")
    private String saffrScnCd;
    @Schema(type = "string", example = " ")
    private String keyword;
    @Schema(type = "string", example = " ")
    private String sdate;
    @Schema(type = "string", example = " ")
    private String edate;
    @Schema(type = "string", example = " ")
    private String okmsg;
    @Schema(type = "string", example = " ")
    private String boardNo;


    //log 작성
    @Schema(type = "string", example = " ")
    private String actId;
    @Schema(type = "string", example = " ")
    private String fileSize;
    @Schema(type = "string", example = " ")
    private String fileNm;
    @Schema(type = "string", example = " ")
    private String useType;


    //mail
    @Schema(type = "string", example = " ")
    private String title;
    @Schema(type = "string", example = " ")
    private String contents;
    @Schema(type = "string", example = " ")
    private String sendemail;
    @Schema(type = "string", example = " ")
    private String sendEeno;
    @Schema(type = "string", example = " ")
    private String sendNm;

}


