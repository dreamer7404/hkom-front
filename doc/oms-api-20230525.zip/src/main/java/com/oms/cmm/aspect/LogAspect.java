package com.oms.cmm.aspect;

import javax.servlet.http.HttpServletRequest;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.stereotype.Component;
import org.springframework.util.StopWatch;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import com.oms.cmm.utils.Utils;
import com.oms.sys.dao.LogDAO;
import com.oms.sys.model.LogUse;

import lombok.RequiredArgsConstructor;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @author 안경수
 * @since 2023. 5. 23.
 * @see
 */
@Aspect
@RequiredArgsConstructor
@Component
public class LogAspect {

    private final LogDAO logDAO;

    @Around("("
            + "    execution(* com.oms.ivm.controller..*(..)) "
            + " || execution(* com.oms.mri.controller..*(..)) "
            + " || execution(* com.oms.print.controller..*(..)) "
            + " || execution(* com.oms.stm.controller..*(..)) "
            + " || execution(* com.oms.sys.controller..*(..))"
            + ") "
            + " && !execution(* com.oms.sys.controller.AuthController.login*(..)) "
            + " && !execution(* com.oms.sys.controller.UsrMgmtController.initUserPw*(..)) "
            + " && !execution(* com.oms.sys.controller.PgmMgmtController.selectPgmMgmtList*(..)) "
            + " && !execution(* com.oms.sys.controller.UsrMgmtController.selectUsrMgmt*(..)) "
            + " && !execution(* com.oms.sys.controller.LogController.selectLogUseList*(..)) "
    )
    public Object logMethodExecutionTime(ProceedingJoinPoint proceedingJoinPoint) throws Throwable{

        // userEeno
        final HttpServletRequest request = ((ServletRequestAttributes) RequestContextHolder.currentRequestAttributes()).getRequest();
        String userEeno = Utils.getUserEeno(request);

        // uri
        String uri = request.getRequestURI();

        String cmd = Utils.getMethod(request) ;

        // className, methodName
        MethodSignature methodSignature = (MethodSignature) proceedingJoinPoint.getSignature();
        String className = methodSignature.getDeclaringType().getSimpleName();
        String methodName = methodSignature.getName();

        final StopWatch stopWatch = new StopWatch();
        stopWatch.start();
        Object result = proceedingJoinPoint.proceed();
        stopWatch.stop();

        // log 저장
        logDAO.insertLogUse(new LogUse(
                userEeno == null ? "" : userEeno,
                uri.substring(4),
                cmd.isBlank() ? "select" : cmd,
                className,
                methodName,
                (int)stopWatch.getTotalTimeMillis()
                ));

//        System.out.println("@@@@@@@@@@@ @@@@@@@@ "
//                + "userEeno: " + userEeno + ", "
//                + className + "." +  methodName  // Method Name
//                + " ( " + uri + " )" + uri.substring(4) + "[" + stopWatch.getTotalTimeMillis() + "ms]");

        return result;
    }





}
