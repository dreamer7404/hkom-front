package com.oms.sys.service;

import java.util.List;

import com.oms.sys.dto.ApiMgmtReqDTO;
import com.oms.sys.dto.ApiMgmtResDTO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @author 안경수
 * @since 2023. 5. 19.
 * @see
 */


public interface ApiMgmtService {
    List<ApiMgmtResDTO> selectApiMgmtList();
    int insertApiMgmt(ApiMgmtReqDTO apiMgmtReqDTO);
    int updateApiMgmt(ApiMgmtReqDTO apiMgmtReqDTO);
    int deleteApiMgmt(List<String> list);
    ApiMgmtResDTO selectApiMgmt(String apiUrl);
}

