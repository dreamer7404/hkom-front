package com.oms.sys.service;

import com.oms.sys.dto.UsrTokenReqDTO;
import com.oms.sys.dto.UsrTokenResDTO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @author 안경수
 * @since 2023. 4. 20.
 * @see
 */

public interface UsrTokenService {
    public UsrTokenResDTO selectUsrToken(UsrTokenReqDTO usrTokenReqDTO) throws Exception;
    public Integer insertUsrToken(UsrTokenReqDTO usrTokenReqDTO) throws Exception;
    public Integer updateUsrToken(UsrTokenReqDTO usrTokenReqDTO) throws Exception;
}
