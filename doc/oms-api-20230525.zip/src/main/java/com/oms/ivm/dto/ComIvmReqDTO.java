package com.oms.ivm.dto;

import java.util.Set;

import org.apache.ibatis.type.Alias;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.oms.common.dto.CommReqDTO;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @author 김정웅
 * @since 2023. 3. 17.
 * @see
 */
@Alias("comIvmReqDTO")
@Data
@AllArgsConstructor
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown =true)
public class ComIvmReqDTO extends CommReqDTO {



    private String userEeno;        //사용자 ID
    private String dlExpdCoCd;      //사용자 회사코드
    private String vehlCd;          //차종코드
    private String qltyVehlCd;      //차종코드
    private String qltyVehlNm;      //차종코드명
    private String vehlCds;         //차종코드(다중 선택)
    private String key;             //
    private String sDate;           //검색조건 시작일
    private String eDate;           //검색조건 종료일
    private String bDate;           //검색조건 기준일
    private String dlExpdPrvsNm;    //언어지역명
    private String language;        //언어코드 ex) EU(영어/미국) 등..
    private String langCd;          //언어코드 ex) EU(영어/미국) 등..
    private String langCdNm;        //언어코드명
    private Set<String> langCds;    //언어코드 다중 선택
    private String year;            //연식?
    private String mdlMdyCd;        //연식
    private String dlExpdMdlMdyCd;  //연식
    private String region;          //지역코드 ex) 유럽, 북미 등..
    private String dlExpdPdiCd;     //공장코드 ex) 아산, 광주2 등..
    private String dlExpdRegnCd;    //지역코드 ex) 유럽, 북미 등..
    private String mode;            //검색조건 화면 옵션 (언어별분석, 일자별분석 등..)
    private String dataSn;          //dataSn
    private String newPrntPbcnNo;   //발간번호
    private String dlvtState;       //배송여부

    private Set<String> dataSns;    //dataSn 다중선택시

    private String menuGubun;       //공통화면의 경우, PDI 또는 세원 구분값
}
