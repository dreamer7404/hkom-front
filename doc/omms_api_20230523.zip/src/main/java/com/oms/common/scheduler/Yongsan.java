package com.oms.common.scheduler;

import java.lang.management.ManagementFactory;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.oms.cmm.utils.Utils;
import com.oms.common.dao.CommDAO;
import com.oms.common.dto.YongsanIvDTO;
import com.oms.common.dto.YongsanVehlDTO;
import com.oms.sys.dao.LogDAO;
import com.oms.sys.dto.SchedLogDTO;

import lombok.RequiredArgsConstructor;
import net.javacrumbs.shedlock.spring.annotation.SchedulerLock;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @author 안경수
 * @since 2023. 5. 18.
 * @see
 */
//@EnableScheduling
@RequiredArgsConstructor
@Component
public class Yongsan {

    private final CommDAO commDao;
    private final LogDAO logDAO;

    private final String baseUrl = "http://gpdi.yongsan.biz/jsp/api/";
    private final String baseInfo = "vehicle.jsp";
    private final String stockInfo = "stock.jsp";
    private final String sessionId = "a0235e76039bc559d1aa9b9b057463ca6174b6b5";


//    @Scheduled(fixedRate = 3000)
//    @SchedulerLock(name="SchedulerLock",    lockAtMostFor = "PT10S", lockAtLeastFor = "PT10S")
//    public void run1() {
//        System.out.println("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ 1111111111111111");
//    }
//
//    @Scheduled(fixedRate = 3000)
//    @SchedulerLock(name="SchedulerLock",    lockAtMostFor = "PT10S", lockAtLeastFor = "PT10S")
//    public void run2() {
//        System.out.println("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ 2222222222222222222");
//
//    }

//    @Scheduled(initialDelay = 1000 * 2, fixedDelay=Long.MAX_VALUE)
    public void runVehl() {

        RestTemplate restTemplate = new RestTemplate();

        String url = baseUrl + baseInfo
                + "?session_id=" + sessionId
                + "&company=all";

        try {
            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_JSON);

            HttpEntity<?> entity = new HttpEntity<>(headers);
            ResponseEntity<String> responseEntity = restTemplate.exchange(url, HttpMethod.POST, entity, String.class);

//            result.put("statusCode", responseEntity.getStatusCodeValue()); //http status code를 확인
//            result.put("header", responseEntity.getHeaders()); //헤더 정보 확인
//            result.put("body", responseEntity.getBody());

            ObjectMapper mapper = new ObjectMapper();
//            jsonInString = mapper.writeValueAsString(responseEntity.getBody());

            mapper.configure(DeserializationFeature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT, true);
            YongsanVehlDTO dto = mapper.readValue(responseEntity.getBody(), YongsanVehlDTO.class);

            System.out.println("### " + dto.getResult());
            System.out.println("### " + dto.getListCount());
            System.out.println("### " + dto.getList().get(0).getVehlNM());


            int result = commDao.insertYongsanVehlInfoIf(dto.getList());

            System.out.println("### resultCount: " + result);

        } catch (JsonProcessingException  e) {
            e.printStackTrace();
        }


    }

//    @Scheduled(initialDelay = 1000 * 2, fixedDelay=Long.MAX_VALUE)
    public void runStock() {

        String jvmId = ManagementFactory.getRuntimeMXBean().getName();

        RestTemplate restTemplate = new RestTemplate();

        String startTime = Utils.getDateTime(); // 시작시간
        String ymd = Utils.getYmd(); // YMD

        String apiUrl = baseUrl + stockInfo
                + "?session_id=" + sessionId
                + "&base_dt=" + ymd
                + "&company=all"
//                + "&vehl_cd=ARC22"
                ;

        try {
            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_JSON);

            HttpEntity<?> entity = new HttpEntity<>(headers);
            ResponseEntity<String> responseEntity = restTemplate.exchange(apiUrl, HttpMethod.POST, entity, String.class);

            ObjectMapper mapper = new ObjectMapper();
            mapper.configure(DeserializationFeature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT, true);
            YongsanIvDTO dto = mapper.readValue(responseEntity.getBody(), YongsanIvDTO.class);

            dto.getList().stream().forEach(item -> System.out.println(item.toString()));

            // apl_ymd 입력
            dto.getList().stream().forEach(item -> item.setAplYmd(ymd));


            // 데이타 저장
            int saveCnt = commDao.insertYongsanIvInfoIf(dto.getList());

            // 로그저장
            SchedLogDTO schedLogDTO = new SchedLogDTO();
            schedLogDTO.setSchedId("iv");
            schedLogDTO.setSchedNm("용산재고조회");
            schedLogDTO.setStartDtm(startTime);
            schedLogDTO.setApiUrl(apiUrl);
            schedLogDTO.setGetDataCnt(dto.getList().size());
            schedLogDTO.setSaveDataCnt(saveCnt);
            schedLogDTO.setCallRslt(dto.getResult());
            int result = logDAO.insertSchedLog(schedLogDTO);

        } catch (JsonProcessingException  e) {
            e.printStackTrace();
        }
    }
}
