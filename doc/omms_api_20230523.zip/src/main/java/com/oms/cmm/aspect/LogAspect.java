package com.oms.cmm.aspect;

import javax.servlet.http.HttpServletRequest;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.stereotype.Component;
import org.springframework.util.StopWatch;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import com.oms.cmm.utils.Utils;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @author 안경수
 * @since 2023. 5. 23.
 * @see
 */
@Aspect
@Component
public class LogAspect {

    @Around(
            "(execution(* com.oms.sys.controller..*(..)) "
                    + " || execution(* com.oms.stm.controller..*(..))) "
//                    + " && !execution(* com.oms.sys.controller.AuthController.login*(..)) "
//                    + " && !execution(* com.oms.sys.controller.UserMgmtController.initUserPw*(..)) "

//            + " || execution(* com.oms.sys.controller..*(..)) "
            )
    public Object logMethodExecutionTime(ProceedingJoinPoint proceedingJoinPoint) throws Throwable{

        String userEeno = "";
        final HttpServletRequest request = ((ServletRequestAttributes) RequestContextHolder.currentRequestAttributes()).getRequest();
        userEeno = Utils.getUserEeno(request);

        MethodSignature methodSignature = (MethodSignature) proceedingJoinPoint.getSignature();

        String className = methodSignature.getDeclaringType().getSimpleName();
        String methodName = methodSignature.getName();

        final StopWatch stopWatch = new StopWatch();
        stopWatch.start();

        Object result = proceedingJoinPoint.proceed();
        stopWatch.stop();

        System.out.println("@@@@@@@@@@@ @@@@@@@@ "
                + "userEeno: " + userEeno + ", "
                + className + "." +  methodName  // Method Name
                + ":: " + stopWatch.getTotalTimeMillis() + " ms");


        return result;
    }
}
