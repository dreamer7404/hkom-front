package com.oms.cmm.utils;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Function;
import java.util.function.Predicate;

import javax.servlet.http.HttpServletRequest;

import org.springframework.util.ResourceUtils;

import com.oms.cmm.global.Consts;
import com.oms.cmm.security.JwtTokenProvider;

import lombok.experimental.UtilityClass;
import lombok.extern.slf4j.Slf4j;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @author 안경수
 * @since 2023. 1. 19.
 * @see
 */

@Slf4j
@UtilityClass
public class Utils {



    public static boolean isNull(Object obj) {
        if(obj == null) return true;
        if ((obj instanceof String) && (((String)obj).trim().length() == 0)) { return true; }
        if (obj instanceof Map) { return ((Map<?, ?>) obj).isEmpty(); }
        if (obj instanceof Map) { return ((Map<?, ?>)obj).isEmpty(); }
        if (obj instanceof List) { return ((List<?>)obj).isEmpty(); }
        if (obj instanceof Object[]) { return (((Object[])obj).length == 0); }
        return false;
    }

    public static String getMethod(HttpServletRequest request) {
        String method = request.getHeader(Consts.METHOD);
        return method == null ? "" : method;
    }

    public static String getRemoteAddress(HttpServletRequest request) {
        String ip = request.getHeader(Consts.X_FORWARDED_FOR);
        return (ip != null) ? ip : request.getRemoteAddr();
    }

    // 사원번호
    public static String getUserEeno(HttpServletRequest request) {
        String token = request.getHeader(Consts.X_AUTH_TOKEN);
        return (token != null && !token.isEmpty()) ? new JwtTokenProvider().getMapInfo(token, Consts.CLAIM_USER_EENO) : null;
    }

    // 회사코드
    public static String getDlExpdCoCd(HttpServletRequest request) {
        String token = request.getHeader(Consts.X_AUTH_TOKEN);
        return (token != null && !token.isEmpty()) ? new JwtTokenProvider().getMapInfo(token, Consts.CLAIM_BLNS_CO_CD) : null;
    }

    // 권하그룹코드
    public static String getDlExpdGCd(HttpServletRequest request) {
        String token = request.getHeader(Consts.X_AUTH_TOKEN);
        return (token != null && !token.isEmpty()) ? new JwtTokenProvider().getMapInfo(token, Consts.CLAIM_GRP_CD) : null;
    }

    // 임시 비번생성
    public static String createPassword() {
        String temp1 = Long.toString(System.currentTimeMillis());
        int size = temp1.length();
        String pw = new String();
        for (int i = 0; i < size; i++) {
            int val = Integer.parseInt(temp1.substring(i, i + 1));
            if (i < 5) {
                val = val + Integer.parseInt(temp1.substring(size - (1 + i), size - i));
            }
            int temp2 = val % 3;
            int temp3 = (val + 15) % 26;
            if (temp2 == 0) {
                pw += (char) (temp3 + 65);
            } else if (temp2 == 1) {
                pw += (char) (temp3 + 97);
            } else {
                pw += String.format("%d", temp2);
            }
        }
        return pw;
    }

    public static <T> Predicate<T> distinctByKey( Function<? super T, Object> keyExtractor) {
        Map<Object, Boolean> map = new ConcurrentHashMap<>();
        return t -> map.putIfAbsent(keyExtractor.apply(t), Boolean.TRUE) == null;
    }

    public static String getEmailContent(String filename) throws IOException {
        File file = ResourceUtils.getFile("classpath:templates/" + filename + ".html");
        return new String(Files.readAllBytes(file.toPath())).replace("\r\n", "");
    }

    public static String getYmd() {
//        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
//        Calendar c1 = Calendar.getInstance();
//        return sdf.format(c1.getTime());
        LocalDateTime startDateTime = LocalDateTime.now();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyyMMdd");
        return startDateTime.format(formatter);
    }
    public static String getDateTime() {

        LocalDateTime startDateTime = LocalDateTime.now();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
//        java.util.Date parsedDate = (Date) formatter.parse("2023-05-19 10:30:00");
//        return new Timestamp(parsedDate.getTime());

        return startDateTime.format(formatter);

    }

}
