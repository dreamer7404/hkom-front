package com.oms.sys.dao;

import com.oms.sys.dto.SchedLogDTO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @author 안경수
 * @since 2023. 3. 13.
 * @see
 */

public interface LogDAO {
    int insertSchedLog(SchedLogDTO schedLogDTO);
    int selectYongsanIvInfoIfCnt();
}
