package com.oms.sys.dao;

import java.util.List;

import com.oms.sys.dto.ApiMgmtReqDTO;
import com.oms.sys.dto.ApiMgmtResDTO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @author 안경수
 * @since 2023. 3. 13.
 * @see
 */

public interface ApiMgmtDAO {

    List<ApiMgmtResDTO> selectApiMgmtList();
    int insertApiMgmt(ApiMgmtReqDTO apiMgmtReqDTO);
    int updateApiMgmt(ApiMgmtReqDTO apiMgmtReqDTO);
    int deleteApiMgmt(List<String> list);
    ApiMgmtResDTO selectApiMgmt(String apiUrl);
}
