package com.oms.sys.dto;

import java.util.List;

import org.apache.ibatis.type.Alias;

import lombok.Data;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @author 안경수
 * @since 2023. 5. 23.
 * @see
 */
@Alias("apiMgmtReqDTO")
@Data
public class ApiMgmtReqDTO {
    private String apiUrl;
    private String apiNm;
    private String apiType;
    private String menuId;

    private String userEeno;
    private List<String> apiUrls;
}
