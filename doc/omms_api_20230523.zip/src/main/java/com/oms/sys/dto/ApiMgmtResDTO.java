package com.oms.sys.dto;

import org.apache.ibatis.type.Alias;

import lombok.Data;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @author 안경수
 * @since 2023. 5. 23.
 * @see
 */
@Alias("apiMgmtResDTO")
@Data
public class ApiMgmtResDTO {
    private String apiUrl;
    private String apiNm;
    private String apiType;
    private String menuId;

    private String pgmNm;

}
