package com.oms.sys.service;

import com.oms.sys.dto.SchedLogDTO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @author Windows i¿½i¿½i¿½i¿½i¿½
 * @since 2023. 5. 19.
 * @see
 */


public interface LogService {
    int insertSchedLog(SchedLogDTO schedLogDTO);
}
