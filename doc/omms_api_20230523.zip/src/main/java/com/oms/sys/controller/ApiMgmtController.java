package com.oms.sys.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.oms.cmm.global.Consts;
import com.oms.cmm.utils.Utils;
import com.oms.sys.dto.ApiMgmtReqDTO;
import com.oms.sys.dto.ApiMgmtResDTO;
import com.oms.sys.service.ApiMgmtService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @author 안경수
 * @since 2023. 5. 23.
 * @see
 */
@Tag(name = "ApiMgmtController", description = "")
@RequiredArgsConstructor
@RestController
@RequestMapping("/api")
public class ApiMgmtController {

    /**
     * 클래스 Injection
     */
    private final ApiMgmtService apiMgmtService;
    private final HttpServletRequest request;

    /**
     * API관리 목록을 조회
     */
    @Operation(summary = "API관리 목록 조회 ")
    @GetMapping("/apiMgmts")
    public List<ApiMgmtResDTO> selectApiMgmtList() throws Exception {
        return apiMgmtService.selectApiMgmtList();
    }


    /**
     * API 수정, 추가
     */
    @Operation(summary = "API 수정, 추가 ")
    @PostMapping("/apiMgmt")
    public int apiMgmt(@RequestBody ApiMgmtReqDTO apiMgmtReqDTO) throws Exception {
        int result = 0;
        apiMgmtReqDTO.setUserEeno(Utils.getUserEeno(request));
        String method = Utils.getMethod(request);

        try {
            // 등록
            if(method.equals(Consts.INSERT)) {
                ApiMgmtResDTO apiMgmtResDTO = apiMgmtService.selectApiMgmt(apiMgmtReqDTO.getApiUrl());
                if(apiMgmtResDTO != null) {
                    return -2;
                }
                result = apiMgmtService.insertApiMgmt(apiMgmtReqDTO);
            }else if(method.equals(Consts.UPDATE)) {
                result = apiMgmtService.updateApiMgmt(apiMgmtReqDTO);
            }else  if(method.equals(Consts.DELETE)) {
                result = apiMgmtService.deleteApiMgmt(apiMgmtReqDTO.getApiUrls());
            }

        }catch(Exception e) {
            return -1;
        }
        return result;

    }





}
