package com.oms.sys.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServletRequest;

import able.cloud.core.web.HController;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.oms.cmm.global.Consts;
import com.oms.cmm.utils.Utils;
import com.oms.common.dto.CommReqDTO;
import com.oms.sys.dto.AuthAffrMgmtReqDTO;
import com.oms.sys.dto.AuthAffrMgmtResDTO;
import com.oms.sys.dto.PgmMgmtReqDTO;
import com.oms.sys.dto.PgmMgmtResDTO;
import com.oms.sys.dto.UseYnReqDTO;
import com.oms.sys.model.AuthAffrMgmt;
import com.oms.sys.service.PgmMgmtService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;


/**
 * <pre>
 * PgmMgmtController
 * </pre>
 *
 * @ClassName   : PgmMgmtController.java
 * @Description :
 * @author 안경수
 * @since 2023.1.19
 * @see
 */
@Tag(name = "PgmMgmtController", description = "")
@RequiredArgsConstructor
@RestController
@RequestMapping("/api")
public class PgmMgmtController extends HController {

    /**
     * 클래스 Injection
     */
    private final PgmMgmtService pgmMgmtService;
    private final HttpServletRequest request;

    /**
     * ********************* 메뉴관리 ***********************************************************
     */

    /**
     * 메뉴 목록을 조회
     */
    @Operation(summary = "프로그램 목록을 조회")
    @GetMapping("/pgmMgmtsAll")
    public Map<String, List> selectPgmMgmtListAll() throws Exception {
        List<PgmMgmtResDTO> list = pgmMgmtService.selectPgmMgmtListAll();

        List<PgmMgmtResDTO> grpList = list.stream().filter(d -> d.getPgmIdSn() == 0 ).collect(Collectors.toList());
        List<PgmMgmtResDTO> menuList = list.stream().filter(d -> d.getPgmIdSn() != 0 ).collect(Collectors.toList());

        // menuList에 그룹명 추가
        for(PgmMgmtResDTO grpDTO: grpList) {
            for(PgmMgmtResDTO menuDTO: menuList) {
                if(grpDTO.getPgmId().equals(menuDTO.getPgmId())){
                    menuDTO.setGrpNm(grpDTO.getPgmNm());
                }
            }
        }

        Map<String, List> map = new HashMap<>();
        map.put("grpList", grpList);    // 메뉴그룹
        map.put("menuList", menuList);  // 메뉴

        return map;
    }


    /**
     * 메뉴 목록을 조회 by 사용자별 권한
     */
    @Operation(summary = "프로그램 목록을 조회")
    @GetMapping("/pgmMgmts")
    public List<PgmMgmtResDTO> selectPgmMgmtList(@ModelAttribute CommReqDTO commReqDTO) throws Exception {
        commReqDTO.setUserEeno(Utils.getUserEeno(request));
        List<PgmMgmtResDTO> list = pgmMgmtService.selectPgmMgmtList(commReqDTO);
        return list;
    }

    /**
     * 메뉴 수정/저장
     */
    @Operation(summary = "프로그램 관리 저장", description = "")
    @PostMapping(value = "/pgmMgmt")
    public Integer pgmMgmt(@RequestBody PgmMgmtReqDTO dto)  throws Exception {
        int result = 0;
        String method = Utils.getMethod(request);

//        if(method.equals(Consts.INSERT)) {
//              result += pgmMgmtService.insertPgmMgmt(dto);
//        } else if (method.equals(Consts.UPDATE)) {
//              result +=pgmMgmtService.updatePgmMgmt(dto);
//        } else if (method.equals(Consts.DELETE)) {
//              result +=pgmMgmtService.deletePgmMgmt(dto);
//        }

        return result;
    }



    /**
     * ********************* 권한관리 ***********************************************************
     */

    /**
     * 사용자 그룹권한 목록 조회
     */
    @Operation(summary = "사용자 그룹권한 목록 조회")
    @GetMapping("/usrGrps")
    public List<PgmMgmtResDTO> usrGrps() throws Exception {

        List<PgmMgmtResDTO> list = pgmMgmtService.selectGrpUsrList();
        return list;
    }


//    /**
//     * 프로그램 권한 관리 저장
//     */
//    @Operation(summary = "프로그램 권한 관리저장", description = "")
//    @Parameter(in = ParameterIn.HEADER, name="_method")
//    @PostMapping(value = "/pgmAuth")
//   public Integer pgmAuth(@RequestBody PgmMgmtReqDTO dto)  throws Exception {
//        int result = 0;
//        dto.setUserEeno(Utils.getUserEeno(request));
//        result = pgmMgmtService.deletePgmGrpAuth(dto);  // 권한 삭제 후 저장.....
//        List<PgmMgmtReqDTO> gridList = dto.getGridList();
//        for(int i=0; i< gridList.size() ; i++){
//            result = pgmMgmtService.insertPgmGrpAuth(dto);  // 프로그램 권한등록
//        }
//        return result;
//    }

    @Operation(summary = "사용여부 변경")
    @PostMapping("/changePgmMgmtUseYn")
    public Integer updatePgmMgmtUseYn(@RequestBody UseYnReqDTO useYnReqDTO)throws Exception {
        int result = 0;
        if(Utils.getMethod(request).equals(Consts.UPDATE)) {
            result = pgmMgmtService.updatePgmMgmtUseYn(useYnReqDTO);
        }
        return result;
    }


    /**
     * 메뉴별 권한 목록을  콤보조회용
     */
    @Operation(summary = "메뉴별 권한 목록을  콤보조회용")
    @GetMapping("/comboAuthAffrMgmt")
    public List<AuthAffrMgmtResDTO> comboAuthAffrMgmt(@ModelAttribute AuthAffrMgmtReqDTO authAffrMgmtReqDTO) throws Exception {

        List<AuthAffrMgmtResDTO> list = pgmMgmtService.selectAuthAffrMgmtList(authAffrMgmtReqDTO);

        // 콤보용 따로
        return list.stream()
                    .filter(Utils.distinctByKey(AuthAffrMgmtResDTO::getPgmId))
                    .collect(Collectors.toList());
    }

    /**
     * 메뉴별 권한 목록을 조회 /특정메뉴 수정
     */
    @Operation(summary = "메뉴별 권한 목록을 조회/특정메뉴 수정")
    @GetMapping("/authAffrMgmts")
    public Map<String, List<AuthAffrMgmtResDTO>> selectAuthAffrMgmtList(@ModelAttribute AuthAffrMgmtReqDTO authAffrMgmtReqDTO) throws Exception {

        List<AuthAffrMgmtResDTO> list = pgmMgmtService.selectAuthAffrMgmtList(authAffrMgmtReqDTO);



        // 그룹메뉴만 가져옴
        List<AuthAffrMgmtResDTO> grpList = list.stream()
                    .filter(d -> d.getPgmIdSn() == 0)
                    .collect(Collectors.toList());



        // null인것 따로
        List<AuthAffrMgmtResDTO> nullList = list.stream()
                .filter(d -> d.getMenuId() == null)
                .collect(Collectors.toList());


        // menu_id 중복제거
        List<AuthAffrMgmtResDTO> menuList = list.stream()
                    .filter(d -> d.getPgmIdSn() != 0 && d.getMenuId() != null)
                    .filter(Utils.distinctByKey(AuthAffrMgmtResDTO::getMenuId))
                    .collect(Collectors.toList());

        // null 다시 추가
        menuList.addAll(nullList);

        // grpNm 변경
        menuList.forEach(dto -> dto.setGrpNm(dto.getGrpNm() + "-" + dto.getMenuAuthCd()));

        // menuList에 그룹명 입력
        for(AuthAffrMgmtResDTO grpDTO: grpList) { // grp
            for(AuthAffrMgmtResDTO menuDTO: menuList) {
                if(menuDTO.getGrpPgmNm() == null && grpDTO.getPgmId().equals(menuDTO.getPgmId())){
                    menuDTO.setGrpPgmNm(grpDTO.getPgmNm()); // 메뉴그룹명
                }
            }
        }

        // menuList에 권한그룹 목록 추가
        for(AuthAffrMgmtResDTO DTO: list) { // all
            for(AuthAffrMgmtResDTO menuDTO: menuList) {
                if(menuDTO.getGrpCd() == null) {
                    menuDTO.setGrpNm("");
                }
                else if(menuDTO.getMenuId().equals(DTO.getMenuId()) && !menuDTO.getGrpNm().contains(DTO.getGrpNm())){
                    menuDTO.setGrpNm(menuDTO.getGrpNm() + ", " + DTO.getGrpNm() + "-" + DTO.getMenuAuthCd()); // 권한그룹명
                }
            }
        }


        Map<String, List<AuthAffrMgmtResDTO>> resultMap = new HashMap<>();
        resultMap.put("grpList", grpList);    // 메뉴그룹
        resultMap.put("menuList", menuList);  // 메뉴
        return resultMap;


    }

    /**
     * 그룹별 권한 목록을 조회
     */
    @Operation(summary = "그룹별 권한 목록을 조회")
    @GetMapping("/authAffrMgmtsForGrp")
    public List<AuthAffrMgmtResDTO> selectAuthAffrMgmtListForGrp(@ModelAttribute AuthAffrMgmtReqDTO authAffrMgmtReqDTO) throws Exception {
        List<AuthAffrMgmtResDTO> list = pgmMgmtService.selectAuthAffrMgmtList(authAffrMgmtReqDTO);
        return list;
    }

    @Operation(summary = "그룹별 권한 목록을 조회")
    @GetMapping("/authAffrMgmtsByGrp")
    public List<AuthAffrMgmtResDTO> selectAuthAffrMgmtListByGrp(@ModelAttribute AuthAffrMgmtReqDTO authAffrMgmtReqDTO) throws Exception {
        List<AuthAffrMgmtResDTO> list = pgmMgmtService.selectAuthAffrMgmtListByGrp(authAffrMgmtReqDTO);
        return list;
    }




    /**
     * 메뉴별 권한 목록을 조회
     */
    @Operation(summary = "메뉴별 권한 ")
    @GetMapping("/authAffrMgmt")
    public List<AuthAffrMgmtResDTO> selectAuthAffrMgmt(@ModelAttribute AuthAffrMgmtReqDTO authAffrMgmtReqDTO) throws Exception {
        return pgmMgmtService.selectAuthAffrMgmt(authAffrMgmtReqDTO);
    }

    /**
     * 메뉴별 권한 목록을 조회 /특정메뉴 수정
     */
    @Operation(summary = "메뉴별/그룹별 권한 수정")
    @PostMapping("/authAffrMgmt")
    public Integer updateAuthAffrMgmt(@RequestBody  AuthAffrMgmtReqDTO dto) throws Exception {
        int result = 0;
        AuthAffrMgmt authAffrMgmt = new AuthAffrMgmt();

        if(Utils.getMethod(request).equals(Consts.UPDATE) ) {
            // 메뉴별 수정
            if(dto.getMenuId() != null) {

                // 삭제
                authAffrMgmt.setMenuId(dto.getMenuId());
                result = pgmMgmtService.deleteAuthAffrMgmt(authAffrMgmt);

                if(result > -1) {
                    String pprrEeno = Utils.getUserEeno(request);

                    List<AuthAffrMgmt> selectedList = dto.getList().stream()
                            .filter(item -> item.getSelected())
                            .collect(Collectors.toList());

                    // pprr 입력
                    selectedList.forEach(item -> item.setPprrEeno(pprrEeno));

                    // 새로저장
                    result = pgmMgmtService.insertAuthAffrMgmt(selectedList);
                }
            }
            // 권한그룹별 수정
            else if(dto.getGrpCd() != null) {
                // 삭제
                authAffrMgmt.setGrpCd(dto.getGrpCd());
                result = pgmMgmtService.deleteAuthAffrMgmt(authAffrMgmt);
                if(result > -1) {
                    String pprrEeno = Utils.getUserEeno(request);

                    // pprr 입력
                    dto.getList().forEach(item -> item.setPprrEeno(pprrEeno));

                    // 새로저장
                    result = pgmMgmtService.insertAuthAffrMgmt(dto.getList());
                }
            }
        }
        return result;
    }









}
