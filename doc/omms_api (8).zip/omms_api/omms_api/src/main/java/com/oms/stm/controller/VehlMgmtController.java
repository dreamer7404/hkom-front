package com.oms.stm.controller;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import able.cloud.core.web.HController;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.oms.common.dto.CommReqDTO;
import com.oms.common.service.CommService;
import com.oms.stm.dto.StmComReqDTO;
import com.oms.stm.dto.VehlMgmtReqDTO;
import com.oms.stm.dto.VehlMgmtResDTO;
import com.oms.stm.service.VehlMgmtService;
import com.oms.sys.dto.UsrMgmtReqDTO;
import com.oms.sys.service.UsrMgmtService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
/**
 * <pre>
 * Statements
 * </pre>
 * @ClassName : VehlMgmtController.java
 * @Description :
 * @author 김경훈
 * @since 2023. 3. 13.
 * @see
 */
@Tag(name = "VehlMgmtController", description = "")
@CrossOrigin(origins="*")
@RequiredArgsConstructor
@RestController
@RequestMapping("/api")
public class VehlMgmtController extends HController {
    /**
     * 클래스 Injection
     */
    private final VehlMgmtService vehlMgmtService;

    private final UsrMgmtService usrService;
    private final CommService commonService;



    @Operation(summary = "차종 조회")
    @GetMapping("/selectVehlMgmtList")
    public  VehlMgmtResDTO  selectVehlMgmtList(@ModelAttribute StmComReqDTO dto) throws Exception {

        VehlMgmtResDTO resDto = new VehlMgmtResDTO();
        CommReqDTO comDto = new CommReqDTO();

        dto.setUserId("H2302603"); //토큰 사용자
        List<VehlMgmtResDTO> vehlList = vehlMgmtService.selectVehlMgmtList(dto);
        resDto.setVehlList(vehlList);

        List<VehlMgmtResDTO> vehlCombo = vehlMgmtService.getVehlCombo(dto);// 차종 콤보박스
        resDto.setVehlCombo(vehlCombo);
        List<VehlMgmtResDTO> pdiCombo = vehlMgmtService.getPdiCombo(dto); //pdi콤보박스
        resDto.setPdiCombo(pdiCombo);
//        List<HMap> cpVehlList = vehlMgmtService.selectCpyTgVehl(hmap); 차종 복사 조회리스트
        comDto.setDlExpdGCd("0008");
        List<VehlMgmtResDTO> RegnClumList = commonService.selectCodeList(comDto); //지역 구분 코드리스트




        dto.setCol1("X");
        dto.setCol2("X");
        dto.setCol3("X");
        dto.setCol4("X");
        dto.setCol5("X");
        dto.setCol6("X");
        dto.setCol7("X");

        for (int i = 0 ; i < RegnClumList.size() ; i++ ) {
            String col = "col"+(i+1);
            String colRegn = RegnClumList.get(i).getDlExpdPrvsCd();
            if( "col1".equals(col)){  dto.setCol1(colRegn);}
            if( "col2".equals(col)){  dto.setCol2(colRegn);}
            if( "col3".equals(col)){  dto.setCol3(colRegn);}
            if( "col4".equals(col)){  dto.setCol4(colRegn);}
            if( "col5".equals(col)){  dto.setCol5(colRegn);}
            if( "col6".equals(col)){  dto.setCol6(colRegn);}
            if( "col7".equals(col)){  dto.setCol7(colRegn);}
        }



        return resDto;

    }

    @Operation(summary = "기존 차종 연식별 조회(콤보박스)")
    @GetMapping("/cpVehlList")
    public  HashMap<String, Object>  cpVehlList(@ModelAttribute StmComReqDTO dto) throws Exception {

        HashMap<String ,Object> resultMap = new HashMap<String, Object>();

        dto.setUserId("H2302603"); //토큰 사용자
        String userId =   dto.getUserId();
        String c2qltyVehlCd = dto.getC2qltyVehlCd();

        List<VehlMgmtResDTO> cpVehlList = vehlMgmtService.selectCpyTgVehl(dto);

        resultMap.put("cpVehlList", cpVehlList);
        resultMap.put("c2qltyVehlCd", c2qltyVehlCd);

        return resultMap;
    }


    @Operation(summary = "차종별 언어 복사")
    @GetMapping("/cpVehlLang")
    public  HashMap<String, Object>  cpVehlLang(@ModelAttribute VehlMgmtReqDTO vehlReqDTO) throws Exception {

        HashMap<String ,Object> resultMap = new HashMap<String, Object>();

        vehlReqDTO.setUserId("H2302603"); //토큰 사용자
        String userId =   vehlReqDTO.getUserId();
        String valCd = vehlReqDTO.getC2qltyVehlNm();
        String[] arr = valCd.split("-");
        String qltyVehlCd =arr[0];
        String mdlMdyCd =arr[1];
        vehlReqDTO.setQltyVehlCd(qltyVehlCd);
        vehlReqDTO.setMdlMdyCd(mdlMdyCd);

        vehlMgmtService.deleteVehlLangCp(vehlReqDTO); // 복사전 삭제
        vehlMgmtService.insertVehlLangCopy(vehlReqDTO); // 언어코드 복사

        vehlMgmtService.deleteVehlNatlLang(vehlReqDTO); // 복사전 삭제
        vehlMgmtService.insertVehlNatlLangCpy(vehlReqDTO); // 국가별 언어코드 복사


        List<VehlMgmtResDTO> cpVehlNatlList = vehlMgmtService.selectCpyTgNatlVehl(vehlReqDTO);


        for(int i=0; i< cpVehlNatlList.size(); i++){

            String c1qltyVehlCd = vehlReqDTO.getC1qltyVehlCd();
            String dlExpdNatCd = cpVehlNatlList.get(i).getDlExpdNatCd();
            String dlExpdRegnCd = cpVehlNatlList.get(i).getDlExpdRegnCd();
            vehlReqDTO.setQltyVehlCd(c1qltyVehlCd);
            vehlReqDTO.setDlExpdNatCd(dlExpdNatCd);
            vehlReqDTO.setDlExpdRegnCd(dlExpdRegnCd);

            String vehlChk  = vehlMgmtService.selectNatlVehlChk(vehlReqDTO);

            if("N".equals(vehlChk)){
                vehlMgmtService.insertNatlVehlMgmt(vehlReqDTO);  // 국가별 차량코드 등록
            }
        }
        return resultMap;
    }



    @Operation(summary = "상세조회")
    @GetMapping("/vehlMgmtDetail")
    public HashMap<String, Object>  vehlMgmtDetail(@ModelAttribute StmComReqDTO dto, HttpServletRequest request) throws Exception {

        HashMap<String,Object> resultMap = new HashMap<String, Object>();
        dto.setUserId("H2302603"); //토큰 사용자
//        String qltyVehlCd = request.getParameter("DqltyVehlCd");
//            hmap.put("qltyVehlCd", qltyVehlCd);
        CommReqDTO comDto = new CommReqDTO();




//        VehlMgmtResDTO result = vehlMgmtService.selectVehlMgmt(vehlReqDTO);
//            mv.addObject("result", result);

        comDto.setDlExpdGCd("0007");// 수신형태
        List<VehlMgmtResDTO> codeList = commonService.selectCodeList(comDto);
//            mv.addObject("codeList", codeList);
//
//        List<HMap> pdiList = commonService.selectDlExpdPdiCdList(hmap); // PDI 리스트
//            mv.addObject("pdiList", pdiList);
//
//        List<HMap> langMstList = langService.selectNatlUseLangCdList(hmap);
//            mv.addObject("langMstList", langMstList);
//
//        List<HMap> natlMstList = langService.selectNatlCdMstList(hmap);
//            mv.addObject("natlMstList", natlMstList);

        List<VehlMgmtResDTO> natlLangList = vehlMgmtService.selectVehlMgmtNatlLangList(dto);

            resultMap.put("natlLangList", natlLangList);


        return resultMap;
    }



//    @Operation(summary = "유저팝업")
//    @GetMapping("/hmcUserchk")
//    public VehlMgmtResDTO hmcUserchk(@ModelAttribute VehlMgmtReqDTO vehlReqDTO) throws Exception {
//
//
//
//
//                // userEenoVal 이전 등록한 사용자
//        String userEenoVal = request.getParameter("userEenoVal");
//        if(userEenoVal != null || userEenoVal !=""){
//            String[] arr = userEenoVal.split(",");
//            mv.addObject("userEenoVal", arr);
//        }
//
//        List<HMap> usrList = commonService.selectUsrList(hmap);
//            mv.addObject("usrList", usrList);
//
//        /** LOG_USE Start =========================================================*/
//        hmap.put("userId", userId);
//
//        hmap.put("useType", "01"); // 사용유형(01:조회, 02:수정, 03:삭제, 04:인쇄, 05:등록, 06:DN)
//
//
//               return mv;
//    }



    @Operation(summary = "차종 관리 수정")
    @GetMapping("/vehlMgmtMod")
    public HashMap<String, Object>  vehlMgmtMod(@ModelAttribute VehlMgmtReqDTO vehlReqDTO) throws Exception {

        UsrMgmtReqDTO usrDTO = new UsrMgmtReqDTO();

        VehlMgmtReqDTO vo = new VehlMgmtReqDTO();

        HashMap<String,Object> resultMap = new HashMap<String, Object>();
        vehlReqDTO.setUserId("H2302603"); //토큰 사용자
        vehlReqDTO.setUpdrEeno("H2302603"); //토큰 사용자
        vehlReqDTO.setPprrEeno("H2302603"); //토큰 사용자


        String oriQltyVehlCd = vehlReqDTO.getQltyVehlCd();
        String oriMdlMdyCd = vehlReqDTO.getMdlMdyCd();
        String qltyVehlNm = vehlReqDTO.getQltyVehlCd();

        vehlReqDTO.setQltyVehlCd( qltyVehlNm.replace("&#40;", "(").replace("&#41;", ")"));
        try{
            // 담당자 처리 Start
            vehlMgmtService.deleteVehlMgmtCrgr(vehlReqDTO);  // 담당자 전체 삭제 후 재등록

            // 차종 권한 삭제 및 등록 등록자

            vehlReqDTO.setClScnCd("U");
            vehlReqDTO.setUserEeno("H2302603");

            // 현재 사용자
            // 등록 or 수정하려는 차종 권한만 삭제 필요
            usrDTO.setClScnCd("U");
            usrDTO.setPprrEeno("H2302603");
            usrDTO.setQltyVehlCd(vehlReqDTO.getQltyVehlCd());
            usrDTO.setUserEeno("H2302603");

            usrService.deleteVehlAuth(usrDTO);
            // 차종 권한 다시 등록
            usrService.insertVehlAuth(usrDTO);


            String hmcVal = vehlReqDTO.getHmcchkVal();
            if(!"N".equals(hmcVal)){
                String[] arr = hmcVal.split(",");
                for(int i=0; i< arr.length ; i++){
                    vehlReqDTO.setCrgrEeno(arr[i]);
                    vehlReqDTO.setBlnsCoCd("01");

                    vehlMgmtService.insertVehlMgmtCrgr(vehlReqDTO);  // HMC 담당자 등록 차종권한은 hmc 전체 부여
                }
            }

            String kyungVal = vehlReqDTO.getKyungchkVal();
            if(!"N".equals(kyungVal)){
                String[] brr = kyungVal.split(",");
                for(int j=0; j< brr.length ; j++){
                    vehlReqDTO.setCrgrEeno(brr[j]);
                    vehlReqDTO.setBlnsCoCd("03");

                    vehlMgmtService.insertVehlMgmtCrgr(vehlReqDTO);  // 경진 담당자 등록

                    // 차종 권한 삭제 및 등록 경진 담당자
                    vehlReqDTO.setUserEeno(brr[j]);

                    usrService.deleteVehlAuth(usrDTO);
                    usrService.insertVehlAuth(usrDTO);

                }
            }


            String sehwaVal = vehlReqDTO.getSehwachkVal();
            if(!"N".equals(sehwaVal)){
                String[] crr = sehwaVal.split(",");
                for(int k=0; k< crr.length ; k++){
                    vehlReqDTO.setCrgrEeno(crr[k]);
                    vehlReqDTO.setBlnsCoCd("05");
                    vehlMgmtService.insertVehlMgmtCrgr(vehlReqDTO);  // 세화 담당자 등록

                    // 차종 권한 삭제 및 등록 세화 담당자
                    vehlReqDTO.setUserEeno(crr[k]);

                    usrService.deleteVehlAuth(usrDTO);
                    usrService.insertVehlAuth(usrDTO);
                }
            }


            String pdiVal = vehlReqDTO.getPdichkVal();
            if(!"N".equals(pdiVal)){
                String[] drr = pdiVal.split(",");
                for(int l=0; l< drr.length ; l++){
                    vehlReqDTO.setCrgrEeno(drr[l]);
                    vehlReqDTO.setBlnsCoCd("04");

                    vehlMgmtService.insertVehlMgmtCrgr(vehlReqDTO);  // pdi 담당자 등록

                    // 차종 권한 삭제 및 등록 pdi 담당자

                    vehlReqDTO.setUserEeno(drr[l]);
                    usrService.deleteVehlAuth(usrDTO);
                    usrService.insertVehlAuth(usrDTO);
                }
            }
            // 담당자 처리 End

            // 연식관계 처리 Start
            vehlMgmtService.deleteVehlMgmtRegnRelCd(vehlReqDTO);  // 연식관계 전체 삭제 후 재등록
            vehlMgmtService.deleteVehlDlExpdMdyMgmt(vehlReqDTO);  // 차종별 이전이후 연식관계 전체 삭제

            int regnClumSize = Integer.parseInt( vehlReqDTO.getRegnClumSize() );
            for (int i = 1; i <= regnClumSize; i++ ) {
                String regnCd =  null;//request.getParameter("regn_" + i);
                String mdyRelCd =null;// request.getParameter( "mdyRelCd_" + i );
                if(mdyRelCd != null && !"".equals(mdyRelCd)){

                    vehlReqDTO.setDlExpdRegnCd(regnCd);
                    vehlReqDTO.setJbMdyRelCd(mdyRelCd);
                    vehlMgmtService.insertVehlMgmtRegnRelCd(vehlReqDTO);

                    // TB_DL_EXPD_MDY_MGMT 차량별 이전연식관계 재등록
                    if("01".equals(mdyRelCd)){  // 완전통합  (미사용)

                        vehlReqDTO.setDlExpdMdlMdyCd(oriMdlMdyCd);
                        vehlMgmtService.insertVehlDlExpdMdyMgmt(vehlReqDTO);  // 기본 연식관계 등록
                        // 이전연식 조회
                        preDlExpdMdyList(vehlReqDTO);
                        // 이후연식 조회
                        nextDlExpdMdyList(vehlReqDTO);
                    }else if("02".equals(mdyRelCd)){ // 후 MY 가능  (미사용)
                        vehlReqDTO.setDlExpdMdlMdyCd(oriMdlMdyCd);
                        vehlMgmtService.insertVehlDlExpdMdyMgmt(vehlReqDTO);  // 기본 연식관계 등록
                        // 이후연식 조회
                        nextDlExpdMdyList(vehlReqDTO);
                    }else if("03".equals(mdyRelCd)){  // 전 MY 가능

                        vehlReqDTO.setDlExpdMdlMdyCd(oriMdlMdyCd);
                        vehlMgmtService.insertVehlDlExpdMdyMgmt(vehlReqDTO);  // 기본 연식관계 등록
                        // 이전연식 조회
                        preDlExpdMdyList(vehlReqDTO);
                    }else{  // 완전분리

                        vehlReqDTO.setDlExpdMdlMdyCd(oriMdlMdyCd);
                        vehlMgmtService.insertVehlDlExpdMdyMgmt(vehlReqDTO);  // 기본 연식관계 등록
                    }
                    // 차종별 언어 코드 등록
                    langMdyMgntSave(vehlReqDTO);
                }
            }
                       // 세화재고 재계산
            // PG_DATA.SP_RECALCULATE_SEWHA_IV_DTL3(V_SYST_YMD, P_VEHL_CD, P_USER_EENO);
//               vehlMgmtService.spRecalculateSewhaIvDtl3(hmap);

            // PDI재고 재계산
            // PG_DATA.SP_RECALCULATE_PDI_IV_DTL3(V_SYST_YMD, P_VEHL_CD, P_USER_EENO);
//               vehlMgmtService.spRecalculatePdiIvDtl3(hmap);


        // 공정코드 처리 Start
            vehlMgmtService.deleteVehlMgmtAltn(vehlReqDTO);

            String dytmPlnCd = vehlReqDTO.getDytmPlnCd();
            if(dytmPlnCd != null && !"".equals(dytmPlnCd)){
                vehlReqDTO.setPrdnVehlCd(dytmPlnCd);
                vehlReqDTO.setPrvsScnCd("A");

                vehlMgmtService.insertVehlMgmtAltn(vehlReqDTO);
            }

            String prdnMstCd = vehlReqDTO.getPrdnMstCd();
            if(prdnMstCd != null && !"".equals(prdnMstCd)){
                vehlReqDTO.setPrdnVehlCd(prdnMstCd);
                vehlReqDTO.setPrvsScnCd("B");
                vehlMgmtService.insertVehlMgmtAltn(vehlReqDTO);
            }

            String bomVehlCd = vehlReqDTO.getBomVehlCd();
            if(bomVehlCd != null && !"".equals(bomVehlCd)){
                vehlReqDTO.setPrdnVehlCd(bomVehlCd);
                vehlReqDTO.setPrvsScnCd("C");
                vehlMgmtService.insertVehlMgmtAltn(vehlReqDTO);
            }

            String saleVehlCd = vehlReqDTO.getSaleVehlCd();
            if(saleVehlCd != null && !"".equals(saleVehlCd)){
                vehlReqDTO.setPrdnVehlCd(saleVehlCd);
                vehlReqDTO.setPrvsScnCd("D");
                vehlMgmtService.insertVehlMgmtAltn(vehlReqDTO);
            }
        // 공정코드 처리 End
            // 국가별 언어코드 수정(삭제 후 등록) Start  chkVal

            vehlMgmtService.deleteNatlVehlLang(vehlReqDTO);  // 차종의 국가별 언어 리스트 전체 삭제

            String chkVal = vehlReqDTO.getChkVal();
            String[] natlarr = chkVal.split(",,");

            if (!"N".equals(chkVal)){

                for(int i=0; i< natlarr.length ; i++){
                    String[] natlbrr = natlarr[i].split("-");
                    vehlReqDTO.setDlExpdNatCd(natlbrr[0]);

                    String vehlChk = vehlMgmtService.selectNatlVehlChk(vehlReqDTO); // 연식별로 다른 경우로 인해 확인 후 없을경우 등록

                    if("N".equals(vehlChk)){
                        vehlMgmtService.insertNatlVehlMgmt(vehlReqDTO);  // 국가별 차량코드 등록
                    }

                    String[] natlcrr =  natlbrr[1].split(",");
                    for(int j=0; j< natlcrr.length ; j++){

                        vehlReqDTO.setLangCd(natlcrr[j]);
                        vehlMgmtService.insertNatlVehlLang(vehlReqDTO); // 차량별 언어코드 등록
                    }
                }
            }
        // 차종코드 처리 Srart
            vehlMgmtService.updateVehlMgmtMain(vehlReqDTO);
        // 차종코드 처리 End


        }catch (Exception ex) {
//            session.setAttribute("message", messageSource.getMessage("VehlMgmtMod Update error", new String[]{"0"}, request.getLocale()));
        }



        return resultMap;
    }


    @Operation(summary = "차종 관리 등록")
    @GetMapping("/vehlMgmtReg")
    public int vehlMgmtReg(@ModelAttribute VehlMgmtReqDTO vehlReqDTO, HttpServletRequest request) throws Exception {

            int result = 0;
            UsrMgmtReqDTO usrDTO = new UsrMgmtReqDTO();
            vehlReqDTO.setUserEeno("H2302603");
            vehlReqDTO.setPprrEeno("H2302603");

            String oriQltyVehlCd = vehlReqDTO.getQltyVehlCd(); //차종코드
            String oriMdlMdyCd = vehlReqDTO.getMdlMdyCd(); //연식

            vehlReqDTO.setOriQltyVehlCd(oriQltyVehlCd);
            vehlReqDTO.setOriMdlMdyCd(oriMdlMdyCd);



            String qltyVehlNm = vehlReqDTO.getQltyVehlNm();
            vehlReqDTO.setQltyVehlNm(qltyVehlNm.replace("&#40;", "(").replace("&#41;", ")")); //차종명

        try{
            String vehlcd = vehlMgmtService.selectVehlMgmtCnt(vehlReqDTO);  // 차종코드 중복 확인 Y일경우 저장가능, N일경우 저장불가

            if("Y".equals(vehlcd)){

                // 연식 등록 확인 후 팝업 처리.....
//                HMap mdychk =  vehlMgmtService.selectVehlMdyChk(vehlReqDTO);
//                mv.addObject("mdychk", mdychk.get("mdychk").toString());

                // 담당자 처리 Start
                vehlMgmtService.insertVehlMgmtMain(vehlReqDTO);
                vehlMgmtService.deleteVehlMgmtCrgr(vehlReqDTO);  // 담당자 전체 삭제 후 재등록

                // 차종 권한 삭제 및 등록 등록자

                usrDTO.setClScnCd("U");
                usrDTO.setPprrEeno("H2302603");
                usrDTO.setQltyVehlCd(vehlReqDTO.getQltyVehlCd());
                usrDTO.setUserEeno("H2302603");
                usrDTO.setVehlCdByVehlReg(oriQltyVehlCd);
                usrService.deleteVehlAuth(usrDTO);
                usrService.insertVehlAuth(usrDTO);

                String hmcVal = vehlReqDTO.getHmcchkVal();
                if(!"N".equals(hmcVal)){
                    String[] arr = hmcVal.split(",");
                    for(int i=0; i< arr.length ; i++){
                        vehlReqDTO.setCrgrEeno(arr[i]);
                        vehlReqDTO.setBlnsCoCd("01");

                        vehlMgmtService.insertVehlMgmtCrgr(vehlReqDTO);  // HMC 담당자 등록 차종권한은 hmc 전체 부여
                    }
                }

                String kyungVal = vehlReqDTO.getKyungchkVal();
                if(!"N".equals(kyungVal)){
                    String[] brr = kyungVal.split(",");
                    for(int j=0; j< brr.length ; j++){
                        vehlReqDTO.setCrgrEeno(brr[j]);
                        vehlReqDTO.setBlnsCoCd("03");

                        vehlMgmtService.insertVehlMgmtCrgr(vehlReqDTO);  // 경진 담당자 등록

                        // 차종 권한 삭제 및 등록 경진 담당자
                        vehlReqDTO.setUserEeno(brr[j]);

                        usrService.deleteVehlAuth(usrDTO);
                        usrService.insertVehlAuth(usrDTO);
                    }
                }


                String sehwaVal = vehlReqDTO.getSehwachkVal();
                if(!"N".equals(sehwaVal)){
                    String[] crr = sehwaVal.split(",");
                    for(int k=0; k< crr.length ; k++){
                        vehlReqDTO.setCrgrEeno(crr[k]);
                        vehlReqDTO.setBlnsCoCd("05");
                        vehlMgmtService.insertVehlMgmtCrgr(vehlReqDTO);  // 세화 담당자 등록

                        // 차종 권한 삭제 및 등록 세화 담당자
                        vehlReqDTO.setUserEeno(crr[k]);

                        usrService.deleteVehlAuth(usrDTO);
                        usrService.insertVehlAuth(usrDTO);
                    }
                }


                String pdiVal = vehlReqDTO.getPdichkVal();
                if(!"N".equals(pdiVal)){
                    String[] drr = pdiVal.split(",");
                    for(int l=0; l< drr.length ; l++){
                        vehlReqDTO.setCrgrEeno(drr[l]);
                        vehlReqDTO.setBlnsCoCd("04");

                        vehlMgmtService.insertVehlMgmtCrgr(vehlReqDTO);  // pdi 담당자 등록

                        // 차종 권한 삭제 및 등록 pdi 담당자

                        vehlReqDTO.setUserEeno(drr[l]);
                        usrService.deleteVehlAuth(usrDTO);
                        usrService.insertVehlAuth(usrDTO);
                    }
                }
                // 담당자 처리 End
                // 연식관계 처리 Start
                vehlMgmtService.deleteVehlMgmtRegnRelCd(vehlReqDTO);  // 연식관계 전체 삭제 후 재등록

                vehlMgmtService.deleteVehlDlExpdMdyMgmt(vehlReqDTO);  // 차량별 이전연식관계 전체 삭제

                int regnClumSize = Integer.parseInt( vehlReqDTO.getRegnClumSize());
                for (int i = 1; i <= regnClumSize; i++ ) {
                    String regnCd = request.getParameter("regn_" + i);
                    String mdyRelCd = request.getParameter( "mdyRelCd_" + i );
                    if(mdyRelCd != null && !"".equals(mdyRelCd)){

                        vehlReqDTO.setDlExpdRegnCd(regnCd);
                        vehlReqDTO.setJbMdyRelCd(mdyRelCd);
                        vehlMgmtService.insertVehlMgmtRegnRelCd(vehlReqDTO);

                        // TB_DL_EXPD_MDY_MGMT 차량별 이전연식관계 재등록
                        if("01".equals(mdyRelCd)){  // 완전통합  (미사용)
                            vehlReqDTO.setDlExpdMdlMdyCd(oriMdlMdyCd);
                            vehlMgmtService.insertVehlDlExpdMdyMgmt(vehlReqDTO);  // 기본 연식관계 등록
                            // 이전연식 조회
                            preDlExpdMdyList(vehlReqDTO);
                            // 이후연식 조회
                            nextDlExpdMdyList(vehlReqDTO);
                        }else if("02".equals(mdyRelCd)){ // 후 MY 가능  (미사용)
                            vehlReqDTO.setDlExpdMdlMdyCd(oriMdlMdyCd);
                            vehlMgmtService.insertVehlDlExpdMdyMgmt(vehlReqDTO);  // 기본 연식관계 등록
                            // 이후연식 조회
                            nextDlExpdMdyList(vehlReqDTO);
                        }else if("03".equals(mdyRelCd)){  // 전 MY 가능
                            vehlReqDTO.setDlExpdMdlMdyCd(oriMdlMdyCd);
                            vehlMgmtService.insertVehlDlExpdMdyMgmt(vehlReqDTO);  // 기본 연식관계 등록
                            // 이전연식 조회
                            preDlExpdMdyList(vehlReqDTO);
                        }else{  // 완전분리
                            vehlReqDTO.setDlExpdMdlMdyCd(oriMdlMdyCd);
                            vehlMgmtService.insertVehlDlExpdMdyMgmt(vehlReqDTO);  // 기본 연식관계 등록
                        }
                        // 차종별 언어 코드 등록
                        langMdyMgntSave(vehlReqDTO);
                    }
                }



            // 공정코드 처리 Start
                vehlMgmtService.deleteVehlMgmtAltn(vehlReqDTO);

                String dytmPlnCd = vehlReqDTO.getDytmPlnCd();
                if(dytmPlnCd != null && !"".equals(dytmPlnCd)){
                    vehlReqDTO.setPrdnVehlCd(dytmPlnCd);
                    vehlReqDTO.setPrvsScnCd("A");
                    vehlMgmtService.insertVehlMgmtAltn(vehlReqDTO);
                }
                String prdnMstCd = request.getParameter("prdnMstCd");
                if(prdnMstCd != null && !"".equals(prdnMstCd)){
                    vehlReqDTO.setPrdnVehlCd(prdnMstCd);
                    vehlReqDTO.setPrvsScnCd("B");
                    vehlMgmtService.insertVehlMgmtAltn(vehlReqDTO);
                }
                String bomVehlCd = request.getParameter("bomVehlCd");
                if(bomVehlCd != null && !"".equals(bomVehlCd)){
                    vehlReqDTO.setPrdnVehlCd(bomVehlCd);
                    vehlReqDTO.setPrvsScnCd("C");
                    vehlMgmtService.insertVehlMgmtAltn(vehlReqDTO);
                }
                String saleVehlCd = request.getParameter("saleVehlCd");
                if(saleVehlCd != null && !"".equals(saleVehlCd)){
                    vehlReqDTO.setPrdnVehlCd(saleVehlCd);
                    vehlReqDTO.setPrvsScnCd("D");
                    vehlMgmtService.insertVehlMgmtAltn(vehlReqDTO);
                }
            // 공정코드 처리 End

            // 국가별 언어코드 등록 Start  chkVal
                vehlMgmtService.deleteNatlVehlLang(vehlReqDTO);  // 차량의 국가별 언어 리스트 전체 삭제
                String chkVal = vehlReqDTO.getChkVal();
                String[] natlarr = chkVal.split(",,");

                if (!"N".equals(chkVal)){
                    for(int i=0; i< natlarr.length ; i++){
                        String[] natlbrr = natlarr[i].split("-");
                        vehlReqDTO.setDlExpdNatCd(natlbrr[0]);
                        String chkVehl = vehlMgmtService.selectNatlVehlChk(vehlReqDTO); // 연식마다 다를 수 있어서 확인 후 추가 등록
                        if("N".equals(chkVehl)){ // 확인 카운트가 없으면 등록
                            vehlMgmtService.insertNatlVehlMgmt(vehlReqDTO);  // 국가별 차량코드 등록
                        }
                        String[] natlcrr =  natlbrr[1].split(",");
                        for(int j=0; j< natlcrr.length ; j++){
                            vehlReqDTO.setLangCd(natlcrr[j]);
                            vehlMgmtService.insertNatlVehlLang(vehlReqDTO); // 차량별 언어코드 등록
                        }
                    }
                }
            // 국가별 언어코드 등록 END

                // 이전연식 확인 후 언어복사=====================================================

//
                List<VehlMgmtResDTO> list = vehlMgmtService.selectPreVehlMdyChk(vehlReqDTO);  // 이전연식 확인
                  if("Y".equals(list.get(0).getChkCpVehl())){
                      vehlReqDTO.setC1qltyVehlCd(oriQltyVehlCd);
                      vehlReqDTO.setC1mdlMdyCd(oriMdlMdyCd);
                      vehlReqDTO.setMdlMdyCd(list.get(0).getChkCpVehl());
                     // 언어 복사를 위해 변수 처리
                      vehlMgmtService.deleteVehlLangCp(vehlReqDTO); // 복사전 삭제
                      vehlMgmtService.insertVehlLangCopy(vehlReqDTO); // 언어코드 복사
                  }
             // =============================================================================
                result = 1; //정상
            }else{
                result = 2; //중복
            }
        }catch (Exception ex) {
//            session.setAttribute("message", messageSource.getMessage("VehlMgmtVehlCd Insert error", new String[]{"0"}, request.getLocale()));
            ex.printStackTrace();
        }
        /** LOG_USE Start =========================================================*/
//        hmap.put("userId", userId);
//        hmap.put("menuId", request.getParameter("menuId"));
//        hmap.put("useType", "05"); // 사용유형(01:조회, 02:수정, 03:삭제, 04:인쇄, 05:등록, 06:DN)
//        hmap.put("actId", "/stm/vehlMgmtReg.do");
//        commonService.insertUseLog(hmap);
        /** LOG_USE END ===========================================================*/
        return result;
    }


    @Operation(summary = "차종관리 엑실다운로드")
    @GetMapping("/vehlMgmtExcelList")

    public List<VehlMgmtResDTO> vehlMgmtExcel(StmComReqDTO dto) throws Exception {
        dto.setUserId("H2302603");


        return vehlMgmtService.selectVehlMgmtList(dto);
    }
    @Operation(summary = "연식 조회")
    @GetMapping("/mdyMgmtList")
    public HashMap<String, Object> mdyMgmtList(StmComReqDTO reqDto) throws Exception {

        HashMap<String, Object> resultMap = new HashMap<String, Object>();
        reqDto.setUserId("H2302603");
        String qltyVehlCd = reqDto.getQltyVehlCd();
        String dlExpdRegnCd = reqDto.getDlExpdRegnCd();
        String dlExpdPacScnCd = reqDto.getDlExpdPacScnCd();
        String sYm = reqDto.getSYm();
        String eYm = reqDto.getEYm();
        String nqltyVehlCd = reqDto.getNqltyVehlCd();

        if("ALL".equals(qltyVehlCd)){
            qltyVehlCd = nqltyVehlCd;
            reqDto.setQltyVehlCd(nqltyVehlCd);
        }

        List<VehlMgmtReqDTO> mdyMonth = vehlMgmtService.selectMdyMonth(reqDto);
            if(sYm == null){
                sYm = mdyMonth.get(0).getSYm();
                reqDto.setSYm(sYm);

            }
            if(eYm == null){
                eYm = mdyMonth.get(0).getEYm();
                reqDto.setEYm(eYm);

            }

//        List<HMap> pdiList = commonService.selectDlExpdPdiCdList(reqDto); // PDI 리스트
//            mv.addObject("pdiList", pdiList);

//        List<HMap> vehlList = commonService.selectQltyVehlCdList(reqDto);
//            mv.addObject("vehlList", vehlList);

//        List<HMap> dlExpdRegnCdList = commonService.selectDlExpdRegnCdList(reqDto);
//            mv.addObject("dlExpdRegnCdList", dlExpdRegnCdList);

//        List<HMap> RegnAll = vehlMgmtService.selectRegnAll(reqDto);
//            mv.addObject("RegnAll", RegnAll);
//
//        List<HMap> mdyList = vehlMgmtService.selectVehlMdyList(reqDto);
//            mv.addObject("mdyList", mdyList);
////            mv.addObject("qltyVehlCd", qltyVehlCd);
////            mv.addObject("dlExpdRegnCd", dlExpdRegnCd);
////            mv.addObject("dlExpdPacScnCd", dlExpdPacScnCd);
//            mv.addObject("sYm", sYm);
//            mv.addObject("eYm", eYm);
//            mv.addObject("nqltyVehlCd", nqltyVehlCd);
//            mv.addObject("mdyMonth", mdyMonth);
//            mv.addObject("okmsg", request.getParameter("okmsg"));


        return resultMap;
    }

    private void preDlExpdMdyList(VehlMgmtReqDTO vo) throws Exception {

        // 이후연식 조회
           List<VehlMgmtReqDTO> preMdyList = vehlMgmtService.selectDlExpdMdyPreList(vo);
           if(preMdyList.isEmpty() == false){
               for(int i=0;i<preMdyList.size();i++){
                   String preMdlMdyCd = preMdyList.get(i).getMdlMdyCd();
                   String preChkMdy = preMdyList.get(i).getChkMdy();

                   if("Y".equals(preChkMdy) ){
                       vo.setDlExpdMdlMdyCd(preMdlMdyCd);
                       vehlMgmtService.insertVehlDlExpdMdyMgmt(vo);
                   }else{
                       vo.setDlExpdMdlMdyCd(preMdlMdyCd);
                       vehlMgmtService.insertVehlDlExpdMdyMgmt(vo);
                       break;
                   }
               }
           }
       }

       private void nextDlExpdMdyList(VehlMgmtReqDTO vo) throws Exception {
           // 이후연식 조회
           List<VehlMgmtReqDTO> nextMdyList = vehlMgmtService.selectDlExpdMdyNextList(vo);
           if(nextMdyList.isEmpty() == false){
               for(int i=0;i<nextMdyList.size();i++){
                   String nextMdlMdyCd = nextMdyList.get(i).getMdlMdyCd();
                   String nextChkMdy = nextMdyList.get(i).getChkMdy();

                   if("Y".equals(nextChkMdy) ){
                       vo.setDlExpdMdlMdyCd(nextMdlMdyCd);
                       vehlMgmtService.insertVehlDlExpdMdyMgmt(vo);
                   }else{
                       vo.setDlExpdMdlMdyCd(nextMdlMdyCd);
                       vehlMgmtService.insertVehlDlExpdMdyMgmt(vo);
                       break;
                   }
               }
           }
       }
       private void langMdyMgntSave(VehlMgmtReqDTO vo) throws Exception {

           List<VehlMgmtReqDTO> langListInfo = vehlMgmtService.selectVehlLangList(vo);

           if(langListInfo.isEmpty() == false){
               for(int i=0; i<langListInfo.size();i++){
                   String langCd = langListInfo.get(i).getLangCd();

                   vo.setLangCd(langCd);
                   vehlMgmtService.deleteVehlLang(vo);
                   vehlMgmtService.insertVehlLangInfo(vo);
               }
           }
       }
}