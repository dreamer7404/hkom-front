package com.oms.ivm.dto;

import org.apache.ibatis.type.Alias;

import com.oms.common.dto.CommReqDTO;

import lombok.AllArgsConstructor;
import lombok.Data;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @author 김정웅
 * @since 2023. 3. 13.
 * @see
 */
@Alias("totIvmRequestReqDTO")
@Data
@AllArgsConstructor
public class TotIvmRequestReqDTO extends CommReqDTO {

    private String content;
    private String userId;

    private String qltyVehlCd;
    private String mdlMdyCd;
    private String rqQty;
    private String langCd;
    private String dataSn;

    private String pExpdRqScnCd;

    //세원:sewon, PDI/용산:pdi
    private String radioType;
}
