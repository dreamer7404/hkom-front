package com.oms.ivm.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import able.cloud.core.web.HController;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.oms.ivm.dto.ComIvmReqDTO;
import com.oms.ivm.dto.Ivm2WeekPlanReqDTO;
import com.oms.ivm.dto.Ivm2WeekPlanResDTO;
import com.oms.ivm.dto.Ivm3DayPlanReqDTO;
import com.oms.ivm.dto.Ivm3DayPlanResDTO;
import com.oms.ivm.dto.IvmPdiOrYongsanIvResDTO;
import com.oms.ivm.dto.IvmSewonIvReqDTO;
import com.oms.ivm.dto.IvmSewonIvResDTO;
import com.oms.ivm.dto.IvmThisMonTrwiReqDTO;
import com.oms.ivm.dto.IvmThisMonTrwiResDTO;
import com.oms.ivm.service.ComIvmService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;


/**
 * <pre>
 * ComIvmController
 * </pre>
 *
 * @ClassName   : ComIvmController.java
 * @Description : 재고관리 > 공통 컨트롤러 (주간계획 팝업 등..)
 * @author 김정웅
 * @since 2023.3.13
 * @see
 */
@Tag(name = "ComIvmController", description = "")
@CrossOrigin(origins="*")
@RequiredArgsConstructor
@RestController
@RequestMapping("/api")
public class ComIvmController extends HController {

    /**
     * 클래스 Injection
     */
    private final HttpServletRequest request;
    private final ComIvmService comIvmService;

    /**
     * 재고관리 > 주간계획(2주)||생산계획(2주)
     */
    @Operation(summary = "주간계획(2주)")
    @GetMapping("/ivm2WeekPlan")
    public List<Ivm2WeekPlanResDTO> selectIvm2WeekPlanList(@ModelAttribute Ivm2WeekPlanReqDTO ivm2WeekPlanReqDTO) throws Exception {
        List<Ivm2WeekPlanResDTO> result = new ArrayList<Ivm2WeekPlanResDTO>();
        result = comIvmService.selectIvm2WeekPlanList(ivm2WeekPlanReqDTO);
        return result;
    }

    /**
     * 재고관리 > 단기계획(3일)
     */
    @Operation(summary = "단기계획(3일)")
    @GetMapping("/ivm3DayPlan")
    public List<Ivm3DayPlanResDTO> selectIvm3DayPlanList(@ModelAttribute Ivm3DayPlanReqDTO ivm3DayPlanReqDTO) throws Exception {
        List<Ivm3DayPlanResDTO> result = new ArrayList<Ivm3DayPlanResDTO>();
        result = comIvmService.selectIvm3DayPrdnPlanList(ivm3DayPlanReqDTO);
        return result;
    }

    /**
     * 재고관리 > 당월투입(누적)
     */
    @Operation(summary = "당월투입(누적)")
    @GetMapping("/ivmThisMonTrwis")
    public List<IvmThisMonTrwiResDTO> selectIvmThisMonTrwiList(@ModelAttribute IvmThisMonTrwiReqDTO ivmThisMonTrwiReqDTO) throws Exception {
        List<IvmThisMonTrwiResDTO> result = new ArrayList<IvmThisMonTrwiResDTO>();
        result = comIvmService.selectIvmThisMonTrwiList(ivmThisMonTrwiReqDTO);
        return result;
    }

    /**
     * 재고관리 > 세원 보유재고
     */
    @Operation(summary = "재고현황-세원보유재고")
    @GetMapping("/ivmSewonIvs")
    public List<IvmSewonIvResDTO> selectIvmSewonIvList(@ModelAttribute IvmSewonIvReqDTO ivmSewonIvReqDTO) throws Exception {
        List<IvmSewonIvResDTO> result = new ArrayList<IvmSewonIvResDTO>();
        result = comIvmService.selectIvmSewonIvList(ivmSewonIvReqDTO);
        return result;

    }

    /**
     * 재고관리 > PDI/용산 재고
     */
    @Operation(summary = "PDI/용산재고")
    @GetMapping("/ivmPdiOrYongsanIvs")
    public List<IvmPdiOrYongsanIvResDTO> selectIvmPdiOrYongsanIvList(@ModelAttribute ComIvmReqDTO comIvmReqDTO) throws Exception {
        List<IvmPdiOrYongsanIvResDTO> result = new ArrayList<IvmPdiOrYongsanIvResDTO>();
        result = comIvmService.selectIvmPdiOrYongsanIvList(comIvmReqDTO);
        return result;

    }

}