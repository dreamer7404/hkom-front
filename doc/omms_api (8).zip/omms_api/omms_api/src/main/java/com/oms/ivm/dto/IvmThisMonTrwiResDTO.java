package com.oms.ivm.dto;

import org.apache.ibatis.type.Alias;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @author 김정웅
 * @since 2023. 3. 15.
 * @see
 */

@Alias("ivmThisMonTrwiResDTO")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class IvmThisMonTrwiResDTO {

    private String wkYmd;
    private String whsnQty;
    private String whotQty;
}