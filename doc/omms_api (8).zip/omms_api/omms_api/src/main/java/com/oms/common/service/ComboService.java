package com.oms.common.service;

import java.util.List;

import com.oms.common.dto.ComboReqDTO;
import com.oms.common.dto.LangComboResDTO;
import com.oms.common.dto.PdiComboResDTO;
import com.oms.common.dto.RegionComboResDTO;
import com.oms.common.dto.SubCdComboResDTO;
import com.oms.common.dto.VehlComboResDTO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @author Windows ≫c¿eAU
 * @since 2023. 3. 22.
 * @see
 */

public interface ComboService {
    public List<PdiComboResDTO> selectPdiComboList(ComboReqDTO comboReqDTO) throws Exception;
    public List<VehlComboResDTO> selectVehlComboList(ComboReqDTO comboReqDTO) throws Exception;
    public List<String> selectMdyComboList(ComboReqDTO comboReqDTO) throws Exception;
    public List<RegionComboResDTO> selectRegionComboList(ComboReqDTO comboReqDTO) throws Exception;
    public List<LangComboResDTO> selectLangComboList(ComboReqDTO comboReqDTO) throws Exception;
    public List<SubCdComboResDTO> selectSubCdComboList(String mainCd) throws Exception;
}
