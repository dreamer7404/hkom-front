package com.oms.sys.dao;

import com.oms.sys.dto.UsrMgmtReqDTO;
import com.oms.sys.dto.UsrSessionResDTO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @author 안경수
 * @since 2023. 2. 24.
 * @see
 */

public interface UsrSessionDAO {
    UsrSessionResDTO selectUsrSession(String userEeno) throws Exception;
}
