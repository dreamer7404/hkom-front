package com.oms.stm.service;

import java.util.List;

import com.oms.common.dto.CommReqDTO;
import com.oms.stm.dto.CodeMgmtReqDTO;
import com.oms.stm.dto.CodeMgmtResDTO;
import com.oms.stm.model.CodeMgmt;


/**
 * <pre>
 * CodeMgmtService
 * </pre>
 * 
 * @ClassName   : CodeMgmtService.java
 * @Description : 클래스 설명을 기술합니다.
 * @author 안경수 
 * @since 2023.1.19
 * @see
 */


public interface CodeMgmtService { 
    public Integer insertCodeMgmt(CodeMgmtReqDTO codeMgmtReqDTO) throws Exception;
    public Integer updateCodeMgmt(CodeMgmtReqDTO codeMgmtReqDTO) throws Exception;
    public Integer deleteCodeMgmt(CodeMgmtReqDTO codeMgmtReqDTO) throws Exception;
    public List<CodeMgmtResDTO> selectCodeMgmtList(CodeMgmtReqDTO codeMgmtReqDTO) throws Exception;
}
