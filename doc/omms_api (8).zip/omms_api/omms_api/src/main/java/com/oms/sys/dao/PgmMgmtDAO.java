package com.oms.sys.dao;

import java.util.List;

import com.oms.common.dto.CommReqDTO;
import com.oms.sys.dto.PgmMgmtResDTO;

/**
 * <pre>
 * PgmMgmt DAO 인터페이스
 * </pre>
 *
 * @Class Name  : PgmMgmtDAO.java
 * @Description : 메뉴정보
 * @author 안경수
 * @since 2023.3.06
 * @see
*/
public interface PgmMgmtDAO {

    List<PgmMgmtResDTO> selectPgmMgmtList(CommReqDTO CommReqDTO) throws Exception;
}
