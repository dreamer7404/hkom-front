package com.oms.common.service.impl;

import java.util.List;

import able.cloud.core.service.HService;

import org.springframework.stereotype.Service;

import com.oms.common.dao.ComboDAO;
import com.oms.common.dto.CodeComboResDTO;
import com.oms.common.dto.ComboReqDTO;
import com.oms.common.dto.GrpComboResDTO;
import com.oms.common.dto.LangComboResDTO;
import com.oms.common.dto.PdiComboResDTO;
import com.oms.common.dto.RegionComboResDTO;
import com.oms.common.dto.SubCdComboResDTO;
import com.oms.common.dto.VehlComboResDTO;
import com.oms.common.service.ComboService;

import lombok.RequiredArgsConstructor;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @author 안경수
 * @since 2023. 3. 22.
 * @see
 */


@RequiredArgsConstructor
@Service("comboService")
public class ComboServiceImpl  extends HService implements ComboService {

    private final ComboDAO comboDAO;

    @Override
    public List<PdiComboResDTO> selectPdiComboList(ComboReqDTO comboReqDTO) throws Exception {
        return comboDAO.selectPdiComboList(comboReqDTO);
    }

    @Override
    public List<VehlComboResDTO> selectVehlComboList(ComboReqDTO comboReqDTO) throws Exception {
        return comboDAO.selectVehlComboList(comboReqDTO);
    }

    @Override
    public List<String> selectMdyComboList(ComboReqDTO comboReqDTO) throws Exception {
        return comboDAO.selectMdyComboList(comboReqDTO);
    }

    @Override
    public List<RegionComboResDTO> selectRegionComboList(ComboReqDTO comboReqDTO) throws Exception {
        return comboDAO.selectRegionComboList(comboReqDTO);
    }

    @Override
    public List<LangComboResDTO> selectLangComboList(ComboReqDTO comboReqDTO) throws Exception {
        return comboDAO.selectLangComboList(comboReqDTO);
    }

    /*
     * @see com.oms.common.service.ComboService#selectSubCdComboList(java.lang.String)
     */
    @Override
    public List<SubCdComboResDTO> selectSubCdComboList(String mainCd) throws Exception {
       return comboDAO.selectSubCdComboList(mainCd);
    }

    /*
     * @see com.oms.common.service.ComboService#selectCoComboList()
     */
    @Override
    public List<CodeComboResDTO> selectCodeComboList(String dlExpdGCd) throws Exception {
        return comboDAO.selectCodeComboList(dlExpdGCd);
    }

    /*
     * @see com.oms.common.service.ComboService#selectGrpComboList()
     */
    @Override
    public List<GrpComboResDTO> selectGrpComboList() throws Exception {
        return comboDAO.selectGrpComboList();
    }



}
