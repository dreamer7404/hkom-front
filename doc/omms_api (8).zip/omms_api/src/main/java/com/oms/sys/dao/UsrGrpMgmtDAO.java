package com.oms.sys.dao;

import java.util.List;

import com.oms.sys.dto.UsrGrpMgmtReqDTO;
import com.oms.sys.dto.UsrGrpMgmtResDTO;

/**
 * <pre>
 * UsrGrpMgmtDAO DAO 인터페이스
 * </pre>
 *
 * @Class Name  : UsrGrpMgmtDAO.java
 * @Description :
 * @author 안경수
 * @since 2023.4.18
 * @see
*/
public interface UsrGrpMgmtDAO {

    List<UsrGrpMgmtResDTO> selectUsrGrpMgmtList() throws Exception;
    Integer insertUsrGrpMgmt(UsrGrpMgmtReqDTO usrGrpMgmtReqDTO ) throws Exception;
    Integer updateUsrGrpMgmt(UsrGrpMgmtReqDTO usrGrpMgmtReqDTO ) throws Exception;
    UsrGrpMgmtResDTO selectUsrGrpMgmt(UsrGrpMgmtReqDTO usrGrpMgmtReqDTO ) throws Exception;

}
