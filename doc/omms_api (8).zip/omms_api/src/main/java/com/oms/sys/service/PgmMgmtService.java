package com.oms.sys.service;

import java.util.List;

import com.oms.common.dto.CommReqDTO;
import com.oms.sys.dto.AuthAffrMgmtReqDTO;
import com.oms.sys.dto.AuthAffrMgmtResDTO;
import com.oms.sys.dto.PgmMgmtReqDTO;
import com.oms.sys.dto.PgmMgmtResDTO;
import com.oms.sys.dto.UseYnReqDTO;
import com.oms.sys.model.AuthAffrMgmt;


/**
 * <pre>
 * PgmMgmtService
 * </pre>
 *
 * @ClassName   : PgmMgmtService.java
 * @Description :
 * @author 안경수
 * @since 2023.1.19
 * @see
 */


public interface PgmMgmtService {

    public List<PgmMgmtResDTO> selectPgmMgmtListAll() throws Exception;
    public List<PgmMgmtResDTO> selectPgmMgmtList(CommReqDTO commReqDTO) throws Exception;

    /**
     * Statements
     *
     * @param dto
     * @return
     */
    public int insertPgmMgmt(PgmMgmtReqDTO dto);

    /**
     * Statements
     *
     * @param dto
     * @return
     */
    public int updatePgmMgmt(PgmMgmtReqDTO dto);

    /**
     * Statements
     *
     * @param dto
     * @return
     */
    public int deletePgmMgmt(PgmMgmtReqDTO dto);

    /**
     * Statements
     *
     * @return
     */
    public List<PgmMgmtResDTO> selectGrpUsrList();

    /**
     * Statements
     *
     * @param dto
     */
    public int deletePgmGrpAuth(PgmMgmtReqDTO dto);

    /**
     * Statements
     *
     * @param dto
     * @return
     */
    public int insertPgmGrpAuth(PgmMgmtReqDTO dto);
    public int updatePgmMgmtUseYn(UseYnReqDTO useYnReqDTO);

    public List<AuthAffrMgmtResDTO> selectAuthAffrMgmtList(AuthAffrMgmtReqDTO authAffrMgmtReqDTO);
    public List<AuthAffrMgmtResDTO> selectAuthAffrMgmtListByGrp(AuthAffrMgmtReqDTO authAffrMgmtReqDTO);
    public List<AuthAffrMgmtResDTO> selectAuthAffrMgmt(AuthAffrMgmtReqDTO authAffrMgmtReqDTO);
    public int deleteAuthAffrMgmt(AuthAffrMgmt authAffrMgmt);
    public int insertAuthAffrMgmt(List<AuthAffrMgmt> list);



}
