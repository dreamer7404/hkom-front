package com.oms.print.service;

import java.util.List;

import com.oms.print.dto.PrintStateReqDTO;
import com.oms.print.dto.PrintStateResDTO;

/**
 * <pre>
 * Statements
 * </pre>
 * @ClassName : PrintStateService.java
 * @Description :
 * @author 김경훈
 * @since 2023. 5. 3.
 * @see
 */

public interface PrintStateService {

    /**
     * Statements
     *
     * @param dto
     * @return
     */
    List<PrintStateResDTO> selectPrintStateList(PrintStateReqDTO dto);

    /**
     * Statements
     *
     * @param dto
     * @return
     */
    PrintStateResDTO selectPrntFpInfo(PrintStateReqDTO dto);



}
