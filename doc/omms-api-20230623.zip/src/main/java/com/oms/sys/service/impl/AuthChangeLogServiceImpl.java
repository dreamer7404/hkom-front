package com.oms.sys.service.impl;

import java.util.List;
import org.springframework.stereotype.Service;

import com.oms.sys.dao.AuthChangeLogDAO;
import com.oms.sys.dto.AuthChangeLogResDTO;
import com.oms.sys.dto.LogComReqDTO;
import com.oms.sys.service.AuthChangeLogService;
import com.oms.sys.service.LogLgiService;
import lombok.RequiredArgsConstructor;



/**
 * <pre>
 * Statements
 * </pre>
 * @ClassName : AuthChangeServiceImpl.java
 * @Description :
 * @author 김경훈
 * @since 2023. 6. 19.
 * @see
 */
@RequiredArgsConstructor
@Service("authChangeLogService")
public class AuthChangeLogServiceImpl implements AuthChangeLogService {

    private final AuthChangeLogDAO authChangeDao;

    /*
     * @see com.oms.sys.service.AuthChangeService#authChangeHistorys(com.oms.sys.dto.AuthChangeReqDTO)
     */
    @Override
    public List<AuthChangeLogResDTO> authChangeHistorys(LogComReqDTO dto) {
        // TODO Auto-generated method stub
        return authChangeDao.authChangeHistorys(dto);
    }

    /*
     * @see com.oms.sys.service.AuthChangeService#authChangeHistoryTots(com.oms.sys.dto.AuthChangeReqDTO)
     */
    @Override
    public Integer authChangeHistoryTots(LogComReqDTO dto) {
        // TODO Auto-generated method stub
        return authChangeDao.authChangeHistoryTots(dto);
    }



}
