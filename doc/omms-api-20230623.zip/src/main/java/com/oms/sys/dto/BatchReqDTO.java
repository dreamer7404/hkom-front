package com.oms.sys.dto;

import org.apache.ibatis.type.Alias;

import com.oms.common.dto.CommReqDTO;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


/**
 * <pre>
 * Statements
 * </pre>
 * @ClassName : BatchReqDTO.java
 * @Description :
 * @author 김경훈
 * @since 2023. 6. 14.
 * @see
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Alias("batchReqDTO")

public class BatchReqDTO   extends CommReqDTO{


    private String bDate;
    private String btchWkCd;
    private String btchNm;

}
