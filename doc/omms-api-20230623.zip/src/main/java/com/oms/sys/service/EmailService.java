package com.oms.sys.service;

import java.util.List;

import com.oms.sys.dto.BatchLogResDTO;
import com.oms.sys.dto.BatchReqDTO;
import com.oms.sys.dto.BatchResDTO;
import com.oms.sys.dto.EmailReqDTO;
import com.oms.sys.dto.EmailLogResDTO;
import com.oms.sys.dto.EmailRcvrResDTO;

/**
 * <pre>
 * Statements
 * </pre>
 * @ClassName : EmailService.java
 * @Description :
 * @author 김경훈
 * @since 2023. 6. 15.
 * @see
 */
public interface EmailService {
        List<EmailLogResDTO> selectEmailLogs(EmailReqDTO dto);
        List<EmailRcvrResDTO> selectEmlRcvrMgmts(EmailReqDTO dto);

        int insEmlRcvrMgmt(EmailReqDTO dto);
        /**
         * Statements
         *
         * @param dto
         * @return
         */
        String selectEmlDupChk(EmailReqDTO dto);
        /**
         * Statements
         *
         * @param dto
         * @return
         */
        int delEmlRcvrMgmt(EmailReqDTO dto);
        /**
         * Statements
         *
         * @param dto
         * @return
         */
        List<EmailRcvrResDTO> emlRcvrUsrList(EmailReqDTO dto);



}
