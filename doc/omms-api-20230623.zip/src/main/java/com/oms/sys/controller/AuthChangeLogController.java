package com.oms.sys.controller;

import java.util.List;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


import com.oms.sys.dto.AuthChangeLogResDTO;

import com.oms.sys.dto.LogComReqDTO;

import com.oms.sys.service.AuthChangeLogService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;

/**
 * <pre>
 * Statements
 * </pre>
 * @ClassName : AuthChangeController.java
 * @Description :
 * @author 김경훈
 * @since 2023. 6. 19.
 * @see
 */
@Tag(name = "AuthChangeController", description = "")
@RequiredArgsConstructor
@RestController
@RequestMapping("/api")
public class AuthChangeLogController {

    /**
     * 클래스 Injection
     */
    private final AuthChangeLogService authChangeService;
        /**
     * Batch 목록을 조회
     */
    @Operation(summary = "권한변경 목록 조회 ")
    @GetMapping("/authChangeHistorys")
    public List<AuthChangeLogResDTO> authChangeHistorys(@ModelAttribute LogComReqDTO dto) throws Exception {
        return authChangeService.authChangeHistorys(dto);
    }


    /**
     * Batch 목록을 조회
     */
    @Operation(summary = "권한변경 목록 Row수 ")
    @GetMapping("/authChangeHistoryTots")
    public Integer authChangeHistoryTots(@ModelAttribute LogComReqDTO dto) throws Exception {
        return authChangeService.authChangeHistoryTots(dto);
    }



}
