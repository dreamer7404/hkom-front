package com.oms.print.service;

import java.util.List;

import com.oms.print.dto.MonthPutInfosResDTO;
import com.oms.print.dto.MonthPutReqDTO;

/**
 * <pre>
 * Statements
 * </pre>
 * @ClassName : MonthPutService.java
 * @Description :
 * @author 김정웅
 * @since 2023. 6. 16.
 * @see
 */

public interface MonthPutService {
    List<MonthPutInfosResDTO> selectMonthPutList(MonthPutReqDTO reqDto);
}
