package com.oms.ivm.service.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import able.cloud.core.service.HService;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.oms.ivm.dao.ComIvmDAO;
import com.oms.ivm.dao.PdiIvmDAO;
import com.oms.ivm.dao.SewIvmDAO;
import com.oms.ivm.dto.ComIvmReqDTO;
import com.oms.ivm.dto.IvmRequestMonitorResDTO;
import com.oms.ivm.dto.PdiIvmReqDTO;
import com.oms.ivm.dto.PdiIvmResDTO;
import com.oms.ivm.dto.PdiPrndMonitorReqDTO;
import com.oms.ivm.dto.PdiPrndMonitorResDTO;
import com.oms.ivm.dto.PdiWhsnReqDTO;
import com.oms.ivm.dto.PdiWhsnResDTO;
import com.oms.ivm.dto.PdiWhsnStatResDTO;
import com.oms.ivm.dto.SewonIvModReqDTO;
import com.oms.ivm.dto.SewonIvModResDTO;
import com.oms.ivm.dto.TotIvmRequestReqDTO;
import com.oms.ivm.service.PdiIvmService;

import lombok.RequiredArgsConstructor;

/**
 * <pre>
 * PdiIvmServiceImpl
 * </pre>
 *
 * @author 김정웅
 * @since 2023. 5. 4.
 * @see
 */
@RequiredArgsConstructor
@Service("pdiIvmService")
public class PdiIvmServiceImpl extends HService implements PdiIvmService {

    private final PdiIvmDAO pdiIvmDAO;
    private final SewIvmDAO sewIvmDAO;
    private final ComIvmDAO comIvmDAO;

    @Override
    public List<PdiIvmResDTO> selectPdiIvmList(PdiIvmReqDTO reqDto) throws Exception {
        String bDate = reqDto.getBDate();
        HashMap<String, String> validMdlMdy4 = sewIvmDAO.selectValidMdlMdy4(bDate);

        reqDto.setPFromMdlMdy(validMdlMdy4.get("P_FROM_MDL_MDY"));
        reqDto.setPToMdlMdy(validMdlMdy4.get("P_TO_MDL_MDY"));

        List<PdiIvmResDTO> result = new ArrayList<PdiIvmResDTO>();

        //배송여부:전체
        if("ALL".equals(reqDto.getDlvtState())) {
            result = pdiIvmDAO.selectPdiIvmListAll(reqDto);
        }
        //배송여부:배송중
        else if ("01".equals(reqDto.getDlvtState())) {
            result = pdiIvmDAO.selectPdiIvmList01(reqDto);
        }
        //배송여부:배송완료
        else if ("02".equals(reqDto.getDlvtState())) {
            result = pdiIvmDAO.selectPdiIvmList02(reqDto);
        }

        return result;
    }

    @Override
    public PdiPrndMonitorResDTO selectPdiPrndMonitor(PdiPrndMonitorReqDTO reqDto) throws Exception {
        PdiPrndMonitorResDTO result = new PdiPrndMonitorResDTO();

        HashMap<String,String> vFramYmd = pdiIvmDAO.selectPdiVFramYmd(reqDto.getDlExpdCoCd(), reqDto.getBDate());
        reqDto.setVFramYmd(vFramYmd.get("V_FRAM_YMD"));

        HashMap<String, Integer> todayPrdnPlan = comIvmDAO.selectIvmTodayPrdnPlanList(reqDto.getDataSn(), reqDto.getBDate());
        int vTddPrdnPlanQty = Integer.parseInt(String.valueOf(todayPrdnPlan.get("V_TDD_PRDN_PLAN_QTY")));
        int vTddPrdnQty3 = Integer.parseInt(String.valueOf(todayPrdnPlan.get("V_TDD_PRDN_QTY3")));
        int vTddPrdnQty = Integer.parseInt(String.valueOf(todayPrdnPlan.get("V_TDD_PRDN_QTY")));
        int planTotQty = vTddPrdnPlanQty + vTddPrdnQty3;
        reqDto.setVTddPrdnPlanQty(vTddPrdnPlanQty);
        reqDto.setVTddPrdnQty3(vTddPrdnQty3);
        reqDto.setVTddPrdnQty(vTddPrdnQty);
        result.setPlanTotQty(planTotQty);

        HashMap<String,String> expdPacScnCd = comIvmDAO.selectExpdPacScnCd(reqDto.getDataSn(), reqDto.getUserEeno(), reqDto.getDlExpdCoCd());
        reqDto.setDlExpdPacScnCd(expdPacScnCd.get("DL_EXPD_PAC_SCN_CD"));
        reqDto.setDlExpdPdiCd(expdPacScnCd.get("DL_EXPD_PDI_CD"));
        reqDto.setLangCd(expdPacScnCd.get("LANG_CD"));

        HashMap<String,String> fuGetWrkdate = comIvmDAO.fuGetWrkdate(reqDto.getBDate());
        reqDto.setVWrkYmd(fuGetWrkdate.get("V_WRK_YMD"));

        result = pdiIvmDAO.selectPdiPrndMonitor(reqDto);
        result.setVLocalChar(reqDto.getVLocalChar());

        return result;
    }

    @Override
    public List<PdiWhsnResDTO> selectPdiWhsnList(ComIvmReqDTO reqDto) throws Exception {
        List<PdiWhsnResDTO> result = new ArrayList<PdiWhsnResDTO>();
        result = pdiIvmDAO.selectPdiWhsnList(reqDto);
        return result;
    }

    @Transactional
    @Override
    public Integer insertPdiWhsnInfos(List<PdiWhsnReqDTO> reqDto, String userEeno) throws Exception {
        Integer totalResult = 0;
        for(PdiWhsnReqDTO param : reqDto) {
            param.setCrgrEeno(userEeno);
            param.setUserEeno(userEeno);
            int whsnQty =  pdiIvmDAO.getWhsnQty(param);

            //--입고확인되지 않은 데이터만을 저장하도록 한다.
            if(0 != whsnQty){
                //--입고상태가 부족인 경우 에는 입고수량에서 부족 수량을 빼준다.
                if("02".equals(param.getExpdWhsnStCd())){
                    whsnQty = param.getWhsnQty() - param.getDeei1Qty();
                    if(whsnQty<0){

                    }
                }
                // 추가 입고 수량 합계
                else if("04".equals(param.getExpdWhsnStCd())){
                    whsnQty = param.getWhsnQty() + param.getDeei1Qty();
                }
                // 정상입고
                else{
                    whsnQty = Integer.valueOf(param.getRqQty());
                }

                param.setWhsnQty(whsnQty);

                try{
                    pdiIvmDAO.insertPdiWhsnInfo(param);
                }catch(Exception e){
                    e.printStackTrace();
                    throw e;
                }

                //--이미 재고등록된 항목이 존재하는지의 여부를 확인한다.
                int vCnt = pdiIvmDAO.getPdiIvCnt(param);

                //--PDI 재고정보 Insert(입고확인)
                if(vCnt == 0){

                    try{
                        pdiIvmDAO.insertPdiIvInfo(param);
                    }catch(Exception e){
                        e.printStackTrace();
                    }

                    //DTO를 HashMap으로 변환하여 asis때 사용된 메서드 호출..
                    ObjectMapper objectMapper = new ObjectMapper();
                    HashMap<String, Object> hMap = objectMapper.convertValue(param, HashMap.class);

                    spUpdatePdiIvDtlInfo(hMap);
                    spRecalculatePdiIvDtl4(hMap);

                }
                else{
                    int vQty = pdiIvmDAO.getVQty(param);
                    int vDiffQty = 0;
                    if(vQty < (whsnQty*-1)){

                    }else{
                        vDiffQty = (whsnQty *-1);
                    }

                    //DTO를 HashMap으로 변환하여 asis때 사용된 메서드 호출..
                    ObjectMapper objectMapper = new ObjectMapper();
                    HashMap<String, Object> hMap = objectMapper.convertValue(param, HashMap.class);
                    hMap.put("vDiffQty", vDiffQty);
                    int pdiIvInfoDtl5 = pdiIvmDAO.updatePdiIvInfoDtl5(hMap);
                    if(!(pdiIvInfoDtl5 >0)){
                    }

                    spUpdatePdiIvDtlInfo(hMap);
                    spRecalculatePdiIvDtl4(hMap);
                }

                //--세화 출고내역에서 입고확인상태로 변경하는 작업 수행(세화재고에서 제외하는 작업도 같이 수행)
                int sewhaWhotInfo = pdiIvmDAO.updateSewhaWhotInfo(param);
                if(!(sewhaWhotInfo >0)){
                    break;
                }

                //--세화 재고정보 업데이트 수행
                HashMap<String, Integer> vQty1Map = pdiIvmDAO.getVQty1(param);
                int vQty1 = Integer.valueOf(String.valueOf(vQty1Map.get("V_QTY")));
                int vDeei1Qty = Integer.valueOf(String.valueOf(vQty1Map.get("V_DEEI1_QTY")));

                //--입고확인시의 재고보정인 경우
                //--입고확인작업은 수정기능이 없고, 수량이 증가만 되고 감소가 되지 않으므로
                //--재고수량보다 출고요청수량이 큰지의 여부만을 확인해 주면 된다.
                int vDiffRqQty = 0;
                if(vQty1 < whsnQty){
                    vDiffRqQty = vQty1;
                    vDeei1Qty = vDeei1Qty + (whsnQty - vQty1);
                }else{
                    vDiffRqQty = whsnQty;
                }
                param.setVDiffRqQty(vDiffRqQty);
                param.setVDeei1Qty(vDeei1Qty);
                //--현재 날짜에 재고 데이터가 존재하지 않더라도 예외발생 없이 그대로 진행하도록 한다.
                int sewhaIvInfo = pdiIvmDAO.updateSewhaIvInfo(param);
                    totalResult += sewhaIvInfo;
                //--재고 데이터가 없어서 입력이 되지 않은 경우에는 0 으로 추가해 준다.
                if(!(sewhaIvInfo >0)){
                    totalResult += pdiIvmDAO.insertSewhaIvInfo(param);
                }

                //DTO를 HashMap으로 변환하여 asis때 사용된 메서드 호출..
                ObjectMapper objectMapper = new ObjectMapper();
                HashMap<String, Object> hMap = objectMapper.convertValue(param, HashMap.class);
                //--현재의 출고 내역을 재고상세 테이블에 저장한다.
                spUpdateSewhaIvDtlInfo(hMap);
                //--출고 내역에 대한 재고상세 테이블 재계산 작업 수행
                spRecalculateSewhaIvDtl4(hMap);

            }else{
//                msg= "Sewon delivery quantity(include shortage qty) is more than zero \n"
//                    + "date: " + date.toString() + ", \n"
//                    + "vehl: " + pVehlCd + ", \n"
//                    + "mkyr: " + pExpdMdlMdyCd + ", \n"
//                    + "lang: " + pLangCd + "," + pNPrntPbcnNo + ", \n"
//                    + "sn: " + pDtlSn;
            }
        }
        return totalResult;
    }

    private void spUpdatePdiIvDtlInfo(HashMap<String, Object> hMap) throws Exception {

        //--입고/출고된 항목에 대한 재고상세 테이블 업데이트 작업 수행
        HashMap<String, Object> cmplYn = pdiIvmDAO.getCmplYn(hMap);
        String vIvQty = cmplYn.get("V_IV_QTY")==null?"0":String.valueOf(cmplYn.get("V_IV_QTY"));
        String vCmplYn = cmplYn.get("V_CMPL_YN")==null?"":String.valueOf(cmplYn.get("V_CMPL_YN"));
        String vTmpTrtmYn = cmplYn.get("V_TMP_TRTM_YN")==null?"":String.valueOf(cmplYn.get("V_TMP_TRTM_YN"));
        hMap.put("vIvQty", vIvQty);
        hMap.put("vCmplYn", vCmplYn);
        hMap.put("vTmpTrtmYn", vTmpTrtmYn);

        //--현재의 입고 내역을 재고상세 테이블에 저장한다.
        if(null != vCmplYn){
            int pdiIvInfoDtl = pdiIvmDAO.updatePdiIvInfoDtl(hMap);
            if(pdiIvInfoDtl==0){
                pdiIvmDAO.insertPdiIvInfoDtl(hMap);
            }
        }
    }

    private void spRecalculatePdiIvDtl4(HashMap<String, Object> hMap) throws Exception {

        //--입고내역에 대한 재고상세 테이블 재계산 작업 수행
        List<HashMap<String, Object>> pdiIvListInfo = pdiIvmDAO.getPdiIvListInfo(hMap);

        //--취급설명서 연식과 차종연식이 다른 항목은 우선 삭제한다.
        int pdiIvInfoDtl = pdiIvmDAO.deletePdiIvInfoDtl(hMap);

        //--취급설명서 연식과 차종연식이 같은 경우에는 안전재고수량을 재고수량으로 업데이트 해 준다.
        int pdiIvInfoDtl2 = pdiIvmDAO.updatePdiIvInfoDtl2(hMap);

        for(int j=0; j<pdiIvListInfo.size();j++){
            HashMap<String, Object> jHMap = pdiIvListInfo.get(j);
            hMap.put("pVehlCd", String.valueOf(jHMap.get("QLTY_VEHL_CD")));
            String dlExpdMdlMdyCd = String.valueOf(jHMap.get("DL_EXPD_MDL_MDY_CD"));
            hMap.put("pExpdMdlMdyCd", dlExpdMdlMdyCd);
            hMap.put("pLangCd", String.valueOf(jHMap.get("LANG_CD")));
            hMap.put("pNPrntPbcnNo", String.valueOf(jHMap.get("NEW_PRNT_PBCN_NO")));

            List<HashMap<String, Object>> mdlMdyCd = pdiIvmDAO.getMdlMdyCd(hMap); //mdlMdyCd
            HashMap<String, Object> cmplYn1 = pdiIvmDAO.getCmplYn(hMap);

            int vIvQty = Integer.valueOf(String.valueOf(cmplYn1.get("V_IV_QTY")));

            String vCmplYn = cmplYn1.get("V_CMPL_YN")==null?"":String.valueOf(cmplYn1.get("V_CMPL_YN"));
            String vTmpTrtmYn = cmplYn1.get("V_TMP_TRTM_YN")==null?"":String.valueOf(cmplYn1.get("V_TMP_TRTM_YN"));
            hMap.put("vCmplYn", vCmplYn);
            hMap.put("vTmpTrtmYn", vTmpTrtmYn);
//            hMap.put("vCmplYn", cmplYn1.get("V_CMPL_YN"));
//            hMap.put("vTmpTrtmYn", cmplYn1.get("V_TMP_TRTM_YN"));

            /*--취급설명서 연식의 3일생산 계획 데이터 조회*/
            int vDlDay3PlanQty = pdiIvmDAO.getDay3PlanQty(hMap);
            hMap.put("vDlDay3PlanQty", vDlDay3PlanQty);

            int vSftyIvDiff = 0;
            String vFlag = "";
            int tempIvQty = 0;
            for(int k=0; k<mdlMdyCd.size();k++){
                HashMap<String, Object> kHMap = mdlMdyCd.get(k);
                String currMdlMdyCd = String.valueOf(kHMap.get("MDL_MDY_CD"));
                hMap.put("currMdlMdyCd",currMdlMdyCd);

                int vCurrDay3PlanQty = pdiIvmDAO.getCurrDay3PlanQty(hMap);
                hMap.put("vCurrDay3PlanQty", vCurrDay3PlanQty);

                int vCurrSftyIvQty = pdiIvmDAO.getCurrSftyIvQty(hMap);
                hMap.put("vCurrSftyIvQty", vCurrSftyIvQty);

                int vSftyIvDiffQty= vCurrDay3PlanQty - vCurrSftyIvQty;
                hMap.put("vSftyIvDiffQty", vSftyIvDiffQty);
                //--2주 생산계획과 안전재고의 차이가 0 보다 큰 경우에만 계산 작업을 진행한다.
                //--(왜냐하면 사전에 초기화 한 상태에서 진행하므로 순수하게 현재 연식에 관계된 것만 있으므로 0 보다 작으면
                //-- 재고가 충분하다는 것이므로 작업할 필요가 없다.)
                if(vSftyIvDiffQty >0){
                    //--재계산할 재고수량이 존재하는 경우에만 재계산 작업을 수행한다.
                    if(vIvQty >0){
                        //--재계산할 연식이 취급설명서 연식보다 이전 연식이라면
                        //--재계산 작업을 수행한다.
                        if(dlExpdMdlMdyCd.compareTo(currMdlMdyCd)> -1){
                            if(vSftyIvDiffQty >= vIvQty){
                                vSftyIvDiff = vIvQty;
                                vIvQty = 0;
                            }else{
                                vSftyIvDiff = vSftyIvDiffQty;
                                vIvQty = vIvQty - vSftyIvDiffQty;
                            }
                            vFlag = "Y";
                        }else{
                            //--재계산할 연식이 취급설명서 연식보다 최근 연식이라면
                            //--이전연식의 2주생산계획 수량보다 재고수량이 큰 경우에만 작업해 주도록 한다.
                            tempIvQty = pdiIvmDAO.getTempIvQty(hMap);
                            tempIvQty = tempIvQty - vDlDay3PlanQty;
                            if(tempIvQty >0){
                                if(vIvQty < tempIvQty){ tempIvQty = vIvQty; }
                                if(vSftyIvDiffQty >= tempIvQty){
                                    vSftyIvDiff = tempIvQty;
                                    vIvQty  = vIvQty - tempIvQty;
                                }else{
                                    vSftyIvDiff=vSftyIvDiffQty;
                                    vIvQty=vIvQty-vSftyIvDiffQty;
                                }
                                vFlag = "Y";
                            }else{
                                vFlag = "N";
                                vSftyIvDiff=0;
                            }
                        }
                    }else{
                        vFlag = "N";
                        vSftyIvDiff=0;
                    }
                }else{
                    vFlag = "N";
                    vSftyIvDiff=0;
                }

                hMap.put("tempIvQty", tempIvQty);
                hMap.put("vIvQty", vIvQty);
                hMap.put("vSftyIvDiff", vSftyIvDiff);

                if(vFlag.equals("Y")){
                    int pdiIvInfoDtl3 = pdiIvmDAO.updatePdiIvInfoDtl3(hMap);
                }
                int pdiIvInfoDtl4 = pdiIvmDAO.updatePdiIvInfoDtl4(hMap);
                if(!(pdiIvInfoDtl4 >0)){
                    pdiIvmDAO.insertPdiIvInfoDtl1(hMap);
                }
            }//k
        }//j
    }

    private void spUpdateSewhaIvDtlInfo(HashMap<String, Object> hMap) throws Exception {
        HashMap<String, Object> sewhaCmplYn = pdiIvmDAO.getSewhaCmplYn(hMap);
        int vIvQty = Integer.valueOf(String.valueOf(sewhaCmplYn.get("V_IV_QTY")));
        int vExpdTmpIvQty = Integer.valueOf(String.valueOf(sewhaCmplYn.get("V_EXPD_TMP_IV_QTY")));
        String vCmplYn = String.valueOf(sewhaCmplYn.get("V_CMPL_YN"));
        String vTmpTrtmYn = (String) sewhaCmplYn.get("V_TMP_TRTM_YN");

        hMap.put("vIvQty", vIvQty);
        hMap.put("vExpdTmpIvQty", vExpdTmpIvQty);
        hMap.put("vCmplYn", vCmplYn);
        hMap.put("vTmpTrtmYn", vTmpTrtmYn);

        //--재고 테이블에 데이터가 존재하는 경우에 아래의 작업을 수행한다.
        if(null != vCmplYn){
            //--재고상세 테이블내에 취급설명서연식으로 적용된 항목의 재고수량을 변경된 수량으로
            //--모두 업데이트 해 준다.
            //--단, 차종의 연식과 취급설명서의 연식이 같은 경우에만 업데이트 해준다.
            //--(왜냐하면 같은 않은 항목은 재고 상세 내역 재계산시에 우선 삭제된 뒤에 다시 계산하기 때문에 의미가 없다.)
            int sewhaIvInfoDtl = pdiIvmDAO.updateSewhaIvInfoDtl(hMap);
            if(!(sewhaIvInfoDtl>0)){
                pdiIvmDAO.insertSewhaIvInfoDtl(hMap);
            }
        }
    }

    private void spRecalculateSewhaIvDtl4(HashMap<String, Object> hMap) throws Exception {
        List<HashMap<String, Object>> sewhaIvList = pdiIvmDAO.getSewhaIvList(hMap);
        //--취급설명서 연식과 차종연식이 다른 항목은 우선 삭제한다.
        int deleteSewhaIvInfoDtl = pdiIvmDAO.deleteSewhaIvInfoDtl(hMap);
        //--취급설명서 연식과 차종연식이 같은 경우에는 안전재고수량을 재고수량으로 업데이트 해 준다.
        int updateSewhaIvInfoDtl1 = pdiIvmDAO.updateSewhaIvInfoDtl1(hMap);

        for(int i=0; i<sewhaIvList.size(); i++){
            HashMap<String, Object> iMap = sewhaIvList.get(i);

//            iMap.put("prdnPlntCd", (String) hMap.get("prdnPlntCd"));


            List<HashMap<String, Object>> sewhaIvDtlIvList = pdiIvmDAO.getSewhaDtlIvList(iMap);
            HashMap<String, Object> vDlIvQtyMap = pdiIvmDAO.getVDlIvQty(iMap);

            int vDlIvQty = Integer.valueOf(String.valueOf(vDlIvQtyMap.get("V_DL_IV_QTY")));
            int vDlExpdTmpIvQty = Integer.valueOf(String.valueOf(vDlIvQtyMap.get("V_DL_EXPD_TMP_IV_QTY")));
            String vDlCmplYn = String.valueOf(vDlIvQtyMap.get("V_DL_CMPL_YN"));
            String vDlTmpTrtmYn = (String) vDlIvQtyMap.get("V_DL_TMP_TRTM_YN");


            //--취급설명서 연식의 2주생산 계획 데이터 조회
            int vDlWek2PlanQty = pdiIvmDAO.getVDlWek2PlanQty(iMap);
            iMap.put("vDlWek2PlanQty", vDlWek2PlanQty);
            //--취급설명서 연식의 PDI 안전재고수량 조회
            int vDlPdiIvQty = pdiIvmDAO.getVDlPdiIvQty(iMap);
            iMap.put("vDlPdiIvQty", vDlPdiIvQty);

            int vSftyIvDiff =  0;
            String vFlag = "";
            for(int j=0; j<sewhaIvDtlIvList.size();j++){
                HashMap<String, Object> jMap = sewhaIvDtlIvList.get(j);
                String vCurrMdlMdyCd = String.valueOf(jMap.get("MDL_MDY_CD"));
                iMap.put("vCurrMdlMdyCd", vCurrMdlMdyCd);

                //--2주생산 계획 데이터 조회
                int vCurrWek2PlanQty = pdiIvmDAO.getVCurrWek2PlanQty(iMap);
                iMap.put("vCurrWek2PlanQty", vCurrWek2PlanQty);

                //--현재 안전재고 수량 조회
                int vCurrSftyIvQty = pdiIvmDAO.getVCurrSftyIvQty(iMap);
                iMap.put("vCurrSftyIvQty", vCurrSftyIvQty);

                //--PDI 안전재고수량 조회
                int vCurrPdiIvQty = pdiIvmDAO.getVCurrPdiIvQty(iMap);
                iMap.put("vCurrPdiIvQty", vCurrPdiIvQty);

                //-- 2주생산계획 수량 - (현재의 안전재고 수량 + PDI 안전재고 수량)
                int vSftyIvDiffQty = vCurrWek2PlanQty - (vCurrSftyIvQty + vCurrPdiIvQty);
                /*--2주 생산계획과 안전재고의 차이가 0 보다 큰 경우에만 계산 작업을 진행한다.
                --(왜냐하면 사전에 초기화 한 상태에서 진행하므로 순수하게 현재 연식에 관계된 것만 있으므로 0 보다 작으면
                -- 재고가 충분하다는 것이므로 작업할 필요가 없다.)*/
                if(vSftyIvDiffQty > 0){//00
                    //--재계산할 재고수량이 존재하는 경우에만 재계산 작업을 수행한다.
                    if(vDlIvQty>0){//10
                        //--재계산할 연식이 취급설명서 연식보다 이전 연식이라면
                        //--재계산 작업을 수행한다.
                        String dlExpdMdlMdyCd = String.valueOf(hMap.get("dlExpdMdlMdyCd"));
                        if( dlExpdMdlMdyCd.compareTo(vCurrMdlMdyCd) > -1 ){//20
                            if(vSftyIvDiffQty >= vDlIvQty){//30
                                vSftyIvDiff =  vDlIvQty;
                                vDlIvQty = 0;
                            }else{//31
                                vSftyIvDiff = vSftyIvDiffQty;
                                vDlIvQty  = vDlIvQty - vSftyIvDiffQty;
                            }//3x

                            vFlag = "Y";
                        //--재계산할 연식이 취급설명서 연식보다 최근 연식이라면
                        //--이전연식의 2주생산계획 수량보다 재고수량이 큰 경우에만 작업해 주도록 한다.
                        }else{//21
                            //================================================================================>>>>>>>>>>>>>>
                            int vTempIvQty = pdiIvmDAO.getVTempIvQty(iMap);
                            vTempIvQty = (vTempIvQty + vDlPdiIvQty) -vDlWek2PlanQty;
                            if(vTempIvQty>0){//30
                                if(vDlIvQty<vTempIvQty){//40
                                    vTempIvQty = vDlIvQty;
                                }//4x
                                if(vSftyIvDiffQty>vTempIvQty){//40
                                    vSftyIvDiffQty = vTempIvQty;
                                    vDlIvQty  = vDlIvQty - vTempIvQty;
                                }else{//41
                                    vSftyIvDiff = vSftyIvDiffQty;
                                    vDlIvQty  = vDlIvQty - vSftyIvDiffQty;
                                }//4x
                                vFlag = "Y";
                            }else{//31
                                vFlag = "N";
                                vSftyIvDiff = 0;
                            } //--재계산할 재고수량 존재여부 확인 End //3x
                            iMap.put("vTempIvQty", vTempIvQty);

                        }//--이전연식여부 비교 End //2x

                    }else{//11
                        vFlag = "N";
                        vSftyIvDiff = 0;
                    }////--재계산할 재고수량 존재여부 확인 End  //1x
                }else{//01
                    vFlag = "N";
                    vSftyIvDiff = 0;

                }//--2주생산 계획 수량 존재여부 확인 End 0x

                //vCurrMdlMdyCd in for j
                iMap.put("vSftyIvDiff", vSftyIvDiff);
                iMap.put("userEeno", hMap.get("userEeno"));
                iMap.put("vDlIvQty", vDlIvQty);
                iMap.put("vDlExpdTmpIvQty", vDlExpdTmpIvQty);
                iMap.put("vDlCmplYn", vDlCmplYn);
                iMap.put("vDlTmpTrtmYn", vDlTmpTrtmYn);

                int updateSewhaIvInfoDtl = 0;
                //--재고 재계산에 의하여 취급설명서 연식의 안전재고 수량이 변경된 경우
                if(vFlag.equals("Y")){
                    //--차종연식과 취급설명서연식이 같은 항목에
                    //--재고 상세 재계산 후 남은 수량을 업데이트 해 준다.
                    updateSewhaIvInfoDtl = pdiIvmDAO.updateSewhaIvInfoDtl2(iMap);
                }else{
                    updateSewhaIvInfoDtl = pdiIvmDAO.updateSewhaIvInfoDtl3(iMap);
                }

                if(!(updateSewhaIvInfoDtl>0)){
                    pdiIvmDAO.insertSewhaIvInfoDtl1(iMap);
                }

            }//for end
        }
    }

    @Override
    public List<SewonIvModResDTO> selectIvModList(ComIvmReqDTO reqDto) throws Exception {
        List<SewonIvModResDTO> result = new ArrayList<SewonIvModResDTO>();
        result = pdiIvmDAO.selectIvPdiModList(reqDto);
        return result;
    }

    @Transactional
    @Override
    public Integer insertIvModList(List<SewonIvModReqDTO> reqDto, String userEeno, String dlExpdCoCd) throws Exception {
        Integer result = 0;
        try {
            for(SewonIvModReqDTO param : reqDto) {
                param.setUserEeno(userEeno);
                param.setDlExpdCoCd(dlExpdCoCd);

                HashMap<String, String> pdiChkWhot = pdiIvmDAO.selectChkWhotCnt(param); // 등록된 재고보정 조회 DECODE(COUNT(*),0,'Y','N') AS CHK_WHOT
                String chkWhot = pdiChkWhot.get("CHK_WHOT");

                String oriModCd = param.getOriModCd();
                String modCd = param.getModCd();
                int modQty = param.getModQty();
                if("N".equals(chkWhot) && !"N".equals(oriModCd)){  // 이전 재고 보정 있을경우 삭제 / 재고처리 후 기존로직 수행

                    if("05".equals(oriModCd) || "06".equals(oriModCd) || "11".equals(oriModCd)){  // 삭제라서 (-)
                        param.setOriModQty(Math.abs(param.getOriModQty()));
                    }else{
                        param.setOriModQty(Math.abs(param.getOriModQty()) * (-1));
                    }

//                    param.setModQty(param.getOriModQty());
//                    param.setModCd(param.getOriModCd());

                    // 1. PDI 재고 +,-
                    pdiIvmDAO.updatePdiIvCancl(param);
                    pdiIvmDAO.updatePdiIvDtlCancl(param);
                    pdiIvmDAO.deletePdiIvInfo(param);

                    if("08".equals(oriModCd) || "09".equals(oriModCd)){ // 세원재고는 다시 * (-1) 쿼리에
                        pdiIvmDAO.updateSeWonIvCancl(param);
                        pdiIvmDAO.updateSeWonIvDtlCancl(param);
                        pdiIvmDAO.insertSeWonCanclWhot(param);
                    }
                }

                param.setModCd(modCd);
                //--재고 보정 추가 삭제 구분
                if("05".equals(modCd) || "06".equals(modCd) || "11".equals(modCd)){
                    modQty = Math.abs(modQty) * (-1);
                }else{
                    modQty = Math.abs(modQty);
                }

                param.setModQty(modQty);

                //--재고수량이 출고수량보다 작은 경우에는 출고 하지 못한다.
                if(param.getIvQty() < modQty) break;

                //DTO를 HashMap으로 변환하여 asis때 사용된 메서드 호출..
                ObjectMapper objectMapper = new ObjectMapper();
                HashMap<String, Object> hMap = objectMapper.convertValue(param, HashMap.class);
                hMap.put("bDate", param.getBDate());
                hMap.put("vDiffQty", modQty);
                int resultTmp = pdiIvmDAO.updatePdiIvInfoDtl5(hMap);  //TB_PDI_IV_INFO insert

                if(!(resultTmp>0)){
                    pdiIvmDAO.insertPdiIvInfo1(hMap);  //TB_PDI_IV_INFO insert
                }

                //--현재의 출고 내역을 재고상세 테이블에 저장한다.
                spUpdatePdiIvDtlInfo(hMap);
                //--출고 내역에 대한 재고상세 테이블 재계산 작업 수행
                spRecalculatePdiIvDtl4(hMap);

                //--출고항목 업데이트 작업 수행
                resultTmp = pdiIvmDAO.updatePdiWhotInfo(param);
                if(!(resultTmp>0)){
                    pdiIvmDAO.insertPdiWhotInfo(param);
                }

                //--반출, 불량일 경우에는 세화재고에 추가해 주는 작업을 수행해 주어야 한다.
                if("08".equals(modCd) || "09".equals(modCd)){
                    pdiIvmDAO.insertSewhaWhotInfo(param);

                    int ivQty = pdiIvmDAO.getVQtyPdi(param);

                    int sewhaIvInfo1 = pdiIvmDAO.updateSewhaIvInfo1(param);
                    if(!(sewhaIvInfo1>0)){
                        //--이미 세화재고가 소진되어 값이 없는 경우에는 재고에 그냥 추가해 준다.
                        pdiIvmDAO.insertSewhaIvInfo1(param);
                    }

                    spUpdateSewhaIvDtlInfo(hMap);
                    spRecalculateSewhaIvDtl4(hMap);

                }
                else if("02".equals(modCd)) {
                    //--별도 요청정보 업데이트
                    String vRqYmd = pdiIvmDAO.getVRqYmd(hMap);
                    hMap.put("vRqYmd", vRqYmd);
                    if(vRqYmd!=null){
                        String vDtlSn = pdiIvmDAO.getVDtlSn(hMap);
                        hMap.put("vDtlSn", vDtlSn);
                        if(vDtlSn!=null){
                            pdiIvmDAO.updateExtraReqInfo(hMap);
                        }
                    }
                    hMap.put("vPrevWhotQty", modQty);
                    //if(whotQty!=null)
                    vRqYmd = pdiIvmDAO.getVRqYmd(hMap);
                    hMap.put("vRqYmd", vRqYmd);
                    if(vRqYmd!=null){
                        String vDtlSn = pdiIvmDAO.getVDtlSn(hMap);
                        hMap.put("vDtlSn", vDtlSn);
                        if(vDtlSn!=null){
                            pdiIvmDAO.updateExtraReqInfo(hMap);
                        }
                    }
                }
            result++;
            }// for end
            return result;
        } catch(RuntimeException e) {
            e.printStackTrace();
            return 0;
        } catch(Exception e) {
            e.printStackTrace();
            return 0;
        }
    }

    @Transactional
    @Override
    public Integer deleteIvModList(List<SewonIvModReqDTO> reqDto, String userEeno, String dlExpdCoCd) throws Exception {
        int result = 0;

        for(SewonIvModReqDTO param : reqDto) {
            param.setUserEeno(userEeno);
            param.setDlExpdCoCd(dlExpdCoCd);

            HashMap<String, Object> dlExpdWhotQtyMap = pdiIvmDAO.getDlExpdWhotQty(param);

            String vExpdWhotStCd = String.valueOf(dlExpdWhotQtyMap.get("V_EXPD_WHOT_ST_CD"));
            String vDiffWhotQty = String.valueOf(dlExpdWhotQtyMap.get("V_DIFF_WHOT_QTY"));

            //DTO를 HashMap으로 변환하여 asis때 사용된 메서드 호출..
            ObjectMapper objectMapper = new ObjectMapper();
            HashMap<String, Object> hMap = objectMapper.convertValue(param, HashMap.class);

            if(vDiffWhotQty != null){
                if(vExpdWhotStCd.equals("05") || vExpdWhotStCd.equals("06") || vExpdWhotStCd.equals("11")){
                    hMap.put("vDiffWhotQty", Math.abs(Integer.parseInt(vDiffWhotQty)));
                }else{
                    hMap.put("vDiffWhotQty", Math.abs(Integer.parseInt(vDiffWhotQty)) * (-1));
                }

                hMap.put("pBatchFlag", "N");
                hMap.put("pCascadeFlag", "N");
                hMap.put("bDate", param.getBDate());
                //--재고데이터 업데이트 작업 수행
                spPdiIvInfoUpdate(hMap, param);

                //--출고항목 업데이트 작업 수행
                pdiIvmDAO.deletePdiIvInfo(param);


                String modCd = param.getModCd();

                //--반출, 불량일 경우에는 세화재고에서도 빼주는 작업을 수행해야 한다.
                if("08".equals(modCd)||"09".equals(modCd)){
                    pdiIvmDAO.insertSewhaWhotInfo(param);

                    int vQty = pdiIvmDAO.getVQtyPdi(param);

                    if(vQty - (Integer)hMap.get("vDiffWhotQty") <0) break;
                    int sewhaIvInfo1 = pdiIvmDAO.updateSewhaIvInfo1(param);
                    if(!(sewhaIvInfo1>0)){
                        //--이미 세화재고가 소진되어 값이 없는 경우에는 재고에 그냥 추가해 준다.
                        pdiIvmDAO.insertSewhaIvInfo1(param);
                    }

                    spUpdateSewhaIvDtlInfo(hMap);
                    spRecalculateSewhaIvDtl4(hMap);

                }else if("02".equals(modCd)){
                    //--별도 요청정보 업데이트
                    hMap.put("vPrevWhotQty", (Integer)hMap.get("vDiffWhotQty"));//vPrevWhotQty
                    //if(vPrevWhotQty!=null)
                    String vRqYmd = pdiIvmDAO.getVRqYmd(hMap);
                    hMap.put("vRqYmd", vRqYmd);
                    if(vRqYmd!=null){
                        String vDtlSn = pdiIvmDAO.getVDtlSn(hMap);
                        hMap.put("vDtlSn", vDtlSn);
                        if(vDtlSn!=null){
                            pdiIvmDAO.updateExtraReqInfo(hMap);
                        }
                    }
                    hMap.put("vPrevWhotQty", null);//whotQty
                    if(hMap.get("vPrevWhotQty")!=null){//whotQty!=null
                        vRqYmd = pdiIvmDAO.getVRqYmd(hMap);
                        hMap.put("vRqYmd", vRqYmd);
                        if(vRqYmd!=null){
                            String vDtlSn = pdiIvmDAO.getVDtlSn(hMap);
                            hMap.put("vDtlSn", vDtlSn);
                            if(vDtlSn!=null){
                                pdiIvmDAO.updateExtraReqInfo(hMap);
                            }
                        }
                    }
                }
            }
        result ++;
        }// for end

        return result;
    }

    private void spPdiIvInfoUpdate(HashMap<String, Object> hMap, SewonIvModReqDTO param) throws Exception {
        int vDiffQty = 0;
        if(hMap.get("pBatchFlag").equals("N")){
            if(hMap.get("pCascadeFlag").equals("N")){
                int vQty = pdiIvmDAO.getVQtyPdi(param);

                //--재고수량이 출고수량보다 작은 경우에는 출고 하지 못한다.
                if(vQty<(Integer)hMap.get("vDiffWhotQty")) {
                    return;
                }else{
                    vDiffQty = (Integer)hMap.get("vDiffWhotQty");
                }

                hMap.put("vDiffWhotQty", vDiffQty);
                int pdiIvInfo = pdiIvmDAO.updatePdiIvInfo(hMap);
                if(!(pdiIvInfo >0)){
                    return;
                }
                //--현재의 재고보정 내역을 재고상세 테이블에 저장한다.
                spUpdatePdiIvDtlInfo(hMap);
                //--재고보정에 대한 재고상세 테이블 재계산 작업 수행
                spRecalculatePdiIvDtl4(hMap);
            }else{
                return;
            }
        }else{
            HashMap<String, Integer> vQty1Map = pdiIvmDAO.getVQty1Pdi(hMap);

            int vQty1 = Integer.valueOf(String.valueOf(vQty1Map.get("V_QTY")));
            int vDeei1Qty = Integer.valueOf(String.valueOf(vQty1Map.get("V_DEEI1_QTY")));
            int vDiffWhotQty =(Integer)hMap.get("vDiffWhotQty");
            if(vQty1<vDiffWhotQty){
                //--재고 수량보다 출고수량이 많은 경우에는 재고수량을 0 으로 해준다.
                vDiffQty  = vQty1;

                //--배치 프로그램이 아닌 다름 프로그램에서 호출시에 문제 발생 여지 있음
                vDeei1Qty = vDeei1Qty + ((Integer)hMap.get("vDiffWhotQty") - vQty1);
            }else{
                if(vDeei1Qty > 0 && vQty1==0){
                    if(vDiffWhotQty + vDeei1Qty >0){
                        vDiffQty  = vQty1;
                        vDeei1Qty = vDiffWhotQty + vDeei1Qty;
                    }else{
                        vDeei1Qty = vDiffWhotQty + vDeei1Qty;
                        vDeei1Qty = 0;
                    }
                }else{
                    vDiffQty = vDiffWhotQty;
                }
            }

            hMap.put("vDiffQty", vDiffQty);
            hMap.put("vDeei1Qty", vDeei1Qty);
            int pdiIvInfoDtl6 = pdiIvmDAO.updatePdiIvInfoDtl6(hMap);
            if(!(pdiIvInfoDtl6 >0)){
                //--과잉출고 되어 재고 보정작업하는 경우에만 신규로 추가해 주면 된다.
                //--(V_DIFF_QTY 로 비교하지 않도록 주의 할 것)
                if(vDiffWhotQty < 0){
                    pdiIvmDAO.insertPdiIvInfo2(hMap);
                }
            }
            //--현재의 재고보정 내역을 재고상세 테이블에 저장한다.
            spUpdatePdiIvDtlInfo(hMap);
            //--재고상세 테이블 재계산 작업은 외부(배치프로그램)에서 수행해 준다.
        }
    }

    @Override
    public Integer insertPdiDlvtRequestInfos(List<ComIvmReqDTO> reqDto, String userEeno, String dlExpdCoCd) throws Exception {
        int result = 0;
        List<ComIvmReqDTO> params = new ArrayList<ComIvmReqDTO>();
        reqDto.forEach(param -> {
            param.setUserEeno(userEeno);
            param.setDlExpdCoCd(dlExpdCoCd);
            params.add(param);
        });
        result = pdiIvmDAO.insertPdiDlvtRequestInfos(params);
        return result;
    }
    @Override
    public Integer insertPdiOrderRequestInfos(List<ComIvmReqDTO> reqDto, String userEeno, String dlExpdCoCd) throws Exception {
        int result = 0;
        List<ComIvmReqDTO> params = new ArrayList<ComIvmReqDTO>();
        reqDto.forEach(param -> {
            param.setUserEeno(userEeno);
            param.setDlExpdCoCd(dlExpdCoCd);
            params.add(param);
        });
        result = pdiIvmDAO.insertPdiOrderRequestInfos(params);
        return result;
    }

    @Override
    public List<PdiWhsnStatResDTO> selectPdiWhsnStatList(ComIvmReqDTO reqDto) throws Exception {
        List<PdiWhsnStatResDTO> result = new ArrayList<PdiWhsnStatResDTO>();
        result = pdiIvmDAO.selectPdiWhsnStatList(reqDto);
        return result;
    }

    @Override
    public List<IvmRequestMonitorResDTO> selectIvmPdiReqStateList(ComIvmReqDTO reqDto) throws Exception {
        List<IvmRequestMonitorResDTO> result = new ArrayList<IvmRequestMonitorResDTO>();
        result = pdiIvmDAO.selectIvmPdiReqStateList(reqDto);
        return result;
    }


}
