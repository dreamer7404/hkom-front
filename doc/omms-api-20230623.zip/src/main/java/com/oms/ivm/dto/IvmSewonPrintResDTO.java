package com.oms.ivm.dto;

import org.apache.ibatis.type.Alias;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @author 김정웅
 * @since 2023. 6. 21.
 * @see
 */

@Alias("ivmSewonPrintResDTO")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class IvmSewonPrintResDTO {

    private String newPrntPbcnNo;
    private String dlExpdPdiCd;
    private String qltyVehlCd;
    private String qltyVehlNm;
    private String mdlMdyCd;
    private String dlExpdRegnCd;
    private String dlExpdRegnNm;
    private String langCd;
    private String langCdNm;
    private String prntParrYmd;
    private String dlvgParrYmd;
    private int prntQty;        // 인쇄해야하는 총 부수 -> O/M발주 등록때 입력한 인쇄부수
    private int leftQty;        // 인쇄를 해야하는 잔여부수(인쇄총부수  - 인쇄완료부수)
    private int ivQty;          // 인쇄 완료 부수
    private String clsYmd;
    private String prdnPlntCd;
    private String dlExpdTmpIvQty;
    private String cmplYn;
    private String tmpTrtmYn;
    private String deei1Qty;
    private String pprrEeno;
    private String framDtm;
    private String updrEeno;
    private String mdfyDtm;
    private String clScnCd;
    private String dataSn;
    private String langSortSn;

    private String iwayCd;
    private String iwayCdNm;





}
