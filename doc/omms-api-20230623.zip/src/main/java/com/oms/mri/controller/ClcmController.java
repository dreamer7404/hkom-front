package com.oms.mri.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServletRequest;

import able.cloud.core.web.HController;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.oms.cmm.global.Consts;
import com.oms.cmm.utils.Utils;
import com.oms.common.dto.AttcFileReqDTO;
import com.oms.common.dto.AttcFileResDTO;
import com.oms.common.dto.MailDTO;
import com.oms.common.model.Mail;
import com.oms.common.service.AttcFileService;
import com.oms.common.service.MailService;
import com.oms.mri.dto.ClcmInfoPopReqDTO;
import com.oms.mri.dto.ClcmInfoResDTO;
import com.oms.mri.dto.ClcmInfosReqDTO;
import com.oms.mri.dto.ClcmInfosResDTO;
import com.oms.mri.service.ClcmService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;


/**
 * <pre>
 * ClcmController
 * </pre>
 *
 * @ClassName   : ClcmController.java
 * @Description : 제작준비 > 법규 및 변경관리 컨트롤러
 * @author 김정웅
 * @since 2023.5.22.
 * @see
 */
@Tag(name = "ClcmController", description = "")
@RequiredArgsConstructor
@RestController
@RequestMapping("/api")
public class ClcmController extends HController {

    /**
     * 클래스 Injection
     */
    private final HttpServletRequest request;
    private final ClcmService clcmService;
    private final AttcFileService attcFileService;
    private final MailService mailService;

    /**
     * 제작준비 > 법규 및 변경관리 목록조회
     */
    @Operation(summary = "법규 및 변경관리 목록 조회")
    @GetMapping("/mriClcmInfos")
    public List<ClcmInfosResDTO> selectClcmInfoList(@ModelAttribute ClcmInfosReqDTO reqDto) throws Exception {
        //사용자 ID, 회사코드 할당
        reqDto.setUserEeno(Utils.getUserEeno(request));
        reqDto.setDlExpdCoCd(Utils.getDlExpdCoCd(request));

        reqDto.setSDate(reqDto.getSsDate());
        reqDto.setEDate(reqDto.getEeDate());
        reqDto.setBDate(reqDto.getBbDate());

        List<ClcmInfosResDTO> result = new ArrayList<ClcmInfosResDTO>();
        result = clcmService.selectClcmInfoList(reqDto);

        return result;
    }

    /**
     * 제작준비 > 법규 및 변경관리 팝업 저장, 수정
     */
    @Operation(summary = "법규 및 변경관리 목록 등록", description = "")
    @Parameter(in = ParameterIn.HEADER, name="_method")
    @PostMapping(value = "/mriClcmInfoPop")
    public Integer insertClcmInfoPop(@RequestBody ClcmInfoPopReqDTO reqDto) throws Exception {
        String method = Utils.getMethod(request);
        String userEeno = Utils.getUserEeno(request);
        String dlExpdCoCd = Utils.getDlExpdCoCd(request);
        reqDto.setUserEeno(userEeno);
        reqDto.setDlExpdCoCd(dlExpdCoCd);

        int result = 0;

        if(method.equals(Consts.INSERT)) {
            result = clcmService.insertClcmInfoPop(reqDto);

            // 첨부파일 나머지정보 저장
            if(reqDto.getAttcSn() != null && reqDto.getAttcSn().size() > 0 ) {

                List<AttcFileReqDTO> attcFileList = new ArrayList<>();

                for(int i=0; i<reqDto.getAttcSn().size(); i++) {
                    attcFileList.add(new AttcFileReqDTO(
                            Long.valueOf(reqDto.getAttcSn().get(i)),
                            "C",                        // 게시판 코드(attc_gbn)
                            reqDto.getDlExpdAltrNo(),   // 게시판 PK string(gbn_sn)
                            0L,                         // 게시판 PK long(blc_sn)
                            reqDto.getExtension().get(i),
                            reqDto.getOriginalName().get(i),
                            Integer.valueOf(reqDto.getSize().get(i)),
                            userEeno
                            ));
                }
                attcFileService.updateAttcFile(attcFileList);  // 업데이트
            }

            if(result > 0) {
                //----------- 이메일발송 시작------------------------------------------------------------------------
                // 수신자 이메일 조회
                List<String> users = reqDto.getSenderList().stream().map(item -> item.get("userEeno")).collect(Collectors.toList());
                List<Mail> rcvList = mailService.selectEmlAdrList(users);
                if(!rcvList.isEmpty()) {

                    MailDTO mailDTO = new MailDTO(
                            "14",
                            rcvList,
                            userEeno,
                            reqDto.getAltrTitl(),
                            reqDto.getAltrSbc(),
                            "발송대기"
                            );
                    // 메일로그 저장
                    result = mailService.insertLogEml(mailDTO);

                    // 메일송수신자로그 저장
                    result = mailService.insertLogEmlSnd(mailDTO);

                    // 메일전송(Async)
                    mailService.send(mailDTO);

                    return 1; // 저장성공
                }else {
                    return -3; // 이메일정보 없음
                }
                //-----------// 이메일발송 종료 ------------------------------------------------------------------------
            }else {
                return -2; //  저장실패
            }


        } else if(method.equals(Consts.UPDATE)) {
            result = clcmService.updateClcmInfoPop(reqDto);

            // tb_attc_mgmt 기존파일 삭제
            if(reqDto.getAttcSnDeleted() != null && !reqDto.getAttcSnDeleted().isEmpty()) {
                attcFileService.deleteAttcFile(reqDto.getAttcSnDeleted());
            }


            // 새로운 첨부파일 나머지정보 저장
            if(reqDto.getAttcSn() != null && !reqDto.getAttcSn().isEmpty() ) {

                List<AttcFileReqDTO> attcFileList = new ArrayList<>();

                for(int i=0; i<reqDto.getAttcSn().size(); i++) {
                    attcFileList.add(new AttcFileReqDTO(
                            Long.valueOf(reqDto.getAttcSn().get(i)),
                            "C",                                        // 법규 및 변경관리 코드(attcGbn)
                            reqDto.getDlExpdAltrNo(),                   // 법규 및 변경관리 PK string
                            0L,                                         // 법규 및 변경관리 PK long
                            reqDto.getExtension().get(i),
                            reqDto.getOriginalName().get(i),
                            Integer.valueOf(reqDto.getSize().get(i)),
                            userEeno
                            ));
                }
                attcFileService.updateAttcFile(attcFileList);  // 업데이트
            }

            if(result > 0) {
                //----------- 이메일발송 시작------------------------------------------------------------------------
                // 수신자 이메일 조회
                List<String> users = reqDto.getSenderList().stream().map(item -> item.get("userEeno")).collect(Collectors.toList());
                List<Mail> rcvList = mailService.selectEmlAdrList(users);
                if(!rcvList.isEmpty()) {

                    MailDTO mailDTO = new MailDTO(
                            "14",
                            rcvList,
                            userEeno,
                            reqDto.getAltrTitl(),
                            reqDto.getAltrSbc(),
                            "발송대기"
                            );
                    // 메일로그 저장
                    result = mailService.insertLogEml(mailDTO);

                    // 메일송수신자로그 저장
                    result = mailService.insertLogEmlSnd(mailDTO);

                    // 메일전송(Async)
                    mailService.send(mailDTO);

                    return 1; // 저장성공
                }else {
                    return -3; // 이메일정보 없음
                }
                //-----------// 이메일발송 종료 ------------------------------------------------------------------------
            }else {
                return -2; //  저장실패
            }
        }

        return result;
    }

    /**
     * 제작준비 > 법규 및 변경관리 삭제
     */
    @Operation(summary = "법규 및 변경관리 삭제", description = "")
    @Parameter(in = ParameterIn.HEADER, name="_method")
    @PostMapping(value = "/mriDelClcmInfo")
    public Integer deleteClcmInfoPop(@RequestBody List<ClcmInfoPopReqDTO> reqDto) throws Exception {
        String method = Utils.getMethod(request);
        String userEeno = Utils.getUserEeno(request);
        String dlExpdCoCd = Utils.getDlExpdCoCd(request);

        int result = 0;

        if (method.equals(Consts.DELETE)) {
            result = clcmService.deleteClcmInfoPop(reqDto, userEeno, dlExpdCoCd);
        }

        return result;
    }

    /**
     * 제작준비 > 법규 및 변경관리 상세조회
     */
    @Operation(summary = "법규 및 변경관리 상세 조회")
    @GetMapping("/mriClcmInfo")
    public ClcmInfoResDTO selectClcmInfo(@ModelAttribute ClcmInfosReqDTO reqDto) throws Exception {
        //사용자 ID, 회사코드 할당
        reqDto.setUserEeno(Utils.getUserEeno(request));
        reqDto.setDlExpdCoCd(Utils.getDlExpdCoCd(request));

        ClcmInfoResDTO result = new ClcmInfoResDTO();
        result = clcmService.selectClcmInfo(reqDto);

        result.setQltyVehlCd(reqDto.getQltyVehlCd());
        result.setQltyVehlNm(reqDto.getQltyVehlNm());


        // 첨부파일정보
        AttcFileReqDTO attcFileReqDTO = new AttcFileReqDTO();
        attcFileReqDTO.setGbnSn(reqDto.getDlExpdAltrNo());
        attcFileReqDTO.setAttcGbn("C"); // 게시판구분(C: 체크리스트첨부)
        List<AttcFileResDTO> fileList = attcFileService.selectAttcFileList(attcFileReqDTO);
        result.setFileList(fileList);

        return result;
    }

    /**
     * 제작준비 > 법규 및 변경관리 수정 차종 별 언어 조회
     */
    @Operation(summary = "법규 및 변경관리 수정 차종 별 언어 조회")
    @GetMapping("/mriClcmLangCdInfos")
    public List<HashMap<String, String>> selectClcmLangCdList(@ModelAttribute ClcmInfosReqDTO reqDto) throws Exception {
        String qltyVehlCd = reqDto.getQltyVehlCd();

        List<HashMap<String, String>> result = new ArrayList<HashMap<String, String>>();
        result = clcmService.selectClcmLangCdList(qltyVehlCd);

        return result;
    }


}