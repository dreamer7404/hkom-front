package com.oms.common.dto;

import java.util.ArrayList;
import java.util.List;

import org.apache.ibatis.type.Alias;

import lombok.Data;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @author 안경수
 * @since 2023. 6. 7.
 * @see
 */
@Alias("vehlMdyLangListReqDTO")
@Data
public class VehlMdyLangListReqDTO {
    private List<VehlMdyLangReqDTO> list1= new ArrayList<>();
    private List<VehlMdyLangReqDTO> list2= new ArrayList<>();
    private List<VehlMdyLangReqDTO> list3= new ArrayList<>();

}
