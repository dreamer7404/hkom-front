package com.oms.common.dao;

import java.util.HashMap;
import java.util.List;

import com.oms.common.dto.CodeComboResDTO;
import com.oms.common.dto.ComboReqDTO;
import com.oms.common.dto.CommLangComboResDTO;
import com.oms.common.dto.GrpComboResDTO;
import com.oms.common.dto.LangComboResDTO;
import com.oms.common.dto.PdiComboResDTO;
import com.oms.common.dto.RegionComboResDTO;
import com.oms.common.dto.SubCdComboResDTO;
import com.oms.common.dto.VehlComboResDTO;
import com.oms.common.dto.VehlMdyLangListReqDTO;
import com.oms.common.dto.VehlMdyLangReqDTO;
import com.oms.common.dto.VehlMdyLangResDTO;
import com.oms.common.dto.VehlMdyReqDTO;
import com.oms.common.dto.VehlMdyResDTO;

/**
 * <pre>
 * 조회콤보용 리스트 가져오기
 * </pre>
 *
 * @author 안경수
 * @since 2023. 3. 22.
 * @see
 */

public interface ComboDAO {
     List<PdiComboResDTO> selectPdiComboList(ComboReqDTO comboReqDTO) throws Exception;
     List<VehlComboResDTO> selectVehlComboList(ComboReqDTO comboReqDTO) throws Exception;
     List<String> selectMdyComboList(ComboReqDTO comboReqDTO) throws Exception;
     List<RegionComboResDTO> selectRegionComboList(ComboReqDTO comboReqDTO) throws Exception;
     List<LangComboResDTO> selectLangComboList(ComboReqDTO comboReqDTO) throws Exception;
     List<SubCdComboResDTO> selectSubCdComboList(String mainCd)  throws Exception;
     List<CodeComboResDTO> selectCodeComboList(String dlExpdGCd)  throws Exception;
     List<GrpComboResDTO> selectGrpComboList()  throws Exception;
     List<HashMap<String, Object>> selectLangByVehlComboList(String userEeno, String dlExpdCoCd) throws Exception;
     List<HashMap<String, Object>> selectOutsourcingComboList(String dlExpdCoCd) throws Exception;

     List<VehlMdyResDTO> selectVehlListByUser(ComboReqDTO comboReqDTO);
     List<String> selectMdyListByVehlCd(String qltyVehlCd);
     List<CommLangComboResDTO> selectLangListByVehlCdAndMdy(VehlMdyReqDTO vehlMdyReqDTO);
     List<VehlMdyLangResDTO> selectVehlMdyLangListByVehl(List<VehlMdyLangReqDTO> list);
     List<VehlMdyLangResDTO> selectVehlMdyLangListByVehlMdy(List<VehlMdyLangReqDTO> list);
     List<VehlMdyLangResDTO> selectVehlMdyLangListByVehlMdyLang(List<VehlMdyLangReqDTO> list);
     List<VehlMdyLangResDTO> selectVehlMdyLangList(VehlMdyLangListReqDTO vehlMdyLangListReqDTO);
}
