package com.oms.common.dto;

import java.util.List;

import com.oms.common.model.YongsanIv;
import com.oms.common.model.YongsanVehl;

import lombok.Data;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @author 안경수
 * @since 2023. 5. 18.
 * @see
 */
@Data
public class YongsanVehlDTO {
    private String result;
    private Integer listCount;
    private List<YongsanVehl> list;
    private String msg;

}
