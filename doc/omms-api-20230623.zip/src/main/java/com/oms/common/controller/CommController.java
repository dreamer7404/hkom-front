package com.oms.common.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.oms.common.dto.AttcFileReqDTO;
import com.oms.common.dto.AttcFileResDTO;
import com.oms.common.service.AttcFileService;
import com.oms.common.service.CommService;
import com.oms.sys.dto.UsrMgmtReqDTO;
import com.oms.sys.dto.UsrMgmtResDTO;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;



/**
 * <pre>
 * Statements
 * </pre>
 * @ClassName : CommController.java
 * @Description :
 * @author 김경훈
 * @since 2023. 3. 22.
 * @see
 */
@Tag(name = "CommController", description = "")
@RequiredArgsConstructor
@RestController
@RequestMapping("/api")
public class CommController {

    private final CommService commService;
    private final AttcFileService attcFileService;



    @Operation(summary = "사용자 정보 조회")
    @GetMapping(value = "/userMgmtPop")
    public List<UsrMgmtResDTO> userMgmtPop(@ModelAttribute UsrMgmtReqDTO dto) throws Exception {
        List<UsrMgmtResDTO> userList =commService.userMgmtPop(dto);

        return  userList;
    }

    @GetMapping(value = "/fileDownload")
    public List<AttcFileResDTO> fileDownload(@ModelAttribute AttcFileReqDTO attcFileReqDTO){
        List<AttcFileResDTO> fileList = new ArrayList<>();

        String attcGbn = attcFileReqDTO.getAttcGbn(); // 첨부파일 구분(A,B,..)
//        Long blcSn = attcFileReqDTO.getBlcSn();
        String gbnSn = attcFileReqDTO.getGbnSn();   // 게시물 PK

        if(attcGbn != null && !attcGbn.isEmpty() && gbnSn != null && !gbnSn.isEmpty()) {
            fileList = attcFileService.selectAttcFileList(attcFileReqDTO);
        }

        return fileList;
    }

}
