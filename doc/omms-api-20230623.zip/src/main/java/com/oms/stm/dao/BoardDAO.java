package com.oms.stm.dao;

import java.util.List;

import com.oms.common.dto.RcvrResDTO;
import com.oms.stm.dto.BoardReqDTO;
import com.oms.stm.dto.BoardResDTO;
import com.oms.sys.dto.UsrMgmtResDTO;


/**
 * <pre>
 * NatlMgmt DAO 인터페이스
 * </pre>
 *
 * @Class Name  : NatlMgmtDAO.java
 * @Description :
 * @author 안경수
 * @since 2023.1.6
 * @see
*/
public interface BoardDAO {
    /**
     * Statements
     *
     * @param boardDTO
     * @return
     */
    List<BoardResDTO> selectBoardList(BoardReqDTO boardReqDTO) throws Exception;
    /**
     * Statements
     *
     * @param boardReqDTO
     * @return
     */
    List<BoardResDTO> selectBoardGrpList(BoardReqDTO boardReqDTO) throws Exception;
    /**
     * Statements
     *
     * @param boardReqDTO
     * @return
     */
    int selectBoardNo(BoardReqDTO boardReqDTO);
    /**
     * Statements
     *
     * @param boardReqDTO
     * @return
     * @return
     */
     Integer insertBoard(BoardReqDTO boardReqDTO);
     /**
      * Statements
      *
      * @param boardReqDTO
     * @return
      */
     Integer insertRcvrMgmt(BoardReqDTO boardReqDTO);
    /**
     * Statements
     *
     * @param boardReqDTO
     * @return
     */
    Integer deleteBoard(BoardReqDTO boardReqDTO);
    /**
     * Statements
     *
     * @param boardReqDTO
     * @return
     */
    Integer updateBoard(BoardReqDTO boardReqDTO);
    /**
     * Statements
     *
     * @param boardReqDTO
     * @return
     */
    BoardResDTO selectBoardOne(BoardReqDTO boardReqDTO);
    /**
     * Statements
     *
     * @param boardReqDTO
     * @return
     */
    List<UsrMgmtResDTO> selectRcvrList(BoardReqDTO boardReqDTO);
    /**
     * Statements
     *
     * @param boardReqDTO
     * @return
     */
    List<RcvrResDTO> selectRcvrChkList(BoardReqDTO boardReqDTO);
    /**
     * Statements
     *
     * @param boardReqDTO
     * @return
     */
    int deleteBoardRecvr(BoardReqDTO boardReqDTO);
    /**
     * Statements
     *
     * @param boardReqDTO
     * @return
     */
    int deleteBoardMulti(BoardReqDTO boardReqDTO);
    /**
     * Statements
     *
     * @param boardReqDTO
     * @return
     */
    int deleteBoardRecvrMulti(BoardReqDTO boardReqDTO);

}
