package com.oms.stm.dto;

import java.util.List;

import org.apache.ibatis.type.Alias;

import com.oms.common.dto.CommReqDTO;
import com.oms.common.dto.RcvrReqDTO;


import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


/**
 * <pre>
 * Statements
 * </pre>
 * @ClassName : PrntPageMgmtReqDTO.java
 * @Description :
 * @author 김경훈
 * @since 2023. 4. 4.
 * @see
 */
@Alias("prntPageMgmtReqDTO")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class PrntPageMgmtReqDTO extends CommReqDTO {


    private String lrnkCd;
    private String newPrntPbcnNo;
    private String dlExpdRegnCd;
    private String a01;
    private String a02;
    private String a03;
    private int deppc1Sn;
    private int deppc2Sn;
    private String qltyVehlCd;
    private String mdlMdyCd;
    private String langCd;
    private String rgstYmd;
    private int endPgSn; //페이지수
    private int endPgSnE; //색인
    private String framDtm;
    private String mdfyDtm;
    private String userEeno;


    List<PrntPageMgmtReqDTO> pageArr;


}


