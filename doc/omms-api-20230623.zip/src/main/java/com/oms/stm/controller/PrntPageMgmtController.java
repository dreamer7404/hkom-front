package com.oms.stm.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import able.cloud.core.web.HController;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.oms.cmm.global.Consts;
import com.oms.cmm.utils.Utils;

import com.oms.stm.dto.PrntPageMgmtReqDTO;
import com.oms.stm.dto.PrntPageMgmtResDTO;
import com.oms.stm.dto.StmComReqDTO;
import com.oms.stm.service.PrntPageMgmtService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;



/**
 * <pre>
 * Statements
 * </pre>
 * @ClassName : PrntPageMgmtController.java
 * @Description :
 * @author 김경훈
 * @since 2023. 4. 4.
 * @see
 */
@Tag(name = "PrntPageMgmtController", description = "")
@RequiredArgsConstructor
@RestController
@RequestMapping("/api")
public class PrntPageMgmtController extends HController {

    /**
     * 클래스 Injection
     */
    private final PrntPageMgmtService prntPageMgmtService;
    private final HttpServletRequest request;


    /**
     * 인쇄페이지관리 조회
     */
    @Operation(summary = "인쇄페이지관리 조회")
    @GetMapping("/prntPageMgmts")
    public  HashMap<String,Object> prntPageMgmts(@ModelAttribute StmComReqDTO dto) throws Exception {

        HashMap<String, Object> resultMap  = new HashMap<String, Object>();
        int nCnt = prntPageMgmtService.selectMaxDeppc1Sn(dto); //인쇄부수 몇개 찍을지 판단, max +1,

        HashMap<String,Object> hmap = new HashMap<String, Object>();
        List<Integer> vCnt = new ArrayList<Integer>();
        List<HashMap<String,Object>> dynamicList = new ArrayList<HashMap<String,Object>>();
        for (int i = 1; i < nCnt; i++) {
             vCnt.add(i);
        }
        String column = "";
        for(int i=0; i< vCnt.size(); i++) {
            HashMap<String,Object> paramMap = new HashMap<String,Object>();
                int num = i+1;
                 column = "col"+Integer.toString(num);
                 int size = vCnt.size()-1;
                if(size==i) {
                    paramMap.put("col", "색인");
                }else {
                 paramMap.put("col", vCnt.get(i)+"장");
                }
                 paramMap.put("field", column);


                 dynamicList.add(paramMap);
                hmap.put(column, vCnt.get(i));
        }

        hmap.put("dlExpdPdiCd", dto.getDlExpdPdiCd());
        hmap.put("qltyVehlCd", dto.getQltyVehlCd());
        hmap.put("mdlMdyCd", dto.getMdlMdyCd());
        hmap.put("dlExpdRegnCd", dto.getDlExpdRegnCd());
        hmap.put("langCd", dto.getLangCd());
        hmap.put("userEeno", Utils.getUserEeno(request));
        hmap.put("dlExpdCoCd", Utils.getDlExpdCoCd(request));
        resultMap.put("prntPageList", prntPageMgmtService.selectPrntPageList(hmap));
        resultMap.put("dynamicList", dynamicList);



        return  resultMap;
    }
    /**
     * 인쇄페이지관리 상세
     */
    @Operation(summary = "인쇄페이지관리 상세")
    @GetMapping("/prntPageMgmt")
    public  HashMap<String,Object> prntPageMgmt(@ModelAttribute StmComReqDTO dto) throws Exception {

        HashMap<String, Object> resultMap  = new HashMap<String, Object>();
        int nCnt = prntPageMgmtService.selectMaxDeppc1Sn(dto); //인쇄부수 몇개 찍을지 판단, max +1,

        List<Integer> vCnt = new ArrayList<Integer>();
        HashMap<String,Object> hmap = new HashMap<String, Object>();

        for (int i = 1; i < nCnt; i++) {
             vCnt.add(i);
        }
        String column = "";
        for(int i=0; i< vCnt.size(); i++) {
            int num = i+1;
            column = "col"+Integer.toString(num);
            hmap.put(column, vCnt.get(i));
        }


        PrntPageMgmtResDTO detailInfo =prntPageMgmtService.selectPrntPageDetail(dto);
        hmap.put("newPrntPbcnNo", dto.getNewPrntPbcnNo());
        hmap.put("lrnkCd", dto.getLrnkCd());
        List<HashMap<String,Object>> detailPageInfo =prntPageMgmtService.detailPageInfo(hmap);
        resultMap.put("detailInfo", detailInfo);
        resultMap.put("detailPageInfo", detailPageInfo);

        return  resultMap;
    }

    /**
     * 인쇄페이지 관리 저장
     */
    @Operation(summary = "인쇄페이지 관리 저장", description = "")
    @Parameter(in = ParameterIn.HEADER, name="_method")
    @PostMapping(value = "/prntPageMgmt")
       public Integer prntPageMgmt(@RequestBody PrntPageMgmtReqDTO dto) throws Exception {
        int result = 0;
        dto.setUserEeno(Utils.getUserEeno(request));
        String method = Utils.getMethod(request);
        String  chk = prntPageMgmtService.validChk(dto);

        List<PrntPageMgmtReqDTO> chkGridData = dto.getPageArr();


        if(method.equals(Consts.INSERT)) {
            dto.setRgstYmd(dto.getRgstYmd().replace("-",""));
            if("Y".equals(chk)) {
                if(dto.getA01()!=null && !"".equals(dto.getA01())) { //서문01
                    dto.setDeppc1Sn(0);
                    dto.setDeppc2Sn(1);
                    dto.setEndPgSn(Integer.parseInt(dto.getA01()));
                    result = prntPageMgmtService.insertPrntPage(dto);
                }
                else {
                    dto.setDeppc1Sn(0);
                    dto.setDeppc2Sn(1);
                    dto.setEndPgSn(0);
                    result = prntPageMgmtService.insertPrntPage(dto);
                }
                if(dto.getA02()!=null && !"".equals(dto.getA02())) {//서문2
                    dto.setDeppc1Sn(0);
                    dto.setDeppc2Sn(2);
                    dto.setEndPgSn(Integer.parseInt(dto.getA02()));
                    result =  prntPageMgmtService.insertPrntPage(dto);
                }
                else {
                    dto.setDeppc1Sn(0);
                    dto.setDeppc2Sn(2);
                    dto.setEndPgSn(0);
                    result =  prntPageMgmtService.insertPrntPage(dto);
                }
                if(dto.getA03()!=null && !"".equals(dto.getA03())) {//서문3
                    dto.setDeppc1Sn(0);
                    dto.setDeppc2Sn(3);
                    dto.setEndPgSn(Integer.parseInt(dto.getA03()));
                    result =  prntPageMgmtService.insertPrntPage(dto);
                }
                else {
                    dto.setDeppc1Sn(0);
                    dto.setDeppc2Sn(3);
                    dto.setEndPgSn(0);
                    result =  prntPageMgmtService.insertPrntPage(dto);
                }
                for (int i = 0; i < chkGridData.size(); i++) {
                    dto.setDeppc1Sn(i+1);
                    dto.setDeppc2Sn(1);
                    dto.setEndPgSn(chkGridData.get(i).getEndPgSn());

                    result =  prntPageMgmtService.insertPrntPage(dto);
                }
              //마지막 색인값 저장
                dto.setDeppc1Sn(chkGridData.size()+1);
                dto.setDeppc2Sn(1);
                dto.setEndPgSn(dto.getEndPgSnE());
                result =  prntPageMgmtService.insertPrntPage(dto);
            } else {
                result = -1;
            }
      }  else if (method.equals(Consts.UPDATE)) {
          dto.setRgstYmd(dto.getRgstYmd().replace("-",""));
          result =prntPageMgmtService.deletePrntPage(dto);

          if(dto.getA01()!=null && !"".equals(dto.getA01())) { //서문01
              dto.setDeppc1Sn(0);
              dto.setDeppc2Sn(1);
              dto.setEndPgSn(Integer.parseInt(dto.getA01()));
              result = prntPageMgmtService.insertPrntPage(dto);
          }
          else {
              dto.setDeppc1Sn(0);
              dto.setDeppc2Sn(1);
              dto.setEndPgSn(0);
              result = prntPageMgmtService.insertPrntPage(dto);
          }
          if(dto.getA02()!=null && !"".equals(dto.getA02())) {//서문2
              dto.setDeppc1Sn(0);
              dto.setDeppc2Sn(2);
              dto.setEndPgSn(Integer.parseInt(dto.getA02()));
              result =  prntPageMgmtService.insertPrntPage(dto);
          }
          else {
              dto.setDeppc1Sn(0);
              dto.setDeppc2Sn(2);
              dto.setEndPgSn(0);
              result =  prntPageMgmtService.insertPrntPage(dto);
          }
          if(dto.getA03()!=null && !"".equals(dto.getA03())) {//서문3
              dto.setDeppc1Sn(0);
              dto.setDeppc2Sn(3);
              dto.setEndPgSn(Integer.parseInt(dto.getA03()));
              result =  prntPageMgmtService.insertPrntPage(dto);
          }
          else {
              dto.setDeppc1Sn(0);
              dto.setDeppc2Sn(3);
              dto.setEndPgSn(0);
              result =  prntPageMgmtService.insertPrntPage(dto);
          }
          for (int i = 0; i < chkGridData.size(); i++) {
              dto.setDeppc1Sn(i+1);
              dto.setDeppc2Sn(1);
              dto.setEndPgSn(chkGridData.get(i).getEndPgSn());

              result =  prntPageMgmtService.insertPrntPage(dto);
          }
        //마지막 색인값 저장
          dto.setDeppc1Sn(chkGridData.size()+1);
          dto.setDeppc2Sn(1);
          dto.setEndPgSn(dto.getEndPgSnE());
          result =  prntPageMgmtService.insertPrntPage(dto);




      }   else if (method.equals(Consts.DELETE)) {
          for(int i=0; i<chkGridData.size(); i++) {
              result =prntPageMgmtService.deletePrntPage(chkGridData.get(i));
          }
      }
    return result;
    }
}