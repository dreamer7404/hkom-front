CREATE OR REPLACE PROCEDURE SP_DELETE_OLD_DATA
IS
    CURSOR C_DEL_TABLE_LIST IS SELECT TBL_NM, COL_NM, KEY_CNT, KEY_1, KEY_2, KEY_3, KEY_4, KEY_5, KEY_6, KEY_7, KEY_8, KEY_9, KEY_10, KEY_ALL FROM TB_DELDATA_LIST ORDER BY TBL_NM;
--    TYPE DEL_ROW_LIST_TYPE IS REF CURSOR;
--    C_DEL_ROW_LIST DEL_ROW_LIST_TYPE;
--    DEL_ROW_TYPE IS TB_DELDATA_LIST%ROWTYPE;
--    DEL_ROW       DEL_ROW_TYPE;
    COMMIT_CNT    NUMBER;
    V_YMD         VARCHAR2(20);
    V_QRY         VARCHAR2(500);
    STRT_YMD      VARCHAR2(20);
    CURR_YMD      VARCHAR2(20);
BEGIN

    COMMIT_CNT := 0;
--    STRT_YMD := TO_CHAR(SYSDATE, 'YYYYMMDDHH24MI');
    STRT_YMD := TO_CHAR(SYSDATE, 'YYYYMMDD');
    
    <<OUTER_LOOP>>
    FOR DEL_TABLE IN C_DEL_TABLE_LIST LOOP
    
        <<INNER_LOOP>>
        LOOP
            V_YMD := NULL;
            CURR_YMD := TO_CHAR(SYSDATE, 'YYYYMMDD');

            -- 배치를 수행한 일자가 변경되면 배치 종료        
            EXIT OUTER_LOOP WHEN STRT_YMD <> CURR_YMD;

            V_QRY := 'SELECT MIN(' || DEL_TABLE.COL_NM || ') FROM ' || DEL_TABLE.TBL_NM || ' WHERE ' || DEL_TABLE.COL_NM || ' < TO_CHAR(SYSDATE - 365 * 3, ''YYYYMMDD'') AND TRIM(' || DEL_TABLE.COL_NM || ') IS NOT NULL ';
            DBMS_OUTPUT.PUT_LINE(V_QRY);
            EXECUTE IMMEDIATE V_QRY INTO V_YMD;
            /*
            SELECT MIN(APL_STRT_YMD)
            INTO V_YMD
            FROM TB_APS_ODR_INFO
            WHERE APL_STRT_YMD < '20130101'
            ;
            */
            EXIT INNER_LOOP WHEN V_YMD IS NULL;    -- EXIT LOOP

            -- 데이터가 적은 테이블은 일자별로 삭제한다.
--            IF DEL_TABLE.KEY_CNT = 0 THEN
                V_QRY := 'DELETE FROM  ' || DEL_TABLE.TBL_NM || ' WHERE ' || DEL_TABLE.COL_NM || ' = ''' || V_YMD || ''' ';
                DBMS_OUTPUT.PUT_LINE(V_QRY);
                EXECUTE IMMEDIATE V_QRY;
--            ELSE    -- 데이터가 많은 테이블은 KEY를 가지고 한 ROW 씩 삭제한다.
--                V_QRY := 'SELECT ' || DEL_TABLE.KEY_ALL || ' FROM ' || DEL_TABLE.TBL_NM || ' WHERE ' || DEL_TABLE.COL_NM || ' = ''' || V_YMD || ''' ';
--                DBMS_OUTPUT.PUT_LINE(V_QRY);
--                OPEN C_DEL_ROW_LIST FOR V_QRY;
--
--                COMMIT_CNT := 0;
--                LOOP
--                    FETCH C_DEL_ROW_LIST  INTO DEL_ROW;
--                    V_QRY := 'DELETE FROM  ' || DEL_TABLE.TBL_NM || ' WHERE 1 = 1';
--                    IF DEL_TABLE.KEY_1  IS NOT NULL THEN V_QRY := V_QRY || ' AND ' || DEL_TABLE.KEY_1  || ' = ''' || DEL_ROW.KEY_1  || ''' '; END IF;
--                    IF DEL_TABLE.KEY_2  IS NOT NULL THEN V_QRY := V_QRY || ' AND ' || DEL_TABLE.KEY_2  || ' = ''' || DEL_ROW.KEY_2  || ''' '; END IF;
--                    IF DEL_TABLE.KEY_3  IS NOT NULL THEN V_QRY := V_QRY || ' AND ' || DEL_TABLE.KEY_3  || ' = ''' || DEL_ROW.KEY_3  || ''' '; END IF;
--                    IF DEL_TABLE.KEY_4  IS NOT NULL THEN V_QRY := V_QRY || ' AND ' || DEL_TABLE.KEY_4  || ' = ''' || DEL_ROW.KEY_4  || ''' '; END IF;
--                    IF DEL_TABLE.KEY_5  IS NOT NULL THEN V_QRY := V_QRY || ' AND ' || DEL_TABLE.KEY_5  || ' = ''' || DEL_ROW.KEY_5  || ''' '; END IF;
--                    IF DEL_TABLE.KEY_6  IS NOT NULL THEN V_QRY := V_QRY || ' AND ' || DEL_TABLE.KEY_6  || ' = ''' || DEL_ROW.KEY_6  || ''' '; END IF;
--                    IF DEL_TABLE.KEY_7  IS NOT NULL THEN V_QRY := V_QRY || ' AND ' || DEL_TABLE.KEY_7  || ' = ''' || DEL_ROW.KEY_7  || ''' '; END IF;
--                    IF DEL_TABLE.KEY_8  IS NOT NULL THEN V_QRY := V_QRY || ' AND ' || DEL_TABLE.KEY_8  || ' = ''' || DEL_ROW.KEY_8  || ''' '; END IF;
--                    IF DEL_TABLE.KEY_9  IS NOT NULL THEN V_QRY := V_QRY || ' AND ' || DEL_TABLE.KEY_9  || ' = ''' || DEL_ROW.KEY_9  || ''' '; END IF;
--                    IF DEL_TABLE.KEY_10 IS NOT NULL THEN V_QRY := V_QRY || ' AND ' || DEL_TABLE.KEY_10 || ' = ''' || DEL_ROW.KEY_10 || ''' '; END IF;
--                    DBMS_OUTPUT.PUT_LINE(V_QRY);
--                
--                    COMMIT_CNT := COMMIT_CNT + 1;
--                
--                    IF COMMIT_CNT > 1000 THEN
--                        COMMIT;
--                        COMMIT_CNT := 0;
--
--                        CURR_YMD := TO_CHAR(SYSDATE, 'YYYYMMDDHH24MI');
--                        -- 배치를 수행한 일자가 변경되면 배치 종료        
--                        EXIT OUTER_LOOP WHEN STRT_YMD <> CURR_YMD;
--                    END IF;
--                END LOOP;
--            END IF;
            /*
            DELETE FROM TB_APS_ODR_INFO WHERE APL_STRT_YMD = V_YMD;
            */
            COMMIT; 

        END LOOP INNER_LOOP;
    END LOOP OUTER_LOOP;
    
    
    COMMIT;

END;