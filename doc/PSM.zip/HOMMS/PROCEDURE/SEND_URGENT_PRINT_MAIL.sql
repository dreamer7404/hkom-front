CREATE OR REPLACE PROCEDURE HOMMS_ADM.SEND_URGENT_PRINT_MAIL
IS
	CURSOR USER_LIST IS
		SELECT
			NVL(USER_NM, ' ') AS USER_NM,
			NVL(USER_EML_ADR, ' ') AS USER_EML_ADR
		FROM TB_USR_MGMT
		WHERE BLNS_CO_CD = '01' AND USE_GBN = 'U'
--			  AND USER_EENO  IN ('5900513')
		      AND USER_EENO  IN ('PMTEST3', '5325551', '5900513', 'ADMIN')
		UNION ALL
		SELECT
			NVL(USER_NM, ' ') AS USER_NM,
			USER_EENO || '@hyundai-partners.com' AS USER_EML_ADR
		FROM TB_USR_MGMT
		WHERE BLNS_CO_CD = '03' AND USE_GBN = 'U'
		;

	CURSOR CONTENTS_LIST IS
		 WITH T AS /* totivmDAO.selecttotivmMgmtList */
		 			( SELECT 
		                    C.DATA_SN,
		                    C.QLTY_VEHL_CD,
		                    C.MDL_MDY_CD,
		                    C.LANG_CD,
		                    '(' || C.QLTY_VEHL_CD || '-' || C.MDL_MDY_CD || ') ' || B.QLTY_VEHL_NM || ' ' || SUBSTR(D.PLNT_NM, 1, 3) AS QLTY_VEHL_NM,
		                    '(' || C.LANG_CD || ')' || C.LANG_CD_NM AS LANG_CD_NM,
		                    C.DL_EXPD_REGN_CD,
		                    C.SORT_SN AS LANG_SORT_SN,
		                    D.PLNT_NM
		               FROM 
		                    TB_VEHL_MGMT B,
		                    TB_LANG_MGMT C,
		                    TB_PLNT_VEHL_MGMT D
		              WHERE B.QLTY_VEHL_CD = C.QLTY_VEHL_CD
		                AND B.QLTY_VEHL_CD = D.QLTY_VEHL_CD(+)
		                AND B.MDL_MDY_CD = C.MDL_MDY_CD
		                AND B.MDL_MDY_CD BETWEEN TO_CHAR(ADD_MONTHS(TO_CHAR(SYSDATE, 'YYYYMMDD'), -48), 'YY')
		                AND TO_CHAR(ADD_MONTHS(TO_CHAR(SYSDATE, 'YYYYMMDD'), 24), 'YY')
		                AND B.MDL_MDY_CD = DECODE('', '', B.MDL_MDY_CD, '')
		                AND B.DL_EXPD_PAC_SCN_CD = DECODE('ALL', 'ALL', B.DL_EXPD_PAC_SCN_CD, 'ALL')
		                AND B.DL_EXPD_PDI_CD = DECODE('ALL', 'ALL', B.DL_EXPD_PDI_CD, 'ALL')
		                AND C.DL_EXPD_REGN_CD = DECODE('ALL', 'ALL', C.DL_EXPD_REGN_CD, 'ALL')
		                AND C.LANG_CD = DECODE('ALL', 'ALL', C.LANG_CD, 'ALL')
		                AND B.USE_YN = 'Y'
		                AND C.USE_YN = 'Y')
		                
		 SELECT 
		        A.QLTY_VEHL_NM,
		        A.LANG_CD_NM,
		        A.DL_EXPD_REGN_NM,
		        A.WEK2_AFTR_IV_QTY,
		        A.PRNT_STATE,
		        B.DL_EXPD_PRVS_NM AS PRNT_STATE_NM
		   FROM ( SELECT 
		                 A.DATA_SN,
		                 A.QLTY_VEHL_CD,
		                 A.MDL_MDY_CD,
		                 A.LANG_CD,
		                 A.DL_EXPD_REGN_CD,
		                 A.QLTY_VEHL_NM,
		                 A.LANG_CD_NM,
		                 B.DL_EXPD_PRVS_NM AS DL_EXPD_REGN_NM,
		                 A.CURR_ORD_QTY,
		                 A.PREV_ORD_QTY,
		                 A.MTH3_TRWI_QTY,
		                 A.DAY3_PLAN_QTY,
		                 A.WEK2_PLAN_QTY,
		                 A.CURR_MTH_TRWI_QTY,
		                 A.PREV_1DAY_TRWI_QTY,
		                 A.SEWHA_IV_QTY,
		                 A.SEWHA_PRNT_YN,
		                 /* 세화 인쇄중 데이터 존재여부 확인 */ A.PDI_IV_QTY,
		                 A.DSID14_QTY,
		                 (A.SEWHA_IV_QTY + A.PDI_IV_QTY - A.WEK2_PLAN_QTY) AS WEK2_AFTR_IV_QTY,
		                 CASE 	WHEN (A.SEWHA_IV_QTY + A.PDI_IV_QTY - A.WEK2_PLAN_QTY) >= A.WEK2_PLAN_QTY * 1.5 THEN '01' 
								WHEN (A.SEWHA_IV_QTY + A.PDI_IV_QTY - A.WEK2_PLAN_QTY) < A.WEK2_PLAN_QTY * 1.5 
									  AND (A.SEWHA_IV_QTY + A.PDI_IV_QTY - A.WEK2_PLAN_QTY) >= A.WEK2_PLAN_QTY THEN '02' 
								WHEN (A.SEWHA_IV_QTY + A.PDI_IV_QTY - A.WEK2_PLAN_QTY) < A.WEK2_PLAN_QTY THEN '04' 
								ELSE '03' 
						 END AS PRNT_STATE, 
						 /* 01: 150%이상, 02: 100~149%, 04: 99% 미만  */ 
		                 NVL(A.SEWHA_IV_QTY, 0) + NVL(A.PDI_IV_QTY, 0) AS IV_SUM,
		                 N_PRNT_PBCN_NO
		            FROM ( SELECT 
		                          A.DATA_SN,
		                          A.QLTY_VEHL_CD,
		                          A.MDL_MDY_CD,
		                          A.LANG_CD,
		                          A.DL_EXPD_REGN_CD,
		                          A.QLTY_VEHL_NM,
		                          A.LANG_CD_NM,
		                          A.LANG_SORT_SN,
		                          NVL(B.CURR_ORD_QTY, 0) AS CURR_ORD_QTY,
		                          NVL(B.PREV_ORD_QTY, 0) AS PREV_ORD_QTY,
		                          NVL(B.MTH3_TRWI_QTY, 0) AS MTH3_TRWI_QTY,
		                          NVL(B.DAY3_PLAN_QTY1, 0) AS DAY3_PLAN_QTY,
		                          NVL(B.WEK2_PLAN_QTY, 0) AS WEK2_PLAN_QTY,
		                          NVL(B.CURR_MTH_TRWI_QTY, 0) AS CURR_MTH_TRWI_QTY,
		                          NVL(B.PREV_1DAY_TRWI_QTY, 0) AS PREV_1DAY_TRWI_QTY,
		                          NVL(C.SEWHA_IV_QTY, 0) AS SEWHA_IV_QTY,
		                          NVL(C.SEWHA_PRNT_YN, 'N') AS SEWHA_PRNT_YN,
		                          NVL(D.PDI_IV_QTY, 0) AS PDI_IV_QTY,
		                          NVL(B.DSID14_QTY, 0) AS DSID14_QTY,
		                          NVL(CASE WHEN C.N_PRNT_PBCN_NO IS NULL THEN D.N_PRNT_PBCN_NO ELSE C.N_PRNT_PBCN_NO END, '') AS N_PRNT_PBCN_NO,
		                          NVL(B.TDD_PRDN_QTY, 0) AS TDD_PRDN_QTY
		                     FROM T A,
		                          ( SELECT A.QLTY_VEHL_CD,
		                                    A.MDL_MDY_CD,
		                                    A.LANG_CD,
		                                    NVL(B.TMM_ORD_QTY, 0) AS CURR_ORD_QTY,
		                                    NVL(B.BORD_QTY, 0) AS PREV_ORD_QTY,
		                                    NVL(B.MTH3_MO_AVG_TRWI_QTY, 0) AS MTH3_TRWI_QTY,
		                                    NVL(B.TDD_PRDN_PLN_QTY, 0) + NVL(B.TDD_PRDN_QTY3, 0) AS DAY3_PLAN_QTY1,
		                                    NVL(B.WEK2_PRDN_PLN_QTY, 0) + NVL(B.TDD_PRDN_QTY3, 0) AS WEK2_PLAN_QTY,
		                                    NVL(B.TMM_TRWI_QTY, 0) AS CURR_MTH_TRWI_QTY,
		                                    NVL(B.BOD_TRWI_QTY, 0) AS PREV_1DAY_TRWI_QTY,
		                                    CASE WHEN C.DSID141_QTY IS NULL THEN NVL(B.YER1_DLY_AVG_TRWI_QTY, 0) * 14 ELSE C.DSID141_QTY END AS DSID14_QTY,
		                                    /*생산계획, 재고, 투입수량이 없더라도 라인진행중인 물량이 있으면 화면에 표시해 주기 위한 항목                                         
											--NVL(B.TDD_PRDN_QTY, 0) AS TDD_PRDN_QTY                                          
											--[변경]. 2009.10.29.김동근 현재 현업의 요청사항과 맞지 않아서 값을 무조건 0 으로 처리함*/ 
											0 AS TDD_PRDN_QTY
		                               FROM T A,
		                                    TB_APS_PROD_SUM_INFO B,
		                                    TB_SFTY_IV_MGMT C
		                              WHERE A.DATA_SN = B.DATA_SN
		                                AND B.APL_YMD = TO_CHAR(SYSDATE, 'YYYYMMDD')
		                                AND A.QLTY_VEHL_CD = C.QLTY_VEHL_CD(+)
		                                AND A.QLTY_VEHL_CD NOT IN( SELECT QLTY_VEHL_CD
		                                                             FROM TB_PLNT_VEHL_MGMT
		                                                            GROUP BY QLTY_VEHL_CD)
		                                AND A.MDL_MDY_CD = C.MDL_MDY_CD(+)
		                                AND A.LANG_CD = C.LANG_CD(+)
		                              UNION ALL
		                             SELECT A.QLTY_VEHL_CD,
		                                    A.MDL_MDY_CD,
		                                    A.LANG_CD,
		                                    SUM(NVL(B.TMM_ORD_QTY, 0) ) AS CURR_ORD_QTY,
		                                    SUM(NVL(B.BORD_QTY, 0) ) AS PREV_ORD_QTY,
		                                    SUM(NVL(B.MTH3_MO_AVG_TRWI_QTY, 0) ) AS MTH3_TRWI_QTY,
		                                    SUM(NVL(B.TDD_PRDN_PLN_QTY, 0) + NVL(B.TDD_PRDN_QTY3, 0) ) AS DAY3_PLAN_QTY1,
		                                    SUM(NVL(B.WEK2_PRDN_PLN_QTY, 0) + NVL(B.TDD_PRDN_QTY3, 0) ) AS WEK2_PLAN_QTY,
		                                    SUM(NVL(B.TMM_TRWI_QTY, 0) ) AS CURR_MTH_TRWI_QTY,
		                                    SUM(NVL(B.BOD_TRWI_QTY,	0) ) AS PREV_1DAY_TRWI_QTY,
		                                    SUM(CASE WHEN C.DSID141_QTY IS NULL THEN NVL(B.YER1_DLY_AVG_TRWI_QTY, 0) * 14 ELSE C.DSID141_QTY END ) AS DSID14_QTY,
		                                    /*생산계획, 재고, 투입수량이 없더라도 라인진행중인 물량이 있으면 화면에 표시해 주기 위한 항목                                         
											--SUM(NVL(B.TDD_PRDN_QTY, 0)) AS TDD_PRDN_QTY                                          
											--[변경]. 2009.10.29.김동근 현재 현업의 요청사항과 맞지 않아서 값을 무조건 0 으로 처리함*/ 
											0 AS TDD_PRDN_QTY
		                               FROM T A,
		                                    TB_PLNT_APS_PROD_SUM_INFO B,
		                                    TB_SFTY_IV_MGMT C
		                              WHERE A.DATA_SN = B.DATA_SN
		                                AND B.APL_YMD = TO_CHAR(SYSDATE, 'YYYYMMDD')
		                                AND A.QLTY_VEHL_CD IN( SELECT QLTY_VEHL_CD
		                                                         FROM TB_PLNT_VEHL_MGMT)
		                                AND A.QLTY_VEHL_CD = C.QLTY_VEHL_CD(+)
		                                AND A.MDL_MDY_CD = C.MDL_MDY_CD(+)
		                                AND A.LANG_CD = C.LANG_CD(+)
		                              GROUP BY A.QLTY_VEHL_CD,
		                                    A.MDL_MDY_CD,
		                                    A.LANG_CD) B,
		                          /*--세화재고*/ ( SELECT A.QLTY_VEHL_CD,
		                                               A.MDL_MDY_CD,
		                                               A.LANG_CD,
		                                               SUM(B.SFTY_IV_QTY) AS SEWHA_IV_QTY,
		                                               /*--인쇄중 데이터 존재 여부 확인 ==> DL_EXPD_TMP_IV_QTY 값은 Default값은  인쇄 수량, 납품이후에는 0으로 설정되어 있음*/ 
													   CASE WHEN SUM(B.DL_EXPD_TMP_IV_QTY) > 0 THEN 'Y' ELSE 'N' END AS SEWHA_PRNT_YN,
		                                               MAX(B.N_PRNT_PBCN_NO) AS N_PRNT_PBCN_NO
		                                          FROM T A,
		                                               TB_SEWHA_IV_INFO_DTL B
		                                         WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
		                                           AND A.MDL_MDY_CD = B.MDL_MDY_CD
		                                           AND A.LANG_CD = B.LANG_CD
		                                           AND B.CLS_YMD = TO_CHAR(SYSDATE, 'YYYYMMDD')
		                                           AND B.SFTY_IV_QTY > 0 /*--안전재고수량이 없는 것은 가져오지 않는다.*/
		                                           AND A.QLTY_VEHL_CD NOT IN( SELECT QLTY_VEHL_CD
		                                                                        FROM TB_PLNT_VEHL_MGMT)
		                                         GROUP BY A.QLTY_VEHL_CD,
		                                               A.MDL_MDY_CD,
		                                               A.LANG_CD
		                                         UNION ALL ( SELECT A.QLTY_VEHL_CD,
		                                                            A.MDL_MDY_CD,
		                                                            A.LANG_CD,
		                                                            SUM(B.SFTY_IV_QTY) AS SEWHA_IV_QTY,
		                                                            /*--인쇄중 데이터 존재 여부 확인 ==> DL_EXPD_TMP_IV_QTY 값은 Default값은  인쇄 수량, 납품이후에는 0으로 설정되어 있음*/ 
																	CASE WHEN SUM(B.DL_EXPD_TMP_IV_QTY) > 0 THEN 'Y' ELSE 'N' END AS SEWHA_PRNT_YN,
		                                                            MAX(B.N_PRNT_PBCN_NO) AS N_PRNT_PBCN_NO
		                                                       FROM T A,
		                                                            TB_SEWHA_IV_INFO_DTL B
		                                                      WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
		                                                        AND A.MDL_MDY_CD = B.MDL_MDY_CD
		                                                        AND A.LANG_CD = B.LANG_CD
		                                                        AND B.CLS_YMD = TO_CHAR(SYSDATE, 'YYYYMMDD')
		                                                        AND B.SFTY_IV_QTY > 0 /*--안전재고수량이 없는 것은 가져오지 않는다.*/
		                                                        AND A.QLTY_VEHL_CD IN( SELECT QLTY_VEHL_CD
		                                                                                 FROM TB_PLNT_VEHL_MGMT)
		                                                      GROUP BY A.QLTY_VEHL_CD,
		                                                            A.MDL_MDY_CD,
		                                                            A.LANG_CD
		                                                      UNION ALL
		                                                     SELECT A.QLTY_VEHL_CD,
		                                                            A.MDL_MDY_CD,
		                                                            A.LANG_CD,
		                                                            SUM(B.SFTY_IV_QTY) AS SEWHA_IV_QTY,
		                                                            /*--인쇄중 데이터 존재 여부 확인 ==> DL_EXPD_TMP_IV_QTY 값은 Default값은  인쇄 수량, 납품이후에는 0으로 설정되어 있음*/ 
																	CASE WHEN SUM(B.DL_EXPD_TMP_IV_QTY) > 0 THEN 'Y' ELSE 'N' END AS SEWHA_PRNT_YN,
		                                                            MAX(B.N_PRNT_PBCN_NO) AS N_PRNT_PBCN_NO
		                                                       FROM T A,
		                                                            TB_SEWHA_IV_INFO_DTL B
		                                                      WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
		                                                        AND A.MDL_MDY_CD = B.MDL_MDY_CD
		                                                        AND A.LANG_CD = B.LANG_CD
		                                                        AND B.CLS_YMD = TO_CHAR(SYSDATE, 'YYYYMMDD')
		                                                        AND B.SFTY_IV_QTY > 0 /*--안전재고수량이 없는 것은 가져오지 않는다.*/
		                                                        AND A.QLTY_VEHL_CD IN( SELECT QLTY_VEHL_CD
		                                                                                 FROM TB_PLNT_VEHL_MGMT)		                                                        
		                                                      GROUP BY A.QLTY_VEHL_CD,
		                                                            A.MDL_MDY_CD,
		                                                            A.LANG_CD) ) C,
		                          /*--PDI재고*/ ( SELECT A.QLTY_VEHL_CD,
		                                                A.MDL_MDY_CD,
		                                                A.LANG_CD,
		                                                SUM(B.SFTY_IV_QTY) AS PDI_IV_QTY,
		                                                MAX(B.N_PRNT_PBCN_NO) AS N_PRNT_PBCN_NO
		                                           FROM T A,
		                                                TB_PDI_IV_INFO_DTL B
		                                          WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
		                                            AND A.MDL_MDY_CD = B.MDL_MDY_CD
		                                            AND A.LANG_CD = B.LANG_CD
		                                            AND B.CLS_YMD = TO_CHAR(SYSDATE, 'YYYYMMDD')
		                                            AND B.SFTY_IV_QTY > 0 /*--안전재고수량이 없는 것은 가져오지 않는다.*/
		                                            AND A.QLTY_VEHL_CD NOT IN( SELECT QLTY_VEHL_CD
		                                                                         FROM TB_PLNT_VEHL_MGMT)
		                                          GROUP BY A.QLTY_VEHL_CD,
		                                                A.MDL_MDY_CD,
		                                                A.LANG_CD
		                                          UNION ALL
		                                         SELECT A.QLTY_VEHL_CD,
		                                                A.MDL_MDY_CD,
		                                                A.LANG_CD,
		                                                SUM(B.SFTY_IV_QTY) AS PDI_IV_QTY,
		                                                MAX(B.N_PRNT_PBCN_NO) AS N_PRNT_PBCN_NO
		                                           FROM T A,
		                                                TB_PDI_IV_INFO_DTL B
		                                          WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
		                                            AND A.MDL_MDY_CD = B.MDL_MDY_CD
		                                            AND A.LANG_CD = B.LANG_CD
		                                            AND B.CLS_YMD = TO_CHAR(SYSDATE, 'YYYYMMDD')
		                                            AND B.SFTY_IV_QTY > 0 /*--안전재고수량이 없는 것은 가져오지 않는다.*/
		                                            AND A.QLTY_VEHL_CD IN( SELECT QLTY_VEHL_CD
		                                                                     FROM TB_PLNT_VEHL_MGMT)
		                                          GROUP BY A.QLTY_VEHL_CD,
		                                                A.MDL_MDY_CD,
		                                                A.LANG_CD) D,
		                          ( SELECT A.QLTY_VEHL_CD,
		                                    A.MDL_MDY_CD,
		                                    A.LANG_CD,
		                                    TO_CHAR(SUM(NVL(B.TDD_PRDN_PLN_QTY,
		                                    0) + NVL(B.TDD_PRDN_QTY3,
		                                    0) ) ) AS PLNT_DAY3_QTY_TEXT,
		                                    TO_CHAR(SUM(NVL(B.WEK2_PRDN_PLN_QTY,
		                                    0) + NVL(B.TDD_PRDN_QTY3,
		                                    0) ) ) AS PLNT_WEK2_QTY_TEXT,
		                                    'Y' AS PLNT_YN,
		                                    C.PLNT_NM
		                               FROM T A,
		                                    TB_PLNT_APS_PROD_SUM_INFO B,
		                                    TB_PLNT_VEHL_MGMT C
		                              WHERE A.DATA_SN = B.DATA_SN
		                                AND B.APL_YMD = TO_CHAR(SYSDATE, 'YYYYMMDD')
		                                AND B.QLTY_VEHL_CD = C.QLTY_VEHL_CD
		                              GROUP BY A.QLTY_VEHL_CD,
		                                    A.MDL_MDY_CD,
		                                    A.LANG_CD,
		                                    C.PLNT_NM) E
		                    WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD (+)
		                      AND A.MDL_MDY_CD = B.MDL_MDY_CD(+)
		                      AND A.LANG_CD = B.LANG_CD(+)
		                      AND A.QLTY_VEHL_CD = C.QLTY_VEHL_CD(+)
		                      AND A.MDL_MDY_CD = C.MDL_MDY_CD(+)
		                      AND A.LANG_CD = C.LANG_CD(+)
		                      AND A.QLTY_VEHL_CD = D.QLTY_VEHL_CD(+)
		                      AND A.MDL_MDY_CD = D.MDL_MDY_CD(+)
		                      AND A.LANG_CD = D.LANG_CD(+)
		                      AND A.QLTY_VEHL_CD = E.QLTY_VEHL_CD(+)
		                      AND A.MDL_MDY_CD = E.MDL_MDY_CD(+)
		                      AND A.LANG_CD = E.LANG_CD(+)
		                 ) A,
		                 TB_CODE_MGMT B
		           WHERE A.DL_EXPD_REGN_CD = B.DL_EXPD_PRVS_CD
		             AND B.DL_EXPD_G_CD = '0008'
		             AND CURR_ORD_QTY + PREV_ORD_QTY + DAY3_PLAN_QTY + WEK2_PLAN_QTY + CURR_MTH_TRWI_QTY + PREV_1DAY_TRWI_QTY + SEWHA_IV_QTY + PDI_IV_QTY + TDD_PRDN_QTY > 0
		           ORDER BY PRNT_STATE DESC,
		                 QLTY_VEHL_CD,
		                 LANG_SORT_SN,
		                 MDL_MDY_CD DESC ) A,
		        TB_CODE_MGMT B,
		        TB_PRNT_REQ_INFO J,
		        TB_PRNT_BKGD_INFO K
		  WHERE A.PRNT_STATE = B.DL_EXPD_PRVS_CD
		    AND B.DL_EXPD_G_CD = '0016'
		    AND A.PRNT_STATE = DECODE('ALL', 'ALL', A.PRNT_STATE, 'ALL')
		    AND A.N_PRNT_PBCN_NO = J.N_PRNT_PBCN_NO(+)
		    AND A.N_PRNT_PBCN_NO = K.N_PRNT_PBCN_NO(+)
		    AND A.PRNT_STATE = '04'
		    ;
		
	V_USER_NM      TB_USR_MGMT.USER_NM%TYPE;
	V_USER_EML_ADR TB_USR_MGMT.USER_EML_ADR%TYPE;
	
	V_MAIL_TITLE   VARCHAR2(2000);
	V_MAIL_CONTENT VARCHAR2(20000);
	V_NO	NUMBER;
	
BEGIN

	-- 1. 메일 발송 컨텐츠 생성
	V_MAIL_TITLE := '오너스매뉴얼관리시스템 - 인쇄(긴급) 매뉴얼 리스트';
	V_MAIL_CONTENT := '<HTML>';
	V_MAIL_CONTENT := V_MAIL_CONTENT || '<HEAD>';
	V_MAIL_CONTENT := V_MAIL_CONTENT || '</HEAD>';
	V_MAIL_CONTENT := V_MAIL_CONTENT || '<BODY style="font-family: Malgun, Gulim; font-size:13px;">';
	V_MAIL_CONTENT := V_MAIL_CONTENT || '<TABLE border=1 style="border-collapse:collapse;text-align:center;">';
	V_MAIL_CONTENT := V_MAIL_CONTENT || '<THEAD>';
	V_MAIL_CONTENT := V_MAIL_CONTENT || '<TR style="background:#f6f6f6;">';
	V_MAIL_CONTENT := V_MAIL_CONTENT || '<TH>순번</TH>';
	V_MAIL_CONTENT := V_MAIL_CONTENT || '<TH>차종 </TH>';
	V_MAIL_CONTENT := V_MAIL_CONTENT || '<TH>언어</TH>';
	V_MAIL_CONTENT := V_MAIL_CONTENT || '<TH>예상재고<BR/>(2주)</TH>';
	V_MAIL_CONTENT := V_MAIL_CONTENT || '<TH>인쇄</TH>';
	V_MAIL_CONTENT := V_MAIL_CONTENT || '</TR>';
	V_MAIL_CONTENT := V_MAIL_CONTENT || '</THEAD>';
	V_MAIL_CONTENT := V_MAIL_CONTENT || '<TBODY>';

	V_NO := 0;
	FOR CONTENTS IN CONTENTS_LIST LOOP
		V_NO := V_NO + 1;
		V_MAIL_CONTENT := V_MAIL_CONTENT || '<TR>';
		V_MAIL_CONTENT := V_MAIL_CONTENT || '<TD>' || V_NO || '</TD>';
		V_MAIL_CONTENT := V_MAIL_CONTENT || '<TD>' || CONTENTS.QLTY_VEHL_NM || '</TD>';
		V_MAIL_CONTENT := V_MAIL_CONTENT || '<TD>' || CONTENTS.LANG_CD_NM || '</TD>';
		V_MAIL_CONTENT := V_MAIL_CONTENT || '<TD>' || CONTENTS.WEK2_AFTR_IV_QTY || '</TD>';
		V_MAIL_CONTENT := V_MAIL_CONTENT || '<TD>' || CONTENTS.PRNT_STATE_NM || '</TD>';
		V_MAIL_CONTENT := V_MAIL_CONTENT || '</TR>';
	END LOOP;

	V_MAIL_CONTENT := V_MAIL_CONTENT || '</TBODY>';
	V_MAIL_CONTENT := V_MAIL_CONTENT || '</TABLE>';
	V_MAIL_CONTENT := V_MAIL_CONTENT || '</BODY></HTML>';
	
	DBMS_OUTPUT.PUT_LINE(V_MAIL_CONTENT);
	
	-- 2. 메일링 리스트 대상자에게 메일 발송
	FOR USERS IN USER_LIST LOOP
		V_USER_NM := USERS.USER_NM;
		V_USER_EML_ADR := USERS.USER_EML_ADR;

			-- 메일 발송
			IF V_USER_EML_ADR <> ' ' THEN

			   SP_CHNL_INSERTSIMPLEEMAIL(V_USER_NM,
				   						 V_USER_EML_ADR,
										 'HOMMS',
										 'H',
										 '0',
										 '0',
										 V_MAIL_CONTENT,
                               			 SYSDATE,
										 V_MAIL_TITLE,
										 '0',
										 '0',
										 V_USER_NM,
				   						 V_USER_EML_ADR,
										 'HOMMS');

			END IF;

	END LOOP;
	
	PG_INTERFACE_APS.WRITE_BATCH_LOG('긴급인쇄메일알람', SYSDATE, 'S', '출력건수 : ' || V_NO || '건');
	
EXCEPTION
	WHEN OTHERS THEN
		PG_INTERFACE_APS.WRITE_BATCH_LOG('긴급인쇄메일알람', SYSDATE, 'F', '긴급인쇄알람 메일 발송 실패(' || V_NO || ' 건)');
		DBMS_OUTPUT.PUT_LINE(V_MAIL_CONTENT);
		DBMS_OUTPUT.PUT_LINE(SQLCODE || ' = ' || SQLERRM);
	
END;