CREATE OR REPLACE PROCEDURE SP_GEN_APM_LOG
/******************************************************************************
 *    SYSTEM명      : 오너스 매뉴얼                    
 *    PPROCEDURE 명 : SP_GEN_APM_LOG 
 *    DESCRIPTION   : (일배치)APM에 전송할 로그 데이터를 IF_APM_LOG로 INSERT
 *    사용 TABLE명  : (조회용)TCMM_LOGIN_LOG, TCMM_ACC_MST
 *                    (수정용)IF_APM_LOG
 *    IN  PARAMETER :  N/A
 *    OUT PARAMETER :  N/A
 *    IN OUT PARAMETER: N/A
 *
 *    변경자     변경일자            변경사유
 *  --------------------------------------------------------------------------
 *    임용석     2019-03-08          최초작성
 ******************************************************************************/
IS
    BATCH_NAME      VARCHAR2(20)    := 'SP_GEN_APM_LOG';
    RETURN_MSG      VARCHAR2(256);
    RETURN_SQL_CODE NUMBER          := 0;
    INSERT_CNT      NUMBER          := 0;
    SP_RUN_STRT_DT  DATE            := SYSDATE;
BEGIN

    -- 배치를 다시 실행시키는 경우 등을 고려하여 기 적재한 데이터 삭제
    BEGIN
        DELETE FROM IF_APM_LOG
        WHERE CRTN_TM >= TRUNC(SYSDATE -1) AND CRTN_TM < TRUNC(SYSDATE);

        COMMIT;

    EXCEPTION WHEN OTHERS THEN
        ROLLBACK;

    END;

    BEGIN
        INSERT INTO IF_APM_LOG
      SELECT
            'C0337'             INFO_SYS_CODE,
            L.PGM_ID            SCRIN_ID,
            '1'                 SCRIN_SKLL_CODE,
            L.USER_ID           EMPLYR_ID,
            ''                  EMPLYR_IP,
            ''                  SERVER_IP,
            M.DP_URL            CALL_URL,
            TO_CHAR(L.LOG_DTM, 'yyyyMMddHH24MISS')    CRTN_TM,
            NULL                CLNT_RSPNS_TIME,
            NULL                NTWRK_RSPNS_TIME,
            NULL                APLCTN_RSPNS_TIME,
            'N'                 FLAG
FROM TB_USE_DPMST M INNER JOIN TB_USE_DP_LOG L ON M.PGM_ID = L.PGM_ID
WHERE  TO_CHAR(L.LOG_DTM, 'yyyyMMddHH24MISS') >= TO_CHAR(TRUNC(SYSDATE - 1), 'yyyyMMddHH24MISS') 
AND  TO_CHAR(L.LOG_DTM, 'yyyyMMddHH24MISS') < TO_CHAR(TRUNC(SYSDATE), 'yyyyMMddHH24MISS')
;

        INSERT_CNT := SQL%ROWCOUNT;
        RETURN_SQL_CODE := SQLCODE;

        RETURN_MSG := 'IF_APM_LOG에 INSERT [' || INSERT_CNT || ']개 처리 완료';

        COMMIT;

    EXCEPTION WHEN OTHERS THEN
        RETURN_MSG := SQLERRM;
        RETURN_SQL_CODE := SQLCODE;
        PG_INTERFACE_APS.WRITE_BATCH_LOG(BATCH_NAME, SP_RUN_STRT_DT, 'F','SQL_CODE: '||RETURN_SQL_CODE ||', MSG:'|| RETURN_MSG);

        ROLLBACK;

    END;

    PG_INTERFACE_APS.WRITE_BATCH_LOG(BATCH_NAME, SP_RUN_STRT_DT, 'S', RETURN_MSG);

END;

