CREATE OR REPLACE 
	   --메일 발송 작업 수행 								 
       PROCEDURE SP_SEND_MAIL(P_VEHL_CD        VARCHAR2,
	   			 		      P_MDL_MDY_CD     VARCHAR2,
						      P_BLNS_CO_CD     VARCHAR2,
						      P_USER_EENO      VARCHAR2,
							  P_MAIL_TITLE	   VARCHAR2,
							  P_MAIL_CONTENT   VARCHAR2)
	   IS
	   	 
		 CURSOR CRGR_USER_LIST_INFO IS SELECT A.USER_EENO AS USER_EENO,
                					   		  NVL(A.USER_NM, ' ') AS USER_NM,
--											  A.USER_EENO || '@autos.hmgc.net' AS USER_EML_ADR
											  A.USER_EML_ADR
           							   FROM TB_USR_MGMT A,
		   							   		TB_VEHL_CRGR_MGMT B
		   							   WHERE A.USER_EENO = B.CRGR_EENO
		   							   AND B.QLTY_VEHL_CD = P_VEHL_CD
		   							   AND B.MDL_MDY_CD = P_MDL_MDY_CD
		   							   AND B.BLNS_CO_CD = P_BLNS_CO_CD
           							   AND B.USE_YN = 'Y'
		   							   AND A.USE_YN = 'Y';
									   
		 V_USER_NM      TB_USR_MGMT.USER_NM%TYPE;
		 V_USER_EML_ADR TB_USR_MGMT.USER_EML_ADR%TYPE;
		 
		 V_MAIL_CONTENT VARCHAR2(8000);
		 
	   BEGIN
	   		
			SELECT NVL(USER_NM, ' '),
--			       P_USER_EENO || '@autos.hmgc.net'
					NVL(USER_EML_ADR, ' ')
			INTO V_USER_NM,
			     V_USER_EML_ADR
			FROM TB_USR_MGMT
			WHERE USER_EENO = P_USER_EENO ;
			
			V_MAIL_CONTENT := '<HTML><BODY>' ||
						      P_MAIL_CONTENT ||
							  '</BODY></HTML>';
			
			--메일발송자 에게도 메일을 발송한다. 
			IF V_USER_EML_ADR <> ' ' THEN
			   
			   SP_CHNL_INSERTSIMPLEEMAIL2(V_USER_NM, 
				   						 V_USER_EML_ADR, 
										 P_USER_EENO, 
										 'H', 
										 '0', 
										 '0', 
										 V_MAIL_CONTENT,
                               			 SYSDATE, 
										 P_MAIL_TITLE, 
										 '0', 
										 '0', 
										 V_USER_NM, 
				   						 V_USER_EML_ADR, 
										 P_USER_EENO);
											 
			END IF;
			  
			FOR USER_LIST IN CRGR_USER_LIST_INFO LOOP
				
				IF USER_LIST.USER_EML_ADR IS NOT NULL THEN
				   
				   SP_CHNL_INSERTSIMPLEEMAIL2(V_USER_NM, 
				   							 V_USER_EML_ADR, 
											 P_USER_EENO, 
											 'H', 
											 '0', 
											 '0', 
											 V_MAIL_CONTENT,
                               				 SYSDATE, 
											 P_MAIL_TITLE, 
											 '0', 
											 '0', 
											 USER_LIST.USER_NM, 
											 USER_LIST.USER_EML_ADR, 
											 USER_LIST.USER_EENO);
							   
				END IF;
					   
			END LOOP;
			
	   END SP_SEND_MAIL;



