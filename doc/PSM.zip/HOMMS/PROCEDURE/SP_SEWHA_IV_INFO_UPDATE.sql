CREATE OR REPLACE        --세화 재고정보 업데이트 수행 
	   PROCEDURE SP_SEWHA_IV_INFO_UPDATE(P_VEHL_CD         VARCHAR2,
	   			 					     P_MDL_MDY_CD	   VARCHAR2,
									     P_LANG_CD         VARCHAR2,
										 P_EXPD_MDL_MDY_CD VARCHAR2,
									     P_N_PRNT_PBCN_NO  VARCHAR2,
									     P_CLS_YMD		   VARCHAR2,
									     P_DIFF_RQ_QTY	   NUMBER,
									     P_USER_EENO	   VARCHAR2,
										 P_FLAG			   VARCHAR2
										 )
       IS
	   	 
		 V_QTY		   NUMBER;
		 V_DIFF_RQ_QTY NUMBER;
		 V_DEEI1_QTY   NUMBER;
		 
	   BEGIN
	   		
	   		SELECT NVL(SUM(IV_QTY), 0),
				   NVL(SUM(DEEI1_QTY), 0)
			INTO V_QTY,
				 V_DEEI1_QTY
			FROM TB_SEWHA_IV_INFO
			WHERE CLS_YMD = P_CLS_YMD
			AND QLTY_VEHL_CD = P_VEHL_CD
			AND DL_EXPD_MDL_MDY_CD = P_EXPD_MDL_MDY_CD
			AND LANG_CD = P_LANG_CD
			AND N_PRNT_PBCN_NO = P_N_PRNT_PBCN_NO
			AND CMPL_YN = 'N';

			--입고확인시의 재고보정인 경우 
			--입고확인작업은 수정기능이 없고, 수량이 증가만 되고 감소가 되지 않으므로  
			--재고수량보다 출고요청수량이 큰지의 여부만을 확인해 주면 된다. 
			IF P_FLAG = 'Y' THEN
			 
			   IF V_QTY < P_DIFF_RQ_QTY THEN 
					   
				  --출고요청된 데이터의 경우 재고가 없거나 출고수량이 재고수량보다 큰 경우에도 출고가 될수 있도록 
			   	  --처리해 달라는 요청에 따라서 아래와 같은 조건 검사 부분을 추가함(재고수량보다 출고수량이 큰 경우 재고수량을 0으로 설정해 준다.)
				  V_DIFF_RQ_QTY := V_QTY;
				  
				  --입고확인시에만 사용되므로 기존의 초과,부족 수량에 신규 부족수량을 더해 주면 된다. 
				  V_DEEI1_QTY   := V_DEEI1_QTY + (P_DIFF_RQ_QTY - V_QTY);
			   
			   ELSE
			      
				  V_DIFF_RQ_QTY := P_DIFF_RQ_QTY;
				  
			   END IF;
			   
			   --현재 날짜에 재고 데이터가 존재하지 않더라도 예외발생 없이 그대로 진행하도록 한다.
			   UPDATE TB_SEWHA_IV_INFO
			   SET IV_QTY = (IV_QTY - V_DIFF_RQ_QTY),
				   UPDR_EENO = P_USER_EENO,
				   MDFY_DTM = SYSDATE,
				   DEEI1_QTY = CASE WHEN V_DEEI1_QTY > 0 THEN V_DEEI1_QTY ELSE NULL END
			   WHERE CLS_YMD = P_CLS_YMD
			   AND QLTY_VEHL_CD = P_VEHL_CD
			   AND DL_EXPD_MDL_MDY_CD = P_EXPD_MDL_MDY_CD
			   AND LANG_CD = P_LANG_CD
			   AND N_PRNT_PBCN_NO = P_N_PRNT_PBCN_NO
			   AND CMPL_YN = 'N'  --이전날짜의 데이터인 경우에는 입력이 되지 않도록 한다.. 
			   ;
			   
			   --재고 데이터가 없어서 입력이 되지 않은 경우에는 0 으로 추가해 준다. 
			   IF SQL%NOTFOUND THEN
			   	  
				  INSERT INTO TB_SEWHA_IV_INFO
				  (CLS_YMD,
			 	   QLTY_VEHL_CD,
			 	   DL_EXPD_MDL_MDY_CD,
			 	   LANG_CD,
			 	   N_PRNT_PBCN_NO,
			 	   IV_QTY,
			 	   DL_EXPD_TMP_IV_QTY,
			 	   CMPL_YN,
			 	   PPRR_EENO,
			 	   FRAM_DTM,
			 	   UPDR_EENO,
			 	   MDFY_DTM,
				   TMP_TRTM_YN,
				   DEEI1_QTY
			      )
				  VALUES(P_CLS_YMD,
					     P_VEHL_CD,
						 P_EXPD_MDL_MDY_CD,
						 P_LANG_CD,
						 P_N_PRNT_PBCN_NO,
						 0,
						 0,
						 'N',
						 P_USER_EENO,
						 SYSDATE,
						 P_USER_EENO,
						 SYSDATE,
						 --재고 데이터가 0 이므로 임시생성된다는 표시를 해준다. 
						 'Y',
						 CASE WHEN V_DEEI1_QTY > 0 THEN V_DEEI1_QTY ELSE NULL END
					    );	  
			   END IF;
			   
			--별도요청 관련 재고보정인 경우 	
			ELSE
				
				--재고수량이 출고수량보다 작은 경우에는 출고 하지 못한다. 
				IF V_QTY < P_DIFF_RQ_QTY THEN
			   
			   	   RAISE_APPLICATION_ERROR(-20001, 'Invalid sewon inventory quantity ' || 
			   								       'date:' || TO_CHAR(TO_DATE(P_CLS_YMD, 'YYYYMMDD'), 'YYYY-MM-DD') || ',' ||
											       'vehl:' || P_VEHL_CD || ',' || 
											       'mkyr:' || P_EXPD_MDL_MDY_CD || ',' || 
											       'lang:' || P_LANG_CD || ',' || P_N_PRNT_PBCN_NO || ',' ||
											       'qty :' || TO_CHAR(P_DIFF_RQ_QTY));
											   
			    END IF;
				
				UPDATE TB_SEWHA_IV_INFO
				SET IV_QTY = (IV_QTY - P_DIFF_RQ_QTY),
					UPDR_EENO = P_USER_EENO,
					MDFY_DTM = SYSDATE
			    WHERE CLS_YMD = P_CLS_YMD
			    AND QLTY_VEHL_CD = P_VEHL_CD
			    AND DL_EXPD_MDL_MDY_CD = P_EXPD_MDL_MDY_CD
			    AND LANG_CD = P_LANG_CD
			    AND N_PRNT_PBCN_NO = P_N_PRNT_PBCN_NO
			    AND CMPL_YN = 'N' --이전날짜의 데이터인 경우에는 입력이 되지 않도록 한다.. 
			    ;
			
			    IF SQL%NOTFOUND THEN
			   
			       RAISE_APPLICATION_ERROR(-20001, 'Invalid input value ' || 
			   								       'date:' || TO_CHAR(TO_DATE(P_CLS_YMD, 'YYYYMMDD'), 'YYYY-MM-DD') || ',' ||
											       'vehl:' || P_VEHL_CD || ',' || 
											       'mkyr:' || P_EXPD_MDL_MDY_CD || ',' || 
											       'lang:' || P_LANG_CD || ',' || P_N_PRNT_PBCN_NO);
			   
			    END IF;
			
			END IF;
			
			--현재의 출고 내역을 재고상세 테이블에 저장한다.
			SP_UPDATE_SEWHA_IV_DTL_INFO(P_VEHL_CD,
			  						    P_EXPD_MDL_MDY_CD,
									    P_LANG_CD,
									    P_N_PRNT_PBCN_NO,
									    P_CLS_YMD,
										P_USER_EENO
										);

			--출고 내역에 대한 재고상세 테이블 재계산 작업 수행 							
		    SP_RECALCULATE_SEWHA_IV_DTL4(P_CLS_YMD,
										 P_VEHL_CD,
									     P_LANG_CD,
										 P_USER_EENO
										 );		

	   END SP_SEWHA_IV_INFO_UPDATE;	
