CREATE or replace PROCEDURE HOMMS_ADM.SP_CHNL_INSERTSIMPLEEMAIL
/******************************************************************************/
/*    SYSTEM명     : ALP 프로젝트
/*    SUB SYSTEM명 : 고객관리
/*    PPROCEDURE 명 : SP_CHNL_INSERTSIMPLEEMAIL
/*    SCRIPT 명     : SP_CHNL_INSERTSIMPLEEMAIL.sql
/*    DESCRIPTION   : EMS 단건 발송
/*    사용 TABLE명 :  MAILQUEUE, RECIPIENTINFO
/*    IN  PARAMETER :
/*            P_SNAME      --발송자명
/*        P_SMAIL       --발송자 이메일 주소
/*          P_SID          --발송자 아이디
/*          P_SPOS      --회사구분필드 (H, K)
/*          P_RPOS      --수신자 그룹위치 (입력값 고정 0)
/*          P_CTNSPOS      --컨텐트위치 (컨텐트 필드에 저장 : 0, 컨텐트가 위치한 URL : 1, 컨텐트 파일의 절대경로 : 2)
/*          P_CONTENTS  --컨텐트 템플릿
/*          P_SDATE      --메일발송일자 (YYYY/MM/DD HH24:MI)
/*          P_SUBJECT      --메일제목
/*          P_STATUS      --예약항목 상태코드 (초기값 0 )
/*          P_CTID      --카테고리 ID (CT_DESC 테이블 참조)
/*          P_RNAME      --수신자명
/*          P_RMAIL      --수신자이메일주소
/*          P_RID          --수신자 아이디
/*
/*    OUT PARAMETER :
/*    IN OUT PARAMETER:
/*
/*    변경자     변경일자            변경사유
/*  --------------------------------------------------------------------------
/*    최재동     2005-12-06         초기생성
/******************************************************************************/
(

 P_SNAME    IN MAILQUEUE.SNAME@DBLK_EMS%TYPE,
 P_SMAIL     IN MAILQUEUE.SMAIL@DBLK_EMS%TYPE,
 P_SID       IN MAILQUEUE.SID@DBLK_EMS%TYPE,
 P_SPOS      IN MAILQUEUE.SPOS@DBLK_EMS%TYPE,
 P_RPOS      IN MAILQUEUE.RPOS@DBLK_EMS%TYPE,
 P_CTNSPOS     IN MAILQUEUE.CTNSPOS@DBLK_EMS%TYPE,
 P_CONTENTS IN VARCHAR,
 P_SDATE       IN MAILQUEUE.SDATE@DBLK_EMS%TYPE,
 P_SUBJECT     IN MAILQUEUE.SUBJECT@DBLK_EMS%TYPE,
 P_STATUS      IN MAILQUEUE.STATUS@DBLK_EMS%TYPE,
 P_CTID         IN MAILQUEUE.CTID@DBLK_EMS%TYPE,
 P_RNAME    IN RECIPIENTINFO.RNAME@DBLK_EMS%TYPE,
 P_RMAIL    IN RECIPIENTINFO.RMAIL@DBLK_EMS%TYPE,
 P_RID      IN RECIPIENTINFO.RID@DBLK_EMS%TYPE

 /****
 P_SNAME    IN MAILQUEUE.SNAME%TYPE,
 P_SMAIL     IN MAILQUEUE.SMAIL%TYPE,
 P_SID       IN MAILQUEUE.SID%TYPE,
 P_SPOS      IN MAILQUEUE.SPOS%TYPE,
 P_RPOS      IN MAILQUEUE.RPOS%TYPE,
 P_CTNSPOS     IN MAILQUEUE.CTNSPOS%TYPE,
 P_CONTENTS IN VARCHAR,
 P_SDATE       IN MAILQUEUE.SDATE%TYPE,
 P_SUBJECT     IN MAILQUEUE.SUBJECT%TYPE,
 P_STATUS      IN MAILQUEUE.STATUS%TYPE,
 P_CTID         IN MAILQUEUE.CTID%TYPE,
 P_RNAME    IN RECIPIENTINFO.RNAME%TYPE,
 P_RMAIL    IN RECIPIENTINFO.RMAIL%TYPE,
 P_RID      IN RECIPIENTINFO.RID%TYPE
  ***/
)
IS
 
 PRAGMA AUTONOMOUS_TRANSACTION;
 
 V_MID        NUMBER;
 V_CONTENTS VARCHAR(30000);
 V_RNAME    VARCHAR(20);
-- V_GRPCD    VARCHAR(3);

BEGIN


     V_CONTENTS := P_CONTENTS;
     V_RNAME := SUBSTRB(P_RNAME, 0, 15);

-- 이메일 로그 DB등록  
/*
     	     SELECT NVL(MAX(MID),0)+1 INTO V_MID FROM MAILQUEUE;
		
		     INSERT INTO MAILQUEUE (MID, SNAME, SMAIL, SID, SPOS, RPOS, CTNSPOS, CONTENTS, SDATE, SUBJECT, STATUS, CTID)     
		     VALUES
		     (V_MID, P_SNAME, P_SMAIL, P_SID, 'H', P_RPOS, P_CTNSPOS, V_CONTENTS, P_SDATE, P_SUBJECT, P_STATUS, P_CTID);
		
		     INSERT INTO RECIPIENTINFO (MID, RNAME, RMAIL, RID)
		     VALUES
		     (V_MID, V_RNAME, P_RMAIL, P_RID);
/*
             SELECT NVL(GRP_CD,'00X') AS GRP_CD
               INTO V_GRPCD
               FROM TB_USR_MGMT
              WHERE USER_EENO = P_SID;
*/

-- 이메일 발송
--			IF V_GRPCD = '000' or V_GRPCD = '001' or V_GRPCD = '004' THEN
				SELECT MAILQUEUESEQ.NEXTVAL@DBLK_EMS INTO V_MID FROM DUAL;
				
				INSERT INTO MAILQUEUE@DBLK_EMS (MID, SNAME, SMAIL, SID, SPOS, RPOS, CTNSPOS, CONTENTS, SDATE, SUBJECT, STATUS, CTID)
			    VALUES
			    (V_MID, P_SNAME, P_SMAIL, P_SID, 'H', P_RPOS, P_CTNSPOS, V_CONTENTS, P_SDATE, P_SUBJECT, P_STATUS, P_CTID);
			    
			    INSERT INTO RECIPIENTINFO@DBLK_EMS (MID, RNAME, RMAIL, RID)
				VALUES
	            (V_MID, V_RNAME, P_RMAIL, P_RID);
	
--			END IF;





     COMMIT;

    --EXCEPTION 추가_20081024
    EXCEPTION
          WHEN OTHERS THEN
                   ROLLBACK ;
                 RAISE_APPLICATION_ERROR(-20102, ' CODE=' || SQLCODE || ',ERRM=' || SQLERRM );
               

END SP_CHNL_INSERTSIMPLEEMAIL;