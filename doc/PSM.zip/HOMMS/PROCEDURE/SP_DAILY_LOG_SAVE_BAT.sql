CREATE OR REPLACE PROCEDURE SP_DAILY_LOG_SAVE_BAT
IS 

	V_QTY		NUMBER;
	V_NAX_NO	NUMBER;
	STRT_DTM    DATE;

BEGIN 

    STRT_DTM  := SYSDATE;
    
	SELECT COUNT(*)
      INTO V_QTY
	  FROM TB_LOG_USE
	 WHERE USE_DTM >= TO_DATE(TO_CHAR(SYSDATE,'YYYYMMDD')) - INTERVAL '1' DAY
       AND USE_DTM < TO_DATE(TO_CHAR(SYSDATE,'YYYYMMDD'))
       AND USE_DTM > (
                      SELECT MAX(LOG_DTM)
                        FROM TB_USE_DP_LOG
                     )
     ;    
    
    IF V_QTY > 0 THEN
    
    	SELECT MAX(LOG_SN)
          INTO V_NAX_NO
    	  FROM TB_USE_DP_LOG ;

    
	    INSERT INTO TB_USE_DP_LOG 
	    (
	    
			SELECT  ROWNUM + V_NAX_NO AS LOG_SN
			       , A.*
			  FROM (
					SELECT   'C0337' AS SYTM_CD
					       , '현대오너스매뉴얼 재고관리시스템' AS SYTM_NM 
					       , (  SELECT Z.MENU_ID || TRIM(TO_CHAR(Z.ACT_SN, '0009'))   AS ACT_ID 
						       FROM TB_ACT_MGMT Z 
						       WHERE Z.ACT_ID = B.ACT_ID
					       ) AS PGM_ID
						       , CASE WHEN A.DP_MN_NM1 IS NOT NULL 
					               AND A.DP_MN_NM2 IS NOT NULL 
					               AND A.DP_MN_NM3 IS NOT NULL 
					               AND A.DP_MN_NM4 IS NOT NULL 
					               AND A.DP_MN_NM5 IS NOT NULL 
					              THEN A.DP_MN_NM1 || '-' || A.DP_MN_NM2 || '-' || A.DP_MN_NM3 || '-' || A.DP_MN_NM4 || '-' || A.DP_MN_NM5 || ':' || A.DP_NM 
					              WHEN A.DP_MN_NM1 IS NOT NULL
					               AND A.DP_MN_NM2 IS NOT NULL 
					               AND A.DP_MN_NM3 IS NOT NULL 
					               AND A.DP_MN_NM4 IS NOT NULL 
					               AND A.DP_MN_NM5 IS NULL 
					              THEN A.DP_MN_NM1 || '-' || A.DP_MN_NM2 || '-' || A.DP_MN_NM3 || '-' || A.DP_MN_NM4 || ':' || A.DP_NM
					              WHEN A.DP_MN_NM1 IS NOT NULL 
					               AND A.DP_MN_NM2 IS NOT NULL 
					               AND A.DP_MN_NM3 IS NOT NULL 
					               AND A.DP_MN_NM4 IS NULL 
					               AND A.DP_MN_NM5 IS NULL 
					              THEN A.DP_MN_NM1 || '-' || A.DP_MN_NM2 || '-' || A.DP_MN_NM3 || ':' || A.DP_NM
					              WHEN A.DP_MN_NM1 IS NOT NULL 
					               AND A.DP_MN_NM2 IS NOT NULL 
					               AND A.DP_MN_NM3 IS NULL 
					               AND A.DP_MN_NM4 IS NULL 
					               AND A.DP_MN_NM5 IS NULL 
					              THEN A.DP_MN_NM1 || '-' || A.DP_MN_NM2 || ':' || A.DP_NM
					              WHEN A.DP_MN_NM1 IS NOT NULL 
					               AND A.DP_MN_NM2 IS NULL 
					               AND A.DP_MN_NM3 IS NULL 
					               AND A.DP_MN_NM4 IS NULL 
					               AND A.DP_MN_NM5 IS NULL 
					              THEN A.DP_MN_NM1 || ':' || A.DP_NM
					              ELSE A.DP_NM
					         END AS DP_NM
					       , B.USER_ID
					       , C.USER_NM
					       , 'H' AS COMP_CD
					       , D.DL_EXPD_PRVS_NM AS COMP_NM
					       , C.USER_DCD AS DEPT_NM
					       , E.DL_EXPD_PRVS_NM AS DEPT_NM
					       , B.USE_DTM AS LOG_DTM
					       , 1 AS LOG_CNT
					       , DECODE(C.GRP_CD,'000','1','2') AS HAE_GBN
					  FROM   TB_USE_DPMST A
					       , TB_LOG_USE B
					       , TB_USR_MGMT C
					       , (
					          SELECT DL_EXPD_PRVS_CD, DL_EXPD_PRVS_NM
					            FROM TB_CODE_MGMT
					           WHERE DL_EXPD_G_CD = '0001'
					          ) D
					       , (
					          SELECT DL_EXPD_PRVS_CD, DL_EXPD_PRVS_NM
					            FROM TB_CODE_MGMT
					           WHERE DL_EXPD_G_CD = '0011'
					          ) E
					 WHERE B.ACT_ID = A.ACT_ID
					   AND B.USER_ID = C.USER_EENO
			           AND B.USE_DTM >= TO_DATE(TO_CHAR(SYSDATE,'YYYYMMDD')) - INTERVAL '1' DAY
			           AND B.USE_DTM < TO_DATE(TO_CHAR(SYSDATE,'YYYYMMDD'))
					   AND B.USE_DTM > (
                                        SELECT MAX(LOG_DTM)
                                          FROM TB_USE_DP_LOG
                                        )
					   AND C.BLNS_CO_CD = D.DL_EXPD_PRVS_CD
					   AND C.USER_DCD = E.DL_EXPD_PRVS_CD
			         ORDER BY B.USE_DTM
					) A
    	);
    
    	COMMIT;
    	PG_INTERFACE_APS.WRITE_BATCH_EXE_LOG('사용로그 배치', STRT_DTM, 'S', '사용로그 등록 : ' || V_QTY);
    	
    ELSE
    
        PG_INTERFACE_APS.WRITE_BATCH_EXE_LOG('사용로그 배치', STRT_DTM, 'S', '사용로그가 없습니다.');
        
    END IF;

		 EXCEPTION
		 WHEN OTHERS THEN
		 ROLLBACK;
		 PG_INTERFACE_APS.WRITE_BATCH_EXE_LOG('사용로그 배치', STRT_DTM, 'F', '사용로그 배치처리실패:[' || SQLERRM || ']');
				 
END SP_DAILY_LOG_SAVE_BAT;