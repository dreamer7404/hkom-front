CREATE OR REPLACE 
	--세화재고 조회(승상구분, PDI, 차종, 연식, 지역, 언어) 						  
    PROCEDURE SP_GET_SEWHA_IV_INFO2(P_USER_EENO    VARCHAR2,
								    P_CURR_YMD	   VARCHAR2,
								    P_PAC_SCN_CD   VARCHAR2,
 								    P_PDI_CD	   VARCHAR2,
								    P_VEHL_CD	   VARCHAR2,
								    P_MDL_MDY	   VARCHAR2,
								    P_REGN_CD	   VARCHAR2,
								    P_LANG_CD	   VARCHAR2,
								    P_DLVY_STATE   VARCHAR2,
								    P_IV_STATE     VARCHAR2,
                                    RS 		       OUT SYS_REFCURSOR)
	   IS
	   	  
		  V_FROM_MDL_MDY VARCHAR2(2);
		  V_TO_MDL_MDY   VARCHAR2(2);


	   BEGIN
	   	  
		  PG_COMMON.SP_GET_VALID_MDL_MDY4(P_CURR_YMD, '', V_FROM_MDL_MDY, V_TO_MDL_MDY);
		  
		  
		  IF P_DLVY_STATE = 'ALL' THEN
		  	 
			 OPEN RS FOR
			 	  WITH T AS (SELECT A.CL_SCN_CD,
			          	 		    C.DATA_SN,
			  					    C.QLTY_VEHL_CD,
                                    C.MDL_MDY_CD,
                                    C.LANG_CD,
									C.QLTY_VEHL_CD || '-' || C.MDL_MDY_CD AS QLTY_VEHL_NM,
									'(' || C.LANG_CD || ')' || C.LANG_CD_NM AS LANG_CD_NM,
                                    C.DL_EXPD_REGN_CD,
									C.SORT_SN AS LANG_SORT_SN
                             FROM (SELECT QLTY_VEHL_CD,
                                          MAX(CL_SCN_CD) AS CL_SCN_CD
                                   FROM TB_AUTH_VEHL
                                   WHERE USER_EENO = P_USER_EENO
                                   AND QLTY_VEHL_CD = DECODE(P_VEHL_CD, 'ALL', QLTY_VEHL_CD, P_VEHL_CD)
                                   GROUP BY QLTY_VEHL_CD
                                  ) A,
                                  TB_VEHL_MGMT B,
                                  TB_LANG_MGMT C
                             WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
                             AND A.QLTY_VEHL_CD = C.QLTY_VEHL_CD
                             AND B.MDL_MDY_CD = C.MDL_MDY_CD
                             AND B.MDL_MDY_CD BETWEEN V_FROM_MDL_MDY AND V_TO_MDL_MDY
                             AND B.MDL_MDY_CD = DECODE(P_MDL_MDY , '', B.MDL_MDY_CD, P_MDL_MDY)
						     AND B.DL_EXPD_PAC_SCN_CD = DECODE(P_PAC_SCN_CD, 'ALL', B.DL_EXPD_PAC_SCN_CD, P_PAC_SCN_CD)
                             AND B.DL_EXPD_PDI_CD = DECODE(P_PDI_CD, 'ALL', B.DL_EXPD_PDI_CD, P_PDI_CD)
						     AND C.DL_EXPD_REGN_CD = DECODE(P_REGN_CD, 'ALL', C.DL_EXPD_REGN_CD, P_REGN_CD)
                             AND C.LANG_CD = DECODE(P_LANG_CD, 'ALL', C.LANG_CD, P_LANG_CD)
							 AND B.USE_YN = 'Y'
							 AND C.USE_YN = 'Y'
                            )
                                    SELECT '1' CL_SCN_CD,
			   		   '1' DATA_SN,
					     '1' QLTY_VEHL_CD,
					     '1' MDL_MDY_CD,
					     '1' LANG_CD,
					     '1' DL_EXPD_REGN_CD,
					     '1' QLTY_VEHL_NM,
					     '1' LANG_CD_NM,
					     '1' DL_EXPD_REGN_NM,
					     '1' WEK2_PLAN_QTY,
					     '1' DAY3_PLAN_QTY,
					     '1' CURR_MTH_TRWI_QTY,
					     '1' PREV_1DAY_TRWI_QTY,
					     '1' SEWHA_IV_QTY,
					     '1' SEWHA_PRNT_YN, --세화 인쇄중 데이터 존재여부 확인 
					     '1' SEWHA_DLVY_QTY,
					     '1' PDI_DEEI1_QTY,
						   '1' EXPD_WHSN_ST_NM,
						   '1' PDI_IV_QTY,
					     '1' DSID3_QTY,
						   '1' DAY3_AFTR_IV_QTY,
						   '1' WEK2_AFTR_IV_QTY,
						   '1' PRNT_STATE,
						   '1' PRNT_STATE_NM,
						   '1' PLNT_DAY3_QTY_TEXT,
					     '1' PLNT_WEK2_QTY_TEXT,
					     '1' PLNT_YN
					     FROM DUAL
					     UNION ALL
        SELECT '2' CL_SCN_CD,
			   		   '2' DATA_SN,
					     '2' QLTY_VEHL_CD,
					     '2' MDL_MDY_CD,
					     '2' LANG_CD,
					     '2' DL_EXPD_REGN_CD,
					     '2' QLTY_VEHL_NM,
					     '2' LANG_CD_NM,
					     '2' DL_EXPD_REGN_NM,
					     '2' WEK2_PLAN_QTY,
					     '2' DAY3_PLAN_QTY,
					     '2' CURR_MTH_TRWI_QTY,
					     '2' PREV_1DAY_TRWI_QTY,
					     '2' SEWHA_IV_QTY,
					     '2' SEWHA_PRNT_YN, --세화 인쇄중 데이터 존재여부 확인 
					     '2' SEWHA_DLVY_QTY,
					     '2' PDI_DEEI1_QTY,
						   '2' EXPD_WHSN_ST_NM,
						   '2' PDI_IV_QTY,
					     '2' DSID3_QTY,
						   '2' DAY3_AFTR_IV_QTY,
						   '2' WEK2_AFTR_IV_QTY,
						   '2' PRNT_STATE,
						   '2' PRNT_STATE_NM,
						   '2' PLNT_DAY3_QTY_TEXT,
					     '2' PLNT_WEK2_QTY_TEXT,
					     '2' PLNT_YN
					     FROM DUAL;

		  END IF;
		  
	   END SP_GET_SEWHA_IV_INFO2;


