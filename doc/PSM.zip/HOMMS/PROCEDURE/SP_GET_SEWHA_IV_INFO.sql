CREATE OR REPLACE    --세화재고 조회(PDI, 차종, 연식, 지역, 언어) 
   PROCEDURE SP_GET_SEWHA_IV_INFO(P_USER_EENO    VARCHAR2,
								  P_CURR_YMD	 VARCHAR2,
 								  P_PDI_CD	     VARCHAR2,
								  P_VEHL_CD	     VARCHAR2,
								  P_MDL_MDY	     VARCHAR2,
								  P_REGN_CD	     VARCHAR2,
								  P_LANG_CD	     VARCHAR2,
								  P_DLVY_STATE   VARCHAR2,
								  P_IV_STATE     VARCHAR2,
                                  RS 		     OUT SYS_REFCURSOR)
    IS
	  	V_MESSAGE VARCHAR2(8000);
	BEGIN			
			PG_TOT_IV_INFO.SP_GET_MESSAGE(P_CURR_YMD, V_MESSAGE);
			
			--P_MESSAGE := V_MESSAGE;
			
			SP_GET_SEWHA_IV_INFO2(P_USER_EENO,
								  P_CURR_YMD,
								  'ALL',
								  P_PDI_CD,
								  P_VEHL_CD,
								  P_MDL_MDY,
								  P_REGN_CD,
								  P_LANG_CD,
								  P_DLVY_STATE,
								  P_IV_STATE,
								  RS);
								  
	END SP_GET_SEWHA_IV_INFO;