CREATE OR REPLACE FUNCTION FU_MD5(str IN VARCHAR2)
RETURN VARCHAR2
IS V_CHECKSUM VARCHAR2(32);

BEGIN
    V_CHECKSUM := LOWER( RAWTOHEX( UTL_RAW.CAST_TO_RAW( SYS.DBMS_OBFUSCATION_TOOLKIT.MD5(input_string => str) ) ) );
    RETURN V_CHECKSUM;
        EXCEPTION
            WHEN NO_DATA_FOUND THEN
            NULL;
        WHEN OTHERS THEN
            -- Consider logging the error and then re-raise
            RAISE;
END FU_MD5;