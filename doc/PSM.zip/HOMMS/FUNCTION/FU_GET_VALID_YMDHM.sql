CREATE OR REPLACE
	   FUNCTION FU_GET_VALID_YMDHM(P_YMDHM VARCHAR2) RETURN VARCHAR2
	   IS
	   	 
		 V_CURR_YER CHAR(4);
		 V_CURR_MTH CHAR(2);
		 V_CURR_DAY CHAR(2);
		 
	   BEGIN
	   	 
		 	V_CURR_YER := SUBSTR(P_YMDHM, 1, 4);
			V_CURR_MTH := SUBSTR(P_YMDHM, 5, 2);
			V_CURR_DAY := SUBSTR(P_YMDHM, 7, 2);
			
			IF V_CURR_YER = '0000' OR
			   V_CURR_MTH = '00' OR
			   V_CURR_DAY = '00' THEN
			   
			   RETURN NULL;
			   
			ELSE
			   
			   RETURN TRIM(P_YMDHM);
			   
			END IF;
				
	   END FU_GET_VALID_YMDHM;