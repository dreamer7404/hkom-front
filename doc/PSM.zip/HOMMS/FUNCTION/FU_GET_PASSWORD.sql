CREATE OR REPLACE FUNCTION FU_GET_PASSWORD (USERID VARCHAR2, PASSWD VARCHAR2)
   RETURN VARCHAR2
IS
   HASHEDPASSWD   VARCHAR2(30);

BEGIN
   SELECT LTRIM (TO_CHAR (DBMS_UTILITY.GET_HASH_VALUE (   UPPER (USERID)
                                                       || '/'
                                                       || PASSWD,
                                                       1000000000,
                                                       POWER (2, 30)
                                                      ),
                          RPAD ('X', 29, 'X') || ('X')
                         )
                )
     INTO HASHEDPASSWD
     FROM DUAL;

   RETURN HASHEDPASSWD;
EXCEPTION
   WHEN NO_DATA_FOUND
   THEN
      NULL;
   WHEN OTHERS
   THEN
      -- Consider logging the error and then re-raise
      RAISE;
END FU_GET_PASSWORD;