CREATE OR REPLACE 
	  --[추가].2010.04.20.김동근 공장별 2주생산계획을 문자형태로 리턴
	  FUNCTION FU_GET_PLNT_WEK2_PLAN_QTY(P_CURR_YMD   VARCHAR2,
  		   					             P_VEHL_CD    VARCHAR2,
							             P_MDL_MDY_CD VARCHAR2,
							             P_LANG_CD	   VARCHAR2) RETURN VARCHAR2
	  IS
	  	CURSOR WEK2_PLAN_LIST IS SELECT QLTY_VEHL_CD, TRIM(TO_CHAR(WEK2_PLAN_QTY, '99,999,999')) AS WEK2_PLAN_QTY,
			   				  	 		PLNT_NM
								 FROM (SELECT TRIM(B.QLTY_VEHL_CD) QLTY_VEHL_CD, NVL(A.WEK2_PRDN_PLN_QTY, 0) + NVL(A.TDD_PRDN_QTY3, 0) AS WEK2_PLAN_QTY,
								 	  		  PLNT_NM
	   	                               FROM TB_PLNT_APS_PROD_SUM_INFO A,
								            TB_PLNT_VEHL_MGMT B
                                       WHERE A.APL_YMD(+) = P_CURR_YMD
								 	   AND A.QLTY_VEHL_CD(+) = P_VEHL_CD
								 	   AND A.MDL_MDY_CD(+) = P_MDL_MDY_CD
								 	   AND A.LANG_CD(+) = P_LANG_CD
								 	   AND A.QLTY_VEHL_CD(+) = B.QLTY_VEHL_CD
								 	   AND A.PRDN_PLNT_CD(+) = B.PRDN_PLNT_CD
								 	   ORDER BY B.SORT_SN
									  )
								 --값이 없는 항목도 표시하도록 한다. 
								 --WHERE WEK2_PLAN_QTY > 0
								 ;
								 
		V_WEK2_LIST VARCHAR2(8000);
		V_FLAG      CHAR(1);
		
	  BEGIN
	  	   --[주의] 2010.05.11.김동근 TB_PLNT_APS_PROD_SUM_INFO 테이블에 공장별 데이터가 하나도 존재하지 않는 차종의 경우(예를 들어 AM 차종의 11MY, PE 언어에 해당하는 광주 1, 2공장 내역이 아예 존재하지 않는는 경우)에는
		   --                         TB_PLNT_VEHL_MGMT 테이블에 지정되어 있다고 하더라도 화면에서 보여지지 않게 된다.('0' 으로 표시됨) 
		   --						  그래서 통일성을 주기 위하여 계획수량이 없는(각 공장 모두 '0' 인) 경우에는 빈문자로 표시되도록 한다. 
		   V_WEK2_LIST := '';
		   V_FLAG      := '0';
		   
		   FOR PLAN_LIST IN WEK2_PLAN_LIST LOOP
			   
			   IF PLAN_LIST.WEK2_PLAN_QTY <> '0' THEN
			   	  
				  V_FLAG := '1';
				  
			   END IF;
			   
		   	   --V_WEK2_LIST := V_WEK2_LIST || PLAN_LIST.PLNT_NM || ': ' || PLAN_LIST.WEK2_PLAN_QTY || '|';
               IF PLAN_LIST.QLTY_VEHL_CD = P_VEHL_CD THEN
			        V_WEK2_LIST := V_WEK2_LIST || PLAN_LIST.WEK2_PLAN_QTY || '/';
               END IF;
			
		   END LOOP;
		   
		   IF V_FLAG = '0' THEN
		   	  
			  V_WEK2_LIST := '';
			  
		   ELSE
		   	   IF LENGTH(V_WEK2_LIST) > 0 THEN
		   
		   	   	  V_WEK2_LIST := SUBSTR(V_WEK2_LIST, 1, LENGTH(V_WEK2_LIST) - 1);
		   
		   	   END IF;
		   
		   END IF;
		   
		   RETURN V_WEK2_LIST;
		
	  END FU_GET_PLNT_WEK2_PLAN_QTY;	