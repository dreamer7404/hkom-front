CREATE OR REPLACE 
	  --PDI 차종연식에 소속된 취급설명서 연식의 재고수량을 이전연식부터 문자형태로 표현해서 리턴하는 함수 								
  	  FUNCTION FU_GET_PDI_IV_TEXT(P_CURR_YMD   VARCHAR2,
  		   					      P_VEHL_CD    VARCHAR2,
							  	  P_MDL_MDY_CD VARCHAR2,
							  	  P_LANG_CD	   VARCHAR2) RETURN VARCHAR2
	  IS
	  
	  	V_IV_QTY_TEXT VARCHAR2(100);
		
		CURSOR PDI_IV_DTL_LIST_INFO IS SELECT DL_EXPD_MDL_MDY_CD,
			   						  	      CASE WHEN DL_EXPD_MDL_MDY_CD = P_MDL_MDY_CD THEN SUM(IV_QTY) ELSE SUM(SFTY_IV_QTY) END AS IV_QTY,
											  CASE WHEN DL_EXPD_MDL_MDY_CD = P_MDL_MDY_CD THEN SUM(SFTY_IV_QTY - IV_QTY) ELSE 0 END AS SFTY_IV_QTY
           							   FROM TB_PDI_IV_INFO_DTL
		   							   WHERE CLS_YMD = P_CURR_YMD
		   							   AND QLTY_VEHL_CD = P_VEHL_CD
		   							   AND MDL_MDY_CD = P_MDL_MDY_CD
		   							   AND LANG_CD = P_LANG_CD
           							   GROUP BY DL_EXPD_MDL_MDY_CD;
										 
	  BEGIN
	  	   
		   V_IV_QTY_TEXT := '';
		   
		   FOR PDI_IV_DTL_LIST IN PDI_IV_DTL_LIST_INFO LOOP
		   	   
			   IF PDI_IV_DTL_LIST.IV_QTY > 0 THEN
			   	  
				  V_IV_QTY_TEXT := V_IV_QTY_TEXT || 
				  				   PDI_IV_DTL_LIST.DL_EXPD_MDL_MDY_CD || 'MY:' || 
								   TRIM(TO_CHAR(PDI_IV_DTL_LIST.IV_QTY, '999,999,999')) || 
								   CASE WHEN PDI_IV_DTL_LIST.SFTY_IV_QTY < 0 THEN '(타연식:' || TRIM(TO_CHAR(PDI_IV_DTL_LIST.SFTY_IV_QTY, '999,999,999')) || ')' ELSE '' END || ' ';
				  
			   END IF;
			   
		   END LOOP;
		   
		   IF LENGTH(V_IV_QTY_TEXT) > 0 THEN
			   
			   	  V_IV_QTY_TEXT := SUBSTR(V_IV_QTY_TEXT, 1, LENGTH(V_IV_QTY_TEXT) - 1);
		    
		   END IF;
		   	
		   RETURN V_IV_QTY_TEXT;
		   
	  END FU_GET_PDI_IV_TEXT;