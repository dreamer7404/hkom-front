CREATE OR REPLACE PACKAGE HOMMS_ADM.PG_USR_LOGIN
AS
   TYPE REFCUR IS REF CURSOR;

   -- 사용자별 로그인
   PROCEDURE SP_USR_LOGIN (P_USER_EENO   IN     TB_USR_MGMT.USER_EENO%TYPE,
                           P_USER_PW     IN     TB_USR_MGMT.USER_PW%TYPE,
                           RS               OUT REFCUR);

   -- 사용자별 로그인
   PROCEDURE SP_USR_LOGIN_N (
      P_USER_EENO      IN     TB_USR_MGMT.USER_EENO%TYPE,
      P_USER_PW        IN     TB_USR_MGMT.USER_PW%TYPE,
      P_USER_SHA_PWD   IN     TB_USR_MGMT.USER_PW%TYPE,
      P_USER_IP_ADR    IN     VARCHAR2,
      P_USER_HOST      IN     VARCHAR2,
      RS                  OUT REFCUR);

   -- 사용자별 로그인
   PROCEDURE SP_USR_LOGIN_N2 (
      P_USER_EENO      IN     TB_USR_MGMT.USER_EENO%TYPE,
      P_USER_PW        IN     TB_USR_MGMT.USER_PW%TYPE,
      P_USER_SHA_PWD   IN     TB_USR_MGMT.USER_PW%TYPE,
      P_USER_IP_ADR    IN     VARCHAR2,
      P_USER_HOST      IN     VARCHAR2,
      RS                  OUT REFCUR);

   -- 사용자별 로그인
   PROCEDURE SP_USR_LOGIN_N3 (
      P_USER_EENO      IN     TB_USR_MGMT.USER_EENO%TYPE,
      P_USER_PW        IN     TB_USR_MGMT.USER_PW%TYPE,
      P_USER_SHA_PWD   IN     TB_USR_MGMT.USER_PW%TYPE,
      P_USER_IP_ADR    IN     VARCHAR2,
      P_USER_HOST      IN     VARCHAR2,
      P_SESS_ID        IN     VARCHAR2,
      RS                  OUT REFCUR);

   PROCEDURE SP_UPDATE_USR_USE_YN;

   -- 사용자 로그아웃 기록 추가
   PROCEDURE SP_USR_LOGOUT (
      P_SESS_ID        IN     VARCHAR2,
      P_LGO_TYPE       IN     TB_LGI_LOG.LGO_TYPE%TYPE);
END PG_USR_LOGIN;