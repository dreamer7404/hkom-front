CREATE OR REPLACE PACKAGE PG_SFTY_IV_MGMT AS
  TYPE REFCUR IS REF CURSOR;
  
  /**
  -- 안전재고관리 조건정보검색
  PROCEDURE SP_SFTY_IV_MGMT_LIST(P_DL_EXPD_PRVS_CD IN VARCHAR2,
                                 P_DL_EXPD_PAC_SCN_CD IN VARCHAR2,
                                 P_DL_EXPD_PDI_CD IN VARCHAR2,
                                 P_UPDR_EENO IN VARCHAR2,
                                 RS OUT REFCUR);
  **/
  					 
  -- 안전재고관리 조건정보검색2 
  PROCEDURE SP_SFTY_IV_MGMT_LIST2(P_MENU_ID 		   VARCHAR2,
							  	  P_USER_EENO 	       VARCHAR2,
  								  P_DL_EXPD_PRVS_CD    IN VARCHAR2,
                                  P_DL_EXPD_PAC_SCN_CD IN VARCHAR2,
                                  P_DL_EXPD_PDI_CD     IN VARCHAR2,
                                  P_UPDR_EENO          IN VARCHAR2,
                                  RS OUT REFCUR);
  
  -- 안전재고관리 정보입력
  PROCEDURE SP_INSERT(P_QLTY_VEHL_CD IN VARCHAR2,
                      P_MDL_MDY_CD IN VARCHAR2,
                      P_LANG_CD IN VARCHAR2,             
                      P_DSID141_QTY IN NUMBER,
                      P_DSID31_QTY IN NUMBER,
                      P_USE_YN IN VARCHAR2,
                      P_PPRR_EENO IN VARCHAR2,
                      P_UPDR_EENO IN VARCHAR2);  
  
  -- 안전재고관리 수정내용검색
  PROCEDURE SP_UPDATE_VIEW(P_QLTY_VEHL_CD IN VARCHAR2,
                           P_MDL_MDY_CD IN VARCHAR2,
                           P_LANG_CD IN VARCHAR2,
                           RS OUT REFCUR); 
                           
   -- 안전재고관리 정보수정                        
   PROCEDURE SP_UPDATE(P_QLTY_VEHL_CD IN VARCHAR2,
                       P_MDL_MDY_CD IN VARCHAR2,
                       P_LANG_CD IN VARCHAR2,
                       P_DSID141_QTY IN NUMBER,
                       P_DSID31_QTY IN NUMBER,
                       P_USE_YN IN VARCHAR2,
                       P_UPDR_EENO IN VARCHAR2);                          
  
  -- 안전재고관리 정보삭제(사용안함)
  PROCEDURE SP_DELETE(P_QLTY_VEHL_CD IN VARCHAR2,
                      P_MDL_MDY_CD IN VARCHAR2,
                      P_LANG_CD IN VARCHAR2);
                      
  -- 안전재고관리 정보삭제(실제삭제)
  PROCEDURE SP_REAL_DELETE(P_QLTY_VEHL_CD IN VARCHAR2,
                           P_MDL_MDY_CD IN VARCHAR2,
                           P_LANG_CD IN VARCHAR2);
                      
END PG_SFTY_IV_MGMT;