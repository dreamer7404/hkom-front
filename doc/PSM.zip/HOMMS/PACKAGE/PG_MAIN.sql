CREATE OR REPLACE PACKAGE PG_MAIN AS
       
       TYPE REFCUR IS REF CURSOR;
	   
       --업무현황 조회 
       PROCEDURE SP_GET_USR_BUSINESS_INFO(P_MENU_ID    VARCHAR2,
                                          P_USER_EENO  VARCHAR2,
                                          P_CURR_YMD   VARCHAR2,
                                          RS          OUT REFCUR);
       
       --발주의뢰 건수 조회(외부에서 호출하지 말것)                                       
       PROCEDURE SP_GET_REQ_PARR_INFO(P_MENU_ID      VARCHAR2,
                                      P_USER_EENO    VARCHAR2,
                                      P_USER_DCD     VARCHAR2,
                                      P_CURR_YMD     VARCHAR2,
                                      P_FROM_MDL_MDY VARCHAR,
                                      P_TO_MDL_MDY   VARCHAR,
                                      P_USER_REQ_QTY OUT NUMBER,
                                      P_DEPT_REQ_QTY OUT NUMBER);
                                      
       --발주승인 건수 조회(외부에서 호출하지 말것) 
       PROCEDURE SP_GET_REQ_APVL_INFO(P_USER_EENO     VARCHAR2,
                                      P_USER_DCD      VARCHAR2,
                                      P_CURR_YMD      VARCHAR2,
                                      P_FROM_MDL_MDY  VARCHAR,
                                      P_TO_MDL_MDY    VARCHAR,
                                      P_USER_APVL_QTY OUT NUMBER,
                                      P_DEPT_APVL_QTY OUT NUMBER);
       
       --세화출고예정 건수 조회(외부에서 호출하지 말것) 
       PROCEDURE SP_GET_SEWHA_WHOT_INFO(P_MENU_ID       VARCHAR2,
                                        P_USER_EENO     VARCHAR2,
                                        P_USER_DCD      VARCHAR2,
                                        P_CURR_YMD      VARCHAR2,
                                        P_FROM_MDL_MDY  VARCHAR,
                                        P_TO_MDL_MDY    VARCHAR,
                                        P_USER_WHOT_QTY OUT NUMBER,
                                        P_DEPT_WHOT_QTY OUT NUMBER);
       
       --PDI 입고확인 건수 조회(외부에서 호출하지 말것)
       PROCEDURE SP_GET_PDI_WHSN_INFO(P_MENU_ID       VARCHAR2,
                                      P_USER_EENO     VARCHAR2,
                                      P_USER_DCD      VARCHAR2,
                                      P_CURR_YMD      VARCHAR2,
                                      P_FROM_MDL_MDY  VARCHAR,
                                      P_TO_MDL_MDY    VARCHAR,
                                      P_USER_WHSN_QTY OUT NUMBER,
                                      P_DEPT_WHSN_QTY OUT NUMBER);
       
       --글로비스 입고확인 건수 조회(외부에서 호출하지 말것) 
       PROCEDURE SP_GET_GLOVIS_WHSN_INFO(P_MENU_ID       VARCHAR2,
                                         P_USER_EENO     VARCHAR2,
                                         P_USER_DCD      VARCHAR2,
                                         P_CURR_YMD      VARCHAR2,
                                         P_FROM_MDL_MDY  VARCHAR,
                                         P_TO_MDL_MDY    VARCHAR,
                                         P_USER_WHSN_QTY OUT NUMBER,
                                         P_DEPT_WHSN_QTY OUT NUMBER);
										 
	   PROCEDURE SP_GET_MENU_LIST(P_USER_EENO VARCHAR2,
	                              RS OUT REFCUR);
	   									                                          
       PROCEDURE SP_GET_FULL_MENU_LIST(P_USER_EENO VARCHAR2,
                                  RS OUT REFCUR);

       -- 비밀번호 변경 경과 일자 조회
       PROCEDURE SP_GET_PW_ALTR_DAY_CNT(P_USER_EENO VARCHAR2,
                                  P_DAY_CNT OUT INT);
       -- 사용자 정보 조회 
       PROCEDURE SP_USER_INFO(P_USER_EENO VARCHAR2, 
                              RS      OUT REFCUR);
       
       -- 사용자 정보 수정  
       PROCEDURE SP_USER_EDIT(P_USER_EENO    VARCHAR2,
                              P_USER_DCD     VARCHAR2,
                              P_USER_EML_ADR VARCHAR2,
                              P_USER_PW      VARCHAR2);
       
       -- 사용자 정보 수정  
       PROCEDURE SP_USER_EDIT_N(P_USER_EENO    VARCHAR2,
                              P_USER_DCD     VARCHAR2,
                              P_USER_EML_ADR VARCHAR2,
                              P_USER_PW      VARCHAR2,
                              P_USER_CHG_PW	VARCHAR2);

       -- 사용자 정보 수정  
       PROCEDURE SP_USER_EDIT_N2(P_USER_EENO    VARCHAR2,
                              P_USER_DCD     VARCHAR2,
                              P_USER_EML_ADR VARCHAR2,
                              P_USER_PW      VARCHAR2,
                              P_USER_CHG_PW    VARCHAR2);

       -- 메인 게시판 조회(TOP 5) 
       PROCEDURE SP_BOARD_TOP5(P_USER_DCD VARCHAR2, 
                               RS     OUT REFCUR);
       
       -- 메인 팝업 게시판 조회(TOP 1) 
       PROCEDURE SP_BOARD_POP(P_USER_DCD VARCHAR2, 
                              P_SCRN_SN OUT INT);
                              
END PG_MAIN;