CREATE OR REPLACE PACKAGE PG_BOARD_MGMT AS

    TYPE REFCUR IS REF CURSOR;
               
        -- 게시판 조회 
        PROCEDURE SP_BOARD_SEARCH(P_AFFR_SCN_CD CHAR,
                                  P_BLC_TITL_NM VARCHAR2,
                                  RS OUT REFCUR);      
        
        -- 게시판 상세 
        PROCEDURE SP_BOARD_VIEW(P_SCRN_SN NUMBER, 
                                RS OUT REFCUR);                                                 
        
        -- 게시대상 목록 
        PROCEDURE SP_SUBJ_LIST(P_SCRN_SN NUMBER, 
                                RS OUT REFCUR);   
                                                            
        -- 게시판 등록, 수정 
        PROCEDURE SP_BOARD_INSERT(P_SCRN_SN      NUMBER,
                                  P_AFFR_SCN_CD  VARCHAR2,
                                  P_RGN_EENO     CHAR,    
                                  P_BLC_TITL_NM  VARCHAR2,   
                                  P_BLC_SBC      CLOB,   
                                  P_ATTC_YN      CHAR,   
                                  P_N1AFP2_ADR   VARCHAR2,
                                  P_BUL_STRT_YMD VARCHAR2,
                                  P_BUL_FNH_YMD  VARCHAR2,
                                  P_BUL_YN       CHAR,
                                  P_RE_SCRN_SN OUT NUMBER);
        -- 게시대상 등록
        PROCEDURE SP_SUBJ_INSERT(P_SCRN_SN     NUMBER,
                                 P_RGN_EENO    CHAR, 
                                 P_BUL_SUBJ_CD VARCHAR2);
                                  
        -- 게시판 삭제 
        PROCEDURE SP_BOARD_DELETE(P_SCRN_SN NUMBER);
        
        -- 게시대상 삭제 
        PROCEDURE SP_SUBJ_DELETE(P_SCRN_SN NUMBER);
        

END PG_BOARD_MGMT;