CREATE OR REPLACE PACKAGE PG_CODE_MGMT AS

	TYPE REFCUR IS REF CURSOR;
               
        -- 항목명으로 그룹코드 검색
        PROCEDURE SP_GCODE_SEARCH(EXPD_PRVS_NM IN TB_CODE_MGMT.DL_EXPD_PRVS_CD%TYPE,
                                  RS OUT REFCUR);      
        
	-- 코드값에 의한 조회
        PROCEDURE SP_CODE_MGMT_LIST(EXPD_G_CD IN TB_CODE_MGMT.DL_EXPD_G_CD%TYPE,
                                    RS OUT REFCUR);                                                 
                                    
        -- 시스템코드 조건정보검색(전체검색포함)
        PROCEDURE SP_SC_MGMT_LIST(EXPD_G_CD IN TB_CODE_MGMT.DL_EXPD_G_CD%TYPE,
                                  EXPD_PRVS_CD IN TB_CODE_MGMT.DL_EXPD_PRVS_CD%TYPE,
                                  YN IN TB_CODE_MGMT.USE_YN%TYPE,                                
                                  RS OUT REFCUR);
        
        -- 그룹코드값에 의한 조회
        PROCEDURE SP_CODE_GRP_MGMT_SELECT(EXPD_G_CD IN TB_CODE_MGMT.DL_EXPD_G_CD%TYPE,
                                          RS OUT REFCUR);

	-- 코드값등록
	PROCEDURE SP_CODE_MGMT_INSERT(DL_EXPD_G_CD IN TB_CODE_MGMT.DL_EXPD_G_CD%TYPE, 
                                      DL_EXPD_PRVS_CD IN TB_CODE_MGMT.DL_EXPD_PRVS_CD%TYPE, 
                                      DL_EXPD_PRVS_NM IN TB_CODE_MGMT.DL_EXPD_PRVS_NM%TYPE, 
                                      SORT_SN IN TB_CODE_MGMT.SORT_SN%TYPE, 
                                      USE_YN IN TB_CODE_MGMT.USE_YN%TYPE, 
                                      PPRR_EENO IN TB_CODE_MGMT.PPRR_EENO%TYPE,
                                      UPDR_EENO IN TB_CODE_MGMT.UPDR_EENO%TYPE);

        -- 수정할 값을 구함
        PROCEDURE SP_UPDATE_VALUE(EXPD_G_CD IN TB_CODE_MGMT.DL_EXPD_G_CD%TYPE,
                                  EXPD_PRVS_CD IN TB_CODE_MGMT.DL_EXPD_PRVS_CD%TYPE,
                                  RS OUT REFCUR);         
        
	-- 코드,항목내용수정
	PROCEDURE SP_CODE_MGMT_UPDATE(EXPD_G_CD IN TB_CODE_MGMT.DL_EXPD_G_CD%TYPE, 
                                      EXPD_G_NM IN TB_CODE_GRP_MGMT.DL_EXPD_G_NM%TYPE,
                                      EXPD_PRVS_CD IN TB_CODE_MGMT.DL_EXPD_PRVS_CD%TYPE, 
                                      EXPD_PRVS_NM IN TB_CODE_MGMT.DL_EXPD_PRVS_NM%TYPE, 
                                      SN IN TB_CODE_MGMT.SORT_SN%TYPE, 
                                      YN IN TB_CODE_MGMT.USE_YN%TYPE,
                                      EENO IN TB_CODE_MGMT.UPDR_EENO%TYPE);
                                      
        -- 코드관리 사용여부 선택
        PROCEDURE SP_CODE_MGMT_DELETE(EXPD_G_CD IN TB_CODE_MGMT.DL_EXPD_G_CD%TYPE,
                                      EXPD_PRVS_CD IN TB_CODE_MGMT.DL_EXPD_PRVS_CD%TYPE);
                                      
        -- 대분류 중복 판별
        PROCEDURE SP_GCODE_FLAG(P_DL_EXPD_G_CD IN VARCHAR2,
                                RS OUT REFCUR);
                                
        -- 소분류 중복 판별 
        PROCEDURE SP_CODE_FLAG(P_DL_EXPD_G_CD IN VARCHAR2,
                               P_DL_EXPD_PRVS_CD IN VARCHAR2,
                               RS OUT REFCUR);
                              
END PG_CODE_MGMT;