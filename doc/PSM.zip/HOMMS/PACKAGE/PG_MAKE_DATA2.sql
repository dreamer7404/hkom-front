CREATE OR REPLACE PACKAGE PG_MAKE_DATA2 AS
 
    PROCEDURE CREATE_USER_INFO_EXCEL;
    
    PROCEDURE CREATE_USER_AFFR_AUTH(P_USER_EENO    CHAR,
                                    P_MENU_ID      VARCHAR2,
                                    P_INP_VEHLS    VARCHAR2, 
                                    P_IQ_VEHLS     VARCHAR2,
                                    P_USER_EENO2   CHAR);
                                    
    PROCEDURE CREATE_USER_VEHL_AUTH(P_USER_EENO    CHAR,
                                    P_MENU_ID      VARCHAR2,
                                    P_INP_VEHLS    VARCHAR2, 
                                    P_IQ_VEHLS     VARCHAR2,
                                    P_USER_EENO2   CHAR);
    
    --권한정보만을 재설정 하기 위해 사용[외부호출] 
    PROCEDURE SP_RESET_USER_AUTH(P_USER_EENO    CHAR,
                                 P_MENU_ID      VARCHAR2,
                                 P_INP_VEHLS    VARCHAR2, 
                                 P_IQ_VEHLS     VARCHAR2);
                                 
    --사용자 권한 정보 복사 기능 수행[외부호출]                                  
    PROCEDURE SP_COPY_USER_AUTH(P_ORIGINAL_USER_EENO CHAR,
                                P_TARGET_USER_EENO   CHAR);

    --차종 담당자별 권한 추가 수행
    --(본사, 경진 담당자로 지정되어 있는 차종에서 입력권한 설정되어 있지 않는 항목 입력권한으로 추가함)
    PROCEDURE SP_ADD_CRGR_USER_AUTH;
    PROCEDURE SP_ADD_CRGR_USER_AUTH_DTL(P_USER_EENO    VARCHAR2,
                                        P_QLTY_VEHL_CD VARCHAR2);
                                                                       
	/**
	--법규및변경관리 변경번호 변경 작업 								
	PROCEDURE SP_UPDATE_CHKLIST_INFO;
    **/
	
END PG_MAKE_DATA2;