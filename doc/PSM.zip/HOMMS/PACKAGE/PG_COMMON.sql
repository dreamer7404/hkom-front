CREATE OR REPLACE PACKAGE PG_COMMON AS

   TYPE REFCUR IS REF CURSOR;
   
   TYPE LIST_TYPE IS TABLE OF VARCHAR(100)
   INDEX BY BINARY_INTEGER;
								   
   -- 조회날짜에 따라 유효한 MIN 연식코드, MAX연식코드를 조회 
   PROCEDURE SP_GET_VALID_MDL_MDY1(P_SEARCH_DATE IN VARCHAR2, 
                                   RS OUT REFCUR);
						
   -- 조회날짜(From ~ To)에 따라 유효한 MIN 연식코드, MAX연식코드를 조회                    		  
   PROCEDURE SP_GET_VALID_MDL_MDY2(P_FROM_DATE IN VARCHAR2,
                                   P_TO_DATE   IN VARCHAR2, 
                                   RS OUT REFCUR);
   
   -- 조회날짜에 따라 유효한 연식코드의 리스트를 조회 								   
   PROCEDURE SP_GET_VALID_MDL_MDY3(P_SEARCH_DATE IN VARCHAR2, 
                                   RS OUT REFCUR);	
   
   PROCEDURE SP_GET_VALID_MDL_MDY4(P_FROM_DATE     IN VARCHAR2,
   			 					   P_TO_DATE       IN VARCHAR2,
								   P_FROM_MDL_MDY OUT VARCHAR2,
                                   P_TO_MDL_MDY   OUT VARCHAR2);
   	   					   
   -- 사용자 권한에 소속된 회사 리스트 조회 
   PROCEDURE SP_GET_EXPD_CO_INFO(P_FROM_YMD 	VARCHAR2,
   			 					 P_TO_YMD		VARCHAR2,
   			 					 P_MENU_ID 	    VARCHAR2,
							     P_USER_EENO    VARCHAR2,
						         P_USF_CD	    VARCHAR2,  -- A : 전체, D: 내수만, E: 수출만 조회, T : 권한구분없이 데이터 조회   
							     RS OUT REFCUR);
   
   -- 사용자 권한에 소속된 승상구분 리스트 조회 						
   PROCEDURE SP_GET_PAC_SCN_INFO(P_FROM_YMD 	VARCHAR2,
   			 					 P_TO_YMD		VARCHAR2,
   			 					 P_MENU_ID 	    VARCHAR2,
							     P_USER_EENO 	VARCHAR2,
								 P_EXPD_CO_CD   VARCHAR2,
								 P_USF_CD		VARCHAR2,  -- A : 전체, D: 내수만, E: 수출만 조회, T : 권한구분없이 데이터 조회   
							     RS OUT REFCUR);
								 
   -- 사용자권한에 소속된 PDI 리스트 조회
   PROCEDURE SP_GET_PDI_INFO(P_FROM_YMD 	VARCHAR2,
   			 				 P_TO_YMD		VARCHAR2,
   			 				 P_MENU_ID 	    VARCHAR2,
							 P_USER_EENO 	VARCHAR2,
							 P_EXPD_CO_CD   VARCHAR2,
						     P_PAC_SCN_CD   VARCHAR2,
						     P_USF_CD		VARCHAR2,  -- A : 전체, D: 내수만, E: 수출만 조회, T : 권한구분없이 데이터 조회   
							 RS OUT REFCUR);
							 
   -- 사용자권한에 소속된 차종 리스트 조회
   PROCEDURE SP_GET_VEHL_INFO(P_FROM_YMD 	 VARCHAR2,
   			 				  P_TO_YMD		 VARCHAR2,
                              P_MENU_ID 	 VARCHAR2,
							  P_USER_EENO 	 VARCHAR2,
							  P_EXPD_CO_CD   VARCHAR2,
						      P_PAC_SCN_CD   VARCHAR2,
							  P_PDI_CD		 VARCHAR2,
							  P_USF_CD		 VARCHAR2,  -- A : 전체, D: 내수만, E: 수출만 조회, T : 권한구분없이 데이터 조회   
							  RS OUT REFCUR);
							  
   -- 사용자권한에 소속된 연식 리스트 조회
   PROCEDURE SP_GET_MDL_MDY_INFO(P_FROM_YMD 	VARCHAR2,
   			 					 P_TO_YMD		VARCHAR2,
   			 					 P_MENU_ID 	    VARCHAR2,
							     P_USER_EENO 	VARCHAR2,
								 P_EXPD_CO_CD   VARCHAR2,
						         P_PAC_SCN_CD   VARCHAR2,
							     P_PDI_CD		VARCHAR2,
							     P_VEHL_CD		VARCHAR2,
							     P_USF_CD		VARCHAR2,  -- A : 전체, D: 내수만, E: 수출만 조회, T : 권한구분없이 데이터 조회     
							     RS OUT REFCUR);		
							  							 
   -- 사용자권한에 소속된 지역 리스트 조회
   /**
   PROCEDURE SP_GET_REGN_INFO(P_FROM_YMD 	 VARCHAR2,
   			 				  P_TO_YMD		 VARCHAR2,
   			 				  P_MENU_ID 	 VARCHAR2,
				              P_USER_EENO 	 VARCHAR2,
							  P_EXPD_CO_CD   VARCHAR2,
						      P_PAC_SCN_CD   VARCHAR2,
				              P_PDI_CD		 VARCHAR2,
						      P_VEHL_CD	     VARCHAR2,
						      P_USF_CD		 VARCHAR2,  -- A : 전체, D: 내수만, E: 수출만 조회  
				              RS OUT REFCUR);
   **/
   PROCEDURE SP_GET_REGN_INFO(P_FROM_YMD 	 VARCHAR2,
   			 				  P_TO_YMD		 VARCHAR2,
   			 				  P_MENU_ID 	 VARCHAR2,
				              P_USER_EENO 	 VARCHAR2,
							  P_EXPD_CO_CD   VARCHAR2,
						      P_PAC_SCN_CD   VARCHAR2,
				              P_PDI_CD		 VARCHAR2,
						      P_VEHL_CD	     VARCHAR2,
						      P_MDL_MDY_CD   VARCHAR2,
						      P_USF_CD		 VARCHAR2,  -- A : 전체, D: 내수만, E: 수출만 조회, T : 권한구분없이 데이터 조회      
				              RS OUT REFCUR); 
							  						
   -- 사용자권한에 소속된 언어 리스트 조회
   /**
   PROCEDURE SP_GET_LANG_INFO(P_FROM_YMD 	 VARCHAR2,
   			 				  P_TO_YMD		 VARCHAR2,
   			 				  P_MENU_ID 	 VARCHAR2,
							  P_USER_EENO 	 VARCHAR2,
							  P_EXPD_CO_CD   VARCHAR2,
						      P_PAC_SCN_CD   VARCHAR2,
							  P_PDI_CD		 VARCHAR2,
							  P_VEHL_CD	     VARCHAR2,
							  P_REGN_CD	     VARCHAR2,
							  P_USF_CD		 VARCHAR2,  -- A : 전체, D: 내수만, E: 수출만 조회
							  RS OUT REFCUR); 
   **/
   PROCEDURE SP_GET_LANG_INFO(P_FROM_YMD 	 VARCHAR2,
   			 				  P_TO_YMD		 VARCHAR2,
   			 				  P_MENU_ID 	 VARCHAR2,
							  P_USER_EENO 	 VARCHAR2,
							  P_EXPD_CO_CD   VARCHAR2,
						      P_PAC_SCN_CD   VARCHAR2,
							  P_PDI_CD		 VARCHAR2,
							  P_VEHL_CD	     VARCHAR2,
							  P_MDL_MDY_CD   VARCHAR2,
							  P_REGN_CD	     VARCHAR2,
							  P_USF_CD		 VARCHAR2,  -- A : 전체, D: 내수만, E: 수출만 조회, T : 권한구분없이 데이터 조회
							  RS OUT REFCUR); 
   
   --해당 프로그램에 수정권한 차종이 존재하는지의 여부를 확인 
   PROCEDURE SP_GET_AUTHORITY_YN(P_MENU_ID 	 VARCHAR2,
							     P_USER_EENO VARCHAR2,
								 P_CHECK_YN OUT VARCHAR2);
								 
   --코드그룹 리스트를 가져온다.
   PROCEDURE SP_GET_CODE_GRP_LIST(RS OUT REFCUR);
  
   --그룹코드에 해당하는 코드항목의 리스트를 가져온다.							  
   PROCEDURE SP_GET_CODE_LIST(P_EXPD_G_CD IN TB_CODE_MGMT.DL_EXPD_G_CD%TYPE,
                              RS OUT REFCUR);
							 			   			
   --사용자 정보 조회 
   PROCEDURE SP_GET_USR_LIST(RS OUT REFCUR);
   
   --사용자 정보 조회2 
   PROCEDURE SP_GET_USR_LIST2(P_BLNS_CO_CD IN TB_USR_MGMT.BLNS_CO_CD%TYPE,
                              RS OUT REFCUR);
  
   --차종 담당자 정보 조회 
   PROCEDURE SP_GET_VEHL_USR_LIST(P_VEHL_CD    VARCHAR2,
  								  P_MDL_MDY_CD VARCHAR2,
								  P_BLNS_CO_CD VARCHAR2, --코드테이블의 그룹코드가 '0021' 인 항목 참고 
								  RS OUT REFCUR);	
   
    --차종 담당자 정보 조회(언어에 따른 PDI 또는 글로비스 차종담당자 리스트 조회)
   PROCEDURE SP_GET_VEHL_USR_LIST2(P_VEHL_CD    VARCHAR2,
  								   P_MDL_MDY_CD VARCHAR2,
								   P_LANG_CD    VARCHAR2,  
								   RS OUT REFCUR);
   
   --조회시에 차종코드에 관계된 APS, 생산마스터, BOM 차종을 가져오기 위한 함수 
   PROCEDURE SP_GET_PRDN_VEHL_LIST(P_QLTY_VEHL_CD VARCHAR2,
			 					   P_PRVS_SCN_CD  VARCHAR2, -- A: APS차종, B:생산마스터차종, C:BOM차종 (참고: 코드테이블 '0023')
								   P_VEHL_LIST	  OUT VARCHAR2
								  );
								  
   --조회시에 승상구분, PDI, 차종에 관계된 APS, 생산마스터, BOM 차종을 가져오기 위한 함수 
   PROCEDURE SP_GET_PRDN_VEHL_LIST2(P_PAC_SCN_CD   VARCHAR2,
							        P_PDI_CD	   VARCHAR2,
   			 					    P_QLTY_VEHL_CD VARCHAR2,
			 					    P_PRVS_SCN_CD  VARCHAR2, -- A: APS차종, B:생산마스터차종, C:BOM차종 (참고: 코드테이블 '0023')
								    P_VEHL_LIST	   OUT VARCHAR2
								   );
								   
   --품질차종이 아닌 다른 차종의 품질 차종 정보를 얻어오는 프로시저 								   
   PROCEDURE SP_GET_VEHL_CD_BY_PRDN(P_PRDN_VEHL_CD VARCHAR2,
                                    P_PRVS_SCN_CD  VARCHAR2, -- A: APS차종, B:생산마스터차종, C:BOM차종 (참고: 코드테이블 '0023')
								    P_VEHL_CD	   OUT VARCHAR2
                                   );
   --품질차종이 아닌 다른 차종의 품질 차종 정보를 얻어오는 프로시저(생산마스터 I/F 전용) 								   
   PROCEDURE SP_GET_VEHL_CD_BY_PRDN2(P_PRDN_VEHL_CD  VARCHAR2,
                                     P_PRVS_SCN_CD   VARCHAR2, -- A: APS차종, B:생산마스터차종, C:BOM차종 (참고: 코드테이블 '0023')
								     P_VEHL_CD	     OUT VARCHAR2,
									 P_PRDN2_VEHL_CD OUT VARCHAR2
                                    );
									 							 				 
   --현재 SYSTEM 날짜를 조회 								 
   PROCEDURE SP_GET_SYSDATE(P_SYSDATE OUT VARCHAR2);
   
   --현재날짜와 1주전 날짜를 리턴 	
   PROCEDURE SP_GET_SYSDATE2(P_SYSDATE  OUT VARCHAR2,
   			 				 P_PREVDATE OUT VARCHAR2);
   
   --현재날짜와 1주후 날짜를 리턴 							 
   PROCEDURE SP_GET_SYSDATE3(P_SYSDATE  OUT VARCHAR2,
                             P_NEXTDATE OUT VARCHAR2);
   
   --현재날짜와 기간 달 수만큼 경과한 날짜를 리턴 							 
   PROCEDURE SP_GET_SYSDATE4(P_DAY_CNT	IN NUMBER,
    		 				 P_PREVDATE OUT VARCHAR2,
                             P_NEXTDATE OUT VARCHAR2);
							 
   PROCEDURE SP_GET_DATEDIFF(P_FROM_MTH VARCHAR2,
   			 				 P_TO_MTH   VARCHAR2,
							 P_DIFFCNT  OUT VARCHAR2);
							 
   PROCEDURE SP_GET_DATELIST(P_FROM_MTH VARCHAR2,
   			 				 P_TO_MTH   VARCHAR2,
							 RS OUT REFCUR);
							 
   --사용자가 해당 메뉴 ID에서 가지는 권한 정보를 조회 		
   PROCEDURE SP_GET_AUTH_AFFR(P_MENU_ID   VARCHAR2,
							  P_USER_EENO VARCHAR2,
						      P_AUTH_CD	  OUT VARCHAR2);	
   --Split 함수 
   FUNCTION FU_SPLIT(P_LIST  VARCHAR2,
                     P_COUNT OUT BINARY_INTEGER) RETURN LIST_TYPE;
   
   --RPAD 함수 
   FUNCTION FU_RPAD(P_VALUE VARCHAR2,
   					P_LENGTH NUMBER) RETURN VARCHAR2;
   
   		
   FUNCTION FU_GET_VARCHAR_LIST(P_LIST VARCHAR2) RETURN VARCHAR2; 
   
   --P_CURR_YMD 날짜에서 P_CNT 갯수만큼 경과한 영업기준 일자를 리턴해 준다. 
   FUNCTION FU_GET_WRKDATE(P_CURR_YMD VARCHAR2,
   						   P_CNT	  NUMBER) RETURN VARCHAR2;

  --P_CURR_YMD 날짜에서 휴일을 고려한 하루 전 일자를 리턴해 준다.
	FUNCTION FU_GET_PRV1DAY_INCL_HOLIDAY(P_CURR_YMD VARCHAR2) RETURN VARCHAR2;

   
   --Date날짜를 한글 형태로 변경하여 리턴 
   FUNCTION FU_TO_LOCAL_DATE_CHAR(P_CURR_DATE DATE) RETURN VARCHAR2;
   
   --신인쇄발간번호를 이용하여 정렬처리 위한 문자열 생성 							   
   FUNCTION FU_GET_SORT_PBCN(P_N_PRNT_PBCN_NO IN VARCHAR2) RETURN VARCHAR2;
   				   
END PG_COMMON;