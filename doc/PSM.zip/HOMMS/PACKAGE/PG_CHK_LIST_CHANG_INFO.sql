CREATE OR REPLACE PACKAGE PG_CHK_LIST_CHANG_INFO AS
    
	TYPE REFCUR IS REF CURSOR;
        
    -- 체크리스트 변경상세정보 삭제
    PROCEDURE SP_CHKLIST_INFO_DEL(P_EXPD_ALTR_NO VARCHAR2,
                                  P_USER_EENO    VARCHAR2);
								  
	PROCEDURE SP_CHKLIST_INFO_DEL2(P_EXPD_ALTR_NO VARCHAR2,
			  					   P_VEHL_LIST	  VARCHAR2,
                                   P_USER_EENO    VARCHAR2);
          
    -- 체크리스트 변경상세정보 입력
    PROCEDURE SP_CHKLIST_INFO_SAVE(P_EXPD_ALTR_NO VARCHAR2,
                                   P_ALTR_YMD     VARCHAR2,
                                   P_RCPM_SHAP_CD VARCHAR2,
                                   P_DSPP_NM      VARCHAR2,
                                   P_CHGR_EENO    VARCHAR2,
                                   P_CRGR_NM      VARCHAR2,
                                   P_VEHL_LIST	  VARCHAR2,
                                   P_LANG_LIST    VARCHAR2,
                                   P_ALTR_SBC     VARCHAR2,
                                   P_USER_EENO    VARCHAR2);

    --법규및 변경관리에서 처리(저장)된 EO번호 내역을 보관					   								   
	PROCEDURE SP_CHKLIST_EONO_SAVE(P_EXPD_ALTR_NO VARCHAR2, 
			  					   P_ALTR_SBC     VARCHAR2,
								   P_USER_EENO    VARCHAR2);
	
	--법규및 변경관리 내역에 EO번호가 저장되어 있는지의 여부를 확인 
	--속도개선을 위하여 BOM 차종에 해당하는 품질차종코드를 같이 얻어온다.
	PROCEDURE SP_CHKLIST_EONO_EXIST(P_PRDN_VEHL_CD VARCHAR2,
                                    P_PRVS_SCN_CD  VARCHAR2, -- A: APS차종, B:생산마스터차종, C:BOM차종 (참고: 코드테이블 '0023') 
									P_EO_CD		   VARCHAR2,
									P_VEHL_CD	   OUT VARCHAR2,
			  						P_EXIST_YN     OUT VARCHAR2);
			
	--체크리스트 변경 내역 검색 
	PROCEDURE SP_GET_CHK_CHANG_LIST(P_MENU_ID 	      VARCHAR2,
									P_USER_EENO       VARCHAR2,
			  						P_FROM_YMD	      VARCHAR2,
                 					P_TO_YMD          VARCHAR2,
                					P_EXPD_CO_CD      VARCHAR2,
                					P_EXPD_PAC_SCN_CD VARCHAR2,
                					P_VEHL_CD	      VARCHAR2,	
                					P_CHANG_USER_EENO VARCHAR2,
									P_FROM_NUM        NUMBER,
									P_TO_NUM          NUMBER,
									P_CONTENT         VARCHAR2,
									P_EXPD_ALTR_NO    VARCHAR2,
									P_CNT OUT NUMBER,                                     
                                    RS    OUT REFCUR);
    
	--변경번호, 차종에 관계된  언어코드 리스트를 얻어오는 함수 
	FUNCTION FU_GET_LANG_LIST_BY_VEHL(P_EXPD_ALTR_NO TB_CHKLIST_DTL_INFO.DL_EXPD_ALTR_NO%TYPE,
			 		                  P_QLTY_VEHL_CD TB_CHKLIST_DTL_INFO.QLTY_VEHL_CD%TYPE)RETURN VARCHAR2;
	  
    --변경번호, 차종에 관계된  신인쇄발간코드 리스트를 얻어오는 함수 
	FUNCTION FU_GET_PBCN_LIST_BY_VEHL(P_EXPD_ALTR_NO TB_CHKLIST_DTL_INFO.DL_EXPD_ALTR_NO%TYPE,
			 		                  P_QLTY_VEHL_CD TB_CHKLIST_DTL_INFO.QLTY_VEHL_CD%TYPE)RETURN VARCHAR2;
	
	--현재의 사용자가 수정가능한 차종의 리스트를 조회(팝업화면용) 
	PROCEDURE SP_GET_VEHL_LIST(P_FROM_YMD    VARCHAR2,
                 			   P_TO_YMD      VARCHAR2,
				               RS OUT REFCUR);
	
	--현재의 사용자가 수정가능한 차종의 리스트를 조회(팝업화면용)2  
	PROCEDURE SP_GET_VEHL_LIST2(P_MENU_ID 	      VARCHAR2,
								P_USER_EENO       VARCHAR2,
			  					P_FROM_YMD        VARCHAR2,
                 			    P_TO_YMD          VARCHAR2,
							    P_EXPD_CO_CD      VARCHAR2,
                			    P_EXPD_PAC_SCN_CD VARCHAR2,
				                RS OUT REFCUR);
							   
	--현재 선택된 차종내역에 해당하는 언어코드 리스트를 조회(팝업화면용) 
	PROCEDURE SP_GET_LANG_LIST(P_FROM_YMD  VARCHAR2,
                 			   P_TO_YMD    VARCHAR2,
				               P_VEHL_LIST VARCHAR2,
				               RS OUT REFCUR);
	
	--조회화면 컬럼 헤더에 표시될 언어코드 리스트 조회 
	PROCEDURE SP_GET_HEADER_LANG_LIST(P_FROM_YMD   VARCHAR2,
                 					  P_TO_YMD     VARCHAR2,
					                  RS OUT REFCUR);  
	
    --체크리스트 파일이름 조회 
	PROCEDURE SP_GET_CHKLIST_FILE_NAME(P_DL_EXPD_ALTR_NO   VARCHAR2,
					                   P_N1AFP2_ADR    OUT VARCHAR2); 
                                       
     --체크리스트 파일이름 수정 
	PROCEDURE SP_CHKLIST_FILE_NAME_SAVE(P_DL_EXPD_ALTR_NO   VARCHAR2,
                                        P_N1AFP2_ADR VARCHAR2,
                                        P_N1AFP2_ADR1 VARCHAR2);
			                                         	   	  
END PG_CHK_LIST_CHANG_INFO;