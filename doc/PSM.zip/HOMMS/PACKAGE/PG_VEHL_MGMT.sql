CREATE OR REPLACE PACKAGE PG_VEHL_MGMT AS

	   TYPE REFCUR IS REF CURSOR;
	   
	   /**
	   --차종내역 조회
	   PROCEDURE SP_GET_VEHL_MGMT(RS OUT REFCUR);
	   **/
	   					  
	   PROCEDURE SP_GET_VEHL_MGMT2(P_EXPD_CO_CD VARCHAR2,
	                               P_PDI_CD	    VARCHAR2,
								   P_VEHL_CD	VARCHAR2,
								   P_MDL_MDY_CD VARCHAR2,
								   P_CRGR_EENO  VARCHAR2,
	                               RS OUT REFCUR);
								   
	   PROCEDURE SP_GET_VEHL_MGMT3(P_MENU_ID 	VARCHAR2,
							  	   P_USER_EENO 	VARCHAR2,
	   			 				   P_EXPD_CO_CD VARCHAR2,
								   P_PAC_SCN_CD VARCHAR2,
	                               P_PDI_CD	    VARCHAR2,
								   P_VEHL_CD	VARCHAR2,
								   P_MDL_MDY_CD VARCHAR2,
								   P_CRGR_EENO  VARCHAR2,
	                               RS OUT REFCUR);
	   
	   --조회시에 차종코드에 관계된 APS, 생산마스터, BOM 차종을 가져오기 위한 함수 
	   FUNCTION FU_GET_PRDN_VEHL_LIST(P_QLTY_VEHL_CD VARCHAR2,
			 						  P_PRVS_SCN_CD  VARCHAR2 -- A: APS차종, B:생산마스터차종, C:BOM차종 (참고: 코드테이블 '0023')
									 ) RETURN VARCHAR2;
       
	   
	   --그룹별 담당자 리스트를 가져오기 위한 함수 
	   FUNCTION FU_GET_CRGR_USER_LIST(P_QLTY_VEHL_CD VARCHAR2,
	                                  P_MDL_MDY_CD   VARCHAR2,
	                                  P_BLNS_CO_CD   VARCHAR2
									 ) RETURN VARCHAR2;
									 
	   --그룹별 담당자 아이디 리스트를 얻어오는 함수 
	   FUNCTION FU_GET_CRGR_USER_ID_LIST(P_QLTY_VEHL_CD VARCHAR2,
	                                     P_MDL_MDY_CD   VARCHAR2,
	                                     P_BLNS_CO_CD   VARCHAR2
								        ) RETURN VARCHAR2;
									 
	   --차종 연식 관계 코드를 가져오기 위한 함수 								 
	   FUNCTION FU_GET_MDY_REL_CD(P_QLTY_VEHL_CD VARCHAR2,
	                              P_MDL_MDY_CD   VARCHAR2,
								  P_EXPD_REGN_CD VARCHAR2
								 ) RETURN VARCHAR2;
								 
	   --차종 연식 관계 명칭을 가져오기 위한 함수 								 
	   FUNCTION FU_GET_MDY_REL_NM(P_QLTY_VEHL_CD VARCHAR2,
	                              P_MDL_MDY_CD   VARCHAR2,
								  P_EXPD_REGN_CD VARCHAR2
								 ) RETURN VARCHAR2;
	  							   
	   PROCEDURE SP_GET_EXPD_REGN_LIST(RS OUT REFCUR);
	   
	   --그룹별 담당자 아이디, 이름 리스트를 가져오기 위한 프로시저
	   PROCEDURE GET_CRGR_USER_LIST(P_QLTY_VEHL_CD VARCHAR2,
	                                P_MDL_MDY_CD   VARCHAR2,
	                                P_BLNS_CO_CD   VARCHAR2,
									P_USER_ID_LIST OUT VARCHAR2,
									P_USER_NM_LIST OUT VARCHAR2
								   );
	   
	   --수정시에 차종코드에 해당하는 정보를 조회 
	   PROCEDURE SP_GET_VEHL_INFO(P_QLTY_VEHL_CD VARCHAR2,
	                              P_MDL_MDY_CD   VARCHAR2,
								  RS OUT REFCUR);
	   
	   --차종코드 정보 저장 
	   PROCEDURE SP_VEHL_INFO_SAVE(P_QLTY_VEHL_CD       VARCHAR2,
	                               P_MDL_MDY_CD         VARCHAR2,
								   P_EXPD_CO_CD         VARCHAR2,
								   P_PAC_SCN_CD         VARCHAR2,
								   P_PDI_CD		        VARCHAR2,
								   P_VEHL_NM			VARCHAR2,
								   P_JB_MDY_REL_CD      VARCHAR2,
								   P_DYTM_PLN_VEHL_LIST VARCHAR2,
								   P_PRDN_MST_VEHL_LIST VARCHAR2,
								   P_BOM_VEHL_LIST      VARCHAR2,
								   P_SALE_VEHL_LIST     VARCHAR2,
								   USER_ID_LIST1        VARCHAR2,
								   USER_ID_LIST2        VARCHAR2,
								   USER_ID_LIST3        VARCHAR2,
								   USER_ID_LIST4        VARCHAR2,
								   USER_ID_LIST5        VARCHAR2,
								   P_USE_YN				VARCHAR2,
								   P_USER_EENO			VARCHAR2,
								   P_MDY_REL_CD1		VARCHAR2,
								   P_MDY_REL_CD2		VARCHAR2,
								   P_MDY_REL_CD3		VARCHAR2,
								   P_MDY_REL_CD4		VARCHAR2,
								   P_MDY_REL_CD5		VARCHAR2,
								   P_MDY_REL_CD6		VARCHAR2,
								   P_ET_YN				CHAR);
	   
	   --GOMS로 부터 실시간 데이터 연계 위해 호출되는 프로시저 
	   PROCEDURE SP_VEHL_INFO_SAVE_IF(P_QLTY_VEHL_CD       VARCHAR2,
	                                  P_MDL_MDY_CD         VARCHAR2,
								      P_EXPD_CO_CD         VARCHAR2,
								   	  P_PAC_SCN_CD         VARCHAR2,
								   	  P_PDI_CD		       VARCHAR2,
   								   	  P_VEHL_NM			   VARCHAR2,
   								   	  P_JB_MDY_REL_CD      VARCHAR2,
   								   	  P_DYTM_PLN_VEHL_LIST VARCHAR2,
   								   	  P_PRDN_MST_VEHL_LIST VARCHAR2,
   								   	  P_BOM_VEHL_LIST      VARCHAR2,
   								   	  P_SALE_VEHL_LIST     VARCHAR2,
   								   	  P_USER_ID_LIST1      VARCHAR2,
   								   	  P_USER_ID_LIST2      VARCHAR2,
   								   	  P_USE_YN			   VARCHAR2,
   								   	  P_USER_EENO		   VARCHAR2,
   								   	  P_MDY_REL_CD1		   VARCHAR2,
   								   	  P_MDY_REL_CD2		   VARCHAR2,
   								   	  P_MDY_REL_CD3		   VARCHAR2,
   								   	  P_MDY_REL_CD4		   VARCHAR2,
   								   	  P_MDY_REL_CD5		   VARCHAR2,
   								   	  P_MDY_REL_CD6		   VARCHAR2);
								   
	   
	   PROCEDURE SP_MDY_REL_CD_SAVE(P_QLTY_VEHL_CD VARCHAR2,
	                                P_MDL_MDY_CD   VARCHAR2,
									P_EXPD_REGN_CD VARCHAR2,
									P_MDY_REL_CD   VARCHAR2,
									P_USER_EENO    VARCHAR2);
									
  	   --연식관리 내역 조회 							   
	   PROCEDURE SP_GET_VEHL_MDY_MGMT(P_EXPD_CO_CD   VARCHAR2,
	                                  P_PAC_SCN_CD   VARCHAR2,
							  		  P_PDI_CD		 VARCHAR2,
	                                  P_QLTY_VEHL_CD VARCHAR2,
									  P_REGN_CD      VARCHAR2,
									  P_FROM_YMD	 VARCHAR2,
									  P_TO_YMD		 VARCHAR2,
									  RS OUT REFCUR);
	   --연식관리 내역 저장 
	   PROCEDURE SP_VEHL_MDY_MGMT_SAVE(P_VEHL_CD    VARCHAR2,
	                                   P_REGN_CD    VARCHAR2,
	   			 					   P_MDL_MDY_CD VARCHAR2,
									   P_FROM_PACK 	VARCHAR2,
									   P_USER_EENO  VARCHAR2);
									   
	   --GOMS로 부터 실시간 데이터 연계 위해 호출되는 프로시저 								   
	   PROCEDURE SP_VEHL_MDY_MGMT_SAVE_IF(P_VEHL_CD    VARCHAR2,
	                                      P_REGN_CD    VARCHAR2,
	   			 					   	  P_MDL_MDY_CD VARCHAR2,
									   	  P_FROM_PACK  VARCHAR2,
									   	  P_USER_EENO  VARCHAR2);
	   								  
	   --연계차종 정보 저장 					   
	   PROCEDURE SP_PRDN_VEHL_LIST_SAVE(P_QLTY_VEHL_CD   VARCHAR2,
										P_PRVS_SCN_CD    VARCHAR2,
										P_PRDN_VEHL_LIST VARCHAR2,
								        P_USER_EENO      VARCHAR2);						
	   
	   --차종 담당자 정보 저장 
	   PROCEDURE SP_CRGR_USER_LIST_SAVE(P_QLTY_VEHL_CD VARCHAR2,
	                                    P_MDL_MDY_CD   VARCHAR2,
	                                    P_BLNS_CO_CD   VARCHAR2,
										P_USER_ID_LIST VARCHAR2,
								        P_USER_EENO    VARCHAR2);
	   				
	   --저장시 언어코드정보와 국가코드정보를 복사하는 작업을 수행(연식 신규추가시에만 호출)  								
	   PROCEDURE SP_VEHL_MDY_COPY(P_VEHL_CD    VARCHAR2,
	   							  P_MDL_MDY_CD VARCHAR2,
								  P_USER_EENO  VARCHAR2);
	   
	   --저장시 직전연식관계 변화에 따른 취급설명서 연식코드 매핑 작업 수행 
	   PROCEDURE SP_VEHL_MDY_REL_CD_UPDATE(P_VEHL_CD      VARCHAR2,
	   							           P_MDL_MDY_CD   VARCHAR2,
										   P_EXPD_REGN_CD VARCHAR2,
								           P_MDY_REL_CD   VARCHAR2,
										   P_USER_EENO    VARCHAR2);
                                           
       --직전연식관계에 따른 연식 리스트 조회 
       FUNCTION FU_GET_REL_MDL_MDY(P_VEHL_CD      VARCHAR2,
	   							   P_MDL_MDY_CD   VARCHAR2,
								   P_EXPD_REGN_CD VARCHAR2,
                                   P_MODE         VARCHAR2,
                                   P_COUNT OUT BINARY_INTEGER) RETURN PG_COMMON.LIST_TYPE;
                                   
       FUNCTION FU_GET_REL_MDL_MDY_SUB(P_VEHL_CD      VARCHAR2,
	   							       P_MDL_MDY_CD   VARCHAR2,
								       P_EXPD_REGN_CD VARCHAR2,
                                       P_MODE         VARCHAR2,
                                       P_ISCONTINUE   OUT VARCHAR2) RETURN VARCHAR2;
                                       
	   
	   --직전연식관계 내역을 저장 					   
       PROCEDURE SP_EXPD_MDY_MGMT_SAVE(P_VEHL_CD         VARCHAR2,
	   			 					   P_MDL_MDY_CD      VARCHAR2,
									   P_EXPD_REGN_CD    VARCHAR2,
									   P_EXPD_MDL_MDY_CD VARCHAR2,
									   P_USER_EENO       VARCHAR2);
	   
	   
	   --월팩코드에 따른 차종의 연식을 저장							   
	   PROCEDURE SP_VEHL_MDY_PACK_SAVE(P_VEHL_CD    VARCHAR2,
	                                   P_REGN_CD    VARCHAR2,
	   			 					   P_MDL_MDY_CD VARCHAR2,
									   P_FROM_PACK 	VARCHAR2,
									   P_USER_EENO  VARCHAR2);
       
	   --신규 차종 입력 항목에 대한 관리자 입력 권한 지정 						   
	   PROCEDURE SP_UPDATE_VEHL_AUTH(P_VEHL_CD    VARCHAR2,
	                                 P_PAC_SCN_CD VARCHAR2);
									 
	   
	   PROCEDURE SP_LANG_MDY_REL_CD_UPDATE(P_VEHL_CD      VARCHAR2,
	   							           P_MDL_MDY_CD   VARCHAR2,
										   P_EXPD_REGN_CD VARCHAR2,
								           P_MDY_REL_CD   VARCHAR2,
										   P_USER_EENO    VARCHAR2);
									   
	   PROCEDURE SP_GET_PLNT_LIST(P_VEHL_CD VARCHAR2,
	                              RS        OUT REFCUR);
       
									  
END PG_VEHL_MGMT;