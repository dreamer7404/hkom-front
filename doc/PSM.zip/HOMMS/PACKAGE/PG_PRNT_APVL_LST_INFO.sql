CREATE OR REPLACE PACKAGE PG_PRNT_APVL_LST_INFO AS

	   TYPE REFCUR IS REF CURSOR;

	   --제작승인 내역 조회
	   PROCEDURE SP_GET_PRNT_APVL_INFO(P_MENU_ID 	    VARCHAR2,
								       P_USER_EENO      VARCHAR2,
									   P_PDI_CD	        VARCHAR2,
	   			 					   P_VEHL_CD	    VARCHAR2,
	   			 	                   P_MDL_MDY_CD     VARCHAR2,
									   P_REGN_CD		VARCHAR2,
					                   P_LANG_CD	    VARCHAR2,
					                   P_N_PRNT_PBCN_NO VARCHAR2,
									   P_FROM_YMD	    VARCHAR2,
									   P_TO_YMD		    VARCHAR2,
									   P_I_WAY_CD       VARCHAR2,
									   P_PRNT_WAY_CD2   VARCHAR2,
									   P_DEPQ1_CD       VARCHAR2,
									   --P_FROM_NUM NUMBER,
							 		   --P_TO_NUM   NUMBER,
									   --P_CNT OUT NUMBER,
					                   RS    OUT REFCUR);

	  --제작승인 내역 조회(엑셀 전용)
	  PROCEDURE SP_GET_PRNT_APVL_INFO_EXCEL(P_MENU_ID 	     VARCHAR2,
								       		P_USER_EENO      VARCHAR2,
									   		P_PDI_CD	     VARCHAR2,
	   			 					   		P_VEHL_CD	     VARCHAR2,
	   			 	                   		P_MDL_MDY_CD     VARCHAR2,
									   		P_REGN_CD		 VARCHAR2,
					                   		P_LANG_CD	     VARCHAR2,
					                   		P_N_PRNT_PBCN_NO VARCHAR2,
									   		P_FROM_YMD	     VARCHAR2,
									   		P_TO_YMD		 VARCHAR2,
											P_I_WAY_CD       VARCHAR2,
									   		P_PRNT_WAY_CD2   VARCHAR2,
									   		P_DEPQ1_CD       VARCHAR2,
					                   		RS    OUT REFCUR);

	  --제작승인 내역 조회(엑셀 전용2)
	  PROCEDURE SP_GET_PRNT_APVL_INFO_EXCEL2(P_MENU_ID 	      VARCHAR2,
								       		 P_USER_EENO      VARCHAR2,
									   		 P_PDI_CD	      VARCHAR2,
	   			 					   		 P_VEHL_CD	      VARCHAR2,
	   			 	                   		 P_MDL_MDY_CD     VARCHAR2,
									   		 P_REGN_CD		  VARCHAR2,
					                   		 P_LANG_CD	      VARCHAR2,
					                   		 P_N_PRNT_PBCN_NO VARCHAR2,
									   		 P_FROM_YMD	      VARCHAR2,
									   		 P_TO_YMD		  VARCHAR2,
											 P_I_WAY_CD       VARCHAR2,
									   		 P_PRNT_WAY_CD2   VARCHAR2,
									   		 P_DEPQ1_CD       VARCHAR2,
					                   		 RS    OUT REFCUR);

	  --개정내역 개수 조회
	  FUNCTION FU_GET_REVICE_COUNT(P_VEHL_CD	    VARCHAR2,
	   			 	               P_LANG_CD	    VARCHAR2,
								   P_N_PRNT_PBCN_NO VARCHAR2) RETURN NUMBER;

      --발간번호에 해당하는 개정내역 조회
	  PROCEDURE SP_GET_REVICE_INFO(P_VEHL_CD	    VARCHAR2,
	   			 	               P_LANG_CD	    VARCHAR2,
								   P_N_PRNT_PBCN_NO VARCHAR2,
								   RS           OUT REFCUR);

	  --특이사항 조회
	  PROCEDURE SP_PRNT_REQ_SBC_INFO(P_N_PRNT_PBCN_NO VARCHAR2,
	  								 RS 		  OUT REFCUR);

	  --특이사항 저장
	  PROCEDURE SP_PRNT_REQ_SBC_SAVE(P_N_PRNT_PBCN_NO VARCHAR2,
	                                 P_PRTL_IMTR_SBC2 VARCHAR2,
	                                 P_USER_EENO      VARCHAR2);

	  --납품예정일 변경
	  PROCEDURE SP_DLVG_PARR_YMD_UPDATE(P_N_PRNT_PBCN_NO VARCHAR2,
	                                    P_DLVG_PARR_YMD  VARCHAR2,
										P_USER_EENO      VARCHAR2);



END PG_PRNT_APVL_LST_INFO;