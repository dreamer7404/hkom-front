CREATE OR REPLACE PACKAGE PG_INTERFACE_APS AS

	   EXPD_CO_CD_HMC  CONSTANT VARCHAR2(4) := PG_DATA.EXPD_CO_CD_HMC;   -- HMC 
	   EXPD_DOM_NAT_CD CONSTANT VARCHAR2(5) := PG_DATA.EXPD_DOM_NAT_CD;  -- 내수 국가코드 
	   BTCH_USER_EENO  CONSTANT VARCHAR2(7) := PG_DATA.BTCH_USER_EENO;   -- 배치작업 담당자 코드 
	   
/**********************************************************/
/** HMC 인터페이스 **/ 
   
	   --현대 APS 인터페이스(외부 호출) 
	   PROCEDURE APS_INTERFACE_HMC;
	   
	   --현대 날짜가 변경될 경우 데이터 Summary 작업 수행(외부 호출, 오라클 스케쥴링) 
	   PROCEDURE APS_INTERFACE_DATE_HMC;
	   
	   FUNCTION APS_ODR_INTERFACE_HMC(CURR_YMD IN VARCHAR2)RETURN VARCHAR2;
	   FUNCTION APS_PROD_INTERFACE_HMC(CURR_YMD IN VARCHAR2)RETURN VARCHAR2;
	   
	   PROCEDURE LOAD_APS_ODR_INFO_HMC (CURR_YMD IN VARCHAR2);
	   PROCEDURE LOAD_APS_PROD_INFO_HMC(CURR_YMD IN VARCHAR2);
/**********************************************************/

/**********************************************************/

       --APS 오더 데이터 존재 여부 조회 
	   FUNCTION GET_APS_ODR_EXIST_YN(CURR_YMD IN VARCHAR2,
	                                 EXPD_CO_CD IN VARCHAR2) RETURN VARCHAR2;
	   
	   --오더 배치결과 정보 존재 여부 조회 
	   FUNCTION GET_BTCH_ODR_FNH_YN(CURR_YMD   IN VARCHAR2,
	                                EXPD_CO_CD IN VARCHAR2)RETURN VARCHAR2;				
/**********************************************************/	

/**********************************************************/	
	   
	   --APS 계획 데이터 존재 여부 조회 
	   FUNCTION GET_APS_PROD_EXIST_YN(CURR_YMD IN VARCHAR2,
	                                  EXPD_CO_CD IN VARCHAR2) RETURN VARCHAR2;

	   
	   --계획 배치결과 정보 존재 여부 조회 
	   FUNCTION GET_BTCH_PROD_FNH_YN(CURR_YMD   IN VARCHAR2,
	                                 EXPD_CO_CD IN VARCHAR2)RETURN VARCHAR2;
/**********************************************************/	
/**********************************************************/
	   
	   /**														
       --오더계획 테이블 차종코드, 연식, 취급설명서 국가코드 일괄 적용시 사용하는 프로시저 
	   --(초기 입력된 값이 없었을때 사용, 현재는 사용할 필요없음) 
	   PROCEDURE GET_MANUAL_ODR_INFO_LIST(FROM_YMD IN VARCHAR2,
	                                      TO_YMD   IN VARCHAR2);
	   **/
       
	   --오더계획 테이블 차종코드, 연식, 취급설명서 국가코드 적용시 사용하는 프로시저  
	   --(GET_APS_ODR_SUM_LIST 프로시저 내에서 사용함) 										   
	--   PROCEDURE GET_MANUAL_ODR_INFO_DETAIL(CURR_YMD IN VARCHAR2);
	   
	   /**
	   --생산계획 테이블 차종코드, 연식, 취급설명서 국가코드 일괄 적용시 사용하는 프로시저 
	   --(초기 입력된 값이 없었을때 사용, 현재는 사용할 필요없음) 
	   PROCEDURE GET_MANUAL_PROD_INFO_LIST(FROM_YMD IN VARCHAR2,
	                                       TO_YMD   IN VARCHAR2); 
	   **/
	   
	   --생산계획 테이블 차종코드, 연식, 취급설명서 국가코드 적용시 사용하는 프로시저  
	   --(GET_APS_PROD_SUM_LIST 프로시저 내에서 사용함) 										
	   --PROCEDURE GET_MANUAL_PROD_INFO_DETAIL(CURR_YMD IN VARCHAR2);
	   			   											
       --APS 차종, 월팩, 목적국 코드에 해당하는 품질차종코드, 연식, 취급설명서 국가코드를 추출 
	   PROCEDURE GET_MANUAL_INFO(P_CURR_YMD		IN  VARCHAR2,
	   			 				 P_EXPD_CO_CD   IN  VARCHAR2,
	   			 				 P_PRDN_VEHL_CD IN  VARCHAR2,
	   			 				 P_MO_PACK_CD   IN  VARCHAR2,
								 P_DEST_NAT_CD  IN  VARCHAR2,
								 P_BASC_MDL_CD  IN  VARCHAR2,
								 P_QLTY_VEHL_CD OUT VARCHAR2,
								 P_MDL_MDY_CD   OUT VARCHAR2,
								 P_EXPD_NAT_CD  OUT VARCHAR2);
	   
	   --미지정 국가명 리턴 							 
	--   FUNCTION FU_GET_NOAPIM_NAT_NM(P_EXPD_CO_CD   IN  VARCHAR2, P_DEST_NAT_CD  IN  VARCHAR2) RETURN VARCHAR2;
	   
	   --연식지정관련 별도 작업 프로시저 								 
	   PROCEDURE GET_MDL_MDY_CD_EXTRA(P_CURR_YMD	 IN VARCHAR2,
	   			 					  P_EXPD_CO_CD   IN VARCHAR2, 
	   								  P_QLTY_VEHL_CD IN VARCHAR2,
									  P_EXPD_NAT_CD  IN VARCHAR2,
									  P_MO_PACK_CD   IN VARCHAR2,
									  P_MODE		 IN VARCHAR2,
									  P_BASC_MDL_CD  IN VARCHAR2,
									  P_MDL_MDY_CD   IN OUT VARCHAR2);
/**********************************************************/

/**********************************************************/	
								   
	   --날짜 데이터 생성(외부 호출) 
	   PROCEDURE CREATE_WK_DATE;
	   
	   --날짜 데이터 생성 상세(외부 호출) 
	   PROCEDURE CREATE_WK_DATE_DTL(CURR_YMD   IN VARCHAR2);
/**********************************************************/	   
	   	   	   
/**********************************************************/
/** 생산오더 Summary 상세작업 **/ 
	   
	   --구버전 현재 사용 안함 
	   --[주의] 실행을 위한 전제조건은 현재날짜에 해당하는 내역이 존재하지 않아야 한다. 
--	   PROCEDURE GET_APS_ODR_SUM(CURR_YMD   IN VARCHAR2,
--	                             EXPD_CO_CD IN VARCHAR2);
	   --신버전 현재 사용 			 
	   PROCEDURE GET_APS_ODR_SUM2(CURR_YMD   IN VARCHAR2,
	                              EXPD_CO_CD IN VARCHAR2);					 
	   
	   --화면에 표시되는 데이터의 형태로 오더 정보를 취합하는 작업을 수행						 
	   PROCEDURE GET_APS_ODR_SUM_DTL(CURR_YMD   IN VARCHAR2,
	   			 					 SRCH_YMD   IN VARCHAR2,
	                                 EXPD_CO_CD IN VARCHAR2);
/**********************************************************/									 

/**********************************************************/	
/** 생산계획 Summary 상세작업 **/ 	  
 	   
	   --구버전 현재 사용 안함 
	   --[주의] 실행을 위한 전제조건은 현재날짜에 해당하는 내역이 존재하지 않아야 한다. 							 
--	   PROCEDURE GET_APS_PROD_SUM(CURR_YMD   IN VARCHAR2,
--	                              EXPD_CO_CD IN VARCHAR2);
       
	   --신버전 현재 사용 								  
	   PROCEDURE GET_APS_PROD_SUM2(CURR_YMD   IN VARCHAR2,
	                               EXPD_CO_CD IN VARCHAR2);
	   
	   --화면에 표시되는 데이터의 형태로 생산계획 정보를 취합하는 작업을 수행								  
	   PROCEDURE GET_APS_PROD_SUM_DTL(CURR_YMD   IN VARCHAR2,
	   			 					  SRCH_YMD   IN VARCHAR2,
	                                  EXPD_CO_CD IN VARCHAR2);
/**********************************************************/										  
 	   
/**********************************************************/	
/** 인터페이스 결과 로그 정보 기록 **/ 	
	   
	   --오더 인터페이스 성공시에 완료일자를 저장 								   
	   PROCEDURE SAVE_ODR_BTCH_FNH_INFO(CURR_YMD   IN VARCHAR2,
	                                    EXPD_CO_CD IN VARCHAR2);
										
	   --계획 인터페이스 성공시에 완료일자를 저장 								   
	   PROCEDURE SAVE_PROD_BTCH_FNH_INFO(CURR_YMD   IN VARCHAR2,
	                                     EXPD_CO_CD IN VARCHAR2);
										 
										 							
	   PROCEDURE WRITE_BATCH_LOG(BTCH_NM          IN VARCHAR2,
	   			 				 STRT_DATE		  IN DATE,
	   			 				 BTCH_WK_CD       IN VARCHAR2,
								 BTCH_WK_RSLT_SBC IN VARCHAR2);

		-- 생산계획 부분 재실행시 로그 기록
	   PROCEDURE WRITE_BATCH_LOG2(CURR_YMD   IN VARCHAR2,
	                                     EXPD_CO_CD IN VARCHAR2);
								 
     --  PROCEDURE WRITE_BATCH_ERRLOG(BTCH_NM          IN VARCHAR2,	    BTCH_WK_RSLT_SBC IN VARCHAR2);
       
	   --에러발생시 배치관리자에게 메세지를 전송하는 역할 수행 									
	   PROCEDURE SEND_ERROR_MAIL(BTCH_NM          IN VARCHAR2,
	                             BTCH_WK_RSLT_SBC IN VARCHAR2);
	   
	   --미지정 국가코드 발생 정보 메일 전송하는 역할 수행 
	   PROCEDURE SEND_NOAPIM_NATL_INFO_MAIL(P_EXPD_CO_CD  IN VARCHAR2, 
	   			 							P_AFFR_SCN_CD IN VARCHAR2,
											P_CURR_YMD    IN VARCHAR2);
											
	   PROCEDURE SEND_NOAPIM_NATL_INFO_MAIL_DTL(EXPD_CO_CD IN VARCHAR2);
	   
	   PROCEDURE WRITE_BATCH_EXE_LOG(BTCH_NM          IN VARCHAR2,
	   			 				 STRT_DATE		  IN DATE,
	   			 				 BTCH_WK_CD       IN VARCHAR2,
								 BTCH_WK_RSLT_SBC IN VARCHAR2);
	   
	   							 
/**********************************************************/ 
	   
END PG_INTERFACE_APS;