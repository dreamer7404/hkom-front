CREATE OR REPLACE PACKAGE BODY PG_MAKE_DATA2 AS
    
	PROCEDURE CREATE_USER_INFO_EXCEL
    IS
        CURSOR USER_LIST IS SELECT USER_EENO, USER_PW, USER_NM, BLNS_CO_NM, USER_OPS_NM, USER_EML_ADR, USER_TN, USER_HP_NO, USE_YN,       
                                   PGM01_INP_VEHL, PGM01_IQ_VEHL,
                                   PGM02_INP_VEHL, PGM02_IQ_VEHL,
                                   PGM03_INP_VEHL, PGM03_IQ_VEHL,
                                   PGM04_INP_VEHL, PGM04_IQ_VEHL,
                                   PGM05_INP_VEHL, PGM05_IQ_VEHL,
                                   PGM06_INP_VEHL, PGM06_IQ_VEHL,
                                   PGM07_INP_VEHL, PGM07_IQ_VEHL,
                                   PGM08_INP_VEHL, PGM08_IQ_VEHL,
                                   PGM09_INP_VEHL, PGM09_IQ_VEHL,
                                   PGM10_INP_VEHL, PGM10_IQ_VEHL,
                                   PGM11_INP_VEHL, PGM11_IQ_VEHL,
                                   PGM12_INP_VEHL, PGM12_IQ_VEHL,
                                   PGM13_INP_VEHL, PGM13_IQ_VEHL,
                                   PGM14_INP_VEHL, PGM14_IQ_VEHL,
                                   PGM15_INP_VEHL, PGM15_IQ_VEHL,
                                   PGM16_INP_VEHL, PGM16_IQ_VEHL,
                                   PGM17_INP_VEHL, PGM17_IQ_VEHL,
                                   PGM18_INP_VEHL, PGM18_IQ_VEHL,
                                   PGM19_INP_VEHL, PGM19_IQ_VEHL,
                                   PGM20_INP_VEHL, PGM20_IQ_VEHL,
                                   PGM21_INP_VEHL, PGM21_IQ_VEHL,
                                   PGM22_INP_VEHL, PGM22_IQ_VEHL,
                                   PGM23_INP_VEHL, PGM23_IQ_VEHL,
                                   PGM24_INP_VEHL, PGM24_IQ_VEHL,
                                   PGM25_INP_VEHL, PGM25_IQ_VEHL,
                                   PGM26_INP_VEHL, PGM26_IQ_VEHL,
                                   PGM27_INP_VEHL, PGM27_IQ_VEHL,
                                   PGM28_INP_VEHL, PGM28_IQ_VEHL,
                                   PGM29_INP_VEHL, PGM29_IQ_VEHL,
                                   PGM30_INP_VEHL, PGM30_IQ_VEHL
                            FROM TB_USR_MGMT_EXCEL;
                            
        V_BLNS_CO_CD VARCHAR2(4);
        V_USER_DCD   VARCHAR2(4);

        V_USER_EENO CHAR(7);
        
        V_CURR_INP_VEHL VARCHAR2(8000);
        V_CURR_IQ_VEHL  VARCHAR2(8000);
        V_CURR_MENU_ID  CHAR(10);
               
    BEGIN
        
        V_USER_EENO := 'SYSUSER';
        
        FOR USER_INFO IN USER_LIST LOOP
            
            /**2010.10.12.김동근 임시 주석처리(사용자 정보 변경없이 권한만 업데이트 처리함)
            
            SELECT MAX(DL_EXPD_PRVS_CD)
            INTO V_BLNS_CO_CD
            FROM TB_CODE_MGMT
            WHERE DL_EXPD_G_CD = '0001'
            AND DL_EXPD_PRVS_NM = TRIM(USER_INFO.BLNS_CO_NM);
            
            IF V_BLNS_CO_CD IS NULL THEN
                
                RAISE_APPLICATION_ERROR(-20001, '[회사코드 존재하지 않음] ' ||
			   								    '회사명:' || USER_INFO.BLNS_CO_NM || ' ');
                                                     
            END IF;
            
            SELECT MAX(DL_EXPD_PRVS_CD)
            INTO V_USER_DCD
            FROM TB_CODE_MGMT
            WHERE DL_EXPD_G_CD = '0011'
            AND DL_EXPD_PRVS_NM = TRIM(USER_INFO.USER_OPS_NM);
            
            IF V_USER_DCD IS NULL THEN
                
                RAISE_APPLICATION_ERROR(-20001, '[부서코드 존재하지 않음] ' ||
			   								    '부서명:' || USER_INFO.USER_OPS_NM || ' ');
                                                     
            END IF;
            
            -- 이전 존재 데이터 삭제 작업 수행 
            DELETE FROM TB_USR_MGMT
            WHERE USER_EENO = USER_INFO.USER_EENO;
            
            --사용자 정보 Insert
            INSERT INTO TB_USR_MGMT(USER_EENO, USER_PW, USER_NM, BLNS_CO_CD, USER_DCD,
                                    USER_EML_ADR, USER_TN, USER_HP_NO, USE_YN, 
                                    PPRR_EENO, FRAM_DTM, UPDR_EENO, MDFY_DTM)
            VALUES(USER_INFO.USER_EENO, USER_INFO.USER_PW, USER_INFO.USER_NM, V_BLNS_CO_CD, V_USER_DCD,
                   USER_INFO.USER_EML_ADR, USER_INFO.USER_TN, USER_INFO.USER_HP_NO, NVL(USER_INFO.USE_YN, 'N'), 
                   V_USER_EENO, SYSDATE, V_USER_EENO, SYSDATE);
                   
            **/
            
            --[1][0002]총재고관리
            V_CURR_INP_VEHL := USER_INFO.PGM01_INP_VEHL;
            V_CURR_IQ_VEHL  := USER_INFO.PGM01_IQ_VEHL;
            V_CURR_MENU_ID  := '0002';
            CREATE_USER_AFFR_AUTH(USER_INFO.USER_EENO, V_CURR_MENU_ID,
                                  V_CURR_INP_VEHL, V_CURR_IQ_VEHL,
                                  V_USER_EENO);
            
            
            --[2][0003]세원재고관리
            V_CURR_INP_VEHL := USER_INFO.PGM02_INP_VEHL;
            V_CURR_IQ_VEHL  := USER_INFO.PGM02_IQ_VEHL;
            V_CURR_MENU_ID  := '0003';
            CREATE_USER_AFFR_AUTH(USER_INFO.USER_EENO, V_CURR_MENU_ID,
                                  V_CURR_INP_VEHL, V_CURR_IQ_VEHL,
                                  V_USER_EENO);
            
            --[3][0004]PDI재고관리
            V_CURR_INP_VEHL := USER_INFO.PGM03_INP_VEHL;
            V_CURR_IQ_VEHL  := USER_INFO.PGM03_IQ_VEHL;
            V_CURR_MENU_ID  := '0004';
            CREATE_USER_AFFR_AUTH(USER_INFO.USER_EENO, V_CURR_MENU_ID,
                                  V_CURR_INP_VEHL, V_CURR_IQ_VEHL,
                                  V_USER_EENO);
            
            --[4][0005]글로비스재고관리
            V_CURR_INP_VEHL := USER_INFO.PGM04_INP_VEHL;
            V_CURR_IQ_VEHL  := USER_INFO.PGM04_IQ_VEHL;
            V_CURR_MENU_ID  := '0005';
            CREATE_USER_AFFR_AUTH(USER_INFO.USER_EENO, V_CURR_MENU_ID,
                                  V_CURR_INP_VEHL, V_CURR_IQ_VEHL,
                                  V_USER_EENO);
            
            --[5][0007]EO발행현황
            V_CURR_INP_VEHL := USER_INFO.PGM05_INP_VEHL;
            V_CURR_IQ_VEHL  := USER_INFO.PGM05_IQ_VEHL;
            V_CURR_MENU_ID  := '0007';
            CREATE_USER_AFFR_AUTH(USER_INFO.USER_EENO, V_CURR_MENU_ID,
                                  V_CURR_INP_VEHL, V_CURR_IQ_VEHL,
                                  V_USER_EENO);
            
            --[6][0008]법규및변경관리
            V_CURR_INP_VEHL := USER_INFO.PGM06_INP_VEHL;
            V_CURR_IQ_VEHL  := USER_INFO.PGM06_IQ_VEHL;
            V_CURR_MENU_ID  := '0008';
            CREATE_USER_AFFR_AUTH(USER_INFO.USER_EENO, V_CURR_MENU_ID,
                                  V_CURR_INP_VEHL, V_CURR_IQ_VEHL,
                                  V_USER_EENO);
            
            --[7][0009]O/M제작의뢰                                  
            V_CURR_INP_VEHL := USER_INFO.PGM07_INP_VEHL;
            V_CURR_IQ_VEHL  := USER_INFO.PGM07_IQ_VEHL;
            V_CURR_MENU_ID  := '0009';
            CREATE_USER_AFFR_AUTH(USER_INFO.USER_EENO, V_CURR_MENU_ID,
                                  V_CURR_INP_VEHL, V_CURR_IQ_VEHL,
                                  V_USER_EENO);
            
            --[8][0010]제작의뢰리스트
            V_CURR_INP_VEHL := USER_INFO.PGM08_INP_VEHL;
            V_CURR_IQ_VEHL  := USER_INFO.PGM08_IQ_VEHL;
            V_CURR_MENU_ID  := '0010';
            CREATE_USER_AFFR_AUTH(USER_INFO.USER_EENO, V_CURR_MENU_ID,
                                  V_CURR_INP_VEHL, V_CURR_IQ_VEHL,
                                  V_USER_EENO);
            
            --[9][0011]O/M승인발주                      
            V_CURR_INP_VEHL := USER_INFO.PGM09_INP_VEHL;
            V_CURR_IQ_VEHL  := USER_INFO.PGM09_IQ_VEHL;
            V_CURR_MENU_ID  := '0011';
            CREATE_USER_AFFR_AUTH(USER_INFO.USER_EENO, V_CURR_MENU_ID,
                                  V_CURR_INP_VEHL, V_CURR_IQ_VEHL,
                                  V_USER_EENO);
            
            --[10][0015]발간현황                      
            V_CURR_INP_VEHL := USER_INFO.PGM10_INP_VEHL;
            V_CURR_IQ_VEHL  := USER_INFO.PGM10_IQ_VEHL;
            V_CURR_MENU_ID  := '0015';
            CREATE_USER_AFFR_AUTH(USER_INFO.USER_EENO, V_CURR_MENU_ID,
                                  V_CURR_INP_VEHL, V_CURR_IQ_VEHL,
                                  V_USER_EENO);
            
            --[11][0019]언어코드관리                  
            V_CURR_INP_VEHL := USER_INFO.PGM11_INP_VEHL;
            V_CURR_IQ_VEHL  := USER_INFO.PGM11_IQ_VEHL;
            V_CURR_MENU_ID  := '0019';
            CREATE_USER_AFFR_AUTH(USER_INFO.USER_EENO, V_CURR_MENU_ID,
                                  V_CURR_INP_VEHL, V_CURR_IQ_VEHL,
                                  V_USER_EENO);
            
            --[12][0020]차종코드관리                  
            V_CURR_INP_VEHL := USER_INFO.PGM12_INP_VEHL;
            V_CURR_IQ_VEHL  := USER_INFO.PGM12_IQ_VEHL;
            V_CURR_MENU_ID  := '0020';
            CREATE_USER_AFFR_AUTH(USER_INFO.USER_EENO, V_CURR_MENU_ID,
                                  V_CURR_INP_VEHL, V_CURR_IQ_VEHL,
                                  V_USER_EENO);
            
            --[13][0021]국가/언어코드관리                   
            V_CURR_INP_VEHL := USER_INFO.PGM13_INP_VEHL;
            V_CURR_IQ_VEHL  := USER_INFO.PGM13_IQ_VEHL;
            V_CURR_MENU_ID  := '0021';
            CREATE_USER_AFFR_AUTH(USER_INFO.USER_EENO, V_CURR_MENU_ID,
                                  V_CURR_INP_VEHL, V_CURR_IQ_VEHL,
                                  V_USER_EENO);
            
            --[14][0022]안전재고관리                   
            V_CURR_INP_VEHL := USER_INFO.PGM14_INP_VEHL;
            V_CURR_IQ_VEHL  := USER_INFO.PGM14_IQ_VEHL;
            V_CURR_MENU_ID  := '0022';
            CREATE_USER_AFFR_AUTH(USER_INFO.USER_EENO, V_CURR_MENU_ID,
                                  V_CURR_INP_VEHL, V_CURR_IQ_VEHL,
                                  V_USER_EENO);
            
            --[15][0023]인쇄페이지관리                     
            V_CURR_INP_VEHL := USER_INFO.PGM15_INP_VEHL;
            V_CURR_IQ_VEHL  := USER_INFO.PGM15_IQ_VEHL;
            V_CURR_MENU_ID  := '0023';
            CREATE_USER_AFFR_AUTH(USER_INFO.USER_EENO, V_CURR_MENU_ID,
                                  V_CURR_INP_VEHL, V_CURR_IQ_VEHL,
                                  V_USER_EENO);                       
        END LOOP;
        
        COMMIT;
    
    END CREATE_USER_INFO_EXCEL;
    
    PROCEDURE CREATE_USER_AFFR_AUTH(P_USER_EENO    CHAR,
                                    P_MENU_ID      VARCHAR2,
                                    P_INP_VEHLS    VARCHAR2, 
                                    P_IQ_VEHLS     VARCHAR2,
                                    P_USER_EENO2   CHAR)
    IS
    BEGIN
        
		DELETE FROM TB_AUTH_AFFR_MGMT
        WHERE USER_EENO = PG_COMMON.FU_RPAD(P_USER_EENO, 7)
        AND MENU_ID = PG_COMMON.FU_RPAD(P_MENU_ID, 10);
		
        IF P_INP_VEHLS IS NOT NULL OR
           P_IQ_VEHLS IS NOT NULL THEN
               
            INSERT INTO TB_AUTH_AFFR_MGMT(USER_EENO, MENU_ID, MENU_AUTH_CD, 
                                          PPRR_EENO, FRAM_DTM, UPDR_EENO, MDFY_DTM)
            VALUES(P_USER_EENO, P_MENU_ID, 'R', 
                   P_USER_EENO2, SYSDATE, P_USER_EENO2, SYSDATE);
                      
            CREATE_USER_VEHL_AUTH(P_USER_EENO, P_MENU_ID, 
                                  P_INP_VEHLS, P_IQ_VEHLS, 
                                  P_USER_EENO2);
               
        END IF;
                       
    END CREATE_USER_AFFR_AUTH;
    
    PROCEDURE CREATE_USER_VEHL_AUTH(P_USER_EENO    CHAR,
                                    P_MENU_ID      VARCHAR2,
                                    P_INP_VEHLS    VARCHAR2, 
                                    P_IQ_VEHLS     VARCHAR2,
                                    P_USER_EENO2   CHAR)
    IS
        V_LIST1     PG_COMMON.LIST_TYPE;
	    V_LIST1_CNT BINARY_INTEGER;
        
        V_LIST2     PG_COMMON.LIST_TYPE;
	    V_LIST2_CNT BINARY_INTEGER;
        
        V_CNT       NUMBER;
        
        V_INP_SCN_CD CHAR(1);
        
    BEGIN

         SELECT MAX(INP_SCN_CD)
         INTO V_INP_SCN_CD
         FROM TB_PGM_MGMT
         WHERE MENU_ID = PG_COMMON.FU_RPAD(P_MENU_ID, 10);
         
         IF V_INP_SCN_CD = 'B' THEN
            
            RETURN;
         
         END IF;
         
		 DELETE FROM TB_AUTH_VEHL_MGMT
         WHERE USER_EENO = PG_COMMON.FU_RPAD(P_USER_EENO, 7)
         AND MENU_ID = PG_COMMON.FU_RPAD(P_MENU_ID, 10);
		 
         IF TRIM(P_INP_VEHLS) = 'ALL' THEN
            
            INSERT INTO TB_AUTH_VEHL_MGMT(USER_EENO, MENU_ID, QLTY_VEHL_CD, CL_SCN_CD,
                                          PPRR_EENO, FRAM_DTM, UPDR_EENO, MDFY_DTM)
            SELECT P_USER_EENO AS USER_EENO,
                   P_MENU_ID   AS MENU_ID,
                   QLTY_VEHL_CD,
                   'U'          AS CL_SCN_CD,
                   P_USER_EENO2 AS PPRR_EENO, 
                   SYSDATE      AS FRAM_DTM, 
                   P_USER_EENO2 AS UPDR_EENO, 
                   SYSDATE      AS MDFY_DTM
            FROM TB_VEHL_MGMT
            GROUP BY QLTY_VEHL_CD;
                                          
         ELSE
         
            V_LIST1 := PG_COMMON.FU_SPLIT(P_INP_VEHLS, V_LIST1_CNT);
               
            FOR CURR_IDX1 IN 1..V_LIST1_CNT LOOP
                                       
                IF TRIM(V_LIST1(CURR_IDX1)) IS NOT NULL THEN
 
                    SELECT COUNT(*)
                    INTO V_CNT
                    FROM TB_VEHL_MGMT
                    WHERE QLTY_VEHL_CD = TRIM(V_LIST1(CURR_IDX1))
                    AND ROWNUM <= 1;
                    
                    IF V_CNT > 0 THEN
                        
						--사용자 입력 실수 대비용 
						SELECT COUNT(*)
						INTO V_CNT
						FROM TB_AUTH_VEHL_MGMT
						WHERE USER_EENO = PG_COMMON.FU_RPAD(P_USER_EENO, 7)
						AND MENU_ID = PG_COMMON.FU_RPAD(P_MENU_ID, 10)
						AND QLTY_VEHL_CD = TRIM(V_LIST1(CURR_IDX1))
						AND CL_SCN_CD = 'U';
						
						IF V_CNT = 0 THEN
						   
						   INSERT INTO TB_AUTH_VEHL_MGMT(USER_EENO, MENU_ID, QLTY_VEHL_CD, CL_SCN_CD,
                                                         PPRR_EENO, FRAM_DTM, UPDR_EENO, MDFY_DTM)
                           VALUES(P_USER_EENO, P_MENU_ID, TRIM(V_LIST1(CURR_IDX1)), 'U',
                                  P_USER_EENO2, SYSDATE, P_USER_EENO2, SYSDATE);
							   
						END IF;
						       
                    /** 차종코드에 항목이 없는 경우에는 에러 발생시키지 않고 그냥 아무런 처리도 하지 않는다.    
                    ELSE
                        
                        RAISE_APPLICATION_ERROR(-20000, '[차종코드 존재하지 않음] ' ||
                                                        '차종코드:' || V_LIST1(CURR_IDX1) || ' ');
                    **/                                    
                    END IF;
                    
                END IF;

            END LOOP;
            
         END IF;
              
         IF TRIM(P_IQ_VEHLS) = 'ALL' THEN
            
            INSERT INTO TB_AUTH_VEHL_MGMT(USER_EENO, MENU_ID, QLTY_VEHL_CD, CL_SCN_CD,
                                          PPRR_EENO, FRAM_DTM, UPDR_EENO, MDFY_DTM)
            SELECT P_USER_EENO AS USER_EENO,
                   P_MENU_ID   AS MENU_ID,
                   QLTY_VEHL_CD,
                   'R'          AS CL_SCN_CD,
                   P_USER_EENO2 AS PPRR_EENO, 
                   SYSDATE      AS FRAM_DTM, 
                   P_USER_EENO2 AS UPDR_EENO, 
                   SYSDATE      AS MDFY_DTM
            FROM TB_VEHL_MGMT
            GROUP BY QLTY_VEHL_CD;
            
         ELSE
            
            V_LIST2 := PG_COMMON.FU_SPLIT(P_IQ_VEHLS, V_LIST2_CNT);
         
            FOR CURR_IDX2 IN 1..V_LIST2_CNT LOOP
                
                IF TRIM(V_LIST2(CURR_IDX2)) IS NOT NULL THEN
                
                    SELECT COUNT(*)
                    INTO V_CNT
                    FROM TB_VEHL_MGMT
                    WHERE QLTY_VEHL_CD = TRIM(V_LIST2(CURR_IDX2))
                    AND ROWNUM <= 1;
                    
                    IF V_CNT > 0 THEN
                        
						--사용자 입력 실수 대비용 
						SELECT COUNT(*)
						INTO V_CNT
						FROM TB_AUTH_VEHL_MGMT
						WHERE USER_EENO = PG_COMMON.FU_RPAD(P_USER_EENO, 7)
						AND MENU_ID = PG_COMMON.FU_RPAD(P_MENU_ID, 10)
						AND QLTY_VEHL_CD = TRIM(V_LIST2(CURR_IDX2))
						AND CL_SCN_CD = 'R';
						
						IF V_CNT = 0 THEN
						   
						   INSERT INTO TB_AUTH_VEHL_MGMT(USER_EENO, MENU_ID, QLTY_VEHL_CD, CL_SCN_CD,
                                                         PPRR_EENO, FRAM_DTM, UPDR_EENO, MDFY_DTM)
                           VALUES(P_USER_EENO, P_MENU_ID, TRIM(V_LIST2(CURR_IDX2)), 'R',
                                  P_USER_EENO2, SYSDATE, P_USER_EENO2, SYSDATE);
							   
						END IF;
						
                        
                               
                    /** 차종코드에 항목이 없는 경우에는 에러 발생시키지 않고 그냥 아무런 처리도 하지 않는다.                              
                    ELSE
                        
                        RAISE_APPLICATION_ERROR(-20000, '[차종코드 존재하지 않음] ' ||
                                                        '차종코드:' || V_LIST2(CURR_IDX2) || ' ');
                    **/                                   
                    END IF;
                   
                END IF;

            END LOOP;
         
         END IF;
      
    END CREATE_USER_VEHL_AUTH;
    
    --권한정보만을 재설정 하기 위해 사용[외부호출] 
    PROCEDURE SP_RESET_USER_AUTH(P_USER_EENO    CHAR,
                                 P_MENU_ID      VARCHAR2,
                                 P_INP_VEHLS    VARCHAR2, 
                                 P_IQ_VEHLS     VARCHAR2)
    IS
    BEGIN
        
		/** 권한 설정 부분에서 이전 설정 내역 삭제하는 기능 포함되어 있음
        DELETE FROM TB_AUTH_AFFR_MGMT
        WHERE USER_EENO = PG_COMMON.FU_RPAD(P_USER_EENO, 7)
        AND MENU_ID = PG_COMMON.FU_RPAD(P_MENU_ID, 10);
            
        DELETE FROM TB_AUTH_VEHL_MGMT
        WHERE USER_EENO = PG_COMMON.FU_RPAD(P_USER_EENO, 7)
        AND MENU_ID = PG_COMMON.FU_RPAD(P_MENU_ID, 10);
        **/
		
        CREATE_USER_AFFR_AUTH(P_USER_EENO, P_MENU_ID,
                              P_INP_VEHLS, P_IQ_VEHLS,
                              'SYSUSER');
                              
        COMMIT;

    END SP_RESET_USER_AUTH;
    
    --사용자 권한 정보 복사 기능 수행[외부호출]                                  
    PROCEDURE SP_COPY_USER_AUTH(P_ORIGINAL_USER_EENO CHAR,
                                P_TARGET_USER_EENO   CHAR)
    IS
    BEGIN
        
        DELETE FROM TB_AUTH_AFFR_MGMT
        WHERE USER_EENO = PG_COMMON.FU_RPAD(P_TARGET_USER_EENO, 7);
            
        DELETE FROM TB_AUTH_VEHL_MGMT
        WHERE USER_EENO = PG_COMMON.FU_RPAD(P_TARGET_USER_EENO, 7);
        
        INSERT INTO TB_AUTH_AFFR_MGMT
        SELECT P_TARGET_USER_EENO AS USER_EENO,
               MENU_ID,
               MENU_AUTH_CD,
               'SYSUSER',
               SYSDATE,
               'SYSUSER',
               SYSDATE,
               USE_YN
        FROM TB_AUTH_AFFR_MGMT
        WHERE USER_EENO = PG_COMMON.FU_RPAD(P_ORIGINAL_USER_EENO, 7);
        
        INSERT INTO TB_AUTH_VEHL_MGMT
        SELECT P_TARGET_USER_EENO AS USER_EENO,
               MENU_ID,
               QLTY_VEHL_CD,
               CL_SCN_CD,
               'SYSUSER',
               SYSDATE,
               'SYSUSER',
               SYSDATE
        FROM TB_AUTH_VEHL_MGMT
        WHERE USER_EENO = PG_COMMON.FU_RPAD(P_ORIGINAL_USER_EENO, 7);
        
        COMMIT;
        
    END SP_COPY_USER_AUTH;
	
    --차종 담당자별 권한 추가 수행
    --(본사, 경진 담당자로 지정되어 있는 차종에서 입력권한 설정되어 있지 않는 항목 입력권한으로 추가함)
    PROCEDURE SP_ADD_CRGR_USER_AUTH
    IS
        CURSOR VEHL_LIST IS SELECT A.CRGR_EENO, A.QLTY_VEHL_CD
                            FROM TB_VEHL_CRGR_MGMT A, 
                                 TB_USR_MGMT B
                            WHERE A.BLNS_CO_CD IN ('01', '02')
                            AND A.CRGR_EENO = B.USER_EENO
                            AND B.USE_YN = 'Y'
                            GROUP BY A.CRGR_EENO, A.QLTY_VEHL_CD;

    BEGIN
        
        FOR VEHL_INFO IN VEHL_LIST LOOP
            
            SP_ADD_CRGR_USER_AUTH_DTL(VEHL_INFO.CRGR_EENO, VEHL_INFO.QLTY_VEHL_CD);
                
        END LOOP;
        
        COMMIT;
    
    END SP_ADD_CRGR_USER_AUTH;
    
    PROCEDURE SP_ADD_CRGR_USER_AUTH_DTL(P_USER_EENO    VARCHAR2,
                                        P_QLTY_VEHL_CD VARCHAR2)
    IS
        CURSOR PGM_LIST IS SELECT A.MENU_ID
                           FROM TB_AUTH_AFFR_MGMT A,
                                TB_PGM_MGMT B
                           WHERE A.MENU_ID = B.MENU_ID
                           AND A.USER_EENO = P_USER_EENO
                           AND B.PGM_ID_SN <> 0
                           AND B.INP_SCN_CD = 'A'
                           AND B.USE_YN = 'Y';
                           
        V_CNT NUMBER;
                           
    BEGIN
        
        FOR PGM_INFO IN PGM_LIST LOOP
            
            DELETE FROM TB_AUTH_VEHL_MGMT
            WHERE USER_EENO = P_USER_EENO
            AND MENU_ID = PGM_INFO.MENU_ID
            AND QLTY_VEHL_CD = P_QLTY_VEHL_CD
            AND CL_SCN_CD = 'R';
            
            SELECT COUNT(*)
            INTO V_CNT
            FROM TB_AUTH_VEHL_MGMT
            WHERE USER_EENO = P_USER_EENO
            AND MENU_ID = PGM_INFO.MENU_ID
            AND QLTY_VEHL_CD = P_QLTY_VEHL_CD
            AND CL_SCN_CD = 'U';
            
            IF V_CNT = 0 THEN
                
                INSERT INTO TB_AUTH_VEHL_MGMT
                VALUES(P_USER_EENO, PGM_INFO.MENU_ID, P_QLTY_VEHL_CD, 'U',
                       'SYSUSER', SYSDATE, 'SYSUSER', SYSDATE);
                        
            END IF;
            
        END LOOP;
        
    END SP_ADD_CRGR_USER_AUTH_DTL;
    
    
	/**
	--법규및변경관리 변경번호 변경 작업 								
	PROCEDURE SP_UPDATE_CHKLIST_INFO
	IS
	  CURSOR CHK_LIST IS SELECT DL_EXPD_ALTR_NO, RCPM_SHAP_CD
	  		 		     FROM TB_CHKLIST_INFO
						 WHERE RCPM_SHAP_CD NOT IN ('05', '06', '07');
						 
	  V_EXPD_ALTR_NO	 VARCHAR2(10);
	  
	BEGIN
	
		 FOR CHK_INFO IN CHK_LIST LOOP
		 	
--			IF SUBSTR(CHK_INFO.DL_EXPD_ALTR_NO, 1, 2) = 'RU' OR 
--			   SUBSTR(CHK_INFO.DL_EXPD_ALTR_NO, 1, 2) = 'R2' THEN
--			   
--			   
--			ELSIF SUBSTR(CHK_INFO.DL_EXPD_ALTR_NO, 1, 2) = 'R1'
--			
--			ELSE
--				
--				V_EXPD_ALTR_NO := 'C' || CHK_INFO.DL_EXPD_ALTR_NO;
--				
--			END IF;
			
			--법규가 아닌 항목만 처리한다.(법규는 수동 처리 해 줄 것)
			V_EXPD_ALTR_NO := 'C' || CHK_INFO.DL_EXPD_ALTR_NO;
			
			UPDATE TB_CHKLIST_INFO
			SET DL_EXPD_ALTR_NO = V_EXPD_ALTR_NO
			WHERE DL_EXPD_ALTR_NO = CHK_INFO.DL_EXPD_ALTR_NO;
			
			UPDATE TB_CHKLIST_DTL_INFO
			SET DL_EXPD_ALTR_NO = V_EXPD_ALTR_NO
			WHERE DL_EXPD_ALTR_NO = CHK_INFO.DL_EXPD_ALTR_NO;
			
		 END LOOP;
	
		 COMMIT;
	
	END SP_UPDATE_CHKLIST_INFO;
	**/
	
END PG_MAKE_DATA2;