CREATE OR REPLACE PACKAGE BODY HOMMS_ADM.PG_USR_MGMT AS
										 
  -- 계정 휴면 처리 및 미사용 계정 삭제 처리 로직
  PROCEDURE SP_USER_MGMT_BTCH
  IS
  V_CNT      NUMBER;
  STRT_DATE  DATE;
  BEGIN
    BEGIN
        V_CNT := 0;
        STRT_DATE  := SYSDATE;
        -- 90일 이상 미사용 휴면 계정 처리
        -- 최종 로그인 기록이 90일 경과한 계정은 USE_YN = 'N' 처리
        -- 17.9.15 (GRP계정 제외)
        SELECT COUNT(*)
            INTO V_CNT
        FROM TB_USR_MGMT
        WHERE USE_YN = 'Y'
            AND (SYSDATE - FIN_LGI_DTM) >= 90
            AND USE_GBN <> 'G'
        ;
        UPDATE TB_USR_MGMT
        SET
            USE_YN = 'N',
            UPDR_EENO = 'BATCH',
            MDFY_DTM = SYSDATE
        WHERE USE_YN = 'Y'
            AND (SYSDATE - FIN_LGI_DTM) >= 90
            AND USE_GBN <> 'G'
        ;
        
        COMMIT;
        
        PG_INTERFACE_APS.WRITE_BATCH_LOG('휴면계정 처리', STRT_DATE, 'S', '배치 '||V_CNT||' 건 처리완료');
    END;

    BEGIN
        V_CNT := 0;
        STRT_DATE  := SYSDATE;
        -- 휴면계정 처리 90일 이상 지난 계정은 삭제 처리
        SELECT COUNT(*)
            INTO V_CNT
        FROM TB_USR_MGMT
        WHERE USE_YN = 'N'
            AND (SYSDATE - MDFY_DTM) >= 90
            AND USE_GBN <> 'G'
        ;
        DELETE FROM TB_USR_MGMT
        WHERE USE_YN = 'N'
            AND (SYSDATE - MDFY_DTM) >= 90
            AND USE_GBN <> 'G'
        ;
        
        COMMIT;
        
        PG_INTERFACE_APS.WRITE_BATCH_LOG('미사용 계정 처리', STRT_DATE, 'S', '배치 '||V_CNT||' 건 처리완료');
    END;
  END SP_USER_MGMT_BTCH;

END PG_USR_MGMT;