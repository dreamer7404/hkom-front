CREATE OR REPLACE package body pg_code_grp_mgmt as

  PROCEDURE SP_CODE_GRP_MGMT_LIST(RS OUT REFCUR)
    Is
  begin
    OPEN RS FOR
      SELECT
        *
      FROM
        TB_CODE_GRP_MGMT
      ORDER BY
        DL_EXPD_G_NM;
	  
  end SP_CODE_GRP_MGMT_LIST;

  PROCEDURE SP_CODE_GRP_MGMT_INSERT(DL_EXPD_G_CD IN TB_CODE_GRP_MGMT.DL_EXPD_G_CD%TYPE,
					  DL_EXPD_G_NM IN TB_CODE_GRP_MGMT.DL_EXPD_G_NM%TYPE,
					  PPRR_EENO IN TB_CODE_GRP_MGMT.PPRR_EENO%TYPE,
                                          UPDR_EENO IN TB_CODE_GRP_MGMT.UPDR_EENO%TYPE)
    as
  begin
    INSERT INTO TB_CODE_GRP_MGMT(
                                  DL_EXPD_G_CD,
                                  DL_EXPD_G_NM,
                                  PPRR_EENO,
                                  UPDR_EENO,
                                  FRAM_DTM,
                                  MDFY_DTM)
    VALUES(
            DL_EXPD_G_CD,
            DL_EXPD_G_NM,
            PPRR_EENO,
            UPDR_EENO,
            SYSDATE,
            SYSDATE);
  end SP_CODE_GRP_MGMT_INSERT;

end pg_code_grp_mgmt;