CREATE OR REPLACE PACKAGE BODY PG_GLOVIS_IV_INFO AS
	   
   --글로비스재고 조회(PDI, 차종, 연식, 지역, 언어) 
   PROCEDURE SP_GET_GLOVIS_IV_INFO(P_MENU_ID 	VARCHAR2,
								   P_USER_EENO  VARCHAR2,
								   P_CURR_YMD	VARCHAR2,
								   P_EXPD_CO_CD VARCHAR2,
 								   P_PDI_CD	    VARCHAR2,
								   P_VEHL_CD	VARCHAR2,
								   P_MDL_MDY	VARCHAR2,
								   P_REGN_CD	VARCHAR2,
								   P_LANG_CD	VARCHAR2,
								   P_DLVY_STATE VARCHAR2,
                                   RS 		  OUT REFCUR,
                                   P_MESSAGE OUT VARCHAR2)
   IS
   	 V_MESSAGE VARCHAR2(8000);
   BEGIN
	   		PG_TOT_IV_INFO.SP_GET_MESSAGE(P_CURR_YMD, V_MESSAGE);
			
			P_MESSAGE := V_MESSAGE;
			
			SP_GET_GLOVIS_IV_INFO2(P_MENU_ID,
								   P_USER_EENO,
								   P_CURR_YMD,
								   P_EXPD_CO_CD,
								   'ALL',
								   P_PDI_CD,
								   P_VEHL_CD,
								   P_MDL_MDY,
								   P_REGN_CD,
								   P_LANG_CD,
								   P_DLVY_STATE,
								   RS);
								  
   END SP_GET_GLOVIS_IV_INFO;
   
   --글로비스재고 조회(승상구분, PDI, 차종, 연식, 지역, 언어) 						  
   PROCEDURE SP_GET_GLOVIS_IV_INFO2(P_MENU_ID 	 VARCHAR2,
								    P_USER_EENO  VARCHAR2,
								    P_CURR_YMD	 VARCHAR2,
									P_EXPD_CO_CD VARCHAR2,
								    P_PAC_SCN_CD VARCHAR2,
 								    P_PDI_CD	 VARCHAR2,
								    P_VEHL_CD	 VARCHAR2,
								    P_MDL_MDY	 VARCHAR2,
								    P_REGN_CD	 VARCHAR2,
								    P_LANG_CD	 VARCHAR2,
								    P_DLVY_STATE VARCHAR2,
                                    RS 		OUT REFCUR)
	   IS
	   	  
		  V_FROM_MDL_MDY VARCHAR2(2);
		  V_TO_MDL_MDY   VARCHAR2(2);
		  
	   	  V_CURR_DATE	DATE;

--          --V_CURR_PACK	VARCHAR2(4);
--          --V_PREV_PACK	VARCHAR2(4);

--		  --V_PREV_YEAR_YMD VARCHAR2(8);  --1년전 현재월 1일 날짜
--		  V_PREV_3MTH_YMD VARCHAR2(8);  --3개월전 1일 날짜
--		  V_PREV_1MTH_YMD VARCHAR2(8);  --1개월전 마지막 날짜
--		  V_PREV_1DAY_YMD VARCHAR2(8);  --어제 날짜
--		  V_CURR_FSTD_YMD VARCHAR2(8);  --현재월 1일 날짜
--		  --V_NEXT_2WEK_YMD VARCHAR2(8);  --2주 후 날짜
		  
--		  V_PREV_2WEK_YMD VARCHAR2(8);  --2주 전 날짜 

	   BEGIN
	   	  
		  PG_COMMON.SP_GET_VALID_MDL_MDY4(P_CURR_YMD, '', V_FROM_MDL_MDY, V_TO_MDL_MDY);
		  
		  V_CURR_DATE := TO_DATE(P_CURR_YMD, 'YYYYMMDD');

--		  --V_CURR_PACK := TO_CHAR(V_CURR_DATE, 'YYMM');
--		  --V_PREV_PACK := TO_CHAR(ADD_MONTHS(V_CURR_DATE, -1), 'YYMM');

--		  --V_PREV_YEAR_YMD := TO_CHAR(ADD_MONTHS(V_CURR_DATE, -12), 'YYYYMM') || '01';
--		  V_PREV_3MTH_YMD := TO_CHAR(ADD_MONTHS(V_CURR_DATE, -3), 'YYYYMM') || '01';
--		  V_PREV_1MTH_YMD := TO_CHAR(LAST_DAY(ADD_MONTHS(V_CURR_DATE, -1)), 'YYYYMMDD');
--		  V_PREV_1DAY_YMD := TO_CHAR(V_CURR_DATE - 1, 'YYYYMMDD');
--		  V_CURR_FSTD_YMD := TO_CHAR(V_CURR_DATE, 'YYYYMM') || '01';
--		  --V_NEXT_2WEK_YMD := TO_CHAR(V_CURR_DATE + 13, 'YYYYMMDD');
		  
--		  V_PREV_2WEK_YMD := TO_CHAR(V_CURR_DATE - 14, 'YYYYMMDD');
		  
		  IF P_DLVY_STATE = 'ALL' THEN
		  	 
			 OPEN RS FOR
			 	  WITH T AS (SELECT A.CL_SCN_CD,
			          	 		    C.DATA_SN,
			  					    C.QLTY_VEHL_CD,
                                    C.MDL_MDY_CD,
                                    C.LANG_CD,
                                    --'(' || C.QLTY_VEHL_CD || ')' || B.QLTY_VEHL_NM || '-' || C.MDL_MDY_CD || 'MY' AS QLTY_VEHL_NM,
									C.QLTY_VEHL_CD || '-' || C.MDL_MDY_CD AS QLTY_VEHL_NM,
                                    --C.LANG_CD_NM,
									'(' || C.LANG_CD || ')' || C.LANG_CD_NM AS LANG_CD_NM,
                                    C.DL_EXPD_REGN_CD,
									C.SORT_SN AS LANG_SORT_SN
                             FROM (SELECT QLTY_VEHL_CD,
                                          MAX(CL_SCN_CD) AS CL_SCN_CD
                                   FROM TB_AUTH_VEHL_MGMT
                                   WHERE MENU_ID = PG_COMMON.FU_RPAD(P_MENU_ID, 10)
                                   AND USER_EENO = PG_COMMON.FU_RPAD(P_USER_EENO, 7)
                                   AND QLTY_VEHL_CD = DECODE(P_VEHL_CD, 'ALL', QLTY_VEHL_CD, P_VEHL_CD)
                                   GROUP BY QLTY_VEHL_CD
                                  ) A,
                                  TB_VEHL_MGMT B,
                                  TB_LANG_MGMT C
                             WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
                             AND A.QLTY_VEHL_CD = C.QLTY_VEHL_CD
                             AND B.MDL_MDY_CD = C.MDL_MDY_CD
                             AND B.MDL_MDY_CD BETWEEN V_FROM_MDL_MDY AND V_TO_MDL_MDY
                             AND B.MDL_MDY_CD = DECODE(P_MDL_MDY , '', B.MDL_MDY_CD, P_MDL_MDY)
							 AND B.DL_EXPD_CO_CD = DECODE(P_EXPD_CO_CD, 'ALL', B.DL_EXPD_CO_CD, P_EXPD_CO_CD)
						     AND B.DL_EXPD_PAC_SCN_CD = DECODE(P_PAC_SCN_CD, 'ALL', B.DL_EXPD_PAC_SCN_CD, P_PAC_SCN_CD)
                             AND B.DL_EXPD_PDI_CD = DECODE(P_PDI_CD, 'ALL', B.DL_EXPD_PDI_CD, P_PDI_CD)
						     AND C.DL_EXPD_REGN_CD = DECODE(P_REGN_CD, 'ALL', C.DL_EXPD_REGN_CD, P_REGN_CD)
							 AND C.LANG_CD = 'KO'
                             --AND C.LANG_CD = DECODE(P_LANG_CD, 'ALL', C.LANG_CD, P_LANG_CD)
							 AND B.USE_YN = 'Y'
							 AND C.USE_YN = 'Y'
                            )
			      SELECT A.CL_SCN_CD,
			   		     A.DATA_SN,
					     A.QLTY_VEHL_CD,
					     A.MDL_MDY_CD,
					     A.LANG_CD,
					     A.DL_EXPD_REGN_CD,
					     A.QLTY_VEHL_NM,
					     A.LANG_CD_NM,
					     A.DL_EXPD_REGN_NM,
					     A.DAY3_PLAN_QTY,
					     A.CURR_MTH_TRWI_QTY,
					     A.PREV_1DAY_TRWI_QTY,
					     A.SEWHA_IV_QTY,
					     A.SEWHA_PRNT_YN, --세화 인쇄중 데이터 존재여부 확인 
					     A.SEWHA_DLVY_QTY,
					     A.GLOVIS_DEEI1_QTY,
						 A.GLOVIS_IV_QTY,
						 A.WEK2_TRWI_QTY,
						 A.DAY3_AFTR_IV_QTY,
						 A.WEK2_AFTR_IV_QTY,
						 A.GLOVIS_FNH_IV_YMD,
						 A.TOT_FNH_IV_YMD,
						 A.PRNT_STATE,
						 B.DL_EXPD_PRVS_NM AS PRNT_STATE_NM,
						 PLNT_DAY3_QTY_TEXT,
						 PLNT_WEK2_QTY_TEXT,
						 PLNT_YN
			      FROM (SELECT A.CL_SCN_CD,
			   		           A.DATA_SN,
					           A.QLTY_VEHL_CD,
					           A.MDL_MDY_CD,
					           A.LANG_CD,
					           A.DL_EXPD_REGN_CD,
					           A.QLTY_VEHL_NM,
					           A.LANG_CD_NM,
					           B.DL_EXPD_PRVS_NM AS DL_EXPD_REGN_NM,
					           A.DAY3_PLAN_QTY,
					           A.CURR_MTH_TRWI_QTY,
					           A.PREV_1DAY_TRWI_QTY,
					           A.SEWHA_IV_QTY,
					           A.SEWHA_PRNT_YN, --세화 인쇄중 데이터 존재여부 확인 
							   A.SEWHA_DLVY_QTY,
							   A.GLOVIS_DEEI1_QTY,
							   A.GLOVIS_IV_QTY,
							   A.WEK2_TRWI_QTY,
							   --[변경] 2010.01.26.김동근 예상재고(3일) 을 1주 일평균 투입수량 기준으로 변경함 
							   --(A.GLOVIS_IV_QTY - A.DAY3_PLAN_QTY) AS DAY3_AFTR_IV_QTY,
							   (A.GLOVIS_IV_QTY - (A.WEK2_TRWI_QTY * 3)) AS DAY3_AFTR_IV_QTY,
							   --[변경] 2010.01.26.김동근 예상재고(2주) 를 1주 일평균 투입수량 기준으로 변경함 
							   --(A.GLOVIS_IV_QTY + A.SEWHA_IV_QTY - (A.MTH3_TRWI_QTY * 14)) AS WEK2_AFTR_IV_QTY,
							   (A.GLOVIS_IV_QTY + A.SEWHA_IV_QTY - (A.WEK2_TRWI_QTY * 12)) AS WEK2_AFTR_IV_QTY,
							   TO_CHAR(V_CURR_DATE + A.GLOVIS_IV_DIFF, 'YYYY-MM-DD') AS GLOVIS_FNH_IV_YMD,
							   TO_CHAR(V_CURR_DATE + A.TOT_IV_DIFF, 'YYYY-MM-DD') AS TOT_FNH_IV_YMD,
							   CASE WHEN A.GLOVIS_IV_DIFF < 3 THEN '01'
							        WHEN A.TOT_IV_DIFF < 14 THEN '02'
									ELSE '03' 
							   END AS PRNT_STATE,
							   PLNT_DAY3_QTY_TEXT,
							   PLNT_WEK2_QTY_TEXT,
							   PLNT_YN
			         FROM (SELECT A.CL_SCN_CD,
			   				      A.DATA_SN,
							      A.QLTY_VEHL_CD,
							      A.MDL_MDY_CD,
							      A.LANG_CD,
							      A.DL_EXPD_REGN_CD,
							      A.QLTY_VEHL_NM,
							      A.LANG_CD_NM,
								  A.LANG_SORT_SN,
								  --CASE WHEN NVL(B.DAY3_PLAN_QTY1, 0) > NVL(B.DAY3_PLAN_QTY2, 0) THEN NVL(B.DAY3_PLAN_QTY1, 0)
     							  --     ELSE NVL(B.DAY3_PLAN_QTY2, 0)
								  --END AS DAY3_PLAN_QTY,
								  NVL(B.DAY3_PLAN_QTY1, 0) AS DAY3_PLAN_QTY,
								  NVL(B.CURR_MTH_TRWI_QTY, 0) AS CURR_MTH_TRWI_QTY,
							      NVL(B.PREV_1DAY_TRWI_QTY, 0) AS PREV_1DAY_TRWI_QTY,
							      NVL(C.SEWHA_IV_QTY, 0) AS SEWHA_IV_QTY,
							      NVL(C.SEWHA_PRNT_YN, 'N') AS SEWHA_PRNT_YN,
								  NVL(D.SEWHA_DLVY_QTY, 0) AS SEWHA_DLVY_QTY,
								  NVL(E.GLOVIS_DEEI1_QTY, 0) AS GLOVIS_DEEI1_QTY,
							      NVL(F.GLOVIS_IV_QTY, 0) AS GLOVIS_IV_QTY,
								  NVL(B.WEK2_TRWI_QTY, 0) AS WEK2_TRWI_QTY,
								  NVL(B.MTH3_TRWI_QTY, 0) AS MTH3_TRWI_QTY,
								  --[변경] 2010.01.26.김동근 재고소진일 계산 기준수량을 1주 일평균 투입수량으로 변경함 
								  /**
								  CASE WHEN NVL(B.MTH3_TRWI_QTY, 0) <> 0 THEN ROUND(NVL(F.GLOVIS_IV_QTY, 0) / NVL(B.MTH3_TRWI_QTY, 0)) 
								       ELSE 0 
								  END AS GLOVIS_IV_DIFF,
								  CASE WHEN NVL(B.MTH3_TRWI_QTY, 0) <> 0 THEN ROUND((NVL(C.SEWHA_IV_QTY, 0) + NVL(F.GLOVIS_IV_QTY, 0)) / NVL(B.MTH3_TRWI_QTY, 0)) 
								       ELSE 0 
								  END AS TOT_IV_DIFF 
								  **/
								  CASE WHEN NVL(B.WEK2_TRWI_QTY, 0) <> 0 THEN ROUND(NVL(F.GLOVIS_IV_QTY, 0) / NVL(B.WEK2_TRWI_QTY, 0)) 
								       ELSE 0 
								  END AS GLOVIS_IV_DIFF,
								  CASE WHEN NVL(B.WEK2_TRWI_QTY, 0) <> 0 THEN ROUND((NVL(C.SEWHA_IV_QTY, 0) + NVL(F.GLOVIS_IV_QTY, 0)) / NVL(B.WEK2_TRWI_QTY, 0)) 
								       ELSE 0 
								  END AS TOT_IV_DIFF,
								  NVL(G.PLNT_DAY3_QTY_TEXT, ' ') AS PLNT_DAY3_QTY_TEXT,
								  NVL(G.PLNT_WEK2_QTY_TEXT, ' ') AS PLNT_WEK2_QTY_TEXT,
								  NVL(G.PLNT_YN, 'N') AS PLNT_YN
			   		       FROM T A,
						        (SELECT A.QLTY_VEHL_CD, 
										A.MDL_MDY_CD, 
										A.LANG_CD,
										NVL(B.TDD_PRDN_PLN_QTY, 0) + NVL(B.TDD_PRDN_QTY3, 0) AS DAY3_PLAN_QTY1,
										--NVL(B.TDD_PRDN_QTY, 0) AS DAY3_PLAN_QTY2,
								  		NVL(B.TMM_TRWI_QTY, 0) AS CURR_MTH_TRWI_QTY,
								  		NVL(B.BOD_TRWI_QTY, 0) AS PREV_1DAY_TRWI_QTY,
										--[변경] 2010.01.26.김동근 2주 일평균 투입수량을 1주 일평균 투입 수량으로 변경함 
										--NVL(B.WEK2_DLY_AVG_TRWI_QTY, 0) AS WEK2_TRWI_QTY,
										NVL(B.WEK1_DLY_AVG_TRWI_QTY, 0) AS WEK2_TRWI_QTY,
										NVL(B.MTH3_DLY_AVG_TRWI_QTY, 0) AS MTH3_TRWI_QTY
								 FROM T A,
						         	  TB_APS_PROD_SUM_INFO B
						         WHERE A.DATA_SN = B.DATA_SN
						   		 AND B.APL_YMD = P_CURR_YMD
								) B,
        				        --세화재고
        				        (SELECT A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD, SUM(B.SFTY_IV_QTY) AS SEWHA_IV_QTY,
						                --인쇄중 데이터 존재 여부 확인 ==> DL_EXPD_TMP_IV_QTY 값은 인쇄중 이전인 경우에는 NULL, 인쇄중인경우에는 인쇄 수량, 납품이후에는 0으로 설정되어 있음 
						  		        CASE WHEN SUM(B.DL_EXPD_TMP_IV_QTY) > 0 THEN 'Y' ELSE 'N'END AS SEWHA_PRNT_YN
         				         FROM T A,
              				          TB_SEWHA_IV_INFO_DTL B
         				         WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
         				         AND A.MDL_MDY_CD = B.MDL_MDY_CD
         				         AND A.LANG_CD = B.LANG_CD
         				         AND B.CLS_YMD = P_CURR_YMD
								 AND B.SFTY_IV_QTY > 0 --안전재고수량이 없는 것은 가져오지 않는다. 
						         GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD
								
								 /*** 
								 SELECT A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD, SUM(IV_QTY) AS SEWHA_IV_QTY,
						                --인쇄중 데이터 존재 여부 확인 ==> DL_EXPD_TMP_IV_QTY 값은 인쇄중 이전인 경우에는 NULL, 인쇄중인경우에는 인쇄 수량, 납품이후에는 0으로 설정되어 있음 
						  		        CASE WHEN SUM(DL_EXPD_TMP_IV_QTY) > 0 THEN 'Y' ELSE 'N'END AS SEWHA_PRNT_YN
         				         FROM T A,
              		   		          TB_DL_EXPD_MDY_MGMT B,
              				          TB_SEWHA_IV_INFO C 
         				         WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
         				         AND A.MDL_MDY_CD = B.MDL_MDY_CD 
								 AND A.DL_EXPD_REGN_CD = B.DL_EXPD_REGN_CD 
         				         AND A.QLTY_VEHL_CD = C.QLTY_VEHL_CD
         				         AND B.DL_EXPD_MDL_MDY_CD = C.DL_EXPD_MDL_MDY_CD
         				         AND A.LANG_CD = C.LANG_CD
         				         AND C.CLS_YMD = P_CURR_YMD
						         GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD 
								 ***/
								 
                                ) C,
								--배송중 데이터 조회
								(SELECT A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD, SUM(B.RQ_QTY) AS SEWHA_DLVY_QTY
								 FROM T A,
									  TB_SEWHA_WHOT_INFO B
								 WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
         				         AND A.MDL_MDY_CD = B.MDL_MDY_CD
								 AND A.LANG_CD = B.LANG_CD
								 AND B.WHSN_YMD > P_CURR_YMD
								 AND B.WHOT_YMD <= P_CURR_YMD
								 AND B.DEL_YN = 'N'
								 GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD 
								 
								 /***
								 SELECT A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD, SUM(RQ_QTY) AS SEWHA_DLVY_QTY
								 FROM T A,
								      TB_DL_EXPD_MDY_MGMT B,
									  TB_SEWHA_WHOT_INFO C
								 WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
         				         AND A.MDL_MDY_CD = B.MDL_MDY_CD 
								 AND A.DL_EXPD_REGN_CD = B.DL_EXPD_REGN_CD 
         				         AND A.QLTY_VEHL_CD = C.QLTY_VEHL_CD
         				         AND B.DL_EXPD_MDL_MDY_CD = C.DL_EXPD_MDL_MDY_CD
								 AND A.LANG_CD = C.LANG_CD
								 AND C.WHSN_YMD > P_CURR_YMD
								 AND C.WHOT_YMD <= P_CURR_YMD
								 AND C.DEL_YN = 'N'
								 GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD 
								 ***/
								 
								) D,
								--입고확인 데이터 조회 
								(SELECT A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD,
										SUM(B.DEEI1_QTY) AS GLOVIS_DEEI1_QTY
								 FROM T A,
									  TB_PDI_WHSN_INFO B
								 WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
         				         AND A.MDL_MDY_CD = B.MDL_MDY_CD
								 AND A.LANG_CD = B.LANG_CD
								 AND B.WHSN_YMD = P_CURR_YMD
								 GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD 
								 
								 /***
								 SELECT A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD,
										SUM(DEEI1_QTY) AS GLOVIS_DEEI1_QTY
								 FROM T A,
								      TB_DL_EXPD_MDY_MGMT B,
									  TB_PDI_WHSN_INFO C
								 WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
         				         AND A.MDL_MDY_CD = B.MDL_MDY_CD 
								 AND A.DL_EXPD_REGN_CD = B.DL_EXPD_REGN_CD 
         				         AND A.QLTY_VEHL_CD = C.QLTY_VEHL_CD
         				         AND B.DL_EXPD_MDL_MDY_CD = C.DL_EXPD_MDL_MDY_CD
								 AND A.LANG_CD = C.LANG_CD
								 AND C.WHSN_YMD = P_CURR_YMD
								 GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD 
								 ***/
								 
								) E,
                                --글로비스재고
                                (SELECT A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD, SUM(B.SFTY_IV_QTY) AS GLOVIS_IV_QTY
                                 FROM T A,
                                      TB_PDI_IV_INFO_DTL B
                                 WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
                                 AND A.MDL_MDY_CD = B.MDL_MDY_CD
                                 AND A.LANG_CD = B.LANG_CD
                                 AND B.CLS_YMD = P_CURR_YMD
								 AND B.SFTY_IV_QTY > 0 --안전재고수량이 없는 것은 가져오지 않는다. 
						         GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD 
								 
								 /*** 
								 SELECT A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD, SUM(IV_QTY) AS GLOVIS_IV_QTY
                                 FROM T A,
                                      TB_DL_EXPD_MDY_MGMT B,
                                      TB_PDI_IV_INFO C
                                 WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
                                 AND A.MDL_MDY_CD = B.MDL_MDY_CD 
								 AND A.DL_EXPD_REGN_CD = B.DL_EXPD_REGN_CD 
                                 AND A.QLTY_VEHL_CD = C.QLTY_VEHL_CD
                                 AND B.DL_EXPD_MDL_MDY_CD = C.DL_EXPD_MDL_MDY_CD
                                 AND A.LANG_CD = C.LANG_CD
                                 AND C.CLS_YMD = P_CURR_YMD
						         GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD 
								 ***/
								 
                                ) F,
								(SELECT A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD,
										PG_TOT_IV_INFO.FU_GET_PLNT_DAY3_PLAN_QTY(P_CURR_YMD, A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD) AS PLNT_DAY3_QTY_TEXT,
										PG_TOT_IV_INFO.FU_GET_PLNT_WEK2_PLAN_QTY(P_CURR_YMD, A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD) AS PLNT_WEK2_QTY_TEXT,
										'Y' AS PLNT_YN
                                 FROM T A,
                                      TB_PLNT_APS_PROD_SUM_INFO B
                                 WHERE A.DATA_SN = B.DATA_SN
                                 AND B.APL_YMD = P_CURR_YMD
						         GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD
								) G
                           WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD(+)
                           AND A.MDL_MDY_CD = B.MDL_MDY_CD(+)
                           AND A.LANG_CD = B.LANG_CD(+)
                           AND A.QLTY_VEHL_CD = C.QLTY_VEHL_CD(+)
                           AND A.MDL_MDY_CD = C.MDL_MDY_CD(+)
                           AND A.LANG_CD = C.LANG_CD(+)
                           AND A.QLTY_VEHL_CD = D.QLTY_VEHL_CD(+)
                           AND A.MDL_MDY_CD = D.MDL_MDY_CD(+)
                           AND A.LANG_CD = D.LANG_CD(+)
                           AND A.QLTY_VEHL_CD = E.QLTY_VEHL_CD(+)
                           AND A.MDL_MDY_CD = E.MDL_MDY_CD(+)
                           AND A.LANG_CD = E.LANG_CD(+)
                           AND A.QLTY_VEHL_CD = F.QLTY_VEHL_CD(+)
                           AND A.MDL_MDY_CD = F.MDL_MDY_CD(+)
                           AND A.LANG_CD = F.LANG_CD(+)
						   AND A.QLTY_VEHL_CD = G.QLTY_VEHL_CD(+)
						   AND A.MDL_MDY_CD = G.MDL_MDY_CD(+)
						   AND A.LANG_CD = G.LANG_CD(+)
                           
					 	   /****  속도 개선을 위한 쿼리 변경 
					 	   SELECT A.CL_SCN_CD,
			   				      A.DATA_SN,
							      A.QLTY_VEHL_CD,
							      A.MDL_MDY_CD,
							      A.LANG_CD,
							      A.DL_EXPD_REGN_CD,
							      A.QLTY_VEHL_NM,
							      A.LANG_CD_NM,
			   				      NVL(B.DAY3_PLAN_QTY, 0) AS DAY3_PLAN_QTY,
							      NVL(C.CURR_MTH_TRWI_QTY, 0) AS CURR_MTH_TRWI_QTY,
							      NVL(D.PREV_1DAY_TRWI_QTY, 0) AS PREV_1DAY_TRWI_QTY,
							      NVL(E.SEWHA_IV_QTY, 0) AS SEWHA_IV_QTY,
							      NVL(E.SEWHA_PRNT_YN, 'N') AS SEWHA_PRNT_YN,
								  NVL(F.SEWHA_DLVY_QTY, 0) AS SEWHA_DLVY_QTY,
								  NVL(G.GLOVIS_DEEI1_QTY, 0) AS GLOVIS_DEEI1_QTY,
							      NVL(H.GLOVIS_IV_QTY, 0) AS GLOVIS_IV_QTY,
								  NVL(I.WEK2_TRWI_QTY, 0) AS WEK2_TRWI_QTY,
								  NVL(J.MTH3_TRWI_QTY, 0) AS MTH3_TRWI_QTY,
								  CASE WHEN NVL(J.MTH3_TRWI_QTY, 0) <> 0 THEN ROUND(NVL(H.GLOVIS_IV_QTY, 0) / NVL(J.MTH3_TRWI_QTY, 0)) 
								       ELSE 0 
								  END AS GLOVIS_IV_DIFF,
								  CASE WHEN NVL(J.MTH3_TRWI_QTY, 0) <> 0 THEN ROUND((NVL(E.SEWHA_IV_QTY, 0) + NVL(H.GLOVIS_IV_QTY, 0)) / NVL(J.MTH3_TRWI_QTY, 0)) 
								       ELSE 0 
								  END AS TOT_IV_DIFF
			   		       FROM T A,
                                --단기계획(3일)
                                (SELECT A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD, SUM(NVL(B.PRDN_PLN_QTY, 0) + NVL(C.PRDN_QTY, 0)) AS DAY3_PLAN_QTY
                                 FROM T A,
                                      TB_APS_PROD_PLAN_SUM_INFO B,
                                      TB_PROD_MST_SUM_INFO C
                                 WHERE A.DATA_SN = B.DATA_SN(+)
                                 AND A.DATA_SN = C.DATA_SN(+)
                                 AND B.APL_STRT_YMD(+) <= P_CURR_YMD
                                 AND B.APL_FNH_YMD(+) >= P_CURR_YMD
                                 AND B.PLN_PARR_YMD(+) = P_CURR_YMD
                                 AND C.APL_YMD(+) = P_CURR_YMD
                                 GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD
                                ) B,
        				        --당월출하누적 
        				        (SELECT A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD, SUM(PRDN_TRWI_QTY) AS CURR_MTH_TRWI_QTY
         				         FROM T A,
              		                  TB_PROD_MST_SUM_INFO B
         				         WHERE A.DATA_SN = B.DATA_SN
      				             AND B.APL_YMD BETWEEN V_CURR_FSTD_YMD AND P_CURR_YMD
      				             GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD
        				        ) C,
      				            --전일출하 
      				            (SELECT A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD, SUM(PRDN_TRWI_QTY) AS PREV_1DAY_TRWI_QTY
         				         FROM T A,
              		                  TB_PROD_MST_SUM_INFO B
         				         WHERE A.DATA_SN = B.DATA_SN
      				             AND B.APL_YMD = V_PREV_1DAY_YMD
      				             GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD
        				        ) D,
        				        --세화재고
        				        (SELECT A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD, SUM(IV_QTY) AS SEWHA_IV_QTY,
						                --인쇄중 데이터 존재 여부 확인 ==> DL_EXPD_TMP_IV_QTY 값은 인쇄중 이전인 경우에는 NULL, 인쇄중인경우에는 인쇄 수량, 납품이후에는 0으로 설정되어 있음 
						  		        CASE WHEN SUM(DL_EXPD_TMP_IV_QTY) > 0 THEN 'Y' ELSE 'N'END AS SEWHA_PRNT_YN
         				         FROM T A,
              		   		          TB_DL_EXPD_MDY_MGMT B,
              				          TB_SEWHA_IV_INFO C
         				         WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
         				         AND A.MDL_MDY_CD = B.MDL_MDY_CD 
								 AND A.DL_EXPD_REGN_CD = B.DL_EXPD_REGN_CD 
         				         AND A.QLTY_VEHL_CD = C.QLTY_VEHL_CD
         				         AND B.DL_EXPD_MDL_MDY_CD = C.DL_EXPD_MDL_MDY_CD
         				         AND A.LANG_CD = C.LANG_CD
         				         AND C.CLS_YMD = P_CURR_YMD
						         GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD
                                ) E,
								--배송중 데이터 조회
								(SELECT A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD, SUM(RQ_QTY) AS SEWHA_DLVY_QTY
								 FROM T A,
								      TB_DL_EXPD_MDY_MGMT B,
									  TB_SEWHA_WHOT_INFO C
								 WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
         				         AND A.MDL_MDY_CD = B.MDL_MDY_CD 
								 AND A.DL_EXPD_REGN_CD = B.DL_EXPD_REGN_CD 
         				         AND A.QLTY_VEHL_CD = C.QLTY_VEHL_CD
         				         AND B.DL_EXPD_MDL_MDY_CD = C.DL_EXPD_MDL_MDY_CD
								 AND C.WHSN_YMD > P_CURR_YMD
								 GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD
								) F,
								--입고확인 데이터 조회 
								(SELECT A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD,
										SUM(DEEI1_QTY) AS GLOVIS_DEEI1_QTY
								 FROM T A,
								      TB_DL_EXPD_MDY_MGMT B,
									  TB_PDI_WHSN_INFO C
								 WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
         				         AND A.MDL_MDY_CD = B.MDL_MDY_CD 
								 AND A.DL_EXPD_REGN_CD = B.DL_EXPD_REGN_CD 
         				         AND A.QLTY_VEHL_CD = C.QLTY_VEHL_CD
         				         AND B.DL_EXPD_MDL_MDY_CD = C.DL_EXPD_MDL_MDY_CD
								 AND C.WHSN_YMD = P_CURR_YMD
								 GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD
								) G,
                                --글로비스재고
                                (SELECT A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD, SUM(IV_QTY) AS GLOVIS_IV_QTY
                                 FROM T A,
                                      TB_DL_EXPD_MDY_MGMT B,
                                      TB_PDI_IV_INFO C
                                 WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
                                 AND A.MDL_MDY_CD = B.MDL_MDY_CD 
								 AND A.DL_EXPD_REGN_CD = B.DL_EXPD_REGN_CD 
                                 AND A.QLTY_VEHL_CD = C.QLTY_VEHL_CD
                                 AND B.DL_EXPD_MDL_MDY_CD = C.DL_EXPD_MDL_MDY_CD
                                 AND A.LANG_CD = C.LANG_CD
                                 AND C.CLS_YMD = P_CURR_YMD
						         GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD
                                ) H,
								--2주 일평균 출하량 
								(SELECT A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD, ROUND(AVG(PRDN_TRWI_QTY)) AS WEK2_TRWI_QTY
                                 FROM T A,
                                      TB_PROD_MST_SUM_INFO B
                                 WHERE A.DATA_SN = B.DATA_SN
                                 AND B.APL_YMD BETWEEN V_PREV_2WEK_YMD AND V_PREV_1DAY_YMD
                                 GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD
								) I,
								--3개월 일평균 출하량 
								(SELECT A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD, ROUND(AVG(PRDN_TRWI_QTY)) AS MTH3_TRWI_QTY
                                 FROM T A,
                                      TB_PROD_MST_SUM_INFO B
                                 WHERE A.DATA_SN = B.DATA_SN
                                 AND B.APL_YMD BETWEEN V_PREV_3MTH_YMD AND V_PREV_1MTH_YMD
                                 GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD
								) J
                           WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD(+)
                           AND A.MDL_MDY_CD = B.MDL_MDY_CD(+)
                           AND A.LANG_CD = B.LANG_CD(+)
                           AND A.QLTY_VEHL_CD = C.QLTY_VEHL_CD(+)
                           AND A.MDL_MDY_CD = C.MDL_MDY_CD(+)
                           AND A.LANG_CD = C.LANG_CD(+)
                           AND A.QLTY_VEHL_CD = D.QLTY_VEHL_CD(+)
                           AND A.MDL_MDY_CD = D.MDL_MDY_CD(+)
                           AND A.LANG_CD = D.LANG_CD(+)
                           AND A.QLTY_VEHL_CD = E.QLTY_VEHL_CD(+)
                           AND A.MDL_MDY_CD = E.MDL_MDY_CD(+)
                           AND A.LANG_CD = E.LANG_CD(+)
                           AND A.QLTY_VEHL_CD = F.QLTY_VEHL_CD(+)
                           AND A.MDL_MDY_CD = F.MDL_MDY_CD(+)
                           AND A.LANG_CD = F.LANG_CD(+)
                           AND A.QLTY_VEHL_CD = G.QLTY_VEHL_CD(+)
                           AND A.MDL_MDY_CD = G.MDL_MDY_CD(+)
                           AND A.LANG_CD = G.LANG_CD(+)
                           AND A.QLTY_VEHL_CD = H.QLTY_VEHL_CD(+)
                           AND A.MDL_MDY_CD = H.MDL_MDY_CD(+)
                           AND A.LANG_CD = H.LANG_CD(+)
						   AND A.QLTY_VEHL_CD = I.QLTY_VEHL_CD(+)
                           AND A.MDL_MDY_CD = I.MDL_MDY_CD(+)
                           AND A.LANG_CD = I.LANG_CD(+)
						   AND A.QLTY_VEHL_CD = J.QLTY_VEHL_CD(+)
                           AND A.MDL_MDY_CD = J.MDL_MDY_CD(+)
                           AND A.LANG_CD = J.LANG_CD(+)
						   ****/
						   
			             ) A,
				         TB_CODE_MGMT B
			         WHERE A.DL_EXPD_REGN_CD = B.DL_EXPD_PRVS_CD
			         AND B.DL_EXPD_G_CD = '0008'
			         AND DAY3_PLAN_QTY + CURR_MTH_TRWI_QTY + PREV_1DAY_TRWI_QTY + SEWHA_IV_QTY + SEWHA_DLVY_QTY + 
					     GLOVIS_DEEI1_QTY + GLOVIS_IV_QTY > 0
			         --ORDER BY QLTY_VEHL_NM, B.SORT_SN, LANG_CD_NM 
					 ORDER BY QLTY_VEHL_CD, LANG_SORT_SN, MDL_MDY_CD
					) A,
					TB_CODE_MGMT B
			    WHERE A.PRNT_STATE = B.DL_EXPD_PRVS_CD
				AND B.DL_EXPD_G_CD = '0022';
		  
		  --배송중인 데이터 조회인 경우 		
		  ELSIF P_DLVY_STATE = '01' THEN
		  		
		  		OPEN RS FOR
			 	  WITH T AS (SELECT A.CL_SCN_CD,
			          	 		    C.DATA_SN,
			  					    C.QLTY_VEHL_CD,
                                    C.MDL_MDY_CD,
                                    C.LANG_CD,
                                    --'(' || C.QLTY_VEHL_CD || ')' || B.QLTY_VEHL_NM || '-' || C.MDL_MDY_CD || 'MY' AS QLTY_VEHL_NM,
									C.QLTY_VEHL_CD || '-' || C.MDL_MDY_CD AS QLTY_VEHL_NM,
                                    --C.LANG_CD_NM,
									'(' || C.LANG_CD || ')' || C.LANG_CD_NM AS LANG_CD_NM,
                                    C.DL_EXPD_REGN_CD,
									C.SORT_SN AS LANG_SORT_SN
                             FROM (SELECT QLTY_VEHL_CD,
                                          MAX(CL_SCN_CD) AS CL_SCN_CD
                                   FROM TB_AUTH_VEHL_MGMT
                                   WHERE MENU_ID = PG_COMMON.FU_RPAD(P_MENU_ID, 10)
                                   AND USER_EENO = PG_COMMON.FU_RPAD(P_USER_EENO, 7)
                                   AND QLTY_VEHL_CD = DECODE(P_VEHL_CD, 'ALL', QLTY_VEHL_CD, P_VEHL_CD)
                                   GROUP BY QLTY_VEHL_CD
                                  ) A,
                                  TB_VEHL_MGMT B,
                                  TB_LANG_MGMT C
                             WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
                             AND A.QLTY_VEHL_CD = C.QLTY_VEHL_CD
                             AND B.MDL_MDY_CD = C.MDL_MDY_CD
                             AND B.MDL_MDY_CD BETWEEN V_FROM_MDL_MDY AND V_TO_MDL_MDY
                             AND B.MDL_MDY_CD = DECODE(P_MDL_MDY , '', B.MDL_MDY_CD, P_MDL_MDY)
						     AND B.DL_EXPD_PAC_SCN_CD = DECODE(P_PAC_SCN_CD, 'ALL', B.DL_EXPD_PAC_SCN_CD, P_PAC_SCN_CD)
                             AND B.DL_EXPD_PDI_CD = DECODE(P_PDI_CD, 'ALL', B.DL_EXPD_PDI_CD, P_PDI_CD)
						     AND C.DL_EXPD_REGN_CD = DECODE(P_REGN_CD, 'ALL', C.DL_EXPD_REGN_CD, P_REGN_CD)
							 AND C.LANG_CD = 'KO'
                             --AND C.LANG_CD = DECODE(P_LANG_CD, 'ALL', C.LANG_CD, P_LANG_CD)
							 AND B.USE_YN = 'Y'
							 AND C.USE_YN = 'Y'
                            )
			      SELECT A.CL_SCN_CD,
			   		     A.DATA_SN,
					     A.QLTY_VEHL_CD,
					     A.MDL_MDY_CD,
					     A.LANG_CD,
					     A.DL_EXPD_REGN_CD,
					     A.QLTY_VEHL_NM,
					     A.LANG_CD_NM,
					     A.DL_EXPD_REGN_NM,
					     A.DAY3_PLAN_QTY,
					     A.CURR_MTH_TRWI_QTY,
					     A.PREV_1DAY_TRWI_QTY,
					     A.SEWHA_IV_QTY,
					     A.SEWHA_PRNT_YN, --세화 인쇄중 데이터 존재여부 확인 
					     A.SEWHA_DLVY_QTY,
					     A.GLOVIS_DEEI1_QTY,
						 A.GLOVIS_IV_QTY,
						 A.WEK2_TRWI_QTY,
						 A.DAY3_AFTR_IV_QTY,
						 A.WEK2_AFTR_IV_QTY,
						 A.GLOVIS_FNH_IV_YMD,
						 A.TOT_FNH_IV_YMD,
						 A.PRNT_STATE,
						 B.DL_EXPD_PRVS_NM AS PRNT_STATE_NM,
						 PLNT_DAY3_QTY_TEXT,
						 PLNT_WEK2_QTY_TEXT,
						 PLNT_YN
			      FROM (SELECT A.CL_SCN_CD,
			   		           A.DATA_SN,
					           A.QLTY_VEHL_CD,
					           A.MDL_MDY_CD,
					           A.LANG_CD,
					           A.DL_EXPD_REGN_CD,
					           A.QLTY_VEHL_NM,
					           A.LANG_CD_NM,
					           B.DL_EXPD_PRVS_NM AS DL_EXPD_REGN_NM,
					           A.DAY3_PLAN_QTY,
					           A.CURR_MTH_TRWI_QTY,
					           A.PREV_1DAY_TRWI_QTY,
					           A.SEWHA_IV_QTY,
					           A.SEWHA_PRNT_YN, --세화 인쇄중 데이터 존재여부 확인 
							   A.SEWHA_DLVY_QTY,
							   0 AS GLOVIS_DEEI1_QTY,
							   A.GLOVIS_IV_QTY,
							   A.WEK2_TRWI_QTY,
							   --[변경] 2010.01.26.김동근 예상재고(3일) 을 1주 일평균 투입수량 기준으로 변경함 
							   --(A.GLOVIS_IV_QTY - A.DAY3_PLAN_QTY) AS DAY3_AFTR_IV_QTY,
							   (A.GLOVIS_IV_QTY - (A.WEK2_TRWI_QTY * 3)) AS DAY3_AFTR_IV_QTY,
							   --[변경] 2010.01.26.김동근 예상재고(2주) 를 1주 일평균 투입수량 기준으로 변경함 
							   --(A.GLOVIS_IV_QTY + A.SEWHA_IV_QTY - (A.MTH3_TRWI_QTY * 14)) AS WEK2_AFTR_IV_QTY,
							   (A.GLOVIS_IV_QTY + A.SEWHA_IV_QTY - (A.WEK2_TRWI_QTY * 12)) AS WEK2_AFTR_IV_QTY,
							   TO_CHAR(V_CURR_DATE + A.GLOVIS_IV_DIFF, 'YYYY-MM-DD') AS GLOVIS_FNH_IV_YMD,
							   TO_CHAR(V_CURR_DATE + A.TOT_IV_DIFF, 'YYYY-MM-DD') AS TOT_FNH_IV_YMD,
							   CASE WHEN A.GLOVIS_IV_DIFF < 3 THEN '01'
							        WHEN A.TOT_IV_DIFF < 14 THEN '02'
									ELSE '03' 
							   END AS PRNT_STATE,
							   PLNT_DAY3_QTY_TEXT,
							   PLNT_WEK2_QTY_TEXT,
							   PLNT_YN
			         FROM (SELECT A.CL_SCN_CD,
			   				      A.DATA_SN,
							      A.QLTY_VEHL_CD,
							      A.MDL_MDY_CD,
							      A.LANG_CD,
							      A.DL_EXPD_REGN_CD,
							      A.QLTY_VEHL_NM,
							      A.LANG_CD_NM,
								  A.LANG_SORT_SN,
								  --CASE WHEN NVL(B.DAY3_PLAN_QTY1, 0) > NVL(B.DAY3_PLAN_QTY2, 0) THEN NVL(B.DAY3_PLAN_QTY1, 0)
     							  --     ELSE NVL(B.DAY3_PLAN_QTY2, 0)
								  --END AS DAY3_PLAN_QTY,
								  NVL(B.DAY3_PLAN_QTY1, 0) AS DAY3_PLAN_QTY,
							      NVL(B.CURR_MTH_TRWI_QTY, 0) AS CURR_MTH_TRWI_QTY,
							      NVL(B.PREV_1DAY_TRWI_QTY, 0) AS PREV_1DAY_TRWI_QTY,
							      NVL(C.SEWHA_IV_QTY, 0) AS SEWHA_IV_QTY,
							      NVL(C.SEWHA_PRNT_YN, 'N') AS SEWHA_PRNT_YN,
								  NVL(D.SEWHA_DLVY_QTY, 0) AS SEWHA_DLVY_QTY,
							      NVL(E.GLOVIS_IV_QTY, 0) AS GLOVIS_IV_QTY,
								  NVL(B.WEK2_TRWI_QTY, 0) AS WEK2_TRWI_QTY,
								  NVL(B.MTH3_TRWI_QTY, 0) AS MTH3_TRWI_QTY,
								  --[변경] 2010.01.26.김동근 재고소진일 계산 기준수량을 1주 일평균 투입수량으로 변경함 
								  /**
								  CASE WHEN NVL(B.MTH3_TRWI_QTY, 0) <> 0 THEN ROUND(NVL(E.GLOVIS_IV_QTY, 0) / NVL(B.MTH3_TRWI_QTY, 0)) 
								       ELSE 0 
								  END AS GLOVIS_IV_DIFF,
								  CASE WHEN NVL(B.MTH3_TRWI_QTY, 0) <> 0 THEN ROUND((NVL(C.SEWHA_IV_QTY, 0) + NVL(E.GLOVIS_IV_QTY, 0)) / NVL(B.MTH3_TRWI_QTY, 0)) 
								       ELSE 0 
								  END AS TOT_IV_DIFF 
								  **/
								  CASE WHEN NVL(B.WEK2_TRWI_QTY, 0) <> 0 THEN ROUND(NVL(E.GLOVIS_IV_QTY, 0) / NVL(B.WEK2_TRWI_QTY, 0)) 
								       ELSE 0 
								  END AS GLOVIS_IV_DIFF,
								  CASE WHEN NVL(B.WEK2_TRWI_QTY, 0) <> 0 THEN ROUND((NVL(C.SEWHA_IV_QTY, 0) + NVL(E.GLOVIS_IV_QTY, 0)) / NVL(B.WEK2_TRWI_QTY, 0)) 
								       ELSE 0 
								  END AS TOT_IV_DIFF,
								  NVL(F.PLNT_DAY3_QTY_TEXT, ' ') AS PLNT_DAY3_QTY_TEXT,
								  NVL(F.PLNT_WEK2_QTY_TEXT, ' ') AS PLNT_WEK2_QTY_TEXT,
								  NVL(F.PLNT_YN, 'N') AS PLNT_YN 
			   		       FROM T A,
						        (SELECT A.QLTY_VEHL_CD, 
										A.MDL_MDY_CD, 
										A.LANG_CD,
										NVL(B.TDD_PRDN_PLN_QTY, 0) + NVL(B.TDD_PRDN_QTY3, 0) AS DAY3_PLAN_QTY1,
										--NVL(B.TDD_PRDN_QTY, 0) AS DAY3_PLAN_QTY2,
								  		NVL(B.TMM_TRWI_QTY, 0) AS CURR_MTH_TRWI_QTY,
								  		NVL(B.BOD_TRWI_QTY, 0) AS PREV_1DAY_TRWI_QTY,
										--[변경] 2010.01.26.김동근 2주 일평균 투입수량을 1주 일평균 투입 수량으로 변경함 
										--NVL(B.WEK2_DLY_AVG_TRWI_QTY, 0) AS WEK2_TRWI_QTY,
										NVL(B.WEK1_DLY_AVG_TRWI_QTY, 0) AS WEK2_TRWI_QTY,
										NVL(B.MTH3_DLY_AVG_TRWI_QTY, 0) AS MTH3_TRWI_QTY
								 FROM T A,
						         	  TB_APS_PROD_SUM_INFO B
						         WHERE A.DATA_SN = B.DATA_SN
						   		 AND B.APL_YMD = P_CURR_YMD
								) B,
        				        --세화재고
        				        (SELECT A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD, SUM(B.SFTY_IV_QTY) AS SEWHA_IV_QTY,
						                --인쇄중 데이터 존재 여부 확인 ==> DL_EXPD_TMP_IV_QTY 값은 인쇄중 이전인 경우에는 NULL, 인쇄중인경우에는 인쇄 수량, 납품이후에는 0으로 설정되어 있음 
						  		        CASE WHEN SUM(B.DL_EXPD_TMP_IV_QTY) > 0 THEN 'Y' ELSE 'N'END AS SEWHA_PRNT_YN
         				         FROM T A,
              				          TB_SEWHA_IV_INFO_DTL B
         				         WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
         				         AND A.MDL_MDY_CD = B.MDL_MDY_CD
         				         AND A.LANG_CD = B.LANG_CD
         				         AND B.CLS_YMD = P_CURR_YMD
								 AND B.SFTY_IV_QTY > 0 --안전재고수량이 없는 것은 가져오지 않는다. 
						         GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD 
								
								 /***
								 SELECT A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD, SUM(IV_QTY) AS SEWHA_IV_QTY,
						                --인쇄중 데이터 존재 여부 확인 ==> DL_EXPD_TMP_IV_QTY 값은 인쇄중 이전인 경우에는 NULL, 인쇄중인경우에는 인쇄 수량, 납품이후에는 0으로 설정되어 있음 
						  		        CASE WHEN SUM(DL_EXPD_TMP_IV_QTY) > 0 THEN 'Y' ELSE 'N'END AS SEWHA_PRNT_YN
         				         FROM T A,
              		   		          TB_DL_EXPD_MDY_MGMT B,
              				          TB_SEWHA_IV_INFO C
         				         WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
         				         AND A.MDL_MDY_CD = B.MDL_MDY_CD 
								 AND A.DL_EXPD_REGN_CD = B.DL_EXPD_REGN_CD 
         				         AND A.QLTY_VEHL_CD = C.QLTY_VEHL_CD
         				         AND B.DL_EXPD_MDL_MDY_CD = C.DL_EXPD_MDL_MDY_CD
         				         AND A.LANG_CD = C.LANG_CD
         				         AND C.CLS_YMD = P_CURR_YMD
						         GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD 
								 ***/
								 
                                ) C,
								--배송중 데이터 조회
								(SELECT A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD, SUM(B.RQ_QTY) AS SEWHA_DLVY_QTY
								 FROM T A,
									  TB_SEWHA_WHOT_INFO B
								 WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
         				         AND A.MDL_MDY_CD = B.MDL_MDY_CD
         				         AND A.LANG_CD = B.LANG_CD
								 AND B.WHSN_YMD > P_CURR_YMD
								 AND B.WHOT_YMD <= P_CURR_YMD
								 AND B.DEL_YN = 'N'
								 GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD
								 
								 /*** 
								 SELECT A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD, SUM(RQ_QTY) AS SEWHA_DLVY_QTY
								 FROM T A,
								      TB_DL_EXPD_MDY_MGMT B,
									  TB_SEWHA_WHOT_INFO C
								 WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
         				         AND A.MDL_MDY_CD = B.MDL_MDY_CD 
								 AND A.DL_EXPD_REGN_CD = B.DL_EXPD_REGN_CD 
         				         AND A.QLTY_VEHL_CD = C.QLTY_VEHL_CD
         				         AND B.DL_EXPD_MDL_MDY_CD = C.DL_EXPD_MDL_MDY_CD
								 AND A.LANG_CD = C.LANG_CD
								 AND C.WHSN_YMD > P_CURR_YMD
								 AND C.WHOT_YMD <= P_CURR_YMD
								 AND C.DEL_YN = 'N'
								 GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD 
								 ***/
								 
								) D,
                                --글로비스재고
                                (SELECT A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD, SUM(B.SFTY_IV_QTY) AS GLOVIS_IV_QTY
                                 FROM T A,
                                      TB_PDI_IV_INFO_DTL B
                                 WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
                                 AND A.MDL_MDY_CD = B.MDL_MDY_CD
                                 AND A.LANG_CD = B.LANG_CD
                                 AND B.CLS_YMD = P_CURR_YMD
								 AND B.SFTY_IV_QTY > 0 --안전재고수량이 없는 것은 가져오지 않는다. 
						         GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD 
								 
								 /*** 
								 SELECT A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD, SUM(IV_QTY) AS GLOVIS_IV_QTY
                                 FROM T A,
                                      TB_DL_EXPD_MDY_MGMT B,
                                      TB_PDI_IV_INFO C
                                 WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
                                 AND A.MDL_MDY_CD = B.MDL_MDY_CD 
								 AND A.DL_EXPD_REGN_CD = B.DL_EXPD_REGN_CD 
                                 AND A.QLTY_VEHL_CD = C.QLTY_VEHL_CD
                                 AND B.DL_EXPD_MDL_MDY_CD = C.DL_EXPD_MDL_MDY_CD
                                 AND A.LANG_CD = C.LANG_CD
                                 AND C.CLS_YMD = P_CURR_YMD
						         GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD 
								 ***/
								 
                                ) E,
								(SELECT A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD,
										PG_TOT_IV_INFO.FU_GET_PLNT_DAY3_PLAN_QTY(P_CURR_YMD, A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD) AS PLNT_DAY3_QTY_TEXT,
										PG_TOT_IV_INFO.FU_GET_PLNT_WEK2_PLAN_QTY(P_CURR_YMD, A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD) AS PLNT_WEK2_QTY_TEXT,
										'Y' AS PLNT_YN
                                 FROM T A,
                                      TB_PLNT_APS_PROD_SUM_INFO B
                                 WHERE A.DATA_SN = B.DATA_SN
                                 AND B.APL_YMD = P_CURR_YMD
						         GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD
								) F 
                           WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD(+)
                           AND A.MDL_MDY_CD = B.MDL_MDY_CD(+)
                           AND A.LANG_CD = B.LANG_CD(+)
                           AND A.QLTY_VEHL_CD = C.QLTY_VEHL_CD(+)
                           AND A.MDL_MDY_CD = C.MDL_MDY_CD(+)
                           AND A.LANG_CD = C.LANG_CD(+)
						   --배송중인 데이터만을 표시해 주기 위해서 OUTER JOIN을 빼준다..
                           AND A.QLTY_VEHL_CD = D.QLTY_VEHL_CD
                           AND A.MDL_MDY_CD = D.MDL_MDY_CD
                           AND A.LANG_CD = D.LANG_CD
                           AND A.QLTY_VEHL_CD = E.QLTY_VEHL_CD(+)
                           AND A.MDL_MDY_CD = E.MDL_MDY_CD(+)
                           AND A.LANG_CD = E.LANG_CD(+)
						   AND A.QLTY_VEHL_CD = F.QLTY_VEHL_CD(+)
						   AND A.MDL_MDY_CD = F.MDL_MDY_CD(+)
						   AND A.LANG_CD = F.LANG_CD(+)
						   
					       /****  속도 개선을 위한 쿼리 변경 
					       SELECT A.CL_SCN_CD,
			   				      A.DATA_SN,
							      A.QLTY_VEHL_CD,
							      A.MDL_MDY_CD,
							      A.LANG_CD,
							      A.DL_EXPD_REGN_CD,
							      A.QLTY_VEHL_NM,
							      A.LANG_CD_NM,
			   				      NVL(B.DAY3_PLAN_QTY, 0) AS DAY3_PLAN_QTY,
							      NVL(C.CURR_MTH_TRWI_QTY, 0) AS CURR_MTH_TRWI_QTY,
							      NVL(D.PREV_1DAY_TRWI_QTY, 0) AS PREV_1DAY_TRWI_QTY,
							      NVL(E.SEWHA_IV_QTY, 0) AS SEWHA_IV_QTY,
							      NVL(E.SEWHA_PRNT_YN, 'N') AS SEWHA_PRNT_YN,
								  NVL(F.SEWHA_DLVY_QTY, 0) AS SEWHA_DLVY_QTY,
							      NVL(G.GLOVIS_IV_QTY, 0) AS GLOVIS_IV_QTY,
								  NVL(H.WEK2_TRWI_QTY, 0) AS WEK2_TRWI_QTY,
								  NVL(I.MTH3_TRWI_QTY, 0) AS MTH3_TRWI_QTY,
								  CASE WHEN NVL(I.MTH3_TRWI_QTY, 0) <> 0 THEN ROUND(NVL(G.GLOVIS_IV_QTY, 0) / NVL(I.MTH3_TRWI_QTY, 0)) 
								       ELSE 0 
								  END AS GLOVIS_IV_DIFF,
								  CASE WHEN NVL(I.MTH3_TRWI_QTY, 0) <> 0 THEN ROUND((NVL(E.SEWHA_IV_QTY, 0) + NVL(G.GLOVIS_IV_QTY, 0)) / NVL(I.MTH3_TRWI_QTY, 0)) 
								       ELSE 0 
								  END AS TOT_IV_DIFF
			   		       FROM T A,
                                --단기계획(3일)
                                (SELECT A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD, SUM(NVL(B.PRDN_PLN_QTY, 0) + NVL(C.PRDN_QTY, 0)) AS DAY3_PLAN_QTY
                                 FROM T A,
                                      TB_APS_PROD_PLAN_SUM_INFO B,
                                      TB_PROD_MST_SUM_INFO C
                                 WHERE A.DATA_SN = B.DATA_SN(+)
                                 AND A.DATA_SN = C.DATA_SN(+)
                                 AND B.APL_STRT_YMD(+) <= P_CURR_YMD
                                 AND B.APL_FNH_YMD(+) >= P_CURR_YMD
                                 AND B.PLN_PARR_YMD(+) = P_CURR_YMD
                                 AND C.APL_YMD(+) = P_CURR_YMD
                                 GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD
                                ) B,
        				        --당월투입
        				        (SELECT A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD, SUM(PRDN_TRWI_QTY) AS CURR_MTH_TRWI_QTY
         				         FROM T A,
              		                  TB_PROD_MST_SUM_INFO B
         				         WHERE A.DATA_SN = B.DATA_SN
      				             AND B.APL_YMD BETWEEN V_CURR_FSTD_YMD AND P_CURR_YMD
      				             GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD
        				        ) C,
      				            --전일투입
      				            (SELECT A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD, SUM(PRDN_TRWI_QTY) AS PREV_1DAY_TRWI_QTY
         				         FROM T A,
              		                  TB_PROD_MST_SUM_INFO B
         				         WHERE A.DATA_SN = B.DATA_SN
      				             AND B.APL_YMD = V_PREV_1DAY_YMD
      				             GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD
        				        ) D,
        				        --세화재고
        				        (SELECT A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD, SUM(IV_QTY) AS SEWHA_IV_QTY,
						                --인쇄중 데이터 존재 여부 확인 ==> DL_EXPD_TMP_IV_QTY 값은 인쇄중 이전인 경우에는 NULL, 인쇄중인경우에는 인쇄 수량, 납품이후에는 0으로 설정되어 있음 
						  		        CASE WHEN SUM(DL_EXPD_TMP_IV_QTY) > 0 THEN 'Y' ELSE 'N'END AS SEWHA_PRNT_YN
         				         FROM T A,
              		   		          TB_DL_EXPD_MDY_MGMT B,
              				          TB_SEWHA_IV_INFO C
         				         WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
         				         AND A.MDL_MDY_CD = B.MDL_MDY_CD 
								 AND A.DL_EXPD_REGN_CD = B.DL_EXPD_REGN_CD 
         				         AND A.QLTY_VEHL_CD = C.QLTY_VEHL_CD
         				         AND B.DL_EXPD_MDL_MDY_CD = C.DL_EXPD_MDL_MDY_CD
         				         AND A.LANG_CD = C.LANG_CD
         				         AND C.CLS_YMD = P_CURR_YMD
						         GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD
                                ) E,
								--배송중 데이터 조회
								(SELECT A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD, SUM(RQ_QTY) AS SEWHA_DLVY_QTY
								 FROM T A,
								      TB_DL_EXPD_MDY_MGMT B,
									  TB_SEWHA_WHOT_INFO C
								 WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
         				         AND A.MDL_MDY_CD = B.MDL_MDY_CD 
								 AND A.DL_EXPD_REGN_CD = B.DL_EXPD_REGN_CD 
         				         AND A.QLTY_VEHL_CD = C.QLTY_VEHL_CD
         				         AND B.DL_EXPD_MDL_MDY_CD = C.DL_EXPD_MDL_MDY_CD
								 AND C.WHSN_YMD > P_CURR_YMD
								 GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD
								) F,
                                --글로비스재고
                                (SELECT A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD, SUM(IV_QTY) AS GLOVIS_IV_QTY
                                 FROM T A,
                                      TB_DL_EXPD_MDY_MGMT B,
                                      TB_PDI_IV_INFO C
                                 WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
                                 AND A.MDL_MDY_CD = B.MDL_MDY_CD 
								 AND A.DL_EXPD_REGN_CD = B.DL_EXPD_REGN_CD 
                                 AND A.QLTY_VEHL_CD = C.QLTY_VEHL_CD 
                                 AND B.DL_EXPD_MDL_MDY_CD = C.DL_EXPD_MDL_MDY_CD
                                 AND A.LANG_CD = C.LANG_CD
                                 AND C.CLS_YMD = P_CURR_YMD
						         GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD
                                ) G,
								--2주 일평균 출하량 
								(SELECT A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD, ROUND(AVG(PRDN_TRWI_QTY)) AS WEK2_TRWI_QTY
                                 FROM T A,
                                      TB_PROD_MST_SUM_INFO B
                                 WHERE A.DATA_SN = B.DATA_SN
                                 AND B.APL_YMD BETWEEN V_PREV_2WEK_YMD AND V_PREV_1DAY_YMD
                                 GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD
								) H,
								--3개월 일평균 출하량 
								(SELECT A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD, ROUND(AVG(PRDN_TRWI_QTY)) AS MTH3_TRWI_QTY
                                 FROM T A,
                                      TB_PROD_MST_SUM_INFO B
                                 WHERE A.DATA_SN = B.DATA_SN
                                 AND B.APL_YMD BETWEEN V_PREV_3MTH_YMD AND V_PREV_1MTH_YMD
                                 GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD
								) I
                           WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD(+)
                           AND A.MDL_MDY_CD = B.MDL_MDY_CD(+)
                           AND A.LANG_CD = B.LANG_CD(+)
                           AND A.QLTY_VEHL_CD = C.QLTY_VEHL_CD(+)
                           AND A.MDL_MDY_CD = C.MDL_MDY_CD(+)
                           AND A.LANG_CD = C.LANG_CD(+)
                           AND A.QLTY_VEHL_CD = D.QLTY_VEHL_CD(+)
                           AND A.MDL_MDY_CD = D.MDL_MDY_CD(+)
                           AND A.LANG_CD = D.LANG_CD(+)
                           AND A.QLTY_VEHL_CD = E.QLTY_VEHL_CD(+)
                           AND A.MDL_MDY_CD = E.MDL_MDY_CD(+)
                           AND A.LANG_CD = E.LANG_CD(+)
                           AND A.QLTY_VEHL_CD = F.QLTY_VEHL_CD(+)
                           AND A.MDL_MDY_CD = F.MDL_MDY_CD(+)
                           AND A.LANG_CD = F.LANG_CD(+)
                           AND A.QLTY_VEHL_CD = G.QLTY_VEHL_CD(+)
                           AND A.MDL_MDY_CD = G.MDL_MDY_CD(+)
                           AND A.LANG_CD = G.LANG_CD(+)
                           AND A.QLTY_VEHL_CD = H.QLTY_VEHL_CD(+)
                           AND A.MDL_MDY_CD = H.MDL_MDY_CD(+)
                           AND A.LANG_CD = H.LANG_CD(+)
						   AND A.QLTY_VEHL_CD = I.QLTY_VEHL_CD(+)
                           AND A.MDL_MDY_CD = I.MDL_MDY_CD(+)
                           AND A.LANG_CD = I.LANG_CD(+) 
						   ****/
						   
			             ) A,
				         TB_CODE_MGMT B
			         WHERE A.DL_EXPD_REGN_CD = B.DL_EXPD_PRVS_CD
			         AND B.DL_EXPD_G_CD = '0008'
			         AND DAY3_PLAN_QTY + CURR_MTH_TRWI_QTY + PREV_1DAY_TRWI_QTY + SEWHA_IV_QTY + SEWHA_DLVY_QTY + 
					 	 GLOVIS_IV_QTY > 0
			         --ORDER BY QLTY_VEHL_NM, B.SORT_SN, LANG_CD_NM 
					 ORDER BY QLTY_VEHL_CD, LANG_SORT_SN, MDL_MDY_CD
					) A,
					TB_CODE_MGMT B
			    WHERE A.PRNT_STATE = B.DL_EXPD_PRVS_CD
				AND B.DL_EXPD_G_CD = '0022';
		  
		  ELSE
		  	  
			  --배송완료된 데이터 조회인 경우
			  	
		  	  OPEN RS FOR
			 	  WITH T AS (SELECT A.CL_SCN_CD,
			          	 		    C.DATA_SN,
			  					    C.QLTY_VEHL_CD,
                                    C.MDL_MDY_CD,
                                    C.LANG_CD,
                                    --'(' || C.QLTY_VEHL_CD || ')' || B.QLTY_VEHL_NM || '-' || C.MDL_MDY_CD || 'MY' AS QLTY_VEHL_NM,
									C.QLTY_VEHL_CD || '-' || C.MDL_MDY_CD AS QLTY_VEHL_NM,
                                    --C.LANG_CD_NM,
									'(' || C.LANG_CD || ')' || C.LANG_CD_NM AS LANG_CD_NM,
                                    C.DL_EXPD_REGN_CD,
									C.SORT_SN AS LANG_SORT_SN
                             FROM (SELECT QLTY_VEHL_CD,
                                          MAX(CL_SCN_CD) AS CL_SCN_CD
                                   FROM TB_AUTH_VEHL_MGMT
                                   WHERE MENU_ID = PG_COMMON.FU_RPAD(P_MENU_ID, 10)
                                   AND USER_EENO = PG_COMMON.FU_RPAD(P_USER_EENO, 7)
                                   AND QLTY_VEHL_CD = DECODE(P_VEHL_CD, 'ALL', QLTY_VEHL_CD, P_VEHL_CD)
                                   GROUP BY QLTY_VEHL_CD
                                  ) A,
                                  TB_VEHL_MGMT B,
                                  TB_LANG_MGMT C
                             WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
                             AND A.QLTY_VEHL_CD = C.QLTY_VEHL_CD
                             AND B.MDL_MDY_CD = C.MDL_MDY_CD
                             AND B.MDL_MDY_CD BETWEEN V_FROM_MDL_MDY AND V_TO_MDL_MDY
                             AND B.MDL_MDY_CD = DECODE(P_MDL_MDY , '', B.MDL_MDY_CD, P_MDL_MDY)
						     AND B.DL_EXPD_PAC_SCN_CD = DECODE(P_PAC_SCN_CD, 'ALL', B.DL_EXPD_PAC_SCN_CD, P_PAC_SCN_CD)
                             AND B.DL_EXPD_PDI_CD = DECODE(P_PDI_CD, 'ALL', B.DL_EXPD_PDI_CD, P_PDI_CD)
						     AND C.DL_EXPD_REGN_CD = DECODE(P_REGN_CD, 'ALL', C.DL_EXPD_REGN_CD, P_REGN_CD)
							 AND C.LANG_CD = 'KO'
                             --AND C.LANG_CD = DECODE(P_LANG_CD, 'ALL', C.LANG_CD, P_LANG_CD)
							 AND B.USE_YN = 'Y'
							 AND C.USE_YN = 'Y'
                            )
			      SELECT A.CL_SCN_CD,
			   		     A.DATA_SN,
					     A.QLTY_VEHL_CD,
					     A.MDL_MDY_CD,
					     A.LANG_CD,
					     A.DL_EXPD_REGN_CD,
					     A.QLTY_VEHL_NM,
					     A.LANG_CD_NM,
					     A.DL_EXPD_REGN_NM,
					     A.DAY3_PLAN_QTY,
					     A.CURR_MTH_TRWI_QTY,
					     A.PREV_1DAY_TRWI_QTY,
					     A.SEWHA_IV_QTY,
					     A.SEWHA_PRNT_YN, --세화 인쇄중 데이터 존재여부 확인 
					     A.SEWHA_DLVY_QTY,
					     A.GLOVIS_DEEI1_QTY,
						 A.GLOVIS_IV_QTY,
						 A.WEK2_TRWI_QTY,
						 A.DAY3_AFTR_IV_QTY,
						 A.WEK2_AFTR_IV_QTY,
						 A.GLOVIS_FNH_IV_YMD,
						 A.TOT_FNH_IV_YMD,
						 A.PRNT_STATE,
						 B.DL_EXPD_PRVS_NM AS PRNT_STATE_NM,
						 PLNT_DAY3_QTY_TEXT,
					 	 PLNT_WEK2_QTY_TEXT,
						 PLNT_YN
			      FROM (SELECT A.CL_SCN_CD,
			   		           A.DATA_SN,
					           A.QLTY_VEHL_CD,
					           A.MDL_MDY_CD,
					           A.LANG_CD,
					           A.DL_EXPD_REGN_CD,
					           A.QLTY_VEHL_NM,
					           A.LANG_CD_NM,
					           B.DL_EXPD_PRVS_NM AS DL_EXPD_REGN_NM,
					           A.DAY3_PLAN_QTY,
					           A.CURR_MTH_TRWI_QTY,
					           A.PREV_1DAY_TRWI_QTY,
					           A.SEWHA_IV_QTY,
					           A.SEWHA_PRNT_YN, --세화 인쇄중 데이터 존재여부 확인 
							   0 AS SEWHA_DLVY_QTY,
							   A.GLOVIS_DEEI1_QTY,
							   A.GLOVIS_IV_QTY,
							   A.WEK2_TRWI_QTY,
							   --[변경] 2010.01.26.김동근 예상재고(3일) 을 1주 일평균 투입수량 기준으로 변경함 
							   --(A.GLOVIS_IV_QTY - A.DAY3_PLAN_QTY) AS DAY3_AFTR_IV_QTY,
							   (A.GLOVIS_IV_QTY - (A.WEK2_TRWI_QTY * 3)) AS DAY3_AFTR_IV_QTY,
							   --[변경] 2010.01.26.김동근 예상재고(2주) 를 1주 일평균 투입수량 기준으로 변경함 
							   --(A.GLOVIS_IV_QTY + A.SEWHA_IV_QTY - (A.MTH3_TRWI_QTY * 14)) AS WEK2_AFTR_IV_QTY,
							   (A.GLOVIS_IV_QTY + A.SEWHA_IV_QTY - (A.WEK2_TRWI_QTY * 12)) AS WEK2_AFTR_IV_QTY,
							   TO_CHAR(V_CURR_DATE + A.GLOVIS_IV_DIFF, 'YYYY-MM-DD') AS GLOVIS_FNH_IV_YMD,
							   TO_CHAR(V_CURR_DATE + A.TOT_IV_DIFF, 'YYYY-MM-DD') AS TOT_FNH_IV_YMD,
							   CASE WHEN A.GLOVIS_IV_DIFF < 3 THEN '01'
							        WHEN A.TOT_IV_DIFF < 14 THEN '02'
									ELSE '03' 
							   END AS PRNT_STATE,
							   PLNT_DAY3_QTY_TEXT,
							   PLNT_WEK2_QTY_TEXT,
							   PLNT_YN
			         FROM (SELECT A.CL_SCN_CD,
			   				      A.DATA_SN,
							      A.QLTY_VEHL_CD,
							      A.MDL_MDY_CD,
							      A.LANG_CD,
							      A.DL_EXPD_REGN_CD,
							      A.QLTY_VEHL_NM,
							      A.LANG_CD_NM,
								  A.LANG_SORT_SN,
								  --CASE WHEN NVL(B.DAY3_PLAN_QTY1, 0) > NVL(B.DAY3_PLAN_QTY2, 0) THEN NVL(B.DAY3_PLAN_QTY1, 0)
     							  --     ELSE NVL(B.DAY3_PLAN_QTY2, 0)
								  --END AS DAY3_PLAN_QTY,
								  NVL(B.DAY3_PLAN_QTY1, 0) AS DAY3_PLAN_QTY,
							      NVL(B.CURR_MTH_TRWI_QTY, 0) AS CURR_MTH_TRWI_QTY,
							      NVL(B.PREV_1DAY_TRWI_QTY, 0) AS PREV_1DAY_TRWI_QTY,
							      NVL(C.SEWHA_IV_QTY, 0) AS SEWHA_IV_QTY,
							      NVL(C.SEWHA_PRNT_YN, 'N') AS SEWHA_PRNT_YN,
								  NVL(D.GLOVIS_DEEI1_QTY, 0) AS GLOVIS_DEEI1_QTY,
							      NVL(E.GLOVIS_IV_QTY, 0) AS GLOVIS_IV_QTY,
								  NVL(B.WEK2_TRWI_QTY, 0) AS WEK2_TRWI_QTY,
								  NVL(B.MTH3_TRWI_QTY, 0) AS MTH3_TRWI_QTY,
								  --[변경] 2010.01.26.김동근 재고소진일 계산 기준수량을 1주 일평균 투입수량으로 변경함 
								  /**
								  CASE WHEN NVL(B.MTH3_TRWI_QTY, 0) <> 0 THEN ROUND(NVL(E.GLOVIS_IV_QTY, 0) / NVL(B.MTH3_TRWI_QTY, 0)) 
								       ELSE 0 
								  END AS GLOVIS_IV_DIFF,
								  CASE WHEN NVL(B.MTH3_TRWI_QTY, 0) <> 0 THEN ROUND((NVL(C.SEWHA_IV_QTY, 0) + NVL(E.GLOVIS_IV_QTY, 0)) / NVL(B.MTH3_TRWI_QTY, 0)) 
								       ELSE 0 
								  END AS TOT_IV_DIFF 
								  **/
								  CASE WHEN NVL(B.WEK2_TRWI_QTY, 0) <> 0 THEN ROUND(NVL(E.GLOVIS_IV_QTY, 0) / NVL(B.WEK2_TRWI_QTY, 0)) 
								       ELSE 0 
								  END AS GLOVIS_IV_DIFF,
								  CASE WHEN NVL(B.WEK2_TRWI_QTY, 0) <> 0 THEN ROUND((NVL(C.SEWHA_IV_QTY, 0) + NVL(E.GLOVIS_IV_QTY, 0)) / NVL(B.WEK2_TRWI_QTY, 0)) 
								       ELSE 0 
								  END AS TOT_IV_DIFF,
								  NVL(F.PLNT_DAY3_QTY_TEXT, ' ') AS PLNT_DAY3_QTY_TEXT,
								  NVL(F.PLNT_WEK2_QTY_TEXT, ' ') AS PLNT_WEK2_QTY_TEXT,
								  NVL(F.PLNT_YN, 'N') AS PLNT_YN
			   		       FROM T A,
						        (SELECT A.QLTY_VEHL_CD, 
										A.MDL_MDY_CD, 
										A.LANG_CD,
										NVL(B.TDD_PRDN_PLN_QTY, 0) + NVL(B.TDD_PRDN_QTY3, 0) AS DAY3_PLAN_QTY1,
										--NVL(B.TDD_PRDN_QTY, 0) AS DAY3_PLAN_QTY2,
								  		NVL(B.TMM_TRWI_QTY, 0) AS CURR_MTH_TRWI_QTY,
								  		NVL(B.BOD_TRWI_QTY, 0) AS PREV_1DAY_TRWI_QTY,
										--[변경] 2010.01.26.김동근 2주 일평균 투입수량을 1주 일평균 투입 수량으로 변경함 
										--NVL(B.WEK2_DLY_AVG_TRWI_QTY, 0) AS WEK2_TRWI_QTY,
										NVL(B.WEK1_DLY_AVG_TRWI_QTY, 0) AS WEK2_TRWI_QTY,
										NVL(B.MTH3_DLY_AVG_TRWI_QTY, 0) AS MTH3_TRWI_QTY
								 FROM T A,
						         	  TB_APS_PROD_SUM_INFO B
						         WHERE A.DATA_SN = B.DATA_SN
						   		 AND B.APL_YMD = P_CURR_YMD
								) B,
        				        --세화재고
        				        (SELECT A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD, SUM(B.SFTY_IV_QTY) AS SEWHA_IV_QTY,
						                --인쇄중 데이터 존재 여부 확인 ==> DL_EXPD_TMP_IV_QTY 값은 인쇄중 이전인 경우에는 NULL, 인쇄중인경우에는 인쇄 수량, 납품이후에는 0으로 설정되어 있음 
						  		        CASE WHEN SUM(B.DL_EXPD_TMP_IV_QTY) > 0 THEN 'Y' ELSE 'N'END AS SEWHA_PRNT_YN
         				         FROM T A,
              				          TB_SEWHA_IV_INFO_DTL B
         				         WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
         				         AND A.MDL_MDY_CD = B.MDL_MDY_CD
         				    	 AND A.LANG_CD = B.LANG_CD
         				         AND B.CLS_YMD = P_CURR_YMD
								 AND B.SFTY_IV_QTY > 0 --안전재고수량이 없는 것은 가져오지 않는다. 
						         GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD 
								 
								 /***
								 SELECT A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD, SUM(IV_QTY) AS SEWHA_IV_QTY,
						                --인쇄중 데이터 존재 여부 확인 ==> DL_EXPD_TMP_IV_QTY 값은 인쇄중 이전인 경우에는 NULL, 인쇄중인경우에는 인쇄 수량, 납품이후에는 0으로 설정되어 있음 
						  		        CASE WHEN SUM(DL_EXPD_TMP_IV_QTY) > 0 THEN 'Y' ELSE 'N'END AS SEWHA_PRNT_YN
         				         FROM T A,
              		   		          TB_DL_EXPD_MDY_MGMT B,
              				          TB_SEWHA_IV_INFO C
         				         WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
         				         AND A.MDL_MDY_CD = B.MDL_MDY_CD 
								 AND A.DL_EXPD_REGN_CD = B.DL_EXPD_REGN_CD 
         				         AND A.QLTY_VEHL_CD = C.QLTY_VEHL_CD
         				         AND B.DL_EXPD_MDL_MDY_CD = C.DL_EXPD_MDL_MDY_CD
         				         AND A.LANG_CD = C.LANG_CD
         				         AND C.CLS_YMD = P_CURR_YMD
						         GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD 
								 ***/
								 
                                ) C,
								--입고확인 데이터 조회 
								(SELECT A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD, 
										SUM(B.DEEI1_QTY) AS GLOVIS_DEEI1_QTY
								 FROM T A,
									  TB_PDI_WHSN_INFO B
								 WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
         				         AND A.MDL_MDY_CD = B.MDL_MDY_CD
         				         AND A.LANG_CD = B.LANG_CD
								 AND B.WHSN_YMD = P_CURR_YMD
								 GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD
								 
								 /***
								 SELECT A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD, 
										SUM(DEEI1_QTY) AS GLOVIS_DEEI1_QTY
								 FROM T A,
								      TB_DL_EXPD_MDY_MGMT B,
									  TB_PDI_WHSN_INFO C
								 WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
         				         AND A.MDL_MDY_CD = B.MDL_MDY_CD 
								 AND A.DL_EXPD_REGN_CD = B.DL_EXPD_REGN_CD 
         				         AND A.QLTY_VEHL_CD = C.QLTY_VEHL_CD
         				         AND B.DL_EXPD_MDL_MDY_CD = C.DL_EXPD_MDL_MDY_CD
								 AND A.LANG_CD = C.LANG_CD
								 AND C.WHSN_YMD = P_CURR_YMD
								 GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD 
								 ***/
								 
								) D,
                                --글로비스재고
                                (SELECT A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD, SUM(B.SFTY_IV_QTY) AS GLOVIS_IV_QTY
                                 FROM T A,
                                      TB_PDI_IV_INFO_DTL B
                                 WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
                                 AND A.MDL_MDY_CD = B.MDL_MDY_CD
                                 AND A.LANG_CD = B.LANG_CD
                                 AND B.CLS_YMD = P_CURR_YMD
								 AND B.SFTY_IV_QTY > 0 --안전재고수량이 없는 것은 가져오지 않는다. 
						         GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD
								 
								 /***
								 SELECT A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD, SUM(IV_QTY) AS GLOVIS_IV_QTY
                                 FROM T A,
                                      TB_DL_EXPD_MDY_MGMT B,
                                      TB_PDI_IV_INFO C
                                 WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
                                 AND A.MDL_MDY_CD = B.MDL_MDY_CD 
								 AND A.DL_EXPD_REGN_CD = B.DL_EXPD_REGN_CD 
                                 AND A.QLTY_VEHL_CD = C.QLTY_VEHL_CD
                                 AND B.DL_EXPD_MDL_MDY_CD = C.DL_EXPD_MDL_MDY_CD
                                 AND A.LANG_CD = C.LANG_CD
                                 AND C.CLS_YMD = P_CURR_YMD
						         GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD 
								 ***/
								 
                                ) E,
								(SELECT A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD,
										PG_TOT_IV_INFO.FU_GET_PLNT_DAY3_PLAN_QTY(P_CURR_YMD, A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD) AS PLNT_DAY3_QTY_TEXT,
										PG_TOT_IV_INFO.FU_GET_PLNT_WEK2_PLAN_QTY(P_CURR_YMD, A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD) AS PLNT_WEK2_QTY_TEXT,
										'Y' AS PLNT_YN
                                 FROM T A,
                                      TB_PLNT_APS_PROD_SUM_INFO B
                                 WHERE A.DATA_SN = B.DATA_SN
                                 AND B.APL_YMD = P_CURR_YMD
						         GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD
								) F
                           WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD(+)
                           AND A.MDL_MDY_CD = B.MDL_MDY_CD(+)
                           AND A.LANG_CD = B.LANG_CD(+)
                           AND A.QLTY_VEHL_CD = C.QLTY_VEHL_CD(+)
                           AND A.MDL_MDY_CD = C.MDL_MDY_CD(+)
                           AND A.LANG_CD = C.LANG_CD(+)
						   --입고확인된 데이터만을 표시해 주기 위해서 OUTER JOIN을 빼준다..
                           AND A.QLTY_VEHL_CD = D.QLTY_VEHL_CD
                           AND A.MDL_MDY_CD = D.MDL_MDY_CD
                           AND A.LANG_CD = D.LANG_CD
                           AND A.QLTY_VEHL_CD = E.QLTY_VEHL_CD(+)
                           AND A.MDL_MDY_CD = E.MDL_MDY_CD(+)
                           AND A.LANG_CD = E.LANG_CD(+)
						   
					 	   /****  속도 개선을 위한 쿼리 변경 
					 	   SELECT A.CL_SCN_CD,
			   				      A.DATA_SN,
							      A.QLTY_VEHL_CD,
							      A.MDL_MDY_CD,
							      A.LANG_CD,
							      A.DL_EXPD_REGN_CD,
							      A.QLTY_VEHL_NM,
							      A.LANG_CD_NM,
			   				      NVL(B.DAY3_PLAN_QTY, 0) AS DAY3_PLAN_QTY,
							      NVL(C.CURR_MTH_TRWI_QTY, 0) AS CURR_MTH_TRWI_QTY,
							      NVL(D.PREV_1DAY_TRWI_QTY, 0) AS PREV_1DAY_TRWI_QTY,
							      NVL(E.SEWHA_IV_QTY, 0) AS SEWHA_IV_QTY,
							      NVL(E.SEWHA_PRNT_YN, 'N') AS SEWHA_PRNT_YN,
								  NVL(F.GLOVIS_DEEI1_QTY, 0) AS GLOVIS_DEEI1_QTY,
							      NVL(G.GLOVIS_IV_QTY, 0) AS GLOVIS_IV_QTY,
								  NVL(H.WEK2_TRWI_QTY, 0) AS WEK2_TRWI_QTY,
								  NVL(I.MTH3_TRWI_QTY, 0) AS MTH3_TRWI_QTY,
								  CASE WHEN NVL(I.MTH3_TRWI_QTY, 0) <> 0 THEN ROUND(NVL(G.GLOVIS_IV_QTY, 0) / NVL(I.MTH3_TRWI_QTY, 0)) 
								       ELSE 0 
								  END AS GLOVIS_IV_DIFF,
								  CASE WHEN NVL(I.MTH3_TRWI_QTY, 0) <> 0 THEN ROUND((NVL(E.SEWHA_IV_QTY, 0) + NVL(G.GLOVIS_IV_QTY, 0)) / NVL(I.MTH3_TRWI_QTY, 0)) 
								       ELSE 0 
								  END AS TOT_IV_DIFF
			   		       FROM T A,
                                --단기계획(3일)
                                (SELECT A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD, SUM(NVL(B.PRDN_PLN_QTY, 0) + NVL(C.PRDN_QTY, 0)) AS DAY3_PLAN_QTY
                                 FROM T A,
                                      TB_APS_PROD_PLAN_SUM_INFO B,
                                      TB_PROD_MST_SUM_INFO C
                                 WHERE A.DATA_SN = B.DATA_SN(+)
                                 AND A.DATA_SN = C.DATA_SN(+)
                                 AND B.APL_STRT_YMD(+) <= P_CURR_YMD
                                 AND B.APL_FNH_YMD(+) >= P_CURR_YMD
                                 AND B.PLN_PARR_YMD(+) = P_CURR_YMD
                                 AND C.APL_YMD(+) = P_CURR_YMD
                                 GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD
                                ) B,
        				        --당월투입
        				        (SELECT A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD, SUM(PRDN_TRWI_QTY) AS CURR_MTH_TRWI_QTY
         				         FROM T A,
              		                  TB_PROD_MST_SUM_INFO B
         				         WHERE A.DATA_SN = B.DATA_SN
      				             AND B.APL_YMD BETWEEN V_CURR_FSTD_YMD AND P_CURR_YMD
      				             GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD
        				        ) C,
      				            --전일투입
      				            (SELECT A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD, SUM(PRDN_TRWI_QTY) AS PREV_1DAY_TRWI_QTY
         				         FROM T A,
              		                  TB_PROD_MST_SUM_INFO B
         				         WHERE A.DATA_SN = B.DATA_SN
      				             AND B.APL_YMD = V_PREV_1DAY_YMD
      				             GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD
        				        ) D,
        				        --세화재고
        				        (SELECT A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD, SUM(IV_QTY) AS SEWHA_IV_QTY,
						                --인쇄중 데이터 존재 여부 확인 ==> DL_EXPD_TMP_IV_QTY 값은 인쇄중 이전인 경우에는 NULL, 인쇄중인경우에는 인쇄 수량, 납품이후에는 0으로 설정되어 있음 
						  		        CASE WHEN SUM(DL_EXPD_TMP_IV_QTY) > 0 THEN 'Y' ELSE 'N'END AS SEWHA_PRNT_YN
         				         FROM T A,
              		   		          TB_DL_EXPD_MDY_MGMT B,
              				          TB_SEWHA_IV_INFO C
         				         WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
         				         AND A.MDL_MDY_CD = B.MDL_MDY_CD 
								 AND A.DL_EXPD_REGN_CD = B.DL_EXPD_REGN_CD 
         				         AND A.QLTY_VEHL_CD = C.QLTY_VEHL_CD
         				         AND B.DL_EXPD_MDL_MDY_CD = C.DL_EXPD_MDL_MDY_CD
         				         AND A.LANG_CD = C.LANG_CD
         				         AND C.CLS_YMD = P_CURR_YMD
						         GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD
                                ) E,
								--입고확인 데이터 조회 
								(SELECT A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD, 
										SUM(DEEI1_QTY) AS GLOVIS_DEEI1_QTY
								 FROM T A,
								      TB_DL_EXPD_MDY_MGMT B,
									  TB_PDI_WHSN_INFO C
								 WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
         				         AND A.MDL_MDY_CD = B.MDL_MDY_CD 
								 AND A.DL_EXPD_REGN_CD = B.DL_EXPD_REGN_CD 
         				         AND A.QLTY_VEHL_CD = C.QLTY_VEHL_CD
         				         AND B.DL_EXPD_MDL_MDY_CD = C.DL_EXPD_MDL_MDY_CD
								 AND C.WHSN_YMD = P_CURR_YMD
								 GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD
								) F,
                                --글로비스재고
                                (SELECT A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD, SUM(IV_QTY) AS GLOVIS_IV_QTY
                                 FROM T A,
                                      TB_DL_EXPD_MDY_MGMT B,
                                      TB_PDI_IV_INFO C
                                 WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
                                 AND A.MDL_MDY_CD = B.MDL_MDY_CD 
								 AND A.DL_EXPD_REGN_CD = B.DL_EXPD_REGN_CD 
                                 AND A.QLTY_VEHL_CD = C.QLTY_VEHL_CD
                                 AND B.DL_EXPD_MDL_MDY_CD = C.DL_EXPD_MDL_MDY_CD
                                 AND A.LANG_CD = C.LANG_CD
                                 AND C.CLS_YMD = P_CURR_YMD
						         GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD
                                ) G,
								--2주 일평균 출하량 
								(SELECT A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD, ROUND(AVG(PRDN_TRWI_QTY)) AS WEK2_TRWI_QTY
                                 FROM T A,
                                      TB_PROD_MST_SUM_INFO B
                                 WHERE A.DATA_SN = B.DATA_SN
                                 AND B.APL_YMD BETWEEN V_PREV_2WEK_YMD AND V_PREV_1DAY_YMD
                                 GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD
								) H,
								--3개월 일평균 출하량 
								(SELECT A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD, ROUND(AVG(PRDN_TRWI_QTY)) AS MTH3_TRWI_QTY
                                 FROM T A,
                                      TB_PROD_MST_SUM_INFO B
                                 WHERE A.DATA_SN = B.DATA_SN
                                 AND B.APL_YMD BETWEEN V_PREV_3MTH_YMD AND V_PREV_1MTH_YMD
                                 GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD
								) I
                           WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD(+)
                           AND A.MDL_MDY_CD = B.MDL_MDY_CD(+)
                           AND A.LANG_CD = B.LANG_CD(+)
                           AND A.QLTY_VEHL_CD = C.QLTY_VEHL_CD(+)
                           AND A.MDL_MDY_CD = C.MDL_MDY_CD(+)
                           AND A.LANG_CD = C.LANG_CD(+)
                           AND A.QLTY_VEHL_CD = D.QLTY_VEHL_CD(+)
                           AND A.MDL_MDY_CD = D.MDL_MDY_CD(+)
                           AND A.LANG_CD = D.LANG_CD(+)
                           AND A.QLTY_VEHL_CD = E.QLTY_VEHL_CD(+)
                           AND A.MDL_MDY_CD = E.MDL_MDY_CD(+)
                           AND A.LANG_CD = E.LANG_CD(+)
                           AND A.QLTY_VEHL_CD = F.QLTY_VEHL_CD(+)
                           AND A.MDL_MDY_CD = F.MDL_MDY_CD(+)
                           AND A.LANG_CD = F.LANG_CD(+)
                           AND A.QLTY_VEHL_CD = G.QLTY_VEHL_CD(+)
                           AND A.MDL_MDY_CD = G.MDL_MDY_CD(+)
                           AND A.LANG_CD = G.LANG_CD(+)
                           AND A.QLTY_VEHL_CD = H.QLTY_VEHL_CD(+)
                           AND A.MDL_MDY_CD = H.MDL_MDY_CD(+)
                           AND A.LANG_CD = H.LANG_CD(+)
						   AND A.QLTY_VEHL_CD = I.QLTY_VEHL_CD(+)
                           AND A.MDL_MDY_CD = I.MDL_MDY_CD(+)
                           AND A.LANG_CD = I.LANG_CD(+)
						   ****/
						   
			             ) A,
				         TB_CODE_MGMT B
			         WHERE A.DL_EXPD_REGN_CD = B.DL_EXPD_PRVS_CD
			         AND B.DL_EXPD_G_CD = '0008'
			         AND DAY3_PLAN_QTY + CURR_MTH_TRWI_QTY + PREV_1DAY_TRWI_QTY + SEWHA_IV_QTY + 
					     GLOVIS_DEEI1_QTY + GLOVIS_IV_QTY > 0
			         --ORDER BY QLTY_VEHL_NM, B.SORT_SN, LANG_CD_NM 
					 ORDER BY QLTY_VEHL_CD, LANG_SORT_SN, MDL_MDY_CD
					) A,
					TB_CODE_MGMT B
			    WHERE A.PRNT_STATE = B.DL_EXPD_PRVS_CD
				AND B.DL_EXPD_G_CD = '0022';
		  
		  END IF;
		  
	   END SP_GET_GLOVIS_IV_INFO2;
	   
	   --글로비스 배송요청 정보 조회
	   PROCEDURE SP_GET_GLOVIS_DLVH_REQ_INFO(P_MENU_ID 	    VARCHAR2,
								             P_USER_EENO    VARCHAR2,
	   			 						     P_DATA_SN_LIST VARCHAR2,
											 P_CURR_YMD     VARCHAR2,
			  						    	 RS OUT REFCUR)
	   IS
	   	 
		 V_CURR_YMD VARCHAR2(8);
		 
		 V_QUERY    VARCHAR2(8000);
		 
	   BEGIN
	   		
			V_CURR_YMD := TO_CHAR(SYSDATE, 'YYYYMMDD');
			
			V_QUERY := 'SELECT A.QLTY_VEHL_NM,' ||
				               'A.LANG_CD_NM,' ||
				               'A.RQ_SCN_NM,' ||
				               'NVL(B.RQ_QTY, 0) AS RQ_QTY,' ||
				               'NVL(B.SPMN_IMTR_SBC, '''') AS SPMN_IMTR_SBC,' ||
				               'A.QLTY_VEHL_CD,' ||
				               'A.MDL_MDY_CD,' ||
				               'A.LANG_CD,' ||
				               'A.RQ_SCN_CD,' ||
				               'NVL(B.DTL_SN, 0) AS DTL_SN,' ||
				               'CASE WHEN A.CL_SCN_CD = ''U'' AND ''' || P_CURR_YMD || '''=''' || V_CURR_YMD || ''' THEN ''Y'' ELSE ''N'' END AS CL_SCN_CD ' ||
		               'FROM (SELECT A.QLTY_VEHL_CD,' ||
				                    'A.MDL_MDY_CD,' ||
						            'A.LANG_CD,' ||
						            'A.QLTY_VEHL_NM,' ||
						            'A.LANG_CD_NM,' ||
						            'A.CL_SCN_CD,' ||
						            'B.RQ_SCN_CD,' ||
						            'B.RQ_SCN_NM,' ||
									'B.SORT_SN,' ||
									'A.LANG_SORT_SN ' ||
				              'FROM (SELECT A.QLTY_VEHL_CD,' ||
							               'A.MDL_MDY_CD,' ||
							               'A.LANG_CD,' ||
							             '''('' || A.QLTY_VEHL_CD || '')'' || MAX(C.QLTY_VEHL_NM) || ''-'' || A.MDL_MDY_CD || ''MY'' AS QLTY_VEHL_NM,' ||
							               --'MAX(A.LANG_CD_NM) AS LANG_CD_NM,' || 
										 '''('' || A.LANG_CD || '')'' || MAX(A.LANG_CD_NM) AS LANG_CD_NM,' ||
							               'MAX(B.CL_SCN_CD) AS CL_SCN_CD,' ||
										   'MAX(A.SORT_SN) AS LANG_SORT_SN ' ||
					                'FROM TB_LANG_MGMT A,' ||
							             'TB_AUTH_VEHL_MGMT B,' ||
							             'TB_VEHL_MGMT C ' ||
					                'WHERE A.DATA_SN IN (' || P_DATA_SN_LIST || ') ' ||
					                'AND A.QLTY_VEHL_CD = B.QLTY_VEHL_CD ' ||
						            'AND A.QLTY_VEHL_CD = C.QLTY_VEHL_CD ' ||
						            'AND A.MDL_MDY_CD = C.MDL_MDY_CD ' ||
					                'AND B.MENU_ID = PG_COMMON.FU_RPAD(''' || P_MENU_ID || ''', 10) ' ||
                                    'AND B.USER_EENO = PG_COMMON.FU_RPAD(''' || P_USER_EENO || ''', 7) ' ||
					                'GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD ' ||
					              ') A,' ||
					              '(SELECT DL_EXPD_PRVS_CD AS RQ_SCN_CD,' ||
					                      'DL_EXPD_PRVS_NM AS RQ_SCN_NM,' ||
										  'SORT_SN ' ||
					               'FROM TB_CODE_MGMT ' ||
						           'WHERE DL_EXPD_G_CD = ''0015'' ' ||
						           'ORDER BY SORT_SN ' ||
					              ') B ' ||
				           ') A,' ||
			               'TB_GLOVIS_DLVH_REQ_INFO B ' ||
			           'WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD(+) ' ||
			           'AND A.MDL_MDY_CD = B.MDL_MDY_CD(+) ' ||
			           'AND A.LANG_CD = B.LANG_CD(+) ' ||
			           'AND A.RQ_SCN_CD = B.DL_EXPD_RQ_SCN_CD(+) ' ||
			           'AND B.RQ_YMD(+) = ''' || P_CURR_YMD || ''' ' ||
			           'AND B.DEL_YN(+) = ''N'' ' ||
					   --'ORDER BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD, A.SORT_SN ';
					   'ORDER BY A.QLTY_VEHL_CD, A.LANG_SORT_SN, A.MDL_MDY_CD, A.SORT_SN ';		 
			
			OPEN RS FOR V_QUERY;
		    
			/***  쿼리작성용 참고 쿼리
			SELECT A.QLTY_VEHL_NM,
				   A.LANG_CD_NM,
				   A.RQ_SCN_NM,
				   NVL(B.RQ_QTY, 0) AS RQ_QTY,
				   NVL(B.SPMN_IMTR_SBC, '') AS SPMN_IMTR_SBC,
				   A.QLTY_VEHL_CD,
				   A.MDL_MDY_CD,
				   A.LANG_CD,
				   A.RQ_SCN_CD,
				   NVL(B.DTL_SN, 0) AS DTL_SN,
				   CASE WHEN A.CL_SCN_CD = 'U' AND P_CURR_YMD = V_CURR_YMD THEN 'Y' ELSE 'N' END AS CL_SCN_CD
		    FROM (SELECT A.QLTY_VEHL_CD,
				         A.MDL_MDY_CD,
						 A.LANG_CD,
						 A.QLTY_VEHL_NM,
						 A.LANG_CD_NM,
						 A.CL_SCN_CD,
						 B.RQ_SCN_CD,
						 B.RQ_SCN_NM,
						 B.SORT_SN 
				  FROM (SELECT A.QLTY_VEHL_CD,
							   A.MDL_MDY_CD,
							   A.LANG_CD,
							   '(' || A.QLTY_VEHL_CD || ')' || MAX(C.QLTY_VEHL_NM) || '-' || A.MDL_MDY_CD || 'MY' AS QLTY_VEHL_NM,
							   MAX(A.LANG_CD_NM) AS LANG_CD_NM,
							   MAX(B.CL_SCN_CD) AS CL_SCN_CD
					    FROM TB_LANG_MGMT A,
							 TB_AUTH_VEHL_MGMT B,
							 TB_VEHL_MGMT C
					    WHERE A.DATA_SN IN (P_DATA_SN_LIST)
					    AND A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
						AND A.QLTY_VEHL_CD = C.QLTY_VEHL_CD
						AND A.MDL_MDY_CD = C.MDL_MDY_CD
					    AND B.MENU_ID = PG_COMMON.FU_RPAD(P_MENU_ID, 10)
                        AND B.USER_EENO = PG_COMMON.FU_RPAD(P_USER_EENO, 7)
					    GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD
					   ) A,
					   (SELECT DL_EXPD_PRVS_CD AS RQ_SCN_CD,
					           DL_EXPD_PRVS_NM AS RQ_SCN_NM,
							   SORT_SN 
					    FROM TB_CODE_MGMT
						WHERE DL_EXPD_G_CD = '0015'
						ORDER BY SORT_SN
					   ) B
				 ) A,
			     TB_GLOVIS_DLVH_REQ_INFO B
			WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD(+)
			AND A.MDL_MDY_CD = B.MDL_MDY_CD(+)
			AND A.LANG_CD = B.LANG_CD(+)
			AND A.RQ_SCN_CD = B.DL_EXPD_RQ_SCN_CD(+)
			AND B.RQ_YMD(+) = P_CURR_YMD
			AND B.DEL_YN(+) = 'N' 
			ORDER BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD, A.SORT_SN	
			**/ 
		 
	   END SP_GET_GLOVIS_DLVH_REQ_INFO;
	   
	   PROCEDURE SP_GLOVIS_DLVH_REQ_SAVE(P_VEHL_CD        VARCHAR2,
	   			 			             P_MDL_MDY_CD     VARCHAR2,
							             P_LANG_CD        VARCHAR2,
										 P_DTL_SN		  NUMBER,
										 P_RQ_SCN_CD	  VARCHAR2,
							             P_RQ_QTY		  NUMBER,
										 P_IMTR_SBC		  VARCHAR2,
							             P_PWMR_EENO      VARCHAR2,
							             P_USER_EENO      VARCHAR2)
	   IS
	   	 
		 V_CURR_YMD VARCHAR2(8);
		 
		 V_DATA_SN  NUMBER(7);
		 
		 V_DTL_SN   NUMBER(11);
	     
		 V_MAIL_TITLE   VARCHAR2(8000);
    	 V_MAIL_CONTENT VARCHAR2(8000);
		 
		 V_QLTY_VEHL_NM TB_VEHL_MGMT.QLTY_VEHL_NM%TYPE;
		 V_LANG_CD_NM   TB_LANG_MGMT.LANG_CD_NM%TYPE;
	
	   BEGIN
	   		
			V_CURR_YMD := TO_CHAR(SYSDATE, 'YYYYMMDD');
			
			SELECT A.DATA_SN,
			       B.QLTY_VEHL_NM,
			       A.LANG_CD_NM
    	    INTO V_DATA_SN,
			     V_QLTY_VEHL_NM,
			     V_LANG_CD_NM
            FROM TB_LANG_MGMT A,
			     TB_VEHL_MGMT B
    	    WHERE A.QLTY_VEHL_CD = P_VEHL_CD
 	        AND A.MDL_MDY_CD = P_MDL_MDY_CD
 	        AND A.LANG_CD = P_LANG_CD
	        AND A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
	        AND A.MDL_MDY_CD = B.MDL_MDY_CD;
			
			UPDATE TB_GLOVIS_DLVH_REQ_INFO
			SET PWMR_EENO = P_PWMR_EENO,
			    RQ_QTY = P_RQ_QTY,
				SPMN_IMTR_SBC = P_IMTR_SBC,
				UPDR_EENO = P_USER_EENO,
				MDFY_DTM = SYSDATE
			WHERE RQ_YMD = V_CURR_YMD
			AND DATA_SN = V_DATA_SN
			AND DTL_SN = P_DTL_SN;
			
			IF SQL%NOTFOUND THEN
			   
			   INSERT INTO TB_GLOVIS_DLVH_REQ_INFO
 	   		   (RQ_YMD,
 	    	    DATA_SN,
 	 			DTL_SN,
 	 	        QLTY_VEHL_CD,
 	 	        MDL_MDY_CD,
 	 	        LANG_CD,
				DL_EXPD_RQ_SCN_CD,
		        PWMR_EENO,
 	 	        RQ_QTY,
				DEL_YN,
				SPMN_IMTR_SBC,
 	 	        PPRR_EENO,
 	 	        FRAM_DTM,
 	 	        UPDR_EENO,
 	 	        MDFY_DTM
 	           )
 	           SELECT V_CURR_YMD,
 		              V_DATA_SN,
 		              NVL(MAX(DTL_SN), 0) + 1,
 		              P_VEHL_CD,
 		              P_MDL_MDY_CD,
 		              P_LANG_CD,
					  P_RQ_SCN_CD,
 		   			  P_PWMR_EENO,
 		   			  P_RQ_QTY,
					  'N',
					  P_IMTR_SBC,
 		   			  P_USER_EENO,
 		   			  SYSDATE,
 		   			  P_USER_EENO,
 		   			  SYSDATE
 	          FROM TB_GLOVIS_DLVH_REQ_INFO
 	          WHERE RQ_YMD = V_CURR_YMD
 	          AND DATA_SN = V_DATA_SN;
			  
			END IF;
			
			--인쇄요청인 경우 
			IF P_RQ_SCN_CD = '01' THEN
			   
			   --메일 발송 
			   V_MAIL_TITLE   := '오너스매뉴얼 인쇄 요청합니다.';
			   V_MAIL_CONTENT := '현재 재고부족으로 상기 메뉴얼의 인쇄를 요청합니다.<br>' ||
					  	         '차종    : (' || P_VEHL_CD || ')' || V_QLTY_VEHL_NM || '-' || P_MDL_MDY_CD || 'MY<br>' ||
					  		     '언어    : (' || P_LANG_CD || ')' || V_LANG_CD_NM || '<br>' ||
					             '수량    : ' || TO_CHAR(P_RQ_QTY) || '부<br>';
    
			   --서비스기술 정보팀 메일 발송 
			   PG_TOT_IV_INFO.SP_SEND_MAIL(P_VEHL_CD, P_MDL_MDY_CD, '01', P_PWMR_EENO, V_MAIL_TITLE, V_MAIL_CONTENT);
			   
			--배송요청인 경우 
			ELSE
			   
			   --메일 발송 
			   V_MAIL_TITLE   := '오너스매뉴얼 긴급 배송 요청합니다.';
			   V_MAIL_CONTENT := '현재 재고부족으로 상기 메뉴얼의 긴급 배송을 요청합니다.<br>' ||
					  		     '차종    : (' || P_VEHL_CD || ')' || V_QLTY_VEHL_NM || '-' || P_MDL_MDY_CD || 'MY<br>' ||
					  			 '언어    : (' || P_LANG_CD || ')' || V_LANG_CD_NM || '<br>' ||
					  			 '수량    : ' || TO_CHAR(P_RQ_QTY) || '부<br>';
								 
			   --세화 메일 발송 						  
			   PG_TOT_IV_INFO.SP_SEND_MAIL(P_VEHL_CD, P_MDL_MDY_CD, '03', P_PWMR_EENO, V_MAIL_TITLE, V_MAIL_CONTENT);
					  
			END IF;
			
	   END SP_GLOVIS_DLVH_REQ_SAVE;
	   
	   PROCEDURE SP_GLOVIS_DLVH_REQ_DELETE(P_VEHL_CD    VARCHAR2,
	   			 			               P_MDL_MDY_CD VARCHAR2,
							               P_LANG_CD    VARCHAR2,
										   P_DTL_SN		NUMBER,
										   P_USER_EENO  VARCHAR2)
	   
	   IS
	   	 
		 V_CURR_YMD VARCHAR2(8);
		 
		 V_DATA_SN  NUMBER(7);
		 
	   BEGIN
	   		
			V_CURR_YMD := TO_CHAR(SYSDATE, 'YYYYMMDD');
			
			SELECT DATA_SN
    	    INTO V_DATA_SN
            FROM TB_LANG_MGMT
    	    WHERE QLTY_VEHL_CD = P_VEHL_CD
    	    AND MDL_MDY_CD = P_MDL_MDY_CD
    	    AND LANG_CD = P_LANG_CD;
			
			UPDATE TB_GLOVIS_DLVH_REQ_INFO
			SET DEL_YN = 'Y',
				UPDR_EENO = P_USER_EENO,
				MDFY_DTM = SYSDATE
			WHERE RQ_YMD = V_CURR_YMD
			AND DATA_SN = V_DATA_SN
			AND DTL_SN = P_DTL_SN;
			
	   END SP_GLOVIS_DLVH_REQ_DELETE;
	   
END PG_GLOVIS_IV_INFO;