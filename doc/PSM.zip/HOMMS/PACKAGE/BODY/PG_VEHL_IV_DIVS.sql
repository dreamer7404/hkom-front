CREATE OR REPLACE PACKAGE BODY HOMMS_ADM.PG_VEHL_IV_DIVS AS

	   --세화 재고 전환 내역 조회 
	   PROCEDURE SP_GET_SEWHA_DIVS_INFO(P_MENU_ID 	   VARCHAR2,
								        P_USER_EENO    VARCHAR2,
	   			 						P_DATA_SN_LIST VARCHAR2,
			  						    P_CURR_YMD     VARCHAR2,
			  						    RS OUT REFCUR)
	   IS
	   	 
		 V_CURR_YMD VARCHAR2(8);
		 
		 V_QUERY    VARCHAR2(8000);
		 
	   BEGIN
	     
		 V_CURR_YMD := TO_CHAR(SYSDATE, 'YYYYMMDD');
		 
		 ----이전 날짜에 재고 데이터가 소진된 항목에 대해서 재고 데이터 새로이 생성
		 --PG_DATA.SP_REMAKE_SEWHA_IV_INFO(P_DATA_SN_LIST, P_CURR_YMD, V_CURR_YMD, P_USER_EENO);
		 
		 V_QUERY := 'SELECT * ' ||
		  		 	'FROM (SELECT A.EXPD_CO_NM,' ||
                	             'NVL(B.DL_EXPD_PRVS_NM, '''') AS EXPD_RQ_SCN_NM,' || --요청구분
             		   			 'A.QLTY_VEHL_NM,' ||
			 		   			 'A.LANG_CD_NM,' ||
			 		   			 'A.N_PRNT_PBCN_NO,' ||
			 		   			 'A.IV_QTY,' ||
			 		   			 'A.RQ_QTY,' ||
			 		   			 'A.DIVS_QLTY_VEHL_CD,' ||
			 		   			 'A.DIVS_DL_EXPD_MDL_MDY_CD,' ||
			 		   			 'A.DIVS_LANG_CD,' ||
			 		   			 'A.PRTL_IMTR_SBC,' ||
			 		   			 'A.QLTY_VEHL_CD,' ||
			 		   			 'A.MDL_MDY_CD,' ||
			 		   			 'A.DL_EXPD_MDL_MDY_CD,' ||
			 		   			 'A.LANG_CD,' || 
			 		   			 'A.EXPD_RQ_SCN_CD,' || --요청구분코드 
			 		   			 'A.CL_SCN_CD ' ||
	            		  'FROM (SELECT A.QLTY_VEHL_CD,' ||
	  	   		   	 		 		   'A.MDL_MDY_CD,' ||
				   			 		   'A.LANG_CD,' ||
				   			 		   'A.DL_EXPD_MDL_MDY_CD,' ||
				   			 		   'A.N_PRNT_PBCN_NO,' ||
				   			 		   'A.IV_QTY,' ||
				   			 		   'A.EXPD_CO_CD,' ||
				   			 		   'A.EXPD_REGN_CD,' ||
				   			 		   'A.QLTY_VEHL_NM,' ||
				   			 		   'A.LANG_CD_NM,' ||
				   			 		   'A.EXPD_CO_NM,' ||
				   			 		   'A.LANG_SORT_SN,' ||
				   			 		   'NVL(B.RQ_QTY, 0) AS RQ_QTY,' ||
				   			 		   'NVL(B.DIVS_QLTY_VEHL_CD, '''') AS DIVS_QLTY_VEHL_CD,' ||
				   			 		   'NVL(B.DIVS_DL_EXPD_MDL_MDY_CD, A.DL_EXPD_MDL_MDY_CD) AS DIVS_DL_EXPD_MDL_MDY_CD,' ||
				   			 		   'NVL(B.DIVS_LANG_CD, A.LANG_CD) AS DIVS_LANG_CD,' ||
				   			 		   'NVL(B.PRTL_IMTR_SBC, '''') AS PRTL_IMTR_SBC,' ||
				   			 		   'NVL(B.DL_EXPD_RQ_SCN_CD, '''') AS EXPD_RQ_SCN_CD,' ||
				   			 		   'CASE WHEN A.CL_SCN_CD = ''U'' THEN ''Y'' ' ||
				   			      	   		'ELSE ''N'' END AS CL_SCN_CD ' ||
		                         'FROM (SELECT B.CLS_YMD,' ||
		   				   		              'A.QLTY_VEHL_CD,' ||
								   			  'A.MDL_MDY_CD,' ||
								   			  'A.LANG_CD,' ||
								   			  'B.DL_EXPD_MDL_MDY_CD,' ||
								   			  'B.N_PRNT_PBCN_NO,' ||
								   			  'B.IV_QTY,' ||
								   			  'A.EXPD_CO_CD,' ||
								   			  'A.EXPD_REGN_CD,' ||
								   			  'A.QLTY_VEHL_NM,' ||
								   			  'A.LANG_CD_NM,' ||
								   			  'A.EXPD_CO_NM,' ||
								   			  'A.CL_SCN_CD,' ||
								   			  'A.LANG_SORT_SN ' ||
                                       'FROM (SELECT A.QLTY_VEHL_CD,' ||
				 	  		  	 		 	 		'A.LANG_CD,' ||
							  			 			'A.MDL_MDY_CD,' ||
							  			 			'B.DL_EXPD_CO_CD AS EXPD_CO_CD,' ||
							  			 			'A.DL_EXPD_REGN_CD AS EXPD_REGN_CD,' ||
						      			 		    '''('' || B.QLTY_VEHL_CD || ''-'' || B.MDL_MDY_CD || '')'' || B.QLTY_VEHL_NM AS QLTY_VEHL_NM,' ||
						      			 			'CASE WHEN A.A_CODE IS NULL THEN ''('' || A.LANG_CD || '')'' ' ||
							  	   		 	             'ELSE ''('' || A.LANG_CD || ''-'' || A.A_CODE || '')'' ' ||
                              			 			'END || A.LANG_CD_NM AS LANG_CD_NM,' ||										   
							  			 			'C.DL_EXPD_PRVS_NM AS EXPD_CO_NM,' ||
							  			 			'A.LANG_SORT_SN,' ||
							  			 			'A.CL_SCN_CD ' ||
					                         'FROM (SELECT A.QLTY_VEHL_CD,' ||
					   				   		   	          'A.MDL_MDY_CD,' ||
											   			  'A.LANG_CD,' ||
											   			  'MAX(A.LANG_CD_NM) AS LANG_CD_NM,' ||
											   			  'MAX(A.DL_EXPD_REGN_CD) AS DL_EXPD_REGN_CD,' ||
											   			  'MAX(A.A_CODE) AS A_CODE,' ||
											   			  'MAX(A.SORT_SN) AS LANG_SORT_SN,' ||
											   			  'MAX(B.CL_SCN_CD) AS CL_SCN_CD ' ||
							            		   'FROM TB_LANG_MGMT A,' ||
							 	  			 	   		'TB_AUTH_VEHL_MGMT B ' ||
							            		   'WHERE A.DATA_SN IN (' || P_DATA_SN_LIST || ') ' ||
							 					   'AND A.QLTY_VEHL_CD = B.QLTY_VEHL_CD ' ||
							 					   'AND B.MENU_ID = PG_COMMON.FU_RPAD(''' || P_MENU_ID || ''', 10) ' ||
                                   		           'AND B.USER_EENO = PG_COMMON.FU_RPAD(''' || P_USER_EENO || ''', 7) ' ||
							 					   'GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD ' ||
							                      ') A,' ||
									   			  'TB_VEHL_MGMT B,' ||
									   			  'TB_CODE_MGMT C,' ||
									   			  'TB_CODE_MGMT D ' ||
					              			 'WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD ' ||
					   			  			 'AND A.MDL_MDY_CD = B.MDL_MDY_CD ' ||
					   			  			 'AND B.DL_EXPD_CO_CD = C.DL_EXPD_PRVS_CD ' ||
					   			  			 'AND C.DL_EXPD_G_CD = ''0003'' ' ||
					   			  			 'AND A.DL_EXPD_REGN_CD = D.DL_EXPD_PRVS_CD ' ||
					   			  			 'AND D.DL_EXPD_G_CD = ''0008'' ' ||
                                            ') A,' ||
				      			 			'TB_SEWHA_IV_INFO_DTL B ' ||
				                       'WHERE B.CLS_YMD = ''' || P_CURR_YMD || ''' ' ||
				 					   'AND A.QLTY_VEHL_CD = B.QLTY_VEHL_CD ' ||
				 					   'AND A.MDL_MDY_CD = B.MDL_MDY_CD ' ||
				 					   'AND A.LANG_CD = B.LANG_CD ' ||
				 					   'AND B.DL_EXPD_TMP_IV_QTY = 0 ' || --인쇄가 끝난것만을 가져온다.
				           			  ') A,' ||
						   			  'TB_SEWHA_DIVS_INFO B ' ||
		   			              'WHERE A.CLS_YMD = B.WHOT_YMD(+) ' ||
		   			  			  'AND A.QLTY_VEHL_CD = B.QLTY_VEHL_CD(+) ' ||
		   			  			  'AND A.MDL_MDY_CD = B.MDL_MDY_CD(+) ' ||
		   			  			  'AND A.LANG_CD = B.LANG_CD(+) ' ||
		   			  			  'AND A.DL_EXPD_MDL_MDY_CD = B.DL_EXPD_MDL_MDY_CD(+) ' ||
		   			  			  'AND A.N_PRNT_PBCN_NO = B.N_PRNT_PBCN_NO(+) ' ||
		             			 ') A,' ||
		  			 			 'TB_CODE_MGMT B ' ||
	                       'WHERE A.EXPD_RQ_SCN_CD = B.DL_EXPD_PRVS_CD(+) ' ||
	  					   'AND B.DL_EXPD_G_CD(+) = ''0033'' ' ||
	  					   'ORDER BY QLTY_VEHL_CD, LANG_SORT_SN, MDL_MDY_CD, N_PRNT_PBCN_NO, DL_EXPD_MDL_MDY_CD ' ||
	           			  ')'; 

		  OPEN RS FOR V_QUERY;
		  
		  /*** 테스트 용 쿼리 
		  
		  SELECT *
		  FROM (SELECT A.EXPD_CO_NM,
                	   NVL(B.DL_EXPD_PRVS_NM, '') AS EXPD_RQ_SCN_NM, --요청구분
             		   A.QLTY_VEHL_NM,
			 		   A.LANG_CD_NM,
			 		   A.N_PRNT_PBCN_NO,
			 		   A.IV_QTY,
			 		   A.RQ_QTY,
			 		   A.DIVS_QLTY_VEHL_CD,
			 		   A.DIVS_DL_EXPD_MDL_MDY_CD,
			 		   A.DIVS_LANG_CD,
			 		   A.PRTL_IMTR_SBC,
			 		   A.QLTY_VEHL_CD,
			 		   A.MDL_MDY_CD,
			 		   A.DL_EXPD_MDL_MDY_CD,
			 		   A.LANG_CD, 
			 		   A.EXPD_RQ_SCN_CD, --요청구분코드 
			 		   A.CL_SCN_CD
	            FROM (SELECT A.QLTY_VEHL_CD,
	  	   		   	 		 A.MDL_MDY_CD,
				   			 A.LANG_CD,
				   			 A.DL_EXPD_MDL_MDY_CD,
				   			 A.N_PRNT_PBCN_NO,
				   			 A.IV_QTY,
				   			 A.EXPD_CO_CD,
				   			 A.EXPD_REGN_CD,
				   			 A.QLTY_VEHL_NM,
				   			 A.LANG_CD_NM,
				   			 A.EXPD_CO_NM,
				   			 A.LANG_SORT_SN,
				   			 NVL(B.RQ_QTY, 0) AS RQ_QTY,
				   			 NVL(B.DIVS_QLTY_VEHL_CD, '') AS DIVS_QLTY_VEHL_CD,
				   			 NVL(B.DIVS_DL_EXPD_MDL_MDY_CD, A.DL_EXPD_MDL_MDY_CD) AS DIVS_DL_EXPD_MDL_MDY_CD,
				   			 NVL(B.DIVS_LANG_CD, A.LANG_CD) AS DIVS_LANG_CD,
				   			 NVL(B.PRTL_IMTR_SBC, '') AS PRTL_IMTR_SBC,
				   			 NVL(B.DL_EXPD_RQ_SCN_CD, '') AS EXPD_RQ_SCN_CD,
				   			 CASE WHEN A.CL_SCN_CD = 'U' THEN 'Y'
				   			      ELSE 'N' END AS CL_SCN_CD
		              FROM (SELECT B.CLS_YMD,
		   				   		   A.QLTY_VEHL_CD,
								   A.MDL_MDY_CD,
								   A.LANG_CD,
								   B.DL_EXPD_MDL_MDY_CD,
								   B.N_PRNT_PBCN_NO,
								   B.IV_QTY,
								   A.EXPD_CO_CD,
								   A.EXPD_REGN_CD,
								   A.QLTY_VEHL_NM,
								   A.LANG_CD_NM,
								   A.EXPD_CO_NM,
								   A.CL_SCN_CD,
								   A.LANG_SORT_SN 
                            FROM (SELECT A.QLTY_VEHL_CD,
				 	  		  	 		 A.LANG_CD,
							  			 A.MDL_MDY_CD,
							  			 B.DL_EXPD_CO_CD AS EXPD_CO_CD,
							  			 A.DL_EXPD_REGN_CD AS EXPD_REGN_CD,
						      			 '(' || B.QLTY_VEHL_CD || '-' || B.MDL_MDY_CD || ')' || B.QLTY_VEHL_NM AS QLTY_VEHL_NM,
						      			 CASE WHEN A.A_CODE IS NULL THEN '(' || A.LANG_CD || ')'
							  	   		 	  ELSE '(' || A.LANG_CD || '-' || A.A_CODE || ')'
                              			 END || A.LANG_CD_NM AS LANG_CD_NM,										   
							  			 C.DL_EXPD_PRVS_NM AS EXPD_CO_NM,
							  			 A.LANG_SORT_SN,
							  			 A.CL_SCN_CD
					              FROM (SELECT A.QLTY_VEHL_CD,
					   				   		   A.MDL_MDY_CD,
											   A.LANG_CD,
											   MAX(A.LANG_CD_NM) AS LANG_CD_NM,
											   MAX(A.DL_EXPD_REGN_CD) AS DL_EXPD_REGN_CD,
											   MAX(A.A_CODE) AS A_CODE,
											   MAX(A.SORT_SN) AS LANG_SORT_SN,
											   MAX(B.CL_SCN_CD) AS CL_SCN_CD
							            FROM TB_LANG_MGMT A,
							 	  			 TB_AUTH_VEHL_MGMT B
							            WHERE A.DATA_SN IN (:P_DATA_SN_LIST )
							 			AND A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
							 			AND B.MENU_ID = PG_COMMON.FU_RPAD(:P_MENU_ID, 10)
							 			AND B.USER_EENO = PG_COMMON.FU_RPAD(:P_USER_EENO, 7)
							 			GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD
							           ) A,
									   TB_VEHL_MGMT B,
									   TB_CODE_MGMT C,
									   TB_CODE_MGMT D
					              WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
					   			  AND A.MDL_MDY_CD = B.MDL_MDY_CD
					   			  AND B.DL_EXPD_CO_CD = C.DL_EXPD_PRVS_CD
					   			  AND C.DL_EXPD_G_CD = '0003'
					   			  AND A.DL_EXPD_REGN_CD = D.DL_EXPD_PRVS_CD
					   			  AND D.DL_EXPD_G_CD = '0008'
                                 ) A,
				      			 TB_SEWHA_IV_INFO_DTL B
				            WHERE B.CLS_YMD = :P_CURR_YMD
				 			AND A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
				 			AND A.MDL_MDY_CD = B.MDL_MDY_CD
				 			AND A.LANG_CD = B.LANG_CD
				 			AND B.DL_EXPD_TMP_IV_QTY = 0 --인쇄가 끝난것만을 가져온다.
				           ) A,
						   TB_SEWHA_DIVS_INFO B
		   			  WHERE A.CLS_YMD = B.WHOT_YMD(+)
		   			  AND A.QLTY_VEHL_CD = B.QLTY_VEHL_CD(+)
		   			  AND A.MDL_MDY_CD = B.MDL_MDY_CD(+)
		   			  AND A.LANG_CD = B.LANG_CD(+)
		   			  AND A.DL_EXPD_MDL_MDY_CD = B.DL_EXPD_MDL_MDY_CD(+)
		   			  AND A.N_PRNT_PBCN_NO = B.N_PRNT_PBCN_NO(+)
		             ) A,
		  			 TB_CODE_MGMT B
	            WHERE A.EXPD_RQ_SCN_CD = B.DL_EXPD_PRVS_CD(+)
	  			AND B.DL_EXPD_G_CD(+) = '0033'
	  			ORDER BY QLTY_VEHL_CD, LANG_SORT_SN, MDL_MDY_CD, N_PRNT_PBCN_NO, DL_EXPD_MDL_MDY_CD
	           ); 
		  	
			***/   
		
	   END SP_GET_SEWHA_DIVS_INFO;
	   
	   PROCEDURE SP_SEWHA_DIVS_INFO_SAVE(P_VEHL_CD              VARCHAR2,
	   			 				         P_MDL_MDY_CD	        VARCHAR2,
								         P_LANG_CD              VARCHAR2,
										 P_EXPD_MDL_MDY_CD      VARCHAR2,
								         P_N_PRNT_PBCN_NO       VARCHAR2,
								         P_WHOT_YMD             VARCHAR2,
								         P_EXPD_RQ_SCN_CD       VARCHAR2,
								         P_RQ_QTY		   		NUMBER,
										 P_DIVS_VEHL_CD	        VARCHAR2,
										 P_DIVS_EXPD_MDL_MDY_CD VARCHAR2,
										 P_DIVS_LANG_CD			VARCHAR2,
								         P_USER_EENO	        VARCHAR2,
										 P_PRTL_IMTR_SBC        VARCHAR2)
	   IS
	   	 
		 V_CURR_YMD      VARCHAR2(8);
		 
		 V_PREV_RQ_QTY NUMBER;
		 V_DIFF_RQ_QTY NUMBER;
		 
	   BEGIN
	   		
			V_CURR_YMD := TO_CHAR(SYSDATE, 'YYYYMMDD');
			
			--이전 전환수량 존재여부 확인 
			SELECT SUM(RQ_QTY)
			INTO V_PREV_RQ_QTY
			FROM TB_SEWHA_DIVS_INFO
			WHERE WHOT_YMD = V_CURR_YMD
			AND QLTY_VEHL_CD = P_VEHL_CD
			AND MDL_MDY_CD = P_MDL_MDY_CD
			AND LANG_CD = P_LANG_CD
			AND DL_EXPD_MDL_MDY_CD = P_EXPD_MDL_MDY_CD
			AND N_PRNT_PBCN_NO = P_N_PRNT_PBCN_NO
			AND DL_EXPD_RQ_SCN_CD = P_EXPD_RQ_SCN_CD;
			
			--별도요청 출고정보 수정작업을 위해서 이전 요청수량이 없으면 반드시 NULL 이어야 한다. 
			IF V_PREV_RQ_QTY IS NULL THEN 
			  	 
			    V_DIFF_RQ_QTY := P_RQ_QTY;
				
			ELSE
			
			    V_DIFF_RQ_QTY := P_RQ_QTY - V_PREV_RQ_QTY;
				
			END IF;
			
			PG_DATA.SP_SEWHA_IV_INFO_UPDATE3(P_VEHL_CD,
	   			 					         P_MDL_MDY_CD,
											 P_LANG_CD,
								    		 P_EXPD_MDL_MDY_CD,
											 P_N_PRNT_PBCN_NO,
											 V_CURR_YMD,
											 V_DIFF_RQ_QTY,
											 P_USER_EENO,
											 'Y');
									
			V_DIFF_RQ_QTY := V_DIFF_RQ_QTY * (-1);
			
			PG_DATA.SP_SEWHA_IV_INFO_UPDATE3(P_DIVS_VEHL_CD,
											 --재고전환으로 추가되는 항목은 취급설명서 연식과 동일한 연식으로 저장되도록 한다. 
	   			 							 --P_MDL_MDY_CD,
											 P_DIVS_EXPD_MDL_MDY_CD,
											 P_DIVS_LANG_CD,
								    		 P_DIVS_EXPD_MDL_MDY_CD,
											 P_N_PRNT_PBCN_NO,
											 V_CURR_YMD,
											 V_DIFF_RQ_QTY,
											 P_USER_EENO,
											 'N');
											 
			UPDATE TB_SEWHA_DIVS_INFO
		    SET RQ_QTY = P_RQ_QTY,
				DIVS_QLTY_VEHL_CD = P_DIVS_VEHL_CD,
				DIVS_DL_EXPD_MDL_MDY_CD = P_DIVS_EXPD_MDL_MDY_CD,
				DIVS_LANG_CD = P_DIVS_LANG_CD,
			    PRTL_IMTR_SBC = P_PRTL_IMTR_SBC,
			    UPDR_EENO = P_USER_EENO,
			    MDFY_DTM = SYSDATE
	        WHERE QLTY_VEHL_CD = P_VEHL_CD
			AND MDL_MDY_CD = P_MDL_MDY_CD
		    AND LANG_CD = P_LANG_CD
			AND DL_EXPD_MDL_MDY_CD = P_EXPD_MDL_MDY_CD
		    AND N_PRNT_PBCN_NO = P_N_PRNT_PBCN_NO
			AND WHOT_YMD = V_CURR_YMD
			AND DL_EXPD_RQ_SCN_CD = P_EXPD_RQ_SCN_CD;
			
			--수정된 항목이 없다면 Insert 해준다. 
		    IF SQL%NOTFOUND THEN
		   	  
			  INSERT INTO TB_SEWHA_DIVS_INFO
   			  (QLTY_VEHL_CD,
			   MDL_MDY_CD,
   			   LANG_CD,
			   DL_EXPD_MDL_MDY_CD,
   			   N_PRNT_PBCN_NO,
   			   WHOT_YMD,
   			   DL_EXPD_RQ_SCN_CD,
   			   RQ_QTY,
			   DIVS_QLTY_VEHL_CD,
			   DIVS_DL_EXPD_MDL_MDY_CD,
			   DIVS_LANG_CD,
   			   PRTL_IMTR_SBC,
   			   PPRR_EENO,
   			   FRAM_DTM,
   			   UPDR_EENO,
   			   MDFY_DTM
			  )
			  VALUES(P_VEHL_CD,
			  		 P_MDL_MDY_CD,
   					 P_LANG_CD,
					 P_EXPD_MDL_MDY_CD,
   					 P_N_PRNT_PBCN_NO,
   					 V_CURR_YMD,
   					 P_EXPD_RQ_SCN_CD,
   					 P_RQ_QTY,
					 P_DIVS_VEHL_CD,
					 P_DIVS_EXPD_MDL_MDY_CD,
					 P_DIVS_LANG_CD,
   					 P_PRTL_IMTR_SBC,
   					 P_USER_EENO,
   					 SYSDATE,
   					 P_USER_EENO,
   					 SYSDATE
					);
		   END IF;
			
			
	   END SP_SEWHA_DIVS_INFO_SAVE;									
	   
	   PROCEDURE SP_SEWHA_DIVS_INFO_DELETE(P_VEHL_CD              VARCHAR2,
	   			 				           P_MDL_MDY_CD	          VARCHAR2,
								           P_LANG_CD              VARCHAR2,
										   P_EXPD_MDL_MDY_CD      VARCHAR2,
								           P_N_PRNT_PBCN_NO       VARCHAR2,
								           P_WHOT_YMD             VARCHAR2,
								           P_EXPD_RQ_SCN_CD       VARCHAR2,
								           P_RQ_QTY		   		  NUMBER,
										   P_DIVS_VEHL_CD	      VARCHAR2,
										   P_DIVS_EXPD_MDL_MDY_CD VARCHAR2,
										   P_DIVS_LANG_CD		  VARCHAR2,
								           P_USER_EENO	          VARCHAR2,
										   P_PRTL_IMTR_SBC        VARCHAR2)
	   IS
	   	 
		 V_RQ_QTY               NUMBER;
		 V_DIVS_VEHL_CD         VARCHAR2(4);
		 V_DIVS_EXPD_MDL_MDY_CD VARCHAR2(2);
		 V_DIVS_LANG_CD         VARCHAR2(3);
	   BEGIN
	   		
			SELECT SUM(RQ_QTY),
				   MAX(DIVS_QLTY_VEHL_CD),
				   MAX(DIVS_DL_EXPD_MDL_MDY_CD),
				   MAX(DIVS_LANG_CD)
			INTO V_RQ_QTY,
			     V_DIVS_VEHL_CD,
				 V_DIVS_EXPD_MDL_MDY_CD,
				 V_DIVS_LANG_CD
			FROM TB_SEWHA_DIVS_INFO
			WHERE WHOT_YMD = P_WHOT_YMD
			AND QLTY_VEHL_CD = P_VEHL_CD
			AND MDL_MDY_CD = P_MDL_MDY_CD
			AND LANG_CD = P_LANG_CD
			AND DL_EXPD_MDL_MDY_CD = P_EXPD_MDL_MDY_CD
			AND N_PRNT_PBCN_NO = P_N_PRNT_PBCN_NO
			AND DL_EXPD_RQ_SCN_CD = P_EXPD_RQ_SCN_CD;
			
			PG_DATA.SP_SEWHA_IV_INFO_UPDATE3(P_VEHL_CD,
	   			 					         P_MDL_MDY_CD,
											 P_LANG_CD,
								    		 P_EXPD_MDL_MDY_CD,
											 P_N_PRNT_PBCN_NO,
											 P_WHOT_YMD,
											 V_RQ_QTY * (-1),
											 P_USER_EENO,
											 'Y');
											 
			PG_DATA.SP_SEWHA_IV_INFO_UPDATE3(V_DIVS_VEHL_CD,
	   			 					         V_DIVS_EXPD_MDL_MDY_CD,
											 V_DIVS_LANG_CD,
								    		 V_DIVS_EXPD_MDL_MDY_CD,
											 P_N_PRNT_PBCN_NO,
											 P_WHOT_YMD,
											 V_RQ_QTY,
											 P_USER_EENO,
											 'Y');
											 
			DELETE FROM TB_SEWHA_DIVS_INFO
			WHERE WHOT_YMD = P_WHOT_YMD
			AND QLTY_VEHL_CD = P_VEHL_CD
			AND MDL_MDY_CD = P_MDL_MDY_CD
			AND LANG_CD = P_LANG_CD
			AND DL_EXPD_MDL_MDY_CD = P_EXPD_MDL_MDY_CD
			AND N_PRNT_PBCN_NO = P_N_PRNT_PBCN_NO
			AND DL_EXPD_RQ_SCN_CD = P_EXPD_RQ_SCN_CD;
											 
	   END SP_SEWHA_DIVS_INFO_DELETE;
	   
	   
	   --PDI 재고 전환 내역 조회 
	   PROCEDURE SP_GET_PDI_DIVS_INFO(P_MENU_ID 	 VARCHAR2,
								      P_USER_EENO    VARCHAR2,
	   			 					  P_DATA_SN_LIST VARCHAR2,
			  						  P_CURR_YMD     VARCHAR2,
			  						  RS OUT REFCUR)
	   IS
	   	 
		 V_CURR_YMD VARCHAR2(8);
		 
		 V_QUERY    VARCHAR2(8000);
		 
	   BEGIN
	     
		 V_CURR_YMD := TO_CHAR(SYSDATE, 'YYYYMMDD');
		  
		 V_QUERY := 'SELECT * ' ||
		  		 	'FROM (SELECT A.EXPD_CO_NM,' ||
                	             'NVL(B.DL_EXPD_PRVS_NM, '''') AS EXPD_RQ_SCN_NM,' || --요청구분
             		   			 'A.QLTY_VEHL_NM,' ||
			 		   			 'A.LANG_CD_NM,' ||
			 		   			 'A.N_PRNT_PBCN_NO,' ||
			 		   			 'A.IV_QTY,' ||
			 		   			 'A.RQ_QTY,' ||
			 		   			 'A.DIVS_QLTY_VEHL_CD,' ||
			 		   			 'A.DIVS_DL_EXPD_MDL_MDY_CD,' ||
			 		   			 'A.DIVS_LANG_CD,' ||
			 		   			 'A.PRTL_IMTR_SBC,' ||
			 		   			 'A.QLTY_VEHL_CD,' ||
			 		   			 'A.MDL_MDY_CD,' ||
			 		   			 'A.DL_EXPD_MDL_MDY_CD,' ||
			 		   			 'A.LANG_CD,' || 
			 		   			 'A.EXPD_RQ_SCN_CD,' || --요청구분코드 
			 		   			 'A.CL_SCN_CD ' ||
	            		  'FROM (SELECT A.QLTY_VEHL_CD,' ||
	  	   		   	 		 		   'A.MDL_MDY_CD,' ||
				   			 		   'A.LANG_CD,' ||
				   			 		   'A.DL_EXPD_MDL_MDY_CD,' ||
				   			 		   'A.N_PRNT_PBCN_NO,' ||
				   			 		   'A.IV_QTY,' ||
				   			 		   'A.EXPD_CO_CD,' ||
				   			 		   'A.EXPD_REGN_CD,' ||
				   			 		   'A.QLTY_VEHL_NM,' ||
				   			 		   'A.LANG_CD_NM,' ||
				   			 		   'A.EXPD_CO_NM,' ||
				   			 		   'A.LANG_SORT_SN,' ||
				   			 		   'NVL(B.RQ_QTY, 0) AS RQ_QTY,' ||
				   			 		   'NVL(B.DIVS_QLTY_VEHL_CD, '''') AS DIVS_QLTY_VEHL_CD,' ||
				   			 		   'NVL(B.DIVS_DL_EXPD_MDL_MDY_CD, A.DL_EXPD_MDL_MDY_CD) AS DIVS_DL_EXPD_MDL_MDY_CD,' ||
				   			 		   'NVL(B.DIVS_LANG_CD, A.LANG_CD) AS DIVS_LANG_CD,' ||
				   			 		   'NVL(B.PRTL_IMTR_SBC, '''') AS PRTL_IMTR_SBC,' ||
				   			 		   'NVL(B.DL_EXPD_RQ_SCN_CD, '''') AS EXPD_RQ_SCN_CD,' ||
				   			 		   'CASE WHEN A.CL_SCN_CD = ''U'' THEN ''Y'' ' ||
				   			      	   		'ELSE ''N'' END AS CL_SCN_CD ' ||
		                         'FROM (SELECT B.CLS_YMD,' ||
		   				   		              'A.QLTY_VEHL_CD,' ||
								   			  'A.MDL_MDY_CD,' ||
								   			  'A.LANG_CD,' ||
								   			  'B.DL_EXPD_MDL_MDY_CD,' ||
								   			  'B.N_PRNT_PBCN_NO,' ||
								   			  'B.IV_QTY,' ||
								   			  'A.EXPD_CO_CD,' ||
								   			  'A.EXPD_REGN_CD,' ||
								   			  'A.QLTY_VEHL_NM,' ||
								   			  'A.LANG_CD_NM,' ||
								   			  'A.EXPD_CO_NM,' ||
								   			  'A.CL_SCN_CD,' ||
								   			  'A.LANG_SORT_SN ' ||
                                       'FROM (SELECT A.QLTY_VEHL_CD,' ||
				 	  		  	 		 	 		'A.LANG_CD,' ||
							  			 			'A.MDL_MDY_CD,' ||
							  			 			'B.DL_EXPD_CO_CD AS EXPD_CO_CD,' ||
							  			 			'A.DL_EXPD_REGN_CD AS EXPD_REGN_CD,' ||
						      			 		    '''('' || B.QLTY_VEHL_CD || ''-'' || B.MDL_MDY_CD || '')'' || B.QLTY_VEHL_NM AS QLTY_VEHL_NM,' ||
						      			 			'CASE WHEN A.A_CODE IS NULL THEN ''('' || A.LANG_CD || '')'' ' ||
							  	   		 	             'ELSE ''('' || A.LANG_CD || ''-'' || A.A_CODE || '')'' ' ||
                              			 			'END || A.LANG_CD_NM AS LANG_CD_NM,' ||										   
							  			 			'C.DL_EXPD_PRVS_NM AS EXPD_CO_NM,' ||
							  			 			'A.LANG_SORT_SN,' ||
							  			 			'A.CL_SCN_CD ' ||
					                         'FROM (SELECT A.QLTY_VEHL_CD,' ||
					   				   		   	          'A.MDL_MDY_CD,' ||
											   			  'A.LANG_CD,' ||
											   			  'MAX(A.LANG_CD_NM) AS LANG_CD_NM,' ||
											   			  'MAX(A.DL_EXPD_REGN_CD) AS DL_EXPD_REGN_CD,' ||
											   			  'MAX(A.A_CODE) AS A_CODE,' ||
											   			  'MAX(A.SORT_SN) AS LANG_SORT_SN,' ||
											   			  'MAX(B.CL_SCN_CD) AS CL_SCN_CD ' ||
							            		   'FROM TB_LANG_MGMT A,' ||
							 	  			 	   		'TB_AUTH_VEHL_MGMT B ' ||
							            		   'WHERE A.DATA_SN IN (' || P_DATA_SN_LIST || ') ' ||
							 					   'AND A.QLTY_VEHL_CD = B.QLTY_VEHL_CD ' ||
							 					   'AND B.MENU_ID = PG_COMMON.FU_RPAD(''' || P_MENU_ID || ''', 10) ' ||
                                   		           'AND B.USER_EENO = PG_COMMON.FU_RPAD(''' || P_USER_EENO || ''', 7) ' ||
							 					   'GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD ' ||
							                      ') A,' ||
									   			  'TB_VEHL_MGMT B,' ||
									   			  'TB_CODE_MGMT C,' ||
									   			  'TB_CODE_MGMT D ' ||
					              			 'WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD ' ||
					   			  			 'AND A.MDL_MDY_CD = B.MDL_MDY_CD ' ||
					   			  			 'AND B.DL_EXPD_CO_CD = C.DL_EXPD_PRVS_CD ' ||
					   			  			 'AND C.DL_EXPD_G_CD = ''0003'' ' ||
					   			  			 'AND A.DL_EXPD_REGN_CD = D.DL_EXPD_PRVS_CD ' ||
					   			  			 'AND D.DL_EXPD_G_CD = ''0008'' ' ||
                                            ') A,' ||
				      			 			'TB_PDI_IV_INFO_DTL B ' ||
				                       'WHERE B.CLS_YMD = ''' || P_CURR_YMD || ''' ' ||
				 					   'AND A.QLTY_VEHL_CD = B.QLTY_VEHL_CD ' ||
				 					   'AND A.MDL_MDY_CD = B.MDL_MDY_CD ' ||
				 					   'AND A.LANG_CD = B.LANG_CD ' ||
				           			  ') A,' ||
						   			  'TB_PDI_DIVS_INFO B ' ||
		   			              'WHERE A.CLS_YMD = B.WHOT_YMD(+) ' ||
		   			  			  'AND A.QLTY_VEHL_CD = B.QLTY_VEHL_CD(+) ' ||
		   			  			  'AND A.MDL_MDY_CD = B.MDL_MDY_CD(+) ' ||
		   			  			  'AND A.LANG_CD = B.LANG_CD(+) ' ||
		   			  			  'AND A.DL_EXPD_MDL_MDY_CD = B.DL_EXPD_MDL_MDY_CD(+) ' ||
		   			  			  'AND A.N_PRNT_PBCN_NO = B.N_PRNT_PBCN_NO(+) ' ||
		             			 ') A,' ||
		  			 			 'TB_CODE_MGMT B ' ||
	                       'WHERE A.EXPD_RQ_SCN_CD = B.DL_EXPD_PRVS_CD(+) ' ||
	  					   'AND B.DL_EXPD_G_CD(+) = ''0033'' ' ||
	  					   'ORDER BY QLTY_VEHL_CD, LANG_SORT_SN, MDL_MDY_CD, N_PRNT_PBCN_NO, DL_EXPD_MDL_MDY_CD ' ||
	           			  ')'; 

		  OPEN RS FOR V_QUERY;
		  
		  /*** 테스트 용 쿼리 
		  
		  SELECT *
		  FROM (SELECT A.EXPD_CO_NM,
                	   NVL(B.DL_EXPD_PRVS_NM, '') AS EXPD_RQ_SCN_NM, --요청구분
             		   A.QLTY_VEHL_NM,
			 		   A.LANG_CD_NM,
			 		   A.N_PRNT_PBCN_NO,
			 		   A.IV_QTY,
			 		   A.RQ_QTY,
			 		   A.DIVS_QLTY_VEHL_CD,
			 		   A.DIVS_DL_EXPD_MDL_MDY_CD,
			 		   A.DIVS_LANG_CD,
			 		   A.PRTL_IMTR_SBC,
			 		   A.QLTY_VEHL_CD,
			 		   A.MDL_MDY_CD,
			 		   A.DL_EXPD_MDL_MDY_CD,
			 		   A.LANG_CD, 
			 		   A.EXPD_RQ_SCN_CD, --요청구분코드 
			 		   A.CL_SCN_CD
	            FROM (SELECT A.QLTY_VEHL_CD,
	  	   		   	 		 A.MDL_MDY_CD,
				   			 A.LANG_CD,
				   			 A.DL_EXPD_MDL_MDY_CD,
				   			 A.N_PRNT_PBCN_NO,
				   			 A.IV_QTY,
				   			 A.EXPD_CO_CD,
				   			 A.EXPD_REGN_CD,
				   			 A.QLTY_VEHL_NM,
				   			 A.LANG_CD_NM,
				   			 A.EXPD_CO_NM,
				   			 A.LANG_SORT_SN,
				   			 NVL(B.RQ_QTY, 0) AS RQ_QTY,
				   			 NVL(B.DIVS_QLTY_VEHL_CD, '') AS DIVS_QLTY_VEHL_CD,
				   			 NVL(B.DIVS_DL_EXPD_MDL_MDY_CD, A.DL_EXPD_MDL_MDY_CD) AS DIVS_DL_EXPD_MDL_MDY_CD,
				   			 NVL(B.DIVS_LANG_CD, A.LANG_CD) AS DIVS_LANG_CD,
				   			 NVL(B.PRTL_IMTR_SBC, '') AS PRTL_IMTR_SBC,
				   			 NVL(B.DL_EXPD_RQ_SCN_CD, '') AS EXPD_RQ_SCN_CD,
				   			 CASE WHEN A.CL_SCN_CD = 'U' THEN 'Y'
				   			      ELSE 'N' END AS CL_SCN_CD
		              FROM (SELECT B.CLS_YMD,
		   				   		   A.QLTY_VEHL_CD,
								   A.MDL_MDY_CD,
								   A.LANG_CD,
								   B.DL_EXPD_MDL_MDY_CD,
								   B.N_PRNT_PBCN_NO,
								   B.IV_QTY,
								   A.EXPD_CO_CD,
								   A.EXPD_REGN_CD,
								   A.QLTY_VEHL_NM,
								   A.LANG_CD_NM,
								   A.EXPD_CO_NM,
								   A.CL_SCN_CD,
								   A.LANG_SORT_SN 
                            FROM (SELECT A.QLTY_VEHL_CD,
				 	  		  	 		 A.LANG_CD,
							  			 A.MDL_MDY_CD,
							  			 B.DL_EXPD_CO_CD AS EXPD_CO_CD,
							  			 A.DL_EXPD_REGN_CD AS EXPD_REGN_CD,
						      			 '(' || B.QLTY_VEHL_CD || '-' || B.MDL_MDY_CD || ')' || B.QLTY_VEHL_NM AS QLTY_VEHL_NM,
						      			 CASE WHEN A.A_CODE IS NULL THEN '(' || A.LANG_CD || ')'
							  	   		 	  ELSE '(' || A.LANG_CD || '-' || A.A_CODE || ')'
                              			 END || A.LANG_CD_NM AS LANG_CD_NM,										   
							  			 C.DL_EXPD_PRVS_NM AS EXPD_CO_NM,
							  			 A.LANG_SORT_SN,
							  			 A.CL_SCN_CD
					              FROM (SELECT A.QLTY_VEHL_CD,
					   				   		   A.MDL_MDY_CD,
											   A.LANG_CD,
											   MAX(A.LANG_CD_NM) AS LANG_CD_NM,
											   MAX(A.DL_EXPD_REGN_CD) AS DL_EXPD_REGN_CD,
											   MAX(A.A_CODE) AS A_CODE,
											   MAX(A.SORT_SN) AS LANG_SORT_SN,
											   MAX(B.CL_SCN_CD) AS CL_SCN_CD
							            FROM TB_LANG_MGMT A,
							 	  			 TB_AUTH_VEHL_MGMT B
							            WHERE A.DATA_SN IN (:P_DATA_SN_LIST )
							 			AND A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
							 			AND B.MENU_ID = PG_COMMON.FU_RPAD(:P_MENU_ID, 10)
							 			AND B.USER_EENO = PG_COMMON.FU_RPAD(:P_USER_EENO, 7)
							 			GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD
							           ) A,
									   TB_VEHL_MGMT B,
									   TB_CODE_MGMT C,
									   TB_CODE_MGMT D
					              WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
					   			  AND A.MDL_MDY_CD = B.MDL_MDY_CD
					   			  AND B.DL_EXPD_CO_CD = C.DL_EXPD_PRVS_CD
					   			  AND C.DL_EXPD_G_CD = '0003'
					   			  AND A.DL_EXPD_REGN_CD = D.DL_EXPD_PRVS_CD
					   			  AND D.DL_EXPD_G_CD = '0008'
                                 ) A,
				      			 TB_PDI_IV_INFO_DTL B 
				            WHERE B.CLS_YMD = :P_CURR_YMD 
				 			AND A.QLTY_VEHL_CD = B.QLTY_VEHL_CD 
				 			AND A.MDL_MDY_CD = B.MDL_MDY_CD 
				 			AND A.LANG_CD = B.LANG_CD 
				           ) A,
						   TB_PDI_DIVS_INFO B 
		   			  WHERE A.CLS_YMD = B.WHOT_YMD(+) 
		   			  AND A.QLTY_VEHL_CD = B.QLTY_VEHL_CD(+) 
		   			  AND A.MDL_MDY_CD = B.MDL_MDY_CD(+) 
		   			  AND A.LANG_CD = B.LANG_CD(+) 
		   			  AND A.DL_EXPD_MDL_MDY_CD = B.DL_EXPD_MDL_MDY_CD(+) 
		   			  AND A.N_PRNT_PBCN_NO = B.N_PRNT_PBCN_NO(+) 
		             ) A,
		  			 TB_CODE_MGMT B 
	            WHERE A.EXPD_RQ_SCN_CD = B.DL_EXPD_PRVS_CD(+) 
	  			AND B.DL_EXPD_G_CD(+) = '0033' 
	  			ORDER BY QLTY_VEHL_CD, LANG_SORT_SN, MDL_MDY_CD, N_PRNT_PBCN_NO, DL_EXPD_MDL_MDY_CD 
	           ); 
		  	
			***/   
			
	   END SP_GET_PDI_DIVS_INFO;
	   
	   PROCEDURE SP_PDI_DIVS_INFO_SAVE(P_VEHL_CD              VARCHAR2,
	   			 				       P_MDL_MDY_CD	          VARCHAR2,
								       P_LANG_CD              VARCHAR2,
									   P_EXPD_MDL_MDY_CD      VARCHAR2,
								       P_N_PRNT_PBCN_NO       VARCHAR2,
								       P_WHOT_YMD             VARCHAR2,
								       P_EXPD_RQ_SCN_CD       VARCHAR2,
								       P_RQ_QTY		   		  NUMBER,
									   P_DIVS_VEHL_CD	      VARCHAR2,
									   P_DIVS_EXPD_MDL_MDY_CD VARCHAR2,
									   P_DIVS_LANG_CD		  VARCHAR2,
								       P_USER_EENO	          VARCHAR2,
									   P_PRTL_IMTR_SBC        VARCHAR2)
	   IS
	   	 
		 V_CURR_YMD      VARCHAR2(8);
		 
		 V_PREV_RQ_QTY NUMBER;
		 V_DIFF_RQ_QTY NUMBER;
		 
	   BEGIN
	   		
			V_CURR_YMD := TO_CHAR(SYSDATE, 'YYYYMMDD');
			
			--이전 전환수량 존재여부 확인 
			SELECT SUM(RQ_QTY)
			INTO V_PREV_RQ_QTY
			FROM TB_PDI_DIVS_INFO
			WHERE WHOT_YMD = V_CURR_YMD
			AND QLTY_VEHL_CD = P_VEHL_CD
			AND MDL_MDY_CD = P_MDL_MDY_CD
			AND LANG_CD = P_LANG_CD
			AND DL_EXPD_MDL_MDY_CD = P_EXPD_MDL_MDY_CD
			AND N_PRNT_PBCN_NO = P_N_PRNT_PBCN_NO
			AND DL_EXPD_RQ_SCN_CD = P_EXPD_RQ_SCN_CD;
			
			--별도요청 출고정보 수정작업을 위해서 이전 요청수량이 없으면 반드시 NULL 이어야 한다. 
			IF V_PREV_RQ_QTY IS NULL THEN 
			  	 
			    V_DIFF_RQ_QTY := P_RQ_QTY;
				
			ELSE
			
			    V_DIFF_RQ_QTY := P_RQ_QTY - V_PREV_RQ_QTY;
				
			END IF;
			
			PG_DATA.SP_PDI_IV_INFO_UPDATE3(P_VEHL_CD,
	   			 					       P_MDL_MDY_CD,
										   P_LANG_CD,
								    	   P_EXPD_MDL_MDY_CD,
										   P_N_PRNT_PBCN_NO,
										   V_CURR_YMD,
										   V_DIFF_RQ_QTY,
										   P_USER_EENO,
										   'Y');
									
			V_DIFF_RQ_QTY := V_DIFF_RQ_QTY * (-1);
			
			PG_DATA.SP_PDI_IV_INFO_UPDATE3(P_DIVS_VEHL_CD,
										   --재고전환으로 추가되는 항목은 취급설명서 연식과 동일한 연식으로 저장되도록 한다.
	   			 						   --P_MDL_MDY_CD,
										   P_DIVS_EXPD_MDL_MDY_CD,
										   P_DIVS_LANG_CD,
								    	   P_DIVS_EXPD_MDL_MDY_CD,
										   P_N_PRNT_PBCN_NO,
										   V_CURR_YMD,
										   V_DIFF_RQ_QTY,
										   P_USER_EENO,
										   'N');
											 
			UPDATE TB_PDI_DIVS_INFO
		    SET RQ_QTY = P_RQ_QTY,
				DIVS_QLTY_VEHL_CD = P_DIVS_VEHL_CD,
				DIVS_DL_EXPD_MDL_MDY_CD = P_DIVS_EXPD_MDL_MDY_CD,
				DIVS_LANG_CD = P_DIVS_LANG_CD,
			    PRTL_IMTR_SBC = P_PRTL_IMTR_SBC,
			    UPDR_EENO = P_USER_EENO,
			    MDFY_DTM = SYSDATE
	        WHERE QLTY_VEHL_CD = P_VEHL_CD
			AND MDL_MDY_CD = P_MDL_MDY_CD
		    AND LANG_CD = P_LANG_CD
			AND DL_EXPD_MDL_MDY_CD = P_EXPD_MDL_MDY_CD
		    AND N_PRNT_PBCN_NO = P_N_PRNT_PBCN_NO
			AND WHOT_YMD = V_CURR_YMD
			AND DL_EXPD_RQ_SCN_CD = P_EXPD_RQ_SCN_CD;
			
			--수정된 항목이 없다면 Insert 해준다. 
		    IF SQL%NOTFOUND THEN
		   	  
			  INSERT INTO TB_PDI_DIVS_INFO
   			  (QLTY_VEHL_CD,
			   MDL_MDY_CD,
   			   LANG_CD,
			   DL_EXPD_MDL_MDY_CD,
   			   N_PRNT_PBCN_NO,
   			   WHOT_YMD,
   			   DL_EXPD_RQ_SCN_CD,
   			   RQ_QTY,
			   DIVS_QLTY_VEHL_CD,
			   DIVS_DL_EXPD_MDL_MDY_CD,
			   DIVS_LANG_CD,
   			   PRTL_IMTR_SBC,
   			   PPRR_EENO,
   			   FRAM_DTM,
   			   UPDR_EENO,
   			   MDFY_DTM
			  )
			  VALUES(P_VEHL_CD,
			  		 P_MDL_MDY_CD,
   					 P_LANG_CD,
					 P_EXPD_MDL_MDY_CD,
   					 P_N_PRNT_PBCN_NO,
   					 V_CURR_YMD,
   					 P_EXPD_RQ_SCN_CD,
   					 P_RQ_QTY,
					 P_DIVS_VEHL_CD,
					 P_DIVS_EXPD_MDL_MDY_CD,
					 P_DIVS_LANG_CD,
   					 P_PRTL_IMTR_SBC,
   					 P_USER_EENO,
   					 SYSDATE,
   					 P_USER_EENO,
   					 SYSDATE
					);
		   END IF;
	   
	   END SP_PDI_DIVS_INFO_SAVE;
	   
	   PROCEDURE SP_PDI_DIVS_INFO_DELETE(P_VEHL_CD              VARCHAR2,
	   			 				         P_MDL_MDY_CD	        VARCHAR2,
								         P_LANG_CD              VARCHAR2,
										 P_EXPD_MDL_MDY_CD      VARCHAR2,
								         P_N_PRNT_PBCN_NO       VARCHAR2,
								         P_WHOT_YMD             VARCHAR2,
								         P_EXPD_RQ_SCN_CD       VARCHAR2,
								         P_RQ_QTY		   		NUMBER,
										 P_DIVS_VEHL_CD	        VARCHAR2,
										 P_DIVS_EXPD_MDL_MDY_CD VARCHAR2,
										 P_DIVS_LANG_CD		    VARCHAR2,
								         P_USER_EENO	        VARCHAR2,
										 P_PRTL_IMTR_SBC        VARCHAR2)
	   IS
	   	 
		 V_RQ_QTY               NUMBER;
		 V_DIVS_VEHL_CD         VARCHAR2(4);
		 V_DIVS_EXPD_MDL_MDY_CD VARCHAR2(2);
		 V_DIVS_LANG_CD         VARCHAR2(3);
		 
	   BEGIN
	   		
			SELECT SUM(RQ_QTY),
				   MAX(DIVS_QLTY_VEHL_CD),
				   MAX(DIVS_DL_EXPD_MDL_MDY_CD),
				   MAX(DIVS_LANG_CD)
			INTO V_RQ_QTY,
			     V_DIVS_VEHL_CD,
				 V_DIVS_EXPD_MDL_MDY_CD,
				 V_DIVS_LANG_CD
			FROM TB_PDI_DIVS_INFO
			WHERE WHOT_YMD = P_WHOT_YMD
			AND QLTY_VEHL_CD = P_VEHL_CD
			AND MDL_MDY_CD = P_MDL_MDY_CD
			AND LANG_CD = P_LANG_CD
			AND DL_EXPD_MDL_MDY_CD = P_EXPD_MDL_MDY_CD
			AND N_PRNT_PBCN_NO = P_N_PRNT_PBCN_NO
			AND DL_EXPD_RQ_SCN_CD = P_EXPD_RQ_SCN_CD;
			
			PG_DATA.SP_PDI_IV_INFO_UPDATE3(P_VEHL_CD,
	   			 					       P_MDL_MDY_CD,
										   P_LANG_CD,
								    	   P_EXPD_MDL_MDY_CD,
										   P_N_PRNT_PBCN_NO,
										   P_WHOT_YMD,
										   V_RQ_QTY * (-1),
										   P_USER_EENO,
										   'Y');
											 
			PG_DATA.SP_PDI_IV_INFO_UPDATE3(V_DIVS_VEHL_CD,
	   			 					       V_DIVS_EXPD_MDL_MDY_CD,
										   V_DIVS_LANG_CD,
								    	   V_DIVS_EXPD_MDL_MDY_CD,
										   P_N_PRNT_PBCN_NO,
										   P_WHOT_YMD,
										   V_RQ_QTY,
										   P_USER_EENO,
										   'Y');
											 
			DELETE FROM TB_PDI_DIVS_INFO
			WHERE WHOT_YMD = P_WHOT_YMD
			AND QLTY_VEHL_CD = P_VEHL_CD
			AND MDL_MDY_CD = P_MDL_MDY_CD
			AND LANG_CD = P_LANG_CD
			AND DL_EXPD_MDL_MDY_CD = P_EXPD_MDL_MDY_CD
			AND N_PRNT_PBCN_NO = P_N_PRNT_PBCN_NO
			AND DL_EXPD_RQ_SCN_CD = P_EXPD_RQ_SCN_CD;
	   
	   END SP_PDI_DIVS_INFO_DELETE;									 
										 
END PG_VEHL_IV_DIVS;