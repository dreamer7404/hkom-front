CREATE OR REPLACE PACKAGE BODY HOMMS_ADM.PG_BATCH_START AS

/**********************************************************/	
	   PROCEDURE SP_BATCH_START
	   IS
	   	 
	   BEGIN
				PG_INTERFACE_APS.APS_INTERFACE_DATE_HMC;
				
				PG_INTERFACE_PROD_MST.PROD_MST_INTERFACE_DATE_HMC;
				
				PG_SEWHA_IV_INFO.SP_SEWHA_IV_INFO_BATCH;
				
				PG_PDI_IV_INFO.SP_PDI_IV_INFO_BATCH;
				
	   END SP_BATCH_START;




/**********************************************************/
	   PROCEDURE SP_BATCH_WORK
	   
	   IS
	   		V_CHK_HMC     VARCHAR2(1);
	   		V_T_CHK       VARCHAR2(1);
	   BEGIN
	   
			PG_DATA.SP_NATL_VEHL_LANG_UPDATE;

			PG_INTERFACE_APS.APS_INTERFACE_HMC;
			
			PG_INTERFACE_PROD_MST.PROD_MST_INTERFACE_HMC2(TO_CHAR(SYSDATE,'YYYYMMDD'),'02');
			

            SELECT DECODE(COUNT(*),3,'Y','N')
              INTO V_CHK_HMC
			  FROM TB_BATCH_FNH_INFO
			 WHERE AFFR_SCN_CD in ('01','02','03')
			   AND DL_EXPD_CO_CD = '01'
			   AND BTCH_FNH_YMD = TO_CHAR(SYSDATE,'YYYYMMDD');
			
			IF V_CHK_HMC = 'Y' THEN
			-- JOB NEXT TIME SET (job No 확인 후 교체  10 --> xx) PG_BATCH_START.SP_BATCH_WORK
				DBMS_JOB.NEXT_DATE(31, ((TO_DATE(TO_CHAR(SYSDATE + 1, 'YYYY-MM-DD')) + INTERVAL '6' HOUR) + INTERVAL '5' MINUTE) );
				SEND_URGENT_PRINT_MAIL;
			ELSE
				V_T_CHK := GET_TIME_CHK('02');
				
				IF V_T_CHK = 'Y' THEN
				    -- JOB 10MIN DELAY
					DBMS_JOB.NEXT_DATE(31, (SYSDATE + INTERVAL '10' MINUTE) );
			    ELSE
			        -- 작업 실패 로그 저장 후 TIME SET
			        PG_INTERFACE_APS.WRITE_BATCH_EXE_LOG('생산마스터배치작업_HMC2', SYSDATE, 'F', 'PROD_MST_INTERFACE_HMC2(02) :: ERP 배치 미실행 확인');
			        DBMS_JOB.NEXT_DATE(31, ((TO_DATE(TO_CHAR(SYSDATE + 1, 'YYYY-MM-DD')) + INTERVAL '6' HOUR) + INTERVAL '5' MINUTE) );
			    END IF;
			END IF;
				
	   END SP_BATCH_WORK;




/**********************************************************/
	   PROCEDURE SP_BATCH_WORK2
	   
	   IS
	   		V_CHK_HMC     VARCHAR2(1);
	   		V_T_CHK       VARCHAR2(1);
	   BEGIN
	   
			PG_DATA.SP_NATL_VEHL_LANG_UPDATE;

			PG_INTERFACE_PROD_MST.PROD_MST_INTERFACE_HMC2(TO_CHAR(SYSDATE,'YYYYMMDD'),'01');

            SELECT DECODE(COUNT(*),0,'N','Y')
              INTO V_CHK_HMC
			  FROM TB_BATCH_FNH_INFO
			 WHERE AFFR_SCN_CD = '04'
			   AND DL_EXPD_CO_CD = '01'
			   AND BTCH_FNH_YMD = TO_CHAR(SYSDATE,'YYYYMMDD');
			
			IF V_CHK_HMC = 'Y' THEN
			    -- JOB NEXT TIME SET
				DBMS_JOB.NEXT_DATE(51, ((TO_DATE(TO_CHAR(SYSDATE + 1, 'YYYY-MM-DD')) + INTERVAL '15' HOUR) + INTERVAL '00' MINUTE) );
			ELSE
				V_T_CHK := GET_TIME_CHK('01');
				
				IF V_T_CHK = 'Y' THEN
				    -- JOB 10MIN DELAY
					DBMS_JOB.NEXT_DATE(51, (SYSDATE + INTERVAL '10' MINUTE) );
			    ELSE
			        -- 작업 실패 로그 저장 후 TIME SET
			        PG_INTERFACE_APS.WRITE_BATCH_EXE_LOG('생산마스터배치작업_HMC2', SYSDATE, 'F', 'PROD_MST_INTERFACE_HMC2(01) :: ERP 배치 미실행 확인');
			        DBMS_JOB.NEXT_DATE(51, ((TO_DATE(TO_CHAR(SYSDATE + 1, 'YYYY-MM-DD')) + INTERVAL '15' HOUR) + INTERVAL '00' MINUTE) );
			    END IF;
			END IF;
				
	   END SP_BATCH_WORK2;



/**********************************************************/
	   FUNCTION GET_TIME_CHK(ET_GUBN_CD IN VARCHAR2) RETURN VARCHAR2

	   IS
		 T_CHK VARCHAR2(1);

	   BEGIN
	   
	        IF ET_GUBN_CD = '02' THEN
	   
				SELECT CASE WHEN SYSDATE < (TO_DATE(TO_CHAR(SYSDATE, 'YYYY-MM-DD')) + INTERVAL '14' HOUR) THEN 'Y'
	                        ELSE 'N'
	                   END CHK
				  INTO T_CHK
				  FROM DUAL;
				  			
			ELSE
			
				SELECT CASE WHEN SYSDATE < (TO_DATE(TO_CHAR(SYSDATE, 'YYYY-MM-DD')) + INTERVAL '22' HOUR) THEN 'Y'
	                        ELSE 'N'
	                   END CHK
				  INTO T_CHK
				  FROM DUAL;
				  
			END IF;
			  
			RETURN T_CHK;
			
	   END GET_TIME_CHK;

/**********************************************************/ 




END PG_BATCH_START;