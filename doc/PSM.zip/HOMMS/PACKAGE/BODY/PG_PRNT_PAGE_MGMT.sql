CREATE OR REPLACE PACKAGE BODY PG_PRNT_PAGE_MGMT AS

  /** 인쇄페이지 관리 */
   --인쇄페이지관리 리스트 조회
   /**
   PROCEDURE SP_PRNT_PAGE_MGMT(P_DL_EXPD_PRVS_CD    IN VARCHAR2,
                               P_DL_EXPD_PAC_SCN_CD IN VARCHAR2,
                               P_DL_EXPD_PDI_CD     IN VARCHAR2,
                               P_UPDR_EENO          IN VARCHAR2,
                               RS OUT REFCUR) 
    IS
  BEGIN
    OPEN RS FOR
    
    SELECT A.DL_EXPD_PRVS_CD, A.DL_EXPD_PRVS_NM, B.MDL_MDY_CD, B.QLTY_VEHL_CD, B.QLTY_VEHL_NM, C.LANG_CD, C.LANG_CD_NM, C.DL_EXPD_REGN_CD
        , D.N_PRNT_PBCN_NO, D.LRNK_CD, D.RGST_YMD, D.N_PRNT_PBCN_NO || '-' || D.LRNK_CD AS PRNT_PBCN_NM
        ,SUM(CASE WHEN  DEPPC1_SN = '0' THEN   END_PG_SN ELSE 0 END) A0
        ,SUM(CASE WHEN  DEPPC1_SN = '1' THEN   END_PG_SN ELSE 0 END) A1
        ,SUM(CASE WHEN  DEPPC1_SN = '2' THEN   END_PG_SN ELSE 0 END) A2
        ,SUM(CASE WHEN  DEPPC1_SN = '3' THEN   END_PG_SN ELSE 0 END) A3
        ,SUM(CASE WHEN  DEPPC1_SN = '4' THEN   END_PG_SN ELSE 0 END) A4
        ,SUM(CASE WHEN  DEPPC1_SN = '5' THEN   END_PG_SN ELSE 0 END) A5
        ,SUM(CASE WHEN  DEPPC1_SN = '6' THEN   END_PG_SN ELSE 0 END) A6
        ,SUM(CASE WHEN  DEPPC1_SN = '7' THEN   END_PG_SN ELSE 0 END) A7
        ,SUM(CASE WHEN  DEPPC1_SN = '8' THEN   END_PG_SN ELSE 0 END) A8
        ,SUM(CASE WHEN  DEPPC1_SN = '9' THEN   END_PG_SN ELSE 0 END) A9
        ,SUM(CASE WHEN  DEPPC1_SN = '10' THEN   END_PG_SN ELSE 0 END) A10
        ,SUM(CASE WHEN  DEPPC1_SN = '11' THEN   END_PG_SN ELSE 0 END) A11
        ,SUM(CASE WHEN  DEPPC1_SN = '12' THEN   END_PG_SN ELSE 0 END) A12
        ,SUM(CASE WHEN  DEPPC1_SN = '13' THEN   END_PG_SN ELSE 0 END) AI
    FROM TB_CODE_MGMT A,
         TB_VEHL_MGMT B,
         TB_LANG_MGMT C,
         TB_PRNT_PAGE_MGMT D
    WHERE A.DL_EXPD_G_CD = '0003'
        AND A.DL_EXPD_PRVS_CD = B.DL_EXPD_CO_CD
        AND B.QLTY_VEHL_CD = C.QLTY_VEHL_CD 
        AND B.MDL_MDY_CD = C.MDL_MDY_CD
        AND C.QLTY_VEHL_CD = D.QLTY_VEHL_CD
        AND C.MDL_MDY_CD = D.MDL_MDY_CD
        AND C.LANG_CD = D.LANG_CD
        AND B.DL_EXPD_CO_CD = DECODE(P_DL_EXPD_PRVS_CD, 'ALL', B.DL_EXPD_CO_CD, P_DL_EXPD_PRVS_CD)
        AND B.DL_EXPD_PDI_CD = DECODE(P_DL_EXPD_PDI_CD, 'ALL', B.DL_EXPD_PDI_CD, P_DL_EXPD_PDI_CD)
        AND B.DL_EXPD_PAC_SCN_CD = DECODE(P_DL_EXPD_PAC_SCN_CD, 'ALL', B.DL_EXPD_PAC_SCN_CD, P_DL_EXPD_PAC_SCN_CD)
        AND D.UPDR_EENO = DECODE(P_UPDR_EENO, '', D.UPDR_EENO, PG_COMMON.FU_RPAD(P_UPDR_EENO, 7))           
    GROUP BY A.DL_EXPD_PRVS_CD, A.DL_EXPD_PRVS_NM, B.MDL_MDY_CD, B.QLTY_VEHL_CD, B.QLTY_VEHL_NM, C.LANG_CD, C.LANG_CD_NM,  C.DL_EXPD_REGN_CD, D.N_PRNT_PBCN_NO, D.LRNK_CD, D.RGST_YMD
    ORDER BY A.DL_EXPD_PRVS_CD, B.QLTY_VEHL_CD DESC;    
    
  END SP_PRNT_PAGE_MGMT;
  **/
   
   --인쇄페이지관리 리스트 조회2 
   PROCEDURE SP_PRNT_PAGE_MGMT2(P_MENU_ID	      IN VARCHAR2,
								P_USER_EENO 	  IN VARCHAR2,
   			 	                P_QLTY_VEHL_CD    IN VARCHAR2,
                                P_MDL_MDY_CD      IN VARCHAR2,
                                P_DL_EXPD_REGN_CD IN VARCHAR2, 
                                P_LANG_CD         IN VARCHAR2,
                                RS OUT REFCUR)
   IS
   	 
	 V_FROM_MDL_MDY VARCHAR(2);
	 V_TO_MDL_MDY   VARCHAR(2);
	
   BEGIN
   		
		PG_COMMON.SP_GET_VALID_MDL_MDY4(TO_CHAR(SYSDATE, 'YYYYMMDD'), '', V_FROM_MDL_MDY, V_TO_MDL_MDY);
		
		OPEN RS FOR
    		 SELECT B.QLTY_VEHL_CD,
			        B.MDL_MDY_CD,
					B.LANG_CD,
					MAX(C.QLTY_VEHL_NM) AS QLTY_VEHL_NM,
					MAX(B.LANG_CD_NM) AS LANG_CD_NM,
					MAX(B.DL_EXPD_REGN_CD) AS DL_EXPD_REGN_CD,
					A.N_PRNT_PBCN_NO,
					A.LRNK_CD,
					MAX(A.RGST_YMD) AS RGST_YMD,
					A.N_PRNT_PBCN_NO || '-' || A.LRNK_CD AS PRNT_PBCN_NM,
			        MAX(D.DL_EXPD_PRVS_CD) AS DL_EXPD_PRVS_CD,
					MAX(D.DL_EXPD_PRVS_NM) AS DL_EXPD_PRVS_NM,
					SUM(CASE WHEN  DEPPC1_SN = '0'  THEN END_PG_SN ELSE 0 END) A0,
        			SUM(CASE WHEN  DEPPC1_SN = '1'  THEN END_PG_SN ELSE 0 END) A1,
        			SUM(CASE WHEN  DEPPC1_SN = '2'  THEN END_PG_SN ELSE 0 END) A2,
        			SUM(CASE WHEN  DEPPC1_SN = '3'  THEN END_PG_SN ELSE 0 END) A3,
        			SUM(CASE WHEN  DEPPC1_SN = '4'  THEN END_PG_SN ELSE 0 END) A4,
        			SUM(CASE WHEN  DEPPC1_SN = '5'  THEN END_PG_SN ELSE 0 END) A5,
        			SUM(CASE WHEN  DEPPC1_SN = '6'  THEN END_PG_SN ELSE 0 END) A6,
        			SUM(CASE WHEN  DEPPC1_SN = '7'  THEN END_PG_SN ELSE 0 END) A7,
        			SUM(CASE WHEN  DEPPC1_SN = '8'  THEN END_PG_SN ELSE 0 END) A8,
        			SUM(CASE WHEN  DEPPC1_SN = '9'  THEN END_PG_SN ELSE 0 END) A9,
        			SUM(CASE WHEN  DEPPC1_SN = '10' THEN END_PG_SN ELSE 0 END) A10,
        			SUM(CASE WHEN  DEPPC1_SN = '11' THEN END_PG_SN ELSE 0 END) A11,
        			SUM(CASE WHEN  DEPPC1_SN = '12' THEN END_PG_SN ELSE 0 END) A12,
        			SUM(CASE WHEN  DEPPC1_SN = '13' THEN END_PG_SN ELSE 0 END) AI
			 FROM TB_PRNT_PAGE_MGMT A,
			      TB_LANG_MGMT B,
				  TB_VEHL_MGMT C,
				  TB_CODE_MGMT D,
				  --TB_CODE_MGMT E,
				  (SELECT QLTY_VEHL_CD
                   FROM TB_AUTH_VEHL_MGMT
                   WHERE MENU_ID = PG_COMMON.FU_RPAD(P_MENU_ID, 10)
                   AND USER_EENO = PG_COMMON.FU_RPAD(P_USER_EENO, 7)
                   GROUP BY QLTY_VEHL_CD
                  ) F
			 WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
			 AND A.MDL_MDY_CD = B.MDL_MDY_CD
			 AND A.LANG_CD = B.LANG_CD
			 AND B.QLTY_VEHL_CD = C.QLTY_VEHL_CD
			 AND B.MDL_MDY_CD = C.MDL_MDY_CD
			 AND B.QLTY_VEHL_CD = F.QLTY_VEHL_CD
			 AND B.QLTY_VEHL_CD = DECODE(P_QLTY_VEHL_CD, 'ALL', B.QLTY_VEHL_CD, P_QLTY_VEHL_CD)
			 AND B.MDL_MDY_CD BETWEEN V_FROM_MDL_MDY AND V_TO_MDL_MDY
			 AND B.MDL_MDY_CD = DECODE(P_MDL_MDY_CD, 'ALL', B.MDL_MDY_CD, P_MDL_MDY_CD)
			 AND B.LANG_CD = DECODE(P_LANG_CD, 'ALL', B.LANG_CD, P_LANG_CD)
			 AND B.DL_EXPD_REGN_CD = DECODE(P_DL_EXPD_REGN_CD, 'ALL', B.DL_EXPD_REGN_CD, P_DL_EXPD_REGN_CD)
			 AND B.USE_YN = 'Y'
			 AND C.USE_YN = 'Y'
			 AND D.DL_EXPD_G_CD = '0003'
			 AND D.DL_EXPD_PRVS_CD = C.DL_EXPD_CO_CD
			 --AND E.DL_EXPD_G_CD = '0008'
			 --AND E.DL_EXPD_PRVS_CD = B.DL_EXPD_REGN_CD 
			 GROUP BY B.QLTY_VEHL_CD, B.MDL_MDY_CD, B.LANG_CD, A.N_PRNT_PBCN_NO, A.LRNK_CD
			 --ORDER BY B.QLTY_VEHL_CD, MAX(D.SORT_SN); 
			 --[변경]. 2010.01.27.김동근 로직 처리된 발간번호 최근 순으로 정렬방식 변경 
			 --ORDER BY B.QLTY_VEHL_CD, MAX(B.SORT_SN), B.MDL_MDY_CD, A.N_PRNT_PBCN_NO 
			 ORDER BY B.QLTY_VEHL_CD, MAX(B.SORT_SN), PG_COMMON.FU_GET_SORT_PBCN(A.N_PRNT_PBCN_NO) DESC, A.N_PRNT_PBCN_NO
			 ; 

   END SP_PRNT_PAGE_MGMT2;
   
   -- 인쇄페이지관리 수정내용조회
   PROCEDURE SP_UPDATE_VIEW(P_N_PRNT_PBCN_NO IN VARCHAR2,
                            P_LRNK_CD        IN VARCHAR2,
                            RS OUT REFCUR)  
   IS
   BEGIN
    
	OPEN RS FOR
     SELECT
         D.N_PRNT_PBCN_NO,
         D.LRNK_CD,
         D.QLTY_VEHL_CD,
         D.MDL_MDY_CD,
         D.LANG_CD,
         D.RGST_YMD,
         C.DL_EXPD_REGN_CD
        ,SUM(CASE WHEN  D.DEPPC1_SN = '0' THEN   D.END_PG_SN ELSE 0 END) AS A0
        ,SUM(CASE WHEN  D.DEPPC1_SN = '1' THEN   D.END_PG_SN ELSE 0 END) AS A1
        ,SUM(CASE WHEN  D.DEPPC1_SN = '2' THEN   D.END_PG_SN ELSE 0 END) AS A2 
        ,SUM(CASE WHEN  D.DEPPC1_SN = '3' THEN   D.END_PG_SN ELSE 0 END) AS A3
        ,SUM(CASE WHEN  D.DEPPC1_SN = '4' THEN   D.END_PG_SN ELSE 0 END) AS A4
        ,SUM(CASE WHEN  D.DEPPC1_SN = '5' THEN   D.END_PG_SN ELSE 0 END) AS A5
        ,SUM(CASE WHEN  D.DEPPC1_SN = '6' THEN   D.END_PG_SN ELSE 0 END) AS A6
        ,SUM(CASE WHEN  D.DEPPC1_SN = '7' THEN   D.END_PG_SN ELSE 0 END) AS A7
        ,SUM(CASE WHEN  D.DEPPC1_SN = '8' THEN   D.END_PG_SN ELSE 0 END) AS A8
        ,SUM(CASE WHEN  D.DEPPC1_SN = '9' THEN   D.END_PG_SN ELSE 0 END) AS A9
        ,SUM(CASE WHEN  D.DEPPC1_SN = '10' THEN   D.END_PG_SN ELSE 0 END) AS A10
        ,SUM(CASE WHEN  D.DEPPC1_SN = '11' THEN   D.END_PG_SN ELSE 0 END) AS A11
        ,SUM(CASE WHEN  D.DEPPC1_SN = '12' THEN   D.END_PG_SN ELSE 0 END) AS A12
        ,SUM(CASE WHEN  D.DEPPC1_SN = '13' THEN   D.END_PG_SN ELSE 0 END) AS AI
    FROM 
         TB_CODE_MGMT A,
         TB_VEHL_MGMT B,
         TB_LANG_MGMT C,
         TB_PRNT_PAGE_MGMT D
    WHERE A.DL_EXPD_G_CD = '0008'                          
    AND A.DL_EXPD_PRVS_CD = B.DL_EXPD_CO_CD
    AND B.QLTY_VEHL_CD = C.QLTY_VEHL_CD 
    AND B.MDL_MDY_CD = C.MDL_MDY_CD
    AND C.QLTY_VEHL_CD = D.QLTY_VEHL_CD
    AND C.MDL_MDY_CD = D.MDL_MDY_CD
    AND C.LANG_CD = D.LANG_CD         
    AND D.N_PRNT_PBCN_NO = P_N_PRNT_PBCN_NO
    AND D.LRNK_CD = P_LRNK_CD
    GROUP BY D.N_PRNT_PBCN_NO, D.LRNK_CD, D.QLTY_VEHL_CD,D. MDL_MDY_CD, D.LANG_CD, D.RGST_YMD, C.DL_EXPD_REGN_CD;
    
  END SP_UPDATE_VIEW;
  
  -- 인쇄페이지 관리 입력
  PROCEDURE SP_INSERT(P_N_PRNT_PBCN_NO IN VARCHAR2,
                      P_QLTY_VEHL_CD   IN VARCHAR2,
                      P_MDL_MDY_CD 	   IN VARCHAR2,
                      P_LANG_CD 	   IN VARCHAR2,
                      P_RGST_YMD 	   IN VARCHAR2,
                      P_DEPPC1_SN 	   IN NUMBER,
                      P_END_PG_SN 	   IN NUMBER,
                      P_PPRR_EENO 	   IN VARCHAR2,
                      P_UPDR_EENO 	   IN VARCHAR2,
                      P_LRNK_CD 	   IN VARCHAR2)
    IS
  BEGIN
    INSERT INTO
          TB_PRNT_PAGE_MGMT (N_PRNT_PBCN_NO,
                              LRNK_CD,
                              QLTY_VEHL_CD,
                              MDL_MDY_CD,
                              LANG_CD,
                              RGST_YMD,
                              DEPPC1_SN,
                              END_PG_SN,
                              PPRR_EENO,
                              FRAM_DTM,
                              UPDR_EENO,
                              MDFY_DTM)
                      VALUES(P_N_PRNT_PBCN_NO,
                            NVL(P_LRNK_CD, '01'),
                            P_QLTY_VEHL_CD,
                            P_MDL_MDY_CD,
                            P_LANG_CD,
                            P_RGST_YMD,
                            P_DEPPC1_SN,
                            P_END_PG_SN,
                            P_PPRR_EENO,
                            SYSDATE,
                            P_UPDR_EENO,
                            SYSDATE);
  END SP_INSERT;
  
   -- 인쇄페이지관리 삭제
   PROCEDURE SP_DELETE(P_N_PRNT_PBCN_NO IN VARCHAR2,
                       P_LRNK_CD 		IN VARCHAR2)
    IS
   BEGIN
    DELETE FROM
      TB_PRNT_PAGE_MGMT
    WHERE
      N_PRNT_PBCN_NO = P_N_PRNT_PBCN_NO
    AND
      LRNK_CD = P_LRNK_CD;
   END SP_DELETE;


  /** 인쇄배열표 */
  -- 인쇄발간번호로 인쇄배열표 조회(POP-UP화면용) 인쇄배열표 정보가 없을 때
  PROCEDURE SP_GET_PAGE_INFO(P_N_PRNT_PBCN_NO IN VARCHAR2,
                             P_QLTY_VEHL_CD   IN VARCHAR2,
                             P_MDL_MDY_CD     IN VARCHAR2,
                             P_LANG_CD        IN VARCHAR2,
                             P_LRNK_CD        IN VARCHAR2,
                             RS OUT REFCUR)
    IS
  BEGIN
    OPEN RS FOR
      SELECT
            N_PRNT_PBCN_NO,
            LRNK_CD,
            A.QLTY_VEHL_CD,
            A.MDL_MDY_CD,
            A.LANG_CD,                   
            DEPPC1_SN,
            END_PG_SN                              
                   FROM TB_PRNT_PAGE_MGMT A,
                        TB_LANG_MGMT B,
                        TB_VEHL_MGMT C
                   WHERE A.N_PRNT_PBCN_NO = P_N_PRNT_PBCN_NO
                   AND A.LRNK_CD = P_LRNK_CD
                   AND A.QLTY_VEHL_CD = P_QLTY_VEHL_CD
                   AND A.MDL_MDY_CD = P_MDL_MDY_CD
                   AND A.LANG_CD = P_LANG_CD
                   AND A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
                   AND A.MDL_MDY_CD = B.MDL_MDY_CD
                   AND A.LANG_CD = B.LANG_CD
                   AND A.QLTY_VEHL_CD = C.QLTY_VEHL_CD
                   AND A.MDL_MDY_CD = C.MDL_MDY_CD
                   ORDER BY A.DEPPC1_SN ASC;                   
                        
   END SP_GET_PAGE_INFO; 
 
   -- 인쇄발간번호로 인쇄배열표 조회(POP-UP화면용) 인쇄배열표 정보가 있을 때                           
   PROCEDURE SP_GET_ALGN_INFO(P_N_PRNT_PBCN_NO IN VARCHAR2,
                              P_QLTY_VEHL_CD   IN VARCHAR2,
                              P_MDL_MDY_CD     IN VARCHAR2,
                              P_LANG_CD        IN VARCHAR2,
                              P_LRNK_CD        IN VARCHAR2,
                              RS OUT REFCUR) 
     IS
  BEGIN
    OPEN RS FOR
      SELECT                             
            DEPPC1_SN,
            DL_EXPD_PRNT_PG_SN,
            LRNK_CD
                   FROM
                      TB_PRNT_ALGN_INFO                       
                   WHERE
                      N_PRNT_PBCN_NO = P_N_PRNT_PBCN_NO
                   AND
                      LRNK_CD = P_LRNK_CD
                   AND
                      QLTY_VEHL_CD = P_QLTY_VEHL_CD
                   AND
                      MDL_MDY_CD = P_MDL_MDY_CD
                   AND
                      LANG_CD = P_LANG_CD                  
                   ORDER BY DEPPC1_SN ASC, DL_EXPD_PRNT_PG_SN ASC;
   END SP_GET_ALGN_INFO;                
  
   -- 인쇄배열표 삭제
   PROCEDURE SP_DELETE_ARRAY(P_N_PRNT_PBCN_NO IN VARCHAR2,
                             P_LRNK_CD IN VARCHAR2)
      IS
   BEGIN
      DELETE FROM
        TB_PRNT_ALGN_INFO
      WHERE
        N_PRNT_PBCN_NO = P_N_PRNT_PBCN_NO
      AND
        LRNK_CD = P_LRNK_CD;
   END SP_DELETE_ARRAY;
  
   -- 인쇄배열표 저장 
   PROCEDURE SP_INSERT_ARRAY(P_N_PRNT_PBCN_NO     IN VARCHAR2,
                             P_QLTY_VEHL_CD       IN VARCHAR2,
                             P_MDL_MDY_CD 	      IN VARCHAR2,
                             P_LANG_CD            IN VARCHAR2,
                             P_DEPPC1_SN          IN NUMBER,
                             P_DL_EXPD_PRNT_PG_SN IN NUMBER,
                             P_PRNT_INSD_PG_SBC   IN VARCHAR2,
                             P_DEPPR1_YN 		  IN VARCHAR2,
                             P_PPRR_EENO 		  IN VARCHAR2,
                             P_UPDR_EENO 		  IN VARCHAR2,
                             P_LRNK_CD 			  IN VARCHAR2)
     IS
   BEGIN        
      INSERT INTO
        TB_PRNT_ALGN_INFO (N_PRNT_PBCN_NO,
                           LRNK_CD,
                           QLTY_VEHL_CD,
                           MDL_MDY_CD,
                           LANG_CD,
                           DEPPC1_SN,
                           DL_EXPD_PRNT_PG_SN,
                           PRNT_INSD_PG_SBC,
                           DEPPR1_YN,
                           PPRR_EENO,
                           FRAM_DTM,
                           UPDR_EENO,
                           MDFY_DTM)
                                  VALUES(P_N_PRNT_PBCN_NO,
                                         P_LRNK_CD,
                                         P_QLTY_VEHL_CD,
                                         P_MDL_MDY_CD,
                                         P_LANG_CD,
                                         P_DEPPC1_SN,
                                         P_DL_EXPD_PRNT_PG_SN,
                                         P_PRNT_INSD_PG_SBC,
                                         P_DEPPR1_YN,
                                         P_PPRR_EENO,
                                         SYSDATE,
                                         P_UPDR_EENO,
                                         SYSDATE);
   END SP_INSERT_ARRAY;     
  
   -- 제작의뢰 수정페이지 카운트구하기
    PROCEDURE SP_GET_MDFY_PAGE_COUNT(P_N_PRNT_PBCN_NO VARCHAR2,
                                     RS OUT REFCUR)
    IS
    BEGIN
         
         OPEN RS FOR
            SELECT
              COUNT(N_PRNT_PBCN_NO) AS PAGECOUNT
            FROM
              TB_PRNT_ALGN_INFO
            WHERE
              N_PRNT_PBCN_NO = P_N_PRNT_PBCN_NO;
                              
    END SP_GET_MDFY_PAGE_COUNT;              
    
	PROCEDURE SP_GET_MDFY_PAGE_COUNT2(P_N_PRNT_PBCN_NO VARCHAR2,
	                                  P_LRNK_CD 	   VARCHAR2,
                                      RS OUT REFCUR)
	IS
	BEGIN
		 
		 OPEN RS FOR
              SELECT COUNT(N_PRNT_PBCN_NO) AS PAGECOUNT
              FROM TB_PRNT_ALGN_INFO
              WHERE N_PRNT_PBCN_NO = P_N_PRNT_PBCN_NO
			  AND LRNK_CD = P_LRNK_CD;
			  
	END SP_GET_MDFY_PAGE_COUNT2;
	
  /** 인쇄세부내역 */
   -- 인쇄세부내역 저장
   PROCEDURE SP_INSERT_ARRAY_DETAIL(P_QLTY_VEHL_CD 	     IN VARCHAR2,
                                    P_MDL_MDY_CD   	     IN VARCHAR2,
                                    P_LANG_CD 	 		 IN VARCHAR2,
                                    P_RQ_QTY  	 		 IN VARCHAR2,
                                    P_DLVG_PARR_YMD      IN VARCHAR2,
                                    P_DL_EXPD_DLVG_PL_CD IN VARCHAR2,
                                    P_N_PRNT_PBCN_NO 	 IN VARCHAR2,
                                    P_OLD_PRNT_PBCN_NO 	 IN VARCHAR2,
                                    P_I_WAY_SBC 		 IN VARCHAR2,
                                    P_BKBD_WAY_SBC 		 IN VARCHAR2,
                                    P_PG_MGN_SBC 		 IN VARCHAR2,
                                    P_DEPCQ1_SBC 		 IN VARCHAR2,
                                    P_DEIPQ1_SBC 		 IN VARCHAR2,
                                    P_PRNT_CVR_SBC 		 IN VARCHAR2,
                                    P_PRNT_INSD_PG_SBC 	 IN VARCHAR2,
                                    P_C_PRNT_CVR_SBC 	 IN VARCHAR2,
                                    P_C_PRNT_INSD_PG_SBC IN VARCHAR2,
                                    P_CVR_CEG_SBC 		 IN VARCHAR2,
                                    P_PG_NL 			 IN NUMBER,
                                    P_CVR_NL 			 IN NUMBER,
                                    P_EXPD_NL 			 IN NUMBER,
                                    P_GRN_DOC_NL 		 IN NUMBER,
                                    P_POST_CRD_NL 		 IN NUMBER,
                                    P_EOFU1_NL 			 IN NUMBER,
                                    P_NR_FLM_MKO_NL 	 IN NUMBER,
                                    P_DGTL_PRNT_NL 		 IN NUMBER,
                                    P_OORD_EDIT_PG_NL 	 IN NUMBER,
                                    P_DEPC1_QTY 		 IN NUMBER,
                                    P_REM 				 IN VARCHAR2,
                                    P_IV_QTY 			 IN NUMBER,
                                    P_ORD_QTY 			 IN NUMBER,
                                    P_MO_AVG_PRDN_QTY 	 IN NUMBER,
                                    P_PPRR_EENO 		 IN VARCHAR2,
                                    P_UPDR_EENO 		 IN VARCHAR2)
  IS
  BEGIN
    
  	   INSERT INTO TB_PRNT_FP_INFO 
	   (QLTY_VEHL_CD,
        MDL_MDY_CD,
		LANG_CD,
		RQ_QTY,
		DLVG_PARR_YMD,
		DL_EXPD_DLVG_PL_CD,
		N_PRNT_PBCN_NO,
		OLD_PRNT_PBCN_NO,
		I_WAY_SBC,
		BKBD_WAY_SBC,
		PG_MGN_SBC,
		DEPCQ1_SBC,
		DEIPQ1_SBC,
		PRNT_CVR_SBC,
		PRNT_INSD_PG_SBC,
		C_PRNT_CVR_SBC,
		C_PRNT_INSD_PG_SBC,
		CVR_CEG_SBC,
		PG_NL,
		CVR_NL,
		EXPD_NL,
		GRN_DOC_NL,
		POST_CRD_NL,
		EOFU1_NL,
		NR_FLM_MKO_NL,
		DGTL_PRNT_NL,
		OORD_EDIT_PG_NL,
		DEPC1_QTY,
		REM,
		IV_QTY,
		ORD_QTY,
		MO_AVG_PRDN_QTY,
		PPRR_EENO,
		FRAM_DTM,
		UPDR_EENO,
		MDFY_DTM
	   )
	   VALUES(P_QLTY_VEHL_CD,
	   		  P_MDL_MDY_CD,
			  P_LANG_CD,
			  P_RQ_QTY,
			  P_DLVG_PARR_YMD,
			  P_DL_EXPD_DLVG_PL_CD,
			  P_N_PRNT_PBCN_NO,
			  P_OLD_PRNT_PBCN_NO,
			  P_I_WAY_SBC,
			  P_BKBD_WAY_SBC,
			  P_PG_MGN_SBC,
			  P_DEPCQ1_SBC,
			  P_DEIPQ1_SBC,
			  P_PRNT_CVR_SBC,
			  P_PRNT_INSD_PG_SBC,
			  P_C_PRNT_CVR_SBC,
			  P_C_PRNT_INSD_PG_SBC,
			  P_CVR_CEG_SBC,
			  P_PG_NL,
			  P_CVR_NL,
			  P_EXPD_NL,
			  P_GRN_DOC_NL,
			  P_POST_CRD_NL,
			  P_EOFU1_NL,
			  P_NR_FLM_MKO_NL,
			  P_DGTL_PRNT_NL,
			  P_OORD_EDIT_PG_NL,
			  P_DEPC1_QTY,
			  P_REM,
			  P_IV_QTY,
			  P_ORD_QTY,
			  P_MO_AVG_PRDN_QTY,
			  P_PPRR_EENO,
			  SYSDATE,
			  P_UPDR_EENO,
			  SYSDATE
			 );
			 
  END SP_INSERT_ARRAY_DETAIL;                                    

  -- 인쇄세부내역 삭제 
  PROCEDURE SP_DELETE_ARRAY_DETAIL(P_N_PRNT_PBCN_NO IN VARCHAR2)
    IS
  BEGIN  
    
	DELETE FROM TB_PRNT_FP_INFO
    WHERE N_PRNT_PBCN_NO = P_N_PRNT_PBCN_NO;
	
  END SP_DELETE_ARRAY_DETAIL;    
  
   -- 인쇄세부내역 조회
   PROCEDURE SP_GET_ARRAY_DETAIL(P_N_PRNT_PBCN_NO IN VARCHAR2,
                                 P_QLTY_VEHL_CD   IN VARCHAR2,
                                 P_MDL_MDY_CD 	  IN VARCHAR2,
                                 P_LANG_CD 		  IN VARCHAR2,
                                 RS OUT REFCUR)
   IS
   BEGIN
   		
    	OPEN RS FOR
      		 SELECT A.N_PRNT_PBCN_NO,
  	  		 		A.QLTY_VEHL_CD,
  			 		A.MDL_MDY_CD,
  			 		A.LANG_CD,
  			 		A.DLVG_PARR_YMD,
  			 		A.DL_EXPD_DLVG_PL_CD,
  			 		A.OLD_PRNT_PBCN_NO,  
  			 		A.I_WAY_SBC,         
  			 		A.BKBD_WAY_SBC,      
  			 		A.PG_MGN_SBC,        
  			 		A.DEPCQ1_SBC,        
  			 		A.DEIPQ1_SBC,        
  			 		A.PRNT_CVR_SBC,      
  			 		A.PRNT_INSD_PG_SBC,  
  			 		A.C_PRNT_CVR_SBC,    
  			 		A.C_PRNT_INSD_PG_SBC,
  			 		A.CVR_CEG_SBC,       
  			 		A.PG_NL,             
  			 		A.CVR_NL,            
  			 		A.EXPD_NL,           
  			 		A.GRN_DOC_NL,        
  			 		A.POST_CRD_NL,       
  			 		A.EOFU1_NL,          
  			 		A.NR_FLM_MKO_NL,     
  			 		A.DGTL_PRNT_NL,      
  			 		A.OORD_EDIT_PG_NL,   
  			 		A.DEPC1_QTY,         
  			 		A.REM,               
  			 		A.IV_QTY,            
  			 		A.ORD_QTY,           
  			 		A.MO_AVG_PRDN_QTY,   
  			 		A.RQ_QTY, B.DL_EXPD_PRVS_NM
            FROM TB_PRNT_FP_INFO A,
        		 TB_CODE_MGMT B
      		WHERE A.N_PRNT_PBCN_NO = P_N_PRNT_PBCN_NO
      		AND A.QLTY_VEHL_CD = P_QLTY_VEHL_CD
      		AND A.MDL_MDY_CD = P_MDL_MDY_CD
      		AND A.LANG_CD = P_LANG_CD
      		AND B.DL_EXPD_G_CD = '0005'
      		AND B.DL_EXPD_PRVS_CD = A.DL_EXPD_DLVG_PL_CD;
      
   END SP_GET_ARRAY_DETAIL;
   
   --인쇄세부내역 초기 작성시인쇄시 재고, 당월오더수량, 3개월 평균 생산량 조회 								 
   PROCEDURE SP_GET_IV_ORD_QTY(P_QLTY_VEHL_CD IN VARCHAR2,
                               P_MDL_MDY_CD   IN VARCHAR2,
                               P_LANG_CD      IN VARCHAR2,
                               RS OUT REFCUR)
   IS
   	 
	 V_IV_QTY1         NUMBER;
	 V_IV_QTY2		   NUMBER;
	 V_ORD_QTY         NUMBER;
	 V_MO_AVG_PRDN_QTY NUMBER;
     V_PDI_CD          VARCHAR2(8);
		 
	 V_CURR_YMD        VARCHAR2(8);
		 
   BEGIN
     
	 	V_CURR_YMD := TO_CHAR(SYSDATE, 'YYYYMMDD');
		
		--현재의 연식을 취급설명서 연식으로 간주하여 계산해 주도록 한다. 	
		SELECT NVL(SUM(IV_QTY), 0)
		INTO V_IV_QTY1
		FROM TB_SEWHA_IV_INFO
		WHERE QLTY_VEHL_CD = P_QLTY_VEHL_CD
		AND DL_EXPD_MDL_MDY_CD = P_MDL_MDY_CD
        AND LANG_CD = P_LANG_CD
		AND CLS_YMD = V_CURR_YMD;			
		
		--현재의 연식을 취급설명서 연식으로 간주하여 계산해 주도록 한다. 
		SELECT NVL(SUM(IV_QTY), 0)
		INTO V_IV_QTY2
		FROM TB_PDI_IV_INFO
		WHERE QLTY_VEHL_CD = P_QLTY_VEHL_CD
		AND DL_EXPD_MDL_MDY_CD = P_MDL_MDY_CD
        AND LANG_CD = P_LANG_CD
		AND CLS_YMD = V_CURR_YMD;
		
		--현재의 연식을 취급설명서 연식으로 간주하여 계산해 주도록 한다. 
		--그리고 순수하게 현재 취급서명서 연식의 투입및 오더 수량을 계산해 주도록 한다. 
		SELECT NVL(SUM(TMM_ORD_QTY), 0),
		       NVL(SUM(MTH3_MO_AVG_TRWI_QTY), 0)
		INTO V_ORD_QTY,
		     V_MO_AVG_PRDN_QTY
        FROM TB_APS_PROD_SUM_INFO
		WHERE QLTY_VEHL_CD = P_QLTY_VEHL_CD
		AND MDL_MDY_CD = P_MDL_MDY_CD
		AND LANG_CD = P_LANG_CD
		AND APL_YMD = V_CURR_YMD;
		
        SELECT DL_EXPD_PDI_CD
        INTO V_PDI_CD
        FROM TB_VEHL_MGMT
        WHERE QLTY_VEHL_CD = P_QLTY_VEHL_CD
        AND MDL_MDY_CD = P_MDL_MDY_CD;
                
		OPEN RS FOR
		SELECT V_IV_QTY1 + V_IV_QTY2 AS IV_QTY,
			   V_ORD_QTY AS ORD_QTY,
			   V_MO_AVG_PRDN_QTY AS MO_AVG_PRDN_QTY,
               V_PDI_CD AS PDI_CD
	    FROM DUAL;
			 
   END SP_GET_IV_ORD_QTY;
   
   /** PG_COMMON 으로 이동 
   
   FUNCTION FU_GET_SORT_PBCN(P_N_PRNT_PBCN_NO IN VARCHAR2) RETURN VARCHAR2
   IS
   	 
	 V_N_PRNT_PBCN_NO VARCHAR2(100);
	 
	 V_YEAR  CHAR(1);
	 V_MONTH CHAR(1);
	 V_EXTEN CHAR(1);
	 
   BEGIN
   		
		IF LENGTH(P_N_PRNT_PBCN_NO) >= 10 THEN
		   
		   V_N_PRNT_PBCN_NO := SUBSTR(P_N_PRNT_PBCN_NO, 1, 7);
		   
		   V_YEAR  := SUBSTR(P_N_PRNT_PBCN_NO, 8, 1);
		   V_MONTH := SUBSTR(P_N_PRNT_PBCN_NO, 9, 1);
		   V_EXTEN := SUBSTR(P_N_PRNT_PBCN_NO, 10, 1);
		   
		   IF V_YEAR = '1' THEN
		   	  V_N_PRNT_PBCN_NO := V_N_PRNT_PBCN_NO || '11';
		   ELSIF V_YEAR = '2' THEN
			  V_N_PRNT_PBCN_NO := V_N_PRNT_PBCN_NO || '12';
		   ELSIF V_YEAR = '3' THEN
			  V_N_PRNT_PBCN_NO := V_N_PRNT_PBCN_NO || '13';
		   ELSIF V_YEAR = '4' THEN
			  V_N_PRNT_PBCN_NO := V_N_PRNT_PBCN_NO || '14';
		   ELSIF V_YEAR = '5' THEN
			  V_N_PRNT_PBCN_NO := V_N_PRNT_PBCN_NO || '15';
		   ELSIF V_YEAR = '6' THEN
			  V_N_PRNT_PBCN_NO := V_N_PRNT_PBCN_NO || '16';
		   ELSIF V_YEAR = '7' THEN
			  V_N_PRNT_PBCN_NO := V_N_PRNT_PBCN_NO || '17';
		   ELSIF V_YEAR = '8' THEN
			  V_N_PRNT_PBCN_NO := V_N_PRNT_PBCN_NO || '08';
		   ELSIF V_YEAR = '9' THEN
			  V_N_PRNT_PBCN_NO := V_N_PRNT_PBCN_NO || '09';
		   ELSIF V_YEAR = '0' THEN
			  V_N_PRNT_PBCN_NO := V_N_PRNT_PBCN_NO || '10';
		   ELSE
		      V_N_PRNT_PBCN_NO := V_N_PRNT_PBCN_NO || V_YEAR;
		   END IF;
		   
		   IF V_MONTH = '1' THEN
		   	  V_N_PRNT_PBCN_NO := V_N_PRNT_PBCN_NO || '01';
		   ELSIF V_MONTH = '2' THEN
			  V_N_PRNT_PBCN_NO := V_N_PRNT_PBCN_NO || '02';
		   ELSIF V_MONTH = '3' THEN
			  V_N_PRNT_PBCN_NO := V_N_PRNT_PBCN_NO || '03';
		   ELSIF V_MONTH = '4' THEN
			  V_N_PRNT_PBCN_NO := V_N_PRNT_PBCN_NO || '04';
		   ELSIF V_MONTH = '5' THEN
			  V_N_PRNT_PBCN_NO := V_N_PRNT_PBCN_NO || '05';
		   ELSIF V_MONTH = '6' THEN
			  V_N_PRNT_PBCN_NO := V_N_PRNT_PBCN_NO || '06';
		   ELSIF V_MONTH = '7' THEN
			  V_N_PRNT_PBCN_NO := V_N_PRNT_PBCN_NO || '07';
		   ELSIF V_MONTH = '8' THEN
			  V_N_PRNT_PBCN_NO := V_N_PRNT_PBCN_NO || '08';
		   ELSIF V_MONTH = '9' THEN
			  V_N_PRNT_PBCN_NO := V_N_PRNT_PBCN_NO || '09';
		   ELSIF V_MONTH = 'O' THEN
			  V_N_PRNT_PBCN_NO := V_N_PRNT_PBCN_NO || '10';
		   ELSIF V_MONTH = 'N' THEN
		      V_N_PRNT_PBCN_NO := V_N_PRNT_PBCN_NO || '11';
		   ELSIF V_MONTH = 'D' THEN
		   	  V_N_PRNT_PBCN_NO := V_N_PRNT_PBCN_NO || '12';
		   ELSE
		      V_N_PRNT_PBCN_NO := V_N_PRNT_PBCN_NO || V_MONTH;
		   END IF;
		   
		   IF V_EXTEN = 'A' THEN
			  V_N_PRNT_PBCN_NO := V_N_PRNT_PBCN_NO || 'Z';
		   ELSE
			  V_N_PRNT_PBCN_NO := V_N_PRNT_PBCN_NO || V_EXTEN;
		   END IF;
		   
		ELSE
			
			V_N_PRNT_PBCN_NO := P_N_PRNT_PBCN_NO;
			
		END IF;
		
		RETURN V_N_PRNT_PBCN_NO;
		
   END FU_GET_SORT_PBCN;
   **/
   
END PG_PRNT_PAGE_MGMT;