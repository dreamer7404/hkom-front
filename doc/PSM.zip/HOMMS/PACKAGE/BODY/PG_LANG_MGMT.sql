CREATE OR REPLACE PACKAGE BODY PG_LANG_MGMT AS
   
   /** 
   -- 언어코드 전체검색 
   PROCEDURE SP_LC_MGMT_LIST(P_DL_EXPD_PRVS_CD IN VARCHAR2,
                             P_DL_EXPD_PDI_CD  IN VARCHAR2,
                             P_QLTY_VEHL_CD    IN VARCHAR2,
                             P_MDL_MDY_CD      IN VARCHAR2,
                             P_DL_EXPD_REGN_CD IN VARCHAR2, 
                             P_LANG_CD         IN VARCHAR2,                           
                             RS OUT REFCUR)
   AS
   BEGIN
    	
		OPEN RS FOR      
           SELECT A.DATA_SN AS DATA_SN,
             	  A.DL_EXPD_REGN_CD AS DL_EXPD_REGN_CD,
             	  A.LANG_CD AS LANG_CD,
             	  A.LANG_CD_NM AS LANG_CD_NM,
             	  A.USE_YN AS USE_YN,
             	  A.PPRR_EENO AS PPRR_EENO,
             	  A.FRAM_DTM AS FRAM_DTM,
             	  B.QLTY_VEHL_CD AS QLTY_VEHL_CD,
             	  B.QLTY_VEHL_NM AS QLTY_VEHL_NM,
             	  B.MDL_MDY_CD AS MDL_MDY_CD,
             	  C.DL_EXPD_PRVS_NM AS DL_EXPD_CO_NM,
             	  D.DL_EXPD_PRVS_NM AS DL_EXPD_REGN_NM
           FROM TB_LANG_MGMT A,
             	TB_VEHL_MGMT B,
             	TB_CODE_MGMT C,
             	TB_CODE_MGMT D
           WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
           AND A.MDL_MDY_CD = B.MDL_MDY_CD
           AND D.DL_EXPD_G_CD = '0008'
           AND A.DL_EXPD_REGN_CD = DECODE(P_DL_EXPD_REGN_CD, 'ALL', A.DL_EXPD_REGN_CD, P_DL_EXPD_REGN_CD)
           AND A.DL_EXPD_REGN_CD = D.DL_EXPD_PRVS_CD
           AND C.DL_EXPD_G_CD = '0003'
           AND B.DL_EXPD_CO_CD = C.DL_EXPD_PRVS_CD
           AND B.DL_EXPD_CO_CD = DECODE(P_DL_EXPD_PRVS_CD, 'ALL', B.DL_EXPD_CO_CD, P_DL_EXPD_PRVS_CD)
           AND B.DL_EXPD_PDI_CD = DECODE(P_DL_EXPD_PDI_CD, 'ALL', B.DL_EXPD_PDI_CD, P_DL_EXPD_PDI_CD)
           AND B.QLTY_VEHL_CD = DECODE(P_QLTY_VEHL_CD, 'ALL', B.QLTY_VEHL_CD, P_QLTY_VEHL_CD)
           AND B.MDL_MDY_CD = DECODE(P_MDL_MDY_CD, 'ALL', B.MDL_MDY_CD, P_MDL_MDY_CD)
           AND A.LANG_CD = DECODE(P_LANG_CD, 'ALL', A.LANG_CD, P_LANG_CD)
           AND A.NAPC_YN = 'N'         
           ORDER BY B.QLTY_VEHL_CD, B.MDL_MDY_CD, A.LANG_CD_NM;
			          
   END SP_LC_MGMT_LIST;  
   **/ 
   
   -- 언어코드 전체검색2  
   PROCEDURE SP_LC_MGMT_LIST2(P_MENU_ID 	     IN VARCHAR2,
			                  P_USER_EENO 	     IN VARCHAR2,
   			                  P_DL_EXPD_PRVS_CD  IN VARCHAR2,
                              P_DL_EXPD_PDI_CD   IN VARCHAR2,
                              P_QLTY_VEHL_CD     IN VARCHAR2,
                              P_MDL_MDY_CD       IN VARCHAR2,
                              P_DL_EXPD_REGN_CD  IN VARCHAR2, 
                              P_LANG_CD          IN VARCHAR2,                           
                              RS OUT REFCUR)
   IS
   	 
	 V_FROM_MDL_MDY VARCHAR(2);
	 V_TO_MDL_MDY   VARCHAR(2);
	 
   BEGIN
   		
		PG_COMMON.SP_GET_VALID_MDL_MDY4(TO_CHAR(SYSDATE, 'YYYYMMDD'), '', V_FROM_MDL_MDY, V_TO_MDL_MDY);
		
		OPEN RS FOR
			 SELECT A.DATA_SN AS DATA_SN,
             		A.DL_EXPD_REGN_CD AS DL_EXPD_REGN_CD,
             		A.LANG_CD AS LANG_CD,
             		A.LANG_CD_NM AS LANG_CD_NM,
             		A.USE_YN AS USE_YN,
             		A.PPRR_EENO AS PPRR_EENO,
             		A.FRAM_DTM AS FRAM_DTM,
             		B.QLTY_VEHL_CD AS QLTY_VEHL_CD,
             		B.QLTY_VEHL_NM AS QLTY_VEHL_NM,
             		B.MDL_MDY_CD AS MDL_MDY_CD,
             		C.DL_EXPD_PRVS_NM AS DL_EXPD_CO_NM,
             		D.DL_EXPD_PRVS_NM AS DL_EXPD_REGN_NM,
					A.SORT_SN, 
					A.A_CODE
             FROM TB_LANG_MGMT A,
             	  TB_VEHL_MGMT B,
             	  TB_CODE_MGMT C,
             	  TB_CODE_MGMT D,
				  (SELECT QLTY_VEHL_CD
                   FROM TB_AUTH_VEHL_MGMT
                   WHERE MENU_ID = PG_COMMON.FU_RPAD(P_MENU_ID, 10)
                   AND USER_EENO = PG_COMMON.FU_RPAD(P_USER_EENO, 7)
                   GROUP BY QLTY_VEHL_CD
                  ) E
             WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
             AND A.MDL_MDY_CD = B.MDL_MDY_CD
		     AND A.QLTY_VEHL_CD = E.QLTY_VEHL_CD
		     AND A.MDL_MDY_CD BETWEEN V_FROM_MDL_MDY AND V_TO_MDL_MDY
             AND D.DL_EXPD_G_CD = '0008'
             AND A.DL_EXPD_REGN_CD = DECODE(P_DL_EXPD_REGN_CD, 'ALL', A.DL_EXPD_REGN_CD, P_DL_EXPD_REGN_CD)
             AND A.DL_EXPD_REGN_CD = D.DL_EXPD_PRVS_CD
             AND C.DL_EXPD_G_CD = '0003'
             AND B.DL_EXPD_CO_CD = C.DL_EXPD_PRVS_CD
             AND B.DL_EXPD_CO_CD = DECODE(P_DL_EXPD_PRVS_CD, 'ALL', B.DL_EXPD_CO_CD, P_DL_EXPD_PRVS_CD)
             AND B.DL_EXPD_PDI_CD = DECODE(P_DL_EXPD_PDI_CD, 'ALL', B.DL_EXPD_PDI_CD, P_DL_EXPD_PDI_CD)
             AND B.QLTY_VEHL_CD = DECODE(P_QLTY_VEHL_CD, 'ALL', B.QLTY_VEHL_CD, P_QLTY_VEHL_CD)
             AND B.MDL_MDY_CD = DECODE(P_MDL_MDY_CD, 'ALL', B.MDL_MDY_CD, P_MDL_MDY_CD)
             AND A.LANG_CD = DECODE(P_LANG_CD, 'ALL', A.LANG_CD, P_LANG_CD)
             --AND A.NAPC_YN = 'N'         
             ORDER BY A.USE_YN DESC, B.QLTY_VEHL_CD, A.SORT_SN, B.MDL_MDY_CD;
			 
   END SP_LC_MGMT_LIST2;
   					  
   -- 전체 차종코드, 회사코드 조회
   PROCEDURE SP_VEHL_LIST(RS OUT REFCUR)
   AS
   	 
	 V_FROM_MDL_MDY VARCHAR(2);
	 V_TO_MDL_MDY   VARCHAR(2);
	 
   BEGIN
       	
        PG_COMMON.SP_GET_VALID_MDL_MDY4(TO_CHAR(SYSDATE, 'YYYYMMDD'), '', V_FROM_MDL_MDY, V_TO_MDL_MDY);
        
        OPEN RS FOR
         	 SELECT QLTY_VEHL_CD || '-' || MDL_MDY_CD AS QLTY_VEHL_CD,
			 		'(' || QLTY_VEHL_CD || '-' || MDL_MDY_CD || ')' || QLTY_VEHL_NM AS QLTY_VEHL_NM	
         	 FROM TB_VEHL_MGMT
         	 WHERE USE_YN = 'Y'
         	 AND MDL_MDY_CD BETWEEN V_FROM_MDL_MDY AND V_TO_MDL_MDY
		 	 ORDER BY QLTY_VEHL_CD, MDL_MDY_CD;
		
   END SP_VEHL_LIST;
   
   -- 언어코드 입력 중복체크
   PROCEDURE SP_CHECK(P_QLTY_VEHL_CD    IN VARCHAR2,
                      P_MDL_MDY_CD      IN VARCHAR2,
                      P_LANG_CD         IN VARCHAR2,
                      P_DL_EXPD_REGN_CD IN VARCHAR2,
                      RS OUT REFCUR)
     IS
   BEGIN
    	
		OPEN RS FOR
      		 SELECT QLTY_VEHL_CD,
        	 		MDL_MDY_CD,
        			LANG_CD,
        			DL_EXPD_REGN_CD
      		 FROM TB_LANG_MGMT
      		 WHERE QLTY_VEHL_CD = P_QLTY_VEHL_CD
      		 AND MDL_MDY_CD = P_MDL_MDY_CD
      		 AND LANG_CD = P_LANG_CD
      		 AND DL_EXPD_REGN_CD = P_DL_EXPD_REGN_CD;
		
   END SP_CHECK;    

   -- 언어코드 입력
   PROCEDURE SP_INSERT(VEHL_CD      IN TB_LANG_MGMT.QLTY_VEHL_CD%TYPE,
                       MDY_CD       IN TB_LANG_MGMT.MDL_MDY_CD%TYPE,
                       L_CD         IN TB_LANG_MGMT.LANG_CD%TYPE,
                       EXPD_REGN_CD IN TB_LANG_MGMT.DL_EXPD_REGN_CD%TYPE,
                       L_CD_NM      IN TB_LANG_MGMT.LANG_CD_NM%TYPE,
                       YN           IN TB_LANG_MGMT.USE_YN%TYPE,
                       N_YN         IN TB_LANG_MGMT.NAPC_YN%TYPE,
					   P_SORT       IN TB_LANG_MGMT.SORT_SN%TYPE,
					   P_ACODE      IN TB_LANG_MGMT.A_CODE%TYPE,
					   P_N1_INS_YN  IN TB_LANG_MGMT.N1_INS_YN%TYPE,
					   P_VEHL_LIST  IN VARCHAR2,
					   P_USER_EENO  IN VARCHAR2)
   AS
   	 
	 V_DATA_SN NUMBER;
	 
   BEGIN
     
		--연식에 따라 명칭이 다른 경우가 있으므로.... 우선은 주석처리 한다. 
		 
	  	--언어코드에 해당 하는 모든 언어명칭을 변경하여 준다. 
		--UPDATE TB_LANG_MGMT
		--SET LANG_CD_NM = L_CD_NM 
		--WHERE LANG_CD = L_CD;
		
		SELECT NVL(MAX(DATA_SN), 0) + 1
		INTO V_DATA_SN
		FROM TB_LANG_MGMT;
		
	    INSERT INTO TB_LANG_MGMT 
		(DATA_SN,
		 QLTY_VEHL_CD,
		 MDL_MDY_CD,
		 LANG_CD,
		 DL_EXPD_REGN_CD,
		 LANG_CD_NM,
		 USE_YN,
		 NAPC_YN,
		 PPRR_EENO,
		 FRAM_DTM,
		 UPDR_EENO,
		 MDFY_DTM,
		 SORT_SN,
		 A_CODE,
		 N1_INS_YN
		)
	    VALUES
	    (V_DATA_SN,
	     VEHL_CD,
		 MDY_CD,
		 L_CD,
		 EXPD_REGN_CD,
		 L_CD_NM,
		 YN,
		 N_YN,
		 P_USER_EENO,
		 SYSDATE,
		 P_USER_EENO,
		 SYSDATE,
		 P_SORT,
		 P_ACODE,
		 P_N1_INS_YN
		);
		
		SP_N1_INS_YN_UPDATE(V_DATA_SN,
							P_VEHL_LIST, 
							P_USER_EENO);
							
   END SP_INSERT;      

   -- 언어코드 사용여부관리(삭제)
   PROCEDURE SP_DELETE(D_SN        IN TB_LANG_MGMT.DATA_SN%TYPE,
   			 		   P_USER_EENO IN VARCHAR2)
   AS
   BEGIN
    
		UPDATE TB_LANG_MGMT
    	SET USE_YN = 'N',
			UPDR_EENO = P_USER_EENO,
			MDFY_DTM = SYSDATE
    	WHERE DATA_SN = D_SN;
   
   END SP_DELETE;

   -- 언어코드 수정할 내용 검색(데이터일련번호 참조) 
   PROCEDURE SP_UPDATE_VIEW(D_SN IN TB_LANG_MGMT.DATA_SN%TYPE,
                            RS   OUT REFCUR)
   AS
   BEGIN
    
		OPEN RS FOR
      		 SELECT A.DATA_SN AS DATA_SN,
        	 		A.LANG_CD AS LANG_CD,
        			A.DL_EXPD_REGN_CD AS DL_EXPD_REGN_CD,
        			A.LANG_CD_NM AS LANG_CD_NM,
        			A.USE_YN AS USE_YN,
					B.QLTY_VEHL_CD || '-' || B.MDL_MDY_CD AS QLTY_VEHL_CD,
			 		'(' || B.QLTY_VEHL_CD || '-' || B.MDL_MDY_CD || ')' || B.QLTY_VEHL_NM AS QLTY_VEHL_NM,
					A.SORT_SN, 
					A.A_CODE,
					NVL(A.N1_INS_YN, 'N') AS N1_INS_YN,
					FU_GET_PDI_COM_VEHL_LIST(A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD, B.DL_EXPD_PDI_CD) AS VEHL_LIST
      		 FROM TB_LANG_MGMT A,
        	 	  TB_VEHL_MGMT B
      		 WHERE A.DATA_SN = D_SN
      		 AND A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
      		 AND A.MDL_MDY_CD = B.MDL_MDY_CD;
		
   END SP_UPDATE_VIEW;
   
   FUNCTION FU_GET_PDI_COM_VEHL_LIST(P_QLTY_VEHL_CD   IN VARCHAR2,
	 	  						     P_MDL_MDY_CD     IN VARCHAR2,
		  						     P_LANG_CD        IN VARCHAR2,
		  						     P_DL_EXPD_PDI_CD IN VARCHAR2
									) RETURN VARCHAR2
   IS
   
   	 V_VEHL_LIST VARCHAR2(8000);
		
	 CURSOR COM_VEHL_LIST IS SELECT QLTY_VEHL_CD
	   	                     FROM TB_PDI_COM_VEHL_MGMT
							 WHERE DIVS_QLTY_VEHL_CD  = P_QLTY_VEHL_CD
							 AND MDL_MDY_CD = P_MDL_MDY_CD
							 AND LANG_CD = P_LANG_CD
							 AND DL_EXPD_PDI_CD = P_DL_EXPD_PDI_CD
							 ORDER BY QLTY_VEHL_CD;
								  
   BEGIN
   		
		V_VEHL_LIST := '';
		
		FOR VEHL_LIST IN COM_VEHL_LIST LOOP
			
			V_VEHL_LIST := V_VEHL_LIST || VEHL_LIST.QLTY_VEHL_CD || ',';
			
		END LOOP;
		
		IF LENGTH(V_VEHL_LIST) > 0 THEN
		   
		   V_VEHL_LIST := SUBSTR(V_VEHL_LIST, 1, LENGTH(V_VEHL_LIST) - 1);
		   
		END IF;

		RETURN V_VEHL_LIST;
		
   END FU_GET_PDI_COM_VEHL_LIST;
   
   --현재의 사용자가 수정가능한 차종의 리스트를 조회(팝업화면용) 
   PROCEDURE SP_GET_VEHL_LIST(P_DATA_SN IN TB_LANG_MGMT.DATA_SN%TYPE,
    		 				  RS        OUT REFCUR)
   IS
   	 
	 V_QLTY_VEHL_CD TB_LANG_MGMT.QLTY_VEHL_CD%TYPE;
	 V_MDL_MDY_CD   TB_LANG_MGMT.MDL_MDY_CD%TYPE;
	 V_LANG_CD		TB_LANG_MGMT.LANG_CD%TYPE;
		
   BEGIN
	  	   
       SELECT QLTY_VEHL_CD,
		   	  MDL_MDY_CD,
			  LANG_CD
	   INTO V_QLTY_VEHL_CD,
		    V_MDL_MDY_CD,
			V_LANG_CD
	   FROM TB_LANG_MGMT
	   WHERE DATA_SN = P_DATA_SN;
		   
	   SP_GET_VEHL_LIST2(V_QLTY_VEHL_CD,
		        		 V_MDL_MDY_CD,
						 V_LANG_CD,
						 RS);
	
   END SP_GET_VEHL_LIST;
   
   PROCEDURE SP_GET_VEHL_LIST2(P_QLTY_VEHL_CD IN VARCHAR2,
	 	  					   P_MDL_MDY_CD   IN VARCHAR2,
							   P_LANG_CD	  IN VARCHAR2,
							   RS             OUT REFCUR)
   IS
   	 
	 V_EXPD_CO_CD      TB_VEHL_MGMT.DL_EXPD_CO_CD%TYPE;
	 V_EXPD_PAC_SCN_CD TB_VEHL_MGMT.DL_EXPD_PAC_SCN_CD%TYPE;
   	 V_EXPD_PDI_CD     TB_VEHL_MGMT.DL_EXPD_PDI_CD%TYPE;
	 
   BEGIN
   		 
		 SELECT DL_EXPD_CO_CD,
		 		DL_EXPD_PAC_SCN_CD,
		 		DL_EXPD_PDI_CD
		 INTO V_EXPD_CO_CD,
		 	  V_EXPD_PAC_SCN_CD,
		      V_EXPD_PDI_CD
		 FROM TB_VEHL_MGMT
		 WHERE QLTY_VEHL_CD = P_QLTY_VEHL_CD
		 AND MDL_MDY_CD = P_MDL_MDY_CD;
		 
		 OPEN RS FOR
		   	SELECT A.QLTY_VEHL_CD, 
				   '(' || A.QLTY_VEHL_CD || ')' || MAX(A.QLTY_VEHL_NM) AS QLTY_VEHL_NM
			FROM TB_VEHL_MGMT A,
				 TB_LANG_MGMT B
			WHERE A.MDL_MDY_CD = P_MDL_MDY_CD
			AND A.USE_YN = 'Y'
			AND B.USE_YN = 'Y'
			AND A.QLTY_VEHL_CD <> P_QLTY_VEHL_CD
			AND A.DL_EXPD_CO_CD = V_EXPD_CO_CD
			AND A.DL_EXPD_PAC_SCN_CD = V_EXPD_PAC_SCN_CD
			AND A.DL_EXPD_PDI_CD = V_EXPD_PDI_CD
			AND B.LANG_CD = P_LANG_CD
			AND A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
			AND A.MDL_MDY_CD = B.MDL_MDY_CD
			GROUP BY A.QLTY_VEHL_CD;

   END SP_GET_VEHL_LIST2;							 
	  
   -- 언어코드 수정 
   PROCEDURE SP_UPDATE(D_SN         IN TB_LANG_MGMT.DATA_SN%TYPE,
                       L_CD         IN TB_LANG_MGMT.LANG_CD%TYPE,
                       L_CD_NM      IN TB_LANG_MGMT.LANG_CD_NM%TYPE,
                       EXPD_REGN_CD IN TB_LANG_MGMT.DL_EXPD_REGN_CD%TYPE,
                       YN           IN TB_LANG_MGMT.USE_YN%TYPE,
					   P_SORT       IN TB_LANG_MGMT.SORT_SN%TYPE,
					   P_ACODE      IN TB_LANG_MGMT.A_CODE%TYPE,
					   P_N1_INS_YN  IN TB_LANG_MGMT.N1_INS_YN%TYPE,
					   P_VEHL_LIST  IN VARCHAR2,
					   P_USER_EENO  IN VARCHAR2)
   AS
   	 
	 V_VEHL_CD VARCHAR2(4);
	 V_MDY_CD  VARCHAR2(2);
	 V_REGN_CD VARCHAR2(4);
	 V_LANG_CD VARCHAR2(3);
	 
   BEGIN
    
		SELECT QLTY_VEHL_CD, 
			   MDL_MDY_CD, 
			   LANG_CD, 
			   DL_EXPD_REGN_CD
		INTO V_VEHL_CD, 
			 V_MDY_CD, 
			 V_LANG_CD, 
			 V_REGN_CD
	    FROM TB_LANG_MGMT
		WHERE DATA_SN = D_SN;
    
		--수정하기에 앞서 지역코드가 바뀌었으면 국가-차종정보의 지역코드역시 수정하여 준다. 
		--(반드시 수정 이전에 처리해 주어야 함) 
		IF V_REGN_CD <> EXPD_REGN_CD THEN
	   
	   	   SP_NATL_VEHL_REGN_SAVE(V_VEHL_CD, V_MDY_CD, L_CD, V_REGN_CD, EXPD_REGN_CD);
	   
	    END IF;
    
		--연식에 따라 명칭이 다른 경우가 있으므로.... 우선은 주석처리 한다. 
	
		--언어코드에 해당 하는 모든 언어명칭을 변경하여 준다. 
		--UPDATE TB_LANG_MGMT
		--SET LANG_CD_NM = L_CD_NM 
		--WHERE LANG_CD = V_LANG_CD;
	
    	UPDATE TB_LANG_MGMT
    	SET -- 2011.08.08.김동근 언어코드는 업데이트 대상에서 제외한다. 언어코드가 변경되면 신규 추가해 주어야 한다.
            --TB_LANG_MGMT.LANG_CD = L_CD,
      		TB_LANG_MGMT.LANG_CD_NM = L_CD_NM,
      		TB_LANG_MGMT.DL_EXPD_REGN_CD = EXPD_REGN_CD,
      		TB_LANG_MGMT.USE_YN = YN,
	  		TB_LANG_MGMT.SORT_SN = P_SORT,
	  		TB_LANG_MGMT.A_CODE = P_ACODE,
			TB_LANG_MGMT.N1_INS_YN = P_N1_INS_YN,
			UPDR_EENO = P_USER_EENO,
			MDFY_DTM = SYSDATE
        WHERE TB_LANG_MGMT.DATA_SN = D_SN;
	  	
		SP_N1_INS_YN_UPDATE(D_SN,
						    P_VEHL_LIST, 
							P_USER_EENO);
        
        --직전연식관계(언어별) 정보 세팅                             
        SP_LANG_MDY_MGMT_SAVE(V_VEHL_CD, 
                              V_LANG_CD,
			                  V_MDY_CD, 
			                  V_REGN_CD,
                              EXPD_REGN_CD,
                              P_USER_EENO);
                              
   END SP_UPDATE;   
   
   PROCEDURE SP_N1_INS_YN_UPDATE(P_DATA_SN   IN NUMBER,
								 P_VEHL_LIST IN VARCHAR2,
  							     P_USER_EENO IN VARCHAR2)
   IS
   
   	 V_VEHL_LIST PG_COMMON.LIST_TYPE;
	 V_VEHL_CNT  BINARY_INTEGER;
	 
	 V_QLTY_VEHL_CD   TB_VEHL_MGMT.QLTY_VEHL_CD%TYPE;
	 V_MDL_MDY_CD     TB_VEHL_MGMT.MDL_MDY_CD%TYPE;
	 V_DL_EXPD_CO_CD  TB_VEHL_MGMT.DL_EXPD_CO_CD%TYPE;
	 V_DL_PAC_SCN_CD  TB_VEHL_MGMT.DL_EXPD_PAC_SCN_CD%TYPE;
	 V_DL_EXPD_PDI_CD TB_VEHL_MGMT.DL_EXPD_PDI_CD%TYPE;
	 V_LANG_CD		  TB_LANG_MGMT.LANG_CD%TYPE;
	 V_N1_INS_YN      TB_LANG_MGMT.N1_INS_YN%TYPE;
	 
   BEGIN
   		
		V_VEHL_LIST := PG_COMMON.FU_SPLIT(P_VEHL_LIST, V_VEHL_CNT);
		
		--수정/신규 입력된 언어정보 조회 
	 	SELECT A.QLTY_VEHL_CD,
	 		   A.MDL_MDY_CD,
			   A.LANG_CD,
			   B.DL_EXPD_CO_CD,
			   B.DL_EXPD_PAC_SCN_CD,
			   B.DL_EXPD_PDI_CD,
			   NVL(A.N1_INS_YN, 'N')
	    INTO V_QLTY_VEHL_CD,
	 	  	 V_MDL_MDY_CD,
		  	 V_LANG_CD,
		  	 V_DL_EXPD_CO_CD,
			 V_DL_PAC_SCN_CD,
		  	 V_DL_EXPD_PDI_CD,
		  	 V_N1_INS_YN
	    FROM TB_LANG_MGMT A,
          	 TB_VEHL_MGMT B
	    WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
	 	AND A.MDL_MDY_CD = B.MDL_MDY_CD
	 	AND A.DATA_SN = P_DATA_SN;
	 	
		IF V_N1_INS_YN = 'Y' THEN
		   
		   --현재 수정/신규 입력된 차종, 연식, 언어가 
		   --다른 PDI 공통 차종에 묶인 경우가 있다면 해당 내역을 삭제해 준다. 
		   DELETE FROM TB_PDI_COM_VEHL_MGMT
		   WHERE QLTY_VEHL_CD = V_QLTY_VEHL_CD
		   AND MDL_MDY_CD = V_MDL_MDY_CD
		   AND LANG_CD = V_LANG_CD
		   AND DL_EXPD_PDI_CD = V_DL_EXPD_PDI_CD;
		   
		   --현재 수정/신규 입력된 차종, 연식, 언어에 
		   --공통 차종으로 묶인 차종들을 삭제해 준다.
		   DELETE FROM TB_PDI_COM_VEHL_MGMT
		   WHERE DIVS_QLTY_VEHL_CD = V_QLTY_VEHL_CD
		   AND MDL_MDY_CD = V_MDL_MDY_CD
		   AND LANG_CD = V_LANG_CD
		   AND DL_EXPD_PDI_CD = V_DL_EXPD_PDI_CD;
		
		   FOR VEHL_NUM IN 1..V_VEHL_CNT LOOP
		 	 
			   IF V_VEHL_LIST(VEHL_NUM) IS NOT NULL THEN
			 	
				  UPDATE TB_LANG_MGMT
				  SET N1_INS_YN = 'N',
				      UPDR_EENO = P_USER_EENO,
					  MDFY_DTM = SYSDATE
				  WHERE QLTY_VEHL_CD = V_VEHL_LIST(VEHL_NUM)
				  AND MDL_MDY_CD = V_MDL_MDY_CD
				  AND LANG_CD = V_LANG_CD;
				  
			   	  --현재 리스트의 차종에 
		 		  --공통 차종으로 묶인 다른 차종들을 삭제해 준다.
		 		  DELETE FROM TB_PDI_COM_VEHL_MGMT
		 		  WHERE DIVS_QLTY_VEHL_CD = V_VEHL_LIST(VEHL_NUM)
		 		  AND MDL_MDY_CD = V_MDL_MDY_CD
		 		  AND LANG_CD = V_LANG_CD
		 		  AND DL_EXPD_PDI_CD = V_DL_EXPD_PDI_CD;
				
				  UPDATE TB_PDI_COM_VEHL_MGMT
				  SET DL_EXPD_PDI_CD = V_DL_EXPD_PDI_CD,
			    	  UPDR_EENO = P_USER_EENO,
					  MDFY_DTM = SYSDATE
			      WHERE QLTY_VEHL_CD = V_VEHL_LIST(VEHL_NUM)
			      AND MDL_MDY_CD = V_MDL_MDY_CD
			      AND LANG_CD = V_LANG_CD
			      AND DIVS_QLTY_VEHL_CD = V_QLTY_VEHL_CD;
			
			      IF SQL%NOTFOUND THEN
			
			       	 INSERT INTO TB_PDI_COM_VEHL_MGMT
			   	   	 (QLTY_VEHL_CD,
			          MDL_MDY_CD,
					  LANG_CD,
					  DIVS_QLTY_VEHL_CD,
					  DL_EXPD_PDI_CD,
					  PPRR_EENO,
					  FRAM_DTM,
					  UPDR_EENO,
					  MDFY_DTM
			         )
			   	   	 VALUES
			   	     (V_VEHL_LIST(VEHL_NUM),
			          V_MDL_MDY_CD,
					  V_LANG_CD,
					  V_QLTY_VEHL_CD,
					  V_DL_EXPD_PDI_CD,
					  P_USER_EENO,
					  SYSDATE,
					  P_USER_EENO,
					  SYSDATE
			         );
			   
			      END IF;
		 
			   END IF;
			 
		   END LOOP;
		
		ELSE
			
		   --현재 수정/신규 입력된 차종, 연식, 언어에 
		   --공통 차종으로 묶인 차종들을 삭제해 준다.
		   DELETE FROM TB_PDI_COM_VEHL_MGMT
		   WHERE DIVS_QLTY_VEHL_CD = V_QLTY_VEHL_CD
		   AND MDL_MDY_CD = V_MDL_MDY_CD
		   AND LANG_CD = V_LANG_CD
		   AND DL_EXPD_PDI_CD = V_DL_EXPD_PDI_CD;
		   
		END IF;
		
   END SP_N1_INS_YN_UPDATE;
   
   --차종 신규 추가시에 사용!! 
   --(신규 추가된 차종에 대하여 이미 추가된 항목이 있을 가능성은 없지만 
   -- 삭제 로직을 제거하지 않고 그냥 둔다.)  
   PROCEDURE SP_N1_INS_YN_UPDATE2(P_DATA_SN   IN NUMBER,
                                  P_USER_EENO IN VARCHAR2)
   IS
   	 
	 V_QLTY_VEHL_CD   TB_VEHL_MGMT.QLTY_VEHL_CD%TYPE;
	 V_MDL_MDY_CD     TB_VEHL_MGMT.MDL_MDY_CD%TYPE;
	 V_DL_EXPD_CO_CD  TB_VEHL_MGMT.DL_EXPD_CO_CD%TYPE;
	 V_DL_PAC_SCN_CD  TB_VEHL_MGMT.DL_EXPD_PAC_SCN_CD%TYPE;
	 V_DL_EXPD_PDI_CD TB_VEHL_MGMT.DL_EXPD_PDI_CD%TYPE;
	 V_LANG_CD		  TB_LANG_MGMT.LANG_CD%TYPE;
	 V_N1_INS_YN      TB_LANG_MGMT.N1_INS_YN%TYPE;
	 	
   BEGIN
     
	 --수정/신규 입력된 언어정보 조회 
	 SELECT A.QLTY_VEHL_CD,
	 		A.MDL_MDY_CD,
			A.LANG_CD,
			B.DL_EXPD_CO_CD,
			B.DL_EXPD_PAC_SCN_CD,
			B.DL_EXPD_PDI_CD,
			NVL(A.N1_INS_YN, 'N')
	 INTO V_QLTY_VEHL_CD,
	 	  V_MDL_MDY_CD,
		  V_LANG_CD,
		  V_DL_EXPD_CO_CD,
		  V_DL_PAC_SCN_CD,
		  V_DL_EXPD_PDI_CD,
		  V_N1_INS_YN
	 FROM TB_LANG_MGMT A,
          TB_VEHL_MGMT B
	 WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
	 AND A.MDL_MDY_CD = B.MDL_MDY_CD
	 AND A.DATA_SN = P_DATA_SN;
	 
	 IF V_N1_INS_YN = 'Y' THEN
	 	 
		 --현재 수정/신규 입력된 차종, 연식, 언어가 
		 --다른 PDI 공통 차종에 묶인 경우가 있다면 해당 내역을 삭제해 준다. 
		 DELETE FROM TB_PDI_COM_VEHL_MGMT
		 WHERE QLTY_VEHL_CD = V_QLTY_VEHL_CD
		 AND MDL_MDY_CD = V_MDL_MDY_CD
		 AND LANG_CD = V_LANG_CD
		 AND DL_EXPD_PDI_CD = V_DL_EXPD_PDI_CD;
		 
		 --현재 수정/신규 입력된 차종, 연식, 언어를 PDI 공통 차종으로 하여 
		 --다른 차종을 묶어준다.
		 SP_N1_INS_YN_UPD_DTL(V_QLTY_VEHL_CD,
		 					  V_MDL_MDY_CD,
							  V_LANG_CD,
							  V_DL_EXPD_CO_CD,
							  V_DL_PAC_SCN_CD,
							  V_DL_EXPD_PDI_CD,
							  P_USER_EENO);
		 					 
	 ELSE
	 	 
		 --현재 수정/신규 입력된 차종, 연식, 언어에 
		 --공통 차종으로 묶인 차종들을 삭제해 준다.
		 DELETE FROM TB_PDI_COM_VEHL_MGMT
		 WHERE DIVS_QLTY_VEHL_CD = V_QLTY_VEHL_CD
		 AND MDL_MDY_CD = V_MDL_MDY_CD
		 AND LANG_CD = V_LANG_CD
		 AND DL_EXPD_PDI_CD = V_DL_EXPD_PDI_CD;
		 
		 --현재 수정/신규 입력된 차종, 연식, 언어에 대하여 
		 --공통 차종으로 지정된 항목이 있다면 그 항목에 현재의 차종을 추가로 묶어준다.
		 SP_N1_INS_YN_MDFY_DTL(V_QLTY_VEHL_CD,
	 	  					   V_MDL_MDY_CD,
		  					   V_LANG_CD,
		  					   V_DL_EXPD_PDI_CD,
							   P_USER_EENO);
		 
	 END IF;
	 
   END SP_N1_INS_YN_UPDATE2;
   
   --현재 수정/신규 입력된 차종, 연식, 언어를 PDI 공통 차종으로 하여 
   --다른 차종들을 묶는 작업 수행 
   PROCEDURE SP_N1_INS_YN_UPD_DTL(P_DIVS_VEHL_CD       IN VARCHAR2,
	 	  						 P_MDL_MDY_CD         IN VARCHAR2,
		  						 P_LANG_CD            IN VARCHAR2,
								 P_DL_EXPD_CO_CD      IN VARCHAR2,
								 P_DL_EXPD_PAC_SCN_CD IN VARCHAR2,
		  						 P_DL_EXPD_PDI_CD     IN VARCHAR2,
								 P_USER_EENO          IN VARCHAR2)
   IS
   	 
	 CURSOR VEHL_LIST_INFO IS SELECT A.QLTY_VEHL_CD,
	 				  	 		     A.MDL_MDY_CD,
								     A.LANG_CD,
								     B.DL_EXPD_CO_CD,
								     B.DL_EXPD_PDI_CD
							  FROM TB_LANG_MGMT A,
							       TB_VEHL_MGMT B
	 				  	      WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
	 					      AND A.MDL_MDY_CD = B.MDL_MDY_CD
						 	  AND NVL(A.N1_INS_YN, 'N') = 'N'
							  AND B.DL_EXPD_CO_CD = P_DL_EXPD_CO_CD
							  AND B.DL_EXPD_PAC_SCN_CD = P_DL_EXPD_PAC_SCN_CD
						 	  AND B.DL_EXPD_PDI_CD = P_DL_EXPD_PDI_CD
						 	  AND A.MDL_MDY_CD = P_MDL_MDY_CD
						 	  AND A.LANG_CD = P_LANG_CD
							  AND A.USE_YN = 'Y'
							  AND B.USE_YN = 'Y'
						 	  AND A.QLTY_VEHL_CD <> P_DIVS_VEHL_CD;
   BEGIN
   		
		FOR VEHL_LIST IN VEHL_LIST_INFO LOOP
			
			UPDATE TB_LANG_MGMT
			SET N1_INS_YN = 'N',
				UPDR_EENO = P_USER_EENO,
				MDFY_DTM = SYSDATE
			WHERE QLTY_VEHL_CD = VEHL_LIST.QLTY_VEHL_CD
			AND MDL_MDY_CD = VEHL_LIST.MDL_MDY_CD
			AND LANG_CD = VEHL_LIST.LANG_CD;
				  
			UPDATE TB_PDI_COM_VEHL_MGMT
			SET DL_EXPD_PDI_CD = VEHL_LIST.DL_EXPD_PDI_CD,
			    UPDR_EENO = P_USER_EENO,
				MDFY_DTM = SYSDATE
			WHERE QLTY_VEHL_CD = VEHL_LIST.QLTY_VEHL_CD
			AND MDL_MDY_CD = VEHL_LIST.MDL_MDY_CD
			AND LANG_CD = VEHL_LIST.LANG_CD
			AND DIVS_QLTY_VEHL_CD = P_DIVS_VEHL_CD;
			
			IF SQL%NOTFOUND THEN
			
			   INSERT INTO TB_PDI_COM_VEHL_MGMT
			   (QLTY_VEHL_CD,
			    MDL_MDY_CD,
				LANG_CD,
				DIVS_QLTY_VEHL_CD,
				DL_EXPD_PDI_CD,
				PPRR_EENO,
				FRAM_DTM,
				UPDR_EENO,
				MDFY_DTM
			   )
			   VALUES
			   (VEHL_LIST.QLTY_VEHL_CD,
			    VEHL_LIST.MDL_MDY_CD,
				VEHL_LIST.LANG_CD,
				P_DIVS_VEHL_CD,
				VEHL_LIST.DL_EXPD_PDI_CD,
				P_USER_EENO,
				SYSDATE,
				P_USER_EENO,
				SYSDATE
			   );
			   
			END IF;
			
		END LOOP;
		
   END SP_N1_INS_YN_UPD_DTL;						
   
   --현재 수정/신규 입력된 차종, 연식, 언어에 대하여 
   --공통 차종으로 지정된 항목이 있다면 그 항목에 현재의 차종을 추가로 묶어주는 작업 수행 
   PROCEDURE SP_N1_INS_YN_MDFY_DTL(P_QLTY_VEHL_CD   IN VARCHAR2,
	 	  						   P_MDL_MDY_CD     IN VARCHAR2,
		  						   P_LANG_CD        IN VARCHAR2,
		  						   P_DL_EXPD_PDI_CD IN VARCHAR2,
								   P_USER_EENO      IN VARCHAR2)
   IS
   	 
	 CURSOR VEHL_LIST_INFO IS SELECT DIVS_QLTY_VEHL_CD
							  FROM TB_PDI_COM_VEHL_MGMT
	 				  	      WHERE QLTY_VEHL_CD = P_QLTY_VEHL_CD
	 					      AND MDL_MDY_CD = P_MDL_MDY_CD
						 	  AND LANG_CD = P_LANG_CD
						 	  AND DL_EXPD_PDI_CD = P_DL_EXPD_PDI_CD;
							  
   BEGIN
   		
		FOR VEHL_LIST IN VEHL_LIST_INFO LOOP

			UPDATE TB_PDI_COM_VEHL_MGMT
			SET DL_EXPD_PDI_CD = P_DL_EXPD_PDI_CD,
			    UPDR_EENO = P_USER_EENO,
				MDFY_DTM = SYSDATE
			WHERE QLTY_VEHL_CD = P_QLTY_VEHL_CD
			AND MDL_MDY_CD = P_MDL_MDY_CD
			AND LANG_CD = P_LANG_CD
			AND DIVS_QLTY_VEHL_CD = VEHL_LIST.DIVS_QLTY_VEHL_CD;
			
			IF SQL%NOTFOUND THEN
			
			   INSERT INTO TB_PDI_COM_VEHL_MGMT
			   (QLTY_VEHL_CD,
			    MDL_MDY_CD,
				LANG_CD,
				DIVS_QLTY_VEHL_CD,
				DL_EXPD_PDI_CD,
				PPRR_EENO,
				FRAM_DTM,
				UPDR_EENO,
				MDFY_DTM
			   )
			   VALUES
			   (P_QLTY_VEHL_CD,
			    P_MDL_MDY_CD,
				P_LANG_CD,
				VEHL_LIST.DIVS_QLTY_VEHL_CD,
				P_DL_EXPD_PDI_CD,
				P_USER_EENO,
				SYSDATE,
				P_USER_EENO,
				SYSDATE
			   );
			   
			END IF;
			
		END LOOP;
		
   END SP_N1_INS_YN_MDFY_DTL;
   
   --차종코드 신규 입력시에 PDI 공통 차종 신규 지정 작업 수행 
   PROCEDURE SP_N1_INS_YN_UPD_PDI(P_QLTY_VEHL_CD   IN VARCHAR2,
	 	  						  P_MDL_MDY_CD     IN VARCHAR2,
								  P_DL_EXPD_PDI_CD IN VARCHAR2, 								  
								  P_USER_EENO      IN VARCHAR2)
   IS
   	 
	 CURSOR LANG_LIST_INFO IS SELECT DATA_SN
							  FROM TB_LANG_MGMT
	 				  	      WHERE QLTY_VEHL_CD = P_QLTY_VEHL_CD
	 					      AND MDL_MDY_CD = P_MDL_MDY_CD;
							  
   BEGIN
   		
		--PDI가 변경된 경우 기존에 입력되었던 정보를 모두 초기화 한 후
		--다시 입력해 준다.
		--(신규 추가된 차종에 대하여 이미 추가된 항목이 있을 가능성은 없지만 
		-- 삭제 로직을 제거하지 않고 그냥 둔다.)  
		
		DELETE FROM TB_PDI_COM_VEHL_MGMT
		WHERE QLTY_VEHL_CD = P_QLTY_VEHL_CD
		AND MDL_MDY_CD = P_MDL_MDY_CD
		AND DL_EXPD_PDI_CD <> P_DL_EXPD_PDI_CD;
		
		DELETE FROM TB_PDI_COM_VEHL_MGMT
		WHERE DIVS_QLTY_VEHL_CD = P_QLTY_VEHL_CD
		AND MDL_MDY_CD = P_MDL_MDY_CD
		AND DL_EXPD_PDI_CD <> P_DL_EXPD_PDI_CD;
		
		FOR LANG_LIST IN LANG_LIST_INFO LOOP
			
			SP_N1_INS_YN_UPDATE2(LANG_LIST.DATA_SN, 
								 P_USER_EENO);
		END LOOP;
		
   END SP_N1_INS_YN_UPD_PDI;								 
								 			
   --언어코드 수정시에 국가-차종의 지역정보를 수정해 준다. 						
   PROCEDURE SP_NATL_VEHL_REGN_SAVE(VEHL_CD           IN TB_LANG_MGMT.QLTY_VEHL_CD%TYPE,
                                    MDY_CD            IN TB_LANG_MGMT.MDL_MDY_CD%TYPE,
                                    L_CD              IN TB_LANG_MGMT.LANG_CD%TYPE,
                                    PREV_EXPD_REGN_CD IN TB_LANG_MGMT.DL_EXPD_REGN_CD%TYPE,
								    NEW_EXPD_REGN_CD  IN TB_LANG_MGMT.DL_EXPD_REGN_CD%TYPE)
   IS
  
  	 CURSOR NATL_LIST_INFO IS SELECT DL_EXPD_CO_CD,
	                                 DL_EXPD_NAT_CD
							  FROM TB_NATL_LANG_MGMT
							  WHERE QLTY_VEHL_CD = VEHL_CD
							  AND MDL_MDY_CD = MDY_CD
							  AND LANG_CD = L_CD
							  GROUP BY DL_EXPD_CO_CD, DL_EXPD_NAT_CD;
									
    BEGIN
  
  	   FOR NATL_LIST IN NATL_LIST_INFO LOOP
	   	   
		   UPDATE TB_NATL_VEHL_MGMT
		   SET DL_EXPD_REGN_CD = NEW_EXPD_REGN_CD,
		       --UPDR_EENO = P_EENO,
			   MDFY_DTM = SYSDATE
		   WHERE DL_EXPD_CO_CD = NATL_LIST.DL_EXPD_CO_CD
		   AND DL_EXPD_NAT_CD = NATL_LIST.DL_EXPD_NAT_CD
		   AND QLTY_VEHL_CD = VEHL_CD
		   AND DL_EXPD_REGN_CD = PREV_EXPD_REGN_CD;
		   
	   END LOOP;
  	   	   
    END SP_NATL_VEHL_REGN_SAVE;
    
	--이전연식에서 지정된 언어코드 항목 복사하는 기능수행(차종코드 수정/추가 시에 호출됨) 								   
    PROCEDURE SP_LANG_COPY(P_QLTY_VEHL_CD    IN VARCHAR2,
	 	  				   P_MDL_MDY_CD      IN VARCHAR2,
						   P_PREV_MDL_MDY_CD IN VARCHAR2,
						   P_USER_EENO       IN VARCHAR2)
	IS
	  CURSOR LANG_LIST_INFO IS SELECT A.QLTY_VEHL_CD,
        	 		                  A.LANG_CD,
        			                  A.DL_EXPD_REGN_CD,
        			                  A.LANG_CD_NM,
        			                  A.USE_YN,
									  A.NAPC_YN,
					                  A.SORT_SN, 
					                  A.A_CODE,
					                  NVL(A.N1_INS_YN, 'N') AS N1_INS_YN,
					                  FU_GET_PDI_COM_VEHL_LIST(A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD, B.DL_EXPD_PDI_CD) AS VEHL_LIST
      		                  FROM TB_LANG_MGMT A,
        	 	                   TB_VEHL_MGMT B
      		                  WHERE A.QLTY_VEHL_CD = P_QLTY_VEHL_CD
							  AND A.MDL_MDY_CD = P_PREV_MDL_MDY_CD
      		                  AND A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
      		                  AND A.MDL_MDY_CD = B.MDL_MDY_CD
							  AND A.USE_YN = 'Y';
	BEGIN
	
		  FOR LANG_LIST IN LANG_LIST_INFO LOOP
		  	  
			  SP_INSERT(LANG_LIST.QLTY_VEHL_CD,
			  			P_MDL_MDY_CD,
						LANG_LIST.LANG_CD,
						LANG_LIST.DL_EXPD_REGN_CD,
						LANG_LIST.LANG_CD_NM,
						LANG_LIST.USE_YN,
						LANG_LIST.NAPC_YN,
						LANG_LIST.SORT_SN,
						LANG_LIST.A_CODE,
						LANG_LIST.N1_INS_YN,
						LANG_LIST.VEHL_LIST,
						P_USER_EENO);
		  END LOOP;
		  
	END SP_LANG_COPY;
	
    --직전연식관계 내역을 저장(언어별) 					   
    PROCEDURE SP_LANG_MDY_MGMT_SAVE(P_VEHL_CD        VARCHAR2,
	   			 			        P_LANG_CD		 VARCHAR2,
                                    P_MDL_MDY_CD     VARCHAR2,
                                    P_PREV_REGN_CD   VARCHAR2,
                                    P_EXPD_REGN_CD   VARCHAR2,
                                    P_USER_EENO      VARCHAR2)
    IS
    	   	 
--		 V_CNT NUMBER;
    		 
    BEGIN
               
        --현재반영되어 있는 내역을 삭제한다,
        DELETE FROM TB_DL_LANG_MDY_MGMT
        WHERE QLTY_VEHL_CD  = P_VEHL_CD
        AND LANG_CD         = P_LANG_CD
        AND DL_EXPD_REGN_CD = P_PREV_REGN_CD
        AND MDL_MDY_CD      = P_MDL_MDY_CD;
        
        INSERT INTO TB_DL_LANG_MDY_MGMT(QLTY_VEHL_CD, LANG_CD, MDL_MDY_CD, DL_EXPD_MDL_MDY_CD, 
                                        PPRR_EENO, FRAM_DTM, UPDR_EENO, MDFY_DTM, DL_EXPD_REGN_CD)
        SELECT QLTY_VEHL_CD,
               P_LANG_CD AS LANG_CD,
               MDL_MDY_CD,
               DL_EXPD_MDL_MDY_CD,
               P_USER_EENO,
               SYSDATE,
               P_USER_EENO,
               SYSDATE,
               DL_EXPD_REGN_CD
        FROM TB_DL_EXPD_MDY_MGMT
        WHERE QLTY_VEHL_CD = P_VEHL_CD
        AND MDL_MDY_CD = P_MDL_MDY_CD
        AND DL_EXPD_REGN_CD = P_EXPD_REGN_CD;
                                                                    			
    END SP_LANG_MDY_MGMT_SAVE;
       					 
END PG_LANG_MGMT;