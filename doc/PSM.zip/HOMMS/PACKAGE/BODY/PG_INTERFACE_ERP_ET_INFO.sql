CREATE OR REPLACE PACKAGE BODY PG_INTERFACE_ERP_ET_INFO AS
	   
/**********************************************************/	   
	   --현대 생산마스터 데이터 전송 완료 일자 설정
	   PROCEDURE SET_ERP_ET_INFO_HMC
	   IS
	   BEGIN

		 SET_ERP_ET_INFO(EXPD_CO_CD_HMC);
		 
	   END SET_ERP_ET_INFO_HMC;
/**********************************************************/

/**********************************************************/	   
	   --생산마스터 데이터 전송 완료 일자 설정
	   PROCEDURE SET_ERP_ET_INFO(P_DL_EXPD_CO_CD VARCHAR2)
	   IS
		 V_CURR_YMD   VARCHAR2(8);
		 V_APL_YMD    VARCHAR2(8);
		 V_ET_GUBN_CD VARCHAR2(2);
		 V_CNT		NUMBER;
	   BEGIN

			V_CURR_YMD := TO_CHAR(SYSDATE, 'YYYYMMDD');
			V_APL_YMD  := TO_CHAR(SYSDATE - 12/24, 'YYYYMMDD');
			V_CNT := 0;
			
			IF V_CURR_YMD = V_APL_YMD THEN
				V_ET_GUBN_CD := '01';
				SELECT  COUNT(*)
				 	INTO V_CNT
				   FROM TB_PROD_MST_INFO_ERP_HMC
				  WHERE APL_YMD = V_CURR_YMD
				  AND ET_GUBN_CD IS NULL;
			ELSE
				V_ET_GUBN_CD := '02';
				 SELECT  COUNT(*)
				 	INTO V_CNT
				   FROM TB_PROD_MST_INFO_ERP_HMC
				  WHERE APL_YMD = V_APL_YMD
				  AND ET_GUBN_CD IS NULL;
			END IF;
            
            IF V_CNT > 0 THEN
	            UPDATE TB_BATCH_ERP_ET_INFO
	               SET   FRAM_DTM          = SYSDATE,
	                       ET_GUBN_CD        = V_ET_GUBN_CD
	             WHERE DL_EXPD_CO_CD = P_DL_EXPD_CO_CD
	                AND BTCH_FNH_YMD  = V_APL_YMD
	                AND ET_GUBN_CD       = V_ET_GUBN_CD;
	            
	            IF SQL%NOTFOUND THEN
	            	INSERT INTO TB_BATCH_ERP_ET_INFO
	                (
	                 DL_EXPD_CO_CD, BTCH_FNH_YMD, ET_GUBN_CD, FRAM_DTM
	                 )
	                 VALUES
	                (
	                 P_DL_EXPD_CO_CD, V_APL_YMD, V_ET_GUBN_CD, SYSDATE
	                 );
	            END IF;
            END IF;            
            
            COMMIT;
            
            EXCEPTION
            	WHEN OTHERS THEN
            		ROLLBACK;

	   END SET_ERP_ET_INFO;
/**********************************************************/
/**********************************************************/	   
	   --생산마스터 데이터 전송 완료 여부 확인
	   FUNCTION GET_ERP_ET_INFO_EXIST_YN(P_CURR_YMD VARCHAR2, P_DL_EXPD_CO_CD VARCHAR2, P_ET_GUBN_CD VARCHAR2) RETURN VARCHAR2
	   IS
		 V_CNT		NUMBER;
		 
	   BEGIN
	   
			SELECT COUNT(*)
              INTO V_CNT
              FROM TB_BATCH_ERP_ET_INFO
             WHERE DL_EXPD_CO_CD = P_DL_EXPD_CO_CD
               AND BTCH_FNH_YMD  = P_CURR_YMD
               AND ET_GUBN_CD    = P_ET_GUBN_CD
            ;
            
            IF V_CNT > 0 THEN
            	RETURN 'Y';
            ELSE
            	RETURN 'N';
            END IF;
            
	   END GET_ERP_ET_INFO_EXIST_YN;
/**********************************************************/

END PG_INTERFACE_ERP_ET_INFO;