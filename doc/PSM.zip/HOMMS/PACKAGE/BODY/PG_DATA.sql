CREATE OR REPLACE PACKAGE BODY HOMMS_ADM.PG_DATA AS
	   
/**********************************************************/	
	   --생산 마스터 배치 작업 시 생산 수량에 따른 재고 보정 작업 처리 
   	   PROCEDURE SP_PROD_MST_PDI_IV_UPDATE(P_VEHL_CD    VARCHAR2,
	   			 			   		       P_MDL_MDY_CD VARCHAR2,
							   			   P_LANG_CD    VARCHAR2,
							   			   P_CLS_YMD	VARCHAR2,
										   P_TRWI_QTY	NUMBER,
										   P_USER_EENO	VARCHAR2)
	   IS
	   	 
		 V_PREV_WHOT_QTY NUMBER;
		 V_TRWI_DIFF     NUMBER;

	   BEGIN
	   
		 	--이미 출고처리된 이전수량을 얻어온다. 
			
			/** PDI 출고 내역 테이블에 연식 컬럼을 추가함으로써 굳이 TB_DL_EXPD_MDY_MGMT 테이블과
			    JOIN 해서 처리해 줄 필요가 없다. 
				
			SELECT NVL(SUM(C.DL_EXPD_WHOT_QTY), 0) 
			INTO V_PREV_WHOT_QTY
			FROM TB_LANG_MGMT A,
			 	 TB_DL_EXPD_MDY_MGMT B,
			 	 TB_PDI_WHOT_INFO C 
			WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
			AND A.MDL_MDY_CD = B.MDL_MDY_CD
--[수정예정] 나중에 주석 제거해 줄 것		
			--AND A.DL_EXPD_REGN_CD = B.DL_EXPD_REGN_CD 
			AND A.QLTY_VEHL_CD = C.QLTY_VEHL_CD 		
			AND A.MDL_MDY_CD = C.MDL_MDY_CD 
			AND A.LANG_CD = C.LANG_CD 
			AND B.DL_EXPD_MDL_MDY_CD = C.DL_EXPD_MDL_MDY_CD 
			AND A.QLTY_VEHL_CD = P_VEHL_CD
			AND A.MDL_MDY_CD = P_MDL_MDY_CD
			AND A.LANG_CD = P_LANG_CD
			AND C.WHOT_YMD = P_CLS_YMD
			AND C.DEL_YN = 'N'
			-- 출고로 빠진 데이터만을 가져오도록 한다.
			AND C.DL_EXPD_WHOT_ST_CD = '01'; 
			**/  
			
			SELECT NVL(SUM(DL_EXPD_WHOT_QTY), 0)
			INTO V_PREV_WHOT_QTY
			FROM TB_PDI_WHOT_INFO
			WHERE QLTY_VEHL_CD = P_VEHL_CD
			AND MDL_MDY_CD = P_MDL_MDY_CD
			AND LANG_CD = P_LANG_CD
			AND WHOT_YMD = P_CLS_YMD
			AND DEL_YN = 'N'
			-- 출고로 빠진 데이터만을 가져오도록 한다.
			AND DL_EXPD_WHOT_ST_CD = '01'; 
			
			
			--원래 0보다 작은 값은 존재하면 안된다. 그러나 현재 존재하고 있어서 아래와 같은 체크로직을 추가함 
			IF V_PREV_WHOT_QTY < 0 THEN
			   
			   V_PREV_WHOT_QTY := 0;
			   
			END IF;
			
			--원래의 출고수량과 투입된 수량이 같으면 작업을 진행하지 않는다.
			V_TRWI_DIFF := P_TRWI_QTY - V_PREV_WHOT_QTY;
				
			--원래의 출고수량보다 투입수량이 많아진 경우
			IF V_TRWI_DIFF > 0 THEN
				   
			    SP_UPDATE_PDI_IV_INFO1(P_VEHL_CD, 
								       P_MDL_MDY_CD, 
								       P_LANG_CD,
				                       P_CLS_YMD,
									   V_TRWI_DIFF,
									   P_USER_EENO);
				
		    --원래의 출고수량보다 투입수량이 적어진 경우					 
		    ELSIF V_TRWI_DIFF < 0 THEN
				   
				SP_UPDATE_PDI_IV_INFO2(P_VEHL_CD, 
								       P_MDL_MDY_CD, 
								       P_LANG_CD,
				                       P_CLS_YMD,
									   V_TRWI_DIFF * (-1),
									   P_USER_EENO);
									  
		    END IF;

	   
	   END SP_PROD_MST_PDI_IV_UPDATE;
/**********************************************************/
/**********************************************************/
	   --원래의 출고수량보다 투입수량이 많아진 경우 호출 
	   PROCEDURE SP_UPDATE_PDI_IV_INFO1(P_QLTY_VEHL_CD IN VARCHAR2,
	   			 				        P_MDL_MDY_CD   IN VARCHAR2,
								    	P_LANG_CD      IN VARCHAR2,
								    	P_APL_YMD      IN VARCHAR2,
										P_TRWI_DIFF    IN NUMBER,
										P_USER_EENO	   IN VARCHAR2)
	   IS
	   	 
		 V_TRWI_DIFF NUMBER;
		 V_WHOT_DIFF NUMBER;
		 V_IV_DIFF	 NUMBER;
		 
		 V_DL_EXPD_MDL_MDY_CD VARCHAR2(2);
		 V_N_PRNT_PBCN_NO     VARCHAR2(100);
		 V_DTL_SN			  NUMBER;
		 								   
		 CURSOR PDI_IV_INFO IS SELECT A.CLS_YMD,
							   		  A.QLTY_VEHL_CD,
									  A.DL_EXPD_MDL_MDY_CD,
									  A.LANG_CD,
									  A.N_PRNT_PBCN_NO,
									  NVL(B.DTL_SN, 0) AS DTL_SN,
									  A.IV_QTY,
									  NVL(B.DL_EXPD_WHOT_QTY, 0) AS EXPD_WHOT_QTY
							   FROM (SELECT B.CLS_YMD,
									 	    B.QLTY_VEHL_CD,
										    B.DL_EXPD_MDL_MDY_CD,
											B.LANG_CD,
											B.N_PRNT_PBCN_NO,
											B.IV_QTY,
											A.MDL_MDY_CD
									 FROM (SELECT A.QLTY_VEHL_CD,
						   		                  B.DL_EXPD_MDL_MDY_CD,
								                  A.LANG_CD,
												  A.MDL_MDY_CD
                                           FROM TB_LANG_MGMT A,
								                TB_DL_EXPD_MDY_MGMT B
                                           WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
                                           AND A.MDL_MDY_CD = B.MDL_MDY_CD					   
										   AND A.DL_EXPD_REGN_CD = B.DL_EXPD_REGN_CD
						                   AND A.QLTY_VEHL_CD = P_QLTY_VEHL_CD
						                   AND A.MDL_MDY_CD = P_MDL_MDY_CD
						                   AND A.LANG_CD = P_LANG_CD
										  ) A,
										  TB_PDI_IV_INFO B
									 WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
					                 AND A.DL_EXPD_MDL_MDY_CD = B.DL_EXPD_MDL_MDY_CD
					                 AND A.LANG_CD = B.LANG_CD
								     AND CLS_YMD = P_APL_YMD
									 --재고 데이터가 0 보다 큰 값만을 가져온다. 
									 AND B.IV_QTY > 0 
									) A,
								    TB_PDI_WHOT_INFO B
							    WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD(+)
								AND A.MDL_MDY_CD = B.MDL_MDY_CD(+)
				      			AND A.LANG_CD = B.LANG_CD(+)
								AND A.DL_EXPD_MDL_MDY_CD = B.DL_EXPD_MDL_MDY_CD(+)
				      			AND A.N_PRNT_PBCN_NO = B.N_PRNT_PBCN_NO(+)
								AND A.CLS_YMD = B.WHOT_YMD(+)
								AND B.DEL_YN(+) = 'N'
								--출고로 빠진 데이터만을 가져오도록 한다.
								AND B.DL_EXPD_WHOT_ST_CD(+) = '01'
								--[변경] 2010.02.03.김동근 발간번호 정렬방식 변경 
								--이전연식의 재고부터 빼주도록 한다. 
								--ORDER BY A.DL_EXPD_MDL_MDY_CD, A.N_PRNT_PBCN_NO 
								ORDER BY A.DL_EXPD_MDL_MDY_CD, PG_COMMON.FU_GET_SORT_PBCN(A.N_PRNT_PBCN_NO)
								; 
								 
	   BEGIN
	   		
			V_TRWI_DIFF := P_TRWI_DIFF;
			
			FOR IV_LIST IN PDI_IV_INFO LOOP
				
				IF V_TRWI_DIFF > 0 THEN
				   
				   IF IV_LIST.IV_QTY >= V_TRWI_DIFF THEN
				   
				   	  V_WHOT_DIFF := V_TRWI_DIFF; --출고로 추가 빼주어야 하는 수량 
					  V_IV_DIFF   := V_TRWI_DIFF; --재고에서 추가 빼주어야 하는 수량 
					  V_TRWI_DIFF := 0;
					  
				   ELSE
				      
					  V_WHOT_DIFF := IV_LIST.IV_QTY; --출고로 추가 빼주어야 하는 수량 
					  V_IV_DIFF   := IV_LIST.IV_QTY; --재고에서 추가 빼주어야 하는 수량 
					  V_TRWI_DIFF := V_TRWI_DIFF - IV_LIST.IV_QTY;
					  
				   END IF;
				   
				    --출고항목 업데이트 작업 수행 
    			    UPDATE TB_PDI_WHOT_INFO
    		        SET CRGR_EENO = BTCH_USER_EENO,
    			        DL_EXPD_WHOT_QTY = DL_EXPD_WHOT_QTY + V_WHOT_DIFF,
    			        DEL_YN = 'N',
    			        UPDR_EENO = P_USER_EENO,
    			        MDFY_DTM = SYSDATE
    			    WHERE WHOT_YMD = P_APL_YMD
    	        	AND QLTY_VEHL_CD = P_QLTY_VEHL_CD
					AND MDL_MDY_CD = P_MDL_MDY_CD
    		        AND LANG_CD = P_LANG_CD
					AND DL_EXPD_MDL_MDY_CD = IV_LIST.DL_EXPD_MDL_MDY_CD
    		        AND N_PRNT_PBCN_NO = IV_LIST.N_PRNT_PBCN_NO
    		        AND DTL_SN = IV_LIST.DTL_SN; 
    			
    				--수정된 항목이 없다면 Insert 해준다. 
    		    	IF SQL%NOTFOUND THEN
    		   	  
    			  	   INSERT INTO TB_PDI_WHOT_INFO
       			  	   (WHOT_YMD,
    			   	    QLTY_VEHL_CD,
       			        DL_EXPD_MDL_MDY_CD,
       			        LANG_CD,
       			        N_PRNT_PBCN_NO,
       			        DTL_SN,
    			        DL_EXPD_WHOT_ST_CD,
    			        CRGR_EENO,
    			        DL_EXPD_WHOT_QTY,
    			        DEL_YN,
    			        PPRR_EENO,
       			        FRAM_DTM,
       			        UPDR_EENO,
       			        MDFY_DTM,
						MDL_MDY_CD
       			       )
       			       SELECT P_APL_YMD,
    			  		      P_QLTY_VEHL_CD,
       			              IV_LIST.DL_EXPD_MDL_MDY_CD,
       					      P_LANG_CD,
       					      IV_LIST.N_PRNT_PBCN_NO,
       					      NVL(MAX(DTL_SN), 0) + 1,
       		                  '01',
    					      BTCH_USER_EENO,
    					      V_WHOT_DIFF,
    					      'N',
    					      P_USER_EENO,
    					      SYSDATE,
    					      P_USER_EENO,
    					      SYSDATE,
							  P_MDL_MDY_CD
       			       FROM TB_PDI_WHOT_INFO
    			       WHERE WHOT_YMD = P_APL_YMD
       			       AND QLTY_VEHL_CD = P_QLTY_VEHL_CD
       			       AND DL_EXPD_MDL_MDY_CD = IV_LIST.DL_EXPD_MDL_MDY_CD
       			       AND LANG_CD = P_LANG_CD
       			       AND N_PRNT_PBCN_NO = IV_LIST.N_PRNT_PBCN_NO;
    		  
    		        END IF;
					
					--재고항목 업데이트 작업 수행
					SP_PDI_IV_INFO_UPDATE(P_QLTY_VEHL_CD,
										  P_MDL_MDY_CD,
										  P_LANG_CD,
										  IV_LIST.DL_EXPD_MDL_MDY_CD,
										  IV_LIST.N_PRNT_PBCN_NO,
										  P_APL_YMD,
										  V_IV_DIFF,
										  'Y',
										  'Y',
										  P_USER_EENO);
				ELSE
				
					--출고처리해야할 수량이 0 이 되면 작업을 종료한다. 
					RETURN;
					
				END IF;
				
			END LOOP;
			
			--재고를 다 소진하였는데도 아직 출고해야할 항목이 더 존재한다면....
			IF V_TRWI_DIFF > 0 THEN
			   
			   SP_GET_PDI_N_PRNT_PBCN_NO(P_QLTY_VEHL_CD,
                                   	     P_MDL_MDY_CD,
                                   	     P_LANG_CD,
                                   	     P_APL_YMD,
								   	     V_DL_EXPD_MDL_MDY_CD,
		 								 V_N_PRNT_PBCN_NO);
										 
			   IF V_DL_EXPD_MDL_MDY_CD IS NOT NULL AND
			      V_N_PRNT_PBCN_NO IS NOT NULL THEN
				    
					SELECT MAX(DTL_SN)
					INTO V_DTL_SN
					FROM TB_PDI_WHOT_INFO
					WHERE WHOT_YMD = P_APL_YMD
    	        	AND QLTY_VEHL_CD = P_QLTY_VEHL_CD
					AND MDL_MDY_CD = P_MDL_MDY_CD
    		        AND LANG_CD = P_LANG_CD
					AND DL_EXPD_MDL_MDY_CD = V_DL_EXPD_MDL_MDY_CD
    		        AND N_PRNT_PBCN_NO = V_N_PRNT_PBCN_NO
					AND DL_EXPD_WHOT_ST_CD = '01'
					AND DEL_YN = 'N';
					
					IF V_DTL_SN IS NOT NULL THEN
					   
					   --출고항목 업데이트 작업 수행 
    			       UPDATE TB_PDI_WHOT_INFO
    		           SET CRGR_EENO = BTCH_USER_EENO,
    			           DL_EXPD_WHOT_QTY = DL_EXPD_WHOT_QTY + V_TRWI_DIFF,
    			           DEL_YN = 'N',
    			           UPDR_EENO = P_USER_EENO,
    			           MDFY_DTM = SYSDATE,
						   MDL_MDY_CD = P_MDL_MDY_CD
    			       WHERE WHOT_YMD = P_APL_YMD
    	        	   AND QLTY_VEHL_CD = P_QLTY_VEHL_CD
					   AND MDL_MDY_CD = P_MDL_MDY_CD
    		       	   AND LANG_CD = P_LANG_CD
					   AND DL_EXPD_MDL_MDY_CD = V_DL_EXPD_MDL_MDY_CD
    		           AND N_PRNT_PBCN_NO = V_N_PRNT_PBCN_NO
    		           AND DTL_SN = V_DTL_SN; 
					
					ELSE
						
					   INSERT INTO TB_PDI_WHOT_INFO
       			  	   (WHOT_YMD,
    			   	    QLTY_VEHL_CD,
       			        DL_EXPD_MDL_MDY_CD,
       			        LANG_CD,
       			        N_PRNT_PBCN_NO,
       			        DTL_SN,
    			        DL_EXPD_WHOT_ST_CD,
    			        CRGR_EENO,
    			        DL_EXPD_WHOT_QTY,
    			        DEL_YN,
    			        PPRR_EENO,
       			        FRAM_DTM,
       			        UPDR_EENO,
       			        MDFY_DTM,
						MDL_MDY_CD
       			       )
       			       SELECT P_APL_YMD,
    			  		      P_QLTY_VEHL_CD,
       			              V_DL_EXPD_MDL_MDY_CD,
       					      P_LANG_CD,
       					      V_N_PRNT_PBCN_NO,
       					      NVL(MAX(DTL_SN), 0) + 1,
       		                  '01',
    					      BTCH_USER_EENO,
    					      V_TRWI_DIFF,
    					      'N',
    					      P_USER_EENO,
    					      SYSDATE,
    					      P_USER_EENO,
    					      SYSDATE,
							  P_MDL_MDY_CD
       			       FROM TB_PDI_WHOT_INFO
    			       WHERE WHOT_YMD = P_APL_YMD
       			       AND QLTY_VEHL_CD = P_QLTY_VEHL_CD
       			       AND DL_EXPD_MDL_MDY_CD = V_DL_EXPD_MDL_MDY_CD
       			       AND LANG_CD = P_LANG_CD
       			       AND N_PRNT_PBCN_NO = V_N_PRNT_PBCN_NO;
					   
					END IF;
					
				    SP_PDI_IV_INFO_UPDATE(P_QLTY_VEHL_CD,
										  P_MDL_MDY_CD,
										  P_LANG_CD,
										  V_DL_EXPD_MDL_MDY_CD,
										  V_N_PRNT_PBCN_NO,
										  P_APL_YMD,
										  V_TRWI_DIFF,
										  'Y',
										  'Y',
										  P_USER_EENO);
										  
			   END IF;
			   
			END IF;
						
	   END SP_UPDATE_PDI_IV_INFO1;
/**********************************************************/
/**********************************************************/	   
	   --원래의 출고수량보다 투입수량이 적어진 경우 호출 								
	   PROCEDURE SP_UPDATE_PDI_IV_INFO2(P_QLTY_VEHL_CD IN VARCHAR2,
	   			 				        P_MDL_MDY_CD   IN VARCHAR2,
								    	P_LANG_CD      IN VARCHAR2,
								    	P_APL_YMD      IN VARCHAR2,
										P_TRWI_DIFF    IN NUMBER,
										P_USER_EENO	   IN VARCHAR2)
	   IS
	   	 
		 V_TRWI_DIFF NUMBER;
		 V_WHOT_DIFF NUMBER;
		 V_IV_DIFF	 NUMBER;
		 
		 V_DL_EXPD_MDL_MDY_CD VARCHAR2(2);
		 V_N_PRNT_PBCN_NO     VARCHAR2(100);
		 V_DTL_SN			  NUMBER;
		 
		 CURSOR PDI_IV_INFO IS SELECT A.CLS_YMD,
							   		  A.QLTY_VEHL_CD,
									  A.DL_EXPD_MDL_MDY_CD,
									  A.LANG_CD,
									  A.N_PRNT_PBCN_NO,
									  B.DTL_SN,
									  A.IV_QTY,
									  B.DL_EXPD_WHOT_QTY AS EXPD_WHOT_QTY
							   FROM (SELECT B.CLS_YMD,
									 	    B.QLTY_VEHL_CD,
										    B.DL_EXPD_MDL_MDY_CD,
											B.LANG_CD,
											B.N_PRNT_PBCN_NO,
											B.IV_QTY,
											A.MDL_MDY_CD
									 FROM (SELECT A.QLTY_VEHL_CD,
						   		                  B.DL_EXPD_MDL_MDY_CD,
								                  A.LANG_CD,
												  A.MDL_MDY_CD
                                           FROM TB_LANG_MGMT A,
								                TB_DL_EXPD_MDY_MGMT B
                                           WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
                                           AND A.MDL_MDY_CD = B.MDL_MDY_CD					   
										   AND A.DL_EXPD_REGN_CD = B.DL_EXPD_REGN_CD										   
						                   AND A.QLTY_VEHL_CD = P_QLTY_VEHL_CD
						                   AND A.MDL_MDY_CD = P_MDL_MDY_CD
						                   AND A.LANG_CD = P_LANG_CD
										  ) A,
										  TB_PDI_IV_INFO B
									 WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
					                 AND A.DL_EXPD_MDL_MDY_CD = B.DL_EXPD_MDL_MDY_CD
					                 AND A.LANG_CD = B.LANG_CD
								     AND CLS_YMD = P_APL_YMD
									) A,
								    TB_PDI_WHOT_INFO B
							    WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
								AND A.MDL_MDY_CD = B.MDL_MDY_CD	
				      			AND A.LANG_CD = B.LANG_CD
								AND A.DL_EXPD_MDL_MDY_CD = B.DL_EXPD_MDL_MDY_CD							
				      			AND A.N_PRNT_PBCN_NO = B.N_PRNT_PBCN_NO
								AND A.CLS_YMD = B.WHOT_YMD
								AND B.DEL_YN = 'N'
								--출고로 빠진 데이터만을 가져오도록 한다.
								AND B.DL_EXPD_WHOT_ST_CD = '01'
								-- -값은 가져오지 않는다.
								AND B.DL_EXPD_WHOT_QTY > 0
								--[변경] 2010.02.03.김동근 발간번호 정렬방식 변경 
								--최근연식의 재고부터 더해주도록 한다. 
								--ORDER BY A.DL_EXPD_MDL_MDY_CD DESC, A.N_PRNT_PBCN_NO DESC 
								ORDER BY A.DL_EXPD_MDL_MDY_CD DESC, PG_COMMON.FU_GET_SORT_PBCN(A.N_PRNT_PBCN_NO) DESC
								; 
								 
	   BEGIN
	   		
			V_TRWI_DIFF := P_TRWI_DIFF;
			
			FOR IV_LIST IN PDI_IV_INFO LOOP
				
				IF V_TRWI_DIFF > 0 THEN
				   
				   IF IV_LIST.EXPD_WHOT_QTY >= V_TRWI_DIFF THEN
				   
				   	  V_WHOT_DIFF := V_TRWI_DIFF * (-1); --출고로 추가 빼주어야 하는 수량 
					  V_IV_DIFF   := V_TRWI_DIFF * (-1); --재고에서 추가 빼주어야 하는 수량 
					  V_TRWI_DIFF := 0;
					  
				   ELSE
				      
					  V_WHOT_DIFF := IV_LIST.EXPD_WHOT_QTY * (-1); --출고로 추가 빼주어야 하는 수량 
					  V_IV_DIFF   := IV_LIST.EXPD_WHOT_QTY * (-1); --재고에서 추가 빼주어야 하는 수량 
					  V_TRWI_DIFF := V_TRWI_DIFF - IV_LIST.EXPD_WHOT_QTY;
					  
				   END IF;
				   
				   --출고항목 업데이트 작업 수행 
    			   UPDATE TB_PDI_WHOT_INFO
    		       SET CRGR_EENO = BTCH_USER_EENO,
    			       DL_EXPD_WHOT_QTY = DL_EXPD_WHOT_QTY + V_WHOT_DIFF,
    			       DEL_YN = 'N',
    			       UPDR_EENO = P_USER_EENO,
    			       MDFY_DTM = SYSDATE
    			   WHERE WHOT_YMD = P_APL_YMD
    	           AND QLTY_VEHL_CD = P_QLTY_VEHL_CD
				   AND MDL_MDY_CD = P_MDL_MDY_CD
    		       AND LANG_CD = P_LANG_CD
				   AND DL_EXPD_MDL_MDY_CD = IV_LIST.DL_EXPD_MDL_MDY_CD
    		       AND N_PRNT_PBCN_NO = IV_LIST.N_PRNT_PBCN_NO
    		       AND DTL_SN = IV_LIST.DTL_SN; 
    			
				   --재고항목 업데이트 작업 수행
				   SP_PDI_IV_INFO_UPDATE(P_QLTY_VEHL_CD,
				   						 P_MDL_MDY_CD,
										 P_LANG_CD,
										 IV_LIST.DL_EXPD_MDL_MDY_CD,
										 IV_LIST.N_PRNT_PBCN_NO,
										 P_APL_YMD,
										 V_IV_DIFF,
										 'Y',
										 'Y',
										 P_USER_EENO);
														 
				ELSE
				
					--출고처리해야할 수량이 0 이 되면 작업을 종료한다. 
					RETURN;
					
				END IF;
				
			END LOOP;
			
			--재고 항목을 모두 업데이트 하였는데도 출고에서 더 빼주어야할 데이터가 존재한다면.... 
			IF V_TRWI_DIFF > 0 THEN
			   
			   V_TRWI_DIFF := V_TRWI_DIFF * (-1);
			   
			   SP_GET_PDI_N_PRNT_PBCN_NO(P_QLTY_VEHL_CD,
                                   	     P_MDL_MDY_CD,
                                   	     P_LANG_CD,
                                   	     P_APL_YMD,
								   	     V_DL_EXPD_MDL_MDY_CD,
		 								 V_N_PRNT_PBCN_NO);
										 
			   IF V_DL_EXPD_MDL_MDY_CD IS NOT NULL AND
			      V_N_PRNT_PBCN_NO IS NOT NULL THEN
				    
					SELECT MAX(DTL_SN)
					INTO V_DTL_SN
					FROM TB_PDI_WHOT_INFO
					WHERE WHOT_YMD = P_APL_YMD
    	        	AND QLTY_VEHL_CD = P_QLTY_VEHL_CD
					AND MDL_MDY_CD = P_MDL_MDY_CD
    		        AND LANG_CD = P_LANG_CD
					AND DL_EXPD_MDL_MDY_CD = V_DL_EXPD_MDL_MDY_CD
    		        AND N_PRNT_PBCN_NO = V_N_PRNT_PBCN_NO
					AND DL_EXPD_WHOT_ST_CD = '01'
					AND DEL_YN = 'N';
					
					IF V_DTL_SN IS NOT NULL THEN
					   
					   --출고항목 업데이트 작업 수행 
    			       UPDATE TB_PDI_WHOT_INFO
    		           SET CRGR_EENO = BTCH_USER_EENO,
    			           DL_EXPD_WHOT_QTY = DL_EXPD_WHOT_QTY + V_TRWI_DIFF,
    			           DEL_YN = 'N',
    			           UPDR_EENO = P_USER_EENO,
    			           MDFY_DTM = SYSDATE
    			       WHERE WHOT_YMD = P_APL_YMD
    	        	   AND QLTY_VEHL_CD = P_QLTY_VEHL_CD
					   AND MDL_MDY_CD = P_MDL_MDY_CD
    		       	   AND LANG_CD = P_LANG_CD
					   AND DL_EXPD_MDL_MDY_CD = V_DL_EXPD_MDL_MDY_CD
    		           AND N_PRNT_PBCN_NO = V_N_PRNT_PBCN_NO
    		           AND DTL_SN = V_DTL_SN; 
					
					ELSE
						
					   INSERT INTO TB_PDI_WHOT_INFO
       			  	   (WHOT_YMD,
    			   	    QLTY_VEHL_CD,
       			        DL_EXPD_MDL_MDY_CD,
       			        LANG_CD,
       			        N_PRNT_PBCN_NO,
       			        DTL_SN,
    			        DL_EXPD_WHOT_ST_CD,
    			        CRGR_EENO,
    			        DL_EXPD_WHOT_QTY,
    			        DEL_YN,
    			        PPRR_EENO,
       			        FRAM_DTM,
       			        UPDR_EENO,
       			        MDFY_DTM,
						MDL_MDY_CD
       			       )
       			       SELECT P_APL_YMD,
    			  		      P_QLTY_VEHL_CD,
       			              V_DL_EXPD_MDL_MDY_CD,
       					      P_LANG_CD,
       					      V_N_PRNT_PBCN_NO,
       					      NVL(MAX(DTL_SN), 0) + 1,
       		                  '01',
    					      BTCH_USER_EENO,
    					      V_TRWI_DIFF,
    					      'N',
    					      P_USER_EENO,
    					      SYSDATE,
    					      P_USER_EENO,
    					      SYSDATE,
							  P_MDL_MDY_CD
       			       FROM TB_PDI_WHOT_INFO
    			       WHERE WHOT_YMD = P_APL_YMD
       			       AND QLTY_VEHL_CD = P_QLTY_VEHL_CD
       			       AND DL_EXPD_MDL_MDY_CD = V_DL_EXPD_MDL_MDY_CD
       			       AND LANG_CD = P_LANG_CD
       			       AND N_PRNT_PBCN_NO = V_N_PRNT_PBCN_NO;
					   
					END IF;
					
				    SP_PDI_IV_INFO_UPDATE(P_QLTY_VEHL_CD,
										  P_MDL_MDY_CD,
										  P_LANG_CD,
										  V_DL_EXPD_MDL_MDY_CD,
										  V_N_PRNT_PBCN_NO,
										  P_APL_YMD,
										  V_TRWI_DIFF,
										  'Y',
										  'Y',
										  P_USER_EENO);
										  
			   END IF;
			   
			END IF;
	   			 
	   END SP_UPDATE_PDI_IV_INFO2;
/**********************************************************/
/**********************************************************/
       --PDI 재고정보 Insert(입고확인) 
	   PROCEDURE SP_PDI_IV_INFO_SAVE_BY_WHSN(P_CURR_YMD		   VARCHAR2,
	   			 							 P_VEHL_CD         VARCHAR2,
											 P_MDL_MDY_CD      VARCHAR2,
								          	 P_LANG_CD         VARCHAR2,
											 P_EXPD_MDL_MDY_CD VARCHAR2,
								    	  	 P_N_PRNT_PBCN_NO  VARCHAR2,
								    	  	 P_DTL_SN          NUMBER,
								    	  	 P_EXPD_WHSN_ST_CD VARCHAR2,
								    	  	 P_EXPD_BOX_QTY    NUMBER,
								    	  	 P_WHSN_QTY		   NUMBER,
								    	  	 P_DEEI1_QTY	   NUMBER,
								    	  	 P_USER_EENO	   VARCHAR2)
	   IS
	   BEGIN
	   		
			--PDI재고 Insert 작업 수행 
			INSERT INTO TB_PDI_IV_INFO
			(CLS_YMD,
			 QLTY_VEHL_CD,
			 DL_EXPD_MDL_MDY_CD,
			 LANG_CD,
			 N_PRNT_PBCN_NO,
			 IV_QTY,
			 CMPL_YN,
			 PPRR_EENO,
			 FRAM_DTM,
			 UPDR_EENO,
			 MDFY_DTM,
             IV_SCN_CD
			)
			VALUES
			(P_CURR_YMD,
			 P_VEHL_CD,
			 P_EXPD_MDL_MDY_CD,
			 P_LANG_CD,
			 P_N_PRNT_PBCN_NO,
			 P_WHSN_QTY, 
			 'N',
			 P_USER_EENO,
			 SYSDATE,
			 P_USER_EENO,
			 SYSDATE,
             'Y'
			);
			
			--현재의 입고 내역을 재고상세 테이블에 저장한다.
			SP_UPDATE_PDI_IV_DTL_INFO(P_VEHL_CD,
									  P_EXPD_MDL_MDY_CD,
									  P_LANG_CD,
									  P_N_PRNT_PBCN_NO,
									  P_CURR_YMD,
									  P_USER_EENO);
									  
			--입고내역에 대한 재고상세 테이블 재계산 작업 수행 							 
			SP_RECALCULATE_PDI_IV_DTL4(P_CURR_YMD,
									   P_VEHL_CD,
									   P_LANG_CD,
									   P_USER_EENO);			

	   END SP_PDI_IV_INFO_SAVE_BY_WHSN;
/**********************************************************/										
/**********************************************************/	
	   --PDI 재고 정보 저장 
       PROCEDURE SP_PDI_IV_INFO_UPDATE(P_VEHL_CD         VARCHAR2,
	   			 					   P_MDL_MDY_CD      VARCHAR2,
							           P_LANG_CD         VARCHAR2,
									   P_EXPD_MDL_MDY_CD VARCHAR2,
								       P_N_PRNT_PBCN_NO  VARCHAR2,
								       P_CLS_YMD		 VARCHAR2,
								       P_DIFF_WHOT_QTY	 NUMBER,
									   P_BATCH_FLAG	     VARCHAR2, --배치프로그램에서 호출 여부 
									   P_CASCADE_FLAG	 VARCHAR2, --현재일 이전날짜의 재고보정 허용 여부 
								       P_USER_EENO	     VARCHAR2)
	   IS
	   	 
		 V_CNT		 NUMBER;
		 
		 V_FROM_DATE DATE;
		 V_TO_DATE   DATE;
		 V_CURR_DATE DATE;
		 
		 V_CURR_YMD  VARCHAR2(8);
		 V_SYST_YMD  VARCHAR2(8);
		 
		 V_QTY		 NUMBER;
		 V_DIFF_QTY  NUMBER;
		 
		 V_DEEI1_QTY NUMBER;
		 
	   BEGIN
	   		
			IF P_BATCH_FLAG = 'N' THEN
			   
			   IF P_CASCADE_FLAG = 'N' THEN
			   	   
				   SELECT NVL(SUM(IV_QTY), 0)
			   	   INTO V_QTY
			   	   FROM TB_PDI_IV_INFO
			   	   WHERE CLS_YMD = P_CLS_YMD
			   	   AND QLTY_VEHL_CD = P_VEHL_CD
			   	   AND DL_EXPD_MDL_MDY_CD = P_EXPD_MDL_MDY_CD
			   	   AND LANG_CD = P_LANG_CD
			   	   AND N_PRNT_PBCN_NO = P_N_PRNT_PBCN_NO
			   	   AND CMPL_YN = 'N';
			
			   	   IF V_QTY < P_DIFF_WHOT_QTY THEN 
			      
				   	  --현재 남아있는 재고수량보다 출고수량이 큰 경우에는 재고보정을 수행하지 않는다. 
				  	  --(만일 재고보정이 가능하게 되면 예기치 않은 여러 문제가 발생될 수 있다.) 
				  
			   	  	  RAISE_APPLICATION_ERROR(-20001, 'Invalid pdi inventory quantity ' || 
			   								   	  	  'date:' || TO_CHAR(TO_DATE(P_CLS_YMD, 'YYYYMMDD'), 'YYYY-MM-DD') || ',' ||
											   	  	  'vehl:' || P_VEHL_CD || ',' || 
											   	  	  'mkyr:' || P_EXPD_MDL_MDY_CD || ',' || 
											   	  	  'lang:' || P_LANG_CD || ',' || P_N_PRNT_PBCN_NO || ',' ||
											   	  	  'qty :' || TO_CHAR(P_DIFF_WHOT_QTY)); 
			   	   ELSE
			      
				   	  V_DIFF_QTY  := P_DIFF_WHOT_QTY;
					   
			   	   END IF;
			   
			   	   UPDATE TB_PDI_IV_INFO
			   	   SET IV_QTY = (IV_QTY - V_DIFF_QTY),
			   	   	   --DEEI1_QTY = NULL,  -- 최소한 재고가 0 이상 이므로 초과부족수량은 NULL로 해준다.
				   	   UPDR_EENO = P_USER_EENO,
				   	   MDFY_DTM = SYSDATE
			       WHERE CLS_YMD = P_CLS_YMD
			   	   AND QLTY_VEHL_CD = P_VEHL_CD
			   	   AND DL_EXPD_MDL_MDY_CD = P_EXPD_MDL_MDY_CD
			   	   AND LANG_CD = P_LANG_CD
			   	   AND N_PRNT_PBCN_NO = P_N_PRNT_PBCN_NO
			   	   AND CMPL_YN = 'N'; --이전날짜의 데이터인 경우에는 입력이 되지 않도록 한다.. 
			
			   	   IF SQL%NOTFOUND THEN
			   
			       	  RAISE_APPLICATION_ERROR(-20001, 'Invalid input value ' || 
			   								          'date:' || TO_CHAR(TO_DATE(P_CLS_YMD, 'YYYYMMDD'), 'YYYY-MM-DD') || ',' ||
											      	  'vehl:' || P_VEHL_CD || ',' || 
											      	  'mkyr:' || P_EXPD_MDL_MDY_CD || ',' || 
											      	  'lang:' || P_LANG_CD || ',' || P_N_PRNT_PBCN_NO);
			   
			       END IF;
			   
			   	   --현재의 재고보정 내역을 재고상세 테이블에 저장한다.
			   	   SP_UPDATE_PDI_IV_DTL_INFO(P_VEHL_CD,
									         P_EXPD_MDL_MDY_CD,
									     	 P_LANG_CD,
									     	 P_N_PRNT_PBCN_NO,
									     	 P_CLS_YMD,
									     	 P_USER_EENO);
			   
			       --재고보정에 대한 재고상세 테이블 재계산 작업 수행 							 
			   	   SP_RECALCULATE_PDI_IV_DTL4(P_CLS_YMD,
										  	  P_VEHL_CD,
									      	  P_LANG_CD,
										  	  P_USER_EENO);
										  
			   ELSE
			   	   
				   --현재는 가장 최근의 재고내역만 수정하므로 아무런 작업을 수행하지 않는다. 
				   --(현재일 이전의 재고보정 기능은 현재 지원해 주지 않는다.)
				   	   
				   RETURN;
				   
			   END IF;
				  
			ELSE
				
				V_FROM_DATE := TO_DATE(P_CLS_YMD, 'YYYYMMDD');
				V_TO_DATE   := TO_DATE(TO_CHAR(SYSDATE, 'YYYYMMDD'), 'YYYYMMDD');
				V_SYST_YMD  := TO_CHAR(V_TO_DATE, 'YYYYMMDD');
				
				V_CNT := ROUND(V_TO_DATE - V_FROM_DATE);
				
				FOR NUM IN 0..V_CNT LOOP
					
					V_CURR_DATE := V_FROM_DATE + NUM;
					
					V_CURR_YMD := TO_CHAR(V_CURR_DATE, 'YYYYMMDD');
					
					SELECT NVL(SUM(IV_QTY), 0),
						   NVL(SUM(DEEI1_QTY), 0)
			   		INTO V_QTY,
						 V_DEEI1_QTY
			   		FROM TB_PDI_IV_INFO
			   		WHERE CLS_YMD = V_CURR_YMD
			   		AND QLTY_VEHL_CD = P_VEHL_CD
			   		AND DL_EXPD_MDL_MDY_CD = P_EXPD_MDL_MDY_CD
			   		AND LANG_CD = P_LANG_CD
			   		AND N_PRNT_PBCN_NO = P_N_PRNT_PBCN_NO;
			   		
					IF V_QTY < P_DIFF_WHOT_QTY THEN 
					   
					   --재고 수량보다 출고수량이 많은 경우에는 재고수량을 0 으로 해준다.
					   V_DIFF_QTY  := V_QTY;
					   
					   --배치 프로그램이 아닌 다름 프로그램에서 호출시에 문제 발생 여지 있음 
					   V_DEEI1_QTY := V_DEEI1_QTY + (P_DIFF_WHOT_QTY - V_QTY); 

					ELSE
					   
					   --배치 프로그램이 아닌 다름 프로그램에서 호출시에 문제 발생 여지 있음 
					   --초과부족수량이 존재하며 현재 재고수량이 0 인 경우에만 아래의 작업을 수행한다.
					   IF V_DEEI1_QTY > 0 AND V_QTY = 0 THEN
					   	  
						  IF (P_DIFF_WHOT_QTY + V_DEEI1_QTY) > 0 THEN
						  	 
							 V_DIFF_QTY  := V_QTY;
							 V_DEEI1_QTY := P_DIFF_WHOT_QTY + V_DEEI1_QTY;
							 
						  ELSE
						     
							 V_DIFF_QTY  := P_DIFF_WHOT_QTY + V_DEEI1_QTY;
							 V_DEEI1_QTY := 0;
							 
						  END IF;

					   ELSE
					   	   
						   V_DIFF_QTY  := P_DIFF_WHOT_QTY;
					   	   --V_DEEI1_QTY := 0;
					   
					   END IF;

					END IF;
					
					UPDATE TB_PDI_IV_INFO
			   		SET IV_QTY = IV_QTY - V_DIFF_QTY,
				   		UPDR_EENO = P_USER_EENO,
				   		MDFY_DTM = SYSDATE,
						DEEI1_QTY = CASE WHEN V_DEEI1_QTY > 0 THEN V_DEEI1_QTY ELSE NULL END
			   		WHERE CLS_YMD = V_CURR_YMD
			   		AND QLTY_VEHL_CD = P_VEHL_CD
			   		AND DL_EXPD_MDL_MDY_CD = P_EXPD_MDL_MDY_CD
			   		AND LANG_CD = P_LANG_CD
			   		AND N_PRNT_PBCN_NO = P_N_PRNT_PBCN_NO; 
			   		
					IF SQL%NOTFOUND THEN
					   
					   --과잉출고 되어 재고 보정작업하는 경우에만 신규로 추가해 주면 된다.
					   --(V_DIFF_QTY 로 비교하지 않도록 주의 할 것)   		  
					   IF P_DIFF_WHOT_QTY < 0 THEN
					   	  
						  INSERT INTO TB_PDI_IV_INFO
						  (CLS_YMD,
			 			   QLTY_VEHL_CD,
			 			   DL_EXPD_MDL_MDY_CD,
			 			   LANG_CD,
			 			   N_PRNT_PBCN_NO,
			 			   IV_QTY,
			 			   CMPL_YN,
			 			   PPRR_EENO,
			 			   FRAM_DTM,
			 			   UPDR_EENO,
			 			   MDFY_DTM,
						   TMP_TRTM_YN
						  )
					   	  VALUES(V_CURR_YMD,
							     P_VEHL_CD,
							     P_EXPD_MDL_MDY_CD,
							     P_LANG_CD,
							     P_N_PRNT_PBCN_NO,
								 --P_DIFF_WHOT_QTY 가 - 로 들어오기 때문에 이때는 -1을 곱해주어야 한다. 
								 P_DIFF_WHOT_QTY * (-1),
								 CASE WHEN V_CURR_YMD = V_SYST_YMD THEN 'N' ELSE 'Y' END,
								 P_USER_EENO,
								 SYSDATE,
								 P_USER_EENO,
								 SYSDATE,
								 'Y'
								);					   	  
						  
					   END IF;
	
					END IF;
					
					--현재의 재고보정 내역을 재고상세 테이블에 저장한다.
					SP_UPDATE_PDI_IV_DTL_INFO(P_VEHL_CD,
									          P_EXPD_MDL_MDY_CD,
									          P_LANG_CD,
									          P_N_PRNT_PBCN_NO,
									          V_CURR_YMD,
									          P_USER_EENO);
											  
					--재고상세 테이블 재계산 작업은 외부(배치프로그램)에서 수행해 준다. 												  
										 
				END LOOP;

			END IF;
			
	   END SP_PDI_IV_INFO_UPDATE;
/**********************************************************/
/**********************************************************/
       --PDI 재고정보 업데이트 수행(재고전환 기능) 																		
	   PROCEDURE SP_PDI_IV_INFO_UPDATE3(P_VEHL_CD         VARCHAR2,
			  						 	P_MDL_MDY_CD	  VARCHAR2,
									 	P_LANG_CD         VARCHAR2,
									 	P_EXPD_MDL_MDY_CD VARCHAR2,
									 	P_N_PRNT_PBCN_NO  VARCHAR2,
									 	P_CLS_YMD		  VARCHAR2,
									 	P_DIFF_RQ_QTY	  NUMBER,
									 	P_USER_EENO	      VARCHAR2,
									 	P_FLAG			  VARCHAR2)
	   IS
	   
	   	 V_QTY		   NUMBER;
		 V_DIFF_RQ_QTY NUMBER;
		 
	   BEGIN
	   		
			SELECT NVL(SUM(IV_QTY), 0)
			INTO V_QTY
			FROM TB_PDI_IV_INFO
			WHERE CLS_YMD = P_CLS_YMD
			AND QLTY_VEHL_CD = P_VEHL_CD
			AND DL_EXPD_MDL_MDY_CD = P_EXPD_MDL_MDY_CD
			AND LANG_CD = P_LANG_CD
			AND N_PRNT_PBCN_NO = P_N_PRNT_PBCN_NO
			AND CMPL_YN = 'N';
				   
			--재고수량이 출고수량보다 작은 경우에는 출고 하지 못한다. 
			IF V_QTY < P_DIFF_RQ_QTY THEN
			   
			   RAISE_APPLICATION_ERROR(-20001, 'Invalid pdi inventory quantity ' || 
			   								   'date:' || TO_CHAR(TO_DATE(P_CLS_YMD, 'YYYYMMDD'), 'YYYY-MM-DD') || ',' ||
											   'vehl:' || P_VEHL_CD || ',' || 
											   'mkyr:' || P_EXPD_MDL_MDY_CD || ',' || 
											   'lang:' || P_LANG_CD || ',' || P_N_PRNT_PBCN_NO || ',' ||
											   'qty :' || TO_CHAR(P_DIFF_RQ_QTY)); 
											   
			END IF;
				   	
			UPDATE TB_PDI_IV_INFO
			SET IV_QTY = (IV_QTY - P_DIFF_RQ_QTY),
				UPDR_EENO = P_USER_EENO,
				MDFY_DTM = SYSDATE
			WHERE CLS_YMD = P_CLS_YMD
			AND QLTY_VEHL_CD = P_VEHL_CD
			AND DL_EXPD_MDL_MDY_CD = P_EXPD_MDL_MDY_CD
			AND LANG_CD = P_LANG_CD
			AND N_PRNT_PBCN_NO = P_N_PRNT_PBCN_NO
			AND CMPL_YN = 'N'; --이전날짜의 데이터인 경우에는 입력이 되지 않도록 한다.. 
			
			IF SQL%NOTFOUND THEN
			   
			   IF P_FLAG = 'Y' THEN
			   	  
				  RAISE_APPLICATION_ERROR(-20001, 'Invalid input value ' || 
			   								      'date:' || TO_CHAR(TO_DATE(P_CLS_YMD, 'YYYYMMDD'), 'YYYY-MM-DD') || ',' ||
											      'vehl:' || P_VEHL_CD || ',' || 
											      'mkyr:' || P_EXPD_MDL_MDY_CD || ',' || 
											      'lang:' || P_LANG_CD || ',' || P_N_PRNT_PBCN_NO);
											   
			   ELSE
			   	  
				  INSERT INTO TB_PDI_IV_INFO
				  (CLS_YMD,
			 	   QLTY_VEHL_CD,
			 	   DL_EXPD_MDL_MDY_CD,
			 	   LANG_CD,
			 	   N_PRNT_PBCN_NO,
			 	   IV_QTY,
			 	   CMPL_YN,
			 	   PPRR_EENO,
			 	   FRAM_DTM,
			 	   UPDR_EENO,
			 	   MDFY_DTM,
				   TMP_TRTM_YN
				  )
				  VALUES(P_CLS_YMD,
						 P_VEHL_CD,
						 P_EXPD_MDL_MDY_CD,
					     P_LANG_CD,
						 P_N_PRNT_PBCN_NO,
						 --P_DIFF_RQ_QTY가 - 로 들어오기 때문에 이때는 -1을 곱해주어야 한다. 
						 P_DIFF_RQ_QTY * (-1),
						 'N',
						 P_USER_EENO,
						 SYSDATE,
						 P_USER_EENO,
						 SYSDATE,
						 --재고보정에 의해서 임시 생성된 데이터이므로 무조건 'Y' 로 설정해 준다.
						 'Y'
						);
			   END IF;
			   
		    END IF;
	   		
			--현재의 출고 내역을 재고상세 테이블에 저장한다.
			SP_UPDATE_PDI_IV_DTL_INFO(P_VEHL_CD,
									  P_EXPD_MDL_MDY_CD,
									  P_LANG_CD,
									  P_N_PRNT_PBCN_NO,
									  P_CLS_YMD,
									  P_USER_EENO);
			   
			--출고 내역에 대한 재고상세 테이블 재계산 작업 수행				 
			SP_RECALCULATE_PDI_IV_DTL4(P_CLS_YMD,
									   P_VEHL_CD,
									   P_LANG_CD,
									   P_USER_EENO);
	   END SP_PDI_IV_INFO_UPDATE3;
/**********************************************************/
									 
									 	
/**********************************************************/	
	   --PDI 재고 데이터가 존재하지 않는 경우 가장 최근의 발간번호및 취급설명서 연식코드를 조회 							   
   	   PROCEDURE SP_GET_PDI_N_PRNT_PBCN_NO(P_VEHL_CD      		VARCHAR2,
                                   	       P_MDL_MDY_CD 		VARCHAR2,
                                   	       P_LANG_CD    		VARCHAR2,
                                   	       P_CLS_YMD			VARCHAR2,
								   	       P_DL_EXPD_MDL_MDY_CD OUT VARCHAR2,
								   	       P_N_PRNT_PBCN_NO     OUT VARCHAR2
								          )
	   IS
	   	 
		 V_CNT       	   NUMBER;
		 
		 V_DL_EXPD_REGN_CD VARCHAR2(4);
		 
	   BEGIN
	   		
			P_DL_EXPD_MDL_MDY_CD := NULL;
			P_N_PRNT_PBCN_NO     := NULL;
			
			SELECT MAX(DL_EXPD_REGN_CD)
		    INTO V_DL_EXPD_REGN_CD
			FROM TB_LANG_MGMT
			WHERE QLTY_VEHL_CD = P_VEHL_CD
			AND MDL_MDY_CD = P_MDL_MDY_CD
			AND LANG_CD = P_LANG_CD;
			
			--TB_PDI_IV_INFO_DTL  테이블이 아니라 TB_PDI_IV_INFO 테이블에서 조회하면 된다.
			--왜냐하면 이곳에서는 즉시 재고 재계산 작업이 즉시 이루어지기 때문이다.
							
			--현재는 무조건 가장 최근(큰) 연식을 가져오도록 처리함 
		    --(필요에 따라 현재의 차종연식과 같은 연식이 있으면 그것을 가져오도록 변경할 여지도 있을듯함) 
			SELECT MAX(A.DL_EXPD_MDL_MDY_CD)
			INTO P_DL_EXPD_MDL_MDY_CD
			FROM TB_PDI_IV_INFO A,
				 TB_DL_EXPD_MDY_MGMT B
		    WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
			AND A.DL_EXPD_MDL_MDY_CD = B.DL_EXPD_MDL_MDY_CD
		    AND A.CLS_YMD <= P_CLS_YMD
		    AND B.QLTY_VEHL_CD = P_VEHL_CD
			AND B.MDL_MDY_CD = P_MDL_MDY_CD
			AND B.DL_EXPD_REGN_CD = V_DL_EXPD_REGN_CD 
			AND A.LANG_CD = P_LANG_CD;
			
			IF P_DL_EXPD_MDL_MDY_CD IS NOT NULL THEN
			   
			   SELECT MAX(N_PRNT_PBCN_NO)
			   INTO P_N_PRNT_PBCN_NO
			   FROM TB_PDI_IV_INFO
			   WHERE QLTY_VEHL_CD = P_VEHL_CD
			   AND DL_EXPD_MDL_MDY_CD = P_DL_EXPD_MDL_MDY_CD
			   AND LANG_CD = P_LANG_CD
			   AND CLS_YMD <= P_CLS_YMD;
  			
			--PDI에 한번도 입고되지 않은 항목에 대해서는 세화재고에 데이터가 존재하는 내역을 이용하도록 한다. 
			ELSE
			   
			   --현재는 무조건 가장 최근(큰) 연식을 가져오도록 처리함 
			   --(필요에 따라 현재의 차종연식과 같은 연식이 있으면 그것을 가져오도록 변경할 여지도 있을듯함) 
			   SELECT MAX(A.DL_EXPD_MDL_MDY_CD)
			   INTO P_DL_EXPD_MDL_MDY_CD
			   FROM TB_SEWHA_IV_INFO A,
				    TB_DL_EXPD_MDY_MGMT B
			   WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
			   AND A.DL_EXPD_MDL_MDY_CD = B.DL_EXPD_MDL_MDY_CD
			   AND A.CLS_YMD <= P_CLS_YMD
			   --인쇄중인 항목은 제외하고.... 납품되었던 항목만을 조회한다. 
			   AND A.DL_EXPD_TMP_IV_QTY = 0
			   AND B.QLTY_VEHL_CD = P_VEHL_CD
			   AND B.MDL_MDY_CD = P_MDL_MDY_CD				   
			   AND B.DL_EXPD_REGN_CD = V_DL_EXPD_REGN_CD 
			   AND A.LANG_CD = P_LANG_CD;	
			   
			   IF P_DL_EXPD_MDL_MDY_CD IS NOT NULL THEN
				   	  
			       SELECT MAX(N_PRNT_PBCN_NO)
				   INTO P_N_PRNT_PBCN_NO
				   FROM TB_SEWHA_IV_INFO
				   WHERE QLTY_VEHL_CD = P_VEHL_CD
				   AND DL_EXPD_MDL_MDY_CD = P_DL_EXPD_MDL_MDY_CD
				   AND LANG_CD = P_LANG_CD
				   AND CLS_YMD <= P_CLS_YMD
				   --인쇄중인 항목은 제외하고.... 납품되었던 항목만을 조회한다. 
				   AND DL_EXPD_TMP_IV_QTY = 0;
					  
			   END IF;
					  
			END IF;
			
			IF P_N_PRNT_PBCN_NO IS NOT NULL THEN
			   	  
			    SELECT COUNT(*)
				INTO V_CNT
				FROM TB_PDI_IV_INFO
				WHERE QLTY_VEHL_CD = P_VEHL_CD
				AND DL_EXPD_MDL_MDY_CD = P_DL_EXPD_MDL_MDY_CD
				AND LANG_CD = P_LANG_CD
				AND CLS_YMD = P_CLS_YMD
				AND N_PRNT_PBCN_NO = P_N_PRNT_PBCN_NO;
				  
				IF V_CNT = 0 THEN
				  	 
				    INSERT INTO TB_PDI_IV_INFO
					(CLS_YMD,
			 		 QLTY_VEHL_CD,
			 		 DL_EXPD_MDL_MDY_CD,
			 		 LANG_CD,
			 		 N_PRNT_PBCN_NO,
			 		 IV_QTY,
			 		 CMPL_YN,
			 		 PPRR_EENO,
			 		 FRAM_DTM,
			 		 UPDR_EENO,
			 		 MDFY_DTM,
					 TMP_TRTM_YN
					)
					VALUES
					(P_CLS_YMD,
					 P_VEHL_CD,
					 P_DL_EXPD_MDL_MDY_CD,
					 P_LANG_CD,
					 P_N_PRNT_PBCN_NO,
					 0,
					 CASE WHEN P_CLS_YMD = TO_CHAR(SYSDATE, 'YYYYMMDD') THEN 'N' ELSE 'Y' END,
					 'SYSTEM',
					 SYSDATE,
					 'SYSTEM',
					 SYSDATE,
					 --임시 생성하는 데이터란 정보를 표시하여 준다. 
					 'Y'
					);

				END IF;
				
				--재고상세 내역에는 별도로 추가해 주지 않아도 된다. 
				--(왜냐하면 배치 실행시 임시 재고 데이터 생성 후 보정작업이 자동으로 이루어 지기 때문이다.) 

			END IF;
			   
	   END SP_GET_PDI_N_PRNT_PBCN_NO;
/**********************************************************/	


/**********************************************************/	
	   --이미 재고데이터가 이전 날짜에 소진된 항목에 대해서 
	   --인자로 주어진 날짜의 재고 데이터를 새로이 생성해 주는 작업 수행
	   PROCEDURE SP_REMAKE_SEWHA_IV_INFO(P_DATA_SN_LIST VARCHAR2,
			  					         P_CURR_YMD     VARCHAR2,
								         P_SYST_YMD	    VARCHAR2,
										 P_USER_EENO    VARCHAR2)
	   IS
	   	 
		 V_CNT       NUMBER;
		  
		 V_DATA_SN_LIST PG_COMMON.LIST_TYPE;
		  
		 V_DATA_SN_CNT  BINARY_INTEGER;
		 
		 V_QLTY_VEHL_CD VARCHAR2(4);
		 V_MDL_MDY_CD	VARCHAR2(4);
		 V_LANG_CD		VARCHAR2(4);
		 
--		 V_CLS_YMD		      VARCHAR2(8);
		 V_DL_EXPD_MDL_MDY_CD VARCHAR2(2);
		 V_N_PRNT_PBCN_NO	  VARCHAR2(100);
		 
		 V_DL_EXPD_REGN_CD	  VARCHAR2(4);
		 
	   BEGIN
	   		
			/** 
			--작성일이 현재일자가 아니면 생성해 주지 않는다. 
			IF P_CURR_YMD <> P_SYST_YMD THEN 
			   
			   RETURN;
			   
			END IF;
			**/ 
			
			V_DATA_SN_LIST := PG_COMMON.FU_SPLIT(P_DATA_SN_LIST, V_DATA_SN_CNT);
			
			--체크리스트 상세정보에서 현재 차종에 발간번호가 설정되지 않은 항목을 삭제한다. 
		  	FOR DATA_SN_NUM IN 1..V_DATA_SN_CNT LOOP
		    	
				SELECT QLTY_VEHL_CD,
					   MDL_MDY_CD,
					   LANG_CD,
					   DL_EXPD_REGN_CD
				INTO V_QLTY_VEHL_CD,
				     V_MDL_MDY_CD,
					 V_LANG_CD,
					 V_DL_EXPD_REGN_CD
				FROM TB_LANG_MGMT
				WHERE DATA_SN = TO_NUMBER(V_DATA_SN_LIST(DATA_SN_NUM));
				
				/*** [변경] TB_SEWHA_IV_INFO 테이블이 아니라 TB_SEWHA_IV_INFO_DTL 테이블에서 조회하는 것으로 변경 
				            왜냐하면 이곳에서는 즉시 재고 재계산 작업이 이루어지지 않기 때문에 TB_SEWHA_IV_INFO_DTL 테이블에 
							직접 써주어야 하기 때문이다. 
				 
				SELECT COUNT(*)
				INTO V_CNT
				FROM TB_SEWHA_IV_INFO A,
				     TB_DL_EXPD_MDY_MGMT B 
				WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD 
				AND A.DL_EXPD_MDL_MDY_CD = B.DL_EXPD_MDL_MDY_CD 
				AND A.CLS_YMD = P_CURR_YMD
				--인쇄중인 항목은 제외하고.... 납품되었던 항목만을 조회한다. 
				AND A.DL_EXPD_TMP_IV_QTY = 0 
				AND B.QLTY_VEHL_CD = V_QLTY_VEHL_CD 
				AND B.MDL_MDY_CD = V_MDL_MDY_CD 
--[수정예정] 나중에 주석 제거해 줄 것				
				--AND B.DL_EXPD_REGN_CD = V_DL_EXPD_REGN_CD 
				AND A.LANG_CD = V_LANG_CD; 
				***/
				
				SELECT COUNT(*)
				INTO V_CNT
				FROM TB_SEWHA_IV_INFO_DTL
				WHERE CLS_YMD = P_CURR_YMD
				AND QLTY_VEHL_CD = V_QLTY_VEHL_CD
				AND MDL_MDY_CD = V_MDL_MDY_CD 
				AND LANG_CD = V_LANG_CD
				--인쇄중인 항목은 제외하고.... 납품되었던 항목만을 조회한다. 
				AND DL_EXPD_TMP_IV_QTY = 0;
				
				IF V_CNT = 0 THEN
 
				   --현재는 무조건 가장 최근(큰) 연식을 가져오도록 처리함 
				   --(필요에 따라 현재의 차종연식과 같은 연식이 있으면 그것을 가져오도록 변경할 여지도 있을듯함) 
				   SELECT MAX(A.DL_EXPD_MDL_MDY_CD)
				   INTO V_DL_EXPD_MDL_MDY_CD
				   FROM TB_SEWHA_IV_INFO A,
				        TB_DL_EXPD_MDY_MGMT B
				   WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
				   AND A.DL_EXPD_MDL_MDY_CD = B.DL_EXPD_MDL_MDY_CD
				   AND A.CLS_YMD <= P_CURR_YMD
				   --인쇄중인 항목은 제외하고.... 납품되었던 항목만을 조회한다. 
				   AND A.DL_EXPD_TMP_IV_QTY = 0
				   AND B.QLTY_VEHL_CD = V_QLTY_VEHL_CD
				   AND B.MDL_MDY_CD = V_MDL_MDY_CD				   
				   AND B.DL_EXPD_REGN_CD = V_DL_EXPD_REGN_CD 
				   AND A.LANG_CD = V_LANG_CD;
				   
				   IF V_DL_EXPD_MDL_MDY_CD IS NOT NULL THEN
				   	  
					  SELECT MAX(N_PRNT_PBCN_NO)
				   	  INTO V_N_PRNT_PBCN_NO
				   	  FROM TB_SEWHA_IV_INFO
					  WHERE QLTY_VEHL_CD = V_QLTY_VEHL_CD
					  AND DL_EXPD_MDL_MDY_CD = V_DL_EXPD_MDL_MDY_CD
					  AND LANG_CD = V_LANG_CD
					  AND CLS_YMD <= P_CURR_YMD
					  --인쇄중인 항목은 제외하고.... 납품되었던 항목만을 조회한다. 
				   	  AND DL_EXPD_TMP_IV_QTY = 0;
					  
					  IF V_N_PRNT_PBCN_NO IS NOT NULL THEN
						  
						  SELECT COUNT(*)
						  INTO V_CNT
						  FROM TB_SEWHA_IV_INFO
						  WHERE CLS_YMD = P_CURR_YMD
						  AND QLTY_VEHL_CD = V_QLTY_VEHL_CD
						  AND DL_EXPD_MDL_MDY_CD = V_DL_EXPD_MDL_MDY_CD
						  AND LANG_CD = V_LANG_CD
						  AND N_PRNT_PBCN_NO = V_N_PRNT_PBCN_NO;
						  
						  IF V_CNT = 0 THEN
						  	 
							 INSERT INTO TB_SEWHA_IV_INFO
						     (CLS_YMD,
						   	  QLTY_VEHL_CD,
						   	  DL_EXPD_MDL_MDY_CD,
						   	  LANG_CD,
						      N_PRNT_PBCN_NO,
						   	  IV_QTY,
						   	  DL_EXPD_TMP_IV_QTY,
						   	  CMPL_YN,
						   	  PPRR_EENO,
						   	  FRAM_DTM,
						   	  UPDR_EENO,
						   	  MDFY_DTM,
						   	  TMP_TRTM_YN
						     )
						  	 VALUES
							 (P_CURR_YMD,
							  V_QLTY_VEHL_CD,
							  V_DL_EXPD_MDL_MDY_CD,
							  V_LANG_CD,
							  V_N_PRNT_PBCN_NO,
							  0,
							  0,
							  CASE WHEN P_CURR_YMD = P_SYST_YMD THEN 'N' ELSE 'Y' END,
							  P_USER_EENO,
							  SYSDATE,
							  P_USER_EENO,
							  SYSDATE,
							  --임시 생성하는 데이터란 정보를 표시하여 준다. 
							  'Y'
							 );
							 
						  END IF;
						  
						  --재고상세 내역에도 데이터를 추가해 준다. 
						  --(재고보정작업이 자동으로 이루어지지 않기 때문에 재고상세 내역에도 데이터를 추가해 주는 것이다.) 

						  SELECT COUNT(*)
						  INTO V_CNT
						  FROM TB_SEWHA_IV_INFO_DTL
						  WHERE CLS_YMD = P_CURR_YMD
						  AND QLTY_VEHL_CD = V_QLTY_VEHL_CD
						  AND MDL_MDY_CD = V_MDL_MDY_CD
						  AND LANG_CD = V_LANG_CD
						  AND DL_EXPD_MDL_MDY_CD = V_DL_EXPD_MDL_MDY_CD
						  AND N_PRNT_PBCN_NO = V_N_PRNT_PBCN_NO;
						  
						  IF V_CNT = 0 THEN
						  	 
							 INSERT INTO TB_SEWHA_IV_INFO_DTL
							 (CLS_YMD,
							  QLTY_VEHL_CD,
							  MDL_MDY_CD,
							  LANG_CD,
							  DL_EXPD_MDL_MDY_CD,
							  N_PRNT_PBCN_NO,
							  IV_QTY,
							  SFTY_IV_QTY,
							  DL_EXPD_TMP_IV_QTY,
							  CMPL_YN,
							  PPRR_EENO,
							  FRAM_DTM,
							  UPDR_EENO,
							  MDFY_DTM,
							  TMP_TRTM_YN
							 )
							 VALUES
							 (P_CURR_YMD,
							  V_QLTY_VEHL_CD,
							  V_MDL_MDY_CD,
							  V_LANG_CD,
							  V_DL_EXPD_MDL_MDY_CD,
							  V_N_PRNT_PBCN_NO,
							  0,
							  0,
							  0,
							  CASE WHEN P_CURR_YMD = P_SYST_YMD THEN 'N' ELSE 'Y' END,
							  P_USER_EENO,
							  SYSDATE,
							  P_USER_EENO,
							  SYSDATE,
							  --임시 생성하는 데이터란 정보를 표시하여 준다. 
							  'Y'
							 );
							 
						  END IF;
						  
					   END IF;
 
				   END IF;

				END IF;

			END LOOP;
			
	   END SP_REMAKE_SEWHA_IV_INFO;
/**********************************************************/
/**********************************************************/
       --세화 재고정보 Insert(세화 입고) 
	   PROCEDURE SP_SEWHA_IV_INFO_SAVE_BY_WHSN(P_WHSN_YMD        VARCHAR2,
			  						           P_QLTY_VEHL_CD    VARCHAR2,
											   P_MDL_MDY_CD	     VARCHAR2,
									           P_LANG_CD         VARCHAR2,
											   P_EXPD_MDL_MDY_CD VARCHAR2,
									           P_N_PRNT_PBCN_NO  VARCHAR2,
									           P_WHSN_QTY        NUMBER,
									           --P_CRGR_EENO       VARCHAR2,
									           --P_PRNT_PARR_YMD   VARCHAR2,
									           P_DLVG_PARR_YMD   VARCHAR2,
									           P_USER_EENO       VARCHAR2)
	   IS
	   BEGIN
	   		
			--재고정보 테이블에 데이터 Insert 
			INSERT INTO TB_SEWHA_IV_INFO
			(CLS_YMD,
			 QLTY_VEHL_CD,
			 DL_EXPD_MDL_MDY_CD,
			 LANG_CD,
			 N_PRNT_PBCN_NO,
			 IV_QTY,
			 DL_EXPD_TMP_IV_QTY,
			 CMPL_YN,
			 PPRR_EENO,
			 FRAM_DTM,
			 UPDR_EENO,
			 MDFY_DTM
			)
			VALUES
			(P_WHSN_YMD,
			 P_QLTY_VEHL_CD,
			 P_EXPD_MDL_MDY_CD,
			 P_LANG_CD,
			 P_N_PRNT_PBCN_NO,
			 P_WHSN_QTY,
			 CASE WHEN P_WHSN_YMD >= P_DLVG_PARR_YMD THEN 0 ELSE P_WHSN_QTY END,
			 'N',
			 P_USER_EENO,
			 SYSDATE,
			 P_USER_EENO,
			 SYSDATE
			);
			
			--현재의 입고 내역을 재고상세 테이블에 저장한다.
			SP_UPDATE_SEWHA_IV_DTL_INFO(P_QLTY_VEHL_CD,
			  						    P_EXPD_MDL_MDY_CD,
									    P_LANG_CD,
									    P_N_PRNT_PBCN_NO,
									    P_WHSN_YMD,
										P_USER_EENO);
			
			--입고내역에 대한 재고상세 테이블 재계산 작업 수행 							
		    SP_RECALCULATE_SEWHA_IV_DTL4(P_WHSN_YMD,
										 P_QLTY_VEHL_CD,
									     P_LANG_CD,
										 P_USER_EENO);										
			
	   END SP_SEWHA_IV_INFO_SAVE_BY_WHSN;
/**********************************************************/
/**********************************************************/
       --세화 재고정보 취소 수행(세화 입고)  						  
	   PROCEDURE SP_SEWHA_IV_INFO_CANCL_BY_WHSN(P_WHSN_YMD        VARCHAR2,
			  						       	  	P_QLTY_VEHL_CD    VARCHAR2,
									       	  	P_MDL_MDY_CD	  VARCHAR2,
									       	  	P_LANG_CD         VARCHAR2,
												P_EXPD_MDL_MDY_CD VARCHAR2,
									       	  	P_N_PRNT_PBCN_NO  VARCHAR2,
									       	  	--P_WHSN_QTY        NUMBER,
									       	  	P_USER_EENO       VARCHAR2)
	   IS
	   	 
		 V_FROM_YMD VARCHAR2(8);
		 V_TO_YMD	VARCHAR2(8);
		 
		 V_FROM_DATE DATE;
		 V_TO_DATE   DATE;
		 V_CNT		 NUMBER;
		 
		 V_CURR_DATE DATE;
		 V_CURR_YMD	 VARCHAR2(8);
		 
	   BEGIN
	   		
			SELECT MIN(CLS_YMD),
				   MAX(CLS_YMD)
			INTO V_FROM_YMD,
				 V_TO_YMD
			FROM TB_SEWHA_IV_INFO
			WHERE QLTY_VEHL_CD = P_QLTY_VEHL_CD
		   	AND DL_EXPD_MDL_MDY_CD = P_EXPD_MDL_MDY_CD
		   	AND LANG_CD = P_LANG_CD
		   	AND N_PRNT_PBCN_NO = P_N_PRNT_PBCN_NO;
			
	   		--입고일 이후의 모든 재고정보를 삭제한다. 
			DELETE FROM TB_SEWHA_IV_INFO
			WHERE QLTY_VEHL_CD = P_QLTY_VEHL_CD
		   	AND DL_EXPD_MDL_MDY_CD = P_EXPD_MDL_MDY_CD
		   	AND LANG_CD = P_LANG_CD
		   	AND N_PRNT_PBCN_NO = P_N_PRNT_PBCN_NO;
			
			--재고상세 정보도 역시 삭제한다.
			DELETE FROM TB_SEWHA_IV_INFO_DTL
			WHERE QLTY_VEHL_CD = P_QLTY_VEHL_CD
		   	AND DL_EXPD_MDL_MDY_CD = P_EXPD_MDL_MDY_CD
		   	AND LANG_CD = P_LANG_CD
		   	AND N_PRNT_PBCN_NO = P_N_PRNT_PBCN_NO;
			
			--삭제내역에 대한 재고상세 테이블 재계산 작업 수행 
			IF V_FROM_YMD IS NOT NULL AND 
			   V_TO_YMD IS NOT NULL THEN
			   
			   V_FROM_DATE := TO_DATE(V_FROM_YMD, 'YYYYMMDD');
			   V_TO_DATE   := TO_DATE(V_TO_YMD, 'YYYYMMDD');
			   
			   V_CNT := ROUND(V_TO_DATE - V_FROM_DATE);
				
			   FOR NUM IN 0..V_CNT LOOP
			   	   
				  V_CURR_DATE := V_FROM_DATE + NUM;
				  V_CURR_YMD  := TO_CHAR(V_CURR_DATE, 'YYYYMMDD');
				  
				  SP_RECALCULATE_SEWHA_IV_DTL4(V_CURR_YMD,
										 	   P_QLTY_VEHL_CD,
			  						     	   P_LANG_CD,
										 	   P_USER_EENO);  
			   END LOOP;
			   					 
			END IF;

	   END SP_SEWHA_IV_INFO_CANCL_BY_WHSN;
/**********************************************************/
/**********************************************************/
       --세화 납품예정일 변경 
	   PROCEDURE SP_SEWHA_DLVG_PARR_YMD_UPDATE(P_WHSN_YMD        VARCHAR2,
			  								   P_VEHL_CD         VARCHAR2,
											   P_MDL_MDY_CD	     VARCHAR2,
									           P_LANG_CD         VARCHAR2,
											   P_EXPD_MDL_MDY_CD VARCHAR2,
									           P_N_PRNT_PBCN_NO  VARCHAR2,
											   P_DLVG_PARR_YMD   VARCHAR2,
										       P_USER_EENO       VARCHAR2)
	   IS
	   BEGIN
	   		
			--재고 테이블의 인쇄중 수량 정보를 업데이트 해 준다. 
			UPDATE TB_SEWHA_IV_INFO
			SET DL_EXPD_TMP_IV_QTY = CASE WHEN CLS_YMD < P_DLVG_PARR_YMD THEN DL_EXPD_TMP_IV_QTY ELSE 0 END,
			    UPDR_EENO = P_USER_EENO,
				MDFY_DTM = SYSDATE
			WHERE QLTY_VEHL_CD = P_VEHL_CD
			AND DL_EXPD_MDL_MDY_CD = P_EXPD_MDL_MDY_CD
			AND LANG_CD = P_LANG_CD
			AND N_PRNT_PBCN_NO = P_N_PRNT_PBCN_NO
			AND CLS_YMD >= P_WHSN_YMD;
			
			--재고 상세 테이블의 인쇄중 수량 정보 역시 업데이트 해 준다. 
			UPDATE TB_SEWHA_IV_INFO_DTL
			SET DL_EXPD_TMP_IV_QTY = CASE WHEN CLS_YMD < P_DLVG_PARR_YMD THEN DL_EXPD_TMP_IV_QTY ELSE 0 END,
			    UPDR_EENO = P_USER_EENO,
				MDFY_DTM = SYSDATE
			WHERE QLTY_VEHL_CD = P_VEHL_CD
			AND DL_EXPD_MDL_MDY_CD = P_EXPD_MDL_MDY_CD
			AND LANG_CD = P_LANG_CD
			AND N_PRNT_PBCN_NO = P_N_PRNT_PBCN_NO
			AND CLS_YMD >= P_WHSN_YMD;
			
	   END SP_SEWHA_DLVG_PARR_YMD_UPDATE;
/**********************************************************/																				  											
/**********************************************************/
       --세화 재고정보 업데이트 수행 
	   PROCEDURE SP_SEWHA_IV_INFO_UPDATE(P_VEHL_CD         VARCHAR2,
	   			 					     P_MDL_MDY_CD	   VARCHAR2,
									     P_LANG_CD         VARCHAR2,
										 P_EXPD_MDL_MDY_CD VARCHAR2,
									     P_N_PRNT_PBCN_NO  VARCHAR2,
									     P_CLS_YMD		   VARCHAR2,
									     P_DIFF_RQ_QTY	   NUMBER,
									     P_USER_EENO	   VARCHAR2,
										 P_FLAG			   VARCHAR2)
       IS
	   	 
		 V_QTY		   NUMBER;
		 V_DIFF_RQ_QTY NUMBER;
		 
		 V_DEEI1_QTY   NUMBER;
		 
	   BEGIN
	   		
	   		SELECT NVL(SUM(IV_QTY), 0),
				   NVL(SUM(DEEI1_QTY), 0)
			INTO V_QTY,
				 V_DEEI1_QTY
			FROM TB_SEWHA_IV_INFO
			WHERE CLS_YMD = P_CLS_YMD
			AND QLTY_VEHL_CD = P_VEHL_CD
			AND DL_EXPD_MDL_MDY_CD = P_EXPD_MDL_MDY_CD
			AND LANG_CD = P_LANG_CD
			AND N_PRNT_PBCN_NO = P_N_PRNT_PBCN_NO
			AND CMPL_YN = 'N';

			--입고확인시의 재고보정인 경우 
			--입고확인작업은 수정기능이 없고, 수량이 증가만 되고 감소가 되지 않으므로  
			--재고수량보다 출고요청수량이 큰지의 여부만을 확인해 주면 된다. 
			IF P_FLAG = 'Y' THEN
			 
			   IF V_QTY < P_DIFF_RQ_QTY THEN 
					   
				  --출고요청된 데이터의 경우 재고가 없거나 출고수량이 재고수량보다 큰 경우에도 출고가 될수 있도록 
			   	  --처리해 달라는 요청에 따라서 아래와 같은 조건 검사 부분을 추가함(재고수량보다 출고수량이 큰 경우 재고수량을 0으로 설정해 준다.)
				  V_DIFF_RQ_QTY := V_QTY;
				  
				  --입고확인시에만 사용되므로 기존의 초과,부족 수량에 신규 부족수량을 더해 주면 된다. 
				  V_DEEI1_QTY   := V_DEEI1_QTY + (P_DIFF_RQ_QTY - V_QTY);
			   
			   ELSE
			      
				  V_DIFF_RQ_QTY := P_DIFF_RQ_QTY;
				  
			   END IF;
			   
			   --현재 날짜에 재고 데이터가 존재하지 않더라도 예외발생 없이 그대로 진행하도록 한다.
			   UPDATE TB_SEWHA_IV_INFO
			   SET IV_QTY = (IV_QTY - V_DIFF_RQ_QTY),
				   UPDR_EENO = P_USER_EENO,
				   MDFY_DTM = SYSDATE,
				   DEEI1_QTY = CASE WHEN V_DEEI1_QTY > 0 THEN V_DEEI1_QTY ELSE NULL END
			   WHERE CLS_YMD = P_CLS_YMD
			   AND QLTY_VEHL_CD = P_VEHL_CD
			   AND DL_EXPD_MDL_MDY_CD = P_EXPD_MDL_MDY_CD
			   AND LANG_CD = P_LANG_CD
			   AND N_PRNT_PBCN_NO = P_N_PRNT_PBCN_NO
			   AND CMPL_YN = 'N'; --이전날짜의 데이터인 경우에는 입력이 되지 않도록 한다.. 
			   
			   --재고 데이터가 없어서 입력이 되지 않은 경우에는 0 으로 추가해 준다. 
			   IF SQL%NOTFOUND THEN
			   	  
				  INSERT INTO TB_SEWHA_IV_INFO
				  (CLS_YMD,
			 	   QLTY_VEHL_CD,
			 	   DL_EXPD_MDL_MDY_CD,
			 	   LANG_CD,
			 	   N_PRNT_PBCN_NO,
			 	   IV_QTY,
			 	   DL_EXPD_TMP_IV_QTY,
			 	   CMPL_YN,
			 	   PPRR_EENO,
			 	   FRAM_DTM,
			 	   UPDR_EENO,
			 	   MDFY_DTM,
				   TMP_TRTM_YN,
				   DEEI1_QTY
			      )
				  VALUES(P_CLS_YMD,
					     P_VEHL_CD,
						 P_EXPD_MDL_MDY_CD,
						 P_LANG_CD,
						 P_N_PRNT_PBCN_NO,
						 0,
						 0,
						 'N',
						 P_USER_EENO,
						 SYSDATE,
						 P_USER_EENO,
						 SYSDATE,
						 --재고 데이터가 0 이므로 임시생성된다는 표시를 해준다. 
						 'Y',
						 CASE WHEN V_DEEI1_QTY > 0 THEN V_DEEI1_QTY ELSE NULL END
					    );	  
			   END IF;
			   
			--별도요청 관련 재고보정인 경우 	
			ELSE
				
				--재고수량이 출고수량보다 작은 경우에는 출고 하지 못한다. 
				IF V_QTY < P_DIFF_RQ_QTY THEN
			   
			   	   RAISE_APPLICATION_ERROR(-20001, 'Invalid sewon inventory quantity ' || 
			   								       'date:' || TO_CHAR(TO_DATE(P_CLS_YMD, 'YYYYMMDD'), 'YYYY-MM-DD') || ',' ||
											       'vehl:' || P_VEHL_CD || ',' || 
											       'mkyr:' || P_EXPD_MDL_MDY_CD || ',' || 
											       'lang:' || P_LANG_CD || ',' || P_N_PRNT_PBCN_NO || ',' ||
											       'qty :' || TO_CHAR(P_DIFF_RQ_QTY));
											   
			    END IF;
				
				UPDATE TB_SEWHA_IV_INFO
				SET IV_QTY = (IV_QTY - P_DIFF_RQ_QTY),
					UPDR_EENO = P_USER_EENO,
					MDFY_DTM = SYSDATE
			    WHERE CLS_YMD = P_CLS_YMD
			    AND QLTY_VEHL_CD = P_VEHL_CD
			    AND DL_EXPD_MDL_MDY_CD = P_EXPD_MDL_MDY_CD
			    AND LANG_CD = P_LANG_CD
			    AND N_PRNT_PBCN_NO = P_N_PRNT_PBCN_NO
			    AND CMPL_YN = 'N'; --이전날짜의 데이터인 경우에는 입력이 되지 않도록 한다.. 
			
			    IF SQL%NOTFOUND THEN
			   
			       RAISE_APPLICATION_ERROR(-20001, 'Invalid input value ' || 
			   								       'date:' || TO_CHAR(TO_DATE(P_CLS_YMD, 'YYYYMMDD'), 'YYYY-MM-DD') || ',' ||
											       'vehl:' || P_VEHL_CD || ',' || 
											       'mkyr:' || P_EXPD_MDL_MDY_CD || ',' || 
											       'lang:' || P_LANG_CD || ',' || P_N_PRNT_PBCN_NO);
			   
			    END IF;
			
			END IF;
			
			--현재의 출고 내역을 재고상세 테이블에 저장한다.
			SP_UPDATE_SEWHA_IV_DTL_INFO(P_VEHL_CD,
			  						    P_EXPD_MDL_MDY_CD,
									    P_LANG_CD,
									    P_N_PRNT_PBCN_NO,
									    P_CLS_YMD,
										P_USER_EENO);

			--출고 내역에 대한 재고상세 테이블 재계산 작업 수행 							
		    SP_RECALCULATE_SEWHA_IV_DTL4(P_CLS_YMD,
										 P_VEHL_CD,
									     P_LANG_CD,
										 P_USER_EENO);		

	   END SP_SEWHA_IV_INFO_UPDATE;	
/**********************************************************/
/**********************************************************/
       --PDI 재고보정(반출, 불량)시에 세화재고 업데이트 작업 수행 									  
	   PROCEDURE SP_SEWHA_IV_INFO_UPDATE2(P_VEHL_CD         VARCHAR2,
	   			 					      P_MDL_MDY_CD	    VARCHAR2,
									      P_LANG_CD         VARCHAR2,
										  P_EXPD_MDL_MDY_CD VARCHAR2,
									      P_N_PRNT_PBCN_NO  VARCHAR2,
									      P_CLS_YMD		    VARCHAR2,
									      P_DIFF_RQ_QTY	    NUMBER,
									      P_CASCADE_FLAG	VARCHAR2, --현재일 이전날짜의 재고보정 허용 여부 
									      P_USER_EENO		VARCHAR2)
	   IS
	   
		 V_CNT		 NUMBER;
		 
		 V_FROM_DATE DATE;
		 V_TO_DATE   DATE;
		 
		 V_CURR_DATE DATE;
		 
		 V_QTY		 NUMBER;
		 
		 V_CURR_YMD	 VARCHAR2(8);
		 
	   BEGIN
	   		
			IF P_CASCADE_FLAG = 'N' THEN
			   
			   SELECT NVL(SUM(IV_QTY), 0)
			   INTO V_QTY
			   FROM TB_SEWHA_IV_INFO
			   WHERE CLS_YMD = P_CLS_YMD
			   AND QLTY_VEHL_CD = P_VEHL_CD
			   AND DL_EXPD_MDL_MDY_CD = P_EXPD_MDL_MDY_CD
			   AND LANG_CD = P_LANG_CD
			   AND N_PRNT_PBCN_NO = P_N_PRNT_PBCN_NO
			   AND CMPL_YN = 'N';
			   
			   --세화재고는 - 값이 있을수 없다....
			   IF (V_QTY - P_DIFF_RQ_QTY) < 0 THEN
			   	  
				  RAISE_APPLICATION_ERROR(-20001, 'Invalid sewon inventory quantity ' || 
			   								      'date:' || TO_CHAR(TO_DATE(P_CLS_YMD, 'YYYYMMDD'), 'YYYY-MM-DD') || ',' ||
											      'vehl:' || P_VEHL_CD || ',' || 
											      'mkyr:' || P_EXPD_MDL_MDY_CD || ',' || 
											      'lang:' || P_LANG_CD || ',' || P_N_PRNT_PBCN_NO || ',' ||
											      'qty :' || TO_CHAR(P_DIFF_RQ_QTY));
											   
			   END IF;
			
			   UPDATE TB_SEWHA_IV_INFO
			   SET IV_QTY = (IV_QTY - P_DIFF_RQ_QTY),
			   	   --DEEI1_QTY = NULL,
				   UPDR_EENO = P_USER_EENO,
				   MDFY_DTM = SYSDATE
			   WHERE CLS_YMD = P_CLS_YMD
			   AND QLTY_VEHL_CD = P_VEHL_CD
			   AND DL_EXPD_MDL_MDY_CD = P_EXPD_MDL_MDY_CD
			   AND LANG_CD = P_LANG_CD
			   AND N_PRNT_PBCN_NO = P_N_PRNT_PBCN_NO
			   AND CMPL_YN = 'N'; --이전날짜의 데이터인 경우에는 입력이 되지 않도록 한다.. 
			   
			   IF SQL%NOTFOUND THEN
			   	  
				  /**  이미 재고가 소진되어 존재하지 않는 경우가 있을 수 있으므로 예외를 발생시키지 않고 
				        재고 내역에 추가를 해 준다. 
				  RAISE_APPLICATION_ERROR(-20001, 'Invalid input value ' || 
			   								      'date:' || TO_CHAR(TO_DATE(P_CLS_YMD, 'YYYYMMDD'), 'YYYY-MM-DD') || ',' ||
											      'vehl:' || P_VEHL_CD || ',' || 
											      'mkyr:' || P_EXPD_MDL_MDY_CD || ',' || 
											      'lang:' || P_LANG_CD || ',' || P_N_PRNT_PBCN_NO); 
				  **/
				  
				  --이미 세화재고가 소진되어 값이 없는 경우에는 재고에 그냥 추가해 준다. 
				  INSERT INTO TB_SEWHA_IV_INFO
				  (CLS_YMD,
			 	   QLTY_VEHL_CD,
			 	   DL_EXPD_MDL_MDY_CD,
			 	   LANG_CD,
			 	   N_PRNT_PBCN_NO,
			 	   IV_QTY,
			 	   DL_EXPD_TMP_IV_QTY,
			 	   CMPL_YN,
			 	   PPRR_EENO,
			 	   FRAM_DTM,
			 	   UPDR_EENO,
			 	   MDFY_DTM,
				   TMP_TRTM_YN
			      )
				  VALUES(P_CLS_YMD,
					     P_VEHL_CD,
						 P_EXPD_MDL_MDY_CD,
						 P_LANG_CD,
						 P_N_PRNT_PBCN_NO,
						 -- P_DIFF_RQ_QTY 가 - 로 들어오기 때문에 이때는 -1을 곱해주어야 한다. 
						 P_DIFF_RQ_QTY * (-1),
						 0,
						 'N',
						 P_USER_EENO,
						 SYSDATE,
						 P_USER_EENO,
						 SYSDATE,
						 ----재고 데이터가 0이 아니라면 임시생성여부를 NULL 로 설정해 주고 그렇지 않으면 'Y'로 해준다.
						 --CASE WHEN P_DIFF_RQ_QTY <> 0 THEN NULL ELSE 'Y' END 
						 --[변경]재고보정에 의해서 임시 생성된 데이터이므로 무조건 'Y' 로 설정해 준다.
						 'Y'
					    );	  
			
			   END IF;
			   
			   --현재의 재고보정 내역을 재고상세 테이블에 저장한다.
			   SP_UPDATE_SEWHA_IV_DTL_INFO(P_VEHL_CD,
			  						       P_EXPD_MDL_MDY_CD,
									       P_LANG_CD,
									       P_N_PRNT_PBCN_NO,
									       P_CLS_YMD,
										   P_USER_EENO);
			   
			   --재고보정 내역에 대한 재고상세 테이블 재계산 작업 수행 							
		       SP_RECALCULATE_SEWHA_IV_DTL4(P_CLS_YMD,
										    P_VEHL_CD,
									     	P_LANG_CD,
										 	P_USER_EENO);

			ELSE
				
				--현재는 가장 최근의 재고내역만 수정하므로 아무런 작업을 수행하지 않는다. 
				--(현재일 이전의 재고보정 기능은 현재 지원해 주지 않는다.) 
				   
				RETURN;
				
				/***
				V_FROM_DATE := TO_DATE(P_CLS_YMD, 'YYYYMMDD');
				V_TO_DATE   := TO_DATE(TO_CHAR(SYSDATE, 'YYYYMMDD'), 'YYYYMMDD');
				
				V_CNT := ROUND(V_TO_DATE - V_FROM_DATE);
				
				FOR NUM IN 0..V_CNT LOOP 
					
					V_CURR_DATE := V_FROM_DATE + NUM;
					V_CURR_YMD  := TO_CHAR(V_CURR_DATE, 'YYYYMMDD');
					
					SELECT NVL(SUM(IV_QTY), 0)
			   		INTO V_QTY
			   		FROM TB_SEWHA_IV_INFO
			   		WHERE CLS_YMD = V_CURR_YMD
			   		AND QLTY_VEHL_CD = P_VEHL_CD
			   		AND DL_EXPD_MDL_MDY_CD = P_EXPD_MDL_MDY_CD
			   		AND LANG_CD = P_LANG_CD
			   		AND N_PRNT_PBCN_NO = P_N_PRNT_PBCN_NO;
					   
					--세화재고는 - 값이 있을수 없다....
					IF (V_QTY - P_DIFF_RQ_QTY) < 0 THEN
			   	  
				  	   RAISE_APPLICATION_ERROR(-20001, 'Invalid sewon inventory quantity ' || 
			   								           'date:' || TO_CHAR(TO_DATE(P_CLS_YMD, 'YYYYMMDD'), 'YYYY-MM-DD') || ',' ||
											           'vehl:' || P_VEHL_CD || ',' || 
											           'mkyr:' || P_EXPD_MDL_MDY_CD || ',' || 
											           'lang:' || P_LANG_CD || ',' || P_N_PRNT_PBCN_NO || ',' ||
											           'qty :' || TO_CHAR(P_DIFF_RQ_QTY));
											   
			       END IF;
					
					UPDATE TB_SEWHA_IV_INFO
			   		SET IV_QTY = (IV_QTY - P_DIFF_RQ_QTY),
						--DEEI1_QTY = NULL, 
						UPDR_EENO = P_USER_EENO,
						MDFY_DTM = SYSDATE
			   	    WHERE CLS_YMD = V_CURR_YMD
			   		AND QLTY_VEHL_CD = P_VEHL_CD
			   		AND DL_EXPD_MDL_MDY_CD = P_EXPD_MDL_MDY_CD
			   		AND LANG_CD = P_LANG_CD
			   		AND N_PRNT_PBCN_NO = P_N_PRNT_PBCN_NO; 
			   		
					IF SQL%NOTFOUND THEN
					   
					   --이미 세화재고가 소진되어 값이 없는 경우에는 재고에 그냥 추가해 준다. 
				  	   INSERT INTO TB_SEWHA_IV_INFO
					   (CLS_YMD,
			 	        QLTY_VEHL_CD,
			 	   		DL_EXPD_MDL_MDY_CD,
			 	   		LANG_CD,
			 	   		N_PRNT_PBCN_NO,
			 	   		IV_QTY,
			 	   		DL_EXPD_TMP_IV_QTY,
			 	   		CMPL_YN,
			 	   		PPRR_EENO,
			 	   		FRAM_DTM,
			 	   		UPDR_EENO,
			 	   		MDFY_DTM,
				   		TMP_TRTM_YN
			           )
				  	   VALUES(V_CURR_YMD,
					     	  P_VEHL_CD,
						 	  P_EXPD_MDL_MDY_CD,
						 	  P_LANG_CD,
						 	  P_N_PRNT_PBCN_NO,
						 	  -- P_DIFF_RQ_QTY 가 - 로 들어오기 때문에 이때는 -1을 곱해주어야 한다. 
						 	  P_DIFF_RQ_QTY * (-1),
						 	  0,
						 	  'N',
						 	  P_USER_EENO,
						 	  SYSDATE,
						 	  P_USER_EENO,
						 	  SYSDATE,
							  --CASE WHEN P_DIFF_RQ_QTY <> 0 THEN NULL ELSE 'Y' END 
							  --[변경]재고보정에 의해서 임시 생성된 데이터이므로 무조건 'Y' 로 설정해 준다.
						 	  'Y'
					         );	  
						
					END IF;
					
					--현재의 재고보정 내역을 재고상세 테이블에 저장한다.
					SP_UPDATE_SEWHA_IV_DTL_INFO(P_VEHL_CD,
			  						       		P_EXPD_MDL_MDY_CD,
									       		P_LANG_CD,
									       		P_N_PRNT_PBCN_NO,
									       		V_CURR_YMD,
										   		P_USER_EENO);
												
				    --재고보정 내역에 대한 재고상세 테이블 재계산 작업 수행 							
		       		SP_RECALCULATE_SEWHA_IV_DTL4(V_CURR_YMD,
										         P_VEHL_CD,
									     		 P_LANG_CD,
										 		 P_USER_EENO);				
										   
			    END LOOP;
				***/ 
				
			END IF;
			
	   END SP_SEWHA_IV_INFO_UPDATE2;
/**********************************************************/
/**********************************************************/
       --세화 재고정보 업데이트 수행(재고 저환 신규 재고 추가 기능 포함)  								   
	   PROCEDURE SP_SEWHA_IV_INFO_UPDATE3(P_VEHL_CD         VARCHAR2,
			  						   	  P_MDL_MDY_CD	    VARCHAR2,
									   	  P_LANG_CD         VARCHAR2,
									   	  P_EXPD_MDL_MDY_CD VARCHAR2,
									   	  P_N_PRNT_PBCN_NO  VARCHAR2,
									   	  P_CLS_YMD		    VARCHAR2,
									   	  P_DIFF_RQ_QTY	    NUMBER,
									   	  P_USER_EENO		VARCHAR2,
										  P_FLAG			VARCHAR2)
	   IS
	   
	   	 V_QTY		   NUMBER;
		 V_DIFF_RQ_QTY NUMBER;
		 
	   BEGIN
	   		
			SELECT NVL(SUM(IV_QTY), 0)
			INTO V_QTY
			FROM TB_SEWHA_IV_INFO
			WHERE CLS_YMD = P_CLS_YMD
			AND QLTY_VEHL_CD = P_VEHL_CD
			AND DL_EXPD_MDL_MDY_CD = P_EXPD_MDL_MDY_CD
			AND LANG_CD = P_LANG_CD
			AND N_PRNT_PBCN_NO = P_N_PRNT_PBCN_NO
			AND CMPL_YN = 'N';
			
			--재고수량이 출고수량보다 작은 경우에는 출고 하지 못한다. 
			IF V_QTY < P_DIFF_RQ_QTY THEN
			   
			   RAISE_APPLICATION_ERROR(-20001, 'Invalid sewon inventory quantity ' || 
			   								   'date:' || TO_CHAR(TO_DATE(P_CLS_YMD, 'YYYYMMDD'), 'YYYY-MM-DD') || ',' ||
											   'vehl:' || P_VEHL_CD || ',' || 
											   'mkyr:' || P_EXPD_MDL_MDY_CD || ',' || 
											   'lang:' || P_LANG_CD || ',' || P_N_PRNT_PBCN_NO || ',' ||
											   'qty :' || TO_CHAR(P_DIFF_RQ_QTY));
											   
			END IF;
				
			UPDATE TB_SEWHA_IV_INFO
			SET IV_QTY = (IV_QTY - P_DIFF_RQ_QTY),
				UPDR_EENO = P_USER_EENO,
				MDFY_DTM = SYSDATE
			WHERE CLS_YMD = P_CLS_YMD
			AND QLTY_VEHL_CD = P_VEHL_CD
			AND DL_EXPD_MDL_MDY_CD = P_EXPD_MDL_MDY_CD
			AND LANG_CD = P_LANG_CD
			AND N_PRNT_PBCN_NO = P_N_PRNT_PBCN_NO
			AND CMPL_YN = 'N'; --이전날짜의 데이터인 경우에는 입력이 되지 않도록 한다.. 
			
			IF SQL%NOTFOUND THEN
			   
			   IF P_FLAG = 'Y' THEN
			   	  
				  RAISE_APPLICATION_ERROR(-20001, 'Invalid input value ' || 
			   								   	  'date:' || TO_CHAR(TO_DATE(P_CLS_YMD, 'YYYYMMDD'), 'YYYY-MM-DD') || ',' ||
											   	  'vehl:' || P_VEHL_CD || ',' || 
											   	  'mkyr:' || P_EXPD_MDL_MDY_CD || ',' || 
											   	  'lang:' || P_LANG_CD || ',' || P_N_PRNT_PBCN_NO);
											   
			   ELSE
			   	  
				  INSERT INTO TB_SEWHA_IV_INFO
				  (CLS_YMD,
			 	   QLTY_VEHL_CD,
			 	   DL_EXPD_MDL_MDY_CD,
			 	   LANG_CD,
			 	   N_PRNT_PBCN_NO,
			 	   IV_QTY,
			 	   DL_EXPD_TMP_IV_QTY,
			 	   CMPL_YN,
			 	   PPRR_EENO,
			 	   FRAM_DTM,
			 	   UPDR_EENO,
			 	   MDFY_DTM,
				   TMP_TRTM_YN
			      )
				  VALUES(P_CLS_YMD,
					     P_VEHL_CD,
						 P_EXPD_MDL_MDY_CD,
						 P_LANG_CD,
						 P_N_PRNT_PBCN_NO,
						 -- P_DIFF_RQ_QTY 가 - 로 들어오기 때문에 이때는 -1을 곱해주어야 한다. 
						 P_DIFF_RQ_QTY * (-1),
						 0,
						 'N',
						 P_USER_EENO,
						 SYSDATE,
						 P_USER_EENO,
						 SYSDATE,
						 --재고보정에 의해서 임시 생성된 데이터이므로 무조건 'Y' 로 설정해 준다.
						 'Y'
					    );	  
				  
			   END IF;
			   
		    END IF;
	   		
			--현재의 출고 내역을 재고상세 테이블에 저장한다.
			SP_UPDATE_SEWHA_IV_DTL_INFO(P_VEHL_CD,
			  						    P_EXPD_MDL_MDY_CD,
									    P_LANG_CD,
									    P_N_PRNT_PBCN_NO,
									    P_CLS_YMD,
										P_USER_EENO);

			--출고 내역에 대한 재고상세 테이블 재계산 작업 수행 							
		    SP_RECALCULATE_SEWHA_IV_DTL4(P_CLS_YMD,
										 P_VEHL_CD,
									     P_LANG_CD,
										 P_USER_EENO);		
										 
	   END SP_SEWHA_IV_INFO_UPDATE3;
/**********************************************************/
									  

/**********************************************************/
       --입고/출고된 항목에 대한 재고상세 테이블 업데이트 작업 수행 
       PROCEDURE SP_UPDATE_PDI_IV_DTL_INFO(P_VEHL_CD         VARCHAR2,
			  						       P_EXPD_MDL_MDY_CD VARCHAR2,
									       P_LANG_CD         VARCHAR2,
									       P_N_PRNT_PBCN_NO  VARCHAR2,
									       P_CLS_YMD		 VARCHAR2,
										   P_USER_EENO	     VARCHAR2)
	   IS
	   		 
		 V_IV_QTY      NUMBER;
		 V_CNT	       NUMBER;
		 V_CMPL_YN     VARCHAR2(1);
		 V_TMP_TRTM_YN VARCHAR2(1);

	   BEGIN
			
			--재고 테이블 재고 수량 조회 
			SELECT SUM(IV_QTY),
			   	   MAX(CMPL_YN),
				   MAX(TMP_TRTM_YN)
			INTO V_IV_QTY,
			     V_CMPL_YN,
				 V_TMP_TRTM_YN
			FROM TB_PDI_IV_INFO
			WHERE CLS_YMD = P_CLS_YMD
			AND QLTY_VEHL_CD = P_VEHL_CD
			AND DL_EXPD_MDL_MDY_CD = P_EXPD_MDL_MDY_CD
			AND LANG_CD = P_LANG_CD
			AND N_PRNT_PBCN_NO = P_N_PRNT_PBCN_NO;
			
			--재고 테이블에 데이터가 존재하는 경우에 아래의 작업을 수행한다. 
			IF V_CMPL_YN IS NOT NULL THEN
			   
			   --재고상세 테이블내에 취급설명서연식으로 적용된 항목의 재고수량을 변경된 수량으로 
			   --모두 업데이트 해 준다. 
			   --단, 차종의 연식과 취급설명서의 연식이 같은 경우에만 업데이트 해준다.
			   --(왜냐하면 같은 않은 항목은 재고 상세 내역 재계산시에 우선 삭제된 뒤에 다시 계산하기 때문에 의미가 없다.)  
			   UPDATE TB_PDI_IV_INFO_DTL
			   SET IV_QTY = V_IV_QTY,
			   	   --안전재고의 수량을 재고수량과 같게 해준다.
			   	   SFTY_IV_QTY = V_IV_QTY,
			   	   CMPL_YN = V_CMPL_YN,
				   UPDR_EENO = P_USER_EENO,
				   MDFY_DTM = SYSDATE,
				   TMP_TRTM_YN = V_TMP_TRTM_YN
			   WHERE CLS_YMD = P_CLS_YMD
			   AND QLTY_VEHL_CD = P_VEHL_CD
			   --차종의 연식과 취급설명서의 연식이 같은 경우에만 업데이트 해 주도록 한다. 
			   AND MDL_MDY_CD = P_EXPD_MDL_MDY_CD
			   AND LANG_CD = P_LANG_CD
			   AND DL_EXPD_MDL_MDY_CD = P_EXPD_MDL_MDY_CD
			   AND N_PRNT_PBCN_NO = P_N_PRNT_PBCN_NO;
			   
			   IF SQL%NOTFOUND THEN
			   	  
				  INSERT INTO TB_PDI_IV_INFO_DTL
				   (CLS_YMD,
				   	QLTY_VEHL_CD,
				   	MDL_MDY_CD,
				   	LANG_CD,
				   	DL_EXPD_MDL_MDY_CD,
				   	N_PRNT_PBCN_NO,
				   	IV_QTY,
				   	SFTY_IV_QTY,
				   	CMPL_YN,
				   	PPRR_EENO,
				   	FRAM_DTM,
				   	UPDR_EENO,
				   	MDFY_DTM,
					TMP_TRTM_YN
				   )
				   VALUES
				   (P_CLS_YMD,
				   	P_VEHL_CD,
					--차종의 연식과 취급설명서의 연식을 같은 값으로 입력해 준다.(반드시 취급설명서의 연식으로 입력) 
				   	P_EXPD_MDL_MDY_CD,
				   	P_LANG_CD,
				   	P_EXPD_MDL_MDY_CD,
				   	P_N_PRNT_PBCN_NO,
				   	V_IV_QTY,
					--차종의 연식과 취급설명서의 연식이 같은 경우에는 안전재고의 수량을 재고수량과 같게 해준다.
				   	V_IV_QTY,
				   	V_CMPL_YN,
				   	P_USER_EENO,
				   	SYSDATE,
				   	P_USER_EENO,
				   	SYSDATE,
					V_TMP_TRTM_YN
				   );
				   
			   END IF;
    
			END IF;
			
	   END SP_UPDATE_PDI_IV_DTL_INFO;
/**********************************************************/
/**********************************************************/  
       --재고상세 내역 재계산 작업 수행 									
	   PROCEDURE SP_RECALCULATE_PDI_IV_DTL1(P_CLS_YMD	      VARCHAR2,
										 	P_VEHL_CD         VARCHAR2,
			  						     	P_EXPD_MDL_MDY_CD VARCHAR2,
									     	P_LANG_CD         VARCHAR2,
											P_N_PRNT_PBCN_NO  VARCHAR2,
										 	P_USER_EENO	      VARCHAR2)
	   IS
	   	 
	   BEGIN
	   			
			--취급설명서 연식과 차종연식이 다른 항목은 우선 삭제한다. 
			DELETE FROM TB_PDI_IV_INFO_DTL 
			WHERE CLS_YMD = P_CLS_YMD 
			AND QLTY_VEHL_CD = P_VEHL_CD 
			AND MDL_MDY_CD <> DL_EXPD_MDL_MDY_CD 
			AND LANG_CD = P_LANG_CD
			AND DL_EXPD_MDL_MDY_CD = P_EXPD_MDL_MDY_CD
			AND N_PRNT_PBCN_NO = P_N_PRNT_PBCN_NO;
			
			--취급설명서 연식과 차종연식이 같은 경우에는 안전재고수량을 재고수량으로 업데이트 해 준다. 
			UPDATE TB_PDI_IV_INFO_DTL 
			SET SFTY_IV_QTY = IV_QTY,
			    UPDR_EENO = P_USER_EENO,
				MDFY_DTM = SYSDATE
			WHERE CLS_YMD = P_CLS_YMD
			AND QLTY_VEHL_CD = P_VEHL_CD 
			AND MDL_MDY_CD = DL_EXPD_MDL_MDY_CD 
			AND LANG_CD = P_LANG_CD
			AND DL_EXPD_MDL_MDY_CD = P_EXPD_MDL_MDY_CD
			AND N_PRNT_PBCN_NO = P_N_PRNT_PBCN_NO;
			
			SP_RECALCULATE_PDI_IV_SUB(P_CLS_YMD,
									  P_VEHL_CD,
									  P_EXPD_MDL_MDY_CD,
									  P_LANG_CD,
									  P_N_PRNT_PBCN_NO,
									  P_USER_EENO);
		    
			--PDI 재고 재계산 작업이 이루어지면 이에 맞추어 세원 재고 재계산 작업도 이루어져야 한다. 									  
			SP_RECALCULATE_SEWHA_IV_DTL1(P_CLS_YMD,
										 P_VEHL_CD,
										 P_EXPD_MDL_MDY_CD,
										 P_LANG_CD,
										 P_N_PRNT_PBCN_NO,
										 P_USER_EENO);
			
	   END SP_RECALCULATE_PDI_IV_DTL1;											 
/**********************************************************/ 
/**********************************************************/ 
	   --재고상세 내역 재계산 작업 수행(배치 프로그램 전용) 									  
	   PROCEDURE SP_RECALCULATE_PDI_IV_DTL2(P_CLS_YMD	VARCHAR2,
										    P_USER_EENO VARCHAR2)
	   IS
	   	 
		 CURSOR PDI_IV_LIST_INFO IS SELECT QLTY_VEHL_CD,
		 						 		   DL_EXPD_MDL_MDY_CD,
		 						  	 	   LANG_CD,
										   N_PRNT_PBCN_NO
		 						  	FROM TB_PDI_IV_INFO
									--재고수량이 0보다 큰 것 보다 현재일에 존재하는 모든 항목을 해 주어야 한다.
									--AND IV_QTY > 0 
									WHERE CLS_YMD = P_CLS_YMD
									GROUP BY QLTY_VEHL_CD, LANG_CD, N_PRNT_PBCN_NO, DL_EXPD_MDL_MDY_CD
									--정렬조건을 아래와 같은 순서를 준수하여야 한다. 
									ORDER BY QLTY_VEHL_CD, LANG_CD, N_PRNT_PBCN_NO, DL_EXPD_MDL_MDY_CD;
								 
	   BEGIN
	   		
			--취급설명서 연식과 차종연식이 다른 항목은 우선 삭제한다. 
			DELETE FROM TB_PDI_IV_INFO_DTL 
			WHERE CLS_YMD = P_CLS_YMD 
			AND MDL_MDY_CD <> DL_EXPD_MDL_MDY_CD;
			
			--취급설명서 연식과 차종연식이 같은 경우에는 안전재고수량을 재고수량으로 업데이트 해 준다. 
			UPDATE TB_PDI_IV_INFO_DTL 
			SET SFTY_IV_QTY = IV_QTY,
			    UPDR_EENO = P_USER_EENO,
				MDFY_DTM = SYSDATE
			WHERE CLS_YMD = P_CLS_YMD
			AND MDL_MDY_CD = DL_EXPD_MDL_MDY_CD;
			
			FOR PDI_IV_LIST IN PDI_IV_LIST_INFO LOOP
				
				SP_RECALCULATE_PDI_IV_SUB(P_CLS_YMD,
										  PDI_IV_LIST.QLTY_VEHL_CD,
										  PDI_IV_LIST.DL_EXPD_MDL_MDY_CD,
										  PDI_IV_LIST.LANG_CD,
										  PDI_IV_LIST.N_PRNT_PBCN_NO,
										  P_USER_EENO);
			END LOOP;
			
			--PDI 재고 재계산 작업이 이루어지면 이에 맞추어 세원 재고 재계산 작업도 이루어져야 한다. 									  
			SP_RECALCULATE_SEWHA_IV_DTL2(P_CLS_YMD,
										 P_USER_EENO);
			
	   END SP_RECALCULATE_PDI_IV_DTL2;
/**********************************************************/
/**********************************************************/
       PROCEDURE SP_RECALCULATE_PDI_IV_DTL3(P_CLS_YMD	VARCHAR2,
	                                        P_VEHL_CD   VARCHAR2,
										    P_USER_EENO VARCHAR2)
	   IS
	   	 CURSOR PDI_IV_LIST_INFO IS SELECT QLTY_VEHL_CD,
		 						 		   DL_EXPD_MDL_MDY_CD,
		 						  	 	   LANG_CD,
										   N_PRNT_PBCN_NO
		 						  	FROM TB_PDI_IV_INFO
									--재고수량이 0보다 큰 것 보다 현재일에 존재하는 모든 항목을 해 주어야 한다.
									--AND IV_QTY > 0 
									WHERE CLS_YMD = P_CLS_YMD
									AND QLTY_VEHL_CD = P_VEHL_CD
									GROUP BY QLTY_VEHL_CD, LANG_CD, N_PRNT_PBCN_NO, DL_EXPD_MDL_MDY_CD
									--정렬조건을 아래와 같은 순서를 준수하여야 한다. 
									ORDER BY QLTY_VEHL_CD, LANG_CD, N_PRNT_PBCN_NO, DL_EXPD_MDL_MDY_CD;
	   BEGIN
	   		
			--취급설명서 연식과 차종연식이 다른 항목은 우선 삭제한다. 
			DELETE FROM TB_PDI_IV_INFO_DTL 
			WHERE CLS_YMD = P_CLS_YMD 
			AND QLTY_VEHL_CD = P_VEHL_CD 
			AND MDL_MDY_CD <> DL_EXPD_MDL_MDY_CD;
			
			--취급설명서 연식과 차종연식이 같은 경우에는 안전재고수량을 재고수량으로 업데이트 해 준다. 
			UPDATE TB_PDI_IV_INFO_DTL 
			SET SFTY_IV_QTY = IV_QTY,
			    UPDR_EENO = P_USER_EENO,
				MDFY_DTM = SYSDATE
			WHERE CLS_YMD = P_CLS_YMD
			AND QLTY_VEHL_CD = P_VEHL_CD 
			AND MDL_MDY_CD = DL_EXPD_MDL_MDY_CD;
			
			FOR PDI_IV_LIST IN PDI_IV_LIST_INFO LOOP
				
				SP_RECALCULATE_PDI_IV_SUB(P_CLS_YMD,
										  PDI_IV_LIST.QLTY_VEHL_CD,
										  PDI_IV_LIST.DL_EXPD_MDL_MDY_CD,
										  PDI_IV_LIST.LANG_CD,
										  PDI_IV_LIST.N_PRNT_PBCN_NO,
										  P_USER_EENO);
			END LOOP;
			
			--PDI 재고 재계산 작업이 이루어지면 이에 맞추어 세원 재고 재계산 작업도 이루어져야 한다. 									  
			SP_RECALCULATE_SEWHA_IV_DTL3(P_CLS_YMD,
										 P_VEHL_CD,
										 P_USER_EENO);
	   
	   END SP_RECALCULATE_PDI_IV_DTL3;
/**********************************************************/
       PROCEDURE SP_RECALCULATE_PDI_IV_DTL4(P_CLS_YMD	VARCHAR2,
	                                        P_VEHL_CD   VARCHAR2,
										    P_LANG_CD	VARCHAR2,
										    P_USER_EENO VARCHAR2)
	   IS
	   
	   	 CURSOR PDI_IV_LIST_INFO IS SELECT QLTY_VEHL_CD,
		 						 		   DL_EXPD_MDL_MDY_CD,
		 						  	 	   LANG_CD,
										   N_PRNT_PBCN_NO
		 						  	FROM TB_PDI_IV_INFO
									--재고수량이 0보다 큰 것 보다 현재일에 존재하는 모든 항목을 해 주어야 한다.
									--AND IV_QTY > 0 
									WHERE CLS_YMD = P_CLS_YMD
									AND QLTY_VEHL_CD = P_VEHL_CD
									AND LANG_CD = P_LANG_CD
									GROUP BY QLTY_VEHL_CD, LANG_CD, N_PRNT_PBCN_NO, DL_EXPD_MDL_MDY_CD
									--정렬조건을 아래와 같은 순서를 준수하여야 한다. 
									ORDER BY QLTY_VEHL_CD, LANG_CD, N_PRNT_PBCN_NO, DL_EXPD_MDL_MDY_CD;
									
	   BEGIN
	   		
			--취급설명서 연식과 차종연식이 다른 항목은 우선 삭제한다. 
			DELETE FROM TB_PDI_IV_INFO_DTL 
			WHERE CLS_YMD = P_CLS_YMD 
			AND QLTY_VEHL_CD = P_VEHL_CD 
			AND MDL_MDY_CD <> DL_EXPD_MDL_MDY_CD 
			AND LANG_CD = P_LANG_CD;
			
			--취급설명서 연식과 차종연식이 같은 경우에는 안전재고수량을 재고수량으로 업데이트 해 준다. 
			UPDATE TB_PDI_IV_INFO_DTL 
			SET SFTY_IV_QTY = IV_QTY,
			    UPDR_EENO = P_USER_EENO,
				MDFY_DTM = SYSDATE
			WHERE CLS_YMD = P_CLS_YMD
			AND QLTY_VEHL_CD = P_VEHL_CD 
			AND MDL_MDY_CD = DL_EXPD_MDL_MDY_CD 
			AND LANG_CD = P_LANG_CD;
			
			FOR PDI_IV_LIST IN PDI_IV_LIST_INFO LOOP
				
				SP_RECALCULATE_PDI_IV_SUB(P_CLS_YMD,
										  PDI_IV_LIST.QLTY_VEHL_CD,
										  PDI_IV_LIST.DL_EXPD_MDL_MDY_CD,
										  PDI_IV_LIST.LANG_CD,
										  PDI_IV_LIST.N_PRNT_PBCN_NO,
										  P_USER_EENO);
			END LOOP;
			
			--PDI 재고 재계산 작업이 이루어지면 이에 맞추어 세원 재고 재계산 작업도 이루어져야 한다. 									  
			SP_RECALCULATE_SEWHA_IV_DTL4(P_CLS_YMD,
										 P_VEHL_CD,
										 P_LANG_CD,
										 P_USER_EENO);
										 
	   END SP_RECALCULATE_PDI_IV_DTL4; 
/**********************************************************/ 
       PROCEDURE SP_RECALCULATE_PDI_IV_SUB(P_CLS_YMD	     VARCHAR2,
										   P_VEHL_CD         VARCHAR2,
			  						       P_EXPD_MDL_MDY_CD VARCHAR2,
									       P_LANG_CD         VARCHAR2,
										   P_N_PRNT_PBCN_NO  VARCHAR2,
										   P_USER_EENO       VARCHAR2)
	   IS
	   
		 V_CURR_MDL_MDY_CD    VARCHAR2(2);
		 V_CURR_DAY3_PLAN_QTY NUMBER;
		 V_CURR_SFTY_IV_QTY   NUMBER;
		 
		 V_SFTY_IV_DIFF_QTY NUMBER;
		 V_SFTY_IV_DIFF 	NUMBER;
		 
		 V_DL_IV_QTY          NUMBER;
		 V_DL_CMPL_YN         VARCHAR(1);
		 V_DL_TMP_TRTM_YN     VARCHAR(1);
		 V_DL_DAY3_PLAN_QTY	  NUMBER;
		 
		 V_CURR_IV_QTY		  NUMBER;
		 V_TEMP_IV_QTY		  NUMBER;
		 V_FLAG				  VARCHAR(1);
		 
		 
		 CURSOR PDI_IV_DTL_LIST_INFO IS SELECT MDL_MDY_CD
									    FROM (
											  --[변경2]차종연식과 취급설명서 연식이 같은 경우도 가져와서 계산하게 되면 수량이 남더라도 
											  --이전연식의 안전재고수량은 무조건 2주생산계획 만큼만 남게 되고 나머지 수량은 가장 최근의 연식으로 포함되게 된다.
											  --이것 역시 문제가 될 수 있다.
											  --그래서 다시 차종연식과 취급설명서 연식이 같은 경우는 제외하도록 하고 로직에서 [변경1]의 문제를 해결하도록 한다.
										      --[변경1]전방통합, 전체통합과 같이 이전 연식의 수량을 이후 연식에서 사용할 경우를 대비하여
											  --차종연식과 취급설명서 연식이 같은 경우도 가져와야 한다.
											  
											  SELECT MDL_MDY_CD
                                              FROM TB_PDI_WHSN_INFO
											  WHERE WHSN_YMD = P_CLS_YMD
											  AND QLTY_VEHL_CD = P_VEHL_CD
											  AND DL_EXPD_MDL_MDY_CD = P_EXPD_MDL_MDY_CD
											  AND LANG_CD = P_LANG_CD
											  AND N_PRNT_PBCN_NO = P_N_PRNT_PBCN_NO
											  --차종연식과 취급설명서 연식이 다른 항목만을 가져온다.
                                              AND MDL_MDY_CD <> DL_EXPD_MDL_MDY_CD
											  GROUP BY MDL_MDY_CD
											  
											  UNION ALL
											  
											  SELECT MDL_MDY_CD
											  FROM TB_PDI_WHOT_INFO
											  WHERE WHOT_YMD = P_CLS_YMD
											  AND QLTY_VEHL_CD = P_VEHL_CD
											  AND DL_EXPD_MDL_MDY_CD = P_EXPD_MDL_MDY_CD
											  AND LANG_CD = P_LANG_CD
											  AND N_PRNT_PBCN_NO = P_N_PRNT_PBCN_NO
											  --차종연식과 취급설명서 연식이 다른 항목만을 가져온다.
											  AND MDL_MDY_CD <> DL_EXPD_MDL_MDY_CD
											  AND DEL_YN = 'N'
											  GROUP BY MDL_MDY_CD
											  
											  UNION ALL
											  
											  SELECT A.MDL_MDY_CD
											  FROM TB_LANG_MGMT A,
     										       TB_DL_EXPD_MDY_MGMT B,
	 											   TB_PDI_IV_INFO C
                                              WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
											  AND A.MDL_MDY_CD = B.MDL_MDY_CD
			 			 		   			  AND A.DL_EXPD_REGN_CD = B.DL_EXPD_REGN_CD 								   
											  AND A.QLTY_VEHL_CD = C.QLTY_VEHL_CD
											  AND B.DL_EXPD_MDL_MDY_CD = C.DL_EXPD_MDL_MDY_CD
											  AND A.LANG_CD = C.LANG_CD
											  --차종연식과 취급설명서 연식이 다른 항목만을 가져온다.
											  AND B.MDL_MDY_CD <> B.DL_EXPD_MDL_MDY_CD
											  AND C.CLS_YMD = P_CLS_YMD
											  AND C.QLTY_VEHL_CD = P_VEHL_CD
											  AND C.DL_EXPD_MDL_MDY_CD = P_EXPD_MDL_MDY_CD
											  AND C.LANG_CD = P_LANG_CD
											  AND C.N_PRNT_PBCN_NO = P_N_PRNT_PBCN_NO
											  GROUP BY A.MDL_MDY_CD
										     )
										
										GROUP BY MDL_MDY_CD
										--정렬순서를 아래와 같이 하여야 한다.
										ORDER BY MDL_MDY_CD;
												 
	   BEGIN
	   		
			SELECT MAX(IV_QTY),
				   MAX(CMPL_YN),
				   MAX(TMP_TRTM_YN)
			INTO V_DL_IV_QTY,
				 V_DL_CMPL_YN,
				 V_DL_TMP_TRTM_YN
			FROM TB_PDI_IV_INFO
			WHERE CLS_YMD = P_CLS_YMD
			AND QLTY_VEHL_CD = P_VEHL_CD
			AND DL_EXPD_MDL_MDY_CD = P_EXPD_MDL_MDY_CD
			AND LANG_CD = P_LANG_CD
			AND N_PRNT_PBCN_NO = P_N_PRNT_PBCN_NO;
			
			--취급설명서 연식의 3일생산 계획 데이터 조회 
			SELECT NVL(SUM(TDD_PRDN_PLN_QTY), 0) + NVL(SUM(TDD_PRDN_QTY3), 0)
			INTO V_DL_DAY3_PLAN_QTY
			FROM TB_APS_PROD_SUM_INFO
			WHERE APL_YMD = P_CLS_YMD
			AND QLTY_VEHL_CD = P_VEHL_CD
			AND MDL_MDY_CD = P_EXPD_MDL_MDY_CD
			AND LANG_CD = P_LANG_CD;

			V_CURR_IV_QTY := V_DL_IV_QTY;
			
			FOR PDI_IV_DTL_LIST IN PDI_IV_DTL_LIST_INFO LOOP
				
				V_CURR_MDL_MDY_CD := PDI_IV_DTL_LIST.MDL_MDY_CD;
				
				--3일 생산 계획 데이터 조회 
				SELECT NVL(SUM(TDD_PRDN_PLN_QTY), 0) + NVL(SUM(TDD_PRDN_QTY3), 0)
				INTO V_CURR_DAY3_PLAN_QTY
				FROM TB_APS_PROD_SUM_INFO
				WHERE APL_YMD = P_CLS_YMD
				AND QLTY_VEHL_CD = P_VEHL_CD
				AND MDL_MDY_CD = V_CURR_MDL_MDY_CD
				AND LANG_CD = P_LANG_CD;
				   
				--현재 안전재고 수량 조회 
				SELECT NVL(SUM(SFTY_IV_QTY), 0)
				INTO V_CURR_SFTY_IV_QTY
				FROM TB_PDI_IV_INFO_DTL
				WHERE CLS_YMD = P_CLS_YMD
				AND QLTY_VEHL_CD = P_VEHL_CD
				AND MDL_MDY_CD = V_CURR_MDL_MDY_CD
				AND LANG_CD = P_LANG_CD;
				   
				V_SFTY_IV_DIFF_QTY := V_CURR_DAY3_PLAN_QTY - V_CURR_SFTY_IV_QTY;
				
				--2주 생산계획과 안전재고의 차이가 0 보다 큰 경우에만 계산 작업을 진행한다.
				--(왜냐하면 사전에 초기화 한 상태에서 진행하므로 순수하게 현재 연식에 관계된 것만 있으므로 0 보다 작으면 
				-- 재고가 충분하다는 것이므로 작업할 필요가 없다.) 
				IF V_SFTY_IV_DIFF_QTY > 0 THEN
				   
				   --재계산할 재고수량이 존재하는 경우에만 재계산 작업을 수행한다. 
				   IF V_CURR_IV_QTY > 0 THEN
				   	  
					  --재계산할 연식이 취급설명서 연식보다 이전 연식이라면
					  --재계산 작업을 수행한다.  
					  IF V_CURR_MDL_MDY_CD <= P_EXPD_MDL_MDY_CD THEN
				   
				   	  	 IF V_SFTY_IV_DIFF_QTY >= V_CURR_IV_QTY THEN
				   	  
					  	 	V_SFTY_IV_DIFF := V_CURR_IV_QTY;
					  	 	V_CURR_IV_QTY  := 0;

				   	  	 ELSE
				      
					  	 	V_SFTY_IV_DIFF := V_SFTY_IV_DIFF_QTY;
					  	 	V_CURR_IV_QTY  := V_CURR_IV_QTY - V_SFTY_IV_DIFF_QTY;
					  
				         END IF;
					  	 
						 V_FLAG := 'Y';
						 
					  --재계산할 연식이 취급설명서 연식보다 최근 연식이라면 
					  --이전연식의 2주생산계획 수량보다 재고수량이 큰 경우에만 작업해 주도록 한다. 
				   	  ELSE
					  	  
						  SELECT NVL(SUM(SFTY_IV_QTY), 0)
						  INTO V_TEMP_IV_QTY
						  FROM TB_PDI_IV_INFO_DTL
						  WHERE CLS_YMD = P_CLS_YMD
						  AND QLTY_VEHL_CD = P_VEHL_CD
						  AND MDL_MDY_CD = P_EXPD_MDL_MDY_CD
						  AND LANG_CD = P_LANG_CD;

						  V_TEMP_IV_QTY := V_TEMP_IV_QTY - V_DL_DAY3_PLAN_QTY;

						  IF V_TEMP_IV_QTY > 0 THEN
						  	 
							 IF V_CURR_IV_QTY < V_TEMP_IV_QTY THEN
							 	
								V_TEMP_IV_QTY := V_CURR_IV_QTY;
								
							 END IF;
							 
							 IF V_SFTY_IV_DIFF_QTY >= V_TEMP_IV_QTY THEN
				   	  
					  	  	 	V_SFTY_IV_DIFF := V_TEMP_IV_QTY;
					  	 	 	V_CURR_IV_QTY  := V_CURR_IV_QTY - V_TEMP_IV_QTY;

				   	  	     ELSE
				      
					  	 	 	V_SFTY_IV_DIFF := V_SFTY_IV_DIFF_QTY;
					  	 	 	V_CURR_IV_QTY  := V_CURR_IV_QTY - V_SFTY_IV_DIFF_QTY;
					  
				             END IF;
							 
							 V_FLAG := 'Y';
						  
						  ELSE
						  	  
							  V_FLAG         := 'N';
							  V_SFTY_IV_DIFF := 0;
					   		  
					   
						  END IF;

					  END IF; --이전연식여부 비교 End 
				   
				   ELSE
				   	   
					   V_FLAG         := 'N';
					   V_SFTY_IV_DIFF := 0;
					   
					   
				   END IF; --재계산할 재고수량 존재여부 확인 End 
				   
				ELSE
					
					V_FLAG         := 'N';
					V_SFTY_IV_DIFF := 0;
					
				END IF; --2주생산 계획 수량 존재여부 확인 End 
				
				--재고 재계산에 의하여 취급설명서 연식의 안전재고 수량이 변경된 경우 
				IF V_FLAG = 'Y' THEN
				   
				   --차종연식과 취급설명서연식이 같은 항목에 
				   --재고 상세 재계산 후 남은 수량을 업데이트 해 준다. 
				   UPDATE TB_PDI_IV_INFO_DTL
				   SET SFTY_IV_QTY        = V_CURR_IV_QTY,
					   UPDR_EENO          = P_USER_EENO,
					   MDFY_DTM           = SYSDATE
				   WHERE CLS_YMD          = P_CLS_YMD
				   AND QLTY_VEHL_CD       = P_VEHL_CD
				   AND MDL_MDY_CD         = P_EXPD_MDL_MDY_CD
				   AND LANG_CD            = P_LANG_CD
				   AND DL_EXPD_MDL_MDY_CD = P_EXPD_MDL_MDY_CD
				   AND N_PRNT_PBCN_NO     = P_N_PRNT_PBCN_NO;
					  
				END IF;
				
				UPDATE TB_PDI_IV_INFO_DTL
				SET IV_QTY = V_DL_IV_QTY,
				    SFTY_IV_QTY = V_SFTY_IV_DIFF,
					CMPL_YN = V_DL_CMPL_YN,
					UPDR_EENO = P_USER_EENO,
					MDFY_DTM = SYSDATE,
					TMP_TRTM_YN = V_DL_TMP_TRTM_YN
				WHERE CLS_YMD = P_CLS_YMD
				AND QLTY_VEHL_CD = P_VEHL_CD
				AND MDL_MDY_CD = V_CURR_MDL_MDY_CD
				AND LANG_CD = P_LANG_CD
				AND DL_EXPD_MDL_MDY_CD = P_EXPD_MDL_MDY_CD
				AND N_PRNT_PBCN_NO = P_N_PRNT_PBCN_NO;

				IF SQL%NOTFOUND THEN
				   
				   INSERT INTO TB_PDI_IV_INFO_DTL
				   (CLS_YMD,
				    QLTY_VEHL_CD,
					MDL_MDY_CD,
					LANG_CD,
					DL_EXPD_MDL_MDY_CD,
					N_PRNT_PBCN_NO,
					IV_QTY,
					SFTY_IV_QTY,
					CMPL_YN,
					PPRR_EENO,
					FRAM_DTM,
					UPDR_EENO,
					MDFY_DTM,
					TMP_TRTM_YN
				   )
				   VALUES
				   (P_CLS_YMD,
				    P_VEHL_CD,
					V_CURR_MDL_MDY_CD,
					P_LANG_CD,
					P_EXPD_MDL_MDY_CD,
					P_N_PRNT_PBCN_NO,
					V_DL_IV_QTY,
					V_SFTY_IV_DIFF,
					V_DL_CMPL_YN,
					P_USER_EENO,
					SYSDATE,
					P_USER_EENO,
					SYSDATE,
					V_DL_TMP_TRTM_YN
				   );
				   	
				END IF;

			END LOOP;
			
	   END SP_RECALCULATE_PDI_IV_SUB;
/**********************************************************/
/**********************************************************/
       --PDI 재고상세 내역 재계산 작업 수행(외부 호출) 										  
	   PROCEDURE GET_PDI_IV_DTL_LIST(FROM_YMD IN VARCHAR2,
	                                 TO_YMD   IN VARCHAR2)
	   IS
	   	 
		 V_FROM_DATE DATE;
		 V_DATE_CNT  NUMBER;
		 
		 V_CURR_DATE DATE;
		 
		 V_CURR_YMD	 VARCHAR2(8);
		 
	   BEGIN
	   		
			V_FROM_DATE := TO_DATE(FROM_YMD, 'YYYYMMDD');
			V_DATE_CNT  := ROUND(TO_DATE(TO_YMD, 'YYYYMMDD') - V_FROM_DATE);
			
			FOR NUM IN 0.. V_DATE_CNT LOOP
				
				V_CURR_DATE := V_FROM_DATE + NUM;
				
				V_CURR_YMD := TO_CHAR(V_CURR_DATE, 'YYYYMMDD');
				
				--현재 날짜의 재고상세내역을 모두 삭제 한다. 
				DELETE FROM TB_PDI_IV_INFO_DTL
				WHERE CLS_YMD = V_CURR_YMD;
				
				--재고상세 테이블에 취급설명서연식과 같은 차종연식으로 데이터를 신규입력하여 준다.
				INSERT INTO TB_PDI_IV_INFO_DTL
				(CLS_YMD, 
				 QLTY_VEHL_CD, 
				 MDL_MDY_CD,
				 LANG_CD, 
				 DL_EXPD_MDL_MDY_CD, 
				 N_PRNT_PBCN_NO,
				 IV_QTY,
				 SFTY_IV_QTY,
				 CMPL_YN,
				 PPRR_EENO,
				 FRAM_DTM,
				 UPDR_EENO,
				 MDFY_DTM,
				 TMP_TRTM_YN
				)
				SELECT V_CURR_YMD,
				       QLTY_VEHL_CD,
					   DL_EXPD_MDL_MDY_CD AS MDL_MDY_CD,
					   LANG_CD,
					   DL_EXPD_MDL_MDY_CD,
					   N_PRNT_PBCN_NO,
					   IV_QTY,
					   IV_QTY,
					   CMPL_YN,
					   BTCH_USER_EENO,
					   SYSDATE,
					   BTCH_USER_EENO,
					   SYSDATE,
					   TMP_TRTM_YN
				FROM TB_PDI_IV_INFO
				WHERE CLS_YMD = V_CURR_YMD;
				
				--재고상세 재계산 작업 수행 
				SP_RECALCULATE_PDI_IV_DTL2(V_CURR_YMD, BTCH_USER_EENO);
				
			END LOOP;
			
			COMMIT;
			
	   END GET_PDI_IV_DTL_LIST;
/**********************************************************/


/**********************************************************/
       --입고/출고된 항목에 대한 세원 재고상세 테이블 업데이트 작업 수행 
       PROCEDURE SP_UPDATE_SEWHA_IV_DTL_INFO(P_VEHL_CD         VARCHAR2,
			  							     P_EXPD_MDL_MDY_CD VARCHAR2,
									         P_LANG_CD         VARCHAR2,
									         P_N_PRNT_PBCN_NO  VARCHAR2,
									         P_CLS_YMD		   VARCHAR2,
										     P_USER_EENO	   VARCHAR2)
	   IS
	   		 
		 V_IV_QTY      	   NUMBER;
		 V_EXPD_TMP_IV_QTY NUMBER;
		 V_CNT	           NUMBER;
		 V_CMPL_YN     	   VARCHAR2(1);
		 V_TMP_TRTM_YN 	   VARCHAR2(1);

	   BEGIN

			--재고 테이블 재고 수량 조회 
			SELECT SUM(IV_QTY),
				   SUM(DL_EXPD_TMP_IV_QTY),
			   	   MAX(CMPL_YN),
				   MAX(TMP_TRTM_YN)
			INTO V_IV_QTY,
				 V_EXPD_TMP_IV_QTY,
			     V_CMPL_YN,
				 V_TMP_TRTM_YN
			FROM TB_SEWHA_IV_INFO
			WHERE CLS_YMD = P_CLS_YMD
			AND QLTY_VEHL_CD = P_VEHL_CD
			AND DL_EXPD_MDL_MDY_CD = P_EXPD_MDL_MDY_CD
			AND LANG_CD = P_LANG_CD
			AND N_PRNT_PBCN_NO = P_N_PRNT_PBCN_NO;
			
			--재고 테이블에 데이터가 존재하는 경우에 아래의 작업을 수행한다. 
			IF V_CMPL_YN IS NOT NULL THEN
			   
			   --재고상세 테이블내에 취급설명서연식으로 적용된 항목의 재고수량을 변경된 수량으로 
			   --모두 업데이트 해 준다. 
			   --단, 차종의 연식과 취급설명서의 연식이 같은 경우에만 업데이트 해준다.
			   --(왜냐하면 같은 않은 항목은 재고 상세 내역 재계산시에 우선 삭제된 뒤에 다시 계산하기 때문에 의미가 없다.)  
			   UPDATE TB_SEWHA_IV_INFO_DTL
			   SET IV_QTY = V_IV_QTY,
			   	   --안전재고의 수량을 재고수량과 같게 해준다.
			   	   SFTY_IV_QTY = V_IV_QTY,
			   	   DL_EXPD_TMP_IV_QTY = V_EXPD_TMP_IV_QTY,
			   	   CMPL_YN = V_CMPL_YN,
				   UPDR_EENO = P_USER_EENO,
				   MDFY_DTM = SYSDATE,
				   TMP_TRTM_YN = V_TMP_TRTM_YN
			   WHERE CLS_YMD = P_CLS_YMD
			   AND QLTY_VEHL_CD = P_VEHL_CD
			   --차종의 연식과 취급설명서의 연식이 같은 경우에만 업데이트 해 주도록 한다. 
			   AND MDL_MDY_CD = P_EXPD_MDL_MDY_CD 
			   AND LANG_CD = P_LANG_CD
			   AND DL_EXPD_MDL_MDY_CD = P_EXPD_MDL_MDY_CD
			   AND N_PRNT_PBCN_NO = P_N_PRNT_PBCN_NO;
			   
			   IF SQL%NOTFOUND THEN
			   	  
				  INSERT INTO TB_SEWHA_IV_INFO_DTL
				   (CLS_YMD,
				   	QLTY_VEHL_CD,
				   	MDL_MDY_CD,
				   	LANG_CD,
				   	DL_EXPD_MDL_MDY_CD,
				   	N_PRNT_PBCN_NO,
				   	IV_QTY,
				   	SFTY_IV_QTY,
					DL_EXPD_TMP_IV_QTY,
				   	CMPL_YN,
				   	PPRR_EENO,
				   	FRAM_DTM,
				   	UPDR_EENO,
				   	MDFY_DTM,
					TMP_TRTM_YN
				   )
				   VALUES
				   (P_CLS_YMD,
				   	P_VEHL_CD,
					--차종의 연식과 취급설명서의 연식을 같은 값으로 입력해 준다.(반드시 취급설명서의 연식으로 입력) 
				   	P_EXPD_MDL_MDY_CD,
				   	P_LANG_CD,
				   	P_EXPD_MDL_MDY_CD,
				   	P_N_PRNT_PBCN_NO,
				   	V_IV_QTY,
					--차종의 연식과 취급설명서의 연식이 같은 경우에는 안전재고의 수량을 재고수량과 같게 해준다.
				   	V_IV_QTY,
					V_EXPD_TMP_IV_QTY,
				   	V_CMPL_YN,
				   	P_USER_EENO,
				   	SYSDATE,
				   	P_USER_EENO,
				   	SYSDATE,
					V_TMP_TRTM_YN
				   );
				  
			   END IF;
    
			END IF;
			
	   END SP_UPDATE_SEWHA_IV_DTL_INFO;
/**********************************************************/ 
/**********************************************************/   
	   --재고상세 내역 재계산 작업 수행 									
	   PROCEDURE SP_RECALCULATE_SEWHA_IV_DTL1(P_CLS_YMD	        VARCHAR2,
										      P_VEHL_CD         VARCHAR2,
			  						       	  P_EXPD_MDL_MDY_CD VARCHAR2,
									       	  P_LANG_CD         VARCHAR2,
											  P_N_PRNT_PBCN_NO  VARCHAR2,
										   	  P_USER_EENO       VARCHAR2)
	   IS
	   BEGIN
	   		
			--취급설명서 연식과 차종연식이 다른 항목은 우선 삭제한다. 
			DELETE FROM TB_SEWHA_IV_INFO_DTL 
			WHERE CLS_YMD = P_CLS_YMD 
			AND QLTY_VEHL_CD = P_VEHL_CD 
			AND MDL_MDY_CD <> DL_EXPD_MDL_MDY_CD 
			AND LANG_CD = P_LANG_CD
			AND DL_EXPD_MDL_MDY_CD = P_EXPD_MDL_MDY_CD
			AND N_PRNT_PBCN_NO = P_N_PRNT_PBCN_NO;
			
			--취급설명서 연식과 차종연식이 같은 경우에는 안전재고수량을 재고수량으로 업데이트 해 준다. 
			UPDATE TB_SEWHA_IV_INFO_DTL 
			SET SFTY_IV_QTY = IV_QTY,
			    UPDR_EENO = P_USER_EENO,
				MDFY_DTM = SYSDATE
			WHERE CLS_YMD = P_CLS_YMD
			AND QLTY_VEHL_CD = P_VEHL_CD 
			AND MDL_MDY_CD = DL_EXPD_MDL_MDY_CD 
			AND LANG_CD = P_LANG_CD
			AND DL_EXPD_MDL_MDY_CD = P_EXPD_MDL_MDY_CD
			AND N_PRNT_PBCN_NO = P_N_PRNT_PBCN_NO;
			
			SP_RECALCULATE_SEWHA_IV_SUB(P_CLS_YMD,
									    P_VEHL_CD,
									    P_EXPD_MDL_MDY_CD,
									    P_LANG_CD,
									    P_N_PRNT_PBCN_NO,
									    P_USER_EENO);
			
	   END SP_RECALCULATE_SEWHA_IV_DTL1;								  
/**********************************************************/
/**********************************************************/
       --재고상세 내역 재계산 작업 수행(배치 프로그램 전용) 							   
	   PROCEDURE SP_RECALCULATE_SEWHA_IV_DTL2(P_CLS_YMD	  VARCHAR2,
										      P_USER_EENO VARCHAR2)
	   IS
	   	 
		 CURSOR SEWHA_IV_LIST_INFO IS SELECT QLTY_VEHL_CD,
		 						   	  		 DL_EXPD_MDL_MDY_CD,
		 						  	 	     LANG_CD,
										     N_PRNT_PBCN_NO
		 						  	  FROM TB_SEWHA_IV_INFO
									  --재고수량이 0보다 큰 것 보다 현재일에 존재하는 모든 항목을 해 주어야 한다.
									  --AND IV_QTY > 0 
									  WHERE CLS_YMD = P_CLS_YMD
									  GROUP BY QLTY_VEHL_CD, LANG_CD, N_PRNT_PBCN_NO, DL_EXPD_MDL_MDY_CD
									  --정렬조건을 아래와 같은 순서를 준수하여야 한다. 
									  ORDER BY QLTY_VEHL_CD, LANG_CD, N_PRNT_PBCN_NO, DL_EXPD_MDL_MDY_CD;
								 
	   BEGIN
	   		
			--취급설명서 연식과 차종연식이 다른 항목은 우선 삭제한다. 
			DELETE FROM TB_SEWHA_IV_INFO_DTL 
			WHERE CLS_YMD = P_CLS_YMD 
			AND MDL_MDY_CD <> DL_EXPD_MDL_MDY_CD;
			
			--취급설명서 연식과 차종연식이 같은 경우에는 안전재고수량을 재고수량으로 업데이트 해 준다. 
			UPDATE TB_SEWHA_IV_INFO_DTL 
			SET SFTY_IV_QTY = IV_QTY,
			    UPDR_EENO = P_USER_EENO,
				MDFY_DTM = SYSDATE
			WHERE CLS_YMD = P_CLS_YMD
			AND MDL_MDY_CD = DL_EXPD_MDL_MDY_CD;
			
			FOR SEWHA_IV_LIST IN SEWHA_IV_LIST_INFO LOOP
				
				SP_RECALCULATE_SEWHA_IV_SUB(P_CLS_YMD,
										    SEWHA_IV_LIST.QLTY_VEHL_CD,
										    SEWHA_IV_LIST.DL_EXPD_MDL_MDY_CD,
										    SEWHA_IV_LIST.LANG_CD,
										    SEWHA_IV_LIST.N_PRNT_PBCN_NO,
										    P_USER_EENO);
			END LOOP;
			
	   END SP_RECALCULATE_SEWHA_IV_DTL2;
/**********************************************************/
/**********************************************************/
       PROCEDURE SP_RECALCULATE_SEWHA_IV_DTL3(P_CLS_YMD   VARCHAR2,
	                                          P_VEHL_CD   VARCHAR2,
										      P_USER_EENO VARCHAR2)
	   IS
	   	 
		 CURSOR SEWHA_IV_LIST_INFO IS SELECT QLTY_VEHL_CD,
		 						   	  		 DL_EXPD_MDL_MDY_CD,
		 						  	 	     LANG_CD,
										     N_PRNT_PBCN_NO
		 						  	  FROM TB_SEWHA_IV_INFO
									  --재고수량이 0보다 큰 것 보다 현재일에 존재하는 모든 항목을 해 주어야 한다.
									  --AND IV_QTY > 0 
									  WHERE CLS_YMD = P_CLS_YMD
									  AND QLTY_VEHL_CD = P_VEHL_CD
									  GROUP BY QLTY_VEHL_CD, LANG_CD, N_PRNT_PBCN_NO, DL_EXPD_MDL_MDY_CD
									  --정렬조건을 아래와 같은 순서를 준수하여야 한다. 
									  ORDER BY QLTY_VEHL_CD, LANG_CD, N_PRNT_PBCN_NO, DL_EXPD_MDL_MDY_CD;
									  
	   BEGIN
	   		
			--취급설명서 연식과 차종연식이 다른 항목은 우선 삭제한다. 
			DELETE FROM TB_SEWHA_IV_INFO_DTL 
			WHERE CLS_YMD = P_CLS_YMD 
			AND QLTY_VEHL_CD = P_VEHL_CD 
			AND MDL_MDY_CD <> DL_EXPD_MDL_MDY_CD;
			
			--취급설명서 연식과 차종연식이 같은 경우에는 안전재고수량을 재고수량으로 업데이트 해 준다. 
			UPDATE TB_SEWHA_IV_INFO_DTL 
			SET SFTY_IV_QTY = IV_QTY,
			    UPDR_EENO = P_USER_EENO,
				MDFY_DTM = SYSDATE
			WHERE CLS_YMD = P_CLS_YMD
			AND QLTY_VEHL_CD = P_VEHL_CD 
			AND MDL_MDY_CD = DL_EXPD_MDL_MDY_CD;
			
			FOR SEWHA_IV_LIST IN SEWHA_IV_LIST_INFO LOOP
				
				SP_RECALCULATE_SEWHA_IV_SUB(P_CLS_YMD,
										    SEWHA_IV_LIST.QLTY_VEHL_CD,
										    SEWHA_IV_LIST.DL_EXPD_MDL_MDY_CD,
										    SEWHA_IV_LIST.LANG_CD,
										    SEWHA_IV_LIST.N_PRNT_PBCN_NO,
										    P_USER_EENO);
			END LOOP;
	   
	   END SP_RECALCULATE_SEWHA_IV_DTL3;
/**********************************************************/	   								    
/**********************************************************/ 
       --재고상세 내역 재계산 작업 수행 								   
	   PROCEDURE SP_RECALCULATE_SEWHA_IV_DTL4(P_CLS_YMD   VARCHAR2,
										      P_VEHL_CD   VARCHAR2,
			  						          P_LANG_CD   VARCHAR2,
										      P_USER_EENO VARCHAR2)
	   IS
	   	 
		 CURSOR SEWHA_IV_LIST_INFO IS SELECT QLTY_VEHL_CD,
		 						   	  		 DL_EXPD_MDL_MDY_CD,
		 						  	 	     LANG_CD,
										     N_PRNT_PBCN_NO
		 						  	  FROM TB_SEWHA_IV_INFO
									  --재고수량이 0보다 큰 것 보다 현재일에 존재하는 모든 항목을 해 주어야 한다.
									  --AND IV_QTY > 0 
									  WHERE CLS_YMD = P_CLS_YMD
									  AND QLTY_VEHL_CD = P_VEHL_CD
									  AND LANG_CD = P_LANG_CD
									  GROUP BY QLTY_VEHL_CD, LANG_CD, N_PRNT_PBCN_NO, DL_EXPD_MDL_MDY_CD
									  --정렬조건을 아래와 같은 순서를 준수하여야 한다. 
									  ORDER BY QLTY_VEHL_CD, LANG_CD, N_PRNT_PBCN_NO, DL_EXPD_MDL_MDY_CD;
									
	   BEGIN
	   		
			--취급설명서 연식과 차종연식이 다른 항목은 우선 삭제한다. 
			DELETE FROM TB_SEWHA_IV_INFO_DTL 
			WHERE CLS_YMD = P_CLS_YMD 
			AND QLTY_VEHL_CD = P_VEHL_CD 
			AND MDL_MDY_CD <> DL_EXPD_MDL_MDY_CD 
			AND LANG_CD = P_LANG_CD;
			
			--취급설명서 연식과 차종연식이 같은 경우에는 안전재고수량을 재고수량으로 업데이트 해 준다. 
			UPDATE TB_SEWHA_IV_INFO_DTL 
			SET SFTY_IV_QTY = IV_QTY,
			    UPDR_EENO = P_USER_EENO,
				MDFY_DTM = SYSDATE
			WHERE CLS_YMD = P_CLS_YMD
			AND QLTY_VEHL_CD = P_VEHL_CD 
			AND MDL_MDY_CD = DL_EXPD_MDL_MDY_CD 
			AND LANG_CD = P_LANG_CD;
			
			FOR SEWHA_IV_LIST IN SEWHA_IV_LIST_INFO LOOP
				
				SP_RECALCULATE_SEWHA_IV_SUB(P_CLS_YMD,
										    SEWHA_IV_LIST.QLTY_VEHL_CD,
										    SEWHA_IV_LIST.DL_EXPD_MDL_MDY_CD,
										    SEWHA_IV_LIST.LANG_CD,
										    SEWHA_IV_LIST.N_PRNT_PBCN_NO,
										    P_USER_EENO);
			END LOOP;
			
	   END SP_RECALCULATE_SEWHA_IV_DTL4;
/**********************************************************/ 		
/**********************************************************/ 										  
	   PROCEDURE SP_RECALCULATE_SEWHA_IV_SUB(P_CLS_YMD	       VARCHAR2,
										     P_VEHL_CD         VARCHAR2,
			  						         P_EXPD_MDL_MDY_CD VARCHAR2,
									         P_LANG_CD         VARCHAR2,
										     P_N_PRNT_PBCN_NO  VARCHAR2,
										     P_USER_EENO       VARCHAR2)
	   IS
	   
	   	 V_CURR_MDL_MDY_CD    VARCHAR2(2);
		 V_CURR_WEK2_PLAN_QTY NUMBER;
		 V_CURR_SFTY_IV_QTY   NUMBER;
		 V_CURR_PDI_IV_QTY	  NUMBER;
		 
		 V_SFTY_IV_DIFF_QTY NUMBER;
		 V_SFTY_IV_DIFF 	NUMBER;
		 
		 V_DL_IV_QTY          NUMBER;
		 V_DL_PDI_IV_QTY      NUMBER;
		 V_DL_EXPD_TMP_IV_QTY NUMBER;
		 V_DL_CMPL_YN         VARCHAR(1);
		 V_DL_TMP_TRTM_YN     VARCHAR(1);
		 V_DL_WEK2_PLAN_QTY	  NUMBER;
		 
		 V_CURR_IV_QTY		  NUMBER;
		 V_TEMP_IV_QTY		  NUMBER;
		 V_FLAG				  VARCHAR(1);
		 
		 CURSOR SEWHA_IV_DTL_LIST_INFO IS SELECT MDL_MDY_CD
									      FROM (
										        --[변경2]차종연식과 취급설명서 연식이 같은 경우도 가져와서 계산하게 되면 수량이 남더라도 
												--이전연식의 안전재고수량은 무조건 2주생산계획 만큼만 남게 되고 나머지 수량은 가장 최근의 연식으로 포함되게 된다.
												--이것 역시 문제가 될 수 있다.
												--그래서 다시 차종연식과 취급설명서 연식이 같은 경우는 제외하도록 하고 로직에서 [변경1]의 문제를 해결하도록 한다.
										        --[변경1]전방통합, 전체통합과 같이 이전 연식의 수량을 이후 연식에서 사용할 경우를 대비하여
												--차종연식과 취급설명서 연식이 같은 경우도 가져와야 한다.
										  	    
												/***  세원 입고현황은 차종연식과 취급설명서 연식이 다른 경우가 현재는 존재치 않는다.
												       그래서 조회할 필요가 없다.
													   
										  	    SELECT MDL_MDY_CD 
                                                FROM TB_SEWHA_WHSN_INFO 
												WHERE WHSN_YMD = P_CLS_YMD 
												AND QLTY_VEHL_CD = P_VEHL_CD 
												AND DL_EXPD_MDL_MDY_CD = P_EXPD_MDL_MDY_CD 
												AND LANG_CD = P_LANG_CD
												AND N_PRNT_PBCN_NO = P_N_PRNT_PBCN_NO 
												--차종연식과 취급설명서 연식이 다른 항목만을 가져온다.
                                                AND MDL_MDY_CD <> DL_EXPD_MDL_MDY_CD 
												GROUP BY MDL_MDY_CD 
											    
											    UNION ALL 
												***/
												
											    SELECT MDL_MDY_CD
											    FROM TB_SEWHA_WHOT_INFO
												WHERE WHOT_YMD = P_CLS_YMD
												AND QLTY_VEHL_CD = P_VEHL_CD
												AND DL_EXPD_MDL_MDY_CD = P_EXPD_MDL_MDY_CD
												AND LANG_CD = P_LANG_CD
												AND N_PRNT_PBCN_NO = P_N_PRNT_PBCN_NO
												--차종연식과 취급설명서 연식이 다른 항목만을 가져온다.
											    AND MDL_MDY_CD <> DL_EXPD_MDL_MDY_CD
												AND DEL_YN = 'N'
												GROUP BY MDL_MDY_CD

											    UNION ALL
											  
											    SELECT A.MDL_MDY_CD
											    FROM TB_LANG_MGMT A,
     										         TB_DL_EXPD_MDY_MGMT B,
	 											     TB_SEWHA_IV_INFO C
                                                WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
											    AND A.MDL_MDY_CD = B.MDL_MDY_CD
			 			 		   			    AND A.DL_EXPD_REGN_CD = B.DL_EXPD_REGN_CD 								   
											    AND A.QLTY_VEHL_CD = C.QLTY_VEHL_CD
											    AND B.DL_EXPD_MDL_MDY_CD = C.DL_EXPD_MDL_MDY_CD
											    AND A.LANG_CD = C.LANG_CD
											    --차종연식과 취급설명서 연식이 다른 항목만을 가져온다.
											    AND B.MDL_MDY_CD <> B.DL_EXPD_MDL_MDY_CD
											    AND C.CLS_YMD = P_CLS_YMD
											    AND C.QLTY_VEHL_CD = P_VEHL_CD
											    AND C.DL_EXPD_MDL_MDY_CD = P_EXPD_MDL_MDY_CD
											    AND C.LANG_CD = P_LANG_CD
											    AND C.N_PRNT_PBCN_NO = P_N_PRNT_PBCN_NO
											    GROUP BY A.MDL_MDY_CD
										       )
										  GROUP BY MDL_MDY_CD
										  --정렬순서를 아래와 같이 하여야 한다.
										  ORDER BY MDL_MDY_CD;
	   BEGIN
	   		
			SELECT MAX(IV_QTY),
				   MAX(DL_EXPD_TMP_IV_QTY),
				   MAX(CMPL_YN),
				   MAX(TMP_TRTM_YN)
			INTO V_DL_IV_QTY,
			     V_DL_EXPD_TMP_IV_QTY,
				 V_DL_CMPL_YN,
				 V_DL_TMP_TRTM_YN
			FROM TB_SEWHA_IV_INFO
			WHERE CLS_YMD = P_CLS_YMD
			AND QLTY_VEHL_CD = P_VEHL_CD
			AND DL_EXPD_MDL_MDY_CD = P_EXPD_MDL_MDY_CD
			AND LANG_CD = P_LANG_CD
			AND N_PRNT_PBCN_NO = P_N_PRNT_PBCN_NO;
			
			--취급설명서 연식의 2주생산 계획 데이터 조회 
			SELECT NVL(SUM(WEK2_PRDN_PLN_QTY), 0) + NVL(SUM(TDD_PRDN_QTY3), 0)
			INTO V_DL_WEK2_PLAN_QTY
			FROM TB_APS_PROD_SUM_INFO
			WHERE APL_YMD = P_CLS_YMD
			AND QLTY_VEHL_CD = P_VEHL_CD
			AND MDL_MDY_CD = P_EXPD_MDL_MDY_CD
			AND LANG_CD = P_LANG_CD;
			
			--취급설명서 연식의 PDI 안전재고수량 조회 
			SELECT SUM(SFTY_IV_QTY)
			INTO V_DL_PDI_IV_QTY
			FROM TB_PDI_IV_INFO_DTL
			WHERE CLS_YMD = P_CLS_YMD
			AND QLTY_VEHL_CD = P_VEHL_CD
			AND MDL_MDY_CD = P_EXPD_MDL_MDY_CD
			AND LANG_CD = P_LANG_CD;
					
			V_CURR_IV_QTY := V_DL_IV_QTY;
			
			FOR SEWHA_IV_DTL_LIST IN SEWHA_IV_DTL_LIST_INFO LOOP
				
				V_CURR_MDL_MDY_CD := SEWHA_IV_DTL_LIST.MDL_MDY_CD;
				   
				--2주생산 계획 데이터 조회 
				SELECT NVL(SUM(WEK2_PRDN_PLN_QTY), 0) + NVL(SUM(TDD_PRDN_QTY3), 0)
				INTO V_CURR_WEK2_PLAN_QTY
				FROM TB_APS_PROD_SUM_INFO
				WHERE APL_YMD = P_CLS_YMD
				AND QLTY_VEHL_CD = P_VEHL_CD
				AND MDL_MDY_CD = V_CURR_MDL_MDY_CD
				AND LANG_CD = P_LANG_CD;
				   
				--현재 안전재고 수량 조회 
				SELECT NVL(SUM(SFTY_IV_QTY), 0)
				INTO V_CURR_SFTY_IV_QTY
				FROM TB_SEWHA_IV_INFO_DTL
				WHERE CLS_YMD = P_CLS_YMD
				AND QLTY_VEHL_CD = P_VEHL_CD
				AND MDL_MDY_CD = V_CURR_MDL_MDY_CD
				AND LANG_CD = P_LANG_CD;
				
				--PDI 안전재고수량 조회 
				SELECT SUM(SFTY_IV_QTY)
				INTO V_CURR_PDI_IV_QTY
				FROM TB_PDI_IV_INFO_DTL
				WHERE CLS_YMD = P_CLS_YMD
				AND QLTY_VEHL_CD = P_VEHL_CD
				AND MDL_MDY_CD = V_CURR_MDL_MDY_CD
				AND LANG_CD = P_LANG_CD;
				
				-- 2주생산계획 수량 - (현재의 안전재고 수량 + PDI 안전재고 수량)    
				V_SFTY_IV_DIFF_QTY := V_CURR_WEK2_PLAN_QTY - (V_CURR_SFTY_IV_QTY + V_CURR_PDI_IV_QTY);
				
				--2주 생산계획과 안전재고의 차이가 0 보다 큰 경우에만 계산 작업을 진행한다.
				--(왜냐하면 사전에 초기화 한 상태에서 진행하므로 순수하게 현재 연식에 관계된 것만 있으므로 0 보다 작으면 
				-- 재고가 충분하다는 것이므로 작업할 필요가 없다.) 
				IF V_SFTY_IV_DIFF_QTY > 0 THEN
				   
				   --재계산할 재고수량이 존재하는 경우에만 재계산 작업을 수행한다. 
				   IF V_CURR_IV_QTY > 0 THEN
				   	  
					  --재계산할 연식이 취급설명서 연식보다 이전 연식이라면
					  --재계산 작업을 수행한다.  
					  IF V_CURR_MDL_MDY_CD <= P_EXPD_MDL_MDY_CD THEN
				   
				   	  	 IF V_SFTY_IV_DIFF_QTY >= V_CURR_IV_QTY THEN
				   	  
					  	 	V_SFTY_IV_DIFF := V_CURR_IV_QTY;
					  	 	V_CURR_IV_QTY  := 0;

				   	  	 ELSE
				      
					  	 	V_SFTY_IV_DIFF := V_SFTY_IV_DIFF_QTY;
					  	 	V_CURR_IV_QTY  := V_CURR_IV_QTY - V_SFTY_IV_DIFF_QTY;
					  
				         END IF;
					  	 
						 V_FLAG := 'Y';
						 
					  --재계산할 연식이 취급설명서 연식보다 최근 연식이라면 
					  --이전연식의 2주생산계획 수량보다 재고수량이 큰 경우에만 작업해 주도록 한다. 
				   	  ELSE
					  	  
						  SELECT NVL(SUM(SFTY_IV_QTY), 0)
						  INTO V_TEMP_IV_QTY
						  FROM TB_SEWHA_IV_INFO_DTL
						  WHERE CLS_YMD = P_CLS_YMD
						  AND QLTY_VEHL_CD = P_VEHL_CD
						  AND MDL_MDY_CD = P_EXPD_MDL_MDY_CD
						  AND LANG_CD = P_LANG_CD;
						  
						  V_TEMP_IV_QTY := (V_TEMP_IV_QTY + V_DL_PDI_IV_QTY) - V_DL_WEK2_PLAN_QTY;
						  
						  IF V_TEMP_IV_QTY > 0 THEN
						  	 
							 IF V_CURR_IV_QTY < V_TEMP_IV_QTY THEN
							 	
								V_TEMP_IV_QTY := V_CURR_IV_QTY;
								
							 END IF;
							 
							 IF V_SFTY_IV_DIFF_QTY >= V_TEMP_IV_QTY THEN
				   	  
					  	  	 	V_SFTY_IV_DIFF := V_TEMP_IV_QTY;
					  	 	 	V_CURR_IV_QTY  := V_CURR_IV_QTY - V_TEMP_IV_QTY;

				   	  	     ELSE
				      
					  	 	 	V_SFTY_IV_DIFF := V_SFTY_IV_DIFF_QTY;
					  	 	 	V_CURR_IV_QTY  := V_CURR_IV_QTY - V_SFTY_IV_DIFF_QTY;
					  
				             END IF;
							 
							 V_FLAG := 'Y';
						  
						  ELSE
						  	  
							  V_FLAG         := 'N';
							  V_SFTY_IV_DIFF := 0;
					   		  
					   
						  END IF;

					  END IF; --이전연식여부 비교 End 
				   
				   ELSE
				   	   
					   V_FLAG         := 'N';
					   V_SFTY_IV_DIFF := 0;
					   
					   
				   END IF; --재계산할 재고수량 존재여부 확인 End 
				   
				ELSE
					
					V_FLAG         := 'N';
					V_SFTY_IV_DIFF := 0;
					
				END IF; --2주생산 계획 수량 존재여부 확인 End 
				
				--재고 재계산에 의하여 취급설명서 연식의 안전재고 수량이 변경된 경우 
				IF V_FLAG = 'Y' THEN
				   
				   --차종연식과 취급설명서연식이 같은 항목에 
				   --재고 상세 재계산 후 남은 수량을 업데이트 해 준다. 
				   UPDATE TB_SEWHA_IV_INFO_DTL
				   SET SFTY_IV_QTY        = V_CURR_IV_QTY,
					   UPDR_EENO          = P_USER_EENO,
					   MDFY_DTM           = SYSDATE
				   WHERE CLS_YMD          = P_CLS_YMD
				   AND QLTY_VEHL_CD       = P_VEHL_CD
				   AND MDL_MDY_CD         = P_EXPD_MDL_MDY_CD
				   AND LANG_CD            = P_LANG_CD
				   AND DL_EXPD_MDL_MDY_CD = P_EXPD_MDL_MDY_CD
				   AND N_PRNT_PBCN_NO     = P_N_PRNT_PBCN_NO;
					  
				END IF;
				
				UPDATE TB_SEWHA_IV_INFO_DTL
				SET IV_QTY             = V_DL_IV_QTY,
				    SFTY_IV_QTY        = V_SFTY_IV_DIFF,
					DL_EXPD_TMP_IV_QTY = V_DL_EXPD_TMP_IV_QTY,
					CMPL_YN            = V_DL_CMPL_YN,
					UPDR_EENO          = P_USER_EENO,
					MDFY_DTM           = SYSDATE,
					TMP_TRTM_YN        = V_DL_TMP_TRTM_YN
				WHERE CLS_YMD          = P_CLS_YMD
				AND QLTY_VEHL_CD       = P_VEHL_CD
				AND MDL_MDY_CD         = V_CURR_MDL_MDY_CD
				AND LANG_CD            = P_LANG_CD
				AND DL_EXPD_MDL_MDY_CD = P_EXPD_MDL_MDY_CD
				AND N_PRNT_PBCN_NO     = P_N_PRNT_PBCN_NO;
				
				IF SQL%NOTFOUND THEN
				   
				   INSERT INTO TB_SEWHA_IV_INFO_DTL
				   (CLS_YMD,
				    QLTY_VEHL_CD,
					MDL_MDY_CD,
					LANG_CD,
					DL_EXPD_MDL_MDY_CD,
					N_PRNT_PBCN_NO,
					IV_QTY,
					SFTY_IV_QTY,
					DL_EXPD_TMP_IV_QTY,
					CMPL_YN,
					PPRR_EENO,
					FRAM_DTM,
					UPDR_EENO,
					MDFY_DTM,
					TMP_TRTM_YN
				   )
				   VALUES
				   (P_CLS_YMD,
				    P_VEHL_CD,
					V_CURR_MDL_MDY_CD,
					P_LANG_CD,
					P_EXPD_MDL_MDY_CD,
					P_N_PRNT_PBCN_NO,
					V_DL_IV_QTY,
					V_SFTY_IV_DIFF,
					V_DL_EXPD_TMP_IV_QTY,
					V_DL_CMPL_YN,
					P_USER_EENO,
					SYSDATE,
					P_USER_EENO,
					SYSDATE,
					V_DL_TMP_TRTM_YN
				   );
				   	
				END IF;
				
			END LOOP;
			
	   END SP_RECALCULATE_SEWHA_IV_SUB;
/**********************************************************/ 		
/**********************************************************/ 										  
       --세원 재고상세 내역 재계산 작업 수행(외부 호출) 										  
	   PROCEDURE GET_SEWHA_IV_DTL_LIST(FROM_YMD IN VARCHAR2,
	                                   TO_YMD   IN VARCHAR2)
	   IS
	   	 
		 V_FROM_DATE DATE;
		 V_DATE_CNT  NUMBER;
		 
		 V_CURR_DATE DATE;
		 
		 V_CURR_YMD	 VARCHAR2(8);
		 
	   BEGIN
	   		
			V_FROM_DATE := TO_DATE(FROM_YMD, 'YYYYMMDD');
			V_DATE_CNT  := ROUND(TO_DATE(TO_YMD, 'YYYYMMDD') - V_FROM_DATE);
			
			FOR NUM IN 0.. V_DATE_CNT LOOP
				
				V_CURR_DATE := V_FROM_DATE + NUM;
				
				V_CURR_YMD := TO_CHAR(V_CURR_DATE, 'YYYYMMDD');
				
				--현재 날짜의 재고상세내역을 모두 삭제 한다. 
				DELETE FROM TB_SEWHA_IV_INFO_DTL
				WHERE CLS_YMD = V_CURR_YMD;
				
				--재고상세 테이블에 취급설명서연식과 같은 차종연식으로 데이터를 신규입력하여 준다.
				INSERT INTO TB_SEWHA_IV_INFO_DTL
				(CLS_YMD, 
				 QLTY_VEHL_CD, 
				 MDL_MDY_CD,
				 LANG_CD, 
				 DL_EXPD_MDL_MDY_CD, 
				 N_PRNT_PBCN_NO,
				 IV_QTY,
				 SFTY_IV_QTY,
				 DL_EXPD_TMP_IV_QTY,
				 CMPL_YN,
				 PPRR_EENO,
				 FRAM_DTM,
				 UPDR_EENO,
				 MDFY_DTM,
				 TMP_TRTM_YN
				)
				SELECT V_CURR_YMD,
				       QLTY_VEHL_CD,
					   DL_EXPD_MDL_MDY_CD AS MDL_MDY_CD,
					   LANG_CD,
					   DL_EXPD_MDL_MDY_CD,
					   N_PRNT_PBCN_NO,
					   IV_QTY,
					   IV_QTY,
					   DL_EXPD_TMP_IV_QTY,
					   CMPL_YN,
					   BTCH_USER_EENO,
					   SYSDATE,
					   BTCH_USER_EENO,
					   SYSDATE,
					   TMP_TRTM_YN
				FROM TB_SEWHA_IV_INFO
				WHERE CLS_YMD = V_CURR_YMD;
				
				--재고상세 재계산 작업 수행 
				SP_RECALCULATE_SEWHA_IV_DTL2(V_CURR_YMD, BTCH_USER_EENO);
				
			END LOOP;
			
			COMMIT;
	   
	   END GET_SEWHA_IV_DTL_LIST;
/**********************************************************/ 
	   

/**********************************************************/ 
       --일자변경시에 작업 수행(배치 실행) 
	   --반드시 현재일 시작시간에 돌려야 한다. 
       PROCEDURE OWNERS_DATE_CHANGE_BATCH
	   IS
	   BEGIN
	        
			--[중요] 아래의 작업들은 오라클 데드락 방지를 위하여 하나의 세션안에서 실행되어야 한다.
			
            --PDI 재고 일자 변경 배치 수행 
			PG_PDI_IV_INFO.SP_PDI_IV_INFO_BATCH();
            
            --세화 재고 일자 변경 배치 수행 
			PG_SEWHA_IV_INFO.SP_SEWHA_IV_INFO_BATCH();
            
			--HMC 생산계획 일자변경 배치 수행 
			PG_INTERFACE_APS.APS_INTERFACE_DATE_HMC();

			--HMC 생산마스터 일자변경 배치 수행 
			PG_INTERFACE_PROD_MST.PROD_MST_INTERFACE_DATE_HMC();
			

			
			--[중요] 위의 작업들이 모두 이루어진 뒤에 아래의 작업이 진행되어야 한다.
			--(일자 변경 배치 수행시에 세원 재고 배치가 이루어진 뒤에 반드시 PDI 재고 배치가 이루어 져야 한다.
			-- PDI 재고 재계산 로직 내부에 세원재고 재계산 로직이 포함되어 있기 때문이다.
			-- 그리고 PDI 재고 에 없는 항목이 세원재고에 있을 수도 있으므로 세원 일자 변경 재치 수행시에는 세원재고 재계산 작업은 또한 진행되어야 한다.) 
			
	   END OWNERS_DATE_CHANGE_BATCH;
/**********************************************************/ 

	-- 국가별 언어코드에는 추가되어 있으나, 국가별 차종코드에는 추가되어 있지 않은 경우 데이터 업데이트 처리
	PROCEDURE SP_NATL_VEHL_LANG_UPDATE
	IS
	BEGIN
	
		BEGIN
			-- 국가별 언어코드에는 추가되어있으나, 국가별 차종코드에는 추가되지 않은 경우 처리
			INSERT INTO TB_NATL_VEHL_MGMT
			SELECT
				DISTINCT
				  A.DL_EXPD_CO_CD
				, A.DL_EXPD_NAT_CD
				, A.QLTY_VEHL_CD
				, C.DL_EXPD_REGN_CD
				, '5900513'
				, SYSDATE
				, '5900513'
				, SYSDATE
			FROM TB_NATL_LANG_MGMT A
			LEFT OUTER JOIN TB_NATL_VEHL_MGMT B ON A.QLTY_VEHL_CD = B.QLTY_VEHL_CD AND A.DL_EXPD_NAT_CD = B.DL_EXPD_NAT_CD
			INNER JOIN TB_NATL_MGMT C ON A.DL_EXPD_CO_CD = C.DL_EXPD_CO_CD AND A.DL_EXPD_NAT_CD = C.DL_EXPD_NAT_CD
			WHERE B.QLTY_VEHL_CD IS NULL
			;
			
			COMMIT;
		END;
		
		BEGIN
			-- 국가코드관리에서는 국가별 차종/언어 설정이 추가되어 있으나 
			-- 언어코드 관리 화면에 차종별 언어 설정이 없는 경우 추가 처리
			MERGE INTO TB_LANG_MGMT A
			USING (
				SELECT
					ROWNUM + A.DATA_SN DATA_SN,
					QLTY_VEHL_CD,
					MDL_MDY_CD,
					LANG_CD,
					DL_EXPD_REGN_CD,
					LANG_CD_NM,
					USE_YN,
					NAPC_YN,
					PPRR_EENO,
					FRAM_DTM,
					UPDR_EENO,
					MDFY_DTM,
					SORT_SN,
					A_CODE,
					N1_INS_YN,
					ET_YN
				FROM (
					SELECT
						DISTINCT
						(SELECT NVL(MAX(DATA_SN), 0) FROM TB_LANG_MGMT) DATA_SN,
						A.QLTY_VEHL_CD,
						A.MDL_MDY_CD,
						A.LANG_CD,
						D.DL_EXPD_REGN_CD,
						D.LANG_CD_NM,
						'Y' USE_YN,
						'N' NAPC_YN,
						'SYSTEM' PPRR_EENO,
						SYSDATE FRAM_DTM,
						'' UPDR_EENO,
						'' MDFY_DTM,
						'' SORT_SN,
						'' A_CODE,
						'N' N1_INS_YN,
						'' ET_YN
					FROM TB_NATL_LANG_MGMT A
					LEFT OUTER JOIN TB_LANG_MGMT B ON (A.QLTY_VEHL_CD = B.QLTY_VEHL_CD AND A.MDL_MDY_CD = B.MDL_MDY_CD AND A.LANG_CD = B.LANG_CD)
					INNER JOIN TB_NATL_MGMT C ON (A.DL_EXPD_CO_CD = C.DL_EXPD_CO_CD AND A.DL_EXPD_NAT_CD = C.DL_EXPD_NAT_CD)
					INNER JOIN TB_LANG_MAST D ON (A.LANG_CD = D.LANG_CD)
					WHERE B.QLTY_VEHL_CD IS NULL
						AND A.MDL_MDY_CD >= TO_CHAR(SYSDATE - (365*2), 'YY')
				) A
			) B
			ON (A.QLTY_VEHL_CD = B.QLTY_VEHL_CD AND A.MDL_MDY_CD = B.MDL_MDY_CD AND A.LANG_CD = B.LANG_CD)
			WHEN NOT MATCHED THEN
				INSERT
				(DATA_SN,
			     QLTY_VEHL_CD,
			     MDL_MDY_CD,
			     LANG_CD,
			     DL_EXPD_REGN_CD,
			     LANG_CD_NM,
			     USE_YN,
			     NAPC_YN,
			     PPRR_EENO,
			     FRAM_DTM,
			     UPDR_EENO,
			     MDFY_DTM,
			     SORT_SN,
			     A_CODE,
			     N1_INS_YN,
			     ET_YN
			    )
			    VALUES
				(B.DATA_SN,
			     B.QLTY_VEHL_CD,
			     B.MDL_MDY_CD,
			     B.LANG_CD,
			     B.DL_EXPD_REGN_CD,
			     B.LANG_CD_NM,
			     B.USE_YN,
			     B.NAPC_YN,
			     B.PPRR_EENO,
			     B.FRAM_DTM,
			     B.UPDR_EENO,
			     B.MDFY_DTM,
			     B.SORT_SN,
			     B.A_CODE,
			     B.N1_INS_YN,
			     B.ET_YN
			    )
			;
			
			COMMIT;
		END;
	
	END SP_NATL_VEHL_LANG_UPDATE;

END PG_DATA;