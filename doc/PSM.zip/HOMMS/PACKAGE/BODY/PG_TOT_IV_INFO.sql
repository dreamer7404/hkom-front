CREATE OR REPLACE PACKAGE BODY PG_TOT_IV_INFO AS
	   
	   --별도요청정보저장 
	   PROCEDURE SP_EXTRA_REQ_SAVE(P_VEHL_CD        VARCHAR2,
	   			 			       P_MDL_MDY_CD     VARCHAR2,
							       P_LANG_CD        VARCHAR2,
								   P_EXPD_RQ_SCN_CD VARCHAR2,
							       P_CRGR_EENO      VARCHAR2,
							       P_RQ_QTY		    NUMBER,
							       P_PWMR_EENO      VARCHAR2,
							       P_RQ_RSON_SBC    VARCHAR2,
							       P_USER_EENO      VARCHAR2)
       IS
	   	 
		 V_CURR_YMD VARCHAR2(8);
		 
		 V_DATA_SN  NUMBER(7);
		 
		 V_DTL_SN   NUMBER(11);
		 
		 V_MAIL_TITLE   VARCHAR2(8000);
		 V_MAIL_CONTENT VARCHAR2(8000);
		 
		 V_QLTY_VEHL_NM TB_VEHL_MGMT.QLTY_VEHL_NM%TYPE;
		 V_LANG_CD_NM	TB_LANG_MGMT.LANG_CD_NM%TYPE;
		 
	   BEGIN
	   		
			V_CURR_YMD := TO_CHAR(SYSDATE, 'YYYYMMDD');
			
			SELECT A.DATA_SN,
			       B.QLTY_VEHL_NM,
				   --A.LANG_CD_NM 
				   CASE WHEN A.A_CODE IS NULL THEN '(' || A.LANG_CD || ')'
						ELSE '(' || A.LANG_CD || '-' || A.A_CODE || ')' 
				   END || A.LANG_CD_NM AS LANG_CD_NM
			INTO V_DATA_SN,
			     V_QLTY_VEHL_NM,
			     V_LANG_CD_NM
		    FROM TB_LANG_MGMT A,
			     TB_VEHL_MGMT B
			WHERE A.QLTY_VEHL_CD = P_VEHL_CD
			AND A.MDL_MDY_CD = P_MDL_MDY_CD
			AND A.LANG_CD = P_LANG_CD
			AND A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
			AND A.MDL_MDY_CD = B.MDL_MDY_CD;
			
			INSERT INTO TB_EXTRA_REQ_INFO
			(RQ_YMD,
			 DATA_SN,
			 DTL_SN,
			 QLTY_VEHL_CD,
			 MDL_MDY_CD,
			 LANG_CD,
			 DL_EXPD_RQ_SCN_CD,
			 --CRGR_EENO, --담당자가 여러명인 경우가 있으므로 그냥 담당자정보는 저장하지 않는다. 
			 RQ_QTY,
			 PWMR_EENO,
			 RQ_RSON_SBC,
			 PPRR_EENO,
			 FRAM_DTM,
			 UPDR_EENO,
			 MDFY_DTM,
			 DLVG_YN
			)
			SELECT V_CURR_YMD,
				   V_DATA_SN,
				   NVL(MAX(DTL_SN), 0) + 1,
				   P_VEHL_CD,
				   P_MDL_MDY_CD,
				   P_LANG_CD,
				   P_EXPD_RQ_SCN_CD,
				   --P_CRGR_EENO,
				   P_RQ_QTY,
				   P_PWMR_EENO,
				   P_RQ_RSON_SBC,
				   P_USER_EENO,
				   SYSDATE,
				   P_USER_EENO,
				   SYSDATE,
				   'N'
			FROM TB_EXTRA_REQ_INFO
			WHERE RQ_YMD = V_CURR_YMD
			AND DATA_SN = V_DATA_SN;
			
			--메일 발송 
			V_MAIL_TITLE   := '오너스매뉴얼 별도 요청합니다.';
			V_MAIL_CONTENT := '다음의 차종/언어에 대한 취급 설명서 별도 요청합니다.<br>' ||
							  '차종    : (' || P_VEHL_CD || ')' || V_QLTY_VEHL_NM || '-' || P_MDL_MDY_CD || 'MY<br>' ||
							  --'언어    : (' || P_LANG_CD || ')' || V_LANG_CD_NM || '<br>' ||
							  '언어    : ' || V_LANG_CD_NM || '<br>' ||
							  '수량    : ' || TO_CHAR(P_RQ_QTY) || '부<br>' ||
							  '특이사항: ' || P_RQ_RSON_SBC || '<br>';
							  
			SP_SEND_MAIL(P_VEHL_CD, P_MDL_MDY_CD, P_EXPD_RQ_SCN_CD, P_PWMR_EENO, V_MAIL_TITLE, V_MAIL_CONTENT);
			
	   END SP_EXTRA_REQ_SAVE;
	   
	   PROCEDURE SP_EXTRA_REQ_SAVE2(P_VEHL_CD        VARCHAR2,
	   			 			        P_MDL_MDY_CD     VARCHAR2,
							        P_LANG_CD        VARCHAR2,
							        P_EXPD_RQ_SCN_CD VARCHAR2,
							        P_CRGR_EENO      VARCHAR2,
							        P_RQ_QTY		 NUMBER,
							        P_PWMR_EENO      VARCHAR2,
							        P_RQ_RSON_SBC    VARCHAR2,
							        P_USER_EENO      VARCHAR2)
	   IS
	   	 
		 V_EXPD_RQ_SCN_CD VARCHAR2(4);
		 
	   BEGIN
	   		
			--세화를 선택한 경우 
			IF P_EXPD_RQ_SCN_CD = '01' THEN
			   
			   V_EXPD_RQ_SCN_CD := '03';
			
			--PDI/글로비스를 선택한 경우 
			ELSE
			   
			   --언어코드가 한글인 경우에는 글로비스로 전달하도록 한다. 
			   IF P_LANG_CD = 'KO' THEN
			   	  
				  V_EXPD_RQ_SCN_CD := '05';
				  
			   ELSE
			   	   
				   V_EXPD_RQ_SCN_CD := '04';
				   
			   END IF;
			   
			END IF;
			
			SP_EXTRA_REQ_SAVE(P_VEHL_CD,
	   			 			  P_MDL_MDY_CD,
							  P_LANG_CD,
							  V_EXPD_RQ_SCN_CD,
							  P_CRGR_EENO,
							  P_RQ_QTY,
							  P_PWMR_EENO,
							  P_RQ_RSON_SBC,
							  P_USER_EENO);
									
	   END SP_EXTRA_REQ_SAVE2;
	   
	   --별도요청 출고 정보 저장 							   
   	   PROCEDURE SP_EXTRA_REQ_UPDATE(P_VEHL_CD         VARCHAR2,
	   			 			         P_MDL_MDY_CD      VARCHAR2,
							         P_LANG_CD         VARCHAR2,
								     P_N_PRNT_PBCN_NO  VARCHAR2,
								     P_EXPD_RQ_SCN_CD  VARCHAR2,	 
								     P_RQ_QTY          NUMBER,
									 P_PREV_RQ_QTY	   NUMBER,
								     P_USER_EENO       VARCHAR2)
	   IS
	   
	   	 V_RQ_YMD VARCHAR2(8);
		 V_DTL_SN NUMBER;
		 
	   BEGIN
	   		
			--이전에 이미 요청등록 처리한 항목에 대한 출고정보를 취소해 준다. 
			IF P_PREV_RQ_QTY IS NOT NULL THEN
			   
			   SELECT MIN(RQ_YMD)
			   INTO V_RQ_YMD
			   FROM TB_EXTRA_REQ_INFO
			   WHERE QLTY_VEHL_CD = P_VEHL_CD
			   AND MDL_MDY_CD = P_MDL_MDY_CD
			   AND LANG_CD = P_LANG_CD
			   AND DL_EXPD_RQ_SCN_CD = P_EXPD_RQ_SCN_CD
			   AND RQ_QTY = P_PREV_RQ_QTY
			   AND DLVG_YN = 'Y'
			   AND N_PRNT_PBCN_NO = P_N_PRNT_PBCN_NO;
			
			   IF V_RQ_YMD IS NOT NULL THEN
			   
			   	  SELECT MIN(DTL_SN)
			   	  INTO V_DTL_SN
			   	  FROM TB_EXTRA_REQ_INFO
			   	  WHERE RQ_YMD = V_RQ_YMD
			   	  AND QLTY_VEHL_CD = P_VEHL_CD
			   	  AND MDL_MDY_CD = P_MDL_MDY_CD
			   	  AND LANG_CD = P_LANG_CD
			   	  AND DL_EXPD_RQ_SCN_CD = P_EXPD_RQ_SCN_CD
			   	  AND RQ_QTY = P_PREV_RQ_QTY
			   	  AND DLVG_YN = 'Y'
			   	  AND N_PRNT_PBCN_NO = P_N_PRNT_PBCN_NO;
			   
			   	  IF V_DTL_SN IS NOT NULL THEN
			   	  
				  	 UPDATE TB_EXTRA_REQ_INFO
				  	 SET DLVG_YN = 'N',
			          	 UPDR_EENO = P_USER_EENO,
					  	 MDFY_DTM = SYSDATE
				  	 WHERE RQ_YMD = V_RQ_YMD
			      	 AND QLTY_VEHL_CD = P_VEHL_CD
				  	 AND MDL_MDY_CD = P_MDL_MDY_CD
				  	 AND LANG_CD = P_LANG_CD
				  	 AND DTL_SN = V_DTL_SN;   
			
			   	  END IF;
			   
			   END IF;
			
			END IF;
			
			IF P_RQ_QTY IS NOT NULL THEN
			    
			   SELECT MIN(RQ_YMD)
			   INTO V_RQ_YMD
			   FROM TB_EXTRA_REQ_INFO
			   WHERE QLTY_VEHL_CD = P_VEHL_CD
			   AND MDL_MDY_CD = P_MDL_MDY_CD
			   AND LANG_CD = P_LANG_CD
			   AND DL_EXPD_RQ_SCN_CD = P_EXPD_RQ_SCN_CD
			   AND RQ_QTY = P_RQ_QTY
			   AND DLVG_YN = 'N';
			   
			   IF V_RQ_YMD IS NOT NULL THEN
			   
			   	  SELECT MIN(DTL_SN)
			   	  INTO V_DTL_SN
			   	  FROM TB_EXTRA_REQ_INFO
			   	  WHERE RQ_YMD = V_RQ_YMD
			   	  AND QLTY_VEHL_CD = P_VEHL_CD
			   	  AND MDL_MDY_CD = P_MDL_MDY_CD
			   	  AND LANG_CD = P_LANG_CD
			   	  AND DL_EXPD_RQ_SCN_CD = P_EXPD_RQ_SCN_CD
			   	  AND RQ_QTY = P_RQ_QTY
			   	  AND DLVG_YN = 'N';
			   
			   	  IF V_DTL_SN IS NOT NULL THEN
			   	  
				  	 UPDATE TB_EXTRA_REQ_INFO
				  	 SET DLVG_YN = 'Y',
				  	  	 N_PRNT_PBCN_NO = P_N_PRNT_PBCN_NO,
			          	 UPDR_EENO = P_USER_EENO,
					  	 MDFY_DTM = SYSDATE
				  	 WHERE RQ_YMD = V_RQ_YMD
			      	 AND QLTY_VEHL_CD = P_VEHL_CD
				  	 AND MDL_MDY_CD = P_MDL_MDY_CD
				  	 AND LANG_CD = P_LANG_CD
				  	 AND DTL_SN = V_DTL_SN;   
			
			      END IF;
			   
			   END IF;
			
			END IF;

	   END SP_EXTRA_REQ_UPDATE;
								 			   
	   --총재고 조회(PDI, 차종, 연식, 지역, 언어) 
	   PROCEDURE SP_GET_TOT_IV_INFO(P_MENU_ID 	   VARCHAR2,
								    P_USER_EENO    VARCHAR2,
								    P_CURR_YMD	   VARCHAR2,
									P_EXPD_CO_CD   VARCHAR2,
 								    P_PDI_CD	   VARCHAR2,
								    P_VEHL_CD	   VARCHAR2,
								    P_MDL_MDY	   VARCHAR2,
								    P_REGN_CD	   VARCHAR2,
								    P_LANG_CD	   VARCHAR2,
								    P_IV_STATE     VARCHAR2,
                                    RS 			   OUT REFCUR,
                                    P_MESSAGE      OUT VARCHAR2)
	   IS
	   	 
		 V_MESSAGE VARCHAR2(8000);
		 
	   BEGIN
			
			SP_GET_MESSAGE(P_CURR_YMD, V_MESSAGE);
			
			P_MESSAGE := V_MESSAGE;
			
			SP_GET_TOT_IV_INFO2(P_MENU_ID,
								P_USER_EENO,
								P_CURR_YMD,
								P_EXPD_CO_CD,
								'ALL',
								P_PDI_CD,
								P_VEHL_CD,
								P_MDL_MDY,
								P_REGN_CD,
								P_LANG_CD,
								P_IV_STATE,
								RS);
                        
								  
	   END SP_GET_TOT_IV_INFO;
	   
	   --총재고 조회(승상구분, PDI, 차종, 연식, 지역, 언어)
	   PROCEDURE SP_GET_TOT_IV_INFO2(P_MENU_ID 	    VARCHAR2,
								     P_USER_EENO 	VARCHAR2,
								     P_CURR_YMD	    VARCHAR2,
									 P_EXPD_CO_CD   VARCHAR2,
								     P_PAC_SCN_CD	VARCHAR2,
 								     P_PDI_CD		VARCHAR2,
								     P_VEHL_CD	    VARCHAR2,
								     P_MDL_MDY	    VARCHAR2,
								     P_REGN_CD	    VARCHAR2,
								     P_LANG_CD	    VARCHAR2,
								     P_IV_STATE     VARCHAR2,
                                     RS 		  OUT REFCUR)
	   IS
	   	  
		  V_FROM_MDL_MDY VARCHAR2(2);
		  V_TO_MDL_MDY   VARCHAR2(2);
		  
--	   	  V_CURR_DATE	DATE;

--          V_CURR_PACK	VARCHAR2(4);
--          V_PREV_PACK	VARCHAR2(4);

--		  V_PREV_YEAR_YMD VARCHAR2(8);  --1년전 현재월 1일 날짜
--		  V_PREV_3MTH_YMD VARCHAR2(8);  --3개월전 1일 날짜
--		  V_PREV_1MTH_YMD VARCHAR2(8);  --1개월전 마지막 날짜
--		  V_PREV_1DAY_YMD VARCHAR2(8);  --어제 날짜
--		  V_CURR_FSTD_YMD VARCHAR2(8);  --현재월 1일 날짜
--		  V_NEXT_2WEK_YMD VARCHAR2(8);  --2주 후 날짜

	   BEGIN
	   	  
		  PG_COMMON.SP_GET_VALID_MDL_MDY4(P_CURR_YMD, '', V_FROM_MDL_MDY, V_TO_MDL_MDY);
		  
--		  V_CURR_DATE := TO_DATE(P_CURR_YMD, 'YYYYMMDD');

--		  V_CURR_PACK := TO_CHAR(V_CURR_DATE, 'YYMM');
--		  V_PREV_PACK := TO_CHAR(ADD_MONTHS(V_CURR_DATE, -1), 'YYMM');

--		  V_PREV_YEAR_YMD := TO_CHAR(ADD_MONTHS(V_CURR_DATE, -12), 'YYYYMM') || '01';
--		  V_PREV_3MTH_YMD := TO_CHAR(ADD_MONTHS(V_CURR_DATE, -3), 'YYYYMM') || '01';
--		  V_PREV_1MTH_YMD := TO_CHAR(LAST_DAY(ADD_MONTHS(V_CURR_DATE, -1)), 'YYYYMMDD');
--		  V_PREV_1DAY_YMD := TO_CHAR(V_CURR_DATE - 1, 'YYYYMMDD');
--		  V_CURR_FSTD_YMD := TO_CHAR(V_CURR_DATE, 'YYYYMM') || '01';
--		  V_NEXT_2WEK_YMD := TO_CHAR(V_CURR_DATE + 13, 'YYYYMMDD');

		  OPEN RS FOR
		  	   WITH T AS (SELECT A.CL_SCN_CD,
			          	 		 C.DATA_SN,
			  					 C.QLTY_VEHL_CD,
                                 C.MDL_MDY_CD,
                                 C.LANG_CD,
                                 --'(' || C.QLTY_VEHL_CD || ')' || B.QLTY_VEHL_NM || '-' || C.MDL_MDY_CD || 'MY' AS QLTY_VEHL_NM,
								 C.QLTY_VEHL_CD || '-' || C.MDL_MDY_CD AS QLTY_VEHL_NM,
                                 --C.LANG_CD_NM,
								 '(' || C.LANG_CD || ')' || C.LANG_CD_NM AS LANG_CD_NM,
                                 C.DL_EXPD_REGN_CD,
								 C.SORT_SN AS LANG_SORT_SN
                          FROM (SELECT QLTY_VEHL_CD,
                                       MAX(CL_SCN_CD) AS CL_SCN_CD
                                FROM TB_AUTH_VEHL_MGMT
                                WHERE MENU_ID = PG_COMMON.FU_RPAD(P_MENU_ID, 10)
                                AND USER_EENO = PG_COMMON.FU_RPAD(P_USER_EENO, 7)
                                AND QLTY_VEHL_CD = DECODE(P_VEHL_CD, 'ALL', QLTY_VEHL_CD, P_VEHL_CD)
                                GROUP BY QLTY_VEHL_CD
                               ) A,
                               TB_VEHL_MGMT B,
                               TB_LANG_MGMT C
                          WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
                          AND A.QLTY_VEHL_CD = C.QLTY_VEHL_CD
                          AND B.MDL_MDY_CD = C.MDL_MDY_CD
                          AND B.MDL_MDY_CD BETWEEN V_FROM_MDL_MDY AND V_TO_MDL_MDY
                          AND B.MDL_MDY_CD = DECODE(P_MDL_MDY , '', B.MDL_MDY_CD, P_MDL_MDY)
						  AND B.DL_EXPD_CO_CD = DECODE(P_EXPD_CO_CD, 'ALL', B.DL_EXPD_CO_CD, P_EXPD_CO_CD)
						  AND B.DL_EXPD_PAC_SCN_CD = DECODE(P_PAC_SCN_CD, 'ALL', B.DL_EXPD_PAC_SCN_CD, P_PAC_SCN_CD)
                          AND B.DL_EXPD_PDI_CD = DECODE(P_PDI_CD, 'ALL', B.DL_EXPD_PDI_CD, P_PDI_CD)
						  AND C.DL_EXPD_REGN_CD = DECODE(P_REGN_CD, 'ALL', C.DL_EXPD_REGN_CD, P_REGN_CD)
                          AND C.LANG_CD = DECODE(P_LANG_CD, 'ALL', C.LANG_CD, P_LANG_CD)
						  AND B.USE_YN = 'Y'
						  AND C.USE_YN = 'Y'
                         )		 
			   SELECT A.CL_SCN_CD,
			   		  A.DATA_SN,
					  A.QLTY_VEHL_CD,
					  A.MDL_MDY_CD,
					  A.LANG_CD,
					  A.DL_EXPD_REGN_CD,
					  A.QLTY_VEHL_NM,
					  A.LANG_CD_NM,
					  A.DL_EXPD_REGN_NM,
					  A.CURR_ORD_QTY,
					  A.PREV_ORD_QTY,
					  A.MTH3_TRWI_QTY,
					  A.DAY3_PLAN_QTY,
					  A.WEK2_PLAN_QTY,
					  A.CURR_MTH_TRWI_QTY,
					  A.PREV_1DAY_TRWI_QTY,
					  A.SEWHA_IV_QTY,
					  A.SEWHA_PRNT_YN,  
					  A.PDI_IV_QTY,
					  A.DSID14_QTY,
					  WEK2_AFTR_IV_QTY,
					  A.PRNT_STATE,
			          B.DL_EXPD_PRVS_NM AS PRNT_STATE_NM,
					  IV_SUM,
					  N_PRNT_PBCN_NO,
					  PLNT_DAY3_QTY_TEXT,
					  PLNT_WEK2_QTY_TEXT,
					  PLNT_YN
			   FROM (SELECT A.CL_SCN_CD,
			   		        A.DATA_SN,
					        A.QLTY_VEHL_CD,
					        A.MDL_MDY_CD,
					        A.LANG_CD,
					        A.DL_EXPD_REGN_CD,
					        A.QLTY_VEHL_NM,
					        A.LANG_CD_NM,
					        B.DL_EXPD_PRVS_NM AS DL_EXPD_REGN_NM,
					        A.CURR_ORD_QTY,
					        A.PREV_ORD_QTY,
					        A.MTH3_TRWI_QTY,
					        A.DAY3_PLAN_QTY,
					        A.WEK2_PLAN_QTY,
					        A.CURR_MTH_TRWI_QTY,
					        A.PREV_1DAY_TRWI_QTY,
					        A.SEWHA_IV_QTY,
					        A.SEWHA_PRNT_YN, --세화 인쇄중 데이터 존재여부 확인 
					        A.PDI_IV_QTY,
					        A.DSID14_QTY,
					        (A.SEWHA_IV_QTY + A.PDI_IV_QTY - A.WEK2_PLAN_QTY) AS WEK2_AFTR_IV_QTY,
						    CASE WHEN A.WEK2_PLAN_QTY <= (A.SEWHA_IV_QTY + A.PDI_IV_QTY - A.WEK2_PLAN_QTY) THEN '01'
								 WHEN A.WEK2_PLAN_QTY * 0.5 >= (A.SEWHA_IV_QTY + A.PDI_IV_QTY - A.WEK2_PLAN_QTY) THEN '04'
								 ELSE '02' END AS PRNT_STATE,
							NVL(A.SEWHA_IV_QTY, 0) + NVL(A.PDI_IV_QTY, 0) AS IV_SUM,
							N_PRNT_PBCN_NO,
							PLNT_DAY3_QTY_TEXT,
							PLNT_WEK2_QTY_TEXT,
							PLNT_YN
			         FROM (SELECT A.CL_SCN_CD,
			   				      A.DATA_SN,
							      A.QLTY_VEHL_CD,
							      A.MDL_MDY_CD,
							      A.LANG_CD,
							      A.DL_EXPD_REGN_CD,
							      A.QLTY_VEHL_NM,
							      A.LANG_CD_NM,
								  A.LANG_SORT_SN,
			   				      NVL(B.CURR_ORD_QTY, 0) AS CURR_ORD_QTY,
							      NVL(B.PREV_ORD_QTY, 0) AS PREV_ORD_QTY,
							      NVL(B.MTH3_TRWI_QTY, 0) AS MTH3_TRWI_QTY,
							      --CASE WHEN NVL(B.DAY3_PLAN_QTY1, 0) > NVL(B.DAY3_PLAN_QTY2, 0) THEN NVL(B.DAY3_PLAN_QTY1, 0)
								  --     ELSE NVL(B.DAY3_PLAN_QTY2, 0)
								  --END AS DAY3_PLAN_QTY,
								  NVL(B.DAY3_PLAN_QTY1, 0) AS DAY3_PLAN_QTY,
							      NVL(B.WEK2_PLAN_QTY, 0) AS WEK2_PLAN_QTY,
							      NVL(B.CURR_MTH_TRWI_QTY, 0) AS CURR_MTH_TRWI_QTY,
							      NVL(B.PREV_1DAY_TRWI_QTY, 0) AS PREV_1DAY_TRWI_QTY,
							      NVL(C.SEWHA_IV_QTY, 0) AS SEWHA_IV_QTY,
							      NVL(C.SEWHA_PRNT_YN, 'N') AS SEWHA_PRNT_YN,
							      NVL(D.PDI_IV_QTY, 0) AS PDI_IV_QTY,
							      NVL(B.DSID14_QTY, 0) AS DSID14_QTY,
								  NVL(CASE WHEN C.N_PRNT_PBCN_NO IS NULL THEN D.N_PRNT_PBCN_NO ELSE C.N_PRNT_PBCN_NO END, '') AS N_PRNT_PBCN_NO,
								  NVL(B.TDD_PRDN_QTY, 0) AS TDD_PRDN_QTY,
								  NVL(E.PLNT_DAY3_QTY_TEXT, ' ') AS PLNT_DAY3_QTY_TEXT,
								  NVL(E.PLNT_WEK2_QTY_TEXT, ' ') AS PLNT_WEK2_QTY_TEXT,
								  NVL(E.PLNT_YN, 'N') AS PLNT_YN
						   FROM T A,
						        (SELECT A.QLTY_VEHL_CD, 
										A.MDL_MDY_CD, 
										A.LANG_CD,
										NVL(B.TMM_ORD_QTY, 0) AS CURR_ORD_QTY,
										NVL(B.BORD_QTY, 0) AS PREV_ORD_QTY,
										NVL(B.MTH3_MO_AVG_TRWI_QTY, 0) AS MTH3_TRWI_QTY,
										NVL(B.TDD_PRDN_PLN_QTY, 0) + NVL(B.TDD_PRDN_QTY3, 0) AS DAY3_PLAN_QTY1,
										--NVL(B.TDD_PRDN_QTY, 0) AS DAY3_PLAN_QTY2,
							      		NVL(B.WEK2_PRDN_PLN_QTY, 0) + NVL(B.TDD_PRDN_QTY3, 0) AS WEK2_PLAN_QTY,
								  		NVL(B.TMM_TRWI_QTY, 0) AS CURR_MTH_TRWI_QTY,
								  		NVL(B.BOD_TRWI_QTY, 0) AS PREV_1DAY_TRWI_QTY,
										CASE WHEN C.DSID141_QTY  IS NULL THEN NVL(B.YER1_DLY_AVG_TRWI_QTY, 0) * 14
								             ELSE C.DSID141_QTY  END AS DSID14_QTY,
										--생산계획, 재고, 투입수량이 없더라도 라인진행중인 물량이 있으면 화면에 표시해 주기 위한 항목
										--NVL(B.TDD_PRDN_QTY, 0) AS TDD_PRDN_QTY 
										--[변경]. 2009.10.29.김동근 현재 현업의 요청사항과 맞지 않아서 값을 무조건 0 으로 처리함 
										0 AS TDD_PRDN_QTY
								 FROM T A,
						         	  TB_APS_PROD_SUM_INFO B,
									  TB_SFTY_IV_MGMT C
						         WHERE A.DATA_SN = B.DATA_SN
						   		 AND B.APL_YMD = P_CURR_YMD
						   		 AND A.QLTY_VEHL_CD = C.QLTY_VEHL_CD(+)
                           		 AND A.MDL_MDY_CD = C.MDL_MDY_CD(+)
                           		 AND A.LANG_CD = C.LANG_CD(+)
								) B,
								--세화재고
        				        (SELECT A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD, SUM(B.SFTY_IV_QTY) AS SEWHA_IV_QTY,
						                --인쇄중 데이터 존재 여부 확인 ==> DL_EXPD_TMP_IV_QTY 값은 Default값은  인쇄 수량, 납품이후에는 0으로 설정되어 있음 
						  		        CASE WHEN SUM(B.DL_EXPD_TMP_IV_QTY) > 0 THEN 'Y' ELSE 'N'END AS SEWHA_PRNT_YN,
										MAX(B.N_PRNT_PBCN_NO) AS N_PRNT_PBCN_NO
         				         FROM T A,
              				          TB_SEWHA_IV_INFO_DTL B
         				         WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
         				         AND A.MDL_MDY_CD = B.MDL_MDY_CD
         				         AND A.LANG_CD = B.LANG_CD
         				         AND B.CLS_YMD = P_CURR_YMD
								 AND B.SFTY_IV_QTY > 0 --안전재고수량이 없는 것은 가져오지 않는다. 
						         GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD 
								
								 /*** 
								 SELECT A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD, SUM(IV_QTY) AS SEWHA_IV_QTY,
						                --인쇄중 데이터 존재 여부 확인 ==> DL_EXPD_TMP_IV_QTY 값은 Default값은  인쇄 수량, 납품이후에는 0으로 설정되어 있음 
						  		        CASE WHEN SUM(DL_EXPD_TMP_IV_QTY) > 0 THEN 'Y' ELSE 'N'END AS SEWHA_PRNT_YN,
										MAX(C.N_PRNT_PBCN_NO) AS N_PRNT_PBCN_NO
         				         FROM T A,
              		   		          TB_DL_EXPD_MDY_MGMT B,
              				          TB_SEWHA_IV_INFO C
         				         WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
         				         AND A.MDL_MDY_CD = B.MDL_MDY_CD
         				         AND A.QLTY_VEHL_CD = C.QLTY_VEHL_CD
         				         AND B.DL_EXPD_MDL_MDY_CD = C.DL_EXPD_MDL_MDY_CD
         				         AND A.LANG_CD = C.LANG_CD
         				         AND C.CLS_YMD = P_CURR_YMD
						         GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD 
								 ***/
								 
                                ) C,
                                --PDI재고
                                (SELECT A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD, SUM(B.SFTY_IV_QTY) AS PDI_IV_QTY,
								        MAX(B.N_PRNT_PBCN_NO) AS N_PRNT_PBCN_NO
                                 FROM T A,
                                      TB_PDI_IV_INFO_DTL B
                                 WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
                                 AND A.MDL_MDY_CD = B.MDL_MDY_CD
                                 AND A.LANG_CD = B.LANG_CD
                                 AND B.CLS_YMD = P_CURR_YMD
								 AND B.SFTY_IV_QTY > 0 --안전재고수량이 없는 것은 가져오지 않는다. 
						         GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD
								 
								 /***
								 SELECT A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD, SUM(IV_QTY) AS PDI_IV_QTY,
								        MAX(C.N_PRNT_PBCN_NO) AS N_PRNT_PBCN_NO
                                 FROM T A,
                                      TB_DL_EXPD_MDY_MGMT B,
                                      TB_PDI_IV_INFO C
                                 WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
                                 AND A.MDL_MDY_CD = B.MDL_MDY_CD
                                 AND A.QLTY_VEHL_CD = C.QLTY_VEHL_CD
                                 AND B.DL_EXPD_MDL_MDY_CD = C.DL_EXPD_MDL_MDY_CD
                                 AND A.LANG_CD = C.LANG_CD
                                 AND C.CLS_YMD = P_CURR_YMD
						         GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD
								 ***/
								 
                                ) D,
								(SELECT A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD,
										FU_GET_PLNT_DAY3_PLAN_QTY(P_CURR_YMD, A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD) AS PLNT_DAY3_QTY_TEXT,
										FU_GET_PLNT_WEK2_PLAN_QTY(P_CURR_YMD, A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD) AS PLNT_WEK2_QTY_TEXT,
										'Y' AS PLNT_YN
                                 FROM T A,
                                      TB_PLNT_APS_PROD_SUM_INFO B
                                 WHERE A.DATA_SN = B.DATA_SN
                                 AND B.APL_YMD = P_CURR_YMD
						         GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD
								) E
						   WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD(+)
                           AND A.MDL_MDY_CD = B.MDL_MDY_CD(+)
                           AND A.LANG_CD = B.LANG_CD(+)
                           AND A.QLTY_VEHL_CD = C.QLTY_VEHL_CD(+)
                           AND A.MDL_MDY_CD = C.MDL_MDY_CD(+)
                           AND A.LANG_CD = C.LANG_CD(+)
                           AND A.QLTY_VEHL_CD = D.QLTY_VEHL_CD(+)
                           AND A.MDL_MDY_CD = D.MDL_MDY_CD(+)
                           AND A.LANG_CD = D.LANG_CD(+)
						   AND A.QLTY_VEHL_CD = E.QLTY_VEHL_CD(+)
						   AND A.MDL_MDY_CD = E.MDL_MDY_CD(+)
						   AND A.LANG_CD = E.LANG_CD(+)
                           
					 	   /****  속도 개선을 위한 쿼리 변경 
					 	   SELECT A.CL_SCN_CD,
			   				      A.DATA_SN,
							      A.QLTY_VEHL_CD,
							      A.MDL_MDY_CD,
							      A.LANG_CD,
							      A.DL_EXPD_REGN_CD,
							      A.QLTY_VEHL_NM,
							      A.LANG_CD_NM,
			   				      NVL(B.CURR_ORD_QTY, 0) AS CURR_ORD_QTY,
							      NVL(C.PREV_ORD_QTY, 0) AS PREV_ORD_QTY,
							      NVL(D.MTH3_TRWI_QTY, 0) AS MTH3_TRWI_QTY,
							      NVL(E.DAY3_PLAN_QTY, 0) AS DAY3_PLAN_QTY,
							      NVL(F.WEK2_PLAN_QTY, 0) AS WEK2_PLAN_QTY,
							      NVL(G.CURR_MTH_TRWI_QTY, 0) AS CURR_MTH_TRWI_QTY,
							      NVL(H.PREV_1DAY_TRWI_QTY, 0) AS PREV_1DAY_TRWI_QTY,
							      NVL(I.SEWHA_IV_QTY, 0) AS SEWHA_IV_QTY,
							      NVL(I.SEWHA_PRNT_YN, 'N') AS SEWHA_PRNT_YN,
							      NVL(J.PDI_IV_QTY, 0) AS PDI_IV_QTY,
							      NVL(K.DSID14_QTY, 0) AS DSID14_QTY
			   		       FROM T A,
                                --당월수출오더 정보
                                (SELECT A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD, SUM(ORD_QTY) AS CURR_ORD_QTY
                                 FROM T A,
                                      TB_APS_ODR_SUM_INFO B
                                 WHERE B.APL_STRT_YMD <= P_CURR_YMD
                                 AND B.APL_FNH_YMD >= P_CURR_YMD
                                 AND A.DATA_SN = B.DATA_SN
                                 AND B.MO_PACK_CD = V_CURR_PACK
                                 GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD
                                ) B,
                                --B/오더
                                (SELECT A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD, SUM(PRDN_PLN_QTY) AS PREV_ORD_QTY
                                 FROM T A,
                                      TB_APS_ODR_SUM_INFO B
                                 WHERE B.APL_STRT_YMD <= P_CURR_YMD
                                 AND B.APL_FNH_YMD >= P_CURR_YMD
                                 AND A.DATA_SN = B.DATA_SN
                                 AND B.MO_PACK_CD <= V_PREV_PACK
                                 GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD
                                ) C,
                                --3개월 평균생산
                                (SELECT A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD, ROUND(SUM(PRDN_TRWI_QTY) / 3) AS MTH3_TRWI_QTY
                                 FROM T A,
                                      TB_PROD_MST_SUM_INFO B
                                 WHERE A.DATA_SN = B.DATA_SN
                                 AND B.APL_YMD BETWEEN V_PREV_3MTH_YMD AND V_PREV_1MTH_YMD
                                 GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD
                                ) D,
                                --단기계획(3일)
                                (SELECT A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD, SUM(NVL(B.PRDN_PLN_QTY, 0) + NVL(C.PRDN_QTY, 0)) AS DAY3_PLAN_QTY
                                 FROM T A,
                                      TB_APS_PROD_PLAN_SUM_INFO B,
                                      TB_PROD_MST_SUM_INFO C
                                 WHERE A.DATA_SN = B.DATA_SN(+)
                                 AND A.DATA_SN = C.DATA_SN(+)
                                 AND B.APL_STRT_YMD(+) <= P_CURR_YMD
                                 AND B.APL_FNH_YMD(+) >= P_CURR_YMD
                                 AND B.PLN_PARR_YMD(+) = P_CURR_YMD
                                 AND C.APL_YMD(+) = P_CURR_YMD
                                 GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD
                                ) E,
                                --생산계획(2주)
                                (SELECT A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD, SUM(PRDN_PLN_QTY) AS WEK2_PLAN_QTY
                                 FROM T A,
                                      TB_APS_PROD_PLAN_SUM_INFO B
                                 WHERE A.DATA_SN = B.DATA_SN
      				             AND B.APL_STRT_YMD <= P_CURR_YMD
                                 AND B.APL_FNH_YMD >= P_CURR_YMD
      				             AND B.PLN_PARR_YMD BETWEEN P_CURR_YMD AND V_NEXT_2WEK_YMD
      				             GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD
                                ) F,
        				        --당월투입
        				        (SELECT A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD, SUM(PRDN_TRWI_QTY) AS CURR_MTH_TRWI_QTY
         				         FROM T A,
              		                  TB_PROD_MST_SUM_INFO B
         				         WHERE A.DATA_SN = B.DATA_SN
      				             AND B.APL_YMD BETWEEN V_CURR_FSTD_YMD AND P_CURR_YMD
      				             GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD
        				        ) G,
      				            --전일투입
      				            (SELECT A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD, SUM(PRDN_TRWI_QTY) AS PREV_1DAY_TRWI_QTY
         				         FROM T A,
              		                  TB_PROD_MST_SUM_INFO B
         				         WHERE A.DATA_SN = B.DATA_SN
      				             AND B.APL_YMD = V_PREV_1DAY_YMD
      				             GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD
        				        ) H,
        				        --세화재고
        				        (SELECT A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD, SUM(IV_QTY) AS SEWHA_IV_QTY,
						                --인쇄중 데이터 존재 여부 확인 ==> DL_EXPD_TMP_IV_QTY 값은 Default값은  인쇄 수량, 납품이후에는 0으로 설정되어 있음 
						  		        CASE WHEN SUM(DL_EXPD_TMP_IV_QTY) > 0 THEN 'Y' ELSE 'N'END AS SEWHA_PRNT_YN
         				         FROM T A,
              		   		          TB_DL_EXPD_MDY_MGMT B,
              				          TB_SEWHA_IV_INFO C
         				         WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
         				         AND A.MDL_MDY_CD = B.MDL_MDY_CD
         				         AND A.QLTY_VEHL_CD = C.QLTY_VEHL_CD
         				         AND B.DL_EXPD_MDL_MDY_CD = C.DL_EXPD_MDL_MDY_CD
         				         AND A.LANG_CD = C.LANG_CD
         				         AND C.CLS_YMD = P_CURR_YMD
						         GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD
                                ) I,
                                --PDI재고
                                (SELECT A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD, SUM(IV_QTY) AS PDI_IV_QTY
                                 FROM T A,
                                      TB_DL_EXPD_MDY_MGMT B,
                                      TB_PDI_IV_INFO C
                                 WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
                                 AND A.MDL_MDY_CD = B.MDL_MDY_CD
                                 AND A.QLTY_VEHL_CD = C.QLTY_VEHL_CD
                                 AND B.DL_EXPD_MDL_MDY_CD = C.DL_EXPD_MDL_MDY_CD
                                 AND A.LANG_CD = C.LANG_CD
                                 AND C.CLS_YMD = P_CURR_YMD
						         GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD
                                ) J,
						        --안전재고 조회
						        (SELECT A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD,
						                CASE WHEN B.DSID141_QTY IS NULL THEN (SELECT NVL(ROUND((SUM(PRDN_TRWI_QTY) / 365 + 1.96 + STDDEV(PRDN_TRWI_QTY)) * 14), 0)
								  	   					  	 	  	          FROM TB_PROD_MST_SUM_INFO C
																	          WHERE C.DATA_SN = A.DATA_SN
																	          AND C.APL_YMD BETWEEN V_PREV_YEAR_YMD AND V_PREV_1MTH_YMD)
								             ELSE B.DSID141_QTY END AS DSID14_QTY
						         FROM T A,
						   		      TB_SFTY_IV_MGMT B
						         WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD(+)
                                 AND A.MDL_MDY_CD = B.MDL_MDY_CD(+)
                                 AND A.QLTY_VEHL_CD = B.QLTY_VEHL_CD(+)

						         
--						         SELECT QLTY_VEHL_CD, MDL_MDY_CD, LANG_CD,
--						  		        CASE WHEN DSID141_QTY  > 0 THEN DSID141_QTY ELSE DSID142_QTY END AS DSID14_QTY -- 확정안전재고에 값이 있으면 그것을 사용하고 없으면 이론안전재고를 사용한다.
--						         FROM (SELECT QLTY_VEHL_CD, MDL_MDY_CD, LANG_CD,
--						   				      SUM(DSID141_QTY) AS DSID141_QTY, --확정안전재고
--										      SUM(DSID142_QTY) AS DSID142_QTY  --이론안전재고(계산값)
--								       FROM (SELECT A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD,
--						                            B.DSID141_QTY, 0 AS DSID142_QTY
--						                     FROM T A,
--						   		                  TB_SFTY_IV_MGMT B
--						                     WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD(+)
--                                            AND A.MDL_MDY_CD = B.MDL_MDY_CD(+)
--                                             AND A.QLTY_VEHL_CD = B.QLTY_VEHL_CD(+)
--
--						                     UNION ALL
--
--								             SELECT A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD,
--						   		                    0 AS DSID141_QTY,
--											        ROUND((SUM(PRDN_TRWI_QTY) / 365 + 1.96 + STDDEV(PRDN_TRWI_QTY)) * 14) AS DSID142_QTY
--         				                     FROM T A,
--              		                              TB_PROD_MST_SUM_INFO B
--         				                     WHERE A.DATA_SN = B.DATA_SN
--      				                         AND B.APL_YMD BETWEEN V_PREV_YEAR_YMD AND V_PREV_1MTH_YMD
--									         GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD
--								            )
--      				                   GROUP BY QLTY_VEHL_CD, MDL_MDY_CD, LANG_CD
--								      )
							      
						        ) K
                           WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD(+)
                           AND A.MDL_MDY_CD = B.MDL_MDY_CD(+)
                           AND A.LANG_CD = B.LANG_CD(+)
                           AND A.QLTY_VEHL_CD = C.QLTY_VEHL_CD(+)
                           AND A.MDL_MDY_CD = C.MDL_MDY_CD(+)
                           AND A.LANG_CD = C.LANG_CD(+)
                           AND A.QLTY_VEHL_CD = D.QLTY_VEHL_CD(+)
                           AND A.MDL_MDY_CD = D.MDL_MDY_CD(+)
                           AND A.LANG_CD = D.LANG_CD(+)
                           AND A.QLTY_VEHL_CD = E.QLTY_VEHL_CD(+)
                           AND A.MDL_MDY_CD = E.MDL_MDY_CD(+)
                           AND A.LANG_CD = E.LANG_CD(+)
                           AND A.QLTY_VEHL_CD = F.QLTY_VEHL_CD(+)
                           AND A.MDL_MDY_CD = F.MDL_MDY_CD(+)
                           AND A.LANG_CD = F.LANG_CD(+)
                           AND A.QLTY_VEHL_CD = G.QLTY_VEHL_CD(+)
                           AND A.MDL_MDY_CD = G.MDL_MDY_CD(+)
                           AND A.LANG_CD = G.LANG_CD(+)
                           AND A.QLTY_VEHL_CD = H.QLTY_VEHL_CD(+)
                           AND A.MDL_MDY_CD = H.MDL_MDY_CD(+)
                           AND A.LANG_CD = H.LANG_CD(+)
                           AND A.QLTY_VEHL_CD = I.QLTY_VEHL_CD(+)
                           AND A.MDL_MDY_CD = I.MDL_MDY_CD(+)
                           AND A.LANG_CD = I.LANG_CD(+)
      			           AND A.QLTY_VEHL_CD = J.QLTY_VEHL_CD(+)
                           AND A.MDL_MDY_CD = J.MDL_MDY_CD(+)
                           AND A.LANG_CD = J.LANG_CD(+)
					       AND A.QLTY_VEHL_CD = K.QLTY_VEHL_CD(+)
                           AND A.MDL_MDY_CD = K.MDL_MDY_CD(+)
                           AND A.LANG_CD = K.LANG_CD(+) 
						   ****/
						   
			             ) A,
				         TB_CODE_MGMT B
			         WHERE A.DL_EXPD_REGN_CD = B.DL_EXPD_PRVS_CD
			         AND B.DL_EXPD_G_CD = '0008'
					 --[변경]. 200910.29. 김동근 최근3개월 생산수량은 값 존재 여부 확인 대상에서 제외한다. 
			         --AND CURR_ORD_QTY + PREV_ORD_QTY + MTH3_TRWI_QTY + DAY3_PLAN_QTY + WEK2_PLAN_QTY + CURR_MTH_TRWI_QTY +
			   	     --    PREV_1DAY_TRWI_QTY + SEWHA_IV_QTY + PDI_IV_QTY + TDD_PRDN_QTY > 0
					 AND CURR_ORD_QTY + PREV_ORD_QTY + DAY3_PLAN_QTY + WEK2_PLAN_QTY + CURR_MTH_TRWI_QTY +
			   	         PREV_1DAY_TRWI_QTY + SEWHA_IV_QTY + PDI_IV_QTY + TDD_PRDN_QTY > 0
			         --ORDER BY QLTY_VEHL_CD, B.SORT_SN, LANG_CD, MDL_MDY_CD 
					 ORDER BY QLTY_VEHL_CD, LANG_SORT_SN, MDL_MDY_CD
					) A,
				    TB_CODE_MGMT B
			    WHERE A.PRNT_STATE = B.DL_EXPD_PRVS_CD
				AND B.DL_EXPD_G_CD = '0016'
				AND A.PRNT_STATE = DECODE(P_IV_STATE, 'ALL', A.PRNT_STATE, P_IV_STATE);
			   
	   END SP_GET_TOT_IV_INFO2;
	   
	   --월간 오더 정보 조회 
	   PROCEDURE SP_GET_MTH_ODR_INFO(P_CURR_YMD VARCHAR2,
	   			 					 P_VEHL_CD	VARCHAR2,
								     P_MDL_MDY	VARCHAR2,
								     P_REGN_CD	VARCHAR2,
								     P_LANG_CD  VARCHAR2,
									 P_FROM_MTH VARCHAR2,
								     P_TO_MTH	VARCHAR2,
                                     RS OUT REFCUR,
                                     P_MESSAGE OUT VARCHAR2)
	   IS
	   	 
		 V_SCH_YMD  VARCHAR2(8);
		 V_MESSAGE  VARCHAR2(8000);
			
		 V_QUERY1 VARCHAR2(8000);
		 V_QUERY2 VARCHAR2(8000);
		 V_QUERY3 VARCHAR2(8000);
		 
		 V_FROM_PACK VARCHAR2(4);
		 V_TO_PACK   VARCHAR2(4);
		 
	   BEGIN
	   		
			SP_GET_MSG_ODR(P_VEHL_CD, P_MDL_MDY, P_CURR_YMD, V_SCH_YMD, V_MESSAGE);
			
			P_MESSAGE := V_MESSAGE;
			
	   		V_FROM_PACK := SUBSTR(P_FROM_MTH, 3, 4);
	   		V_TO_PACK   := SUBSTR(P_TO_MTH,   3, 4);
	   		
			V_QUERY1 := FU_GET_MTH_PACK_QRY(P_FROM_MTH, P_TO_MTH);
			
			V_QUERY2 := '';
			
			V_QUERY2 := V_QUERY2 || '(';
			V_QUERY2 := V_QUERY2 ||  'SELECT MAX(A.REGN_NM) AS REGN_NM,';
			V_QUERY2 := V_QUERY2 ||         'B.LANG_CD,';
			V_QUERY2 := V_QUERY2 ||         'MAX(A.LANG_CD_NM) AS LANG_CD_NM,';
			V_QUERY2 := V_QUERY2 ||         'MO_PACK_CD AS MTH,';
			V_QUERY2 := V_QUERY2 ||         'MAX(A.SORT_SN) AS SORT_SN,';
			V_QUERY2 := V_QUERY2 ||         'SUM(B.PRDN_PLN_QTY) AS QTY, ';
			V_QUERY2 := V_QUERY2 ||         'MAX(A.LANG_SORT_SN) AS LANG_SORT_SN ';
			V_QUERY2 := V_QUERY2 ||  'FROM (SELECT B.SORT_SN,';
			V_QUERY2 := V_QUERY2 ||               'DL_EXPD_PRVS_NM AS REGN_NM,';
			V_QUERY2 := V_QUERY2 ||               'LANG_CD,';
			V_QUERY2 := V_QUERY2 ||               'LANG_CD_NM,';
			V_QUERY2 := V_QUERY2 ||               'QLTY_VEHL_CD,';
			V_QUERY2 := V_QUERY2 ||               'MDL_MDY_CD,';
			V_QUERY2 := V_QUERY2 ||               'A.SORT_SN AS LANG_SORT_SN ';
	        V_QUERY2 := V_QUERY2 ||        'FROM TB_LANG_MGMT A,';
	        V_QUERY2 := V_QUERY2 ||             'TB_CODE_MGMT B ';
	        V_QUERY2 := V_QUERY2 ||        'WHERE A.DL_EXPD_REGN_CD = B.DL_EXPD_PRVS_CD ';
	        V_QUERY2 := V_QUERY2 ||        'AND B.DL_EXPD_G_CD = ''0008'' ';
	        V_QUERY2 := V_QUERY2 ||        'AND A.QLTY_VEHL_CD = ''' || P_VEHL_CD || ''' ';
	        V_QUERY2 := V_QUERY2 ||        'AND A.MDL_MDY_CD = ''' || P_MDL_MDY || ''' ';
			V_QUERY2 := V_QUERY2 ||        'AND A.USE_YN = ''Y'' ';
	        
	        IF P_REGN_CD <> 'ALL' THEN
				
				V_QUERY2 := V_QUERY2 ||    'AND DL_EXPD_REGN_CD = ''' || P_REGN_CD || ''' ';
				
	        END IF;
	        
	        IF P_LANG_CD <> 'ALL' THEN
	        
				V_QUERY2 := V_QUERY2 ||    'AND LANG_CD = ''' || P_LANG_CD || ''' ';
				
	        END IF;
	        
	        V_QUERY2 := V_QUERY2 ||       ') A,';
	        V_QUERY2 := V_QUERY2 ||       'TB_APS_ODR_SUM_INFO B ';
	        V_QUERY2 := V_QUERY2 ||  'WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD ';
			V_QUERY2 := V_QUERY2 ||	 'AND A.MDL_MDY_CD = B.MDL_MDY_CD ';
			V_QUERY2 := V_QUERY2 ||	 'AND A.LANG_CD = B.LANG_CD ';
			V_QUERY2 := V_QUERY2 ||	 'AND B.APL_STRT_YMD <= ''' || V_SCH_YMD || ''' ';
			V_QUERY2 := V_QUERY2 ||	 'AND B.APL_FNH_YMD >= ''' || V_SCH_YMD || ''' ';
			V_QUERY2 := V_QUERY2 ||  'AND B.MO_PACK_CD BETWEEN ''' || V_FROM_PACK || ''' AND ''' || V_TO_PACK || ''' ';
			V_QUERY2 := V_QUERY2 ||	 'GROUP BY B.QLTY_VEHL_CD, B.MDL_MDY_CD, B.LANG_CD, B.MO_PACK_CD ';
			--V_QUERY2 := V_QUERY2 ||  'ORDER BY MAX(A.SORT_SN), B.LANG_CD, B.MO_PACK_CD ';          
			V_QUERY2 := V_QUERY2 || ') ';
			
			
			
			V_QUERY3 := '';
			
			V_QUERY3 := V_QUERY3 || '(';
			V_QUERY3 := V_QUERY3 ||  'SELECT MO_PACK_CD AS MTH,';
			V_QUERY3 := V_QUERY3 ||         'SUM(B.ORD_QTY) AS QTY ';
			V_QUERY3 := V_QUERY3 ||  'FROM (SELECT LANG_CD,';
			V_QUERY3 := V_QUERY3 ||               'QLTY_VEHL_CD,';
			V_QUERY3 := V_QUERY3 ||               'MDL_MDY_CD ';
	        V_QUERY3 := V_QUERY3 ||        'FROM TB_LANG_MGMT A ';
	        V_QUERY3 := V_QUERY3 ||        'WHERE A.QLTY_VEHL_CD = ''' || P_VEHL_CD || ''' ';
	        V_QUERY3 := V_QUERY3 ||        'AND A.MDL_MDY_CD = ''' || P_MDL_MDY || ''' ';
			V_QUERY3 := V_QUERY3 ||        'AND A.USE_YN = ''Y'' ';
	        
	        IF P_REGN_CD <> 'ALL' THEN
				
				V_QUERY3 := V_QUERY3 ||    'AND A.DL_EXPD_REGN_CD = ''' || P_REGN_CD || ''' ';
				
	        END IF;
	        
	        IF P_LANG_CD <> 'ALL' THEN
	        
				V_QUERY3 := V_QUERY3 ||    'AND A.LANG_CD = ''' || P_LANG_CD || ''' ';
				
	        END IF;
	        
	        V_QUERY3 := V_QUERY3 ||       ') A,';
	        V_QUERY3 := V_QUERY3 ||       'TB_APS_ODR_SUM_INFO B ';
	        V_QUERY3 := V_QUERY3 ||  'WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD ';
			V_QUERY3 := V_QUERY3 ||	 'AND A.MDL_MDY_CD = B.MDL_MDY_CD ';
			V_QUERY3 := V_QUERY3 ||	 'AND A.LANG_CD = B.LANG_CD ';
			V_QUERY3 := V_QUERY3 ||	 'AND B.APL_STRT_YMD <= ''' || V_SCH_YMD || ''' ';
			V_QUERY3 := V_QUERY3 ||	 'AND B.APL_FNH_YMD >= ''' || V_SCH_YMD || ''' ';
			V_QUERY3 := V_QUERY3 ||  'AND B.MO_PACK_CD BETWEEN ''' || V_FROM_PACK || ''' AND ''' || V_TO_PACK || ''' ';
			V_QUERY3 := V_QUERY3 ||	 'GROUP BY B.MO_PACK_CD ';        
			V_QUERY3 := V_QUERY3 || ') ';
			
			                
			OPEN RS FOR 'SELECT * ' ||
			            'FROM (SELECT REGN_NM,LANG_CD,LANG_CD_NM,' || V_QUERY1 || ' ' ||
			                  'FROM ' || V_QUERY2 ||
						      'GROUP BY REGN_NM,LANG_CD,LANG_CD_NM ' ||
							  --'ORDER BY MAX(SORT_SN), LANG_CD_NM ' ||
							  'ORDER BY MAX(SORT_SN), MAX(LANG_SORT_SN) ' ||
							 ') ' ||
			            'UNION ALL ' ||
			            'SELECT ''TOTAL'' AS REGN_NM,''TOTAL'' AS LANG_CD,''TOTAL'' AS LANG_CD_NM,' || V_QUERY1 || ' ' ||
			            'FROM ' || V_QUERY3;
			
			/**  테스트용 쿼리 
			SELECT MAX(A.REGN_NM) AS REGN_NM,
	   			   B.LANG_CD,
	   			   MAX(A.LANG_CD_NM) AS LANG_CD_NM,
	   			   MO_PACK_CD AS MTH,
	   			   SUM(B.ORD_QTY) AS QTY 
		    FROM (SELECT B.SORT_SN,
		     	 		 DL_EXPD_PRVS_NM AS REGN_NM,
		     			 LANG_CD,
		     			 LANG_CD_NM,
		     			 QLTY_VEHL_CD,
		     			 MDL_MDY_CD 
	  			 FROM TB_LANG_MGMT A,
	       		 	  TB_CODE_MGMT B 
	  			 WHERE A.DL_EXPD_REGN_CD = B.DL_EXPD_PRVS_CD 
	  			 AND B.DL_EXPD_G_CD = '0008' 
	  			 AND A.QLTY_VEHL_CD =  'KM'  
	  			 AND A.MDL_MDY_CD = '09' 
	            ) A,
	            TB_APS_ODR_SUM_INFO B
		   WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
		   AND A.MDL_MDY_CD = B.MDL_MDY_CD
		   AND A.LANG_CD = B.LANG_CD
		   AND B.APL_STRT_YMD <= '20081130'
		   AND B.APL_FNH_YMD >= '20081130'
		   AND B.MO_PACK_CD BETWEEN '0801' AND '0811'
		   GROUP BY B.QLTY_VEHL_CD, B.MDL_MDY_CD, B.LANG_CD, B.MO_PACK_CD
		   ORDER BY MAX(A.SORT_SN), B.LANG_CD, B.MO_PACK_CD  
           **/
            
	   END SP_GET_MTH_ODR_INFO;
	   
	   --월간 생산 정보 조회 			
	   PROCEDURE SP_GET_PROD_MST_INFO(P_VEHL_CD	 VARCHAR2,
								      P_MDL_MDY	 VARCHAR2,
								      P_REGN_CD	 VARCHAR2,
								      P_LANG_CD  VARCHAR2,
								      P_FROM_MTH VARCHAR2,
								      P_TO_MTH	 VARCHAR2,
                                      RS OUT REFCUR,
                                      P_MESSAGE OUT VARCHAR2)
       IS
       	 
		 V_CURR_YMD VARCHAR2(8);
		 V_SCH_YMD  VARCHAR2(8);
		 
		 V_MESSAGE  VARCHAR2(8000);
		 
		 V_QUERY1 VARCHAR2(8000);
		 V_QUERY2 VARCHAR2(8000);
		 V_QUERY3 VARCHAR2(8000);
		 
		 V_FROM_YMD VARCHAR2(8);
		 V_TO_YMD   VARCHAR2(8);
		 
       BEGIN
			
			V_FROM_YMD := P_FROM_MTH || '01';
			V_TO_YMD   := TO_CHAR(LAST_DAY(TO_DATE(P_TO_MTH || '01', 'YYYYMMDD')), 'YYYYMMDD');
	   		
			V_CURR_YMD := TO_CHAR(SYSDATE, 'YYYYMMDD');
			
			IF V_CURR_YMD > V_TO_YMD THEN
			   
			   V_CURR_YMD := V_TO_YMD;
			   
			END IF;
			
			SP_GET_MSG_PROD(P_VEHL_CD, P_MDL_MDY, V_CURR_YMD, V_SCH_YMD, V_MESSAGE);
			
			P_MESSAGE := V_MESSAGE;
			
			V_QUERY1 := FU_GET_MTH_PACK_QRY(P_FROM_MTH, P_TO_MTH);
			
			V_QUERY2 := '';
			
			V_QUERY2 := V_QUERY2 || '(';
			V_QUERY2 := V_QUERY2 ||  'SELECT MAX(A.REGN_NM) AS REGN_NM,';
			V_QUERY2 := V_QUERY2 ||         'B.LANG_CD,';
			V_QUERY2 := V_QUERY2 ||         'MAX(A.LANG_CD_NM) AS LANG_CD_NM,';
			V_QUERY2 := V_QUERY2 ||         'SUBSTR(B.APL_YMD, 3, 4) AS MTH,';
			V_QUERY2 := V_QUERY2 ||         'MAX(A.SORT_SN) AS SORT_SN,';
			V_QUERY2 := V_QUERY2 ||         'SUM(B.PRDN_TRWI_QTY) AS QTY,';
			V_QUERY2 := V_QUERY2 ||         'MAX(A.LANG_SORT_SN) AS LANG_SORT_SN ';
			V_QUERY2 := V_QUERY2 ||  'FROM (SELECT B.SORT_SN,';
			V_QUERY2 := V_QUERY2 ||               'DL_EXPD_PRVS_NM AS REGN_NM,';
			V_QUERY2 := V_QUERY2 ||               'LANG_CD,';
			V_QUERY2 := V_QUERY2 ||               'LANG_CD_NM,';
			V_QUERY2 := V_QUERY2 ||               'QLTY_VEHL_CD,';
			V_QUERY2 := V_QUERY2 ||               'MDL_MDY_CD,';
			V_QUERY2 := V_QUERY2 ||               'A.SORT_SN AS LANG_SORT_SN ';
	        V_QUERY2 := V_QUERY2 ||        'FROM TB_LANG_MGMT A,';
	        V_QUERY2 := V_QUERY2 ||             'TB_CODE_MGMT B ';
	        V_QUERY2 := V_QUERY2 ||        'WHERE A.DL_EXPD_REGN_CD = B.DL_EXPD_PRVS_CD ';
	        V_QUERY2 := V_QUERY2 ||        'AND B.DL_EXPD_G_CD = ''0008'' ';
	        V_QUERY2 := V_QUERY2 ||        'AND A.QLTY_VEHL_CD = ''' || P_VEHL_CD || ''' ';
	        V_QUERY2 := V_QUERY2 ||        'AND A.MDL_MDY_CD = ''' || P_MDL_MDY || ''' ';
			V_QUERY2 := V_QUERY2 ||        'AND A.USE_YN = ''Y'' ';
	        
	        IF P_REGN_CD <> 'ALL' THEN
				
				V_QUERY2 := V_QUERY2 ||    'AND DL_EXPD_REGN_CD = ''' || P_REGN_CD || ''' ';
				
	        END IF;
	        
	        IF P_LANG_CD <> 'ALL' THEN
	        
				V_QUERY2 := V_QUERY2 ||    'AND LANG_CD = ''' || P_LANG_CD || ''' ';
				
	        END IF;
	        
	        V_QUERY2 := V_QUERY2 ||       ') A,';
	        V_QUERY2 := V_QUERY2 ||       'TB_PROD_MST_SUM_INFO B ';
	        V_QUERY2 := V_QUERY2 ||  'WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD ';
			V_QUERY2 := V_QUERY2 ||	 'AND A.MDL_MDY_CD = B.MDL_MDY_CD ';
			V_QUERY2 := V_QUERY2 ||	 'AND A.LANG_CD = B.LANG_CD ';
			V_QUERY2 := V_QUERY2 ||	 'AND B.APL_YMD BETWEEN ''' || V_FROM_YMD || ''' AND ''' || V_TO_YMD || ''' ';
			V_QUERY2 := V_QUERY2 ||	 'GROUP BY B.QLTY_VEHL_CD, B.MDL_MDY_CD, B.LANG_CD, SUBSTR(B.APL_YMD, 3, 4) ';
			--V_QUERY2 := V_QUERY2 ||  'ORDER BY MAX(A.SORT_SN), B.LANG_CD, SUBSTR(B.APL_YMD, 3, 4) ';         
			V_QUERY2 := V_QUERY2 || ') ';
			
			
			
			V_QUERY3 := '';
			
			V_QUERY3 := V_QUERY3 || '(';
			V_QUERY3 := V_QUERY3 ||  'SELECT SUBSTR(B.APL_YMD, 3, 4) AS MTH,';
			V_QUERY3 := V_QUERY3 ||         'SUM(B.PRDN_TRWI_QTY) AS QTY ';
			V_QUERY3 := V_QUERY3 ||  'FROM (SELECT LANG_CD,';
			V_QUERY3 := V_QUERY3 ||               'QLTY_VEHL_CD,';
			V_QUERY3 := V_QUERY3 ||               'MDL_MDY_CD ';
	        V_QUERY3 := V_QUERY3 ||        'FROM TB_LANG_MGMT A ';
	        V_QUERY3 := V_QUERY3 ||        'WHERE A.QLTY_VEHL_CD = ''' || P_VEHL_CD || ''' ';
	        V_QUERY3 := V_QUERY3 ||        'AND A.MDL_MDY_CD = ''' || P_MDL_MDY || ''' ';
			V_QUERY3 := V_QUERY3 ||        'AND A.USE_YN = ''Y'' ';
	        
	        IF P_REGN_CD <> 'ALL' THEN
				
				V_QUERY3 := V_QUERY3 ||    'AND A.DL_EXPD_REGN_CD = ''' || P_REGN_CD || ''' ';
				
	        END IF;
	        
	        IF P_LANG_CD <> 'ALL' THEN
	        
				V_QUERY3 := V_QUERY3 ||    'AND A.LANG_CD = ''' || P_LANG_CD || ''' ';
				
	        END IF;
	        
	        V_QUERY3 := V_QUERY3 ||       ') A,';
	        V_QUERY3 := V_QUERY3 ||       'TB_PROD_MST_SUM_INFO B ';
	        V_QUERY3 := V_QUERY3 ||  'WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD ';
			V_QUERY3 := V_QUERY3 ||	 'AND A.MDL_MDY_CD = B.MDL_MDY_CD ';
			V_QUERY3 := V_QUERY3 ||	 'AND A.LANG_CD = B.LANG_CD ';
			V_QUERY3 := V_QUERY3 ||	 'AND B.APL_YMD BETWEEN ''' || V_FROM_YMD || ''' AND ''' || V_TO_YMD || ''' ';
			V_QUERY3 := V_QUERY3 ||	 'GROUP BY SUBSTR(B.APL_YMD, 3, 4) ';        
			V_QUERY3 := V_QUERY3 || ') ';
			
			                
			OPEN RS FOR 'SELECT * ' ||
				 	    'FROM (SELECT REGN_NM,LANG_CD,LANG_CD_NM,' || V_QUERY1 || ' ' ||
			                  'FROM ' || V_QUERY2 ||
						      'GROUP BY REGN_NM,LANG_CD,LANG_CD_NM ' ||
							  --'ORDER BY MAX(SORT_SN), LANG_CD_NM ' || 
							  'ORDER BY MAX(SORT_SN), MAX(LANG_SORT_SN) ' ||
							 ') ' ||
			            'UNION ALL ' ||
			            'SELECT ''TOTAL'' AS REGN_NM,''TOTAL'' AS LANG_CD,''TOTAL'' AS LANG_CD_NM,' || V_QUERY1 || ' ' ||
			            'FROM ' || V_QUERY3;
						
       END SP_GET_PROD_MST_INFO;
       
	   --월간 오더,생산 정보 조회 
       PROCEDURE SP_GET_ODR_PROD_INFO(P_CURR_YMD VARCHAR2,
	   			 					  P_VEHL_CD	 VARCHAR2,
								      P_MDL_MDY	 VARCHAR2,
								      P_REGN_CD	 VARCHAR2,
								      P_LANG_CD  VARCHAR2,
								      P_FROM_MTH VARCHAR2,
								      P_TO_MTH	 VARCHAR2,
                                      RS OUT REFCUR,
                                      P_MESSAGE OUT VARCHAR2)
       IS
         
		 V_SCH_YMD  VARCHAR2(8);
		 V_MESSAGE  VARCHAR2(8000);
		 
         V_QUERY1 VARCHAR2(8000);
		 V_QUERY2 VARCHAR2(8000);
		 V_QUERY3 VARCHAR2(8000);
		 V_QUERY4 VARCHAR2(8000);
		 V_QUERY5 VARCHAR2(8000);
		 
		 V_FROM_PACK VARCHAR2(4);
		 V_TO_PACK   VARCHAR2(4);
		 
	   BEGIN
	   		
			--SP_GET_MSG_ODR_PROD(P_VEHL_CD, P_MDL_MDY, P_CURR_YMD, V_SCH_YMD, V_MESSAGE);
			SP_GET_MSG_ODR(P_VEHL_CD, P_MDL_MDY, P_CURR_YMD, V_SCH_YMD, V_MESSAGE);
			
			P_MESSAGE := V_MESSAGE;
									
	   		V_FROM_PACK := SUBSTR(P_FROM_MTH, 3, 4);
	   		V_TO_PACK   := SUBSTR(P_TO_MTH,   3, 4);
	   		
			V_QUERY1 := FU_GET_MTH_PACK_QRY(P_FROM_MTH, P_TO_MTH);
			
			V_QUERY2 := '';
			
			V_QUERY2 := V_QUERY2 || '(';
			V_QUERY2 := V_QUERY2 ||  'SELECT MAX(A.REGN_NM) AS REGN_NM,';
			V_QUERY2 := V_QUERY2 ||         'MAX(A.SORT_SN) AS SORT_SN,';
			V_QUERY2 := V_QUERY2 ||         'B.LANG_CD,';
			V_QUERY2 := V_QUERY2 ||         'MAX(A.LANG_CD_NM) AS LANG_CD_NM,';
			V_QUERY2 := V_QUERY2 ||         'MO_PACK_CD AS MTH,';
			V_QUERY2 := V_QUERY2 ||         'SUM(B.PRDN_PLN_QTY) AS QTY,';
			V_QUERY2 := V_QUERY2 ||         'MAX(A.LANG_SORT_SN) AS LANG_SORT_SN ';
			V_QUERY2 := V_QUERY2 ||  'FROM (SELECT B.SORT_SN,';
			V_QUERY2 := V_QUERY2 ||               'DL_EXPD_PRVS_NM AS REGN_NM,';
			V_QUERY2 := V_QUERY2 ||               'LANG_CD,';
			V_QUERY2 := V_QUERY2 ||               'LANG_CD_NM,';
			V_QUERY2 := V_QUERY2 ||               'QLTY_VEHL_CD,';
			V_QUERY2 := V_QUERY2 ||               'MDL_MDY_CD,';
			V_QUERY2 := V_QUERY2 ||               'A.SORT_SN AS LANG_SORT_SN ';
	        V_QUERY2 := V_QUERY2 ||        'FROM TB_LANG_MGMT A,';
	        V_QUERY2 := V_QUERY2 ||             'TB_CODE_MGMT B ';
	        V_QUERY2 := V_QUERY2 ||        'WHERE A.DL_EXPD_REGN_CD = B.DL_EXPD_PRVS_CD ';
	        V_QUERY2 := V_QUERY2 ||        'AND B.DL_EXPD_G_CD = ''0008'' ';
	        V_QUERY2 := V_QUERY2 ||        'AND A.QLTY_VEHL_CD = ''' || P_VEHL_CD || ''' ';
	        V_QUERY2 := V_QUERY2 ||        'AND A.MDL_MDY_CD = ''' || P_MDL_MDY || ''' ';
			V_QUERY2 := V_QUERY2 ||        'AND A.USE_YN = ''Y'' ';
	        
	        IF P_REGN_CD <> 'ALL' THEN
				
				V_QUERY2 := V_QUERY2 ||    'AND DL_EXPD_REGN_CD = ''' || P_REGN_CD || ''' ';
				
	        END IF;
	        
	        IF P_LANG_CD <> 'ALL' THEN
	        
				V_QUERY2 := V_QUERY2 ||    'AND LANG_CD = ''' || P_LANG_CD || ''' ';
				
	        END IF;
	        
	        V_QUERY2 := V_QUERY2 ||       ') A,';
	        V_QUERY2 := V_QUERY2 ||       'TB_APS_ODR_SUM_INFO B ';
	        V_QUERY2 := V_QUERY2 ||  'WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD ';
			V_QUERY2 := V_QUERY2 ||	 'AND A.MDL_MDY_CD = B.MDL_MDY_CD ';
			V_QUERY2 := V_QUERY2 ||	 'AND A.LANG_CD = B.LANG_CD ';
			V_QUERY2 := V_QUERY2 ||	 'AND B.APL_STRT_YMD <= ''' || V_SCH_YMD || ''' ';
			V_QUERY2 := V_QUERY2 ||	 'AND B.APL_FNH_YMD >= ''' || V_SCH_YMD || ''' ';
			V_QUERY2 := V_QUERY2 ||  'AND B.MO_PACK_CD BETWEEN ''' || V_FROM_PACK || ''' AND ''' || V_TO_PACK || ''' ';
			V_QUERY2 := V_QUERY2 ||	 'GROUP BY B.QLTY_VEHL_CD, B.MDL_MDY_CD, B.LANG_CD, B.MO_PACK_CD ';      
			V_QUERY2 := V_QUERY2 || ') ';
			
			
			V_QUERY3 := '';
			
			V_QUERY3 := V_QUERY3 || '(';
			V_QUERY3 := V_QUERY3 ||  'SELECT MO_PACK_CD AS MTH,';
			V_QUERY3 := V_QUERY3 ||         'SUM(B.ORD_QTY) AS QTY ';
			V_QUERY3 := V_QUERY3 ||  'FROM (SELECT LANG_CD,';
			V_QUERY3 := V_QUERY3 ||               'QLTY_VEHL_CD,';
			V_QUERY3 := V_QUERY3 ||               'MDL_MDY_CD ';
	        V_QUERY3 := V_QUERY3 ||        'FROM TB_LANG_MGMT A ';
	        V_QUERY3 := V_QUERY3 ||        'WHERE A.QLTY_VEHL_CD = ''' || P_VEHL_CD || ''' ';
	        V_QUERY3 := V_QUERY3 ||        'AND A.MDL_MDY_CD = ''' || P_MDL_MDY || ''' ';
			V_QUERY3 := V_QUERY3 ||        'AND A.USE_YN = ''Y'' ';
	        
	        IF P_REGN_CD <> 'ALL' THEN
				
				V_QUERY3 := V_QUERY3 ||    'AND A.DL_EXPD_REGN_CD = ''' || P_REGN_CD || ''' ';
				
	        END IF;
	        
	        IF P_LANG_CD <> 'ALL' THEN
	        
				V_QUERY3 := V_QUERY3 ||    'AND A.LANG_CD = ''' || P_LANG_CD || ''' ';
				
	        END IF;
	        
	        V_QUERY3 := V_QUERY3 ||       ') A,';
	        V_QUERY3 := V_QUERY3 ||       'TB_APS_ODR_SUM_INFO B ';
	        V_QUERY3 := V_QUERY3 ||  'WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD ';
			V_QUERY3 := V_QUERY3 ||	 'AND A.MDL_MDY_CD = B.MDL_MDY_CD ';
			V_QUERY3 := V_QUERY3 ||	 'AND A.LANG_CD = B.LANG_CD ';
			V_QUERY3 := V_QUERY3 ||	 'AND B.APL_STRT_YMD <= ''' || V_SCH_YMD || ''' ';
			V_QUERY3 := V_QUERY3 ||	 'AND B.APL_FNH_YMD >= ''' || V_SCH_YMD || ''' ';
			V_QUERY3 := V_QUERY3 ||  'AND B.MO_PACK_CD BETWEEN ''' || V_FROM_PACK || ''' AND ''' || V_TO_PACK || ''' ';
			V_QUERY3 := V_QUERY3 ||	 'GROUP BY B.MO_PACK_CD ';        
			V_QUERY3 := V_QUERY3 || ') ';
			
			
			V_QUERY4 := '';
			
			V_QUERY4 := V_QUERY4 || '(';
			V_QUERY4 := V_QUERY4 ||  'SELECT MAX(A.REGN_NM) AS REGN_NM,';
			V_QUERY4 := V_QUERY4 ||         'MAX(A.SORT_SN) AS SORT_SN,';
			V_QUERY4 := V_QUERY4 ||         'B.LANG_CD,';
			V_QUERY4 := V_QUERY4 ||         'MAX(A.LANG_CD_NM) AS LANG_CD_NM,';
			V_QUERY4 := V_QUERY4 ||         'MO_PACK_CD AS MTH,';
			V_QUERY4 := V_QUERY4 ||         'SUM(B.PRDN_TRWI_QTY) AS QTY,';
			V_QUERY4 := V_QUERY4 ||         'MAX(A.LANG_SORT_SN) AS LANG_SORT_SN ';
			V_QUERY4 := V_QUERY4 ||  'FROM (SELECT B.SORT_SN,';
			V_QUERY4 := V_QUERY4 ||               'DL_EXPD_PRVS_NM AS REGN_NM,';
			V_QUERY4 := V_QUERY4 ||               'LANG_CD,';
			V_QUERY4 := V_QUERY4 ||               'LANG_CD_NM,';
			V_QUERY4 := V_QUERY4 ||               'QLTY_VEHL_CD,';
			V_QUERY4 := V_QUERY4 ||               'MDL_MDY_CD,';
			V_QUERY4 := V_QUERY4 ||               'A.SORT_SN AS LANG_SORT_SN ';
	        V_QUERY4 := V_QUERY4 ||        'FROM TB_LANG_MGMT A,';
	        V_QUERY4 := V_QUERY4 ||             'TB_CODE_MGMT B ';
	        V_QUERY4 := V_QUERY4 ||        'WHERE A.DL_EXPD_REGN_CD = B.DL_EXPD_PRVS_CD ';
	        V_QUERY4 := V_QUERY4 ||        'AND B.DL_EXPD_G_CD = ''0008'' ';
	        V_QUERY4 := V_QUERY4 ||        'AND A.QLTY_VEHL_CD = ''' || P_VEHL_CD || ''' ';
	        V_QUERY4 := V_QUERY4 ||        'AND A.MDL_MDY_CD = ''' || P_MDL_MDY || ''' ';
			V_QUERY4 := V_QUERY4 ||        'AND A.USE_YN = ''Y'' ';
	        
	        IF P_REGN_CD <> 'ALL' THEN
				
				V_QUERY4 := V_QUERY4 ||    'AND DL_EXPD_REGN_CD = ''' || P_REGN_CD || ''' ';
				
	        END IF;
	        
	        IF P_LANG_CD <> 'ALL' THEN
	        
				V_QUERY4 := V_QUERY4 ||    'AND LANG_CD = ''' || P_LANG_CD || ''' ';
				
	        END IF;
	        
	        V_QUERY4 := V_QUERY4 ||       ') A,';
	        V_QUERY4 := V_QUERY4 ||       'TB_PROD_ODR_INFO B ';
	        V_QUERY4 := V_QUERY4 ||  'WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD ';
			V_QUERY4 := V_QUERY4 ||	 'AND A.MDL_MDY_CD = B.MDL_MDY_CD ';
			V_QUERY4 := V_QUERY4 ||	 'AND A.LANG_CD = B.LANG_CD ';
			V_QUERY4 := V_QUERY4 ||  'AND B.MO_PACK_CD BETWEEN ''' || V_FROM_PACK || ''' AND ''' || V_TO_PACK || ''' ';
			V_QUERY4 := V_QUERY4 ||	 'GROUP BY B.QLTY_VEHL_CD, B.MDL_MDY_CD, B.LANG_CD, B.MO_PACK_CD ';     
			V_QUERY4 := V_QUERY4 || ') ';
			
			V_QUERY5 := '';
			
			V_QUERY5 := V_QUERY5 || '(';
			V_QUERY5 := V_QUERY5 ||  'SELECT MO_PACK_CD AS MTH,';
			V_QUERY5 := V_QUERY5 ||         'SUM(B.PRDN_TRWI_QTY) AS QTY ';
			V_QUERY5 := V_QUERY5 ||  'FROM (SELECT LANG_CD,';
			V_QUERY5 := V_QUERY5 ||               'QLTY_VEHL_CD,';
			V_QUERY5 := V_QUERY5 ||               'MDL_MDY_CD ';
	        V_QUERY5 := V_QUERY5 ||        'FROM TB_LANG_MGMT A ';
	        V_QUERY5 := V_QUERY5 ||        'WHERE A.QLTY_VEHL_CD = ''' || P_VEHL_CD || ''' ';
	        V_QUERY5 := V_QUERY5 ||        'AND A.MDL_MDY_CD = ''' || P_MDL_MDY || ''' ';
			V_QUERY5 := V_QUERY5 ||        'AND A.USE_YN = ''Y'' ';
	        
	        IF P_REGN_CD <> 'ALL' THEN
				
				V_QUERY5 := V_QUERY5 ||    'AND A.DL_EXPD_REGN_CD = ''' || P_REGN_CD || ''' ';
				
	        END IF;
	        
	        IF P_LANG_CD <> 'ALL' THEN
	        
				V_QUERY5 := V_QUERY5 ||    'AND A.LANG_CD = ''' || P_LANG_CD || ''' ';
				
	        END IF;
	        
	        V_QUERY5 := V_QUERY5 ||       ') A,';
	        V_QUERY5 := V_QUERY5 ||       'TB_PROD_ODR_INFO B ';
	        V_QUERY5 := V_QUERY5 ||  'WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD ';
			V_QUERY5 := V_QUERY5 ||	 'AND A.MDL_MDY_CD = B.MDL_MDY_CD ';
			V_QUERY5 := V_QUERY5 ||	 'AND A.LANG_CD = B.LANG_CD ';
			V_QUERY5 := V_QUERY5 ||  'AND B.MO_PACK_CD BETWEEN ''' || V_FROM_PACK || ''' AND ''' || V_TO_PACK || ''' ';
			V_QUERY5 := V_QUERY5 ||	 'GROUP BY B.MO_PACK_CD ';        
			V_QUERY5 := V_QUERY5 || ') ';
			
			
			OPEN RS FOR 'SELECT * ' ||
			            'FROM (SELECT 1 AS IDX,1 AS SN,REGN_NM,LANG_CD,LANG_CD_NM,SORT_SN,' || V_QUERY1 || ',LANG_SORT_SN ' ||
			                  'FROM ' || V_QUERY2 ||
							  'GROUP BY REGN_NM,LANG_CD,LANG_CD_NM,SORT_SN,LANG_SORT_SN ' ||
			                  'UNION ALL ' ||
			                  'SELECT 2 AS IDX,1 AS SN,REGN_NM,LANG_CD,LANG_CD_NM,SORT_SN,' || V_QUERY1 || ',LANG_SORT_SN ' ||
			                  'FROM ' || V_QUERY4 ||
							  'GROUP BY REGN_NM,LANG_CD,LANG_CD_NM,SORT_SN,LANG_SORT_SN ' ||
			                  'UNION ALL ' ||
			                  'SELECT 3 AS IDX,2 AS SN,''TOTAL'' AS REGN_NM,''TOTAL'' AS LANG_CD,''TOTAL'' AS LANG_CD_NM,999 AS SORT_SN,' || V_QUERY1 || ',9999 AS LANG_SORT_SN ' ||
							  'FROM ' || V_QUERY3 ||
							  'UNION ALL ' ||
							  'SELECT 4 AS IDX,2 AS SN,''TOTAL'' AS REGN_NM,''TOTAL'' AS LANG_CD,''TOTAL'' AS LANG_CD_NM,999 AS SORT_SN,' || V_QUERY1 || ',9999 AS LANG_SORT_SN ' ||
							  'FROM ' || V_QUERY5 ||
			                 ') ' ||
			            --'ORDER BY SN,SORT_SN,LANG_CD_NM,IDX ';
						'ORDER BY SN,SORT_SN,LANG_SORT_SN,IDX ';
			                
       END SP_GET_ODR_PROD_INFO;
	   
	   --조회기간에 따란 Dynamic Query 생성 함수 
	   FUNCTION FU_GET_MTH_PACK_QRY(P_FROM_MTH VARCHAR2,
								    P_TO_MTH   VARCHAR2) RETURN VARCHAR2
	   IS
	   	 
		 V_QUERY VARCHAR2(8000);
		 
		 V_FROM_DATE DATE;
		 V_TO_DATE   DATE;
		 
		 V_CNT       NUMBER;
		 
		 V_CURR_DATE DATE;
		 
	   BEGIN
	   		
			--PG_COMMON.SP_GET_DATEDIFF(P_FROM_MTH, P_TO_MTH, V_CNT);
			--V_CNT := V_CNT - 1;
			
			--V_FROM_DATE := TO_DATE(P_FROM_MTH || '01', 'YYYYMMDD');
			
			SELECT TO_DATE(MIN(WK_YMD), 'YYYYMMDD')
			INTO V_FROM_DATE
			FROM TB_WRK_DATE_MGMT
			WHERE WK_YMD >= P_FROM_MTH || '01';
			
			V_TO_DATE   := LAST_DAY(TO_DATE(P_TO_MTH || '01', 'YYYYMMDD'));
			
			V_CNT := ROUND(MONTHS_BETWEEN(V_TO_DATE, V_FROM_DATE)) - 1;
			
			FOR NUM IN 0..V_CNT LOOP
				
				V_CURR_DATE := ADD_MONTHS(V_FROM_DATE, NUM);
				
				IF NUM = V_CNT THEN
				   
				   	V_QUERY := V_QUERY || 'NVL(SUM(DECODE(MTH,''' || TO_CHAR(V_CURR_DATE, 'YYMM') || ''',QTY,0)), 0) AS COL' || TO_CHAR(NUM + 1);
				   
				ELSE
					
					V_QUERY := V_QUERY || 'NVL(SUM(DECODE(MTH,''' || TO_CHAR(V_CURR_DATE, 'YYMM') || ''',QTY,0)), 0) AS COL' || TO_CHAR(NUM + 1) || ',';
					
				END IF;
				
			END LOOP;
			
	   		RETURN V_QUERY;
			
	   END FU_GET_MTH_PACK_QRY;
	   
	   --언어별 차종 재고 내역 조회 				
       PROCEDURE SP_GET_IV_BY_LANG(P_VEHL_CD  VARCHAR2,
							       P_MDL_MDY  VARCHAR2,
							       P_REGN_CD  VARCHAR2,
							       P_LANG_CD  VARCHAR2,
							       P_FROM_YMD VARCHAR2,
							       P_TO_YMD	  VARCHAR2,
                                   RS OUT REFCUR)
	   IS
	   BEGIN
	   		
			OPEN RS FOR
				 WITH T AS (SELECT B.SORT_SN,
				 	  	   		   DL_EXPD_REGN_CD,
				                   DL_EXPD_PRVS_NM AS REGN_NM,
								   LANG_CD,
								   LANG_CD_NM,
								   QLTY_VEHL_CD,
								   MDL_MDY_CD,
								   A.SORT_SN AS LANG_SORT_SN
						    FROM TB_LANG_MGMT A,
							     TB_CODE_MGMT B
						    WHERE A.DL_EXPD_REGN_CD = B.DL_EXPD_PRVS_CD
							AND B.DL_EXPD_G_CD = '0008'
							AND A.QLTY_VEHL_CD = P_VEHL_CD
							AND A.MDL_MDY_CD = P_MDL_MDY
							AND A.DL_EXPD_REGN_CD = DECODE(P_REGN_CD, 'ALL', A.DL_EXPD_REGN_CD, P_REGN_CD)
							AND A.LANG_CD = DECODE(P_LANG_CD, 'ALL', A.LANG_CD, P_LANG_CD)
							AND A.USE_YN = 'Y'
				 	  	   ),
					  U AS (SELECT A.REGN_NM, 
					  	   		   A.LANG_CD, 
								   A.LANG_CD_NM,
				                   NVL(B.SEWHA_WHSN_QTY, 0) AS SEWHA_WHSN_QTY,
							       NVL(C.SEWHA_WHOT_QTY, 0) AS SEWHA_WHOT_QTY,
							       NVL(D.SEWHA_IV_QTY, 0) AS SEWHA_IV_QTY,
								   NVL(D.SEWHA_IV_TEXT, '') AS SEWHA_IV_TEXT,
							       NVL(E.PDI_WHSN_QTY, 0) AS PDI_WHSN_QTY,
							       NVL(F.PDI_NORMAL_WHOT, 0) AS PDI_NORMAL_WHOT,
							       NVL(F.PDI_EXTRA_WHOT, 0) AS PDI_EXTRA_WHOT,
							       NVL(F.PDI_DISUSE_WHOT, 0) AS PDI_DISUSE_WHOT,
							       NVL(F.PDI_REVICE_WHOT, 0) * (-1) AS PDI_REVICE_WHOT,
							       NVL(G.PDI_IV_QTY, 0) AS PDI_IV_QTY,
								   NVL(G.PDI_IV_TEXT, '') AS PDI_IV_TEXT,
							       NVL(D.SEWHA_IV_QTY, 0) + NVL(G.PDI_IV_QTY, 0) AS IV_QTY
				            FROM T A,
								 --세화입고 정보의 경우 차종연식과 취급설명서 연식이 같을 수 밖에 없다.
								 --(발주의뢰 화면에서 같게 넘어갈 수 밖에 없다.) 
								 --그리고 제일 마지막 날의 재고 데이터만 가지고 조회 하다 보니 재고 테이블과 JOIN 하는 것도 어렵다.
								 --그래서 취급설명서 연식관리 테이블과 조인해서 처리해 줄 수 밖에 없다. 
					   		     --세화 입고(인쇄) 현황 조회  ==> 기간별 조회이므로 인쇄중인지의 여부를 구분짓는것이 무의미 하다. 
					             (
								  /*** [변경] TB_DL_EXPD_MDY_MGMT 테이블을 JOIN 대상에서 제외함 
								  SELECT A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD, SUM(C.WHSN_QTY) AS SEWHA_WHSN_QTY
							      FROM T A,
							 	       TB_DL_EXPD_MDY_MGMT B,
									   TB_SEWHA_WHSN_INFO C
								  WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
								  AND A.MDL_MDY_CD = B.MDL_MDY_CD							  
								  AND A.DL_EXPD_REGN_CD = B.DL_EXPD_REGN_CD 
							      AND A.QLTY_VEHL_CD = C.QLTY_VEHL_CD
         				          AND B.DL_EXPD_MDL_MDY_CD = C.DL_EXPD_MDL_MDY_CD
         				          AND A.LANG_CD = C.LANG_CD
         				          AND C.WHSN_YMD BETWEEN P_FROM_YMD AND P_TO_YMD --입고일이 조회기간에 포함된 데이터만을 가져온다.
						          GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD 
								  ***/ 
								  
								  SELECT A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD, SUM(B.WHSN_QTY) AS SEWHA_WHSN_QTY
							      FROM T A,
									   TB_SEWHA_WHSN_INFO B
								  WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
								  AND A.MDL_MDY_CD = B.MDL_MDY_CD							  
								  AND A.LANG_CD = B.LANG_CD
         				          AND B.WHSN_YMD BETWEEN P_FROM_YMD AND P_TO_YMD --입고일이 조회기간에 포함된 데이터만을 가져온다.
						          GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD 
								  
							     ) B,
							     --세화 배송 현황 조회 
							     (SELECT A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD, SUM(B.RQ_QTY) AS SEWHA_WHOT_QTY
							      FROM T A,
								       TB_SEWHA_WHOT_INFO B
							      WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
         				          AND A.MDL_MDY_CD = B.MDL_MDY_CD
         				          AND A.LANG_CD = B.LANG_CD
         				          AND B.WHSN_YMD BETWEEN P_FROM_YMD AND P_TO_YMD --PDI 입고년월일이 조회기간에 포함된 데이터만을 가져온다.
								  AND B.DEL_YN = 'N'	 				         -- 삭제되지 않은 데이터만을 조회한다. 
						          GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD
							     ) C,
							     --세화 재고 현황 조회 
							     ( 		   					 	  
								  SELECT A.QLTY_VEHL_CD, 
								  		 A.MDL_MDY_CD, 
										 A.LANG_CD, 
										 SUM(B.SFTY_IV_QTY) AS SEWHA_IV_QTY, 
								  		 FU_GET_SEWHA_IV_TEXT(P_TO_YMD, A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD) AS SEWHA_IV_TEXT 
         				          FROM T A,
              				           TB_SEWHA_IV_INFO_DTL B 
         				          WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
         				          AND A.MDL_MDY_CD = B.MDL_MDY_CD
         				          AND A.LANG_CD = B.LANG_CD
         				          AND B.CLS_YMD = P_TO_YMD --최종일의 재고 데이터를 조회한다.
						          GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD 
								  
								  /*** [이전버전] 
								  SELECT A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD, SUM(C.IV_QTY) AS SEWHA_IV_QTY 
							      FROM T A,
							 	       TB_DL_EXPD_MDY_MGMT B,
									   TB_SEWHA_IV_INFO C
								  WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
								  AND A.MDL_MDY_CD = B.MDL_MDY_CD									  
								  AND A.DL_EXPD_REGN_CD = B.DL_EXPD_REGN_CD 
							      AND A.QLTY_VEHL_CD = C.QLTY_VEHL_CD
         				          AND B.DL_EXPD_MDL_MDY_CD = C.DL_EXPD_MDL_MDY_CD
         				          AND A.LANG_CD = C.LANG_CD
         				          AND C.CLS_YMD = P_TO_YMD --최종일의 재고 데이터를 조회한다.
						          GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD 
								  ***/
								  
							     ) D,
							     --PDI 입고 현황 조회 
							     (SELECT A.QLTY_VEHL_CD, 
								 		 A.MDL_MDY_CD, 
										 A.LANG_CD, 
										 SUM(B.WHSN_QTY) AS PDI_WHSN_QTY
							      FROM T A,
								       TB_PDI_WHSN_INFO B
							      WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
         				          AND A.MDL_MDY_CD = B.MDL_MDY_CD
         				          AND A.LANG_CD = B.LANG_CD
         				          AND B.WHSN_YMD BETWEEN P_FROM_YMD AND P_TO_YMD --PDI 입고년월일이 조회기간에 포함된 데이터만을 가져온다.
						          GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD
							     ) E,
							     --PDI 출고 현황 조회 
							     (SELECT A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD,
									     SUM(CASE WHEN B.DL_EXPD_WHOT_ST_CD = '01' THEN B.DL_EXPD_WHOT_QTY ELSE 0 END) AS PDI_NORMAL_WHOT,     --출고 
									     SUM(CASE WHEN B.DL_EXPD_WHOT_ST_CD = '02' THEN B.DL_EXPD_WHOT_QTY ELSE 0 END) AS PDI_EXTRA_WHOT,      --별도출고
									     SUM(CASE WHEN B.DL_EXPD_WHOT_ST_CD = '03' THEN B.DL_EXPD_WHOT_QTY ELSE 0 END) AS PDI_DISUSE_WHOT,     --폐기 
									     SUM(CASE WHEN B.DL_EXPD_WHOT_ST_CD IN ('04','05','06', '07', '08','09') THEN B.DL_EXPD_WHOT_QTY ELSE 0 END) AS PDI_REVICE_WHOT --재고보정 
							      FROM T A,
								       TB_PDI_WHOT_INFO B
							      WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
         				          AND A.MDL_MDY_CD = B.MDL_MDY_CD
         				          AND A.LANG_CD = B.LANG_CD
         				          AND B.WHOT_YMD BETWEEN P_FROM_YMD AND P_TO_YMD --PDI 출고년월일이 조회기간에 포함된 데이터만을 가져온다.
						          AND B.DEL_YN = 'N'
							      GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD
							     ) F,
							     --PDI 재고 현황 조회 
							     (						  
								  SELECT A.QLTY_VEHL_CD, 
								  		 A.MDL_MDY_CD, 
										 A.LANG_CD, 
										 SUM(B.SFTY_IV_QTY) AS PDI_IV_QTY,
								         FU_GET_PDI_IV_TEXT(P_TO_YMD, A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD) AS PDI_IV_TEXT 
                                  FROM T A,
                                       TB_PDI_IV_INFO_DTL B
                                  WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
                                  AND A.MDL_MDY_CD = B.MDL_MDY_CD
                                  AND A.LANG_CD = B.LANG_CD
                                  AND B.CLS_YMD = P_TO_YMD --최종일의 재고 데이터를 조회한다.
						          GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD 
								  
								  /*** [이전버전] 
								  SELECT A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD, SUM(C.IV_QTY) AS PDI_IV_QTY 
							      FROM T A,
							 	       TB_DL_EXPD_MDY_MGMT B,
									   TB_PDI_IV_INFO C
								  WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
								  AND A.MDL_MDY_CD = B.MDL_MDY_CD								  
								  AND A.DL_EXPD_REGN_CD = B.DL_EXPD_REGN_CD 
							      AND A.QLTY_VEHL_CD = C.QLTY_VEHL_CD
         				          AND B.DL_EXPD_MDL_MDY_CD = C.DL_EXPD_MDL_MDY_CD
         				          AND A.LANG_CD = C.LANG_CD
         				          AND C.CLS_YMD = P_TO_YMD --최종일의 재고 데이터를 조회한다.
						          GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD 
								  ***/
								  
							     ) G
					        WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD(+)
                            AND A.MDL_MDY_CD = B.MDL_MDY_CD(+)
                            AND A.LANG_CD = B.LANG_CD(+)
                            AND A.QLTY_VEHL_CD = C.QLTY_VEHL_CD(+)
                            AND A.MDL_MDY_CD = C.MDL_MDY_CD(+)
                            AND A.LANG_CD = C.LANG_CD(+)
                            AND A.QLTY_VEHL_CD = D.QLTY_VEHL_CD(+)
                            AND A.MDL_MDY_CD = D.MDL_MDY_CD(+)
                            AND A.LANG_CD = D.LANG_CD(+)
                            AND A.QLTY_VEHL_CD = E.QLTY_VEHL_CD(+)
                            AND A.MDL_MDY_CD = E.MDL_MDY_CD(+)
                            AND A.LANG_CD = E.LANG_CD(+)
                            AND A.QLTY_VEHL_CD = F.QLTY_VEHL_CD(+)
                            AND A.MDL_MDY_CD = F.MDL_MDY_CD(+)
                            AND A.LANG_CD = F.LANG_CD(+)
                            AND A.QLTY_VEHL_CD = G.QLTY_VEHL_CD(+)
                            AND A.MDL_MDY_CD = G.MDL_MDY_CD(+)
                            AND A.LANG_CD = G.LANG_CD(+)
					        --ORDER BY A.SORT_SN, A.LANG_CD 
							ORDER BY A.SORT_SN, A.LANG_SORT_SN
					       )
				 SELECT REGN_NM, 
					  	LANG_CD, 
						LANG_CD_NM,
				        SEWHA_WHSN_QTY,
					    SEWHA_WHOT_QTY,
					    SEWHA_IV_QTY,
					    PDI_WHSN_QTY,
						PDI_NORMAL_WHOT,
					    PDI_EXTRA_WHOT,
					    PDI_DISUSE_WHOT,
					    PDI_REVICE_WHOT,
					    PDI_IV_QTY,
					    IV_QTY,
						SEWHA_IV_TEXT,
						PDI_IV_TEXT
				 FROM U
				 UNION ALL
				 SELECT 'TOTAL' AS REGN_NM,
				 		'TOTAL' AS LANG_CD,
						'TOTAL' AS LANG_CD_NM,
						SUM(SEWHA_WHSN_QTY) AS SEWHA_WHSN_QTY,
					    SUM(SEWHA_WHOT_QTY) AS SEWHA_WHOT_QTY,
					    SUM(SEWHA_IV_QTY) AS SEWHA_IV_QTY,
					    SUM(PDI_WHSN_QTY) AS PDI_WHSN_QTY,
						SUM(PDI_NORMAL_WHOT) AS PDI_NORMAL_WHOT,
					    SUM(PDI_EXTRA_WHOT) AS PDI_EXTRA_WHOT,
					    SUM(PDI_DISUSE_WHOT) AS PDI_DISUSE_WHOT,
					    SUM(PDI_REVICE_WHOT) AS PDI_REVICE_WHOT,
					    SUM(PDI_IV_QTY) AS PDI_IV_QTY,
					    SUM(IV_QTY) AS IV_QTY,
						'' AS SEWHA_IV_TEXT,
						'' AS PDI_IV_TEXT
				 FROM U;
			
	   END SP_GET_IV_BY_LANG;
	   
	   --날짜별 차종 재고 내역 조회 							   
  	   PROCEDURE SP_GET_IV_BY_YMD(P_VEHL_CD  VARCHAR2,
							      P_MDL_MDY  VARCHAR2,
							      P_REGN_CD  VARCHAR2,
							      P_LANG_CD  VARCHAR2,
							      P_FROM_YMD VARCHAR2,
							      P_TO_YMD	 VARCHAR2,
								  --P_FROM_NUM NUMBER,
								  --P_TO_NUM   NUMBER,
								  --P_CNT OUT NUMBER,
                                  RS OUT REFCUR)
	   IS
	   	 
		 --V_END_NUM NUMBER;
		 
	   BEGIN
	   		
			/**
			SELECT COUNT(*) 
			INTO P_CNT
			FROM TB_WRK_DATE_MGMT
			WHERE WK_YMD BETWEEN P_FROM_YMD AND P_TO_YMD;
			 
			IF P_TO_NUM > P_CNT THEN
		   	  
			   V_END_NUM := P_CNT;
			  
		    ELSE
		      
			   V_END_NUM := P_TO_NUM;
			  
		    END IF;
		    **/
			
			OPEN RS FOR
				 WITH 
				 	  /***
					  T AS (SELECT A.LANG_CD,
								   A.LANG_CD_NM,
								   A.QLTY_VEHL_CD,
								   A.MDL_MDY_CD
						    FROM TB_LANG_MGMT A
							WHERE A.QLTY_VEHL_CD = P_VEHL_CD
							AND A.MDL_MDY_CD = P_MDL_MDY
							AND A.LANG_CD = P_LANG_CD
							AND A.USE_YN = 'Y'
				 	  	   ), 
					  ***/ 
					  
					  U AS (--[참고]나중에 데이터 속도가 느려지면 페이징 기능을 이곳에 넣어주기 위하여 추가된 부분임....
					  	    SELECT WK_YMD
					        FROM (SELECT WK_YMD, ROWNUM AS ROWNM
					              FROM TB_WRK_DATE_MGMT
							      WHERE WK_YMD BETWEEN P_FROM_YMD AND P_TO_YMD
							      ORDER BY WK_YMD
								 )
						    --WHERE ROWNM BETWEEN P_FROM_NUM AND V_END_NUM 
						   )
				 SELECT TO_CHAR(TO_DATE(A.WK_YMD, 'YYYYMMDD'), 'YYYY-MM-DD') AS CLS_YMD,
				 		NVL(B.SEWHA_PRNT_YN, 'N') AS SEWHA_PRNT_YN,
						NVL(B.SEWHA_WHSN_QTY, 0) AS SEWHA_WHSN_QTY,
						NVL(B.SEWHA_NORMAL_WHOT, 0) AS SEWHA_NORMAL_WHOT,
						NVL(B.SEWHA_EXTRA_WHOT, 0) AS SEWHA_EXTRA_WHOT,
						NVL(B.SEWHA_IV_QTY, 0) AS SEWHA_IV_QTY,
						NVL(C.PDI_WHSN_QTY, 0) AS PDI_WHSN_QTY,
						NVL(C.EXPD_WHSN_ST_NM, '') AS EXPD_WHSN_ST_NM,
						NVL(C.PDI_DEEI1_QTY, 0) AS PDI_DEEI1_QTY,
						NVL(C.PDI_NORMAL_WHOT, 0) AS PDI_NORMAL_WHOT,
						NVL(C.PDI_EXTRA_WHOT, 0) AS PDI_EXTRA_WHOT,
						NVL(C.PDI_DISUSE_WHOT, 0) AS PDI_DISUSE_WHOT,
						NVL(C.PDI_REVICE_WHOT, 0) AS PDI_REVICE_WHOT,
						NVL(C.PDI_IV_QTY, 0) AS PDI_IV_QTY,
						NVL(B.SEWHA_IV_QTY, 0) + NVL(C.PDI_IV_QTY, 0) AS IV_QTY,
						FU_GET_SEWHA_IV_TEXT(A.WK_YMD, P_VEHL_CD, P_MDL_MDY, P_LANG_CD) AS SEWHA_IV_TEXT,
						FU_GET_PDI_IV_TEXT(A.WK_YMD, P_VEHL_CD, P_MDL_MDY, P_LANG_CD) AS PDI_IV_TEXT 
				 FROM U A,
				      (SELECT CLS_YMD, 
				 	  		  SUM(SEWHA_IV_QTY) AS SEWHA_IV_QTY,
							  MAX(SEWHA_PRNT_YN) AS SEWHA_PRNT_YN,
				 	  		  SUM(SEWHA_WHSN_QTY) AS SEWHA_WHSN_QTY, 
							  SUM(SEWHA_NORMAL_WHOT) AS SEWHA_NORMAL_WHOT,
							  SUM(SEWHA_EXTRA_WHOT) AS SEWHA_EXTRA_WHOT
				       FROM (SELECT A.CLS_YMD, 
					   				A.QLTY_VEHL_CD, 
									A.MDL_MDY_CD, 
									A.LANG_CD, 
									--A.DL_EXPD_MDL_MDY_CD, 
									A.N_PRNT_PBCN_NO, 
							        MAX(SEWHA_IV_QTY) AS SEWHA_IV_QTY,
									----인쇄중인 수량이 없는데도 재고에 DL_EXPD_TMP_IV_QTY 값이 있는 경우에는 이곳에서 인쇄여부를 바꿔준다. 
									--CASE WHEN MAX(SEWHA_WHSN_QTY) = 0 THEN 'N' ELSE MAX(SEWHA_PRNT_YN) END AS SEWHA_PRNT_YN,
									MAX(SEWHA_PRNT_YN) AS SEWHA_PRNT_YN,
							        MAX(SEWHA_WHSN_QTY) AS SEWHA_WHSN_QTY,
									SUM(CASE WHEN DL_EXPD_RQ_SCN_CD = '01' THEN RQ_QTY ELSE 0 END) AS SEWHA_NORMAL_WHOT,
							        SUM(CASE WHEN DL_EXPD_RQ_SCN_CD = '02' THEN RQ_QTY ELSE 0 END) AS SEWHA_EXTRA_WHOT
				             FROM (SELECT A.CLS_YMD, 
							 	  		  A.QLTY_VEHL_CD, 
										  A.MDL_MDY_CD, 
										  A.LANG_CD, 
										  A.DL_EXPD_MDL_MDY_CD, 
										  A.N_PRNT_PBCN_NO, 
									      MAX(SEWHA_IV_QTY) AS SEWHA_IV_QTY,
										  --MAX(SEWHA_PRNT_YN) AS SEWHA_PRNT_YN,
										  MAX(CASE WHEN A.CLS_YMD < B.DLVG_PARR_YMD THEN 'Y' ELSE 'N' END) AS SEWHA_PRNT_YN,
									      NVL(SUM(WHSN_QTY), 0) AS SEWHA_WHSN_QTY
				                   FROM (
								   		 /*** 
										 SELECT B.CLS_YMD, 
								   				A.QLTY_VEHL_CD, 
												A.MDL_MDY_CD, 
												A.LANG_CD, 
								                B.DL_EXPD_MDL_MDY_CD, 
												B.N_PRNT_PBCN_NO,
								   				----인쇄중 데이터 존재 여부 확인 ==> DL_EXPD_TMP_IV_QTY 값은 Default는  인쇄 수량, 납품이후에는 0으로 설정되어 있음 
						  		                --CASE WHEN SUM(B.DL_EXPD_TMP_IV_QTY) > 0 THEN 'Y' ELSE 'N'END AS SEWHA_PRNT_YN 
								                SUM(B.IV_QTY) AS SEWHA_IV_QTY
         				                 FROM T A,
              				                  TB_SEWHA_IV_INFO_DTL B,
											  U C
         				                 WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
         				                 AND A.MDL_MDY_CD = B.MDL_MDY_CD
         				                 AND A.LANG_CD = B.LANG_CD
         				                 AND B.CLS_YMD = C.WK_YMD
										 ----전상상의 재고 소진된 항목을 추가 출고를 위하여 임시 생성한 경우의 데이터는 가져오지 않는다.
										 --AND B.TMP_TRTM_YN IS NULL 
						                 GROUP BY B.CLS_YMD, A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD, 
										 	   	  B.DL_EXPD_MDL_MDY_CD, B.N_PRNT_PBCN_NO 
										 ***/
										 
										 SELECT A.CLS_YMD, 
								   				A.QLTY_VEHL_CD, 
												A.MDL_MDY_CD, 
												A.LANG_CD, 
								                A.DL_EXPD_MDL_MDY_CD, 
												A.N_PRNT_PBCN_NO,
								   				----인쇄중 데이터 존재 여부 확인 ==> DL_EXPD_TMP_IV_QTY 값은 Default는  인쇄 수량, 납품이후에는 0으로 설정되어 있음 
						  		                --CASE WHEN SUM(A.DL_EXPD_TMP_IV_QTY) > 0 THEN 'Y' ELSE 'N'END AS SEWHA_PRNT_YN 
								                SUM(A.SFTY_IV_QTY) AS SEWHA_IV_QTY
         				                 FROM TB_SEWHA_IV_INFO_DTL A,
											  U B
         				                 WHERE A.QLTY_VEHL_CD = P_VEHL_CD
         				                 AND A.MDL_MDY_CD = P_MDL_MDY
         				                 AND A.LANG_CD = P_LANG_CD
         				                 AND A.CLS_YMD = B.WK_YMD
										 ----전상상의 재고 소진된 항목을 추가 출고를 위하여 임시 생성한 경우의 데이터는 가져오지 않는다.
										 --AND A.TMP_TRTM_YN IS NULL 
						                 GROUP BY A.CLS_YMD, A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD, 
										 	   	  A.DL_EXPD_MDL_MDY_CD, A.N_PRNT_PBCN_NO
												  
						                ) A,
							            TB_SEWHA_WHSN_INFO B
					              WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD(+)
								  --세화입고 정보의 경우 차종연식과 취급설명서 연식이 같을 수 밖에 없다.
								  --(발주의뢰 화면에서 같게 넘어갈 수 밖에 없다.) 
								  --그래서 차종연식은 비교조건에서 빼도록 한다. 
					              --AND A.MDL_MDY_CD = B.MDL_MDY_CD(+) 
					              AND A.LANG_CD = B.LANG_CD(+)
								  AND A.DL_EXPD_MDL_MDY_CD = B.DL_EXPD_MDL_MDY_CD(+)
							      AND A.N_PRNT_PBCN_NO = B.N_PRNT_PBCN_NO(+)
					              --AND A.CLS_YMD = B.WHSN_YMD(+)
							      GROUP BY A.CLS_YMD, A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD, 
								  		   A.DL_EXPD_MDL_MDY_CD, A.N_PRNT_PBCN_NO
					             ) A,
					             TB_SEWHA_WHOT_INFO B
					       WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD(+)
					       AND A.MDL_MDY_CD = B.MDL_MDY_CD(+)
					       AND A.LANG_CD = B.LANG_CD(+)
						   AND A.DL_EXPD_MDL_MDY_CD = B.DL_EXPD_MDL_MDY_CD(+)
					       AND A.N_PRNT_PBCN_NO = B.N_PRNT_PBCN_NO(+)
					       AND A.CLS_YMD = B.WHSN_YMD(+) --출고데이터의 경우에는 PDI입고일과 비교한다. 
						   AND B.DEL_YN(+) = 'N'
					       GROUP BY A.CLS_YMD, A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD, A.N_PRNT_PBCN_NO
						  )
					  GROUP BY CLS_YMD
					 ) B,
					 (SELECT CLS_YMD, 
				 	  		  SUM(PDI_IV_QTY) AS PDI_IV_QTY,
				 	  		  SUM(PDI_WHSN_QTY) AS PDI_WHSN_QTY,
							  MAX(EXPD_WHSN_ST_NM) AS EXPD_WHSN_ST_NM,
							  --CASE WHEN MAX(EXPD_WHSN_ST_CD) = '0' THEN '-'
							  --     WHEN MAX(EXPD_WHSN_ST_CD) = '1' THEN '정상입고'
							  --	   WHEN MAX(EXPD_WHSN_ST_CD) = '2' THEN '과잉'
							  --	   WHEN MAX(EXPD_WHSN_ST_CD) = '3' THEN '부족'
							  --END AS EXPD_WHSN_ST_NM,
							  SUM(PDI_DEEI1_QTY) AS PDI_DEEI1_QTY,
							  SUM(PDI_NORMAL_WHOT) AS PDI_NORMAL_WHOT,
							  SUM(PDI_EXTRA_WHOT) AS PDI_EXTRA_WHOT,
							  SUM(PDI_DISUSE_WHOT) AS PDI_DISUSE_WHOT,
							  SUM(PDI_REVICE_WHOT) * (-1) AS PDI_REVICE_WHOT
				       FROM (SELECT A.CLS_YMD, 
					   				A.QLTY_VEHL_CD, 
									A.MDL_MDY_CD,
									A.LANG_CD, 
									--A.DL_EXPD_MDL_MDY_CD, 
									A.N_PRNT_PBCN_NO, 
							        MAX(PDI_IV_QTY) AS PDI_IV_QTY,
							        MAX(PDI_WHSN_QTY) AS PDI_WHSN_QTY,
									NVL(MAX(C.DL_EXPD_PRVS_NM), '') AS EXPD_WHSN_ST_NM,
									--MAX(EXPD_WHSN_ST_CD) AS EXPD_WHSN_ST_CD,
									MAX(PDI_DEEI1_QTY) AS PDI_DEEI1_QTY,
							        SUM(CASE WHEN DL_EXPD_WHOT_ST_CD = '01' THEN DL_EXPD_WHOT_QTY ELSE 0 END) AS PDI_NORMAL_WHOT,     --출고 
									SUM(CASE WHEN DL_EXPD_WHOT_ST_CD = '02' THEN DL_EXPD_WHOT_QTY ELSE 0 END) AS PDI_EXTRA_WHOT,              --별도출고
									SUM(CASE WHEN DL_EXPD_WHOT_ST_CD = '03' THEN DL_EXPD_WHOT_QTY ELSE 0 END) AS PDI_DISUSE_WHOT,             --폐기 
									SUM(CASE WHEN DL_EXPD_WHOT_ST_CD IN ('04','05','06', '07', '08','09') THEN DL_EXPD_WHOT_QTY ELSE 0 END) AS PDI_REVICE_WHOT --재고보정 
				             FROM (SELECT A.CLS_YMD, 
							 	  		  A.QLTY_VEHL_CD, 
										  A.MDL_MDY_CD,
										  A.LANG_CD, 
										  A.DL_EXPD_MDL_MDY_CD,
										  A.N_PRNT_PBCN_NO, 
									      MAX(PDI_IV_QTY) AS PDI_IV_QTY,
										  MAX(DL_EXPD_WHSN_ST_CD) AS EXPD_WHSN_ST_CD,
										  --MAX(CASE WHEN DL_EXPD_WHSN_ST_CD = '01' THEN '1'
										  --         WHEN DL_EXPD_WHSN_ST_CD = '02' THEN '3'
										  --		   WHEN DL_EXPD_WHSN_ST_CD = '03' THEN '2'
										  -- 		   ELSE '0'
										  --	  END) AS EXPD_WHSN_ST_CD,
									      NVL(SUM(B.WHSN_QTY), 0) AS PDI_WHSN_QTY,
										  NVL(SUM(B.DEEI1_QTY), 0) AS PDI_DEEI1_QTY
				                   FROM (
								   		 /*** 
										 SELECT B.CLS_YMD, 
								   				A.QLTY_VEHL_CD, 
												A.MDL_MDY_CD, 
												A.LANG_CD, 
												B.DL_EXPD_MDL_MDY_CD, 
												B.N_PRNT_PBCN_NO, 
								                SUM(B.IV_QTY) AS PDI_IV_QTY
         				                 FROM T A,
              				                  TB_PDI_IV_INFO_DTL B,
											  U C
         				                 WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
         				                 AND A.MDL_MDY_CD = B.MDL_MDY_CD
         				                 AND A.LANG_CD = B.LANG_CD
         				                 AND B.CLS_YMD = C.WK_YMD
						                 GROUP BY B.CLS_YMD, A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD, 
										          B.DL_EXPD_MDL_MDY_CD, B.N_PRNT_PBCN_NO 
										 ***/
										 
										 SELECT A.CLS_YMD, 
								   				A.QLTY_VEHL_CD, 
												A.MDL_MDY_CD, 
												A.LANG_CD, 
												A.DL_EXPD_MDL_MDY_CD, 
												A.N_PRNT_PBCN_NO, 
								                SUM(A.SFTY_IV_QTY) AS PDI_IV_QTY
         				                 FROM TB_PDI_IV_INFO_DTL A,
											  U B
         				                 WHERE A.QLTY_VEHL_CD = P_VEHL_CD
         				                 AND A.MDL_MDY_CD = P_MDL_MDY
         				                 AND A.LANG_CD = P_LANG_CD
         				                 AND A.CLS_YMD = B.WK_YMD
						                 GROUP BY A.CLS_YMD, A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD, 
										          A.DL_EXPD_MDL_MDY_CD, A.N_PRNT_PBCN_NO
						                ) A,
							            TB_PDI_WHSN_INFO B
					              WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD(+)
					              AND A.MDL_MDY_CD = B.MDL_MDY_CD(+)
					              AND A.LANG_CD = B.LANG_CD(+)
								  AND A.DL_EXPD_MDL_MDY_CD = B.DL_EXPD_MDL_MDY_CD(+)
							      AND A.N_PRNT_PBCN_NO = B.N_PRNT_PBCN_NO(+)
					              AND A.CLS_YMD = B.WHSN_YMD(+)
							      GROUP BY A.CLS_YMD, A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD, 
								           A.DL_EXPD_MDL_MDY_CD, A.N_PRNT_PBCN_NO
					             ) A,
					             TB_PDI_WHOT_INFO B,
								 TB_CODE_MGMT C
					       WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD(+)
						   AND A.MDL_MDY_CD = B.MDL_MDY_CD(+)
					       AND A.LANG_CD = B.LANG_CD(+)
						   AND A.DL_EXPD_MDL_MDY_CD = B.DL_EXPD_MDL_MDY_CD(+)
					       AND A.N_PRNT_PBCN_NO = B.N_PRNT_PBCN_NO(+)
					       AND A.CLS_YMD = B.WHOT_YMD(+)
						   AND B.DEL_YN(+) = 'N'
						   AND A.EXPD_WHSN_ST_CD = C.DL_EXPD_PRVS_CD(+)
						   AND C.DL_EXPD_G_CD(+) = '0013'
					       GROUP BY A.CLS_YMD, A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD, A.N_PRNT_PBCN_NO
						  )
					  GROUP BY CLS_YMD
				     ) C
			    WHERE A.WK_YMD = B.CLS_YMD(+)
				AND A.WK_YMD = C.CLS_YMD(+)
				ORDER BY A.WK_YMD;

	   END SP_GET_IV_BY_YMD;
       
	   --주간계획(2주) 데이터 조회  							  
	   PROCEDURE SP_GET_2WEK_PLAN_INFO(P_DATA_SN  NUMBER,
   			 					       P_CURR_YMD VARCHAR2,
								       RS         OUT REFCUR,
                                       P_MESSAGE  OUT VARCHAR2)
	   IS
	   	 
		 V_SCH_YMD  VARCHAR2(8);
		 
		 V_MESSAGE  VARCHAR2(8000);
		 
		 V_TO_YMD   VARCHAR2(8);
		 
	   BEGIN
	   		
			--생산계획 및 생산 현황의 현재일 기준 최종 인터페이스 시간정보를 조회 
			SP_GET_MSG_PLAN_PROD(P_DATA_SN, P_CURR_YMD, V_SCH_YMD, V_MESSAGE);
			
			P_MESSAGE := V_MESSAGE;
			
			V_TO_YMD := TO_CHAR(TO_DATE(P_CURR_YMD, 'YYYYMMDD') + 14, 'YYYYMMDD');
			
	   		OPEN RS FOR
				 WITH T AS (SELECT TO_CHAR(TO_DATE(A.WK_YMD, 'YYYYMMDD'), 'YYYY-MM-DD') AS WK_YMD,
				 	  	   		   A.IDX_NM, --D+0, D+1, ... 
				                   A.DOW_NM, --요일명칭
						           NVL(B.PRDN_PLN_QTY, 0) AS PRDN_PLN_QTY,
						           NVL(B.DCSN_YN, '') AS DCSN_YN,
								   ROWNM
				            FROM (SELECT A.WK_YMD,
								 		 'D+' || TO_CHAR(ROWNUM - 1) AS IDX_NM,
				                         B.DL_EXPD_PRVS_NM AS DOW_NM,
										 ROWNUM AS ROWNM
				                  FROM TB_WRK_DATE_MGMT A,
                                       TB_CODE_MGMT B
					              WHERE A.DOW_CD = B.DL_EXPD_PRVS_CD
					              AND B.DL_EXPD_G_CD = '0018'
					              AND A.WK_YMD BETWEEN P_CURR_YMD AND V_TO_YMD
								  ORDER BY A.WK_YMD
					             ) A,
					             (SELECT PLN_PARR_YMD, 
				 		                 SUM(PRDN_PLN_QTY) AS PRDN_PLN_QTY, 
						                 MAX(B.DL_EXPD_PRVS_NM) AS DCSN_YN
				                  FROM TB_APS_PROD_PLAN_SUM_INFO A,
					   		           TB_CODE_MGMT B
				                  WHERE APL_STRT_YMD <= V_SCH_YMD
				                  AND APL_FNH_YMD >= V_SCH_YMD
				                  AND DATA_SN = P_DATA_SN
					              AND A.DCSN_YN = B.DL_EXPD_PRVS_CD
					              AND B.DL_EXPD_G_CD = '0019'
				                  AND PLN_PARR_YMD BETWEEN P_CURR_YMD AND V_TO_YMD
				                  GROUP BY PLN_PARR_YMD
					             ) B
							WHERE A.WK_YMD = B.PLN_PARR_YMD(+)
							
							UNION ALL
							
							SELECT 'PDI 미통과분' AS WK_YMD,
								   '' AS IDX_NM,
								   '' AS DOW_NM,
								   NVL(TDD_PRDN_QTY3, 0) AS PRDN_PLN_QTY,
								   '' AS DCSN_YN,
								   0 AS ROWNM
							FROM TB_APS_PROD_SUM_INFO
							WHERE APL_YMD = P_CURR_YMD
							AND DATA_SN = P_DATA_SN
						   )
				 SELECT WK_YMD,
				 		IDX_NM,
				        DOW_NM,
						PRDN_PLN_QTY,
						DCSN_YN
				 FROM (SELECT WK_YMD,
				 			  IDX_NM,
				        	  DOW_NM,
							  PRDN_PLN_QTY,
							  DCSN_YN
					   FROM T
					   ORDER BY ROWNM
					  )
				 UNION ALL
				 SELECT 'TOTAL' AS WK_YMD,
				 		'TOTAL' AS IDX_NM,
				 		'TOTAL' AS DOW_NM,
						SUM(PRDN_PLN_QTY) AS PRDN_PLN_QTY,
						'' AS DCSN_YN
				 FROM T;
				 
				 /**
				 WITH T AS (SELECT TO_CHAR(TO_DATE(A.WK_YMD, 'YYYYMMDD'), 'YYYY-MM-DD') AS WK_YMD,
				 	  	   		   A.IDX_NM, --D+0, D+1, ... 
				                   A.DOW_NM, --요일명칭
						           NVL(B.PRDN_PLN_QTY, 0)  + NVL(C.TDD_PRDN_PLAN_QTY, 0) AS PRDN_PLN_QTY,
						           NVL(B.DCSN_YN, '') AS DCSN_YN
				            FROM (SELECT A.WK_YMD,
								 		 'D+' || TO_CHAR(ROWNUM - 1) AS IDX_NM,
				                         B.DL_EXPD_PRVS_NM AS DOW_NM
				                  FROM TB_WRK_DATE_MGMT A,
                                       TB_CODE_MGMT B
					              WHERE A.DOW_CD = B.DL_EXPD_PRVS_CD
					              AND B.DL_EXPD_G_CD = '0018'
					              AND A.WK_YMD BETWEEN P_CURR_YMD AND V_TO_YMD
								  ORDER BY A.WK_YMD
					             ) A,
					             (SELECT PLN_PARR_YMD, 
				 		                 SUM(PRDN_PLN_QTY) AS PRDN_PLN_QTY, 
						                 MAX(B.DL_EXPD_PRVS_NM) AS DCSN_YN
				                  FROM TB_APS_PROD_PLAN_SUM_INFO A,
					   		           TB_CODE_MGMT B
				                  WHERE APL_STRT_YMD <= V_SCH_YMD
				                  AND APL_FNH_YMD >= V_SCH_YMD
				                  AND DATA_SN = P_DATA_SN
					              AND A.DCSN_YN = B.DL_EXPD_PRVS_CD
					              AND B.DL_EXPD_G_CD = '0019'
				                  AND PLN_PARR_YMD BETWEEN P_CURR_YMD AND V_TO_YMD
				                  GROUP BY PLN_PARR_YMD
					             ) B,
								 (SELECT P_CURR_YMD AS PLN_PARR_YMD,
								 		 NVL(TDD_PRDN_QTY3, 0) AS TDD_PRDN_PLAN_QTY
								  FROM TB_APS_PROD_SUM_INFO
								  WHERE APL_YMD = P_CURR_YMD
								  AND DATA_SN = P_DATA_SN
								 ) C
				             WHERE A.WK_YMD = B.PLN_PARR_YMD(+)
							 AND A.WK_YMD = C.PLN_PARR_YMD(+)
						    )
				 SELECT WK_YMD,
				 		IDX_NM,
				        DOW_NM,
						PRDN_PLN_QTY,
						DCSN_YN
				 FROM T
				 UNION ALL
				 SELECT 'TOTAL' AS WK_YMD,
				 		'TOTAL' AS IDX_NM,
				 		'TOTAL' AS DOW_NM,
						SUM(PRDN_PLN_QTY) AS PRDN_PLN_QTY,
						'' AS DCSN_YN
				 FROM T
				 ORDER BY WK_YMD;
				 **/
				 
	   END SP_GET_2WEK_PLAN_INFO;
	   
	   PROCEDURE SP_GET_2WEK_PLAN_INFO2(P_DATA_SN      NUMBER,
   			 					        P_CURR_YMD     VARCHAR2,
								        P_PRDN_PLNT_CD VARCHAR2,
								        RS             OUT REFCUR,
                                        P_MESSAGE      OUT VARCHAR2)
	   IS
	   	 V_SCH_YMD  VARCHAR2(8);
		 
		 V_MESSAGE  VARCHAR2(8000);
		 
		 V_TO_YMD   VARCHAR2(8);
		 
	   BEGIN
	   		
			IF P_PRDN_PLNT_CD = 'ALL' THEN
			   
			   SP_GET_2WEK_PLAN_INFO(P_DATA_SN, P_CURR_YMD, RS, P_MESSAGE);
			   
			ELSE
			   
			   --생산계획 및 생산 현황의 현재일 기준 최종 인터페이스 시간정보를 조회 
			   SP_GET_MSG_PLAN_PROD(P_DATA_SN, P_CURR_YMD, V_SCH_YMD, V_MESSAGE);
			
			   P_MESSAGE := V_MESSAGE;
			
			   V_TO_YMD := TO_CHAR(TO_DATE(P_CURR_YMD, 'YYYYMMDD') + 14, 'YYYYMMDD');
			
	   		   OPEN RS FOR
				 	WITH T AS (SELECT TO_CHAR(TO_DATE(A.WK_YMD, 'YYYYMMDD'), 'YYYY-MM-DD') AS WK_YMD,
				 	  	   		   	  A.IDX_NM, --D+0, D+1, ... 
				                   	  A.DOW_NM, --요일명칭
						           	  NVL(B.PRDN_PLN_QTY, 0) AS PRDN_PLN_QTY,
						           	  NVL(B.DCSN_YN, '') AS DCSN_YN,
								   	  ROWNM
				               FROM (SELECT A.WK_YMD,
								 		 	'D+' || TO_CHAR(ROWNUM - 1) AS IDX_NM,
				                         	B.DL_EXPD_PRVS_NM AS DOW_NM,
										 	ROWNUM AS ROWNM
				                     FROM TB_WRK_DATE_MGMT A,
                                       	  TB_CODE_MGMT B
					              	 WHERE A.DOW_CD = B.DL_EXPD_PRVS_CD
					              	 AND B.DL_EXPD_G_CD = '0018'
					              	 AND A.WK_YMD BETWEEN P_CURR_YMD AND V_TO_YMD
								  	 ORDER BY A.WK_YMD
					                ) A,
					                (SELECT PLN_PARR_YMD, 
				 		                    SUM(PRDN_PLN_QTY) AS PRDN_PLN_QTY, 
						                    MAX(B.DL_EXPD_PRVS_NM) AS DCSN_YN
				                     FROM TB_PLNT_APS_PROD_PLAN_SUM_INFO A,
					   		              TB_CODE_MGMT B
				                     WHERE APL_STRT_YMD <= V_SCH_YMD
				                     AND APL_FNH_YMD >= V_SCH_YMD
				                     AND DATA_SN = P_DATA_SN
									 AND PRDN_PLNT_CD = P_PRDN_PLNT_CD
					                 AND A.DCSN_YN = B.DL_EXPD_PRVS_CD
					                 AND B.DL_EXPD_G_CD = '0019'
				                     AND PLN_PARR_YMD BETWEEN P_CURR_YMD AND V_TO_YMD
				                     GROUP BY PLN_PARR_YMD
					                ) B
							   WHERE A.WK_YMD = B.PLN_PARR_YMD(+)
							
							   UNION ALL
							
							   SELECT 'PDI 미통과분' AS WK_YMD,
								      '' AS IDX_NM,
								      '' AS DOW_NM,
								      NVL(TDD_PRDN_QTY3, 0) AS PRDN_PLN_QTY,
								      '' AS DCSN_YN,
								      0 AS ROWNM
							   FROM TB_PLNT_APS_PROD_SUM_INFO
							   WHERE APL_YMD = P_CURR_YMD
							   AND DATA_SN = P_DATA_SN
							   AND PRDN_PLNT_CD = P_PRDN_PLNT_CD
						      )
				    SELECT WK_YMD,
				 		   IDX_NM,
				           DOW_NM,
						   PRDN_PLN_QTY,
						   DCSN_YN
				    FROM (SELECT WK_YMD,
				 			     IDX_NM,
				        	     DOW_NM,
							     PRDN_PLN_QTY,
							     DCSN_YN
					      FROM T
					      ORDER BY ROWNM
					     )
				    UNION ALL
				    SELECT 'TOTAL' AS WK_YMD,
				 		   'TOTAL' AS IDX_NM,
				 		   'TOTAL' AS DOW_NM,
						   SUM(PRDN_PLN_QTY) AS PRDN_PLN_QTY,
						   '' AS DCSN_YN
				    FROM T;
			END IF;
			
	   END SP_GET_2WEK_PLAN_INFO2;					   
								   
	   --주간계획(2주) 화면 내의 Summary 내역 조회 								  
  	   PROCEDURE SP_GET_TOT_ODR_INFO(P_DATA_SN  NUMBER,
   			 					     P_CURR_YMD VARCHAR2,
								     RS OUT REFCUR)
	   IS
	   	 
		 V_SCH_YMD1  VARCHAR2(8);
		 V_SCH_YMD2  VARCHAR2(8);
		 
		 V_MESSAGE  VARCHAR2(8000);
		 
		 V_PREV_MTH_PACK VARCHAR2(4); --이전월팩
		 V_CURR_MTH_PACK VARCHAR2(4); --현재월팩
		 V_PREV_1MTH_YMD VARCHAR2(8); --1개월전 마지막 날짜
		 V_CURR_FSTD_YMD VARCHAR2(8); --현재월 1일 날짜
		 V_CURR_LAST_YMD VARCHAR2(8); --현재월 마지막 날짜 
		 
		 V_CURR_DATE DATE;
		 
	   BEGIN
	   		
			--SP_GET_MSG_ODR_PLAN(P_DATA_SN, P_CURR_YMD, V_SCH_YMD1, V_SCH_YMD2, V_MESSAGE);
			SP_GET_MSG_PLAN_PROD(P_DATA_SN, P_CURR_YMD, V_SCH_YMD1, V_MESSAGE);
			
			V_SCH_YMD2 := V_SCH_YMD1;
			
			V_CURR_DATE := TO_DATE(P_CURR_YMD, 'YYYYMMDD');
			
			V_PREV_MTH_PACK := TO_CHAR(V_CURR_DATE - 1, 'YYMM');
			V_CURR_MTH_PACK := TO_CHAR(V_CURR_DATE, 'YYMM');
			V_PREV_1MTH_YMD := TO_CHAR(LAST_DAY(ADD_MONTHS(V_CURR_DATE, -1)), 'YYYYMMDD');
			V_CURR_FSTD_YMD := TO_CHAR(V_CURR_DATE, 'YYYYMM') || '01';
			V_CURR_LAST_YMD := TO_CHAR(LAST_DAY(V_CURR_DATE), 'YYYYMMDD');
			
			OPEN RS FOR
				 SELECT PREV_PLAN_QTY + CURR_ORD_QTY AS TOT_ORD_QTY,                 --총오더
				 		PREV_PROD_QTY,                                               --선생산 
						PREV_PLAN_QTY + CURR_ORD_QTY - PREV_PROD_QTY AS NET_ORD_QTY, --가용오더 
						CURR_ORD_QTY,                                                --당월오더 
						CURR_PROD_QTY,                                               --당월생산 
						CURR_PLAN_QTY,                                               --당월예상 
						PREV_PLAN_QTY + CURR_ORD_QTY - PREV_PROD_QTY - CURR_PROD_QTY - CURR_PLAN_QTY NEXT_ORD_QTY --차월이월 
				 FROM (SELECT --지난달까지 생산되지 않은 오더수량 
				 	  		  (SELECT SUM(PRDN_PLN_QTY)
				       		   FROM TB_APS_ODR_SUM_INFO
							   WHERE APL_STRT_YMD <= V_SCH_YMD1
							   AND APL_FNH_YMD >= V_SCH_YMD1
							   AND MO_PACK_CD <= V_PREV_MTH_PACK 
                               AND DATA_SN = P_DATA_SN
							  ) AS PREV_PLAN_QTY,
							  --당월오더수량 
							  (SELECT SUM(ORD_QTY)
				       		   FROM TB_APS_ODR_SUM_INFO
							   WHERE APL_STRT_YMD <= V_SCH_YMD1
							   AND APL_FNH_YMD >= V_SCH_YMD1
							   AND MO_PACK_CD = V_CURR_MTH_PACK 
                               AND DATA_SN = P_DATA_SN
							  ) AS CURR_ORD_QTY,
							  --선생산 수량 
							  (SELECT SUM(PRDN_TRWI_QTY)
							   FROM TB_PROD_ODR_INFO
							   WHERE MO_PACK_CD >= V_CURR_MTH_PACK 
							   AND DATA_SN = P_DATA_SN
							   AND APL_YMD <= V_PREV_1MTH_YMD
							  ) AS PREV_PROD_QTY,
							  --당월생산수량
							  (SELECT SUM(PRDN_TRWI_QTY)
							   FROM TB_PROD_MST_SUM_INFO
							   WHERE APL_YMD BETWEEN V_CURR_FSTD_YMD AND P_CURR_YMD
							   AND DATA_SN = P_DATA_SN
							  ) AS CURR_PROD_QTY,
							  --당월예상수량 
							  (SELECT SUM(PRDN_PLN_QTY)
							   FROM TB_APS_PROD_PLAN_SUM_INFO
							   WHERE APL_STRT_YMD <= V_SCH_YMD2
							   AND APL_FNH_YMD >= V_SCH_YMD2
							   AND PLN_PARR_YMD BETWEEN P_CURR_YMD AND V_CURR_LAST_YMD
                               AND DATA_SN = P_DATA_SN
							  ) AS CURR_PLAN_QTY
					   FROM DUAL
				      );       
				 
	   END SP_GET_TOT_ODR_INFO;
	   
	   --단기계획(3일) 데이터 조회 								
  	   PROCEDURE SP_GET_3DAY_PLAN_INFO(P_DATA_SN      NUMBER,
   			 					  	   P_CURR_YMD     VARCHAR2,
								       RS             OUT REFCUR ,
								       P_PLAN_TOT_QTY OUT NUMBER,
								       P_MESSAGE	  OUT VARCHAR2
									   )
	   IS
	   	 	
			V_SCH_YMD  VARCHAR2(8);
			
			V_MESSAGE  VARCHAR2(8000);
			
			V_TDD_PRDN_PLAN_QTY NUMBER;
			V_TDD_PRDN_QTY3     NUMBER;
			V_TDD_PRDN_QTY      NUMBER;
			
			V_NEXT_2DAY_YMD VARCHAR2(8);
			
			V_PAC_SCN_CD VARCHAR2(4);
			V_PDI_CD	 VARCHAR2(4);
			V_LANG_CD	 VARCHAR2(3);
			
	   BEGIN
	   		
			--생산 현황의 현재일 기준 최종 인터페이스 시간정보를 조회 
			SP_GET_MSG_PROD2(P_DATA_SN, P_CURR_YMD, V_SCH_YMD, V_MESSAGE);
			
			P_MESSAGE := V_MESSAGE;
			
			
			SELECT NVL(SUM(TDD_PRDN_PLN_QTY), 0),
				   NVL(SUM(TDD_PRDN_QTY3), 0),
				   NVL(SUM(TDD_PRDN_QTY), 0)
			INTO V_TDD_PRDN_PLAN_QTY, 
				 V_TDD_PRDN_QTY3,
				 V_TDD_PRDN_QTY
			FROM TB_APS_PROD_SUM_INFO
			WHERE DATA_SN = P_DATA_SN
			AND APL_YMD = P_CURR_YMD;
			
			SELECT MAX(DL_EXPD_PAC_SCN_CD),
				   MAX(DL_EXPD_PDI_CD),
				   MAX(LANG_CD)
			INTO V_PAC_SCN_CD,
			     V_PDI_CD,
				 V_LANG_CD
			FROM TB_LANG_MGMT A,
			     TB_VEHL_MGMT B
			WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
			AND A.MDL_MDY_CD = B.MDL_MDY_CD
			AND A.DATA_SN = P_DATA_SN;
			
			P_PLAN_TOT_QTY := V_TDD_PRDN_PLAN_QTY + V_TDD_PRDN_QTY3;
			
			V_NEXT_2DAY_YMD := PG_COMMON.FU_GET_WRKDATE(P_CURR_YMD, 2);
			
			OPEN RS FOR
			    SELECT TH0_POW_STRT_YMDHM,
					   TH0_POW_FNH_YMDHM,
					   TH0_POW_TRWI_QTY,
					   NVL(TH1_POW_STRT_YMDHM, '')	AS TH1_POW_STRT_YMDHM,
					   NVL(TH1_POW_FNH_YMDHM,  '')  AS TH1_POW_FNH_YMDHM,
					   NVL(TH1_POW_TRWI_QTY,    0)  AS TH1_POW_TRWI_QTY, 
					   NVL(TH2_POW_STRT_YMDHM, '')  AS TH2_POW_STRT_YMDHM,
					   NVL(TH2_POW_FNH_YMDHM,  '')  AS TH2_POW_FNH_YMDHM,  
					   NVL(TH2_POW_TRWI_QTY,    0)  AS TH2_POW_TRWI_QTY,  
					   NVL(TH3_POW_STRT_YMDHM, '')  AS TH3_POW_STRT_YMDHM,
					   NVL(TH3_POW_FNH_YMDHM,  '')  AS TH3_POW_FNH_YMDHM,  
					   NVL(TH3_POW_TRWI_QTY,    0)  AS TH3_POW_TRWI_QTY,  
					   NVL(TH4_POW_STRT_YMDHM, '')  AS TH4_POW_STRT_YMDHM,
					   NVL(TH4_POW_FNH_YMDHM,  '')  AS TH4_POW_FNH_YMDHM, 
					   NVL(TH4_POW_TRWI_QTY,    0)  AS TH4_POW_TRWI_QTY,  
					   NVL(TH5_POW_STRT_YMDHM, '')  AS TH5_POW_STRT_YMDHM,
					   NVL(TH5_POW_FNH_YMDHM,  '')  AS TH5_POW_FNH_YMDHM, 
					   NVL(TH5_POW_TRWI_QTY,    0)  AS TH5_POW_TRWI_QTY,  
					   NVL(TH6_POW_STRT_YMDHM, '')  AS TH6_POW_STRT_YMDHM,
					   NVL(TH6_POW_FNH_YMDHM,  '')  AS TH6_POW_FNH_YMDHM,  
					   NVL(TH6_POW_TRWI_QTY,    0)  AS TH6_POW_TRWI_QTY,  
					   NVL(TH7_POW_STRT_YMDHM, '')  AS TH7_POW_STRT_YMDHM,
					   NVL(TH7_POW_FNH_YMDHM,  '')  AS TH7_POW_FNH_YMDHM, 
					   NVL(TH7_POW_TRWI_QTY,    0)  AS TH7_POW_TRWI_QTY,  
					   NVL(TH8_POW_STRT_YMDHM, '')  AS TH8_POW_STRT_YMDHM,
					   NVL(TH8_POW_FNH_YMDHM,  '')  AS TH8_POW_FNH_YMDHM, 
					   NVL(TH8_POW_TRWI_QTY,    0)  AS TH8_POW_TRWI_QTY,  
					   NVL(TH9_POW_STRT_YMDHM, '')  AS TH9_POW_STRT_YMDHM,
					   NVL(TH9_POW_FNH_YMDHM,  '')  AS TH9_POW_FNH_YMDHM,
					   NVL(TH9_POW_TRWI_QTY,    0)  AS TH9_POW_TRWI_QTY,
					   NVL(TH10_POW_STRT_YMDHM,'')  AS TH10_POW_STRT_YMDHM,     
					   NVL(TH10_POW_FNH_YMDHM, '')  AS TH10_POW_FNH_YMDHM,
					   NVL(TH10_POW_TRWI_QTY,   0)  AS TH10_POW_TRWI_QTY, 
					   NVL(TH11_POW_STRT_YMDHM,'')  AS TH11_POW_STRT_YMDHM,      
					   NVL(TH11_POW_FNH_YMDHM, '')  AS TH11_POW_FNH_YMDHM,
					   NVL(TH11_POW_TRWI_QTY,   0)  AS TH11_POW_TRWI_QTY, 
					   NVL(TH12_POW_STRT_YMDHM,'')  AS TH12_POW_STRT_YMDHM, 
					   NVL(TH12_POW_FNH_YMDHM, '')  AS TH12_POW_FNH_YMDHM,
					   NVL(TH12_POW_TRWI_QTY,   0)  AS TH12_POW_TRWI_QTY, 
					   NVL(TH13_POW_STRT_YMDHM,'')  AS TH13_POW_STRT_YMDHM, 
					   NVL(TH13_POW_FNH_YMDHM, '')  AS TH13_POW_FNH_YMDHM,
					   NVL(TH13_POW_TRWI_QTY,   0)  AS TH13_POW_TRWI_QTY, 
					   NVL(TH14_POW_STRT_YMDHM,'')  AS TH14_POW_STRT_YMDHM,     
					   NVL(TH14_POW_FNH_YMDHM, '')  AS TH14_POW_FNH_YMDHM,
					   NVL(TH14_POW_TRWI_QTY,   0)  AS TH14_POW_TRWI_QTY, 
					   NVL(TH15_POW_STRT_YMDHM,'')  AS TH15_POW_STRT_YMDHM,   
					   NVL(TH15_POW_FNH_YMDHM, '')  AS TH15_POW_FNH_YMDHM,
					   NVL(TH15_POW_TRWI_QTY,   0)  AS TH15_POW_TRWI_QTY, 
					   NVL(TH16_POW_STRT_YMDHM,'')  AS TH16_POW_STRT_YMDHM,   
					   NVL(TH16_POW_FNH_YMDHM, '')  AS TH16_POW_FNH_YMDHM,
					   NVL(TH16_POW_TRWI_QTY,   0)  AS TH16_POW_TRWI_QTY,
					   FU_GET_MIN_YMDHM(V_PAC_SCN_CD, V_PDI_CD,V_LANG_CD,
					                    TH9_POW_STRT_YMDHM, TH10_POW_STRT_YMDHM, TH11_POW_STRT_YMDHM, TH12_POW_STRT_YMDHM,
					                    TH13_POW_STRT_YMDHM, TH14_POW_STRT_YMDHM, TH15_POW_STRT_YMDHM, TH16_POW_STRT_YMDHM) AS POW_STRT_YMDHM,
					   FU_GET_MAX_YMDHM(V_PAC_SCN_CD, V_PDI_CD,V_LANG_CD,
					                    TH9_POW_FNH_YMDHM, TH10_POW_FNH_YMDHM, TH11_POW_FNH_YMDHM, TH12_POW_FNH_YMDHM,
					                    TH13_POW_FNH_YMDHM, TH14_POW_FNH_YMDHM, TH15_POW_FNH_YMDHM, TH16_POW_FNH_YMDHM) AS POW_FNH_YMDHM,
					   V_TDD_PRDN_QTY3 AS POW_TRWI_QTY
			    FROM (SELECT P_DATA_SN AS DATA_SN,
				 		     TO_CHAR(TO_DATE(P_CURR_YMD,'YYYYMMDD'), 'YYYY/MM/DD') AS TH0_POW_STRT_YMDHM,
				 	         TO_CHAR(TO_DATE(V_NEXT_2DAY_YMD,'YYYYMMDD'), 'YYYY/MM/DD') AS TH0_POW_FNH_YMDHM,
						     V_TDD_PRDN_PLAN_QTY - (V_TDD_PRDN_QTY - V_TDD_PRDN_QTY3) AS TH0_POW_TRWI_QTY
				      FROM DUAL
				     ) A,
				     (SELECT DATA_SN,
						     TO_CHAR(TO_DATE(FU_GET_VALID_YMDHM(TH1_POW_STRT_YMDHM),'YYYYMMDDHH24MI'), 'YYYY/MM/DD HH24:MI') AS TH1_POW_STRT_YMDHM,
       				         TO_CHAR(TO_DATE(FU_GET_VALID_YMDHM(TH1_POW_FNH_YMDHM),'YYYYMMDDHH24MI'), 'YYYY/MM/DD HH24:MI') AS TH1_POW_FNH_YMDHM,
       				         TH1_POW_TRWI_QTY, 
       				         TO_CHAR(TO_DATE(FU_GET_VALID_YMDHM(TH2_POW_STRT_YMDHM),'YYYYMMDDHH24MI'), 'YYYY/MM/DD HH24:MI') AS TH2_POW_STRT_YMDHM,
       				         TO_CHAR(TO_DATE(FU_GET_VALID_YMDHM(TH2_POW_FNH_YMDHM),'YYYYMMDDHH24MI'), 'YYYY/MM/DD HH24:MI') AS TH2_POW_FNH_YMDHM,  
       					     TH2_POW_TRWI_QTY,  
       					     TO_CHAR(TO_DATE(FU_GET_VALID_YMDHM(TH3_POW_STRT_YMDHM),'YYYYMMDDHH24MI'), 'YYYY/MM/DD HH24:MI') AS TH3_POW_STRT_YMDHM,
       						 TO_CHAR(TO_DATE(FU_GET_VALID_YMDHM(TH3_POW_FNH_YMDHM),'YYYYMMDDHH24MI'), 'YYYY/MM/DD HH24:MI') AS TH3_POW_FNH_YMDHM,  
       						 TH3_POW_TRWI_QTY,  
       						 TO_CHAR(TO_DATE(FU_GET_VALID_YMDHM(TH4_POW_STRT_YMDHM),'YYYYMMDDHH24MI'), 'YYYY/MM/DD HH24:MI') AS TH4_POW_STRT_YMDHM,
       						 TO_CHAR(TO_DATE(FU_GET_VALID_YMDHM(TH4_POW_FNH_YMDHM),'YYYYMMDDHH24MI'), 'YYYY/MM/DD HH24:MI') AS TH4_POW_FNH_YMDHM, 
       						 TH4_POW_TRWI_QTY,  
       						 TO_CHAR(TO_DATE(FU_GET_VALID_YMDHM(TH5_POW_STRT_YMDHM),'YYYYMMDDHH24MI'), 'YYYY/MM/DD HH24:MI') AS TH5_POW_STRT_YMDHM,
       						 TO_CHAR(TO_DATE(FU_GET_VALID_YMDHM(TH5_POW_FNH_YMDHM),'YYYYMMDDHH24MI'), 'YYYY/MM/DD HH24:MI') AS TH5_POW_FNH_YMDHM, 
       						 TH5_POW_TRWI_QTY,  
       						 TO_CHAR(TO_DATE(FU_GET_VALID_YMDHM(TH6_POW_STRT_YMDHM),'YYYYMMDDHH24MI'), 'YYYY/MM/DD HH24:MI') AS TH6_POW_STRT_YMDHM,
       						 TO_CHAR(TO_DATE(FU_GET_VALID_YMDHM(TH6_POW_FNH_YMDHM),'YYYYMMDDHH24MI'), 'YYYY/MM/DD HH24:MI') AS TH6_POW_FNH_YMDHM,  
       						 TH6_POW_TRWI_QTY,  
       						 TO_CHAR(TO_DATE(FU_GET_VALID_YMDHM(TH7_POW_STRT_YMDHM),'YYYYMMDDHH24MI'), 'YYYY/MM/DD HH24:MI') AS TH7_POW_STRT_YMDHM,
       						 TO_CHAR(TO_DATE(FU_GET_VALID_YMDHM(TH7_POW_FNH_YMDHM),'YYYYMMDDHH24MI'), 'YYYY/MM/DD HH24:MI') AS TH7_POW_FNH_YMDHM, 
       						 TH7_POW_TRWI_QTY,  
       						 TO_CHAR(TO_DATE(FU_GET_VALID_YMDHM(TH8_POW_STRT_YMDHM),'YYYYMMDDHH24MI'), 'YYYY/MM/DD HH24:MI') AS TH8_POW_STRT_YMDHM,
       						 TO_CHAR(TO_DATE(FU_GET_VALID_YMDHM(TH8_POW_FNH_YMDHM),'YYYYMMDDHH24MI'), 'YYYY/MM/DD HH24:MI') AS TH8_POW_FNH_YMDHM, 
       						 TH8_POW_TRWI_QTY,
							 TO_CHAR(TO_DATE(FU_GET_VALID_YMDHM(TH9_POW_STRT_YMDHM),'YYYYMMDDHH24MI'), 'YYYY/MM/DD HH24:MI') AS TH9_POW_STRT_YMDHM,
       						 TO_CHAR(TO_DATE(FU_GET_VALID_YMDHM(TH9_POW_FNH_YMDHM),'YYYYMMDDHH24MI'), 'YYYY/MM/DD HH24:MI') AS TH9_POW_FNH_YMDHM,
							 TH9_POW_TRWI_QTY,  
       						 TO_CHAR(TO_DATE(FU_GET_VALID_YMDHM(T10PS1_YMDHM),'YYYYMMDDHH24MI'), 'YYYY/MM/DD HH24:MI') AS TH10_POW_STRT_YMDHM,     
       						 TO_CHAR(TO_DATE(FU_GET_VALID_YMDHM(TH10_POW_FNH_YMDHM),'YYYYMMDDHH24MI'), 'YYYY/MM/DD HH24:MI') AS TH10_POW_FNH_YMDHM,
       						 TH10_POW_TRWI_QTY, 
       						 TO_CHAR(TO_DATE(FU_GET_VALID_YMDHM(T11PS1_YMDHM),'YYYYMMDDHH24MI'), 'YYYY/MM/DD HH24:MI') AS TH11_POW_STRT_YMDHM,      
       						 TO_CHAR(TO_DATE(FU_GET_VALID_YMDHM(TH11_POW_FNH_YMDHM),'YYYYMMDDHH24MI'), 'YYYY/MM/DD HH24:MI') AS TH11_POW_FNH_YMDHM,
       						 TH11_POW_TRWI_QTY, 
       						 TO_CHAR(TO_DATE(FU_GET_VALID_YMDHM(T12PS1_YMDHM),'YYYYMMDDHH24MI'), 'YYYY/MM/DD HH24:MI') AS TH12_POW_STRT_YMDHM, 
       						 TO_CHAR(TO_DATE(FU_GET_VALID_YMDHM(TH12_POW_FNH_YMDHM),'YYYYMMDDHH24MI'), 'YYYY/MM/DD HH24:MI') AS TH12_POW_FNH_YMDHM,
       						 TH12_POW_TRWI_QTY, 
       						 TO_CHAR(TO_DATE(FU_GET_VALID_YMDHM(T13PS1_YMDHM),'YYYYMMDDHH24MI'), 'YYYY/MM/DD HH24:MI') AS TH13_POW_STRT_YMDHM, 
       						 TO_CHAR(TO_DATE(FU_GET_VALID_YMDHM(TH13_POW_FNH_YMDHM),'YYYYMMDDHH24MI'), 'YYYY/MM/DD HH24:MI') AS TH13_POW_FNH_YMDHM,
       						 TH13_POW_TRWI_QTY, 
       						 TO_CHAR(TO_DATE(FU_GET_VALID_YMDHM(T14PS1_YMDHM),'YYYYMMDDHH24MI'), 'YYYY/MM/DD HH24:MI') AS TH14_POW_STRT_YMDHM,     
       						 TO_CHAR(TO_DATE(FU_GET_VALID_YMDHM(TH14_POW_FNH_YMDHM),'YYYYMMDDHH24MI'), 'YYYY/MM/DD HH24:MI') AS TH14_POW_FNH_YMDHM,
       						 TH14_POW_TRWI_QTY, 
       						 TO_CHAR(TO_DATE(FU_GET_VALID_YMDHM(T15PS1_YMDHM),'YYYYMMDDHH24MI'), 'YYYY/MM/DD HH24:MI') AS TH15_POW_STRT_YMDHM,   
       						 TO_CHAR(TO_DATE(FU_GET_VALID_YMDHM(TH15_POW_FNH_YMDHM),'YYYYMMDDHH24MI'), 'YYYY/MM/DD HH24:MI') AS TH15_POW_FNH_YMDHM,
       						 TH15_POW_TRWI_QTY, 
       						 TO_CHAR(TO_DATE(FU_GET_VALID_YMDHM(T16PS1_YMDHM),'YYYYMMDDHH24MI'), 'YYYY/MM/DD HH24:MI') AS TH16_POW_STRT_YMDHM,   
       						 TO_CHAR(TO_DATE(FU_GET_VALID_YMDHM(TH16_POW_FNH_YMDHM),'YYYYMMDDHH24MI'), 'YYYY/MM/DD HH24:MI') AS TH16_POW_FNH_YMDHM,
       						 TH16_POW_TRWI_QTY
					  FROM TB_PROD_MST_SUM_INFO
					  --WHERE APL_YMD = TO_CHAR(TO_DATE(V_SCH_YMD, 'YYYYMMDD') - 1, 'YYYYMMDD')
					  WHERE APL_YMD = V_SCH_YMD
				      AND DATA_SN = P_DATA_SN
				     ) B
		        WHERE A.DATA_SN = B.DATA_SN(+);
			
		
			/**  [2009-02-09] 3일 계획 데이터를 얻어오는 로직 변경 
			 
			P_PLAN_TOT_QTY := 0;
			
			SELECT NVL(SUM(TDD_PRDN_PLN_QTY), 0),
				   NVL(SUM(TDD_PRDN_QTY2), 0),
				   NVL(SUM(TDD_PRDN_QTY), 0)
			INTO V_TDD_PRDN_PLAN_QTY, 
				 V_TDD_PRDN_QTY3,
				 V_TDD_PRDN_QTY
			FROM TB_APS_PROD_SUM_INFO
			WHERE DATA_SN = P_DATA_SN
			AND APL_YMD = P_CURR_YMD;

			IF (V_TDD_PRDN_PLAN_QTY + V_TDD_PRDN_QTY3) > V_TDD_PRDN_QTY THEN
			   
			   P_PLAN_TOT_QTY := V_TDD_PRDN_PLAN_QTY + V_TDD_PRDN_QTY3;
			   
			   V_NEXT_2DAY_YMD := PG_COMMON.FU_GET_WRKDATE(P_CURR_YMD, 2);
			   
			   OPEN RS FOR
			    SELECT MIN(TH0_POW_STRT_YMDHM)  AS TH0_POW_STRT_YMDHM,
					   MAX(TH0_POW_FNH_YMDHM)   AS TH0_POW_FNH_YMDHM,
					   SUM(TH0_POW_TRWI_QTY)    AS TH0_POW_TRWI_QTY,
					   MIN(TH1_POW_STRT_YMDHM)	AS TH1_POW_STRT_YMDHM,
					   MAX(TH1_POW_FNH_YMDHM)   AS TH1_POW_FNH_YMDHM,
					   SUM(TH1_POW_TRWI_QTY)    AS TH1_POW_TRWI_QTY, 
					   MIN(TH2_POW_STRT_YMDHM)  AS TH2_POW_STRT_YMDHM,
					   MAX(TH2_POW_FNH_YMDHM)   AS TH2_POW_FNH_YMDHM,  
					   SUM(TH2_POW_TRWI_QTY)  	AS TH2_POW_TRWI_QTY,  
					   MIN(TH3_POW_STRT_YMDHM)  AS TH3_POW_STRT_YMDHM,
					   MAX(TH3_POW_FNH_YMDHM)   AS TH3_POW_FNH_YMDHM,  
					   SUM(TH3_POW_TRWI_QTY)    AS TH3_POW_TRWI_QTY,  
					   MIN(TH4_POW_STRT_YMDHM)  AS TH4_POW_STRT_YMDHM,
					   MAX(TH4_POW_FNH_YMDHM)   AS TH4_POW_FNH_YMDHM, 
					   SUM(TH4_POW_TRWI_QTY)    AS TH4_POW_TRWI_QTY,  
					   MIN(TH5_POW_STRT_YMDHM)  AS TH5_POW_STRT_YMDHM,
					   MAX(TH5_POW_FNH_YMDHM)   AS TH5_POW_FNH_YMDHM, 
					   SUM(TH5_POW_TRWI_QTY)    AS TH5_POW_TRWI_QTY,  
					   MIN(TH6_POW_STRT_YMDHM)  AS TH6_POW_STRT_YMDHM,
					   MAX(TH6_POW_FNH_YMDHM)   AS TH6_POW_FNH_YMDHM,  
					   SUM(TH6_POW_TRWI_QTY)    AS TH6_POW_TRWI_QTY,  
					   MIN(TH7_POW_STRT_YMDHM)  AS TH7_POW_STRT_YMDHM,
					   MAX(TH7_POW_FNH_YMDHM)   AS TH7_POW_FNH_YMDHM, 
					   SUM(TH7_POW_TRWI_QTY)    AS TH7_POW_TRWI_QTY,  
					   MIN(TH8_POW_STRT_YMDHM)  AS TH8_POW_STRT_YMDHM,
					   MAX(TH8_POW_FNH_YMDHM)   AS TH8_POW_FNH_YMDHM, 
					   SUM(TH8_POW_TRWI_QTY)    AS TH8_POW_TRWI_QTY,  
					   MIN(TH9_POW_STRT_YMDHM)  AS TH9_POW_STRT_YMDHM,
					   MAX(TH9_POW_FNH_YMDHM)   AS TH9_POW_FNH_YMDHM,
					   SUM(TH9_POW_TRWI_QTY)    AS TH9_POW_TRWI_QTY,  
					   MIN(TH10_POW_STRT_YMDHM) AS TH10_POW_STRT_YMDHM,     
					   MAX(TH10_POW_FNH_YMDHM)  AS TH10_POW_FNH_YMDHM,
					   SUM(TH10_POW_TRWI_QTY)   AS TH10_POW_TRWI_QTY, 
					   MIN(TH11_POW_STRT_YMDHM) AS TH11_POW_STRT_YMDHM,      
					   MAX(TH11_POW_FNH_YMDHM)  AS TH11_POW_FNH_YMDHM,
					   SUM(TH11_POW_TRWI_QTY)   AS TH11_POW_TRWI_QTY, 
					   MIN(TH12_POW_STRT_YMDHM) AS TH12_POW_STRT_YMDHM, 
					   MAX(TH12_POW_FNH_YMDHM)  AS TH12_POW_FNH_YMDHM,
					   SUM(TH12_POW_TRWI_QTY)   AS TH12_POW_TRWI_QTY, 
					   MIN(TH13_POW_STRT_YMDHM) AS TH13_POW_STRT_YMDHM, 
					   MAX(TH13_POW_FNH_YMDHM)  AS TH13_POW_FNH_YMDHM,
					   SUM(TH13_POW_TRWI_QTY)   AS TH13_POW_TRWI_QTY, 
					   MIN(TH14_POW_STRT_YMDHM) AS TH14_POW_STRT_YMDHM,     
					   MAX(TH14_POW_FNH_YMDHM)  AS TH14_POW_FNH_YMDHM,
					   SUM(TH14_POW_TRWI_QTY)   AS TH14_POW_TRWI_QTY, 
					   MIN(TH15_POW_STRT_YMDHM) AS TH15_POW_STRT_YMDHM,   
					   MAX(TH15_POW_FNH_YMDHM)  AS TH15_POW_FNH_YMDHM,
					   SUM(TH15_POW_TRWI_QTY)   AS TH15_POW_TRWI_QTY, 
					   MIN(TH16_POW_STRT_YMDHM) AS TH16_POW_STRT_YMDHM,   
					   MAX(TH16_POW_FNH_YMDHM)  AS TH16_POW_FNH_YMDHM,
					   SUM(TH16_POW_TRWI_QTY)   AS TH16_POW_TRWI_QTY
				FROM (SELECT TO_CHAR(TO_DATE(P_CURR_YMD,'YYYYMMDD'), 'YYYY/MM/DD') AS TH0_POW_STRT_YMDHM,
				 	         TO_CHAR(TO_DATE(V_NEXT_2DAY_YMD,'YYYYMMDD'), 'YYYY/MM/DD') AS TH0_POW_FNH_YMDHM,
						     V_TDD_PRDN_PLAN_QTY - V_TDD_PRDN_QTY + V_TDD_PRDN_QTY3 AS TH0_POW_TRWI_QTY,
						     '' AS TH1_POW_STRT_YMDHM,
       				         '' AS TH1_POW_FNH_YMDHM,
       				         0  AS TH1_POW_TRWI_QTY, 
       				    	 '' AS TH2_POW_STRT_YMDHM,
       				    	 '' AS TH2_POW_FNH_YMDHM,  
	       					 0  AS TH2_POW_TRWI_QTY,  
       					     '' AS TH3_POW_STRT_YMDHM,
       					     '' AS TH3_POW_FNH_YMDHM,  
       					     0  AS TH3_POW_TRWI_QTY,  
       					     '' AS TH4_POW_STRT_YMDHM,
       					     '' AS TH4_POW_FNH_YMDHM, 
       					     0  AS TH4_POW_TRWI_QTY,  
       					     '' AS TH5_POW_STRT_YMDHM,
       					     '' AS TH5_POW_FNH_YMDHM, 
       					     0  AS TH5_POW_TRWI_QTY,  
       					     '' AS TH6_POW_STRT_YMDHM,
       					     '' AS TH6_POW_FNH_YMDHM,  
       					     0  AS TH6_POW_TRWI_QTY,  
       					     '' AS TH7_POW_STRT_YMDHM,
       					     '' AS TH7_POW_FNH_YMDHM, 
       					     0  AS TH7_POW_TRWI_QTY,  
       					     '' AS TH8_POW_STRT_YMDHM,
       					     '' AS TH8_POW_FNH_YMDHM, 
       					     0  AS TH8_POW_TRWI_QTY,  
       					     '' AS TH9_POW_STRT_YMDHM,
       					     '' AS TH9_POW_FNH_YMDHM,
       					     0  AS TH9_POW_TRWI_QTY,  
       					     '' AS TH10_POW_STRT_YMDHM,     
       					     '' AS TH10_POW_FNH_YMDHM,
       					     0  AS TH10_POW_TRWI_QTY, 
       					     '' AS TH11_POW_STRT_YMDHM,      
       					     '' AS TH11_POW_FNH_YMDHM,
       					     0  AS TH11_POW_TRWI_QTY, 
       					     '' AS TH12_POW_STRT_YMDHM, 
       					     '' AS TH12_POW_FNH_YMDHM,
       					     0  AS TH12_POW_TRWI_QTY, 
       					     '' AS TH13_POW_STRT_YMDHM, 
       					     '' AS TH13_POW_FNH_YMDHM,
       					     0  AS TH13_POW_TRWI_QTY, 
       					     '' AS TH14_POW_STRT_YMDHM,     
       					     '' AS TH14_POW_FNH_YMDHM,
       					     0  AS TH14_POW_TRWI_QTY, 
       					     '' AS TH15_POW_STRT_YMDHM,   
       					     '' AS TH15_POW_FNH_YMDHM,
       					     0  AS TH15_POW_TRWI_QTY, 
       					     '' AS TH16_POW_STRT_YMDHM,   
       					     '' AS TH16_POW_FNH_YMDHM,
       					     0 AS TH16_POW_TRWI_QTY
				      FROM DUAL
				 
				 	  UNION ALL
				 
				 	  SELECT TO_CHAR(TO_DATE(P_CURR_YMD,'YYYYMMDD'), 'YYYY/MM/DD') AS TH0_POW_STRT_YMDHM,
				 	         TO_CHAR(TO_DATE(V_NEXT_2DAY_YMD,'YYYYMMDD'), 'YYYY/MM/DD') AS TH0_POW_FNH_YMDHM,
						     NVL(TH0_POW_TRWI_QTY, 0) AS TH0_POW_TRWI_QTY,
						     TO_CHAR(TO_DATE(TH1_POW_STRT_YMDHM,'YYYYMMDDHH24MI'), 'YYYY/MM/DD:HH24:MI') AS TH1_POW_STRT_YMDHM,
       				         TO_CHAR(TO_DATE(TH1_POW_FNH_YMDHM,'YYYYMMDDHH24MI'), 'YYYY/MM/DD:HH24:MI') AS TH1_POW_FNH_YMDHM,
       				         NVL(TH1_POW_TRWI_QTY, 0) AS TH1_POW_TRWI_QTY, 
       				         TO_CHAR(TO_DATE(TH2_POW_STRT_YMDHM,'YYYYMMDDHH24MI'), 'YYYY/MM/DD:HH24:MI') AS TH2_POW_STRT_YMDHM,
       				         TO_CHAR(TO_DATE(TH2_POW_FNH_YMDHM,'YYYYMMDDHH24MI'), 'YYYY/MM/DD:HH24:MI') AS TH2_POW_FNH_YMDHM,  
       					     NVL(TH2_POW_TRWI_QTY, 0) AS TH2_POW_TRWI_QTY,  
       					     TO_CHAR(TO_DATE(TH3_POW_STRT_YMDHM,'YYYYMMDDHH24MI'), 'YYYY/MM/DD:HH24:MI') AS TH3_POW_STRT_YMDHM,
       						 TO_CHAR(TO_DATE(TH3_POW_FNH_YMDHM,'YYYYMMDDHH24MI'), 'YYYY/MM/DD:HH24:MI') AS TH3_POW_FNH_YMDHM,  
       						 NVL(TH3_POW_TRWI_QTY, 0) AS TH3_POW_TRWI_QTY,  
       						 TO_CHAR(TO_DATE(TH4_POW_STRT_YMDHM,'YYYYMMDDHH24MI'), 'YYYY/MM/DD:HH24:MI') AS TH4_POW_STRT_YMDHM,
       						 TO_CHAR(TO_DATE(TH4_POW_FNH_YMDHM,'YYYYMMDDHH24MI'), 'YYYY/MM/DD:HH24:MI') AS TH4_POW_FNH_YMDHM, 
       						 NVL(TH4_POW_TRWI_QTY, 0) AS TH4_POW_TRWI_QTY,  
       						 TO_CHAR(TO_DATE(TH5_POW_STRT_YMDHM,'YYYYMMDDHH24MI'), 'YYYY/MM/DD:HH24:MI') AS TH5_POW_STRT_YMDHM,
       						 TO_CHAR(TO_DATE(TH5_POW_FNH_YMDHM,'YYYYMMDDHH24MI'), 'YYYY/MM/DD:HH24:MI') AS TH5_POW_FNH_YMDHM, 
       						 NVL(TH5_POW_TRWI_QTY, 0) AS TH5_POW_TRWI_QTY,  
       						 TO_CHAR(TO_DATE(TH6_POW_STRT_YMDHM,'YYYYMMDDHH24MI'), 'YYYY/MM/DD:HH24:MI') AS TH6_POW_STRT_YMDHM,
       						 TO_CHAR(TO_DATE(TH6_POW_FNH_YMDHM,'YYYYMMDDHH24MI'), 'YYYY/MM/DD:HH24:MI') AS TH6_POW_FNH_YMDHM,  
       						 NVL(TH6_POW_TRWI_QTY, 0) AS TH6_POW_TRWI_QTY,  
       						 TO_CHAR(TO_DATE(TH7_POW_STRT_YMDHM,'YYYYMMDDHH24MI'), 'YYYY/MM/DD:HH24:MI') AS TH7_POW_STRT_YMDHM,
       						 TO_CHAR(TO_DATE(TH7_POW_FNH_YMDHM,'YYYYMMDDHH24MI'), 'YYYY/MM/DD:HH24:MI') AS TH7_POW_FNH_YMDHM, 
       						 NVL(TH7_POW_TRWI_QTY, 0) AS TH7_POW_TRWI_QTY,  
       						 TO_CHAR(TO_DATE(TH8_POW_STRT_YMDHM,'YYYYMMDDHH24MI'), 'YYYY/MM/DD:HH24:MI') AS TH8_POW_STRT_YMDHM,
       						 TO_CHAR(TO_DATE(TH8_POW_FNH_YMDHM,'YYYYMMDDHH24MI'), 'YYYY/MM/DD:HH24:MI') AS TH8_POW_FNH_YMDHM, 
       						 NVL(TH8_POW_TRWI_QTY, 0) AS TH8_POW_TRWI_QTY,  
       						 TO_CHAR(TO_DATE(TH9_POW_STRT_YMDHM,'YYYYMMDDHH24MI'), 'YYYY/MM/DD:HH24:MI') AS TH9_POW_STRT_YMDHM,
       						 TO_CHAR(TO_DATE(TH9_POW_FNH_YMDHM,'YYYYMMDDHH24MI'), 'YYYY/MM/DD:HH24:MI') AS TH9_POW_FNH_YMDHM,
       						 NVL(TH9_POW_TRWI_QTY, 0) AS TH9_POW_TRWI_QTY,  
       						 TO_CHAR(TO_DATE(T10PS1_YMDHM,'YYYYMMDDHH24MI'), 'YYYY/MM/DD:HH24:MI') AS TH10_POW_STRT_YMDHM,     
       						 TO_CHAR(TO_DATE(TH10_POW_FNH_YMDHM,'YYYYMMDDHH24MI'), 'YYYY/MM/DD:HH24:MI') AS TH10_POW_FNH_YMDHM,
       						 NVL(TH10_POW_TRWI_QTY, 0) AS TH10_POW_TRWI_QTY, 
       						 TO_CHAR(TO_DATE(T11PS1_YMDHM,'YYYYMMDDHH24MI'), 'YYYY/MM/DD:HH24:MI') AS TH11_POW_STRT_YMDHM,      
       						 TO_CHAR(TO_DATE(TH11_POW_FNH_YMDHM,'YYYYMMDDHH24MI'), 'YYYY/MM/DD:HH24:MI') AS TH11_POW_FNH_YMDHM,
       						 NVL(TH11_POW_TRWI_QTY, 0) AS TH11_POW_TRWI_QTY, 
       						 TO_CHAR(TO_DATE(T12PS1_YMDHM,'YYYYMMDDHH24MI'), 'YYYY/MM/DD:HH24:MI') AS TH12_POW_STRT_YMDHM, 
       						 TO_CHAR(TO_DATE(TH12_POW_FNH_YMDHM,'YYYYMMDDHH24MI'), 'YYYY/MM/DD:HH24:MI') AS TH12_POW_FNH_YMDHM,
       						 NVL(TH12_POW_TRWI_QTY, 0) AS TH12_POW_TRWI_QTY, 
       						 TO_CHAR(TO_DATE(T13PS1_YMDHM,'YYYYMMDDHH24MI'), 'YYYY/MM/DD:HH24:MI') AS TH13_POW_STRT_YMDHM, 
       						 TO_CHAR(TO_DATE(TH13_POW_FNH_YMDHM,'YYYYMMDDHH24MI'), 'YYYY/MM/DD:HH24:MI') AS TH13_POW_FNH_YMDHM,
       						 NVL(TH13_POW_TRWI_QTY, 0) AS TH13_POW_TRWI_QTY, 
       						 TO_CHAR(TO_DATE(T14PS1_YMDHM,'YYYYMMDDHH24MI'), 'YYYY/MM/DD:HH24:MI') AS TH14_POW_STRT_YMDHM,     
       						 TO_CHAR(TO_DATE(TH14_POW_FNH_YMDHM,'YYYYMMDDHH24MI'), 'YYYY/MM/DD:HH24:MI') AS TH14_POW_FNH_YMDHM,
       						 NVL(TH14_POW_TRWI_QTY, 0) AS TH14_POW_TRWI_QTY, 
       						 TO_CHAR(TO_DATE(T15PS1_YMDHM,'YYYYMMDDHH24MI'), 'YYYY/MM/DD:HH24:MI') AS TH15_POW_STRT_YMDHM,   
       						 TO_CHAR(TO_DATE(TH15_POW_FNH_YMDHM,'YYYYMMDDHH24MI'), 'YYYY/MM/DD:HH24:MI') AS TH15_POW_FNH_YMDHM,
       						 NVL(TH15_POW_TRWI_QTY, 0) AS TH15_POW_TRWI_QTY, 
       						 TO_CHAR(TO_DATE(T16PS1_YMDHM,'YYYYMMDDHH24MI'), 'YYYY/MM/DD:HH24:MI') AS TH16_POW_STRT_YMDHM,   
       						 TO_CHAR(TO_DATE(TH16_POW_FNH_YMDHM,'YYYYMMDDHH24MI'), 'YYYY/MM/DD:HH24:MI') AS TH16_POW_FNH_YMDHM,
       						 NVL(TH16_POW_TRWI_QTY, 0) AS TH16_POW_TRWI_QTY
				      FROM TB_PROD_MST_SUM_INFO
					  --조회일자를 현재일자가 아닌 최종 I/F 작업일자 기준 하루전의 데이터를 조회하도록 한다. 
					  --생산현황 데이터는 현재일자의 하루전 데이터를 조회하여야 한다. 
				      --WHERE APL_YMD = P_CURR_YMD 
					  --WHERE APL_YMD BETWEEN TO_CHAR(TO_DATE(P_CURR_YMD, 'YYYYMMDD') - 1, 'YYYYMMDD') AND P_CURR_YMD 
					  --WHERE APL_YMD = TO_CHAR(TO_DATE(P_CURR_YMD, 'YYYYMMDD') - 1, 'YYYYMMDD') 
					  WHERE APL_YMD = TO_CHAR(TO_DATE(V_SCH_YMD, 'YYYYMMDD') - 1, 'YYYYMMDD')
				      AND DATA_SN = P_DATA_SN
				     );
				    
			ELSE
				 
				 P_PLAN_TOT_QTY := V_TDD_PRDN_QTY;
				 
				 OPEN RS FOR
				 SELECT TO_CHAR(TO_DATE(TH0_POW_STRT_YMD,'YYYYMMDD'), 'YYYY/MM/DD') AS TH0_POW_STRT_YMDHM,
				 	    TO_CHAR(TO_DATE(TH0_POW_FNH_YMD,'YYYYMMDD'), 'YYYY/MM/DD') AS TH0_POW_FNH_YMDHM,
						NVL(TH0_POW_TRWI_QTY, 0) AS TH0_POW_TRWI_QTY,
						TO_CHAR(TO_DATE(TH1_POW_STRT_YMDHM,'YYYYMMDDHH24MI'), 'YYYY/MM/DD:HH24:MI') AS TH1_POW_STRT_YMDHM,
       				    TO_CHAR(TO_DATE(TH1_POW_FNH_YMDHM,'YYYYMMDDHH24MI'), 'YYYY/MM/DD:HH24:MI') AS TH1_POW_FNH_YMDHM,
       				    NVL(TH1_POW_TRWI_QTY, 0) AS TH1_POW_TRWI_QTY, 
       				    TO_CHAR(TO_DATE(TH2_POW_STRT_YMDHM,'YYYYMMDDHH24MI'), 'YYYY/MM/DD:HH24:MI') AS TH2_POW_STRT_YMDHM,
       				    TO_CHAR(TO_DATE(TH2_POW_FNH_YMDHM,'YYYYMMDDHH24MI'), 'YYYY/MM/DD:HH24:MI') AS TH2_POW_FNH_YMDHM,  
       					NVL(TH2_POW_TRWI_QTY, 0) AS TH2_POW_TRWI_QTY,  
       					TO_CHAR(TO_DATE(TH3_POW_STRT_YMDHM,'YYYYMMDDHH24MI'), 'YYYY/MM/DD:HH24:MI') AS TH3_POW_STRT_YMDHM,
       					TO_CHAR(TO_DATE(TH3_POW_FNH_YMDHM,'YYYYMMDDHH24MI'), 'YYYY/MM/DD:HH24:MI') AS TH3_POW_FNH_YMDHM,  
       					NVL(TH3_POW_TRWI_QTY, 0) AS TH3_POW_TRWI_QTY,  
       					TO_CHAR(TO_DATE(TH4_POW_STRT_YMDHM,'YYYYMMDDHH24MI'), 'YYYY/MM/DD:HH24:MI') AS TH4_POW_STRT_YMDHM,
       					TO_CHAR(TO_DATE(TH4_POW_FNH_YMDHM,'YYYYMMDDHH24MI'), 'YYYY/MM/DD:HH24:MI') AS TH4_POW_FNH_YMDHM, 
       					NVL(TH4_POW_TRWI_QTY, 0) AS TH4_POW_TRWI_QTY,  
       					TO_CHAR(TO_DATE(TH5_POW_STRT_YMDHM,'YYYYMMDDHH24MI'), 'YYYY/MM/DD:HH24:MI') AS TH5_POW_STRT_YMDHM,
       					TO_CHAR(TO_DATE(TH5_POW_FNH_YMDHM,'YYYYMMDDHH24MI'), 'YYYY/MM/DD:HH24:MI') AS TH5_POW_FNH_YMDHM, 
       					NVL(TH5_POW_TRWI_QTY, 0) AS TH5_POW_TRWI_QTY,  
       					TO_CHAR(TO_DATE(TH6_POW_STRT_YMDHM,'YYYYMMDDHH24MI'), 'YYYY/MM/DD:HH24:MI') AS TH6_POW_STRT_YMDHM,
       					TO_CHAR(TO_DATE(TH6_POW_FNH_YMDHM,'YYYYMMDDHH24MI'), 'YYYY/MM/DD:HH24:MI') AS TH6_POW_FNH_YMDHM,  
       					NVL(TH6_POW_TRWI_QTY, 0) AS TH6_POW_TRWI_QTY,  
       					TO_CHAR(TO_DATE(TH7_POW_STRT_YMDHM,'YYYYMMDDHH24MI'), 'YYYY/MM/DD:HH24:MI') AS TH7_POW_STRT_YMDHM,
       					TO_CHAR(TO_DATE(TH7_POW_FNH_YMDHM,'YYYYMMDDHH24MI'), 'YYYY/MM/DD:HH24:MI') AS TH7_POW_FNH_YMDHM, 
       					NVL(TH7_POW_TRWI_QTY, 0) AS TH7_POW_TRWI_QTY,  
       					TO_CHAR(TO_DATE(TH8_POW_STRT_YMDHM,'YYYYMMDDHH24MI'), 'YYYY/MM/DD:HH24:MI') AS TH8_POW_STRT_YMDHM,
       					TO_CHAR(TO_DATE(TH8_POW_FNH_YMDHM,'YYYYMMDDHH24MI'), 'YYYY/MM/DD:HH24:MI') AS TH8_POW_FNH_YMDHM, 
       					NVL(TH8_POW_TRWI_QTY, 0) AS TH8_POW_TRWI_QTY,  
       					TO_CHAR(TO_DATE(TH9_POW_STRT_YMDHM,'YYYYMMDDHH24MI'), 'YYYY/MM/DD:HH24:MI') AS TH9_POW_STRT_YMDHM,
       					TO_CHAR(TO_DATE(TH9_POW_FNH_YMDHM,'YYYYMMDDHH24MI'), 'YYYY/MM/DD:HH24:MI') AS TH9_POW_FNH_YMDHM,
       					NVL(TH9_POW_TRWI_QTY, 0) AS TH9_POW_TRWI_QTY,  
       					TO_CHAR(TO_DATE(T10PS1_YMDHM,'YYYYMMDDHH24MI'), 'YYYY/MM/DD:HH24:MI') AS TH10_POW_STRT_YMDHM,     
       					TO_CHAR(TO_DATE(TH10_POW_FNH_YMDHM,'YYYYMMDDHH24MI'), 'YYYY/MM/DD:HH24:MI') AS TH10_POW_FNH_YMDHM,
       					NVL(TH10_POW_TRWI_QTY, 0) AS TH10_POW_TRWI_QTY, 
       					TO_CHAR(TO_DATE(T11PS1_YMDHM,'YYYYMMDDHH24MI'), 'YYYY/MM/DD:HH24:MI') AS TH11_POW_STRT_YMDHM,      
       					TO_CHAR(TO_DATE(TH11_POW_FNH_YMDHM,'YYYYMMDDHH24MI'), 'YYYY/MM/DD:HH24:MI') AS TH11_POW_FNH_YMDHM,
       					NVL(TH11_POW_TRWI_QTY, 0) AS TH11_POW_TRWI_QTY, 
       					TO_CHAR(TO_DATE(T12PS1_YMDHM,'YYYYMMDDHH24MI'), 'YYYY/MM/DD:HH24:MI') AS TH12_POW_STRT_YMDHM, 
       					TO_CHAR(TO_DATE(TH12_POW_FNH_YMDHM,'YYYYMMDDHH24MI'), 'YYYY/MM/DD:HH24:MI') AS TH12_POW_FNH_YMDHM,
       					NVL(TH12_POW_TRWI_QTY, 0) AS TH12_POW_TRWI_QTY, 
       					TO_CHAR(TO_DATE(T13PS1_YMDHM,'YYYYMMDDHH24MI'), 'YYYY/MM/DD:HH24:MI') AS TH13_POW_STRT_YMDHM, 
       					TO_CHAR(TO_DATE(TH13_POW_FNH_YMDHM,'YYYYMMDDHH24MI'), 'YYYY/MM/DD:HH24:MI') AS TH13_POW_FNH_YMDHM,
       					NVL(TH13_POW_TRWI_QTY, 0) AS TH13_POW_TRWI_QTY, 
       					TO_CHAR(TO_DATE(T14PS1_YMDHM,'YYYYMMDDHH24MI'), 'YYYY/MM/DD:HH24:MI') AS TH14_POW_STRT_YMDHM,     
       					TO_CHAR(TO_DATE(TH14_POW_FNH_YMDHM,'YYYYMMDDHH24MI'), 'YYYY/MM/DD:HH24:MI') AS TH14_POW_FNH_YMDHM,
       					NVL(TH14_POW_TRWI_QTY, 0) AS TH14_POW_TRWI_QTY, 
       					TO_CHAR(TO_DATE(T15PS1_YMDHM,'YYYYMMDDHH24MI'), 'YYYY/MM/DD:HH24:MI') AS TH15_POW_STRT_YMDHM,   
       					TO_CHAR(TO_DATE(TH15_POW_FNH_YMDHM,'YYYYMMDDHH24MI'), 'YYYY/MM/DD:HH24:MI') AS TH15_POW_FNH_YMDHM,
       					NVL(TH15_POW_TRWI_QTY, 0) AS TH15_POW_TRWI_QTY, 
       					TO_CHAR(TO_DATE(T16PS1_YMDHM,'YYYYMMDDHH24MI'), 'YYYY/MM/DD:HH24:MI') AS TH16_POW_STRT_YMDHM,   
       					TO_CHAR(TO_DATE(TH16_POW_FNH_YMDHM,'YYYYMMDDHH24MI'), 'YYYY/MM/DD:HH24:MI') AS TH16_POW_FNH_YMDHM,
       					NVL(TH16_POW_TRWI_QTY, 0) AS TH16_POW_TRWI_QTY
				 FROM TB_PROD_MST_SUM_INFO
				 --생산현황 데이터는 현재일자의 하루전 데이터를 조회하여야 한다.
				 --조회일자를 현재일자가 아닌 최종 I/F 작업일자 기준 하루전의 데이터를 조회하도록 한다.  
				 --WHERE APL_YMD = P_CURR_YMD 
				 --WHERE APL_YMD BETWEEN TO_CHAR(TO_DATE(P_CURR_YMD, 'YYYYMMDD') - 1, 'YYYYMMDD') AND P_CURR_YMD
				 --WHERE APL_YMD = TO_CHAR(TO_DATE(P_CURR_YMD, 'YYYYMMDD') - 1, 'YYYYMMDD')
				 WHERE APL_YMD = TO_CHAR(TO_DATE(V_SCH_YMD, 'YYYYMMDD') - 1, 'YYYYMMDD')
				 AND DATA_SN = P_DATA_SN;
  
			END IF;
			**/  

	   END SP_GET_3DAY_PLAN_INFO;
	   
	   PROCEDURE SP_GET_3DAY_PLAN_INFO2(P_DATA_SN      NUMBER,
   			 					        P_CURR_YMD     VARCHAR2,
								        P_PRDN_PLNT_CD VARCHAR2,
								        RS             OUT REFCUR ,
								   		P_PLAN_TOT_QTY OUT NUMBER,
								   		P_MESSAGE	   OUT VARCHAR2
								  	   )
	   IS
	   	 	V_SCH_YMD  VARCHAR2(8);
			
			V_MESSAGE  VARCHAR2(8000);
			
			V_TDD_PRDN_PLAN_QTY NUMBER;
			V_TDD_PRDN_QTY3     NUMBER;
			V_TDD_PRDN_QTY      NUMBER;
			
			V_NEXT_2DAY_YMD VARCHAR2(8);
			
			V_PAC_SCN_CD VARCHAR2(4);
			V_PDI_CD	 VARCHAR2(4);
			V_LANG_CD	 VARCHAR2(3);
	   BEGIN
	   		
			IF P_PRDN_PLNT_CD = 'ALL' THEN
			   
			    SP_GET_3DAY_PLAN_INFO(P_DATA_SN, P_CURR_YMD, RS, P_PLAN_TOT_QTY, P_MESSAGE);
			   
			ELSE
			   
			   	--생산 현황의 현재일 기준 최종 인터페이스 시간정보를 조회 
				SP_GET_MSG_PROD2(P_DATA_SN, P_CURR_YMD, V_SCH_YMD, V_MESSAGE);
				
				P_MESSAGE := V_MESSAGE;
				
				
				SELECT NVL(SUM(TDD_PRDN_PLN_QTY), 0),
					   NVL(SUM(TDD_PRDN_QTY3), 0),
					   NVL(SUM(TDD_PRDN_QTY), 0)
				INTO V_TDD_PRDN_PLAN_QTY, 
					 V_TDD_PRDN_QTY3,
					 V_TDD_PRDN_QTY
				FROM TB_PLNT_APS_PROD_SUM_INFO
				WHERE DATA_SN = P_DATA_SN
				AND APL_YMD = P_CURR_YMD
				AND PRDN_PLNT_CD = P_PRDN_PLNT_CD;
				
				SELECT MAX(DL_EXPD_PAC_SCN_CD),
					   MAX(DL_EXPD_PDI_CD),
					   MAX(LANG_CD)
				INTO V_PAC_SCN_CD,
				     V_PDI_CD,
					 V_LANG_CD
				FROM TB_LANG_MGMT A,
				     TB_VEHL_MGMT B
				WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
				AND A.MDL_MDY_CD = B.MDL_MDY_CD
				AND A.DATA_SN = P_DATA_SN;
				
				P_PLAN_TOT_QTY := V_TDD_PRDN_PLAN_QTY + V_TDD_PRDN_QTY3;
				
				V_NEXT_2DAY_YMD := PG_COMMON.FU_GET_WRKDATE(P_CURR_YMD, 2);
				
				OPEN RS FOR
				    SELECT TH0_POW_STRT_YMDHM,
						   TH0_POW_FNH_YMDHM,
						   TH0_POW_TRWI_QTY,
						   NVL(TH1_POW_STRT_YMDHM, '')	AS TH1_POW_STRT_YMDHM,
						   NVL(TH1_POW_FNH_YMDHM,  '')  AS TH1_POW_FNH_YMDHM,
						   NVL(TH1_POW_TRWI_QTY,    0)  AS TH1_POW_TRWI_QTY, 
						   NVL(TH2_POW_STRT_YMDHM, '')  AS TH2_POW_STRT_YMDHM,
						   NVL(TH2_POW_FNH_YMDHM,  '')  AS TH2_POW_FNH_YMDHM,  
						   NVL(TH2_POW_TRWI_QTY,    0)  AS TH2_POW_TRWI_QTY,  
						   NVL(TH3_POW_STRT_YMDHM, '')  AS TH3_POW_STRT_YMDHM,
						   NVL(TH3_POW_FNH_YMDHM,  '')  AS TH3_POW_FNH_YMDHM,  
						   NVL(TH3_POW_TRWI_QTY,    0)  AS TH3_POW_TRWI_QTY,  
						   NVL(TH4_POW_STRT_YMDHM, '')  AS TH4_POW_STRT_YMDHM,
						   NVL(TH4_POW_FNH_YMDHM,  '')  AS TH4_POW_FNH_YMDHM, 
						   NVL(TH4_POW_TRWI_QTY,    0)  AS TH4_POW_TRWI_QTY,  
						   NVL(TH5_POW_STRT_YMDHM, '')  AS TH5_POW_STRT_YMDHM,
						   NVL(TH5_POW_FNH_YMDHM,  '')  AS TH5_POW_FNH_YMDHM, 
						   NVL(TH5_POW_TRWI_QTY,    0)  AS TH5_POW_TRWI_QTY,  
						   NVL(TH6_POW_STRT_YMDHM, '')  AS TH6_POW_STRT_YMDHM,
						   NVL(TH6_POW_FNH_YMDHM,  '')  AS TH6_POW_FNH_YMDHM,  
						   NVL(TH6_POW_TRWI_QTY,    0)  AS TH6_POW_TRWI_QTY,  
						   NVL(TH7_POW_STRT_YMDHM, '')  AS TH7_POW_STRT_YMDHM,
						   NVL(TH7_POW_FNH_YMDHM,  '')  AS TH7_POW_FNH_YMDHM, 
						   NVL(TH7_POW_TRWI_QTY,    0)  AS TH7_POW_TRWI_QTY,  
						   NVL(TH8_POW_STRT_YMDHM, '')  AS TH8_POW_STRT_YMDHM,
						   NVL(TH8_POW_FNH_YMDHM,  '')  AS TH8_POW_FNH_YMDHM, 
						   NVL(TH8_POW_TRWI_QTY,    0)  AS TH8_POW_TRWI_QTY,  
						   NVL(TH9_POW_STRT_YMDHM, '')  AS TH9_POW_STRT_YMDHM,
						   NVL(TH9_POW_FNH_YMDHM,  '')  AS TH9_POW_FNH_YMDHM,
						   NVL(TH9_POW_TRWI_QTY,    0)  AS TH9_POW_TRWI_QTY,
						   NVL(TH10_POW_STRT_YMDHM,'')  AS TH10_POW_STRT_YMDHM,     
						   NVL(TH10_POW_FNH_YMDHM, '')  AS TH10_POW_FNH_YMDHM,
						   NVL(TH10_POW_TRWI_QTY,   0)  AS TH10_POW_TRWI_QTY, 
						   NVL(TH11_POW_STRT_YMDHM,'')  AS TH11_POW_STRT_YMDHM,      
						   NVL(TH11_POW_FNH_YMDHM, '')  AS TH11_POW_FNH_YMDHM,
						   NVL(TH11_POW_TRWI_QTY,   0)  AS TH11_POW_TRWI_QTY, 
						   NVL(TH12_POW_STRT_YMDHM,'')  AS TH12_POW_STRT_YMDHM, 
						   NVL(TH12_POW_FNH_YMDHM, '')  AS TH12_POW_FNH_YMDHM,
						   NVL(TH12_POW_TRWI_QTY,   0)  AS TH12_POW_TRWI_QTY, 
						   NVL(TH13_POW_STRT_YMDHM,'')  AS TH13_POW_STRT_YMDHM, 
						   NVL(TH13_POW_FNH_YMDHM, '')  AS TH13_POW_FNH_YMDHM,
						   NVL(TH13_POW_TRWI_QTY,   0)  AS TH13_POW_TRWI_QTY, 
						   NVL(TH14_POW_STRT_YMDHM,'')  AS TH14_POW_STRT_YMDHM,     
						   NVL(TH14_POW_FNH_YMDHM, '')  AS TH14_POW_FNH_YMDHM,
						   NVL(TH14_POW_TRWI_QTY,   0)  AS TH14_POW_TRWI_QTY, 
						   NVL(TH15_POW_STRT_YMDHM,'')  AS TH15_POW_STRT_YMDHM,   
						   NVL(TH15_POW_FNH_YMDHM, '')  AS TH15_POW_FNH_YMDHM,
						   NVL(TH15_POW_TRWI_QTY,   0)  AS TH15_POW_TRWI_QTY, 
						   NVL(TH16_POW_STRT_YMDHM,'')  AS TH16_POW_STRT_YMDHM,   
						   NVL(TH16_POW_FNH_YMDHM, '')  AS TH16_POW_FNH_YMDHM,
						   NVL(TH16_POW_TRWI_QTY,   0)  AS TH16_POW_TRWI_QTY,
						   FU_GET_MIN_YMDHM(V_PAC_SCN_CD, V_PDI_CD,V_LANG_CD,
						                    TH9_POW_STRT_YMDHM, TH10_POW_STRT_YMDHM, TH11_POW_STRT_YMDHM, TH12_POW_STRT_YMDHM,
						                    TH13_POW_STRT_YMDHM, TH14_POW_STRT_YMDHM, TH15_POW_STRT_YMDHM, TH16_POW_STRT_YMDHM) AS POW_STRT_YMDHM,
						   FU_GET_MAX_YMDHM(V_PAC_SCN_CD, V_PDI_CD,V_LANG_CD,
						                    TH9_POW_FNH_YMDHM, TH10_POW_FNH_YMDHM, TH11_POW_FNH_YMDHM, TH12_POW_FNH_YMDHM,
						                    TH13_POW_FNH_YMDHM, TH14_POW_FNH_YMDHM, TH15_POW_FNH_YMDHM, TH16_POW_FNH_YMDHM) AS POW_FNH_YMDHM,
						   V_TDD_PRDN_QTY3 AS POW_TRWI_QTY
				    FROM (SELECT P_DATA_SN AS DATA_SN,
					 		     TO_CHAR(TO_DATE(P_CURR_YMD,'YYYYMMDD'), 'YYYY/MM/DD') AS TH0_POW_STRT_YMDHM,
					 	         TO_CHAR(TO_DATE(V_NEXT_2DAY_YMD,'YYYYMMDD'), 'YYYY/MM/DD') AS TH0_POW_FNH_YMDHM,
							     V_TDD_PRDN_PLAN_QTY - (V_TDD_PRDN_QTY - V_TDD_PRDN_QTY3) AS TH0_POW_TRWI_QTY
					      FROM DUAL
					     ) A,
					     (SELECT DATA_SN,
							     TO_CHAR(TO_DATE(FU_GET_VALID_YMDHM(TH1_POW_STRT_YMDHM),'YYYYMMDDHH24MI'), 'YYYY/MM/DD HH24:MI') AS TH1_POW_STRT_YMDHM,
	       				         TO_CHAR(TO_DATE(FU_GET_VALID_YMDHM(TH1_POW_FNH_YMDHM),'YYYYMMDDHH24MI'), 'YYYY/MM/DD HH24:MI') AS TH1_POW_FNH_YMDHM,
	       				         TH1_POW_TRWI_QTY, 
	       				         TO_CHAR(TO_DATE(FU_GET_VALID_YMDHM(TH2_POW_STRT_YMDHM),'YYYYMMDDHH24MI'), 'YYYY/MM/DD HH24:MI') AS TH2_POW_STRT_YMDHM,
	       				         TO_CHAR(TO_DATE(FU_GET_VALID_YMDHM(TH2_POW_FNH_YMDHM),'YYYYMMDDHH24MI'), 'YYYY/MM/DD HH24:MI') AS TH2_POW_FNH_YMDHM,  
	       					     TH2_POW_TRWI_QTY,  
	       					     TO_CHAR(TO_DATE(FU_GET_VALID_YMDHM(TH3_POW_STRT_YMDHM),'YYYYMMDDHH24MI'), 'YYYY/MM/DD HH24:MI') AS TH3_POW_STRT_YMDHM,
	       						 TO_CHAR(TO_DATE(FU_GET_VALID_YMDHM(TH3_POW_FNH_YMDHM),'YYYYMMDDHH24MI'), 'YYYY/MM/DD HH24:MI') AS TH3_POW_FNH_YMDHM,  
	       						 TH3_POW_TRWI_QTY,  
	       						 TO_CHAR(TO_DATE(FU_GET_VALID_YMDHM(TH4_POW_STRT_YMDHM),'YYYYMMDDHH24MI'), 'YYYY/MM/DD HH24:MI') AS TH4_POW_STRT_YMDHM,
	       						 TO_CHAR(TO_DATE(FU_GET_VALID_YMDHM(TH4_POW_FNH_YMDHM),'YYYYMMDDHH24MI'), 'YYYY/MM/DD HH24:MI') AS TH4_POW_FNH_YMDHM, 
	       						 TH4_POW_TRWI_QTY,  
	       						 TO_CHAR(TO_DATE(FU_GET_VALID_YMDHM(TH5_POW_STRT_YMDHM),'YYYYMMDDHH24MI'), 'YYYY/MM/DD HH24:MI') AS TH5_POW_STRT_YMDHM,
	       						 TO_CHAR(TO_DATE(FU_GET_VALID_YMDHM(TH5_POW_FNH_YMDHM),'YYYYMMDDHH24MI'), 'YYYY/MM/DD HH24:MI') AS TH5_POW_FNH_YMDHM, 
	       						 TH5_POW_TRWI_QTY,  
	       						 TO_CHAR(TO_DATE(FU_GET_VALID_YMDHM(TH6_POW_STRT_YMDHM),'YYYYMMDDHH24MI'), 'YYYY/MM/DD HH24:MI') AS TH6_POW_STRT_YMDHM,
	       						 TO_CHAR(TO_DATE(FU_GET_VALID_YMDHM(TH6_POW_FNH_YMDHM),'YYYYMMDDHH24MI'), 'YYYY/MM/DD HH24:MI') AS TH6_POW_FNH_YMDHM,  
	       						 TH6_POW_TRWI_QTY,  
	       						 TO_CHAR(TO_DATE(FU_GET_VALID_YMDHM(TH7_POW_STRT_YMDHM),'YYYYMMDDHH24MI'), 'YYYY/MM/DD HH24:MI') AS TH7_POW_STRT_YMDHM,
	       						 TO_CHAR(TO_DATE(FU_GET_VALID_YMDHM(TH7_POW_FNH_YMDHM),'YYYYMMDDHH24MI'), 'YYYY/MM/DD HH24:MI') AS TH7_POW_FNH_YMDHM, 
	       						 TH7_POW_TRWI_QTY,  
	       						 TO_CHAR(TO_DATE(FU_GET_VALID_YMDHM(TH8_POW_STRT_YMDHM),'YYYYMMDDHH24MI'), 'YYYY/MM/DD HH24:MI') AS TH8_POW_STRT_YMDHM,
	       						 TO_CHAR(TO_DATE(FU_GET_VALID_YMDHM(TH8_POW_FNH_YMDHM),'YYYYMMDDHH24MI'), 'YYYY/MM/DD HH24:MI') AS TH8_POW_FNH_YMDHM, 
	       						 TH8_POW_TRWI_QTY,
								 TO_CHAR(TO_DATE(FU_GET_VALID_YMDHM(TH9_POW_STRT_YMDHM),'YYYYMMDDHH24MI'), 'YYYY/MM/DD HH24:MI') AS TH9_POW_STRT_YMDHM,
	       						 TO_CHAR(TO_DATE(FU_GET_VALID_YMDHM(TH9_POW_FNH_YMDHM),'YYYYMMDDHH24MI'), 'YYYY/MM/DD HH24:MI') AS TH9_POW_FNH_YMDHM,
								 TH9_POW_TRWI_QTY,  
	       						 TO_CHAR(TO_DATE(FU_GET_VALID_YMDHM(T10PS1_YMDHM),'YYYYMMDDHH24MI'), 'YYYY/MM/DD HH24:MI') AS TH10_POW_STRT_YMDHM,     
	       						 TO_CHAR(TO_DATE(FU_GET_VALID_YMDHM(TH10_POW_FNH_YMDHM),'YYYYMMDDHH24MI'), 'YYYY/MM/DD HH24:MI') AS TH10_POW_FNH_YMDHM,
	       						 TH10_POW_TRWI_QTY, 
	       						 TO_CHAR(TO_DATE(FU_GET_VALID_YMDHM(T11PS1_YMDHM),'YYYYMMDDHH24MI'), 'YYYY/MM/DD HH24:MI') AS TH11_POW_STRT_YMDHM,      
	       						 TO_CHAR(TO_DATE(FU_GET_VALID_YMDHM(TH11_POW_FNH_YMDHM),'YYYYMMDDHH24MI'), 'YYYY/MM/DD HH24:MI') AS TH11_POW_FNH_YMDHM,
	       						 TH11_POW_TRWI_QTY, 
	       						 TO_CHAR(TO_DATE(FU_GET_VALID_YMDHM(T12PS1_YMDHM),'YYYYMMDDHH24MI'), 'YYYY/MM/DD HH24:MI') AS TH12_POW_STRT_YMDHM, 
	       						 TO_CHAR(TO_DATE(FU_GET_VALID_YMDHM(TH12_POW_FNH_YMDHM),'YYYYMMDDHH24MI'), 'YYYY/MM/DD HH24:MI') AS TH12_POW_FNH_YMDHM,
	       						 TH12_POW_TRWI_QTY, 
	       						 TO_CHAR(TO_DATE(FU_GET_VALID_YMDHM(T13PS1_YMDHM),'YYYYMMDDHH24MI'), 'YYYY/MM/DD HH24:MI') AS TH13_POW_STRT_YMDHM, 
	       						 TO_CHAR(TO_DATE(FU_GET_VALID_YMDHM(TH13_POW_FNH_YMDHM),'YYYYMMDDHH24MI'), 'YYYY/MM/DD HH24:MI') AS TH13_POW_FNH_YMDHM,
	       						 TH13_POW_TRWI_QTY, 
	       						 TO_CHAR(TO_DATE(FU_GET_VALID_YMDHM(T14PS1_YMDHM),'YYYYMMDDHH24MI'), 'YYYY/MM/DD HH24:MI') AS TH14_POW_STRT_YMDHM,     
	       						 TO_CHAR(TO_DATE(FU_GET_VALID_YMDHM(TH14_POW_FNH_YMDHM),'YYYYMMDDHH24MI'), 'YYYY/MM/DD HH24:MI') AS TH14_POW_FNH_YMDHM,
	       						 TH14_POW_TRWI_QTY, 
	       						 TO_CHAR(TO_DATE(FU_GET_VALID_YMDHM(T15PS1_YMDHM),'YYYYMMDDHH24MI'), 'YYYY/MM/DD HH24:MI') AS TH15_POW_STRT_YMDHM,   
	       						 TO_CHAR(TO_DATE(FU_GET_VALID_YMDHM(TH15_POW_FNH_YMDHM),'YYYYMMDDHH24MI'), 'YYYY/MM/DD HH24:MI') AS TH15_POW_FNH_YMDHM,
	       						 TH15_POW_TRWI_QTY, 
	       						 TO_CHAR(TO_DATE(FU_GET_VALID_YMDHM(T16PS1_YMDHM),'YYYYMMDDHH24MI'), 'YYYY/MM/DD HH24:MI') AS TH16_POW_STRT_YMDHM,   
	       						 TO_CHAR(TO_DATE(FU_GET_VALID_YMDHM(TH16_POW_FNH_YMDHM),'YYYYMMDDHH24MI'), 'YYYY/MM/DD HH24:MI') AS TH16_POW_FNH_YMDHM,
	       						 TH16_POW_TRWI_QTY
						  FROM TB_PLNT_PROD_MST_SUM_INFO
						  --WHERE APL_YMD = TO_CHAR(TO_DATE(V_SCH_YMD, 'YYYYMMDD') - 1, 'YYYYMMDD')
						  WHERE APL_YMD = V_SCH_YMD
					      AND DATA_SN = P_DATA_SN
						  AND PRDN_PLNT_CD = P_PRDN_PLNT_CD
					     ) B
			        WHERE A.DATA_SN = B.DATA_SN(+);
				
			END IF;
			
	   END SP_GET_3DAY_PLAN_INFO2;
	   
	   --9공정 ~ 투입전 공정 사이의 최소 시각 얻어오기 
	   FUNCTION FU_GET_MIN_YMDHM(P_PAC_SCN_CD          VARCHAR2,
  		   						 P_PDI_CD	           VARCHAR2,
								 P_LANG_CD			   VARCHAR2,
								 P_TH9_POW_STRT_YMDHM  VARCHAR2,
								 P_TH10_POW_STRT_YMDHM VARCHAR2,
								 P_TH11_POW_STRT_YMDHM VARCHAR2,
								 P_TH12_POW_STRT_YMDHM VARCHAR2,
								 P_TH13_POW_STRT_YMDHM VARCHAR2,
								 P_TH14_POW_STRT_YMDHM VARCHAR2,
								 P_TH15_POW_STRT_YMDHM VARCHAR2,
								 P_TH16_POW_STRT_YMDHM VARCHAR2) RETURN VARCHAR2
	   IS
	   	 
		 V_POW_STRT_YMDHM VARCHAR2(16);
		 
	   BEGIN
	   		
			V_POW_STRT_YMDHM := '9999/12/31 23:59';
			
			IF P_TH9_POW_STRT_YMDHM IS NOT NULL THEN
				  	 
			    V_POW_STRT_YMDHM := P_TH9_POW_STRT_YMDHM;
					 
			END IF;
			   
			IF P_LANG_CD = 'KO' THEN
			   
			   IF P_TH10_POW_STRT_YMDHM IS NOT NULL THEN
			   
			      IF V_POW_STRT_YMDHM > P_TH10_POW_STRT_YMDHM THEN
				  	 
			          V_POW_STRT_YMDHM := P_TH10_POW_STRT_YMDHM;
				  
				  END IF;
					 
			   END IF;
				  
			   IF P_TH11_POW_STRT_YMDHM IS NOT NULL THEN
			   
				  IF V_POW_STRT_YMDHM > P_TH11_POW_STRT_YMDHM THEN
				  	 
				      V_POW_STRT_YMDHM := P_TH11_POW_STRT_YMDHM;
				  
				  END IF;
					 
			   END IF;
			   
			   IF P_TH12_POW_STRT_YMDHM IS NOT NULL THEN
			   
				  IF V_POW_STRT_YMDHM > P_TH12_POW_STRT_YMDHM THEN
				  	 
			          V_POW_STRT_YMDHM := P_TH12_POW_STRT_YMDHM;
				  
				  END IF;
					 
			   END IF;
				  
			   IF P_TH13_POW_STRT_YMDHM IS NOT NULL THEN
			   
				  IF V_POW_STRT_YMDHM > P_TH13_POW_STRT_YMDHM THEN
				  	 
				      V_POW_STRT_YMDHM := P_TH13_POW_STRT_YMDHM;
				   
				  END IF;
					 
			   END IF;
			   
			   IF P_TH14_POW_STRT_YMDHM IS NOT NULL THEN
			   
				  IF V_POW_STRT_YMDHM > P_TH14_POW_STRT_YMDHM THEN
				  	 
				      V_POW_STRT_YMDHM := P_TH14_POW_STRT_YMDHM;
				   
				  END IF;
					 
			   END IF;
			   
			   IF P_TH15_POW_STRT_YMDHM IS NOT NULL THEN
			   
				  IF V_POW_STRT_YMDHM > P_TH15_POW_STRT_YMDHM THEN
				  	 
				      V_POW_STRT_YMDHM := P_TH15_POW_STRT_YMDHM;
				   
				  END IF;
					 
			   END IF;
			   
			    IF P_TH16_POW_STRT_YMDHM IS NOT NULL THEN
				
				   IF V_POW_STRT_YMDHM > P_TH16_POW_STRT_YMDHM THEN
				  	 
				       V_POW_STRT_YMDHM := P_TH16_POW_STRT_YMDHM;
				   
				   END IF;
				   	 
			   END IF;
			   	  
			ELSE
				
				IF P_PAC_SCN_CD = '01' THEN
			   
			   	   IF P_PDI_CD = '04' THEN
			   	  
				   	  IF P_TH10_POW_STRT_YMDHM IS NOT NULL THEN
					  
			          	 IF V_POW_STRT_YMDHM > P_TH10_POW_STRT_YMDHM THEN
				  	 
			                 V_POW_STRT_YMDHM := P_TH10_POW_STRT_YMDHM;
						  
						 END IF;
					 
			          END IF;
				  
			          IF P_TH11_POW_STRT_YMDHM IS NOT NULL THEN
			             
				         IF V_POW_STRT_YMDHM > P_TH11_POW_STRT_YMDHM THEN
				  	 
				             V_POW_STRT_YMDHM := P_TH11_POW_STRT_YMDHM;
						 
						 END IF;
					 
			          END IF;
				  
			       ELSE
			   	  
				      IF P_TH10_POW_STRT_YMDHM IS NOT NULL THEN
					  
			             IF V_POW_STRT_YMDHM > P_TH10_POW_STRT_YMDHM THEN
				  	 
			                 V_POW_STRT_YMDHM := P_TH10_POW_STRT_YMDHM;
							 
						 END IF;
					 
			          END IF;
				  
			       END IF;
			   
			   ELSE
			       
				   IF P_TH10_POW_STRT_YMDHM IS NOT NULL THEN
					  
			          IF V_POW_STRT_YMDHM > P_TH10_POW_STRT_YMDHM THEN
				  	 
			              V_POW_STRT_YMDHM := P_TH10_POW_STRT_YMDHM;
						  
					  END IF;
					 
			       END IF;
				  
			       IF P_TH11_POW_STRT_YMDHM IS NOT NULL THEN
			             
				      IF V_POW_STRT_YMDHM > P_TH11_POW_STRT_YMDHM THEN
				  	 
				          V_POW_STRT_YMDHM := P_TH11_POW_STRT_YMDHM;
						 
					  END IF;
					 
			       END IF;
					  
			   END IF;
			
			END IF;
			
			IF V_POW_STRT_YMDHM = '9999/12/31 23:59' THEN
			   
			   V_POW_STRT_YMDHM := '';
			   
			END IF;
			
			RETURN V_POW_STRT_YMDHM;
			
	   END FU_GET_MIN_YMDHM;
	   
	   --9공정 ~ 투입전 공정 사이의 최대 시각 얻어오기 		
	   FUNCTION FU_GET_MAX_YMDHM(P_PAC_SCN_CD          VARCHAR2,
  		   					     P_PDI_CD	           VARCHAR2,
							     P_LANG_CD			   VARCHAR2,
							     P_TH9_POW_FNH_YMDHM   VARCHAR2,
								 P_TH10_POW_FNH_YMDHM  VARCHAR2,
								 P_TH11_POW_FNH_YMDHM  VARCHAR2,
								 P_TH12_POW_FNH_YMDHM  VARCHAR2,
								 P_TH13_POW_FNH_YMDHM  VARCHAR2,
								 P_TH14_POW_FNH_YMDHM  VARCHAR2,
								 P_TH15_POW_FNH_YMDHM  VARCHAR2,
								 P_TH16_POW_FNH_YMDHM  VARCHAR2) RETURN VARCHAR2
	   IS
	   	 
		 V_POW_FNH_YMDHM VARCHAR2(16);
		 
	   BEGIN
	   		
			V_POW_FNH_YMDHM := '0000/00/00 00:00';
			
			IF P_TH9_POW_FNH_YMDHM IS NOT NULL THEN
				  	 
			    V_POW_FNH_YMDHM := P_TH9_POW_FNH_YMDHM;
					 
			END IF;
			   
			IF P_LANG_CD = 'KO' THEN
			   
			   IF P_TH10_POW_FNH_YMDHM IS NOT NULL THEN
			   
			      IF V_POW_FNH_YMDHM < P_TH10_POW_FNH_YMDHM THEN
				  	 
			          V_POW_FNH_YMDHM := P_TH10_POW_FNH_YMDHM;
				  
				  END IF;
					 
			   END IF;
				  
			   IF P_TH11_POW_FNH_YMDHM IS NOT NULL THEN
			   
				  IF V_POW_FNH_YMDHM < P_TH11_POW_FNH_YMDHM THEN
				  	 
				      V_POW_FNH_YMDHM := P_TH11_POW_FNH_YMDHM;
				  
				  END IF;
					 
			   END IF;
			   
			   IF P_TH12_POW_FNH_YMDHM IS NOT NULL THEN
			   
				  IF V_POW_FNH_YMDHM < P_TH12_POW_FNH_YMDHM THEN
				  	 
			          V_POW_FNH_YMDHM := P_TH12_POW_FNH_YMDHM;
				  
				  END IF;
					 
			   END IF;
				  
			   IF P_TH13_POW_FNH_YMDHM IS NOT NULL THEN
			   
				  IF V_POW_FNH_YMDHM < P_TH13_POW_FNH_YMDHM THEN
				  	 
				      V_POW_FNH_YMDHM := P_TH13_POW_FNH_YMDHM;
				   
				  END IF;
					 
			   END IF;
			   
			   IF P_TH14_POW_FNH_YMDHM IS NOT NULL THEN
			   
				  IF V_POW_FNH_YMDHM < P_TH14_POW_FNH_YMDHM THEN
				  	 
				      V_POW_FNH_YMDHM := P_TH14_POW_FNH_YMDHM;
				   
				  END IF;
					 
			   END IF;
			   
			   IF P_TH15_POW_FNH_YMDHM IS NOT NULL THEN
			   
				  IF V_POW_FNH_YMDHM < P_TH15_POW_FNH_YMDHM THEN
				  	 
				      V_POW_FNH_YMDHM := P_TH15_POW_FNH_YMDHM;
				   
				  END IF;
					 
			   END IF;
			   
			    IF P_TH16_POW_FNH_YMDHM IS NOT NULL THEN
				
				   IF V_POW_FNH_YMDHM < P_TH16_POW_FNH_YMDHM THEN
				  	 
				       V_POW_FNH_YMDHM := P_TH16_POW_FNH_YMDHM;
				   
				   END IF;
				   	 
			   END IF;
			   	  
			ELSE
				
				IF P_PAC_SCN_CD = '01' THEN
			   
			   	   IF P_PDI_CD = '04' THEN
			   	  
				   	  IF P_TH10_POW_FNH_YMDHM IS NOT NULL THEN
					  
			          	 IF V_POW_FNH_YMDHM < P_TH10_POW_FNH_YMDHM THEN
				  	 
			                 V_POW_FNH_YMDHM := P_TH10_POW_FNH_YMDHM;
						  
						 END IF;
					 
			          END IF;
				  
			          IF P_TH11_POW_FNH_YMDHM IS NOT NULL THEN
			             
				         IF V_POW_FNH_YMDHM < P_TH11_POW_FNH_YMDHM THEN
				  	 
				             V_POW_FNH_YMDHM := P_TH11_POW_FNH_YMDHM;
						 
						 END IF;
					 
			          END IF;
				  
			       ELSE
			   	  
				      IF P_TH10_POW_FNH_YMDHM IS NOT NULL THEN
					  
			             IF V_POW_FNH_YMDHM < P_TH10_POW_FNH_YMDHM THEN
				  	 
			                 V_POW_FNH_YMDHM := P_TH10_POW_FNH_YMDHM;
							 
						 END IF;
					 
			          END IF;
				  
			       END IF;
			   
			   ELSE
			       
				   IF P_TH10_POW_FNH_YMDHM IS NOT NULL THEN
					  
			          IF V_POW_FNH_YMDHM < P_TH10_POW_FNH_YMDHM THEN
				  	 
			              V_POW_FNH_YMDHM := P_TH10_POW_FNH_YMDHM;
						  
					  END IF;
					 
			       END IF;
				  
			       IF P_TH11_POW_FNH_YMDHM IS NOT NULL THEN
			             
				      IF V_POW_FNH_YMDHM < P_TH11_POW_FNH_YMDHM THEN
				  	 
				          V_POW_FNH_YMDHM := P_TH11_POW_FNH_YMDHM;
						 
					  END IF;
					 
			       END IF;
					  
			   END IF;
			
			END IF;
			
			IF V_POW_FNH_YMDHM = '0000/00/00 00:00' THEN
			   
			   V_POW_FNH_YMDHM := '';
			   
			END IF;
			
			RETURN V_POW_FNH_YMDHM;
			
	   END FU_GET_MAX_YMDHM;
	   
	   --PPMS에서 넘어온 시간값이 적절한지의 여부를 확인 
	   FUNCTION FU_GET_VALID_YMDHM(P_YMDHM VARCHAR2) RETURN VARCHAR2
	   IS
	   	 
		 V_CURR_YER CHAR(4);
		 V_CURR_MTH CHAR(2);
		 V_CURR_DAY CHAR(2);
		 
	   BEGIN
	   	 
		 	V_CURR_YER := SUBSTR(P_YMDHM, 1, 4);
			V_CURR_MTH := SUBSTR(P_YMDHM, 5, 2);
			V_CURR_DAY := SUBSTR(P_YMDHM, 7, 2);
			
			IF V_CURR_YER = '0000' OR
			   V_CURR_MTH = '00' OR
			   V_CURR_DAY = '00' THEN
			   
			   RETURN NULL;
			   
			ELSE
			   
			   RETURN TRIM(P_YMDHM);
			   
			END IF;
				
	   END FU_GET_VALID_YMDHM;
	   
	   --당월투입현황 조회 								  
  	   PROCEDURE SP_GET_1MTH_TRWI_INFO(P_VEHL_CD  VARCHAR2,
							           P_MDL_MDY  VARCHAR2,
								       P_LANG_CD  VARCHAR2,
								       P_CURR_YMD VARCHAR2,
								       RS OUT REFCUR,
                                       P_MESSAGE OUT VARCHAR2)
	   IS
	   	 
		 V_CURR_FSTD_YMD VARCHAR2(8); --현재월 1일 날짜
		 V_CURR_LAST_YMD VARCHAR2(8); --현재월 마지막 날짜 
		 
	   BEGIN
	   		
			V_CURR_FSTD_YMD := SUBSTR(P_CURR_YMD, 1, 6) || '01';
			V_CURR_LAST_YMD := TO_CHAR(LAST_DAY(TO_DATE(P_CURR_YMD, 'YYYYMMDD')), 'YYYYMMDD');
			P_MESSAGE := '';
			OPEN RS FOR
				 WITH 
				      /*** 
				 	  T AS (SELECT A.LANG_CD,
								   A.QLTY_VEHL_CD,
								   A.MDL_MDY_CD
						    FROM TB_LANG_MGMT A
							WHERE A.QLTY_VEHL_CD = P_VEHL_CD
							AND A.MDL_MDY_CD = P_MDL_MDY
							AND A.LANG_CD = P_LANG_CD
				 	  	   ), 
					  ***/
					  
					  U AS (SELECT TO_CHAR(TO_DATE(A.WK_YMD, 'YYYYMMDD'), 'YYYY-MM-DD') AS WK_YMD,
								   NVL(B.WHSN_QTY, 0) AS WHSN_QTY,
								   NVL(C.WHOT_QTY, 0) AS WHOT_QTY
				            FROM (SELECT WK_YMD
					              FROM TB_WRK_DATE_MGMT
					              WHERE WK_YMD BETWEEN V_CURR_FSTD_YMD AND V_CURR_LAST_YMD
					              ORDER BY WK_YMD
					             ) A,
							     (
								  /***
								  SELECT B.WHSN_YMD, 
									   	 SUM(B.WHSN_QTY) AS WHSN_QTY
								  FROM T A,
									   TB_PDI_WHSN_INFO B
								  WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
								  AND A.MDL_MDY_CD = B.MDL_MDY_CD
								  AND A.LANG_CD = B.LANG_CD
								  AND B.WHSN_YMD BETWEEN V_CURR_FSTD_YMD AND V_CURR_LAST_YMD
								  GROUP BY B.WHSN_YMD 
								  ***/
								  
								  SELECT WHSN_YMD, 
									   	 SUM(WHSN_QTY) AS WHSN_QTY
								  FROM TB_PDI_WHSN_INFO
								  WHERE QLTY_VEHL_CD = P_VEHL_CD
								  AND MDL_MDY_CD = P_MDL_MDY
								  AND LANG_CD = P_LANG_CD
								  AND WHSN_YMD BETWEEN V_CURR_FSTD_YMD AND V_CURR_LAST_YMD
								  GROUP BY WHSN_YMD
								  
								 ) B,
								 (
								  /*** 
								  SELECT B.WHOT_YMD,
									     SUM(DL_EXPD_WHOT_QTY) AS WHOT_QTY
								  FROM T A,
									   TB_PDI_WHOT_INFO B
								  WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
								  AND A.MDL_MDY_CD = B.MDL_MDY_CD
								  AND A.LANG_CD = B.LANG_CD
								  AND B.WHOT_YMD BETWEEN V_CURR_FSTD_YMD AND V_CURR_LAST_YMD
								  AND B.DL_EXPD_WHOT_ST_CD = '01' --투입(일반출고)된 항목만 조회 한다. 
								  AND B.DEL_YN = 'N'
								  GROUP BY B.WHOT_YMD 
								  ***/
								  
								  SELECT WHOT_YMD,
									     SUM(DL_EXPD_WHOT_QTY) AS WHOT_QTY
								  FROM TB_PDI_WHOT_INFO
								  WHERE QLTY_VEHL_CD = P_VEHL_CD
								  AND MDL_MDY_CD = P_MDL_MDY
								  AND LANG_CD = P_LANG_CD
								  AND WHOT_YMD BETWEEN V_CURR_FSTD_YMD AND V_CURR_LAST_YMD
								  AND DL_EXPD_WHOT_ST_CD = '01' --투입(일반출고)된 항목만 조회 한다. 
								  AND DEL_YN = 'N'
								  GROUP BY WHOT_YMD
								  
								 ) C
							 WHERE A.WK_YMD = B.WHSN_YMD(+)
							 AND A.WK_YMD = C.WHOT_YMD(+)
						   )
				 SELECT WK_YMD, 
				 		WHSN_QTY, 
						WHOT_QTY
				 FROM U
				 UNION ALL
				 SELECT 'TOTAL' AS WK_YMD, 
				 		SUM(WHSN_QTY) AS WHSN_QTY, 
						SUM(WHOT_QTY) AS WHOT_QTY
				 FROM U
				 ORDER BY WK_YMD;
						   
	   END SP_GET_1MTH_TRWI_INFO;
	   
	   --세화재고현황 조회 			  
       PROCEDURE SP_GET_SEWHA_IV_INFO(P_VEHL_CD  VARCHAR2,
							          P_MDL_MDY  VARCHAR2,
								      P_LANG_CD  VARCHAR2,
								      P_CURR_YMD VARCHAR2,
								      RS OUT REFCUR)
	   IS
	   BEGIN
	   		
			OPEN RS FOR
				 WITH 
				 	  /***
				 	  T AS (SELECT A.LANG_CD,
								   A.QLTY_VEHL_CD,
								   A.MDL_MDY_CD
						    FROM TB_LANG_MGMT A
							WHERE A.QLTY_VEHL_CD = P_VEHL_CD
							AND A.MDL_MDY_CD = P_MDL_MDY
							AND A.LANG_CD = P_LANG_CD
				           ), 
					  ***/ 
					  U AS (SELECT A.N_PRNT_PBCN_NO,
					  	   		   MAX(A.DL_EXPD_MDL_MDY_CD) AS DL_EXPD_MDL_MDY_CD,
					  	   		   MAX(C.DL_EXPD_PRVS_NM) AS IV_STATE_NM,
								   TO_CHAR(TO_DATE(MAX(B.WHSN_YMD), 'YYYYMMDD'), 'YYYY-MM-DD') AS TRTM_YMD,           -- 발주일 
								   TO_CHAR(TO_DATE(MAX(B.PRNT_PARR_YMD), 'YYYYMMDD'), 'YYYY-MM-DD') AS PRNT_PARR_YMD, --인쇄일 
								   TO_CHAR(TO_DATE(MAX(B.DLVG_PARR_YMD), 'YYYYMMDD'), 'YYYY-MM-DD') AS DLVG_PARR_YMD, --납품일 
								   MAX(A.IV_QTY) AS IV_QTY,
								   NVL(SUM(D.RQ_QTY), 0) AS PREV_DLVG_QTY,
								   MAX(A.IV_TEXT) AS IV_TEXT
					  	    FROM (SELECT A.QLTY_VEHL_CD,
								 		 A.MDL_MDY_CD,
										 A.LANG_CD,
										 B.DL_EXPD_MDL_MDY_CD,
								 		 B.N_PRNT_PBCN_NO,
								 		 B.SFTY_IV_QTY AS IV_QTY,
										 CASE WHEN (B.DL_EXPD_MDL_MDY_CD = P_MDL_MDY AND B.SFTY_IV_QTY - B.IV_QTY < 0) THEN TRIM(TO_CHAR(B.IV_QTY, '999,999,999')) ||
																															'(타연식:' || TRIM(TO_CHAR(B.SFTY_IV_QTY - B.IV_QTY, '999,999,999')) || ')'
											  ELSE '' 
										 END IV_TEXT,
										 CASE WHEN DL_EXPD_TMP_IV_QTY > 0 THEN '01'
										      ELSE '02'
										 END IV_STATE
								  FROM TB_LANG_MGMT A,
								  	   TB_SEWHA_IV_INFO_DTL B
								  WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
								  AND A.MDL_MDY_CD = B.MDL_MDY_CD
								  AND A.LANG_CD = B.LANG_CD
								  AND B.CLS_YMD = P_CURR_YMD
								  AND A.QLTY_VEHL_CD = P_VEHL_CD
								  AND A.MDL_MDY_CD = P_MDL_MDY
								  AND A.LANG_CD = P_LANG_CD
								 ) A,
								 TB_SEWHA_WHSN_INFO B,
								 TB_CODE_MGMT C,
								 TB_SEWHA_WHOT_INFO D
							WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD(+)
							--세화입고 정보의 경우 차종연식과 취급설명서 연식이 같을 수 밖에 없다.
							--(발주의뢰 화면에서 같게 넘어갈 수 밖에 없다.) 
							--그래서 차종연식은 비교조건에서 빼도록 한다. 
						    --AND A.MDL_MDY_CD = B.MDL_MDY_CD(+) 
							AND A.LANG_CD = B.LANG_CD(+)
							AND A.DL_EXPD_MDL_MDY_CD = B.DL_EXPD_MDL_MDY_CD(+)
							AND A.N_PRNT_PBCN_NO = B.N_PRNT_PBCN_NO(+)
							AND A.QLTY_VEHL_CD = D.QLTY_VEHL_CD(+)
							AND A.MDL_MDY_CD = D.MDL_MDY_CD(+)
							AND A.LANG_CD = D.LANG_CD(+)
							AND A.DL_EXPD_MDL_MDY_CD = D.DL_EXPD_MDL_MDY_CD(+)
							AND A.N_PRNT_PBCN_NO = D.N_PRNT_PBCN_NO(+)
							AND D.DEL_YN(+) = 'N'
							AND D.CMPL_YN(+) = 'Y' --입고확인된 항목만 보여지도록 한다. 
							AND A.IV_STATE = C.DL_EXPD_PRVS_CD
					        AND C.DL_EXPD_G_CD = '0020'
							GROUP BY A.N_PRNT_PBCN_NO
					       )
				 SELECT N_PRNT_PBCN_NO,
				 		DL_EXPD_MDL_MDY_CD,
				        IV_STATE_NM,
						TRTM_YMD,
						PRNT_PARR_YMD,
						DLVG_PARR_YMD,
						IV_QTY,
						PREV_DLVG_QTY,
						IV_TEXT
				 FROM U
				 UNION ALL
				 SELECT 'TOTAL' AS N_PRNT_PBCN_NO,
				 		'TOTAL' AS DL_EXPD_MDL_MDY_CD,
				        'TOTAL' AS IV_STATE_NM,
						'TOTAL' AS TRTM_YMD,
						'TOTAL' AS PRNT_PARR_YMD,
						'TOTAL' AS DLVG_PARR_YMD,
						SUM(IV_QTY) AS IV_QTY,
						SUM(PREV_DLVG_QTY) AS PREV_DLVG_QTY,
						'' AS IV_TEXT
				 FROM U;
				 
	   END SP_GET_SEWHA_IV_INFO;
	   
	   --당월 PDI 재고현황 조회 						 
  	   PROCEDURE SP_GET_1MTH_PDI_INFO(P_VEHL_CD  VARCHAR2,
							     	  P_MDL_MDY  VARCHAR2,
								 	  P_LANG_CD  VARCHAR2,
								 	  P_CURR_YMD VARCHAR2,
								 	  RS OUT REFCUR)
	   IS
	   	 
		 V_CURR_FSTD_YMD VARCHAR2(8); --현재월 1일 날짜
		 V_CURR_LAST_YMD VARCHAR2(8); --현재월 마지막 날짜 
		 
	   BEGIN
	   		
			V_CURR_FSTD_YMD := SUBSTR(P_CURR_YMD, 1, 6) || '01';
			V_CURR_LAST_YMD := TO_CHAR(LAST_DAY(TO_DATE(P_CURR_YMD, 'YYYYMMDD')), 'YYYYMMDD');
			
			OPEN RS FOR
				 WITH 
				 	  /***
					  T AS (SELECT A.LANG_CD,
								   A.LANG_CD_NM,
								   A.QLTY_VEHL_CD,
								   A.MDL_MDY_CD
						    FROM TB_LANG_MGMT A 
							WHERE A.QLTY_VEHL_CD = P_VEHL_CD
							AND A.MDL_MDY_CD = P_MDL_MDY
							AND A.LANG_CD = P_LANG_CD
				 	  	   ), 
					  ***/ 
					  
					  U AS (SELECT WK_YMD
					        FROM TB_WRK_DATE_MGMT
							WHERE WK_YMD BETWEEN V_CURR_FSTD_YMD AND V_CURR_LAST_YMD
							ORDER BY WK_YMD
						   )
				 SELECT TO_CHAR(TO_DATE(A.WK_YMD, 'YYYYMMDD'), 'YYYY-MM-DD') AS CLS_YMD, --날짜 
				 		NVL(B.PDI_WHSN_QTY, 0 ) AS PDI_WHSN_QTY, 		  			   	 --입고수량 
						NVL(B.EXPD_WHSN_ST_NM, '') AS EXPD_WHSN_ST_NM,					 --상태
						NVL(B.PDI_NORMAL_WHOT, 0 ) AS PDI_NORMAL_WHOT,					 --투입수량  
						NVL(B.PDI_EXTRA_WHOT, 0) AS PDI_EXTRA_WHOT,						 --별도출고수량 
						NVL(B.PDI_DISUSE_WHOT, 0) AS PDI_DISUSE_WHOT,					 --폐기수량 
						NVL(B.PDI_REVICE_WHOT, 0) AS PDI_REVICE_WHOT,					 --보정수량 
						NVL(B.PDI_IV_QTY, 0) AS PDI_IV_QTY,								 --현재고 
						FU_GET_PDI_IV_TEXT(A.WK_YMD, P_VEHL_CD, P_MDL_MDY, P_LANG_CD) AS PDI_IV_TEXT 
				 FROM U A,
					 (SELECT CLS_YMD, 
				 	  		 SUM(PDI_IV_QTY) AS PDI_IV_QTY,
				 	  		 SUM(PDI_WHSN_QTY) AS PDI_WHSN_QTY,
							 MAX(EXPD_WHSN_ST_NM) AS EXPD_WHSN_ST_NM,
							 --CASE WHEN MAX(EXPD_WHSN_ST_CD) = '0' THEN '-'
							 --     WHEN MAX(EXPD_WHSN_ST_CD) = '1' THEN '정상입고'
							 --	   WHEN MAX(EXPD_WHSN_ST_CD) = '2' THEN '과잉'
							 --	   WHEN MAX(EXPD_WHSN_ST_CD) = '3' THEN '부족'
							 --END AS EXPD_WHSN_ST_NM,
							 SUM(PDI_DEEI1_QTY) AS PDI_DEEI1_QTY,
							 SUM(PDI_NORMAL_WHOT) AS PDI_NORMAL_WHOT,
							 SUM(PDI_EXTRA_WHOT) AS PDI_EXTRA_WHOT,
							 SUM(PDI_DISUSE_WHOT) AS PDI_DISUSE_WHOT,
							 SUM(PDI_REVICE_WHOT) * (-1) AS PDI_REVICE_WHOT
				       FROM (SELECT A.CLS_YMD, 
					   				A.QLTY_VEHL_CD, 
									A.MDL_MDY_CD,
									A.LANG_CD, 
									--A.DL_EXPD_MDL_MDY_CD, 
									A.N_PRNT_PBCN_NO, 
							        MAX(PDI_IV_QTY) AS PDI_IV_QTY,
							        MAX(PDI_WHSN_QTY) AS PDI_WHSN_QTY,
									NVL(MAX(C.DL_EXPD_PRVS_NM), '') AS EXPD_WHSN_ST_NM,
									--MAX(EXPD_WHSN_ST_CD) AS EXPD_WHSN_ST_CD,
									MAX(PDI_DEEI1_QTY) AS PDI_DEEI1_QTY,
							        SUM(CASE WHEN DL_EXPD_WHOT_ST_CD = '01' THEN DL_EXPD_WHOT_QTY ELSE 0 END) AS PDI_NORMAL_WHOT,     --투입(출고) 
									SUM(CASE WHEN DL_EXPD_WHOT_ST_CD = '02' THEN DL_EXPD_WHOT_QTY ELSE 0 END) AS PDI_EXTRA_WHOT,              --별도출고
									SUM(CASE WHEN DL_EXPD_WHOT_ST_CD = '03' THEN DL_EXPD_WHOT_QTY ELSE 0 END) AS PDI_DISUSE_WHOT,             --폐기 
									SUM(CASE WHEN DL_EXPD_WHOT_ST_CD IN ('04','05','06', '07', '08','09') THEN DL_EXPD_WHOT_QTY ELSE 0 END) AS PDI_REVICE_WHOT --재고보정 
				             FROM (SELECT A.CLS_YMD, 
							 	  		  A.QLTY_VEHL_CD, 
										  A.MDL_MDY_CD,
										  A.LANG_CD, 
										  A.DL_EXPD_MDL_MDY_CD,
										  A.N_PRNT_PBCN_NO, 
									      MAX(PDI_IV_QTY) AS PDI_IV_QTY,
										  MAX(DL_EXPD_WHSN_ST_CD) AS EXPD_WHSN_ST_CD,
										  --MAX(CASE WHEN DL_EXPD_WHSN_ST_CD = '01' THEN '1'
										  --         WHEN DL_EXPD_WHSN_ST_CD = '02' THEN '3'
										  --		   WHEN DL_EXPD_WHSN_ST_CD = '03' THEN '2'
										  -- 		   ELSE '0'
										  --	  END) AS EXPD_WHSN_ST_CD,
									      NVL(SUM(B.WHSN_QTY), 0) AS PDI_WHSN_QTY,
										  NVL(SUM(B.DEEI1_QTY), 0) AS PDI_DEEI1_QTY
				                   FROM (SELECT B.CLS_YMD, 
								   				A.QLTY_VEHL_CD, 
												A.MDL_MDY_CD,
												A.LANG_CD, 
												B.DL_EXPD_MDL_MDY_CD,
												B.N_PRNT_PBCN_NO, 
								                SUM(B.SFTY_IV_QTY) AS PDI_IV_QTY
         				                 FROM TB_LANG_MGMT A,
              				                  TB_PDI_IV_INFO_DTL B,
											  U C
         				                 WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
         				                 AND A.MDL_MDY_CD = B.MDL_MDY_CD
         				                 AND A.LANG_CD = B.LANG_CD
         				                 AND B.CLS_YMD = C.WK_YMD
										 AND A.QLTY_VEHL_CD = P_VEHL_CD
										 AND A.MDL_MDY_CD = P_MDL_MDY
										 AND A.LANG_CD = P_LANG_CD
						                 GROUP BY B.CLS_YMD, A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD, 
										 	      B.DL_EXPD_MDL_MDY_CD, B.N_PRNT_PBCN_NO
						                ) A,
							            TB_PDI_WHSN_INFO B
					              WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD(+)
								  AND A.MDL_MDY_CD = B.MDL_MDY_CD(+)
					              AND A.LANG_CD = B.LANG_CD(+)
								  AND A.DL_EXPD_MDL_MDY_CD = B.DL_EXPD_MDL_MDY_CD(+)
							      AND A.N_PRNT_PBCN_NO = B.N_PRNT_PBCN_NO(+)
					              AND A.CLS_YMD = B.WHSN_YMD(+)
							      GROUP BY A.CLS_YMD, A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD, 
								  		   A.DL_EXPD_MDL_MDY_CD, A.N_PRNT_PBCN_NO
					             ) A,
					             TB_PDI_WHOT_INFO B,
								 TB_CODE_MGMT C
					       WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD(+)
						   AND A.MDL_MDY_CD = B.MDL_MDY_CD(+)
					       AND A.LANG_CD = B.LANG_CD(+)
						   AND A.DL_EXPD_MDL_MDY_CD = B.DL_EXPD_MDL_MDY_CD(+)
					       AND A.N_PRNT_PBCN_NO = B.N_PRNT_PBCN_NO(+)
					       AND A.CLS_YMD = B.WHOT_YMD(+)
						   AND B.DEL_YN(+) = 'N'
						   AND A.EXPD_WHSN_ST_CD = C.DL_EXPD_PRVS_CD(+)
						   AND C.DL_EXPD_G_CD(+) = '0013'
					       GROUP BY A.CLS_YMD, A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD, A.N_PRNT_PBCN_NO
						  )
					  GROUP BY CLS_YMD
				     ) B
			    WHERE A.WK_YMD = B.CLS_YMD(+)
				ORDER BY A.WK_YMD;
				 
	   END SP_GET_1MTH_PDI_INFO;

	   --당월 PDI 재고현황 조회 						 
  	   PROCEDURE SP_GET_1MTH_PDI_INFO2(P_VEHL_CD  VARCHAR2,
							     	  P_MDL_MDY  VARCHAR2,
								 	  P_LANG_CD  VARCHAR2,
								 	  P_CURR_YMD VARCHAR2,
								 	  RS OUT REFCUR)
	   IS
	   	 
		 V_CURR_FSTD_YMD VARCHAR2(8); --현재월 1일 날짜
		 V_CURR_LAST_YMD VARCHAR2(8); --현재월 마지막 날짜 
		 
	   BEGIN
	   		
			V_CURR_FSTD_YMD := SUBSTR(P_CURR_YMD, 1, 6) || '01';
			V_CURR_LAST_YMD := TO_CHAR(LAST_DAY(TO_DATE(P_CURR_YMD, 'YYYYMMDD')), 'YYYYMMDD');
			
			OPEN RS FOR
				 WITH 
					  U AS (SELECT WK_YMD
					        FROM TB_WRK_DATE_MGMT
							WHERE WK_YMD BETWEEN V_CURR_FSTD_YMD AND V_CURR_LAST_YMD
                            UNION
                            SELECT '합계' WK_YMD
                            FROM DUAL
							ORDER BY WK_YMD
						   )
				 SELECT DECODE(A.WK_YMD, '합계', A.WK_YMD, TO_CHAR(TO_DATE(A.WK_YMD, 'YYYYMMDD'), 'YYYY-MM-DD')) AS CLS_YMD, --날짜 
				 		NVL(B.PDI_WHSN_QTY, 0 ) AS PDI_WHSN_QTY, 		  			   	 --입고수량 
						NVL(B.EXPD_WHSN_ST_NM, '') AS EXPD_WHSN_ST_NM,					 --상태
						NVL(B.PDI_NORMAL_WHOT, 0 ) AS PDI_NORMAL_WHOT,					 --투입수량  
						NVL(B.PDI_EXTRA_WHOT, 0) AS PDI_EXTRA_WHOT,						 --별도출고수량 
						NVL(B.PDI_DISUSE_WHOT, 0) AS PDI_DISUSE_WHOT,					 --폐기수량 
						NVL(B.PDI_REVICE_WHOT, 0) AS PDI_REVICE_WHOT,					 --보정수량 
						NVL(B.PDI_IV_QTY, 0) AS PDI_IV_QTY,								 --현재고 
						FU_GET_PDI_IV_TEXT(A.WK_YMD, P_VEHL_CD, P_MDL_MDY, P_LANG_CD) AS PDI_IV_TEXT 
				 FROM U A,
					 (SELECT NVL(CLS_YMD, '합계') CLS_YMD, 
				 	  		 SUM(PDI_IV_QTY) AS PDI_IV_QTY,
				 	  		 SUM(PDI_WHSN_QTY) AS PDI_WHSN_QTY,
							 MAX(EXPD_WHSN_ST_NM) AS EXPD_WHSN_ST_NM,
							 --CASE WHEN MAX(EXPD_WHSN_ST_CD) = '0' THEN '-'
							 --     WHEN MAX(EXPD_WHSN_ST_CD) = '1' THEN '정상입고'
							 --	   WHEN MAX(EXPD_WHSN_ST_CD) = '2' THEN '과잉'
							 --	   WHEN MAX(EXPD_WHSN_ST_CD) = '3' THEN '부족'
							 --END AS EXPD_WHSN_ST_NM,
							 SUM(PDI_DEEI1_QTY) AS PDI_DEEI1_QTY,
							 SUM(PDI_NORMAL_WHOT) AS PDI_NORMAL_WHOT,
							 SUM(PDI_EXTRA_WHOT) AS PDI_EXTRA_WHOT,
							 SUM(PDI_DISUSE_WHOT) AS PDI_DISUSE_WHOT,
							 SUM(PDI_REVICE_WHOT) * (-1) AS PDI_REVICE_WHOT
				       FROM (SELECT A.CLS_YMD, 
					   				A.QLTY_VEHL_CD, 
									A.MDL_MDY_CD,
									A.LANG_CD, 
									--A.DL_EXPD_MDL_MDY_CD, 
									A.N_PRNT_PBCN_NO, 
							        MAX(PDI_IV_QTY) AS PDI_IV_QTY,
							        MAX(PDI_WHSN_QTY) AS PDI_WHSN_QTY,
									NVL(MAX(C.DL_EXPD_PRVS_NM), '') AS EXPD_WHSN_ST_NM,
									--MAX(EXPD_WHSN_ST_CD) AS EXPD_WHSN_ST_CD,
									MAX(PDI_DEEI1_QTY) AS PDI_DEEI1_QTY,
							        SUM(CASE WHEN DL_EXPD_WHOT_ST_CD = '01' THEN DL_EXPD_WHOT_QTY ELSE 0 END) AS PDI_NORMAL_WHOT,     --투입(출고) 
									SUM(CASE WHEN DL_EXPD_WHOT_ST_CD = '02' THEN DL_EXPD_WHOT_QTY ELSE 0 END) AS PDI_EXTRA_WHOT,              --별도출고
									SUM(CASE WHEN DL_EXPD_WHOT_ST_CD = '03' THEN DL_EXPD_WHOT_QTY ELSE 0 END) AS PDI_DISUSE_WHOT,             --폐기 
									SUM(CASE WHEN DL_EXPD_WHOT_ST_CD IN ('04','05','06', '07', '08','09') THEN DL_EXPD_WHOT_QTY ELSE 0 END) AS PDI_REVICE_WHOT --재고보정 
				             FROM (SELECT A.CLS_YMD, 
							 	  		  A.QLTY_VEHL_CD, 
										  A.MDL_MDY_CD,
										  A.LANG_CD, 
										  A.DL_EXPD_MDL_MDY_CD,
										  A.N_PRNT_PBCN_NO, 
									      MAX(PDI_IV_QTY) AS PDI_IV_QTY,
										  MAX(DL_EXPD_WHSN_ST_CD) AS EXPD_WHSN_ST_CD,
										  --MAX(CASE WHEN DL_EXPD_WHSN_ST_CD = '01' THEN '1'
										  --         WHEN DL_EXPD_WHSN_ST_CD = '02' THEN '3'
										  --		   WHEN DL_EXPD_WHSN_ST_CD = '03' THEN '2'
										  -- 		   ELSE '0'
										  --	  END) AS EXPD_WHSN_ST_CD,
									      NVL(SUM(B.WHSN_QTY), 0) AS PDI_WHSN_QTY,
										  NVL(SUM(B.DEEI1_QTY), 0) AS PDI_DEEI1_QTY
				                   FROM (SELECT B.CLS_YMD, 
								   				A.QLTY_VEHL_CD, 
												A.MDL_MDY_CD,
												A.LANG_CD, 
												B.DL_EXPD_MDL_MDY_CD,
												B.N_PRNT_PBCN_NO, 
								                SUM(B.SFTY_IV_QTY) AS PDI_IV_QTY
         				                 FROM TB_LANG_MGMT A,
              				                  TB_PDI_IV_INFO_DTL B,
											  U C
         				                 WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
         				                 AND A.MDL_MDY_CD = B.MDL_MDY_CD
         				                 AND A.LANG_CD = B.LANG_CD
         				                 AND B.CLS_YMD = C.WK_YMD
										 AND A.QLTY_VEHL_CD = P_VEHL_CD
										 AND A.MDL_MDY_CD = P_MDL_MDY
										 AND A.LANG_CD = P_LANG_CD
						                 GROUP BY B.CLS_YMD, A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD, 
										 	      B.DL_EXPD_MDL_MDY_CD, B.N_PRNT_PBCN_NO
						                ) A,
							            TB_PDI_WHSN_INFO B
					              WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD(+)
								  AND A.MDL_MDY_CD = B.MDL_MDY_CD(+)
					              AND A.LANG_CD = B.LANG_CD(+)
								  AND A.DL_EXPD_MDL_MDY_CD = B.DL_EXPD_MDL_MDY_CD(+)
							      AND A.N_PRNT_PBCN_NO = B.N_PRNT_PBCN_NO(+)
					              AND A.CLS_YMD = B.WHSN_YMD(+)
							      GROUP BY A.CLS_YMD, A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD, 
								  		   A.DL_EXPD_MDL_MDY_CD, A.N_PRNT_PBCN_NO
					             ) A,
					             TB_PDI_WHOT_INFO B,
								 TB_CODE_MGMT C
					       WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD(+)
						   AND A.MDL_MDY_CD = B.MDL_MDY_CD(+)
					       AND A.LANG_CD = B.LANG_CD(+)
						   AND A.DL_EXPD_MDL_MDY_CD = B.DL_EXPD_MDL_MDY_CD(+)
					       AND A.N_PRNT_PBCN_NO = B.N_PRNT_PBCN_NO(+)
					       AND A.CLS_YMD = B.WHOT_YMD(+)
						   AND B.DEL_YN(+) = 'N'
						   AND A.EXPD_WHSN_ST_CD = C.DL_EXPD_PRVS_CD(+)
						   AND C.DL_EXPD_G_CD(+) = '0013'
					       GROUP BY A.CLS_YMD, A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD, A.N_PRNT_PBCN_NO
						  )
					  GROUP BY ROLLUP(CLS_YMD)
				     ) B
			    WHERE A.WK_YMD = B.CLS_YMD(+)
				ORDER BY A.WK_YMD;
				 
	   END SP_GET_1MTH_PDI_INFO2;
	   
	   --메일 발송 작업 수행 								 
       PROCEDURE SP_SEND_MAIL(P_VEHL_CD        VARCHAR2,
	   			 		      P_MDL_MDY_CD     VARCHAR2,
						      P_BLNS_CO_CD     VARCHAR2,
						      P_USER_EENO      VARCHAR2,
							  P_MAIL_TITLE	   VARCHAR2,
							  P_MAIL_CONTENT   VARCHAR2)
	   IS
	   	 
		 CURSOR CRGR_USER_LIST_INFO IS SELECT A.USER_EENO AS USER_EENO,
                					   		  NVL(A.USER_NM, ' ') AS USER_NM,
											  A.USER_EML_ADR AS USER_EML_ADR
           							   FROM TB_USR_MGMT A,
		   							   		TB_VEHL_CRGR_MGMT B
		   							   WHERE A.USER_EENO = B.CRGR_EENO
		   							   AND B.QLTY_VEHL_CD = P_VEHL_CD
		   							   AND B.MDL_MDY_CD = P_MDL_MDY_CD
		   							   AND B.BLNS_CO_CD = P_BLNS_CO_CD
           							   AND B.USE_YN = 'Y'
		   							   AND A.USE_YN = 'Y';
									   
		 V_USER_NM      TB_USR_MGMT.USER_NM%TYPE;
		 V_USER_EML_ADR TB_USR_MGMT.USER_EML_ADR%TYPE;
		 
		 V_MAIL_CONTENT VARCHAR2(8000);
		 
	   BEGIN
	   		
			SELECT NVL(USER_NM, ' '),
			       NVL(USER_EML_ADR, ' ')
			INTO V_USER_NM,
			     V_USER_EML_ADR
			FROM TB_USR_MGMT
			WHERE USER_EENO = PG_COMMON.FU_RPAD(P_USER_EENO, 7);
			
			V_MAIL_CONTENT := '<HTML><BODY>' ||
						      P_MAIL_CONTENT ||
							  --'연락번호: ' || V_USER_TN || '<br>' ||
							  '</BODY></HTML>';
			
			--메일발송자 에게도 메일을 발송한다. 
			IF V_USER_EML_ADR <> ' ' THEN
			   
			   SP_CHNL_INSERTSIMPLEEMAIL(V_USER_NM, 
				   						 V_USER_EML_ADR, 
										 P_USER_EENO, 
										 'H', 
										 '0', 
										 '0', 
										 V_MAIL_CONTENT,
                               			 SYSDATE, 
										 P_MAIL_TITLE, 
										 '0', 
										 '0', 
										 V_USER_NM, 
				   						 V_USER_EML_ADR, 
										 P_USER_EENO);
											 
			END IF;
			  
			FOR USER_LIST IN CRGR_USER_LIST_INFO LOOP
				
				IF USER_LIST.USER_EML_ADR IS NOT NULL THEN
				   
				   SP_CHNL_INSERTSIMPLEEMAIL(V_USER_NM, 
				   							 V_USER_EML_ADR, 
											 P_USER_EENO, 
											 'H', 
											 '0', 
											 '0', 
											 V_MAIL_CONTENT,
                               				 SYSDATE, 
											 P_MAIL_TITLE, 
											 '0', 
											 '0', 
											 USER_LIST.USER_NM, 
											 USER_LIST.USER_EML_ADR, 
											 USER_LIST.USER_EENO);
							   
				END IF;
					   
			END LOOP;
			
	   END SP_SEND_MAIL;
	   
	   --인터페이스 메세지 정보 조회(DATA_SN을 이용하여 생산계획 과 생산마스터 인터페이스 시간정보를 조회함)
  	   PROCEDURE SP_GET_MSG_PLAN_PROD(P_DATA_SN  NUMBER,
   			 				          P_CURR_YMD VARCHAR2,
							          P_SCH_YMD  OUT VARCHAR2,
							          P_MESSAGE  OUT VARCHAR2)
	   IS
	   
--	   	 V_FRAM_DTM1 DATE;
--		 V_FRAM_DTM2 DATE;
		 
--		 V_FRAM_DTM  DATE;
	     
		 V_PLN_FRAM_YMD VARCHAR2(8);
		 V_FRAM_YMD     VARCHAR2(8);
		 V_EXPD_CO_CD   VARCHAR2(4);
		 
	   BEGIN

	   		/***
			--생산게획 내역 조회 
	   		SELECT MAX(FRAM_DTM)
			INTO V_FRAM_DTM1
			FROM TB_BATCH_FNH_INFO
			WHERE AFFR_SCN_CD = '02'
			AND DL_EXPD_CO_CD = (SELECT B.DL_EXPD_CO_CD
			                     FROM TB_LANG_MGMT A,
								      TB_VEHL_MGMT B
								 WHERE A.DATA_SN = P_DATA_SN
								 AND A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
								 AND A.MDL_MDY_CD = B.MDL_MDY_CD
								)
			AND BTCH_FNH_YMD <= P_CURR_YMD;
			
			IF V_FRAM_DTM1 IS NOT NULL THEN

			   P_SCH_YMD := TO_CHAR(V_FRAM_DTM1, 'YYYYMMDD');
			   
			ELSE
			   
			   P_SCH_YMD := P_CURR_YMD;
			   
			END IF;
			
			--생산현황 내역 조회 
	   		SELECT MAX(FRAM_DTM)
			INTO V_FRAM_DTM2
			FROM TB_BATCH_FNH_INFO
			WHERE AFFR_SCN_CD = '03'
			AND DL_EXPD_CO_CD = (SELECT B.DL_EXPD_CO_CD
			                     FROM TB_LANG_MGMT A,
								      TB_VEHL_MGMT B
								 WHERE A.DATA_SN = P_DATA_SN
								 AND A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
								 AND A.MDL_MDY_CD = B.MDL_MDY_CD
								)
			AND BTCH_FNH_YMD <= P_CURR_YMD;
			
			IF V_FRAM_DTM1 IS NULL THEN
			   
			   V_FRAM_DTM := TO_DATE(P_CURR_YMD, 'YYYYMMDD');
			
			ELSE
			   
			   V_FRAM_DTM := V_FRAM_DTM1;
			   
			END IF;
			
			IF V_FRAM_DTM2 IS NOT NULL THEN
			
			   
			   IF V_FRAM_DTM2 < V_FRAM_DTM THEN
			   	  
				  V_FRAM_DTM := V_FRAM_DTM2;
				  
			   END IF;
			   
			END IF;
			
			P_MESSAGE:= PG_COMMON.FU_TO_LOCAL_DATE_CHAR(V_FRAM_DTM) || ' 기준입니다.';
			
			****/
			
			--소속회사코드 조회 
			SELECT MAX(B.DL_EXPD_CO_CD)
			INTO V_EXPD_CO_CD
			FROM TB_LANG_MGMT A,
			     TB_VEHL_MGMT B
			WHERE A.DATA_SN = P_DATA_SN
			AND A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
			AND A.MDL_MDY_CD = B.MDL_MDY_CD;
			
			
			SELECT MAX(BTCH_FNH_YMD)
			INTO V_PLN_FRAM_YMD
			FROM TB_BATCH_FNH_INFO
			WHERE AFFR_SCN_CD = '02'
			AND DL_EXPD_CO_CD = V_EXPD_CO_CD
			AND BTCH_FNH_YMD <= P_CURR_YMD;
			
			IF V_PLN_FRAM_YMD IS NOT NULL THEN

			   P_SCH_YMD := V_PLN_FRAM_YMD;
			   
--			ELSE
			   
--			   P_SCH_YMD := P_CURR_YMD;
			   
			END IF;
			
			
			--생산계획 데이터 역시 생산마스터 데이터를 기초로 생산된 것이므로 
			--생산마스터 인터페이스 날짜 정보만 확인해 주면 된다.
			
			--생산현황 내역 조회 
	   		SELECT MAX(BTCH_FNH_YMD)
			INTO V_FRAM_YMD
			FROM TB_BATCH_FNH_INFO
			WHERE AFFR_SCN_CD = '03'
			AND DL_EXPD_CO_CD = V_EXPD_CO_CD
			AND BTCH_FNH_YMD <= V_PLN_FRAM_YMD; 
			
			IF V_FRAM_YMD IS NOT NULL THEN
			   
			   P_MESSAGE := FU_TO_CLOSE_DATE_CHAR(V_FRAM_YMD, V_EXPD_CO_CD) || ' 기준입니다.';
			   
			END IF;

	   END SP_GET_MSG_PLAN_PROD;	
	   
	   PROCEDURE SP_GET_MSG_PROD2(P_DATA_SN  NUMBER,
   			 				      P_CURR_YMD VARCHAR2,
							      P_SCH_YMD  OUT VARCHAR2,
							      P_MESSAGE  OUT VARCHAR2)
	   IS
	   	 
		 V_FRAM_YMD     VARCHAR2(8);
		 V_EXPD_CO_CD   VARCHAR2(4);
		 
	   BEGIN
	   		
			--소속회사코드 조회 
			SELECT MAX(B.DL_EXPD_CO_CD)
			INTO V_EXPD_CO_CD
			FROM TB_LANG_MGMT A,
			     TB_VEHL_MGMT B
			WHERE A.DATA_SN = P_DATA_SN
			AND A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
			AND A.MDL_MDY_CD = B.MDL_MDY_CD;
			
			--생산현황 내역 조회 
	   		SELECT MAX(BTCH_FNH_YMD)
			INTO V_FRAM_YMD
			FROM TB_BATCH_FNH_INFO
			WHERE AFFR_SCN_CD = '03'
			AND DL_EXPD_CO_CD = V_EXPD_CO_CD
			AND BTCH_FNH_YMD <= P_CURR_YMD; 
			
			IF V_FRAM_YMD IS NOT NULL THEN
			   
			   P_SCH_YMD := V_FRAM_YMD;
			   
			   P_MESSAGE := FU_TO_CLOSE_DATE_CHAR(V_FRAM_YMD, V_EXPD_CO_CD) || ' 기준입니다.';
			   
			END IF;
	   
	   END SP_GET_MSG_PROD2;
	   
	   --인터페이스 메세지 정보 조회(차종과 연식을 이용하여 오더 인터페이스 시간정보를 조회함)
       PROCEDURE SP_GET_MSG_ODR(P_VEHL_CD  VARCHAR2,
						        P_MDL_MDY  VARCHAR2,
   			 				    P_CURR_YMD VARCHAR2,
							    P_SCH_YMD  OUT VARCHAR2,
							    P_MESSAGE  OUT VARCHAR2)
							
	  IS
	  	
--		V_FRAM_DTM1 DATE;
		
		 V_PLN_FRAM_YMD VARCHAR2(8);
		 V_FRAM_YMD     VARCHAR2(8);
		 V_EXPD_CO_CD   VARCHAR2(4);
		 
	  BEGIN
	  	   
		   /****
		   
		   --생산게획 내역 조회 
	   	   SELECT MAX(FRAM_DTM)
		   INTO V_FRAM_DTM1
		   FROM TB_BATCH_FNH_INFO
		   WHERE AFFR_SCN_CD = '01'
		   AND DL_EXPD_CO_CD = (SELECT DL_EXPD_CO_CD
			                    FROM TB_VEHL_MGMT
								WHERE QLTY_VEHL_CD = P_VEHL_CD
								AND MDL_MDY_CD = P_MDL_MDY
							   )
		   AND BTCH_FNH_YMD <= P_CURR_YMD;
			
		   IF V_FRAM_DTM1 IS NOT NULL THEN

		   	  P_SCH_YMD := TO_CHAR(V_FRAM_DTM1, 'YYYYMMDD');
			   
		   ELSE
			   
			  P_SCH_YMD   := P_CURR_YMD;
			  
			  V_FRAM_DTM1 := TO_DATE(P_CURR_YMD, 'YYYYMMDD');
			   
		   END IF;
		   
		   P_MESSAGE:= PG_COMMON.FU_TO_LOCAL_DATE_CHAR(V_FRAM_DTM1) || ' 기준입니다.';
		   
		   ****/
		   
		   --소속회사코드 조회 
		   SELECT MAX(DL_EXPD_CO_CD)
		   INTO V_EXPD_CO_CD
		   FROM TB_VEHL_MGMT
		   WHERE QLTY_VEHL_CD = P_VEHL_CD
		   AND MDL_MDY_CD = P_MDL_MDY;
		   
			
		   SELECT MAX(BTCH_FNH_YMD)
		   INTO V_PLN_FRAM_YMD
		   FROM TB_BATCH_FNH_INFO
		   WHERE AFFR_SCN_CD = '01'
		   AND DL_EXPD_CO_CD = V_EXPD_CO_CD
		   AND BTCH_FNH_YMD <= P_CURR_YMD;
		   
		   IF V_PLN_FRAM_YMD IS NOT NULL THEN

		   	  P_SCH_YMD := V_PLN_FRAM_YMD;
			   
--		   ELSE
			   
--			  P_SCH_YMD   := P_CURR_YMD;
			   
		   END IF;
		   
		   --생산계획 데이터 역시 생산마스터 데이터를 기초로 생산된 것이므로 
		   --생산마스터 인터페이스 날짜 정보만 확인해 주면 된다.
			
		   --생산현황 내역 조회 
	   	   SELECT MAX(BTCH_FNH_YMD)
		   INTO V_FRAM_YMD
		   FROM TB_BATCH_FNH_INFO
		   WHERE AFFR_SCN_CD = '03'
		   AND DL_EXPD_CO_CD = V_EXPD_CO_CD
		   AND BTCH_FNH_YMD <= V_PLN_FRAM_YMD; 
			
		   IF V_FRAM_YMD IS NOT NULL THEN
			   
			   P_MESSAGE := FU_TO_CLOSE_DATE_CHAR(V_FRAM_YMD, V_EXPD_CO_CD) || ' 기준입니다.';
			   
		   END IF;
		   
	  END SP_GET_MSG_ODR;
	  
	  --인터페이스 메세지 정보 조회(차종과 연식을 이용하여 생산마스터 인터페이스 시간정보를 조회함)
  	  PROCEDURE SP_GET_MSG_PROD(P_VEHL_CD  VARCHAR2,
						    	P_MDL_MDY  VARCHAR2,
   			 			        P_CURR_YMD VARCHAR2,
								P_SCH_YMD  OUT VARCHAR2,
 						        P_MESSAGE  OUT VARCHAR2)
	  IS
	  	
--		V_FRAM_DTM1 DATE;
		
		 V_FRAM_YMD     VARCHAR2(8);
		 V_EXPD_CO_CD   VARCHAR2(4);
		 
	  BEGIN
	  	   
		   /****
		   
		   --생산게획 내역 조회 
	   	   SELECT MAX(FRAM_DTM)
		   INTO V_FRAM_DTM1
		   FROM TB_BATCH_FNH_INFO
		   WHERE AFFR_SCN_CD = '03'
		   AND DL_EXPD_CO_CD = (SELECT DL_EXPD_CO_CD
			                    FROM TB_VEHL_MGMT
								WHERE QLTY_VEHL_CD = P_VEHL_CD
								AND MDL_MDY_CD = P_MDL_MDY
							   )
		   AND BTCH_FNH_YMD <= P_CURR_YMD;
		   
		   IF V_FRAM_DTM1 IS NULL THEN
		   	  
			  V_FRAM_DTM1 := TO_DATE(P_CURR_YMD, 'YYYYMMDD');
			  
		   END IF;
		   
		   P_MESSAGE:= PG_COMMON.FU_TO_LOCAL_DATE_CHAR(V_FRAM_DTM1) || ' 기준입니다.';
	  	   
		   ****/
		   
		   --소속회사코드 조회 
		   SELECT MAX(DL_EXPD_CO_CD)
		   INTO V_EXPD_CO_CD
		   FROM TB_VEHL_MGMT
		   WHERE QLTY_VEHL_CD = P_VEHL_CD
		   AND MDL_MDY_CD = P_MDL_MDY;

		   --생산현황 내역 조회 
	   	   SELECT MAX(BTCH_FNH_YMD)
		   INTO V_FRAM_YMD
		   FROM TB_BATCH_FNH_INFO
		   WHERE AFFR_SCN_CD = '03'
		   AND DL_EXPD_CO_CD = V_EXPD_CO_CD
		   AND BTCH_FNH_YMD <= P_CURR_YMD; 
			
		   IF V_FRAM_YMD IS NOT NULL THEN
			   
			   P_SCH_YMD := V_FRAM_YMD;
			   
			   P_MESSAGE := FU_TO_CLOSE_DATE_CHAR(V_FRAM_YMD, V_EXPD_CO_CD) || ' 기준입니다.';
			   
		   END IF;
		   
	  END SP_GET_MSG_PROD;
	  
	  /**   현재 사용 안함 				  		
	  --인터페이스 메세지 정보 조회(차종과 연식을 이용하여 오더계획 과 생산마스터 인터페이스 시간정보를 조회함)
  	  PROCEDURE SP_GET_MSG_ODR_PROD(P_VEHL_CD  VARCHAR2,
						            P_MDL_MDY  VARCHAR2,
   			 			            P_CURR_YMD VARCHAR2,
						            P_SCH_YMD  OUT VARCHAR2,
 						            P_MESSAGE  OUT VARCHAR2)
	  IS
	  
	  	V_FRAM_DTM1 DATE;
		V_FRAM_DTM2 DATE;
		
		V_FRAM_DTM  DATE;
		
	  BEGIN
	  	   
		   --오더계획 내역 조회 
	   	   SELECT MAX(FRAM_DTM)
		   INTO V_FRAM_DTM1
		   FROM TB_BATCH_FNH_INFO
		   WHERE AFFR_SCN_CD = '01'
		   AND DL_EXPD_CO_CD = (SELECT DL_EXPD_CO_CD
			                    FROM TB_VEHL_MGMT
								WHERE QLTY_VEHL_CD = P_VEHL_CD
								AND MDL_MDY_CD = P_MDL_MDY
							   )
		   AND BTCH_FNH_YMD <= P_CURR_YMD;
			
		   IF V_FRAM_DTM1 IS NOT NULL THEN

		   	  P_SCH_YMD := TO_CHAR(V_FRAM_DTM1, 'YYYYMMDD');
			   
		   ELSE
			   
			  P_SCH_YMD := P_CURR_YMD;
			   
		   END IF;
		   
		   --생산현황 내역 조회 
	   	   SELECT MAX(FRAM_DTM)
		   INTO V_FRAM_DTM2
		   FROM TB_BATCH_FNH_INFO
		   WHERE AFFR_SCN_CD = '03'
		   AND DL_EXPD_CO_CD = (SELECT DL_EXPD_CO_CD
			                    FROM TB_VEHL_MGMT
								WHERE QLTY_VEHL_CD = P_VEHL_CD
								AND MDL_MDY_CD = P_MDL_MDY
							   )
		   AND BTCH_FNH_YMD <= P_CURR_YMD;
		   
		   
		   IF V_FRAM_DTM1 IS NULL THEN
			   
			   V_FRAM_DTM := TO_DATE(P_CURR_YMD, 'YYYYMMDD');
			
		   ELSE
			   
			   V_FRAM_DTM := V_FRAM_DTM1;
			   
		   END IF;
			
		   IF V_FRAM_DTM2 IS NOT NULL THEN
			
		       IF V_FRAM_DTM2 < V_FRAM_DTM THEN
			   	  
				  V_FRAM_DTM := V_FRAM_DTM2;
				  
			   END IF;
			   
		   END IF;
			
		   P_MESSAGE:= PG_COMMON.FU_TO_LOCAL_DATE_CHAR(V_FRAM_DTM) || ' 기준입니다.';
	  
	  END SP_GET_MSG_ODR_PROD;
	  **/
	  
	  /**   현재 사용 안함 					
	  --인터페이스 메세지 정보 조회(DATA_SN을 이용하여 오더계획과 생산계획 인터페이스 시간정보를 조회함)						   
      PROCEDURE SP_GET_MSG_ODR_PLAN(P_DATA_SN  NUMBER,
   			 				        P_CURR_YMD VARCHAR2,
							        P_SCH_YMD1 OUT VARCHAR2,
								    P_SCH_YMD2 OUT VARCHAR2,
							        P_MESSAGE  OUT VARCHAR2)
	  IS
	  	
		V_FRAM_DTM1 DATE;
		V_FRAM_DTM2 DATE;
		
		V_FRAM_DTM  DATE;
		
	  BEGIN
	       
		   --가장 최근의 APS 오더 정보 인터페이스 일자를 얻어온다. 
			SELECT MAX(FRAM_DTM)
			INTO V_FRAM_DTM1
			FROM TB_BATCH_FNH_INFO
			WHERE AFFR_SCN_CD = '01'
			AND DL_EXPD_CO_CD = (SELECT B.DL_EXPD_CO_CD
			                     FROM TB_LANG_MGMT A,
								      TB_VEHL_MGMT B
								 WHERE A.DATA_SN = P_DATA_SN
								 AND A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
								 AND A.MDL_MDY_CD = B.MDL_MDY_CD
								)
			AND BTCH_FNH_YMD <= P_CURR_YMD;
			
			IF V_FRAM_DTM1 IS NOT NULL THEN
			   
			   P_SCH_YMD1 := TO_CHAR(V_FRAM_DTM1, 'YYYYMMDD');
			   
			ELSE
			   
			   P_SCH_YMD1 := P_CURR_YMD;
			   
			END IF;
			
			--가장 최근의 APS 생산계획 정보 인터페이스 일자를 얻어온다.
			SELECT MAX(FRAM_DTM)
			INTO V_FRAM_DTM2
			FROM TB_BATCH_FNH_INFO
			WHERE AFFR_SCN_CD = '02'
			AND DL_EXPD_CO_CD = (SELECT B.DL_EXPD_CO_CD
			                     FROM TB_LANG_MGMT A,
								      TB_VEHL_MGMT B
								 WHERE A.DATA_SN = P_DATA_SN
								 AND A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
								 AND A.MDL_MDY_CD = B.MDL_MDY_CD
								)
			AND BTCH_FNH_YMD <= P_CURR_YMD;
			
			IF V_FRAM_DTM2 IS NOT NULL THEN
			   
			   P_SCH_YMD2 := TO_CHAR(V_FRAM_DTM2, 'YYYYMMDD');
			   
			ELSE
			   
			   P_SCH_YMD2 := P_CURR_YMD;
			   
			END IF;
			
			
			IF V_FRAM_DTM1 IS NULL THEN
			   
			   V_FRAM_DTM := TO_DATE(P_CURR_YMD, 'YYYYMMDD');
			
		    ELSE
			   
			   V_FRAM_DTM := V_FRAM_DTM1;
			   
		    END IF;
			
		    IF V_FRAM_DTM2 IS NOT NULL THEN
			
		       IF V_FRAM_DTM2 < V_FRAM_DTM THEN
			   	  
				  V_FRAM_DTM := V_FRAM_DTM2;
				  
			   END IF;
			   
		    END IF;
		    
			P_MESSAGE:= PG_COMMON.FU_TO_LOCAL_DATE_CHAR(V_FRAM_DTM) || ' 기준입니다.';
						   
	  END SP_GET_MSG_ODR_PLAN;
	  **/
	  
	  PROCEDURE SP_GET_MESSAGE(P_CURR_YMD VARCHAR2,
	                           P_MESSAGE  OUT VARCHAR2)
	  IS
	  	
		/**
		V_FRAM_DTM1 DATE;
		V_FRAM_DTM2 DATE;
		V_FRAM_DTM3 DATE;
		V_FRAM_DTM4 DATE;
		V_FRAM_DTM5 DATE;
		V_FRAM_DTM6 DATE; 
		**/
		
--		V_FRAM_DTM DATE;
		
--		V_FRAM_YMD VARCHAR2(8);
		
		V_FRAM_YMD1 VARCHAR2(8);
		V_FRAM_YMD2 VARCHAR2(8);
		
	  BEGIN
	  	   
		   /**
		   SELECT MAX(FRAM_DTM)
		   INTO V_FRAM_DTM1
		   FROM TB_BATCH_FNH_INFO
		   WHERE AFFR_SCN_CD = '01'
		   AND DL_EXPD_CO_CD = '01'
		   AND BTCH_FNH_YMD <= P_CURR_YMD;
		   
		   SELECT MAX(FRAM_DTM)
		   INTO V_FRAM_DTM2
		   FROM TB_BATCH_FNH_INFO
		   WHERE AFFR_SCN_CD = '01'
		   AND DL_EXPD_CO_CD = '02'
		   AND BTCH_FNH_YMD <= P_CURR_YMD;
		   
		   SELECT MAX(FRAM_DTM)
		   INTO V_FRAM_DTM3
		   FROM TB_BATCH_FNH_INFO
		   WHERE AFFR_SCN_CD = '02'
		   AND DL_EXPD_CO_CD = '01'
		   AND BTCH_FNH_YMD <= P_CURR_YMD;
		   
		   SELECT MAX(FRAM_DTM)
		   INTO V_FRAM_DTM4
		   FROM TB_BATCH_FNH_INFO
		   WHERE AFFR_SCN_CD = '02'
		   AND DL_EXPD_CO_CD = '02'
		   AND BTCH_FNH_YMD <= P_CURR_YMD;
		   
		   SELECT MAX(FRAM_DTM)
		   INTO V_FRAM_DTM5
		   FROM TB_BATCH_FNH_INFO
		   WHERE AFFR_SCN_CD = '03'
		   AND DL_EXPD_CO_CD = '01'
		   AND BTCH_FNH_YMD <= P_CURR_YMD;
		   
		   SELECT MAX(FRAM_DTM)
		   INTO V_FRAM_DTM6
		   FROM TB_BATCH_FNH_INFO
		   WHERE AFFR_SCN_CD = '03'
		   AND DL_EXPD_CO_CD = '02'
		   AND BTCH_FNH_YMD <= P_CURR_YMD;
		   **/
		   
		   /*****
		   SELECT MIN(FRAM_DTM)
		   INTO V_FRAM_DTM
		   FROM (
		   		 SELECT MAX(FRAM_DTM) AS FRAM_DTM
		         FROM TB_BATCH_FNH_INFO
		         WHERE AFFR_SCN_CD = '01'
		         AND DL_EXPD_CO_CD = '01'
		         AND BTCH_FNH_YMD <= P_CURR_YMD
		   		 
				 UNION ALL
				 
		         SELECT MAX(FRAM_DTM) AS FRAM_DTM
		         FROM TB_BATCH_FNH_INFO
		         WHERE AFFR_SCN_CD = '01'
		         AND DL_EXPD_CO_CD = '02'
		         AND BTCH_FNH_YMD <= P_CURR_YMD
		   		 
				 UNION ALL
				 
		         SELECT MAX(FRAM_DTM) AS FRAM_DTM
		         FROM TB_BATCH_FNH_INFO
		         WHERE AFFR_SCN_CD = '02'
		         AND DL_EXPD_CO_CD = '01'
		         AND BTCH_FNH_YMD <= P_CURR_YMD
		   		 
				 UNION ALL
				 
		   		 SELECT MAX(FRAM_DTM) AS FRAM_DTM
		         FROM TB_BATCH_FNH_INFO
		         WHERE AFFR_SCN_CD = '02'
		         AND DL_EXPD_CO_CD = '02'
		         AND BTCH_FNH_YMD <= P_CURR_YMD
		   		 
				 UNION ALL
				 
		   		 SELECT MAX(FRAM_DTM) AS FRAM_DTM
		         FROM TB_BATCH_FNH_INFO
		   		 WHERE AFFR_SCN_CD = '03'
		   		 AND DL_EXPD_CO_CD = '01'
		   		 AND BTCH_FNH_YMD <= P_CURR_YMD
		   		 
				 UNION ALL
				 
		   		 SELECT MAX(FRAM_DTM) AS FRAM_DTM
		   		 FROM TB_BATCH_FNH_INFO
		   		 WHERE AFFR_SCN_CD = '03'
		   		 AND DL_EXPD_CO_CD = '02'
		   		 AND BTCH_FNH_YMD <= P_CURR_YMD
		        );
		        
		   IF V_FRAM_DTM IS NULL THEN
		   	  
			  V_FRAM_DTM := TO_DATE(P_CURR_YMD, 'YYYYMMDD');
			  
		   END IF;
		   ****/
		   
		   /**
		   P_MESSAGE:= '※ HMC 오더계획: ' || PG_COMMON.FU_TO_LOCAL_DATE_CHAR(V_FRAM_DTM1) || ', ' ||
						  'KMC 오더계획: ' || PG_COMMON.FU_TO_LOCAL_DATE_CHAR(V_FRAM_DTM2) || ', ' ||
						  'HMC 생산계획: ' || PG_COMMON.FU_TO_LOCAL_DATE_CHAR(V_FRAM_DTM3) || ', ' ||
						  'KMC 생산계획: ' || PG_COMMON.FU_TO_LOCAL_DATE_CHAR(V_FRAM_DTM4) || ', ' ||
						  'HMC 생산마스터: ' || PG_COMMON.FU_TO_LOCAL_DATE_CHAR(V_FRAM_DTM5) || ', ' ||
						  'KMC 생산마스터: ' || PG_COMMON.FU_TO_LOCAL_DATE_CHAR(V_FRAM_DTM6) || ' 기준입니다.'; 
		   **/
		   
		   /***
		   P_MESSAGE := PG_COMMON.FU_TO_LOCAL_DATE_CHAR(V_FRAM_DTM) || ' 기준입니다.'; 
		   ***/
		   
		   /****
		   SELECT MAX(BTCH_FNH_YMD)
		   INTO V_FRAM_YMD
		   FROM TB_BATCH_FNH_INFO
		   WHERE AFFR_SCN_CD = '03'
		   AND DL_EXPD_CO_CD = '01'
		   AND BTCH_FNH_YMD <= P_CURR_YMD; 
		   
		   P_MESSAGE := '';
		   
		   IF V_FRAM_YMD IS NOT NULL THEN
			   
			   P_MESSAGE := 'HMC:' || FU_TO_CLOSE_DATE_CHAR(V_FRAM_YMD, EXPD_CO_CD_HMC) || ' '; 
			   
		   END IF;
		   
		   SELECT MAX(BTCH_FNH_YMD)
		   INTO V_FRAM_YMD
		   FROM TB_BATCH_FNH_INFO
		   WHERE AFFR_SCN_CD = '03'
		   AND DL_EXPD_CO_CD = '02'
		   AND BTCH_FNH_YMD <= P_CURR_YMD; 
		
		   IF V_FRAM_YMD IS NOT NULL THEN
			   
			   P_MESSAGE := P_MESSAGE || 'KMC:' || FU_TO_CLOSE_DATE_CHAR(V_FRAM_YMD, EXPD_CO_CD_KMC) || ' 기준입니다.'; 
			   
		   END IF;
		   ****/
		   
		   SELECT MAX(BTCH_FNH_YMD)
		   INTO V_FRAM_YMD1
		   FROM TB_BATCH_FNH_INFO
		   WHERE AFFR_SCN_CD = '03'
		   AND DL_EXPD_CO_CD = '01'
		   AND BTCH_FNH_YMD <= P_CURR_YMD;
		   
		   SELECT MAX(BTCH_FNH_YMD)
		   INTO V_FRAM_YMD2
		   FROM TB_BATCH_FNH_INFO
		   WHERE AFFR_SCN_CD = '03'
		   AND DL_EXPD_CO_CD = '02'
		   AND BTCH_FNH_YMD <= P_CURR_YMD;
		   
		   --둘 중에서 작은 값을 화면에 표시해 준다. 
		   IF NVL(V_FRAM_YMD1, P_CURR_YMD) < NVL(V_FRAM_YMD2, P_CURR_YMD) THEN
		   	  
			  IF V_FRAM_YMD1 IS NOT NULL THEN
			   
			   	 P_MESSAGE := SUBSTR(V_FRAM_YMD1, 5, 2)   || '월' || 
						      SUBSTR(V_FRAM_YMD1, 7, 2)   || '일' || '(HMC:03시30분 KMC:03시30분) 기준'; 
			   
		   	  END IF;
		   
		   ELSE
		      
			  IF V_FRAM_YMD2 IS NOT NULL THEN
			   
			   	 P_MESSAGE := SUBSTR(V_FRAM_YMD2, 5, 2)   || '월' || 
						      SUBSTR(V_FRAM_YMD2, 7, 2)   || '일' || '(HMC:03시30분 KMC:03시30분) 기준'; 
			   
		   	  END IF;
			  
		   END IF;
		   
	  END SP_GET_MESSAGE;
	  
	  --마감일자에 마감시간을 더해서 한글 형태로 변경하여 리턴 
  	  FUNCTION FU_TO_CLOSE_DATE_CHAR(P_CURR_YMD VARCHAR2, 
  		   						     P_EXPD_CO_CD VARCHAR2) RETURN VARCHAR2
      IS
   	 
	  	V_LOCAL_CHAR VARCHAR2(30);
	    
		V_LOCAL_DATE DATE;
		
   	  BEGIN
   	  	   
		   IF P_EXPD_CO_CD = EXPD_CO_CD_KMC THEN
		   	  
			  V_LOCAL_DATE := TO_DATE(P_CURR_YMD || KMC_CLOSE_TIME, 'YYYYMMDDHH24MI');
			  
		   ELSE
		      
			  V_LOCAL_DATE := TO_DATE(P_CURR_YMD || HMC_CLOSE_TIME, 'YYYYMMDDHH24MI');
			  
		   END IF;
		   
		   V_LOCAL_CHAR := TO_CHAR(V_LOCAL_DATE, 'MM')   || '월' || 
						   TO_CHAR(V_LOCAL_DATE, 'DD')   || '일' || '(' ||
						   TO_CHAR(V_LOCAL_DATE, 'HH24') || '시' ||
					       TO_CHAR(V_LOCAL_DATE, 'MI')   || '분' || ')'; 
		
		   RETURN V_LOCAL_CHAR;
	  
	  END FU_TO_CLOSE_DATE_CHAR;
	  
	  --세원 차종연식에 소속된 취급설명서 연식의 재고수량을 이전연식부터 문자형태로 표현해서 리턴하는 함수 								 
  	  FUNCTION FU_GET_SEWHA_IV_TEXT(P_CURR_YMD   VARCHAR2,
  		   						    P_VEHL_CD    VARCHAR2,
								    P_MDL_MDY_CD VARCHAR2,
								    P_LANG_CD	 VARCHAR2) RETURN VARCHAR2
	  IS
	  	
		V_IV_QTY_TEXT VARCHAR2(100);
		
		CURSOR SEWHA_IV_DTL_LIST_INFO IS SELECT DL_EXPD_MDL_MDY_CD,
			   						  	        CASE WHEN DL_EXPD_MDL_MDY_CD = P_MDL_MDY_CD THEN SUM(IV_QTY) ELSE SUM(SFTY_IV_QTY) END AS IV_QTY,
												CASE WHEN DL_EXPD_MDL_MDY_CD = P_MDL_MDY_CD THEN SUM(SFTY_IV_QTY - IV_QTY) ELSE 0 END AS SFTY_IV_QTY
           							     FROM TB_SEWHA_IV_INFO_DTL
		   							     WHERE CLS_YMD = P_CURR_YMD
		   							     AND QLTY_VEHL_CD = P_VEHL_CD
		   							     AND MDL_MDY_CD = P_MDL_MDY_CD
		   							     AND LANG_CD = P_LANG_CD
           							     GROUP BY DL_EXPD_MDL_MDY_CD;
	  	
	  BEGIN
	  	   
		   V_IV_QTY_TEXT := '';
		   
		   FOR SEWHA_IV_DTL_LIST IN SEWHA_IV_DTL_LIST_INFO LOOP
		   	   
			   IF SEWHA_IV_DTL_LIST.IV_QTY > 0 THEN
			   	  
				  V_IV_QTY_TEXT := V_IV_QTY_TEXT || 
				  				   SEWHA_IV_DTL_LIST.DL_EXPD_MDL_MDY_CD || 'MY:' || 
								   TRIM(TO_CHAR(SEWHA_IV_DTL_LIST.IV_QTY, '999,999,999')) || 
								   CASE WHEN SEWHA_IV_DTL_LIST.SFTY_IV_QTY < 0 THEN '(타연식:' || TRIM(TO_CHAR(SEWHA_IV_DTL_LIST.SFTY_IV_QTY, '999,999,999')) || ')' ELSE '' END || ' ';
				  
			   END IF;
			   
		   END LOOP;
		   
		   IF LENGTH(V_IV_QTY_TEXT) > 0 THEN
			   
			   	  V_IV_QTY_TEXT := SUBSTR(V_IV_QTY_TEXT, 1, LENGTH(V_IV_QTY_TEXT) - 1);
		   
		   END IF;
		   
		   RETURN V_IV_QTY_TEXT;
		   
	  END FU_GET_SEWHA_IV_TEXT;
	  
	  --PDI 차종연식에 소속된 취급설명서 연식의 재고수량을 이전연식부터 문자형태로 표현해서 리턴하는 함수 								
  	  FUNCTION FU_GET_PDI_IV_TEXT(P_CURR_YMD   VARCHAR2,
  		   					      P_VEHL_CD    VARCHAR2,
							  	  P_MDL_MDY_CD VARCHAR2,
							  	  P_LANG_CD	   VARCHAR2) RETURN VARCHAR2
	  IS
	  
	  	V_IV_QTY_TEXT VARCHAR2(100);
		
		CURSOR PDI_IV_DTL_LIST_INFO IS SELECT DL_EXPD_MDL_MDY_CD,
			   						  	      CASE WHEN DL_EXPD_MDL_MDY_CD = P_MDL_MDY_CD THEN SUM(IV_QTY) ELSE SUM(SFTY_IV_QTY) END AS IV_QTY,
											  CASE WHEN DL_EXPD_MDL_MDY_CD = P_MDL_MDY_CD THEN SUM(SFTY_IV_QTY - IV_QTY) ELSE 0 END AS SFTY_IV_QTY
           							   FROM TB_PDI_IV_INFO_DTL
		   							   WHERE CLS_YMD = P_CURR_YMD
		   							   AND QLTY_VEHL_CD = P_VEHL_CD
		   							   AND MDL_MDY_CD = P_MDL_MDY_CD
		   							   AND LANG_CD = P_LANG_CD
           							   GROUP BY DL_EXPD_MDL_MDY_CD;
										 
	  BEGIN
	  	   
		   V_IV_QTY_TEXT := '';
		   
		   FOR PDI_IV_DTL_LIST IN PDI_IV_DTL_LIST_INFO LOOP
		   	   
			   IF PDI_IV_DTL_LIST.IV_QTY > 0 THEN
			   	  
				  V_IV_QTY_TEXT := V_IV_QTY_TEXT || 
				  				   PDI_IV_DTL_LIST.DL_EXPD_MDL_MDY_CD || 'MY:' || 
								   TRIM(TO_CHAR(PDI_IV_DTL_LIST.IV_QTY, '999,999,999')) || 
								   CASE WHEN PDI_IV_DTL_LIST.SFTY_IV_QTY < 0 THEN '(타연식:' || TRIM(TO_CHAR(PDI_IV_DTL_LIST.SFTY_IV_QTY, '999,999,999')) || ')' ELSE '' END || ' ';
				  
			   END IF;
			   
		   END LOOP;
		   
		   IF LENGTH(V_IV_QTY_TEXT) > 0 THEN
			   
			   	  V_IV_QTY_TEXT := SUBSTR(V_IV_QTY_TEXT, 1, LENGTH(V_IV_QTY_TEXT) - 1);
		    
		   END IF;
		   	
		   RETURN V_IV_QTY_TEXT;
		   
	  END FU_GET_PDI_IV_TEXT;
	  
	  --[추가].2010.04.20.김동근 공장별 2주생산계획을 문자형태로 리턴
	  FUNCTION FU_GET_PLNT_WEK2_PLAN_QTY(P_CURR_YMD   VARCHAR2,
  		   					             P_VEHL_CD    VARCHAR2,
							             P_MDL_MDY_CD VARCHAR2,
							             P_LANG_CD	   VARCHAR2) RETURN VARCHAR2
	  IS
	  	CURSOR WEK2_PLAN_LIST IS SELECT QLTY_VEHL_CD, TRIM(TO_CHAR(WEK2_PLAN_QTY, '99,999,999')) AS WEK2_PLAN_QTY,
			   				  	 		PLNT_NM
								 FROM (SELECT TRIM(B.QLTY_VEHL_CD) QLTY_VEHL_CD, NVL(A.WEK2_PRDN_PLN_QTY, 0) + NVL(A.TDD_PRDN_QTY3, 0) AS WEK2_PLAN_QTY,
								 	  		  PLNT_NM
	   	                               FROM TB_PLNT_APS_PROD_SUM_INFO A,
								            TB_PLNT_VEHL_MGMT B
                                       WHERE A.APL_YMD(+) = P_CURR_YMD
								 	   AND A.QLTY_VEHL_CD(+) = P_VEHL_CD
								 	   AND A.MDL_MDY_CD(+) = P_MDL_MDY_CD
								 	   AND A.LANG_CD(+) = P_LANG_CD
								 	   AND A.QLTY_VEHL_CD(+) = B.QLTY_VEHL_CD
								 	   AND A.PRDN_PLNT_CD(+) = B.PRDN_PLNT_CD
								 	   ORDER BY B.SORT_SN
									  )
								 --값이 없는 항목도 표시하도록 한다. 
								 --WHERE WEK2_PLAN_QTY > 0
								 ;
								 
		V_WEK2_LIST VARCHAR2(8000);
		V_FLAG      CHAR(1);
		
	  BEGIN
	  	   --[주의] 2010.05.11.김동근 TB_PLNT_APS_PROD_SUM_INFO 테이블에 공장별 데이터가 하나도 존재하지 않는 차종의 경우(예를 들어 AM 차종의 11MY, PE 언어에 해당하는 광주 1, 2공장 내역이 아예 존재하지 않는는 경우)에는
		   --                         TB_PLNT_VEHL_MGMT 테이블에 지정되어 있다고 하더라도 화면에서 보여지지 않게 된다.('0' 으로 표시됨) 
		   --						  그래서 통일성을 주기 위하여 계획수량이 없는(각 공장 모두 '0' 인) 경우에는 빈문자로 표시되도록 한다. 
		   V_WEK2_LIST := '';
		   V_FLAG      := '0';
		   
		   FOR PLAN_LIST IN WEK2_PLAN_LIST LOOP
			   
			   IF PLAN_LIST.WEK2_PLAN_QTY <> '0' THEN
			   	  
				  V_FLAG := '1';
				  
			   END IF;
			   
		   	   --V_WEK2_LIST := V_WEK2_LIST || PLAN_LIST.PLNT_NM || ': ' || PLAN_LIST.WEK2_PLAN_QTY || '|';
               IF PLAN_LIST.QLTY_VEHL_CD = P_VEHL_CD THEN
			        V_WEK2_LIST := V_WEK2_LIST || PLAN_LIST.WEK2_PLAN_QTY || '/';
               END IF;
			
		   END LOOP;
		   
		   IF V_FLAG = '0' THEN
		   	  
			  V_WEK2_LIST := '';
			  
		   ELSE
		   	   IF LENGTH(V_WEK2_LIST) > 0 THEN
		   
		   	   	  V_WEK2_LIST := SUBSTR(V_WEK2_LIST, 1, LENGTH(V_WEK2_LIST) - 1);
		   
		   	   END IF;
		   
		   END IF;
		   
		   RETURN V_WEK2_LIST;
		
	  END FU_GET_PLNT_WEK2_PLAN_QTY;		
	  
	  --[추가].2010.04.20.김동근 공장별 3일생산계획을 문자형태로 리턴
	  FUNCTION FU_GET_PLNT_DAY3_PLAN_QTY(P_CURR_YMD   VARCHAR2,
  		   					             P_VEHL_CD    VARCHAR2,
							             P_MDL_MDY_CD VARCHAR2,
							             P_LANG_CD	   VARCHAR2) RETURN VARCHAR2
	  IS
	  	CURSOR DAY3_PLAN_LIST IS SELECT QLTY_VEHL_CD, TRIM(TO_CHAR(DAY3_PLAN_QTY1, '99,999,999')) AS DAY3_PLAN_QTY1,
			   				  	 		PLNT_NM
			   				  	 FROM (SELECT TRIM(B.QLTY_VEHL_CD) QLTY_VEHL_CD, NVL(A.TDD_PRDN_PLN_QTY, 0) + NVL(A.TDD_PRDN_QTY3, 0) AS DAY3_PLAN_QTY1,
			   				  	              B.PLNT_NM
	   	                               FROM TB_PLNT_APS_PROD_SUM_INFO A,
								            TB_PLNT_VEHL_MGMT B
                                       WHERE A.APL_YMD(+) = P_CURR_YMD
								 	   AND A.QLTY_VEHL_CD(+) = P_VEHL_CD
								 	   AND A.MDL_MDY_CD(+) = P_MDL_MDY_CD
								 	   AND A.LANG_CD(+) = P_LANG_CD
								 	   AND A.QLTY_VEHL_CD(+) = B.QLTY_VEHL_CD
								 	   AND A.PRDN_PLNT_CD(+) = B.PRDN_PLNT_CD
								 	   ORDER BY B.SORT_SN
									  )
								  --값이 없는 항목도 표시하도록 한다. 
								  --WHERE DAY3_PLAN_QTY1 > 0
								  ;
								 
		V_DAY3_LIST VARCHAR2(8000);
		V_FLAG      CHAR(1);
		
	  BEGIN
	  	   
		   --[주의] 2010.05.11.김동근 TB_PLNT_APS_PROD_SUM_INFO 테이블에 공장별 데이터가 하나도 존재하지 않는 차종의 경우(예를 들어 AM 차종의 11MY, PE 언어에 해당하는 광주 1, 2공장 내역이 아예 존재하지 않는는 경우)에는
		   --                         TB_PLNT_VEHL_MGMT 테이블에 지정되어 있다고 하더라도 화면에서 보여지지 않게 된다.('0' 으로 표시됨) 
		   --						  그래서 통일성을 주기 위하여 계획수량이 없는(각 공장 모두 '0' 인) 경우에는 빈문자로 표시되도록 한다.
		   V_DAY3_LIST := '';
		   V_FLAG      := '0';
		   
		   FOR PLAN_LIST IN DAY3_PLAN_LIST LOOP
			   
			   IF PLAN_LIST.DAY3_PLAN_QTY1 <> '0' THEN
			   	  
				  V_FLAG := '1';
				  
			   END IF;
			   
		   	   --V_DAY3_LIST := V_DAY3_LIST || PLAN_LIST.PLNT_NM || ': ' || PLAN_LIST.DAY3_PLAN_QTY1 || '|';
               IF PLAN_LIST.QLTY_VEHL_CD = P_VEHL_CD THEN
			       V_DAY3_LIST := V_DAY3_LIST || PLAN_LIST.DAY3_PLAN_QTY1 || '/';
               END IF;
			
		   END LOOP;
		   
		   IF V_FLAG = '0' THEN
		   	  
			  V_DAY3_LIST := '';
			  
		   ELSE
		   	   
			   IF LENGTH(V_DAY3_LIST) > 0 THEN
		   
		   	   	  V_DAY3_LIST := SUBSTR(V_DAY3_LIST, 1, LENGTH(V_DAY3_LIST) - 1);
		   
		   	   END IF;
		   
		   END IF;
		   
		   RETURN V_DAY3_LIST;
		
	  END FU_GET_PLNT_DAY3_PLAN_QTY;					 
	  				  											 							 					 		 				   					
END PG_TOT_IV_INFO;