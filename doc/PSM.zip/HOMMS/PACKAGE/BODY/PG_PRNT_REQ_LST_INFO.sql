CREATE OR REPLACE PACKAGE BODY PG_PRNT_REQ_LST_INFO AS
	   
	   --제작의뢰 내역 조회 
	   PROCEDURE SP_GET_PRNT_REQ_INFO(P_MENU_ID 	   VARCHAR2,
                                          P_USER_EENO      VARCHAR2,
                                          P_PAC_SCN_CD	   VARCHAR2,
                                          P_VEHL_CD	   VARCHAR2,
                                          P_MDL_MDY_CD     VARCHAR2,
                                          P_REGN_CD        VARCHAR2,
                                          P_LANG_CD	   VARCHAR2,
                                          P_N_PRNT_PBCN_NO VARCHAR2,
                                          P_FROM_YMD	   VARCHAR2,
                                          P_TO_YMD	   VARCHAR2,
                                          P_CRGR_EENO      VARCHAR2,
                                          P_REQ_STATE	   VARCHAR2,
                                          --P_FROM_NUM NUMBER,
                                          --P_TO_NUM   NUMBER,
                                          --P_CNT OUT NUMBER, 
                                          RS    OUT REFCUR)
	  IS
	  	
		V_FROM_MDL_MDY VARCHAR(2);
	 	V_TO_MDL_MDY   VARCHAR(2);
		
		--V_END_NUM      NUMBER;
		
		V_CRGR_EENO    VARCHAR2(7);
		
	  BEGIN
	  	   
		   V_CRGR_EENO := PG_COMMON.FU_RPAD(P_CRGR_EENO, 7);
		   
		   PG_COMMON.SP_GET_VALID_MDL_MDY4(P_FROM_YMD, P_TO_YMD, V_FROM_MDL_MDY, V_TO_MDL_MDY);
		   
		   /**
		   WITH T AS (SELECT C.QLTY_VEHL_CD,
                             C.MDL_MDY_CD,
                             C.LANG_CD
                      FROM (SELECT QLTY_VEHL_CD
                            FROM TB_AUTH_VEHL_MGMT
                            WHERE MENU_ID = PG_COMMON.FU_RPAD(P_MENU_ID, 10)
                            AND USER_EENO = PG_COMMON.FU_RPAD(P_USER_EENO, 7)
                            AND QLTY_VEHL_CD = DECODE(P_VEHL_CD, 'ALL', QLTY_VEHL_CD, P_VEHL_CD)
                            GROUP BY QLTY_VEHL_CD
                           ) A,
                           TB_VEHL_MGMT B,
                           TB_LANG_MGMT C
                      WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
                      AND A.QLTY_VEHL_CD = C.QLTY_VEHL_CD
                      AND B.MDL_MDY_CD = C.MDL_MDY_CD
                      AND B.MDL_MDY_CD BETWEEN V_FROM_MDL_MDY AND V_TO_MDL_MDY
                      AND B.MDL_MDY_CD = DECODE(P_MDL_MDY_CD , '', B.MDL_MDY_CD, P_MDL_MDY_CD)
					  AND B.DL_EXPD_PAC_SCN_CD = DECODE(P_PAC_SCN_CD, 'ALL', B.DL_EXPD_PAC_SCN_CD, P_PAC_SCN_CD)
					  AND C.DL_EXPD_REGN_CD = DECODE(P_REGN_CD, 'ALL', C.DL_EXPD_REGN_CD, P_REGN_CD)
                      AND C.LANG_CD = DECODE(P_LANG_CD, 'ALL', C.LANG_CD, P_LANG_CD)
					 )
		   SELECT COUNT(*)
		   INTO P_CNT
		   FROM T A,
			    TB_PRNT_REQ_INFO B,
				TB_PRNT_BKGD_INFO C
		   WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
		   AND A.MDL_MDY_CD = B.MDL_MDY_CD
		   AND A.LANG_CD = B.LANG_CD
		   AND A.QLTY_VEHL_CD = C.QLTY_VEHL_CD
		   AND A.MDL_MDY_CD = C.MDL_MDY_CD
		   AND A.LANG_CD = C.LANG_CD
		   AND B.N_PRNT_PBCN_NO = C.N_PRNT_PBCN_NO
		   AND B.N_PRNT_PBCN_NO = DECODE(P_N_PRNT_PBCN_NO, '', B.N_PRNT_PBCN_NO, P_N_PRNT_PBCN_NO)
		   AND B.ORDN_RQST_YMD BETWEEN P_FROM_YMD AND P_TO_YMD
		   AND B.CSET_CRGR_EENO = DECODE(P_CSET_CRGR_EENO, '', B.CSET_CRGR_EENO, P_CSET_CRGR_EENO)
		   AND C.DL_EXPD_RDCS_ST_CD = DECODE(P_REQ_STATE, 'ALL', C.DL_EXPD_RDCS_ST_CD, P_REQ_STATE);
		   
		   IF P_TO_NUM > P_CNT THEN
		   	  
			  V_END_NUM := P_CNT;
			  
		   ELSE
		      
			  V_END_NUM := P_TO_NUM;
			  
		   END IF;
		   
		   **/
		   
		   OPEN RS FOR
		   		WITH T AS (SELECT A.CL_SCN_CD,
			  		          	  C.QLTY_VEHL_CD,
                                  C.MDL_MDY_CD,
								  C.LANG_CD,
								  '(' || C.QLTY_VEHL_CD || ')' || B.QLTY_VEHL_NM AS QLTY_VEHL_NM,
								  C.MDL_MDY_CD || 'MY' AS MDL_MDY_NM,
								  C.LANG_CD_NM,
						  		  B.DL_EXPD_PAC_SCN_CD,
								  C.DL_EXPD_REGN_CD
                           FROM (SELECT QLTY_VEHL_CD,
                                        MAX(CL_SCN_CD) AS CL_SCN_CD
                                 FROM TB_AUTH_VEHL_MGMT
                                 WHERE MENU_ID = PG_COMMON.FU_RPAD(P_MENU_ID, 10)
                                 AND USER_EENO = PG_COMMON.FU_RPAD(P_USER_EENO, 7)
                                 AND QLTY_VEHL_CD = DECODE(P_VEHL_CD, 'ALL', QLTY_VEHL_CD, P_VEHL_CD)
                                 GROUP BY QLTY_VEHL_CD
                                ) A,
                                TB_VEHL_MGMT B,
                                TB_LANG_MGMT C
                           WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
                           AND A.QLTY_VEHL_CD = C.QLTY_VEHL_CD
                           AND B.MDL_MDY_CD = C.MDL_MDY_CD
                           AND B.MDL_MDY_CD BETWEEN V_FROM_MDL_MDY AND V_TO_MDL_MDY
                           AND B.MDL_MDY_CD = DECODE(P_MDL_MDY_CD , '', B.MDL_MDY_CD, P_MDL_MDY_CD)
						   AND B.DL_EXPD_PAC_SCN_CD = DECODE(P_PAC_SCN_CD, 'ALL', B.DL_EXPD_PAC_SCN_CD, P_PAC_SCN_CD)
						   AND C.DL_EXPD_REGN_CD = DECODE(P_REGN_CD, 'ALL', C.DL_EXPD_REGN_CD, P_REGN_CD)
                           AND C.LANG_CD = DECODE(P_LANG_CD, 'ALL', C.LANG_CD, P_LANG_CD)
						   AND B.USE_YN = 'Y'
                           --2013.01.25 임용석 : 제작의뢰리스트 조회 시 이전 자료의 경우 언어 사용여부가 N으로 설정되어있는 경우
                           --                    조회되지 않아, 제작의뢰리스트 조회에서는 언어 사용여부 체크 해제함.
                           --                    최재규 차장 요청 사항
						   --AND C.USE_YN = 'Y'
					      )
		   		SELECT E.DL_EXPD_PRVS_NM AS EXPD_PAC_SCN_NM, --승상구분
				       D.MDL_MDY_NM,
                       D.QLTY_VEHL_NM,
					   F.DL_EXPD_PRVS_NM AS EXPD_REGN_NM,    --지역
					   F.DL_EXPD_PRVS_CD AS EXPD_REGN_CD,    --지역코드                                          
					   D.LANG_CD_NM,
					   --TO_CHAR(TO_DATE(B.ORDN_RQST_YMD, 'YYYYMMDD'), 'YYYY-MM-DD') AS ORDN_RQST_YMD,
					   TO_CHAR(TO_DATE(B.PRNT_PARR_YMD, 'YYYYMMDD'), 'YYYY-MM-DD') AS ORDN_RQST_YMD,
					   TO_CHAR(TO_DATE(B.DLVG_PARR_YMD, 'YYYYMMDD'), 'YYYY-MM-DD') AS DLVG_PARR_YMD,
					   B.PRNT_PARR_QTY,
					   H.USER_NM,
					   G.DL_EXPD_PRVS_NM || ':' || TO_CHAR(TO_DATE(C.TRTM_YMD, 'YYYYMMDD'), 'YYYY-MM-DD') AS TRTM_RST,
					   G.DL_EXPD_PRVS_CD,
					   A.QLTY_VEHL_CD,
					   A.MDL_MDY_CD,
					   A.LANG_CD,
					   A.N_PRNT_PBCN_NO,
					   B.OLD_PRNT_PBCN_NO,
				       CASE WHEN D.CL_SCN_CD = 'U' AND C.DL_EXPD_RDCS_ST_CD IN ('01', '04') THEN 'Y' ELSE 'N' END AS CL_SCN_CD,
					   I.DL_EXPD_PRVS_NM AS PRNT_WAY_NM,
					   J.DL_EXPD_PRVS_NM AS PRNT_WAY_NM2,
					   K.DL_EXPD_PRVS_NM AS DEPQ1_NM
				FROM (--페이징처리를 위하여 추가된 부분임.
					  SELECT N_PRNT_PBCN_NO,
					         QLTY_VEHL_CD,
                             MDL_MDY_CD,
                             LANG_CD
				      FROM (SELECT N_PRNT_PBCN_NO,
					  	   		   QLTY_VEHL_CD,
                                   MDL_MDY_CD,
                                   LANG_CD,
					  		       ROWNUM AS ROWNM
							FROM (SELECT B.N_PRNT_PBCN_NO,
                                         A.QLTY_VEHL_CD,
                                         A.MDL_MDY_CD,
                                         A.LANG_CD
				                  FROM T A,
					  	               TB_PRNT_REQ_INFO B,
						               TB_PRNT_BKGD_INFO C
					              WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
					        	  AND A.MDL_MDY_CD = B.MDL_MDY_CD
					        	  AND A.LANG_CD = B.LANG_CD
					        	  AND A.QLTY_VEHL_CD = C.QLTY_VEHL_CD
					        	  AND A.MDL_MDY_CD = C.MDL_MDY_CD
					        	  AND A.LANG_CD = C.LANG_CD
					        	  AND B.N_PRNT_PBCN_NO = C.N_PRNT_PBCN_NO
					        	  AND B.N_PRNT_PBCN_NO = DECODE(P_N_PRNT_PBCN_NO, '', B.N_PRNT_PBCN_NO, P_N_PRNT_PBCN_NO)
					        	  AND B.ORDN_RQST_YMD BETWEEN P_FROM_YMD AND P_TO_YMD
					        	  AND B.CRGR_EENO = DECODE(V_CRGR_EENO, '', B.CRGR_EENO, V_CRGR_EENO)
					        	  AND C.DL_EXPD_RDCS_ST_CD = DECODE(P_REQ_STATE, 'ALL', C.DL_EXPD_RDCS_ST_CD, P_REQ_STATE)
								  ORDER BY CASE WHEN C.DL_EXPD_RDCS_ST_CD IN ('01', '04') THEN 1 
								                WHEN C.DL_EXPD_RDCS_ST_CD = '02' THEN 2
												WHEN C.DL_EXPD_RDCS_ST_CD = '03' THEN 3
												ELSE 4
										   END, C.TRTM_YMD DESC
								 )
						   )
					   --WHERE ROWNM BETWEEN P_FROM_NUM AND V_END_NUM 
					  ) A,
					  TB_PRNT_REQ_INFO B,
				      TB_PRNT_BKGD_INFO C,
					  T D,
					  TB_CODE_MGMT E,
					  TB_CODE_MGMT F,
					  TB_CODE_MGMT G,                                        
					  TB_USR_MGMT H,
					  TB_CODE_MGMT I,
					  TB_CODE_MGMT J,
					  TB_CODE_MGMT K
				 WHERE A.N_PRNT_PBCN_NO = B.N_PRNT_PBCN_NO
				 AND A.N_PRNT_PBCN_NO = C.N_PRNT_PBCN_NO
				 AND A.QLTY_VEHL_CD = D.QLTY_VEHL_CD
				 AND A.MDL_MDY_CD = D.MDL_MDY_CD
				 AND A.LANG_CD = D.LANG_CD
				 AND D.DL_EXPD_PAC_SCN_CD = E.DL_EXPD_PRVS_CD
				 AND E.DL_EXPD_G_CD = '0004'
				 AND D.DL_EXPD_REGN_CD = F.DL_EXPD_PRVS_CD                                                           
			         AND F.DL_EXPD_G_CD = '0008'
				 AND C.DL_EXPD_RDCS_ST_CD = G.DL_EXPD_PRVS_CD
				 AND G.DL_EXPD_G_CD = '0009'
				 AND B.CRGR_EENO = H.USER_EENO(+)
				 AND I.DL_EXPD_G_CD = '0025'
				 AND B.PRNT_WAY_CD = I.DL_EXPD_PRVS_CD
				 AND J.DL_EXPD_G_CD = '0029'
				 AND B.PRNT_WAY_CD2 = J.DL_EXPD_PRVS_CD
				 AND K.DL_EXPD_G_CD = '0026'
				 AND B.DEPQ1_CD = K.DL_EXPD_PRVS_CD
				 ORDER BY CASE WHEN C.DL_EXPD_RDCS_ST_CD IN ('01', '04') THEN 1 
							   WHEN C.DL_EXPD_RDCS_ST_CD = '02' THEN 2
							   WHEN C.DL_EXPD_RDCS_ST_CD = '03' THEN 3
						       ELSE 4
						  END, C.TRTM_YMD DESC;
				
	  END SP_GET_PRNT_REQ_INFO;
	  
END PG_PRNT_REQ_LST_INFO;