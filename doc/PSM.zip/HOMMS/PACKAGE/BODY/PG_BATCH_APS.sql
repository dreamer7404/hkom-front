CREATE OR REPLACE PACKAGE BODY PG_BATCH_APS AS

/**********************************************************/    
       PROCEDURE SP_BATCH_APS 
       IS
            
       BEGIN
                PG_INTERFACE_APS.APS_INTERFACE_HMC; 
                
       END SP_BATCH_APS;

END PG_BATCH_APS;