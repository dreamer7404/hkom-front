CREATE OR REPLACE PACKAGE BODY HOMMS_ADM.PG_USR_LOGIN AS

	   -- 사용자별 로그인
       PROCEDURE SP_USR_LOGIN(P_USER_EENO IN TB_USR_MGMT.USER_EENO%TYPE,
       						  P_USER_PW IN TB_USR_MGMT.USER_PW%TYPE,
                              RS OUT REFCUR)
       AS
       BEGIN
	   
     	OPEN RS FOR SELECT A.USER_EENO,
                           A.USER_PW, 
                           A.USER_NM,
						   A.BLNS_CO_CD,
						   B.DL_EXPD_PRVS_NM AS BLNS_CO_NM,
                           A.USER_DCD,
						   C.DL_EXPD_PRVS_NM AS USER_DCD_NM
                    FROM TB_USR_MGMT A,
						 TB_CODE_MGMT B,
						 TB_CODE_MGMT C
                    WHERE A.USER_EENO = PG_COMMON.FU_RPAD(P_USER_EENO, 7)
                    AND A.USER_PW = FU_GET_PASSWORD(PG_COMMON.FU_RPAD(P_USER_EENO, 7), P_USER_PW)
			        AND A.USE_YN = 'Y'
					AND A.BLNS_CO_CD = B.DL_EXPD_PRVS_CD
					AND B.DL_EXPD_G_CD = '0001'
					AND A.USER_DCD = C.DL_EXPD_PRVS_CD
					AND C.DL_EXPD_G_CD = '0011';
			 
       END SP_USR_LOGIN;
  
	   -- 사용자별 로그인
       PROCEDURE SP_USR_LOGIN_N(P_USER_EENO IN TB_USR_MGMT.USER_EENO%TYPE,
       						  P_USER_PW IN TB_USR_MGMT.USER_PW%TYPE,
                              P_USER_SHA_PWD IN TB_USR_MGMT.USER_PW%TYPE,
                              P_USER_IP_ADR IN VARCHAR2,
                              P_USER_HOST IN VARCHAR2,
                              RS OUT REFCUR)
       AS
       V_CNT		    NUMBER;
       V_USER_PW	    VARCHAR2(10);
       V_USER_SHA_PWD   VARCHAR2(128);
       V_IN_PWD         VARCHAR2(128);      -- 입력된 비밀번호
       V_SRC_PWD        VARCHAR2(128);      -- 디비에 저장된 비밀번호
       V_LOCK_CNT       VARCHAR2(10);
       V_PW_ERR_OFT	    NUMBER;
       V_FIN_LGI_DAY_CNT	NUMBER;
       V_USE_YN		    CHAR(1);
       BEGIN
       
       	-- 로그인 시도 ID가 존재하는 지 여부 체크
       	SELECT NVL(COUNT(USER_EENO), 0)
        	INTO V_CNT
        FROM TB_USR_MGMT A
        WHERE A.USER_EENO = PG_COMMON.FU_RPAD(P_USER_EENO, 7);
        
        -- ID가 존재하는 경우
        IF V_CNT > 0 THEN
        	-- 1. 비밀번호, 오류회수, 사용여부 체크
            SELECT TRIM(USER_PW), PW_ERR_OFT, USE_YN, ROUND(SYSDATE - FIN_LGI_DTM), TO_CHAR(SYSDATE, 'YYYYMMDDHH24MI') - TO_CHAR(PW_LOCK_DTM, 'YYYYMMDDHH24MI')
            	INTO V_USER_PW, V_PW_ERR_OFT, V_USE_YN, V_FIN_LGI_DAY_CNT, V_LOCK_CNT
            FROM TB_USR_MGMT
            WHERE USER_EENO = PG_COMMON.FU_RPAD(P_USER_EENO, 7);
            
            -- 1.1 기존 HASHED PWD나 SHA PWD가 모두 NULL 인 경우 잘못된 경우임.
            IF V_USER_PW IS NULL AND V_USER_SHA_PWD IS NULL THEN
                -- 1.2 로그인 이력에 로그인 실패 기록
                INSERT INTO TB_LGI_LOG
                (LGI_LOG_SN, USER_ID, LGI_DTM, SUCS_YN, USER_IP_ADR, ID_EXIST_YN)
                VALUES
                (LGI_LOG_SQ.NEXTVAL, P_USER_EENO, SYSDATE, 'N', P_USER_IP_ADR, 'Y');
            ELSE
                -- 2. 비밀번호가 맞지 않는 경우
                IF V_USER_SHA_PWD IS NULL THEN
                    V_IN_PWD  := FU_GET_PASSWORD(PG_COMMON.FU_RPAD(P_USER_EENO, 7), P_USER_PW);
                    V_SRC_PWD := V_USER_PW;
                ELSE
                    V_IN_PWD  := P_USER_SHA_PWD;
                    V_SRC_PWD := V_USER_SHA_PWD;
                END IF;
                IF V_IN_PWD <> V_SRC_PWD THEN
                -- 2. 비밀번호가 맞지 않는 경우
                /** IF V_USER_PW <> FU_GET_PASSWORD(PG_COMMON.FU_RPAD(P_USER_EENO, 7), P_USER_PW) THEN **/
                    -- 2.1 비밀번호 오입력 회수 5회 이상인 경우 사용자 계정 LOCK 처리
                    IF V_PW_ERR_OFT +1 >= 5 THEN
                        UPDATE TB_USR_MGMT
                        SET PW_ERR_OFT = PW_ERR_OFT + 1,
                            PW_LOCK_DTM = SYSDATE
                        WHERE USER_EENO = PG_COMMON.FU_RPAD(P_USER_EENO, 7);
                    -- 2.2 비밀번호 오입력 회수 기록
                    ELSE
                        UPDATE TB_USR_MGMT
                        SET PW_ERR_OFT = PW_ERR_OFT + 1
                        WHERE USER_EENO = PG_COMMON.FU_RPAD(P_USER_EENO, 7);
                    END IF;

                    -- 2.3 로그인 이력에 로그인 실패 기록
                    INSERT INTO TB_LGI_LOG
                    (LGI_LOG_SN, USER_ID, LGI_DTM, SUCS_YN, USER_IP_ADR, ID_EXIST_YN)
                    VALUES
                    (LGI_LOG_SQ.NEXTVAL, P_USER_EENO, SYSDATE, 'N', P_USER_IP_ADR, 'Y');
                -- 3. 비밀번호 맞는 경우
                ELSE
                    -- 3.1 사용계정인 경우
                    IF V_USE_YN = 'Y' AND V_FIN_LGI_DAY_CNT <= 90 AND (V_LOCK_CNT IS NULL OR V_LOCK_CNT > '100') THEN
                        -- 3.1.1 사용자 정보에 최종 로그인 시간 기록 및 비밀번호 오류 회수, 비밀번호 잠김 시간 초기화
                        UPDATE TB_USR_MGMT
                        SET PW_ERR_OFT = 0,
                            FIN_LGI_DTM = SYSDATE,
                            PW_LOCK_DTM = ''
                        WHERE USER_EENO = PG_COMMON.FU_RPAD(P_USER_EENO, 7);

                        -- 3.1.2 로그인 이력에 로그인 성공 기록
                        INSERT INTO TB_LGI_LOG
                        (LGI_LOG_SN, USER_ID, LGI_DTM, SUCS_YN, USER_IP_ADR, ID_EXIST_YN)
                        VALUES
                        (LGI_LOG_SQ.NEXTVAL, P_USER_EENO, SYSDATE, 'Y', P_USER_IP_ADR, 'Y');
                    -- 3.2 미사용, LOCK 된 계정인 경우
                    ELSE
                        -- 3.2.1 로그인 이력에 로그인 실패만 기록
                        INSERT INTO TB_LGI_LOG
                        (LGI_LOG_SN, USER_ID, LGI_DTM, SUCS_YN, USER_IP_ADR, ID_EXIST_YN)
                        VALUES
                        (LGI_LOG_SQ.NEXTVAL, P_USER_EENO, SYSDATE, 'N', P_USER_IP_ADR, 'Y');
                    END IF;
                END IF;
            END IF;
            
        -- ID가 존재하지 않는 경우
        ELSE
        	INSERT INTO TB_LGI_LOG
            (LGI_LOG_SN, USER_ID, LGI_DTM, SUCS_YN, USER_IP_ADR, ID_EXIST_YN)
            VALUES
            (LGI_LOG_SQ.NEXTVAL, P_USER_EENO, SYSDATE, 'N', P_USER_IP_ADR, 'N');
        END IF;
        
        COMMIT;

     	OPEN RS FOR SELECT A.USER_EENO,
                           TRIM(A.USER_PW) USER_PW, 
                           A.USER_NM,
						   A.BLNS_CO_CD,
						   B.DL_EXPD_PRVS_NM AS BLNS_CO_NM,
                           A.USER_DCD,
						   C.DL_EXPD_PRVS_NM AS USER_DCD_NM,
        				   A.USE_YN,
                           TO_CHAR(SYSDATE, 'YYYYMMDDHH24MI') - TO_CHAR(A.PW_LOCK_DTM, 'YYYYMMDDHH24MI') PW_LOCK_TIME,
                           ROUND(SYSDATE - A.PW_ALTR_DTM) PW_ALTR_DAY_CNT,
                           ROUND(SYSDATE - A.FIN_LGI_DTM) FIN_LGI_DAY_CNT,
                           A.PW_ERR_OFT,
                           A.USER_CHG_PW
                    FROM TB_USR_MGMT A,
						 TB_CODE_MGMT B,
						 TB_CODE_MGMT C
                    WHERE A.USER_EENO = PG_COMMON.FU_RPAD(P_USER_EENO, 7)
                    --AND A.USER_PW = FU_GET_PASSWORD(PG_COMMON.FU_RPAD(P_USER_EENO, 7), P_USER_PW)
			        --AND A.USE_YN = 'Y'
					AND A.BLNS_CO_CD = B.DL_EXPD_PRVS_CD
					AND B.DL_EXPD_G_CD = '0001'
					AND A.USER_DCD = C.DL_EXPD_PRVS_CD
					AND C.DL_EXPD_G_CD = '0011';

       END SP_USR_LOGIN_N;
       
       -- 사용자별 로그인
       PROCEDURE SP_USR_LOGIN_N2(P_USER_EENO IN TB_USR_MGMT.USER_EENO%TYPE,
                                 P_USER_PW IN TB_USR_MGMT.USER_PW%TYPE,
                              P_USER_SHA_PWD IN TB_USR_MGMT.USER_PW%TYPE,
                              P_USER_IP_ADR IN VARCHAR2,
                              P_USER_HOST IN VARCHAR2,
                              RS OUT REFCUR)
       AS
       V_CNT            NUMBER;
       V_USER_PW        VARCHAR2(10);
       V_USER_SHA_PWD   VARCHAR2(128);
       V_IN_PWD         VARCHAR2(128);      -- 입력된 비밀번호
       V_SRC_PWD        VARCHAR2(128);      -- 디비에 저장된 비밀번호
       V_LOCK_CNT       VARCHAR2(10);
       V_PW_ERR_OFT        NUMBER;
       V_FIN_LGI_DAY_CNT    NUMBER;
       V_USE_YN            CHAR(1);
       BEGIN
       
           -- 로그인 시도 ID가 존재하는 지 여부 체크
           SELECT NVL(COUNT(USER_EENO), 0)
            INTO V_CNT
        FROM TB_USR_MGMT A
        WHERE A.USER_EENO = PG_COMMON.FU_RPAD(P_USER_EENO, 7);
        
        -- ID가 존재하는 경우
        IF V_CNT > 0 THEN
            -- 1. 비밀번호, 오류회수, 사용여부 체크
            SELECT TRIM(USER_PW), PW_ERR_OFT, USE_YN, ROUND(SYSDATE - FIN_LGI_DTM), TO_CHAR(SYSDATE, 'YYYYMMDDHH24MI') - TO_CHAR(PW_LOCK_DTM, 'YYYYMMDDHH24MI')
                INTO V_USER_PW, V_PW_ERR_OFT, V_USE_YN, V_FIN_LGI_DAY_CNT, V_LOCK_CNT
            FROM TB_USR_MGMT
            WHERE USER_EENO = PG_COMMON.FU_RPAD(P_USER_EENO, 7);
            
            -- 1.1 기존 HASHED PWD나 SHA PWD가 모두 NULL 인 경우 잘못된 경우임.
            IF V_USER_PW IS NULL AND V_USER_SHA_PWD IS NULL THEN
                -- 1.2 로그인 이력에 로그인 실패 기록
                INSERT INTO TB_LGI_LOG
                (LGI_LOG_SN, USER_ID, LGI_DTM, SUCS_YN, USER_IP_ADR, ID_EXIST_YN)
                VALUES
                (LGI_LOG_SQ.NEXTVAL, P_USER_EENO, SYSDATE, 'N', P_USER_IP_ADR, 'Y');
            ELSE
                -- 2. 비밀번호가 맞지 않는 경우
                IF V_USER_SHA_PWD IS NULL THEN
                    V_IN_PWD  := FU_GET_PASSWORD(PG_COMMON.FU_RPAD(P_USER_EENO, 7), P_USER_PW);
                    V_SRC_PWD := V_USER_PW;
                ELSE
                    V_IN_PWD  := FU_MD5(P_USER_PW);
                    V_SRC_PWD := V_USER_SHA_PWD;
                END IF;
                -- 2. 비밀번호가 맞지 않는 경우
                IF V_IN_PWD <> V_SRC_PWD THEN
                /** IF V_USER_PW <> FU_GET_PASSWORD(PG_COMMON.FU_RPAD(P_USER_EENO, 7), P_USER_PW) THEN **/
                    -- 2.1 비밀번호 오입력 회수 5회 이상인 경우 사용자 계정 LOCK 처리
                    IF V_PW_ERR_OFT +1 >= 5 THEN
                        UPDATE TB_USR_MGMT
                        SET PW_ERR_OFT = PW_ERR_OFT + 1,
                            PW_LOCK_DTM = SYSDATE
                        WHERE USER_EENO = PG_COMMON.FU_RPAD(P_USER_EENO, 7);
                    -- 2.2 비밀번호 오입력 회수 기록
                    ELSE
                        UPDATE TB_USR_MGMT
                        SET PW_ERR_OFT = PW_ERR_OFT + 1
                        WHERE USER_EENO = PG_COMMON.FU_RPAD(P_USER_EENO, 7);
                    END IF;

                    -- 2.3 로그인 이력에 로그인 실패 기록
                    INSERT INTO TB_LGI_LOG
                    (LGI_LOG_SN, USER_ID, LGI_DTM, SUCS_YN, USER_IP_ADR, ID_EXIST_YN)
                    VALUES
                    (LGI_LOG_SQ.NEXTVAL, P_USER_EENO, SYSDATE, 'N', P_USER_IP_ADR, 'Y');
                -- 3. 비밀번호 맞는 경우
                ELSE
                    -- 3.1 사용계정인 경우
                    IF V_USE_YN = 'Y' AND V_FIN_LGI_DAY_CNT <= 90 AND (V_LOCK_CNT IS NULL OR V_LOCK_CNT > '100') THEN
                        -- 3.1.1 사용자 정보에 최종 로그인 시간 기록 및 비밀번호 오류 회수, 비밀번호 잠김 시간 초기화
                        UPDATE TB_USR_MGMT
                        SET PW_ERR_OFT = 0,
                            FIN_LGI_DTM = SYSDATE,
                            PW_LOCK_DTM = ''
                        WHERE USER_EENO = PG_COMMON.FU_RPAD(P_USER_EENO, 7);

                        -- 3.1.2 로그인 이력에 로그인 성공 기록
                        INSERT INTO TB_LGI_LOG
                        (LGI_LOG_SN, USER_ID, LGI_DTM, SUCS_YN, USER_IP_ADR, ID_EXIST_YN)
                        VALUES
                        (LGI_LOG_SQ.NEXTVAL, P_USER_EENO, SYSDATE, 'Y', P_USER_IP_ADR, 'Y');
                    -- 3.2 미사용, LOCK 된 계정인 경우
                    ELSE
                        -- 3.2.1 로그인 이력에 로그인 실패만 기록
                        INSERT INTO TB_LGI_LOG
                        (LGI_LOG_SN, USER_ID, LGI_DTM, SUCS_YN, USER_IP_ADR, ID_EXIST_YN)
                        VALUES
                        (LGI_LOG_SQ.NEXTVAL, P_USER_EENO, SYSDATE, 'N', P_USER_IP_ADR, 'Y');
                    END IF;
                END IF;
            END IF;
            
        -- ID가 존재하지 않는 경우
        ELSE
            INSERT INTO TB_LGI_LOG
            (LGI_LOG_SN, USER_ID, LGI_DTM, SUCS_YN, USER_IP_ADR, ID_EXIST_YN)
            VALUES
            (LGI_LOG_SQ.NEXTVAL, P_USER_EENO, SYSDATE, 'N', P_USER_IP_ADR, 'N');
        END IF;
        
        COMMIT;

         OPEN RS FOR SELECT A.USER_EENO,
                           TRIM(A.USER_PW) USER_PW, 
                           A.USER_NM,
                           A.BLNS_CO_CD,
                           B.DL_EXPD_PRVS_NM AS BLNS_CO_NM,
                           A.USER_DCD,
                           C.DL_EXPD_PRVS_NM AS USER_DCD_NM,
                           A.USE_YN,
                           TO_CHAR(SYSDATE, 'YYYYMMDDHH24MI') - TO_CHAR(A.PW_LOCK_DTM, 'YYYYMMDDHH24MI') PW_LOCK_TIME,
                           ROUND(SYSDATE - A.PW_ALTR_DTM) PW_ALTR_DAY_CNT,
                           ROUND(SYSDATE - A.FIN_LGI_DTM) FIN_LGI_DAY_CNT,
                           A.PW_ERR_OFT,
                           A.USER_CHG_PW
                    FROM TB_USR_MGMT A,
                         TB_CODE_MGMT B,
                         TB_CODE_MGMT C
                    WHERE A.USER_EENO = PG_COMMON.FU_RPAD(P_USER_EENO, 7)
                    --AND A.USER_PW = FU_GET_PASSWORD(PG_COMMON.FU_RPAD(P_USER_EENO, 7), P_USER_PW)
                    --AND A.USE_YN = 'Y'
                    AND A.BLNS_CO_CD = B.DL_EXPD_PRVS_CD
                    AND B.DL_EXPD_G_CD = '0001'
                    AND A.USER_DCD = C.DL_EXPD_PRVS_CD
                    AND C.DL_EXPD_G_CD = '0011';

       END SP_USR_LOGIN_N2;

       -- 사용자별 로그인
       PROCEDURE SP_USR_LOGIN_N3(P_USER_EENO    IN TB_USR_MGMT.USER_EENO%TYPE,
                                 P_USER_PW      IN TB_USR_MGMT.USER_PW%TYPE,
                                 P_USER_SHA_PWD IN TB_USR_MGMT.USER_PW%TYPE,
                                 P_USER_IP_ADR  IN VARCHAR2,
                                 P_USER_HOST    IN VARCHAR2,
                                 P_SESS_ID      IN VARCHAR2,
                                 RS OUT REFCUR)
       AS
       V_CNT            NUMBER;
       V_USER_PW        VARCHAR2(10);
       V_USER_SHA_PWD   VARCHAR2(128);
       V_IN_PWD         VARCHAR2(128);      -- 입력된 비밀번호
       V_SRC_PWD        VARCHAR2(128);      -- 디비에 저장된 비밀번호
       V_LOCK_CNT       VARCHAR2(10);
       V_PW_ERR_OFT        NUMBER;
       V_FIN_LGI_DAY_CNT    NUMBER;
       V_USE_YN            CHAR(1);
       BEGIN
       
           -- 로그인 시도 ID가 존재하는 지 여부 체크
           SELECT NVL(COUNT(USER_EENO), 0)
            INTO V_CNT
        FROM TB_USR_MGMT A
        WHERE A.USER_EENO = PG_COMMON.FU_RPAD(P_USER_EENO, 7);
        
        -- ID가 존재하는 경우
        IF V_CNT > 0 THEN
            -- 1. 비밀번호, 오류회수, 사용여부 체크
            SELECT TRIM(USER_PW), PW_ERR_OFT, USE_YN, ROUND(SYSDATE - FIN_LGI_DTM), TO_CHAR(SYSDATE, 'YYYYMMDDHH24MI') - TO_CHAR(PW_LOCK_DTM, 'YYYYMMDDHH24MI')
                INTO V_USER_PW, V_PW_ERR_OFT, V_USE_YN, V_FIN_LGI_DAY_CNT, V_LOCK_CNT
            FROM TB_USR_MGMT
            WHERE USER_EENO = PG_COMMON.FU_RPAD(P_USER_EENO, 7);
            
            -- 1.1 기존 HASHED PWD나 SHA PWD가 모두 NULL 인 경우 잘못된 경우임.
            IF V_USER_PW IS NULL AND V_USER_SHA_PWD IS NULL THEN
                -- 1.2 로그인 이력에 로그인 실패 기록
                INSERT INTO TB_LGI_LOG
                (LGI_LOG_SN, USER_ID, LGI_DTM, SUCS_YN, USER_IP_ADR, ID_EXIST_YN, SESS_ID)
                VALUES
                (LGI_LOG_SQ.NEXTVAL, P_USER_EENO, SYSDATE, 'N', P_USER_IP_ADR, 'Y', P_SESS_ID);
            ELSE
                -- 2. 비밀번호가 맞지 않는 경우
                IF V_USER_SHA_PWD IS NULL THEN
                    V_IN_PWD  := FU_GET_PASSWORD(PG_COMMON.FU_RPAD(P_USER_EENO, 7), P_USER_PW);
                    V_SRC_PWD := V_USER_PW;
                ELSE
                    V_IN_PWD  := FU_MD5(P_USER_PW);
                    V_SRC_PWD := V_USER_SHA_PWD;
                END IF;
                -- 2. 비밀번호가 맞지 않는 경우
                IF V_IN_PWD <> V_SRC_PWD THEN
                /** IF V_USER_PW <> FU_GET_PASSWORD(PG_COMMON.FU_RPAD(P_USER_EENO, 7), P_USER_PW) THEN **/
                    -- 2.1 비밀번호 오입력 회수 5회 이상인 경우 사용자 계정 LOCK 처리
                    IF V_PW_ERR_OFT +1 >= 5 THEN
                        UPDATE TB_USR_MGMT
                        SET PW_ERR_OFT = PW_ERR_OFT + 1,
                            PW_LOCK_DTM = SYSDATE
                        WHERE USER_EENO = PG_COMMON.FU_RPAD(P_USER_EENO, 7);
                    -- 2.2 비밀번호 오입력 회수 기록
                    ELSE
                        UPDATE TB_USR_MGMT
                        SET PW_ERR_OFT = PW_ERR_OFT + 1
                        WHERE USER_EENO = PG_COMMON.FU_RPAD(P_USER_EENO, 7);
                    END IF;

                    -- 2.3 로그인 이력에 로그인 실패 기록
                    INSERT INTO TB_LGI_LOG
                    (LGI_LOG_SN, USER_ID, LGI_DTM, SUCS_YN, USER_IP_ADR, ID_EXIST_YN, SESS_ID)
                    VALUES
                    (LGI_LOG_SQ.NEXTVAL, P_USER_EENO, SYSDATE, 'N', P_USER_IP_ADR, 'Y', P_SESS_ID);
                -- 3. 비밀번호 맞는 경우
                ELSE
                    -- 3.1 사용계정인 경우
                    IF V_USE_YN = 'Y' AND V_FIN_LGI_DAY_CNT <= 90 AND (V_LOCK_CNT IS NULL OR V_LOCK_CNT > '100') THEN
                        -- 3.1.1 사용자 정보에 최종 로그인 시간 기록 및 비밀번호 오류 회수, 비밀번호 잠김 시간 초기화
                        UPDATE TB_USR_MGMT
                        SET PW_ERR_OFT = 0,
                            FIN_LGI_DTM = SYSDATE,
                            PW_LOCK_DTM = ''
                        WHERE USER_EENO = PG_COMMON.FU_RPAD(P_USER_EENO, 7);

                        -- 3.1.2 로그인 이력에 로그인 성공 기록
                        INSERT INTO TB_LGI_LOG
                        (LGI_LOG_SN, USER_ID, LGI_DTM, SUCS_YN, USER_IP_ADR, ID_EXIST_YN, SESS_ID)
                        VALUES
                        (LGI_LOG_SQ.NEXTVAL, P_USER_EENO, SYSDATE, 'Y', P_USER_IP_ADR, 'Y', P_SESS_ID);
                    -- 3.2 미사용, LOCK 된 계정인 경우
                    ELSE
                        -- 3.2.1 로그인 이력에 로그인 실패만 기록
                        INSERT INTO TB_LGI_LOG
                        (LGI_LOG_SN, USER_ID, LGI_DTM, SUCS_YN, USER_IP_ADR, ID_EXIST_YN, SESS_ID)
                        VALUES
                        (LGI_LOG_SQ.NEXTVAL, P_USER_EENO, SYSDATE, 'N', P_USER_IP_ADR, 'Y', P_SESS_ID);
                    END IF;
                END IF;
            END IF;
            
        -- ID가 존재하지 않는 경우
        ELSE
            INSERT INTO TB_LGI_LOG
            (LGI_LOG_SN, USER_ID, LGI_DTM, SUCS_YN, USER_IP_ADR, ID_EXIST_YN, SESS_ID)
            VALUES
            (LGI_LOG_SQ.NEXTVAL, P_USER_EENO, SYSDATE, 'N', P_USER_IP_ADR, 'N', P_SESS_ID);
        END IF;
        
        COMMIT;

         OPEN RS FOR SELECT A.USER_EENO,
                           TRIM(A.USER_PW) USER_PW, 
                           A.USER_NM,
                           A.BLNS_CO_CD,
                           B.DL_EXPD_PRVS_NM AS BLNS_CO_NM,
                           A.USER_DCD,
                           C.DL_EXPD_PRVS_NM AS USER_DCD_NM,
                           A.USE_YN,
                           TO_CHAR(SYSDATE, 'YYYYMMDDHH24MI') - TO_CHAR(A.PW_LOCK_DTM, 'YYYYMMDDHH24MI') PW_LOCK_TIME,
                           ROUND(SYSDATE - A.PW_ALTR_DTM) PW_ALTR_DAY_CNT,
                           ROUND(SYSDATE - A.FIN_LGI_DTM) FIN_LGI_DAY_CNT,
                           A.PW_ERR_OFT,
                           A.USER_CHG_PW
                    FROM TB_USR_MGMT A,
                         TB_CODE_MGMT B,
                         TB_CODE_MGMT C
                    WHERE A.USER_EENO = PG_COMMON.FU_RPAD(P_USER_EENO, 7)
                    --AND A.USER_PW = FU_GET_PASSWORD(PG_COMMON.FU_RPAD(P_USER_EENO, 7), P_USER_PW)
                    --AND A.USE_YN = 'Y'
                    AND A.BLNS_CO_CD = B.DL_EXPD_PRVS_CD
                    AND B.DL_EXPD_G_CD = '0001'
                    AND A.USER_DCD = C.DL_EXPD_PRVS_CD
                    AND C.DL_EXPD_G_CD = '0011';

       END SP_USR_LOGIN_N3;

       PROCEDURE SP_UPDATE_USR_USE_YN
       AS
       BEGIN
            UPDATE TB_USR_MGMT
            SET USE_YN = 'N',
                UPDR_EENO = 'SYSTEM',
                MDFY_DTM = SYSDATE
            WHERE USE_YN <> 'N'
                AND ROUND(SYSDATE - FIN_LGI_DTM) > 90;
       END SP_UPDATE_USR_USE_YN;

   -- 사용자 로그아웃 기록 추가
   PROCEDURE SP_USR_LOGOUT (
      P_SESS_ID        IN     VARCHAR2,
      P_LGO_TYPE       IN     TB_LGI_LOG.LGO_TYPE%TYPE)
   IS
   BEGIN
   
      UPDATE TB_LGI_LOG
      SET LGO_DTM = SYSDATE,
          LGO_TYPE = P_LGO_TYPE
      WHERE SESS_ID = P_SESS_ID
        AND LGO_DTM IS NULL
      ;

      COMMIT;


   END SP_USR_LOGOUT;

END PG_USR_LOGIN;