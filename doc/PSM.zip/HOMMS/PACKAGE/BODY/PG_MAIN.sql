CREATE OR REPLACE PACKAGE BODY PG_MAIN AS
       
       --업무현황 조회 
       PROCEDURE SP_GET_USR_BUSINESS_INFO(P_MENU_ID    VARCHAR2,
                                          P_USER_EENO  VARCHAR2,
                                          P_CURR_YMD   VARCHAR2,
                                          RS          OUT REFCUR)
       IS
            
         V_USER_DCD     VARCHAR2(8);
         
         V_FROM_MDL_MDY VARCHAR(2);
         V_TO_MDL_MDY   VARCHAR(2);
         
         V_USER_REQ_QTY NUMBER;
         V_DEPT_REQ_QTY NUMBER;
         
         V_USER_APVL_QTY NUMBER;
         V_DEPT_APVL_QTY NUMBER;
         
         V_USER_WHOT_QTY NUMBER;
         V_DEPT_WHOT_QTY NUMBER;
         
         V_USER_WHSN_QTY NUMBER;
         V_DEPT_WHSN_QTY NUMBER;
     
       BEGIN
               
            PG_COMMON.SP_GET_VALID_MDL_MDY4(P_CURR_YMD, '', V_FROM_MDL_MDY, V_TO_MDL_MDY);
            
            --사용자 부서코드를 얻어온다. 
            SELECT USER_DCD
            INTO V_USER_DCD
            FROM TB_USR_MGMT
            WHERE USER_EENO = PG_COMMON.FU_RPAD(P_USER_EENO, 7);
            
            --서비스기술정보팀인 경우 (발주의뢰, 발주승인)
            IF V_USER_DCD = '01' THEN
               
               SP_GET_REQ_PARR_INFO(P_MENU_ID,
                                    P_USER_EENO,
                                    V_USER_DCD,
                                    P_CURR_YMD,
                                    V_FROM_MDL_MDY,
                                    V_TO_MDL_MDY,
                                    V_USER_REQ_QTY,
                                    V_DEPT_REQ_QTY);
                                    
               SP_GET_REQ_APVL_INFO(P_USER_EENO,
                                    V_USER_DCD,
                                    P_CURR_YMD,
                                    V_FROM_MDL_MDY,
                                    V_TO_MDL_MDY,
                                    V_USER_APVL_QTY,
                                    V_DEPT_APVL_QTY);
                                      
               OPEN RS FOR
                     SELECT V_USER_REQ_QTY AS USER_REQ_PARR_QTY,   --사용자 발주의뢰 건수 
                            V_USER_APVL_QTY AS USER_REQ_APVL_QTY,  --사용자 발주승인 건수 
                            0 AS USER_WHOT_WHSN_QTY,               --사용자 입/출고관리 건수 
                            V_DEPT_REQ_QTY AS DEPT_REQ_PARR_QTY,   --팀 발주의뢰 건수 
                            V_DEPT_APVL_QTY AS DEPT_REQ_APVL_QTY,  --팀 발주승인 건수 
                            0 AS DEPT_WHOT_WHSN_QTY                --팀 입/출고관리 건수 
                     FROM DUAL;
                     
            --경진인 경우 (발주의뢰) 
            ELSIF V_USER_DCD = '02' THEN
                
                SP_GET_REQ_PARR_INFO(P_MENU_ID,
                                     P_USER_EENO,
                                     V_USER_DCD,
                                     P_CURR_YMD,
                                     V_FROM_MDL_MDY,
                                     V_TO_MDL_MDY,
                                     V_USER_REQ_QTY,
                                     V_DEPT_REQ_QTY);
                                    
                OPEN RS FOR
                     SELECT V_USER_REQ_QTY AS USER_REQ_PARR_QTY,  --사용자 발주의뢰 건수 
                            0 AS USER_REQ_APVL_QTY,               --사용자 발주승인 건수 
                            0 AS USER_WHOT_WHSN_QTY,              --사용자 입/출고관리 건수 
                            V_DEPT_REQ_QTY AS DEPT_REQ_PARR_QTY,  --팀 발주의뢰 건수 
                            0 AS DEPT_REQ_APVL_QTY,               --팀 발주승인 건수 
                            0 AS DEPT_WHOT_WHSN_QTY               --팀 입/출고관리 건수 
                     FROM DUAL;
                     
            --세화인 경우 (출고관리) ==>긴급배송 수량 표시 
            ELSIF V_USER_DCD = '03' THEN
                
                SP_GET_SEWHA_WHOT_INFO(P_MENU_ID,
                                       P_USER_EENO,
                                       V_USER_DCD,
                                       P_CURR_YMD,
                                       V_FROM_MDL_MDY,
                                       V_TO_MDL_MDY,
                                       V_USER_WHOT_QTY,
                                       V_DEPT_WHOT_QTY);
                                        
                OPEN RS FOR
                     SELECT 0 AS USER_REQ_PARR_QTY,                --사용자 발주의뢰 건수 
                            0 AS USER_REQ_APVL_QTY,                --사용자 발주승인 건수 
                            V_USER_WHOT_QTY AS USER_WHOT_WHSN_QTY, --사용자 입/출고관리 건수 
                            0 AS DEPT_REQ_PARR_QTY,                --팀 발주의뢰 건수 
                            0 AS DEPT_REQ_APVL_QTY,                --팀 발주승인 건수 
                            V_DEPT_WHOT_QTY AS DEPT_WHOT_WHSN_QTY  --팀 입/출고관리 건수 
                     FROM DUAL;
                     
            --PDI인 경우(입고관리)  
            ELSIF V_USER_DCD = '04' THEN
                
                SP_GET_PDI_WHSN_INFO(P_MENU_ID,
                                     P_USER_EENO,
                                     V_USER_DCD,
                                     P_CURR_YMD,
                                     V_FROM_MDL_MDY,
                                     V_TO_MDL_MDY,
                                     V_USER_WHSN_QTY,
                                     V_DEPT_WHSN_QTY);
                                      
                OPEN RS FOR
                     SELECT 0 AS USER_REQ_PARR_QTY,                --사용자 발주의뢰 건수 
                            0 AS USER_REQ_APVL_QTY,                --사용자 발주승인 건수 
                            V_USER_WHSN_QTY AS USER_WHOT_WHSN_QTY, --사용자 입/출고관리 건수 
                            0 AS DEPT_REQ_PARR_QTY,                --팀 발주의뢰 건수 
                            0 AS DEPT_REQ_APVL_QTY,                --팀 발주승인 건수 
                            V_USER_WHSN_QTY AS DEPT_WHOT_WHSN_QTY  --팀 입/출고관리 건수 
                     FROM DUAL;
                     
            --글로비스인 경우(입고관리) 
            ELSIF V_USER_DCD = '05' THEN
                
                SP_GET_GLOVIS_WHSN_INFO(P_MENU_ID,
                                        P_USER_EENO,
                                        V_USER_DCD,
                                        P_CURR_YMD,
                                        V_FROM_MDL_MDY,
                                        V_TO_MDL_MDY,
                                        V_USER_WHSN_QTY,
                                        V_DEPT_WHSN_QTY);
                                        
                OPEN RS FOR
                     SELECT 0 AS USER_REQ_PARR_QTY,                --사용자 발주의뢰 건수 
                            0 AS USER_REQ_APVL_QTY,                --사용자 발주승인 건수 
                            V_USER_WHSN_QTY AS USER_WHOT_WHSN_QTY, --사용자 입/출고관리 건수 
                            0 AS DEPT_REQ_PARR_QTY,                --팀 발주의뢰 건수 
                            0 AS DEPT_REQ_APVL_QTY,                --팀 발주승인 건수 
                            V_DEPT_WHSN_QTY AS DEPT_WHOT_WHSN_QTY  --팀 입/출고관리 건수 
                     FROM DUAL;
                     
            --기타의 경우 
            ELSE
                                         
                OPEN RS FOR
                     SELECT 0 AS USER_REQ_PARR_QTY,  --사용자 발주의뢰 건수 
                            0 AS USER_REQ_APVL_QTY,  --사용자 발주승인 건수 
                            0 AS USER_WHOT_WHSN_QTY, --사용자 입/출고관리 건수 
                            0 AS DEPT_REQ_PARR_QTY,  --팀 발주의뢰 건수 
                            0 AS DEPT_REQ_APVL_QTY,  --팀 발주승인 건수 
                            0 AS DEPT_WHOT_WHSN_QTY  --팀 입/출고관리 건수 
                     FROM DUAL;
                     
            END IF;
            
       END SP_GET_USR_BUSINESS_INFO;
       
       --발주의뢰 건수 조회(외부에서 호출하지 말것)                                       
       PROCEDURE SP_GET_REQ_PARR_INFO(P_MENU_ID      VARCHAR2,
                                      P_USER_EENO    VARCHAR2,
                                      P_USER_DCD     VARCHAR2,
                                      P_CURR_YMD     VARCHAR2,
                                      P_FROM_MDL_MDY VARCHAR,
                                      P_TO_MDL_MDY   VARCHAR,
                                      P_USER_REQ_QTY OUT NUMBER,
                                      P_DEPT_REQ_QTY OUT NUMBER)
       IS
            
         V_CURR_DATE    DATE;
         
         V_PREV_YEAR_YMD VARCHAR2(8);  --1년전 현재월 1일 날짜
         V_PREV_1MTH_YMD VARCHAR2(8);  --1개월전 마지막 날짜
         V_NEXT_2WEK_YMD VARCHAR2(8);  --2주 후 날짜
         
       BEGIN
               
            V_CURR_DATE := TO_DATE(P_CURR_YMD, 'YYYYMMDD');
            
            V_PREV_YEAR_YMD := TO_CHAR(ADD_MONTHS(V_CURR_DATE, -12), 'YYYYMM') || '01';
            V_PREV_1MTH_YMD := TO_CHAR(LAST_DAY(ADD_MONTHS(V_CURR_DATE, -1)), 'YYYYMMDD');
            V_NEXT_2WEK_YMD := TO_CHAR(V_CURR_DATE + 13, 'YYYYMMDD');
            
            WITH T AS (--로그인한 사용자가 수정가능한 차종 및 언어, 연식을 가져오는 부분 
                       SELECT B.QLTY_VEHL_CD,
                               B.MDL_MDY_CD,
                               B.LANG_CD
                       FROM (SELECT QLTY_VEHL_CD
                             FROM TB_AUTH_VEHL_MGMT
                             WHERE MENU_ID = PG_COMMON.FU_RPAD(P_MENU_ID, 10)
                             AND USER_EENO = PG_COMMON.FU_RPAD(P_USER_EENO, 7)
                             AND CL_SCN_CD = 'U'
                            ) A,
                            TB_LANG_MGMT B
                       WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
                       AND B.MDL_MDY_CD BETWEEN P_FROM_MDL_MDY AND P_TO_MDL_MDY
					   AND B.USE_YN = 'Y'
                      ),
                 U AS (--로그인한 사용자가 소속된 부서원들이 수정가능한 차종 및 언어, 연식을 가져오는 부분 
                       SELECT B.QLTY_VEHL_CD,
                              B.MDL_MDY_CD,
                              B.LANG_CD
                       FROM (SELECT A.QLTY_VEHL_CD
                             FROM TB_AUTH_VEHL_MGMT A,
                                  TB_USR_MGMT B
                             WHERE MENU_ID = PG_COMMON.FU_RPAD(P_MENU_ID, 10)
                             AND A.USER_EENO = B.USER_EENO
                             AND B.USER_DCD = P_USER_DCD
                             AND CL_SCN_CD = 'U'
                             GROUP BY A.QLTY_VEHL_CD
                            ) A,
                            TB_LANG_MGMT B
                       WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
                       AND B.MDL_MDY_CD BETWEEN P_FROM_MDL_MDY AND P_TO_MDL_MDY
					   AND B.USE_YN = 'Y'
                      )
            SELECT (--로그인한 사용자가 발주의뢰해야할 건수 
                    SELECT SUM(CASE WHEN WEK2_PLAN_QTY * 0.5 >= (SEWHA_IV_QTY + PDI_IV_QTY - WEK2_PLAN_QTY) THEN 1
                                    ELSE 0 
                               END
                              )
                    FROM (SELECT NVL(B.WEK2_PLAN_QTY, 0) AS WEK2_PLAN_QTY,
                                 NVL(C.SEWHA_IV_QTY, 0) AS SEWHA_IV_QTY,
                                 NVL(D.PDI_IV_QTY, 0) AS PDI_IV_QTY
                          FROM T A,
                               --생산계획(2주) 
                               (SELECT A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD,
									   NVL(B.WEK2_PRDN_PLN_QTY, 0) + NVL(B.TDD_PRDN_QTY2, 0) AS WEK2_PLAN_QTY
								 FROM T A,
						         	  TB_APS_PROD_SUM_INFO B
						         WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
								 AND A.MDL_MDY_CD = B.MDL_MDY_CD
								 AND A.LANG_CD = B.LANG_CD
						   		 AND B.APL_YMD = P_CURR_YMD
								) B,
                                --세화재고
                                (SELECT A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD, SUM(B.SFTY_IV_QTY) AS SEWHA_IV_QTY
                                 FROM T A,
                                      TB_SEWHA_IV_INFO_DTL B
                                 WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
                                 AND A.MDL_MDY_CD = B.MDL_MDY_CD
                                 AND A.LANG_CD = B.LANG_CD
                                 AND B.CLS_YMD = P_CURR_YMD
                                 GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD
								  
								 /*** 
								 SELECT A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD, SUM(IV_QTY) AS SEWHA_IV_QTY
                                 FROM T A,
                                      TB_DL_EXPD_MDY_MGMT B,
                                      TB_SEWHA_IV_INFO C
                                 WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
                                 AND A.MDL_MDY_CD = B.MDL_MDY_CD
                                 AND A.QLTY_VEHL_CD = C.QLTY_VEHL_CD
                                 AND B.DL_EXPD_MDL_MDY_CD = C.DL_EXPD_MDL_MDY_CD
                                 AND A.LANG_CD = C.LANG_CD
                                 AND C.CLS_YMD = P_CURR_YMD
                                 GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD 
								 ***/ 
								 
                                ) C,
                                --PDI재고
                                (SELECT A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD, SUM(B.SFTY_IV_QTY) AS PDI_IV_QTY
                                 FROM T A,
                                      TB_PDI_IV_INFO_DTL B
                                 WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
                                 AND A.MDL_MDY_CD = B.MDL_MDY_CD
                                 AND A.LANG_CD = B.LANG_CD
                                 AND B.CLS_YMD = P_CURR_YMD
                                 GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD 
								 
								 /*** 
								 SELECT A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD, SUM(IV_QTY) AS PDI_IV_QTY
                                 FROM T A,
                                      TB_DL_EXPD_MDY_MGMT B,
                                      TB_PDI_IV_INFO C
                                 WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
                                 AND A.MDL_MDY_CD = B.MDL_MDY_CD
                                 AND A.QLTY_VEHL_CD = C.QLTY_VEHL_CD
                                 AND B.DL_EXPD_MDL_MDY_CD = C.DL_EXPD_MDL_MDY_CD
                                 AND A.LANG_CD = C.LANG_CD
                                 AND C.CLS_YMD = P_CURR_YMD
                                 GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD 
								 ***/ 
								 
                                ) D
                          WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD(+)
                          AND A.MDL_MDY_CD = B.MDL_MDY_CD(+)
                          AND A.LANG_CD = B.LANG_CD(+)
                          AND A.QLTY_VEHL_CD = C.QLTY_VEHL_CD(+)
                          AND A.MDL_MDY_CD = C.MDL_MDY_CD(+)
                          AND A.LANG_CD = C.LANG_CD(+)
                          AND A.QLTY_VEHL_CD = D.QLTY_VEHL_CD(+)
                          AND A.MDL_MDY_CD = D.MDL_MDY_CD(+)
                          AND A.LANG_CD = D.LANG_CD(+)
                         )
                    WHERE WEK2_PLAN_QTY + SEWHA_IV_QTY + PDI_IV_QTY > 0
                   ),
                   (--로그인한 사용자가 소속된 부서원들이 발주의뢰해야할 건수 
                    SELECT SUM(
						   	   CASE WHEN WEK2_PLAN_QTY * 0.5 >= (SEWHA_IV_QTY + PDI_IV_QTY - WEK2_PLAN_QTY) THEN 1
                                    ELSE 0 
                               END
                              )
                    FROM (SELECT NVL(B.WEK2_PLAN_QTY, 0) AS WEK2_PLAN_QTY,
                                 NVL(C.SEWHA_IV_QTY, 0) AS SEWHA_IV_QTY,
                                 NVL(D.PDI_IV_QTY, 0) AS PDI_IV_QTY
                          FROM U A,
						       --생산계획(2주) 
                               (SELECT A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD,
									   NVL(B.WEK2_PRDN_PLN_QTY, 0) + NVL(B.TDD_PRDN_QTY2, 0) AS WEK2_PLAN_QTY
								FROM U A,
						         	 TB_APS_PROD_SUM_INFO B
						        WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
								AND A.MDL_MDY_CD = B.MDL_MDY_CD
								AND A.LANG_CD = B.LANG_CD
						   		AND B.APL_YMD = P_CURR_YMD
							   ) B,
                               --세화재고
                               (SELECT A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD, SUM(B.SFTY_IV_QTY) AS SEWHA_IV_QTY
                                FROM U A,
                                     TB_SEWHA_IV_INFO_DTL B
                                WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
                                AND A.MDL_MDY_CD = B.MDL_MDY_CD
                                AND A.LANG_CD = B.LANG_CD
                                AND B.CLS_YMD = P_CURR_YMD
                                GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD 
							   
							    /*** 
							    SELECT A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD, SUM(IV_QTY) AS SEWHA_IV_QTY
                                FROM U A,
                                     TB_DL_EXPD_MDY_MGMT B,
                                     TB_SEWHA_IV_INFO C
                                WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
                                AND A.MDL_MDY_CD = B.MDL_MDY_CD
                                AND A.QLTY_VEHL_CD = C.QLTY_VEHL_CD
                                AND B.DL_EXPD_MDL_MDY_CD = C.DL_EXPD_MDL_MDY_CD
                                AND A.LANG_CD = C.LANG_CD
                                AND C.CLS_YMD = P_CURR_YMD
                                GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD 
								***/
								
                               ) C,
                               --PDI재고
                               (SELECT A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD, SUM(B.SFTY_IV_QTY) AS PDI_IV_QTY
                                FROM U A,
                                     TB_PDI_IV_INFO_DTL B
                                WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
                                AND A.MDL_MDY_CD = B.MDL_MDY_CD
                                AND A.LANG_CD = B.LANG_CD
                                AND B.CLS_YMD = P_CURR_YMD
                                GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD 
							    
								/*** 
							   	SELECT A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD, SUM(IV_QTY) AS PDI_IV_QTY
                                FROM U A,
                                     TB_DL_EXPD_MDY_MGMT B,
                                     TB_PDI_IV_INFO C
                                WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
                                AND A.MDL_MDY_CD = B.MDL_MDY_CD
                                AND A.QLTY_VEHL_CD = C.QLTY_VEHL_CD
                                AND B.DL_EXPD_MDL_MDY_CD = C.DL_EXPD_MDL_MDY_CD
                                AND A.LANG_CD = C.LANG_CD
                                AND C.CLS_YMD = P_CURR_YMD
                                GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD 
								***/
								
                               ) D
                          WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD(+)
                          AND A.MDL_MDY_CD = B.MDL_MDY_CD(+)
                          AND A.LANG_CD = B.LANG_CD(+)
                          AND A.QLTY_VEHL_CD = C.QLTY_VEHL_CD(+)
                          AND A.MDL_MDY_CD = C.MDL_MDY_CD(+)
                          AND A.LANG_CD = C.LANG_CD(+)
                          AND A.QLTY_VEHL_CD = D.QLTY_VEHL_CD(+)
                          AND A.MDL_MDY_CD = D.MDL_MDY_CD(+)
                          AND A.LANG_CD = D.LANG_CD(+)
                         )
                    WHERE WEK2_PLAN_QTY + SEWHA_IV_QTY + PDI_IV_QTY > 0
                   )
            INTO P_USER_REQ_QTY, P_DEPT_REQ_QTY
            FROM DUAL;
            
            IF P_USER_REQ_QTY IS NULL THEN
               
               P_USER_REQ_QTY := 0;
               
            END IF;
            
            IF P_DEPT_REQ_QTY IS NULL THEN
               
               P_DEPT_REQ_QTY := 0;
               
            END IF;
            
       END SP_GET_REQ_PARR_INFO;
                                         
       --발주승인 건수 조회(외부에서 호출하지 말것) 
       PROCEDURE SP_GET_REQ_APVL_INFO(P_USER_EENO     VARCHAR2,
                                      P_USER_DCD      VARCHAR2,
                                      P_CURR_YMD      VARCHAR2,
                                      P_FROM_MDL_MDY  VARCHAR,
                                      P_TO_MDL_MDY    VARCHAR,
                                      P_USER_APVL_QTY OUT NUMBER,
                                      P_DEPT_APVL_QTY OUT NUMBER)
       IS
            V_MENU_ID CHAR(10);
         
       BEGIN
               
            V_MENU_ID := PG_COMMON.FU_RPAD('0011', 10);
            
            WITH T AS (--로그인한 사용자가 수정가능한 차종 및 언어, 연식을 가져오는 부분 
                       SELECT B.QLTY_VEHL_CD,
                              B.MDL_MDY_CD,
                              B.LANG_CD
                       FROM (SELECT QLTY_VEHL_CD
                             FROM TB_AUTH_VEHL_MGMT
                             WHERE MENU_ID = V_MENU_ID
                             AND USER_EENO = PG_COMMON.FU_RPAD(P_USER_EENO, 7)
                             AND CL_SCN_CD = 'U'
                            ) A,
                            TB_LANG_MGMT B
                       WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
                       AND B.MDL_MDY_CD BETWEEN P_FROM_MDL_MDY AND P_TO_MDL_MDY
					   AND B.USE_YN = 'Y'
                      ),
                 U AS (--로그인한 사용자가 소속된 부서원들이 수정가능한 차종 및 언어, 연식을 가져오는 부분 
                       SELECT B.QLTY_VEHL_CD,
                              B.MDL_MDY_CD,
                              B.LANG_CD
                       FROM (SELECT A.QLTY_VEHL_CD
                             FROM TB_AUTH_VEHL_MGMT A,
                                  TB_USR_MGMT B
                             WHERE MENU_ID = V_MENU_ID
                             AND A.USER_EENO = B.USER_EENO
                             AND B.USER_DCD = P_USER_DCD
                             AND CL_SCN_CD = 'U'
                             GROUP BY A.QLTY_VEHL_CD
                            ) A,
                            TB_LANG_MGMT B
                       WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
                       AND B.MDL_MDY_CD BETWEEN P_FROM_MDL_MDY AND P_TO_MDL_MDY
					   AND B.USE_YN = 'Y'
                      )
             SELECT (SELECT COUNT(*)
                     FROM T A,
                          TB_PRNT_BKGD_INFO B
                     WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
                     AND A.MDL_MDY_CD = B.MDL_MDY_CD
                     AND A.LANG_CD = B.LANG_CD
                     --의뢰, 재의뢰 된 항목의 건수를 가져온다. 
                     AND DL_EXPD_RDCS_ST_CD IN ('01', '04')
                    ), 
                    (SELECT COUNT(*)
                     FROM U A,
                          TB_PRNT_BKGD_INFO B
                     WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
                     AND A.MDL_MDY_CD = B.MDL_MDY_CD
                     AND A.LANG_CD = B.LANG_CD
                     --의뢰, 재의뢰 된 항목의 건수를 가져온다.
                     AND DL_EXPD_RDCS_ST_CD IN ('01', '04')
                    )
             INTO P_USER_APVL_QTY, P_DEPT_APVL_QTY
             FROM DUAL;
             
             IF P_USER_APVL_QTY IS NULL THEN
               
               P_USER_APVL_QTY := 0;
               
             END IF;
            
             IF P_DEPT_APVL_QTY IS NULL THEN
               
               P_DEPT_APVL_QTY := 0;
               
             END IF;
            
       END SP_GET_REQ_APVL_INFO;                
       
       --세화출고예정 건수 조회(외부에서 호출하지 말것) 
       PROCEDURE SP_GET_SEWHA_WHOT_INFO(P_MENU_ID       VARCHAR2,
                                        P_USER_EENO     VARCHAR2,
                                        P_USER_DCD      VARCHAR2,
                                        P_CURR_YMD      VARCHAR2,
                                        P_FROM_MDL_MDY  VARCHAR,
                                        P_TO_MDL_MDY    VARCHAR,
                                        P_USER_WHOT_QTY OUT NUMBER,
                                        P_DEPT_WHOT_QTY OUT NUMBER)
       IS
            
         V_CURR_DATE    DATE;
         
         V_PREV_YEAR_YMD VARCHAR2(8);  --1년전 현재월 1일 날짜
         V_PREV_1MTH_YMD VARCHAR2(8);  --1개월전 마지막 날짜
         
       BEGIN
               
            V_CURR_DATE := TO_DATE(P_CURR_YMD, 'YYYYMMDD');
            
            V_PREV_YEAR_YMD := TO_CHAR(ADD_MONTHS(V_CURR_DATE, -12), 'YYYYMM') || '01';
            V_PREV_1MTH_YMD := TO_CHAR(LAST_DAY(ADD_MONTHS(V_CURR_DATE, -1)), 'YYYYMMDD');
            
            WITH T AS (--로그인한 사용자가 수정가능한 차종 및 언어, 연식을 가져오는 부분 
                       SELECT B.QLTY_VEHL_CD,
                              B.MDL_MDY_CD,
                              B.LANG_CD
                       FROM (SELECT QLTY_VEHL_CD
                             FROM TB_AUTH_VEHL_MGMT
                             WHERE MENU_ID = PG_COMMON.FU_RPAD(P_MENU_ID, 10)
                             AND USER_EENO = PG_COMMON.FU_RPAD(P_USER_EENO, 7)
                             AND CL_SCN_CD = 'U'
                            ) A,
                            TB_LANG_MGMT B
                       WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
                       AND B.MDL_MDY_CD BETWEEN P_FROM_MDL_MDY AND P_TO_MDL_MDY
					   AND B.USE_YN = 'Y'
                      ),
                 U AS (--로그인한 사용자가 소속된 부서원들이 수정가능한 차종 및 언어, 연식을 가져오는 부분 
                       SELECT B.QLTY_VEHL_CD,
                              B.MDL_MDY_CD,
                              B.LANG_CD
                       FROM (SELECT A.QLTY_VEHL_CD
                             FROM TB_AUTH_VEHL_MGMT A,
                                  TB_USR_MGMT B
                             WHERE MENU_ID = PG_COMMON.FU_RPAD(P_MENU_ID, 10)
                             AND A.USER_EENO = B.USER_EENO
                             AND B.USER_DCD = P_USER_DCD
                             AND CL_SCN_CD = 'U'
                             GROUP BY A.QLTY_VEHL_CD
                            ) A,
                            TB_LANG_MGMT B
                       WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
                       AND B.MDL_MDY_CD BETWEEN P_FROM_MDL_MDY AND P_TO_MDL_MDY
					   AND B.USE_YN = 'Y'
                      )
             SELECT (--로그인한 사용자가 출고해야할 건수 
                     SELECT SUM(CASE WHEN DSID3_QTY > PDI_IV_QTY - DAY3_PLAN_QTY AND
								          DAY2_PLAN_QTY > PDI_IV_QTY - DAY3_PLAN_QTY THEN 1
								     ELSE 0 
								END
                               )
                     FROM (SELECT NVL(B.DAY3_PLAN_QTY, 0) AS DAY3_PLAN_QTY,
                                  NVL(C.PDI_IV_QTY, 0) AS PDI_IV_QTY,
                                  NVL(B.DSID3_QTY, 0) AS DSID3_QTY,
								  NVL(B.DAY2_PLAN_QTY, 0) AS DAY2_PLAN_QTY
                           FROM T A,
                                --단기계획(3일)
								(SELECT A.QLTY_VEHL_CD, 
										A.MDL_MDY_CD, 
										A.LANG_CD,
										CASE WHEN NVL(B.TDD_PRDN_PLN_QTY, 0) + NVL(B.TDD_PRDN_QTY2, 0) > NVL(B.TDD_PRDN_QTY, 0) THEN NVL(B.TDD_PRDN_PLN_QTY, 0) + NVL(B.TDD_PRDN_QTY2, 0)
     							             ELSE NVL(B.TDD_PRDN_QTY, 0)
								        END AS DAY3_PLAN_QTY,
								  		CASE WHEN A.LANG_CD = 'EU' THEN NVL(B.TDD_PRDN_PLN_QTY, 0) + NVL(B.TDD_PRDN_QTY2, 0)
										     ELSE NVL(B.TDD_PRDN_PLN_QTY2, 0) + NVL(B.TDD_PRDN_QTY2, 0)
									    END AS DSID3_QTY,
										NVL(B.TDD_PRDN_PLN_QTY3, 0) + NVL(B.TDD_PRDN_QTY2, 0) AS DAY2_PLAN_QTY
								 FROM T A,
						         	  TB_APS_PROD_SUM_INFO B
						         WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
								 AND A.MDL_MDY_CD = B.MDL_MDY_CD
								 AND A.LANG_CD = B.LANG_CD
						   		 AND B.APL_YMD = P_CURR_YMD
								) B,
                                --PDI재고
                                (SELECT A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD, SUM(B.SFTY_IV_QTY) AS PDI_IV_QTY
                                 FROM T A,
                                      TB_PDI_IV_INFO_DTL B
                                 WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
                                 AND A.MDL_MDY_CD = B.MDL_MDY_CD
                                 AND A.LANG_CD = B.LANG_CD
                                 AND B.CLS_YMD = P_CURR_YMD
                                 GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD
								
								 /***
								 SELECT A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD, SUM(IV_QTY) AS PDI_IV_QTY
                                 FROM T A,
                                      TB_DL_EXPD_MDY_MGMT B,
                                      TB_PDI_IV_INFO C
                                 WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
                                 AND A.MDL_MDY_CD = B.MDL_MDY_CD
                                 AND A.QLTY_VEHL_CD = C.QLTY_VEHL_CD
                                 AND B.DL_EXPD_MDL_MDY_CD = C.DL_EXPD_MDL_MDY_CD
                                 AND A.LANG_CD = C.LANG_CD
                                 AND C.CLS_YMD = P_CURR_YMD
                                 GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD
								 ***/
								 
                                ) C
                           WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD(+)
                           AND A.MDL_MDY_CD = B.MDL_MDY_CD(+)
                           AND A.LANG_CD = B.LANG_CD(+)
                           AND A.QLTY_VEHL_CD = C.QLTY_VEHL_CD(+)
                           AND A.MDL_MDY_CD = C.MDL_MDY_CD(+)
                           AND A.LANG_CD = C.LANG_CD(+)
                          )
                     WHERE DAY3_PLAN_QTY + PDI_IV_QTY + DSID3_QTY > 0
                    ), 
                    (--로그인한 사용자가 소속된 부서원들이 출고해야할 건수 
                     SELECT SUM(CASE WHEN DSID3_QTY > PDI_IV_QTY - DAY3_PLAN_QTY AND
								          DAY2_PLAN_QTY > PDI_IV_QTY - DAY3_PLAN_QTY THEN 1
								     ELSE 0 
								END
                               )
                     FROM (SELECT NVL(B.DAY3_PLAN_QTY, 0) AS DAY3_PLAN_QTY,
                                  NVL(C.PDI_IV_QTY, 0) AS PDI_IV_QTY,
                                  NVL(B.DSID3_QTY, 0) AS DSID3_QTY,
								  NVL(B.DAY2_PLAN_QTY, 0) AS DAY2_PLAN_QTY
                           FROM U A,
                                --단기계획(3일)
								(SELECT A.QLTY_VEHL_CD, 
										A.MDL_MDY_CD, 
										A.LANG_CD,
										CASE WHEN NVL(B.TDD_PRDN_PLN_QTY, 0) + NVL(B.TDD_PRDN_QTY2, 0) > NVL(B.TDD_PRDN_QTY, 0) THEN NVL(B.TDD_PRDN_PLN_QTY, 0) + NVL(B.TDD_PRDN_QTY2, 0)
     							             ELSE NVL(B.TDD_PRDN_QTY, 0)
								        END AS DAY3_PLAN_QTY,
								  		CASE WHEN A.LANG_CD = 'EU' THEN NVL(B.TDD_PRDN_PLN_QTY, 0) + NVL(B.TDD_PRDN_QTY2, 0)
										     ELSE NVL(B.TDD_PRDN_PLN_QTY2, 0) + NVL(B.TDD_PRDN_QTY2, 0)
									    END AS DSID3_QTY,
										NVL(B.TDD_PRDN_PLN_QTY3, 0) + NVL(B.TDD_PRDN_QTY2, 0) AS DAY2_PLAN_QTY
								 FROM U A,
						         	  TB_APS_PROD_SUM_INFO B
						         WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
								 AND A.MDL_MDY_CD = B.MDL_MDY_CD
								 AND A.LANG_CD = B.LANG_CD
						   		 AND B.APL_YMD = P_CURR_YMD
								) B,
                                --PDI재고
                                (SELECT A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD, SUM(B.SFTY_IV_QTY) AS PDI_IV_QTY
                                 FROM U A,
                                      TB_PDI_IV_INFO_DTL B
                                 WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
                                 AND A.MDL_MDY_CD = B.MDL_MDY_CD
                                 AND A.LANG_CD = B.LANG_CD
                                 AND B.CLS_YMD = P_CURR_YMD
                                 GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD 
								 
								 /*** 
								 SELECT A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD, SUM(IV_QTY) AS PDI_IV_QTY
                                 FROM U A,
                                      TB_DL_EXPD_MDY_MGMT B,
                                      TB_PDI_IV_INFO C
                                 WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
                                 AND A.MDL_MDY_CD = B.MDL_MDY_CD
                                 AND A.QLTY_VEHL_CD = C.QLTY_VEHL_CD
                                 AND B.DL_EXPD_MDL_MDY_CD = C.DL_EXPD_MDL_MDY_CD
                                 AND A.LANG_CD = C.LANG_CD
                                 AND C.CLS_YMD = P_CURR_YMD
                                 GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD 
								 ***/
								 
                                ) C
                           WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD(+)
                           AND A.MDL_MDY_CD = B.MDL_MDY_CD(+)
                           AND A.LANG_CD = B.LANG_CD(+)
                           AND A.QLTY_VEHL_CD = C.QLTY_VEHL_CD(+)
                           AND A.MDL_MDY_CD = C.MDL_MDY_CD(+)
                           AND A.LANG_CD = C.LANG_CD(+)
                          )
                     WHERE DAY3_PLAN_QTY + PDI_IV_QTY + DSID3_QTY > 0
                    )
             INTO P_USER_WHOT_QTY, P_DEPT_WHOT_QTY
             FROM DUAL;
             
             IF P_USER_WHOT_QTY IS NULL THEN
               
               P_USER_WHOT_QTY := 0;
               
             END IF;
            
             IF P_DEPT_WHOT_QTY IS NULL THEN
               
               P_DEPT_WHOT_QTY := 0;
               
             END IF;
             
       END SP_GET_SEWHA_WHOT_INFO;
       
       --PDI 입고확인 건수 조회(외부에서 호출하지 말것) 
       PROCEDURE SP_GET_PDI_WHSN_INFO(P_MENU_ID       VARCHAR2,
                                      P_USER_EENO     VARCHAR2,
                                      P_USER_DCD      VARCHAR2,
                                      P_CURR_YMD      VARCHAR2,
                                      P_FROM_MDL_MDY  VARCHAR,
                                      P_TO_MDL_MDY    VARCHAR,
                                      P_USER_WHSN_QTY OUT NUMBER,
                                      P_DEPT_WHSN_QTY OUT NUMBER)
       IS
       BEGIN
               
            WITH T AS (--로그인한 사용자가 수정가능한 차종 및 언어, 연식을 가져오는 부분 
                       SELECT B.QLTY_VEHL_CD,
                              B.MDL_MDY_CD,
                              B.LANG_CD
                       FROM (SELECT QLTY_VEHL_CD
                             FROM TB_AUTH_VEHL_MGMT
                             WHERE MENU_ID = PG_COMMON.FU_RPAD(P_MENU_ID, 10)
                             AND USER_EENO = PG_COMMON.FU_RPAD(P_USER_EENO, 7)
                             AND CL_SCN_CD = 'U'
                            ) A,
                            TB_LANG_MGMT B
                       WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
                       AND B.MDL_MDY_CD BETWEEN P_FROM_MDL_MDY AND P_TO_MDL_MDY
					   AND B.USE_YN = 'Y'
                       AND B.LANG_CD <> 'KO'
                      ),
                 U AS (--로그인한 사용자가 소속된 부서원들이 수정가능한 차종 및 언어, 연식을 가져오는 부분 
                       SELECT B.QLTY_VEHL_CD,
                              B.MDL_MDY_CD,
                              B.LANG_CD
                       FROM (SELECT A.QLTY_VEHL_CD
                             FROM TB_AUTH_VEHL_MGMT A,
                                  TB_USR_MGMT B
                             WHERE MENU_ID = PG_COMMON.FU_RPAD(P_MENU_ID, 10)
                             AND A.USER_EENO = B.USER_EENO
                             AND B.USER_DCD = P_USER_DCD
                             AND CL_SCN_CD = 'U'
                             GROUP BY A.QLTY_VEHL_CD
                            ) A,
                            TB_LANG_MGMT B
                       WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
                       AND B.MDL_MDY_CD BETWEEN P_FROM_MDL_MDY AND P_TO_MDL_MDY
					   AND B.USE_YN = 'Y'
                       AND B.LANG_CD <> 'KO'
                      )
             SELECT (SELECT COUNT(*)
                     FROM T A,
                          TB_SEWHA_WHOT_INFO B
                     WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
                     AND A.MDL_MDY_CD = B.MDL_MDY_CD
                     AND A.LANG_CD = B.LANG_CD
                     --별도요청을 제외한 일반항목만 가져오도록 한다. 
                     AND B.DL_EXPD_RQ_SCN_CD = '01' 
                     AND B.CMPL_YN = 'N'
                    ),
                    (SELECT COUNT(*)
                     FROM U A,
                          TB_SEWHA_WHOT_INFO B
                     WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
                     AND A.MDL_MDY_CD = B.MDL_MDY_CD
                     AND A.LANG_CD = B.LANG_CD
                     --별도요청을 제외한 일반항목만 가져오도록 한다. 
                     AND B.DL_EXPD_RQ_SCN_CD = '01' 
                     AND B.CMPL_YN = 'N'
                    )
             INTO P_USER_WHSN_QTY, P_DEPT_WHSN_QTY
             FROM DUAL;
             
             IF P_USER_WHSN_QTY IS NULL THEN
               
               P_USER_WHSN_QTY := 0;
               
             END IF;
            
             IF P_DEPT_WHSN_QTY IS NULL THEN
               
               P_DEPT_WHSN_QTY := 0;
               
             END IF;
             
       END SP_GET_PDI_WHSN_INFO;
       
       --글로비스 입고확인 건수 조회(외부에서 호출하지 말것) 
       PROCEDURE SP_GET_GLOVIS_WHSN_INFO(P_MENU_ID       VARCHAR2,
                                         P_USER_EENO     VARCHAR2,
                                         P_USER_DCD      VARCHAR2,
                                         P_CURR_YMD      VARCHAR2,
                                         P_FROM_MDL_MDY  VARCHAR,
                                         P_TO_MDL_MDY    VARCHAR,
                                         P_USER_WHSN_QTY OUT NUMBER,
                                         P_DEPT_WHSN_QTY OUT NUMBER)
       IS
       BEGIN
               
            WITH T AS (--로그인한 사용자가 수정가능한 차종 및 언어, 연식을 가져오는 부분 
                       SELECT B.QLTY_VEHL_CD,
                              B.MDL_MDY_CD,
                              B.LANG_CD
                       FROM (SELECT QLTY_VEHL_CD
                             FROM TB_AUTH_VEHL_MGMT
                             WHERE MENU_ID = PG_COMMON.FU_RPAD(P_MENU_ID, 10)
                             AND USER_EENO = PG_COMMON.FU_RPAD(P_USER_EENO, 7)
                             AND CL_SCN_CD = 'U'
                            ) A,
                            TB_LANG_MGMT B
                       WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
                       AND B.MDL_MDY_CD BETWEEN P_FROM_MDL_MDY AND P_TO_MDL_MDY
					   AND B.USE_YN = 'Y'
                       AND B.LANG_CD = 'KO'
                      ),
                 U AS (--로그인한 사용자가 소속된 부서원들이 수정가능한 차종 및 언어, 연식을 가져오는 부분 
                       SELECT B.QLTY_VEHL_CD,
                              B.MDL_MDY_CD,
                              B.LANG_CD
                       FROM (SELECT A.QLTY_VEHL_CD
                             FROM TB_AUTH_VEHL_MGMT A,
                                  TB_USR_MGMT B
                             WHERE MENU_ID = PG_COMMON.FU_RPAD(P_MENU_ID, 10)
                             AND A.USER_EENO = B.USER_EENO
                             AND B.USER_DCD = P_USER_DCD
                             AND CL_SCN_CD = 'U'
                             GROUP BY A.QLTY_VEHL_CD
                            ) A,
                            TB_LANG_MGMT B
                       WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
                       AND B.MDL_MDY_CD BETWEEN P_FROM_MDL_MDY AND P_TO_MDL_MDY
					   AND B.USE_YN = 'Y'
                       AND B.LANG_CD = 'KO'
                      )
             SELECT (SELECT COUNT(*)
                     FROM T A,
                          TB_SEWHA_WHOT_INFO B
                     WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
                     AND A.MDL_MDY_CD = B.MDL_MDY_CD
                     AND A.LANG_CD = B.LANG_CD
                     --별도요청을 제외한 일반항목만 가져오도록 한다. 
                     AND B.DL_EXPD_RQ_SCN_CD = '01' 
                     AND B.CMPL_YN = 'N'
                    ),
                    (SELECT COUNT(*)
                     FROM U A,
                          TB_SEWHA_WHOT_INFO B
                     WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
                     AND A.MDL_MDY_CD = B.MDL_MDY_CD
                     AND A.LANG_CD = B.LANG_CD
                     --별도요청을 제외한 일반항목만 가져오도록 한다. 
                     AND B.DL_EXPD_RQ_SCN_CD = '01' 
                     AND B.CMPL_YN = 'N'
                    )
             INTO P_USER_WHSN_QTY, P_DEPT_WHSN_QTY
             FROM DUAL;
             
             IF P_USER_WHSN_QTY IS NULL THEN
               
               P_USER_WHSN_QTY := 0;
               
             END IF;
            
             IF P_DEPT_WHSN_QTY IS NULL THEN
               
               P_DEPT_WHSN_QTY := 0;
               
             END IF;
             
       END SP_GET_GLOVIS_WHSN_INFO;
       
       PROCEDURE SP_GET_MENU_LIST(P_USER_EENO VARCHAR2,
	                              RS OUT REFCUR)
	   IS
	   BEGIN
	   		
			OPEN RS FOR
				 SELECT TRIM(A.MENU_ID) AS MENU_ID, 
				 		TRIM(A.PGM_ID) AS PGM_ID, 
						PGM_NM, 
						PGM_PATH_ADR,
						CASE WHEN B.MENU_ID IS NULL THEN 'N' ELSE 'Y' END AS AUTH
				 FROM TB_PGM_MGMT A, 
				 	  TB_AUTH_AFFR_MGMT B
				 WHERE A.PGM_ID_SN <> 0
				 AND A.USE_YN = 'Y'
				 AND A.MENU_ID = B.MENU_ID
				 AND B.MENU_AUTH_CD = 'R'
				 AND B.USER_EENO = PG_COMMON.FU_RPAD(P_USER_EENO, 7) 
				 ORDER BY A.PGM_ID, PGM_ID_SN;
						
	   END SP_GET_MENU_LIST;

       PROCEDURE SP_GET_FULL_MENU_LIST(P_USER_EENO VARCHAR2,
                                  RS OUT REFCUR)
       IS
       BEGIN
               
            OPEN RS FOR
                 SELECT TRIM(A.MENU_ID) AS MENU_ID, 
                         TRIM(A.PGM_ID) AS PGM_ID, 
                        PGM_NM, 
                        PGM_PATH_ADR,
                        CASE WHEN B.MENU_ID IS NULL THEN 'N' ELSE 'Y' END AS AUTH
                 FROM TB_PGM_MGMT A, 
                       TB_AUTH_AFFR_MGMT B
                 WHERE A.PGM_ID_SN <> 0
                 AND A.USE_YN = 'Y'
                 AND A.MENU_ID = B.MENU_ID(+)
                 AND B.MENU_AUTH_CD(+) = 'R'
                 AND B.USER_EENO(+) = PG_COMMON.FU_RPAD(P_USER_EENO, 7) 
                 ORDER BY A.PGM_ID, PGM_ID_SN;
                        
       END SP_GET_FULL_MENU_LIST;
	   
       -- 비밀번호 변경 경과 일자 조회
       PROCEDURE SP_GET_PW_ALTR_DAY_CNT(P_USER_EENO VARCHAR2,
                                  P_DAY_CNT OUT INT)
       IS
       BEGIN
             SELECT NVL(ROUND(SYSDATE - A.PW_ALTR_DTM), 0) INTO P_DAY_CNT
             FROM TB_USR_MGMT A
             WHERE A.USER_EENO = PG_COMMON.FU_RPAD(P_USER_EENO, 7);
       END SP_GET_PW_ALTR_DAY_CNT;
       -- 사용자 정보 조회 
       PROCEDURE SP_USER_INFO(P_USER_EENO VARCHAR2, 
                              RS       OUT REFCUR)
       IS
       BEGIN
       
       OPEN RS FOR
        
            SELECT 
                USER_EENO,
                USER_PW,
                USER_DCD,
				B.DL_EXPD_PRVS_NM AS USER_DCD_NM,
                USER_NM,
                USER_EML_ADR
            FROM TB_USR_MGMT A,
			     TB_CODE_MGMT B
            WHERE USER_EENO = PG_COMMON.FU_RPAD(P_USER_EENO, 7) 
			AND A.USE_YN = 'Y'
			AND A.USER_DCD = B.DL_EXPD_PRVS_CD
			AND B.DL_EXPD_G_CD = '0011';
            
       END SP_USER_INFO;
       
       -- 사용자 정보 수정  
       PROCEDURE SP_USER_EDIT(P_USER_EENO    VARCHAR2,
                              P_USER_DCD     VARCHAR2,
                              P_USER_EML_ADR VARCHAR2,
                              P_USER_PW      VARCHAR2)
       IS
       BEGIN
       
       		IF P_USER_PW IS NULL OR P_USER_PW = '' THEN
                UPDATE TB_USR_MGMT
                SET 
                    USER_DCD = P_USER_DCD,
                    USER_EML_ADR = P_USER_EML_ADR
                WHERE USER_EENO = P_USER_EENO;
            ELSE
                UPDATE TB_USR_MGMT
                SET 
                    USER_DCD = P_USER_DCD,
                    USER_EML_ADR = P_USER_EML_ADR,
                    USER_PW = FU_GET_PASSWORD(PG_COMMON.FU_RPAD(P_USER_EENO, 7), P_USER_PW),
                    PW_ALTR_DTM = SYSDATE
                WHERE USER_EENO = PG_COMMON.FU_RPAD(P_USER_EENO, 7);
            END IF;
            
       END SP_USER_EDIT;
            
       PROCEDURE SP_USER_EDIT_N(P_USER_EENO    VARCHAR2,
                              P_USER_DCD     VARCHAR2,
                              P_USER_EML_ADR VARCHAR2,
                              P_USER_PW      VARCHAR2,
                              P_USER_CHG_PW	VARCHAR2)
       IS
       BEGIN
       
       		IF P_USER_PW IS NULL OR P_USER_PW = '' THEN
                UPDATE TB_USR_MGMT
                SET 
                    USER_DCD = P_USER_DCD,
                    USER_EML_ADR = P_USER_EML_ADR,
                    UPDR_EENO = PG_COMMON.FU_RPAD(P_USER_EENO, 7),
                    MDFY_DTM = SYSDATE
                WHERE USER_EENO = PG_COMMON.FU_RPAD(P_USER_EENO, 7);
            ELSE
                UPDATE TB_USR_MGMT
                SET 
                    USER_DCD = P_USER_DCD,
                    USER_EML_ADR = P_USER_EML_ADR,
                    USER_PW = FU_GET_PASSWORD(PG_COMMON.FU_RPAD(P_USER_EENO, 7), P_USER_PW),
                    --USER_SHA_PWD = P_USER_PW,
                    USER_CHG_PW = P_USER_CHG_PW,
                    PW_ALTR_DTM = SYSDATE,
                    UPDR_EENO = PG_COMMON.FU_RPAD(P_USER_EENO, 7),
                    MDFY_DTM = SYSDATE,
                    PW_LOCK_DTM = '',
                    PW_ERR_OFT = 0
                WHERE USER_EENO = PG_COMMON.FU_RPAD(P_USER_EENO, 7);
            END IF;
            
       END SP_USER_EDIT_N;

       PROCEDURE SP_USER_EDIT_N2(P_USER_EENO    VARCHAR2,
                              P_USER_DCD     VARCHAR2,
                              P_USER_EML_ADR VARCHAR2,
                              P_USER_PW      VARCHAR2,
                              P_USER_CHG_PW    VARCHAR2)
       IS
       BEGIN
       
               IF P_USER_PW IS NULL OR P_USER_PW = '' THEN
                UPDATE TB_USR_MGMT
                SET 
                    USER_DCD = P_USER_DCD,
                    USER_EML_ADR = P_USER_EML_ADR,
                    UPDR_EENO = PG_COMMON.FU_RPAD(P_USER_EENO, 7),
                    MDFY_DTM = SYSDATE
                WHERE USER_EENO = PG_COMMON.FU_RPAD(P_USER_EENO, 7);
            ELSE
                UPDATE TB_USR_MGMT
                SET 
                    USER_DCD = P_USER_DCD,
                    USER_EML_ADR = P_USER_EML_ADR,
                    USER_PW = ' ',--FU_GET_PASSWORD(PG_COMMON.FU_RPAD(P_USER_EENO, 7), P_USER_PW),
                    USER_CHG_PW = P_USER_CHG_PW,
                    PW_ALTR_DTM = SYSDATE,
                    UPDR_EENO = PG_COMMON.FU_RPAD(P_USER_EENO, 7),
                    MDFY_DTM = SYSDATE,
                    PW_LOCK_DTM = '',
                    PW_ERR_OFT = 0
                WHERE USER_EENO = PG_COMMON.FU_RPAD(P_USER_EENO, 7);
            END IF;
            
       END SP_USER_EDIT_N2;

       -- 메인 게시판 조회(TOP 5) 
       PROCEDURE SP_BOARD_TOP5(P_USER_DCD VARCHAR2, 
                               RS      OUT REFCUR)
       IS
       BEGIN
       
       OPEN RS FOR
            SELECT * FROM 
            (
                SELECT ROWNUM RN, A.* FROM 
                (
                    SELECT 
                        BM.SCRN_SN,
                        BM.BLC_TITL_NM 
                    FROM TB_BOARD_MGMT BM,
                         TB_BOARD_SUBJ_MGMT BSM
                    WHERE BM.SCRN_SN = BSM.SCRN_SN
                          AND BSM.BUL_SUBJ_CD = P_USER_DCD
                    ORDER BY BM.FRAM_DTM DESC
                )A 
            )
            WHERE RN < 6;
            
       END SP_BOARD_TOP5;
        
      
       
       -- 메인 팝업 게시판 조회(TOP 1) 
       PROCEDURE SP_BOARD_POP(P_USER_DCD VARCHAR2, 
                              P_SCRN_SN OUT INT)
       IS
       BEGIN
            
            SELECT NVL(MAX(SCRN_SN),0) INTO P_SCRN_SN FROM 
            (
                SELECT ROWNUM RN, SCRN_SN FROM 
                (
                    SELECT 
                        BM.SCRN_SN
                    FROM TB_BOARD_MGMT BM,
                         TB_BOARD_SUBJ_MGMT BSM
                    WHERE BM.SCRN_SN = BSM.SCRN_SN
                          AND BSM.BUL_SUBJ_CD = P_USER_DCD
                          AND BM.BUL_YN = 'Y'
                          AND TO_CHAR(SYSDATE, 'YYYYMMDD') BETWEEN BM.BUL_STRT_YMD AND BM.BUL_FNH_YMD
                    ORDER BY BM.FRAM_DTM DESC
                )A 
            )
            WHERE RN < 2;
            
       END SP_BOARD_POP;
       
END PG_MAIN;