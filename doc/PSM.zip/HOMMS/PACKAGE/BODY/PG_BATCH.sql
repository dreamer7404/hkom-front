CREATE OR REPLACE PACKAGE BODY HOMMS_ADM.PG_BATCH AS

/**********************************************************/    
       PROCEDURE SP_BATCH_APS
       IS
            
       BEGIN
                
--                PG_INTERFACE_APS.APS_INTERFACE_KMC;
                
                PG_INTERFACE_APS.APS_INTERFACE_HMC;

       END SP_BATCH_APS;

       PROCEDURE SP_BATCH_ERP
       IS
            
       BEGIN
                
--                PG_INTERFACE_PROD_MST.PROD_MST_INTERFACE_KMC;
                
                PG_INTERFACE_PROD_MST.PROD_MST_INTERFACE_HMC;

       END SP_BATCH_ERP;

       PROCEDURE SP_BATCH_ALL
       IS
            
       BEGIN
                
--                PG_INTERFACE_PROD_MST.PROD_MST_INTERFACE_KMC;

                PG_INTERFACE_PROD_MST.PROD_MST_INTERFACE_HMC;

--                PG_INTERFACE_APS.APS_INTERFACE_KMC;
                
                PG_INTERFACE_APS.APS_INTERFACE_HMC;

                SP_BATCH_EXECUTE_CHECK;
                
       END SP_BATCH_ALL;
       
       PROCEDURE SP_BATCH_EXECUTE_CHECK
       IS
        V_EXE_BATCH_CNT NUMBER;
        STRT_DATE  DATE;
       BEGIN
       
        STRT_DATE  := SYSDATE;

        SELECT COUNT(*)
            INTO V_EXE_BATCH_CNT
        FROM TB_BATCH_FNH_INFO
        WHERE BTCH_FNH_YMD = TO_CHAR(SYSDATE, 'YYYYMMDD')
        ;
        
        IF V_EXE_BATCH_CNT = 6 THEN
        -- BATCH가 모두 완료된 경우 원래 스케쥴 시간으로 원복
        
            PG_INTERFACE_APS.WRITE_BATCH_LOG('SP_BATCH_EXECUTE_CHECK', STRT_DATE, 'S', '배치처리완료');
            DBMS_JOB.NEXT_DATE(322, TRUNC(SYSDATE+1)+320/1440);
        
        ELSE
        -- 그렇지 않은 경우 5분 후로 JOB 스케쥴 조정
            --DBMS_JOB.NEXT_DATE(322, (SYSDATE + 5/1440));
            PG_INTERFACE_APS.WRITE_BATCH_LOG('SP_BATCH_EXECUTE_CHECK', STRT_DATE, 'F', '배치처리 스케쥴 조정');
            DBMS_JOB.NEXT_DATE(322, (SYSDATE + 5/1440));
        END IF;
        
       
       END SP_BATCH_EXECUTE_CHECK;

       PROCEDURE SP_BATCH_RUN_IMMEDIATELY
       IS
            
       BEGIN
                
        DBMS_JOB.RUN(322, TRUE);
                
       END SP_BATCH_RUN_IMMEDIATELY;

END PG_BATCH;