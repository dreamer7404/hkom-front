CREATE OR REPLACE PACKAGE BODY PG_CHK_LIST_CHANG_INFO AS
	   
        -- 체크리스트 변경상세정보 삭제 
 	    PROCEDURE SP_CHKLIST_INFO_DEL(P_EXPD_ALTR_NO VARCHAR2,
		                              P_USER_EENO    VARCHAR2)
		IS
		  V_CNT      NUMBER;
		BEGIN
		  
		  SELECT COUNT(*) INTO V_CNT
		  FROM TB_CHKLIST_DTL_INFO
		  WHERE DL_EXPD_ALTR_NO = P_EXPD_ALTR_NO
		  AND N_PRNT_PBCN_NO IS NOT NULL;
		  
		  --발간번호가 발부되어 사용된 내역이 없는 항목만 삭제가 가능하다. 
		  IF V_CNT = 0 THEN
		  	 
			 /**
			 DELETE FROM TB_CHKLIST_INFO
			 WHERE DL_EXPD_ALTR_NO = P_EXPD_ALTR_NO;
			 **/
			 
			 UPDATE TB_CHKLIST_INFO
			 SET DEL_YN = 'Y'
			 WHERE DL_EXPD_ALTR_NO = P_EXPD_ALTR_NO;
			 
			 DELETE FROM TB_CHKLIST_DTL_INFO
			 WHERE DL_EXPD_ALTR_NO = P_EXPD_ALTR_NO;
			 
		  END IF;
		   
		END SP_CHKLIST_INFO_DEL;
		
		PROCEDURE SP_CHKLIST_INFO_DEL2(P_EXPD_ALTR_NO VARCHAR2,
			  					       P_VEHL_LIST	  VARCHAR2,
                                       P_USER_EENO    VARCHAR2)
		IS
		  
		  V_CNT       NUMBER;
		  
		  V_VEHL_LIST PG_COMMON.LIST_TYPE;
		  
		  V_VEHL_CNT  BINARY_INTEGER;
		  
		BEGIN
		  
		  V_VEHL_LIST := PG_COMMON.FU_SPLIT(P_VEHL_LIST, V_VEHL_CNT);
		  
		  --체크리스트 상세정보에서 현재 차종에 발간번호가 설정되지 않은 항목을 삭제한다. 
		  FOR VEHL_NUM IN 1..V_VEHL_CNT LOOP
		  	  
			  DELETE FROM TB_CHKLIST_DTL_INFO
			  WHERE DL_EXPD_ALTR_NO = P_EXPD_ALTR_NO
			  AND QLTY_VEHL_CD = V_VEHL_LIST(VEHL_NUM)
			  AND N_PRNT_PBCN_NO IS NULL;
			  
		  END LOOP;
		  
		  --체크리스트 상세정보에 현재 변경번호에 해당하는 내역이 존재하는 지의 여부를 확인한다. 
		  SELECT COUNT(*) INTO V_CNT
		  FROM TB_CHKLIST_DTL_INFO
		  WHERE DL_EXPD_ALTR_NO = P_EXPD_ALTR_NO;
		  
		  --발간번호가 발부되어 사용된 내역이 없는 항목만 삭제가 가능하다. 
		  IF V_CNT = 0 THEN
		  	 
			 /**
			 DELETE FROM TB_CHKLIST_INFO
			 WHERE DL_EXPD_ALTR_NO = P_EXPD_ALTR_NO; 
			 **/
			 
			 UPDATE TB_CHKLIST_INFO
			 SET DEL_YN = 'Y'
			 WHERE DL_EXPD_ALTR_NO = P_EXPD_ALTR_NO;

		  END IF;
		
		END SP_CHKLIST_INFO_DEL2;
                
        -- 체크리스트 변경상세정보 입력 
		PROCEDURE SP_CHKLIST_INFO_SAVE(P_EXPD_ALTR_NO VARCHAR2,
				  					   P_ALTR_YMD     VARCHAR2,
				  					   P_RCPM_SHAP_CD VARCHAR2,
                                       P_DSPP_NM      VARCHAR2,
                                       P_CHGR_EENO    VARCHAR2,
                                       P_CRGR_NM      VARCHAR2,
									   P_VEHL_LIST	  VARCHAR2,
									   P_LANG_LIST    VARCHAR2,
                                       P_ALTR_SBC     VARCHAR2,
                                       P_USER_EENO    VARCHAR2)
		IS
		  
		  V_LANG_LIST PG_COMMON.LIST_TYPE;
		  V_VEHL_LIST PG_COMMON.LIST_TYPE;
		  
		  V_LANG_CNT BINARY_INTEGER;
		  V_VEHL_CNT BINARY_INTEGER;
		  
		  V_EXPD_ALTR_NO TB_CHKLIST_INFO.DL_EXPD_ALTR_NO%TYPE;
		  
		  V_ALTR_YMD VARCHAR2(8);
		  
		  V_CNT      NUMBER;
		  
		  V_PREV_SHAP_CD VARCHAR2(4);
		  
		BEGIN
		  
		  V_LANG_LIST := PG_COMMON.FU_SPLIT(P_LANG_LIST, V_LANG_CNT);
		  V_VEHL_LIST := PG_COMMON.FU_SPLIT(P_VEHL_LIST, V_VEHL_CNT);
		  
		  IF P_ALTR_YMD IS NULL OR P_ALTR_YMD = '' THEN
		  	 
			 V_ALTR_YMD := TO_CHAR(SYSDATE, 'YYYYMMDD');
		  
		  ELSE 
		  	 
			 V_ALTR_YMD := P_ALTR_YMD;
			 
		  END IF;
		  
		  IF P_EXPD_ALTR_NO IS NULL OR P_EXPD_ALTR_NO = '' THEN
		  	 
			 
			 IF P_RCPM_SHAP_CD IN ('05', '07') THEN
			 
			 	--법규/법규2 의 경우에는 변경번호 생성방식이 다르다...
				
				--변경번호 생성 
			 	SELECT 'R' || TO_CHAR(TO_DATE(V_ALTR_YMD, 'YYYYMMDD'), 'YY') || '-' ||
			           TRIM(TO_CHAR(NVL(TO_NUMBER(SUBSTR(MAX(DL_EXPD_ALTR_NO), 5, 4)) + 1, 1), '0000'))
			 	INTO V_EXPD_ALTR_NO
			 	FROM TB_CHKLIST_INFO
			 	WHERE ALTR_YMD LIKE SUBSTR(V_ALTR_YMD, 1, 4) || '%'
				AND RCPM_SHAP_CD IN ('05', '07');
				 
				 
			 ELSIF P_RCPM_SHAP_CD = '06' THEN
			 	
				--법규1의 경우에는 변경번호 생성방식이 다르다...
				
				--변경번호 생성 
			 	SELECT 'V' || TO_CHAR(TO_DATE(V_ALTR_YMD, 'YYYYMMDD'), 'YY') || '-' ||
			           TRIM(TO_CHAR(NVL(TO_NUMBER(SUBSTR(MAX(DL_EXPD_ALTR_NO), 5, 4)) + 1, 1), '0000'))
			 	INTO V_EXPD_ALTR_NO
			 	FROM TB_CHKLIST_INFO
			 	WHERE ALTR_YMD LIKE SUBSTR(V_ALTR_YMD, 1, 4) || '%'
				AND RCPM_SHAP_CD = '06';
				
			 /** [변경] 2010.10.18.김동근 '05', '07'은 동일방식으로 처리됨 
			 ELSIF P_RCPM_SHAP_CD IN ('05', '07') THEN
				
				--법규2의 경우에는 변경번호 생성방식이 다르다...
				
				--변경번호 생성 
			 	SELECT 'R' || TO_CHAR(TO_DATE(V_ALTR_YMD, 'YYYYMMDD'), 'YY') || '-' ||
			           TRIM(TO_CHAR(NVL(TO_NUMBER(SUBSTR(MAX(DL_EXPD_ALTR_NO), 5, 4)) + 1, 1), '0000'))
			 	INTO V_EXPD_ALTR_NO
			 	FROM TB_CHKLIST_INFO
			 	WHERE ALTR_YMD LIKE SUBSTR(V_ALTR_YMD, 1, 4) || '%'
				AND RCPM_SHAP_CD IN ('05', '07');
			 
			 **/	
				
			 ELSE
			 	 
				 --변경번호 생성 
			 	 SELECT 'C' || TO_CHAR(TO_DATE(V_ALTR_YMD, 'YYYYMMDD'), 'YY') || '-' ||
			        	TRIM(TO_CHAR(NVL(TO_NUMBER(SUBSTR(MAX(DL_EXPD_ALTR_NO), 5, 4)) + 1, 1), '0000'))
			 	 INTO V_EXPD_ALTR_NO
			 	 FROM TB_CHKLIST_INFO
			 	 WHERE ALTR_YMD LIKE SUBSTR(V_ALTR_YMD, 1, 4) || '%'
				 AND RCPM_SHAP_CD NOT IN ('05', '06', '07');
			 
			 END IF;
			 
			 --TB_CHKLIST_INFO 테이블에 값 신규 추가 
			 INSERT INTO TB_CHKLIST_INFO
             (DL_EXPD_ALTR_NO,
              ALTR_YMD, 
		      RCPM_SHAP_CD,
              DSPP_NM, 
		      CHGR_EENO,
              CRGR_NM, 
		      ALTR_SBC,
              PPRR_EENO,
              FRAM_DTM,
              UPDR_EENO,
              MDFY_DTM,
			  DEL_YN
		     )
             VALUES 
		     (V_EXPD_ALTR_NO,
              V_ALTR_YMD,
              P_RCPM_SHAP_CD,
              P_DSPP_NM,
              P_CHGR_EENO,
              P_CRGR_NM,
              P_ALTR_SBC,
              P_USER_EENO,
              SYSDATE,
              P_USER_EENO,
              SYSDATE,
			  'N'
		     );
           	 
			 --EO번호 내역 저장 
			 IF P_RCPM_SHAP_CD = '04' THEN
			 	
				SP_CHKLIST_EONO_SAVE(V_EXPD_ALTR_NO, P_ALTR_SBC, P_USER_EENO);
				
			 END IF;
			 
			 FOR VEHL_NUM IN 1..V_VEHL_CNT LOOP
			 	 
				 FOR LANG_NUM IN 1..V_LANG_CNT LOOP
				 	 
					 --언어코드 테이블에 존재하는 항목만 저장한다. 
					 SELECT COUNT(*) INTO V_CNT
					 FROM TB_LANG_MGMT
					 WHERE QLTY_VEHL_CD = V_VEHL_LIST(VEHL_NUM)
					 AND LANG_CD = V_LANG_LIST(LANG_NUM)
					 AND ROWNUM <= 1;
					 
					 IF V_CNT > 0 THEN
					 	
						INSERT INTO TB_CHKLIST_DTL_INFO
					    (DL_EXPD_ALTR_NO,
					     QLTY_VEHL_CD,
					     LANG_CD,
					     PPRR_EENO,
					     FRAM_DTM,
					     UPDR_EENO,
					     MDFY_DTM
					    )
					    VALUES
					    (V_EXPD_ALTR_NO,
					     V_VEHL_LIST(VEHL_NUM),
					     V_LANG_LIST(LANG_NUM),
					     P_USER_EENO,
					     SYSDATE,
					     P_USER_EENO,
					     SYSDATE
					    );
					 
					 END IF;
					 
				 END LOOP;
				 
			 END LOOP;
			 
		  ELSE
		     
			 --이전의 수신형태코드가 무엇인지 확인한다. 
			 SELECT RCPM_SHAP_CD
			 INTO V_PREV_SHAP_CD
			 FROM TB_CHKLIST_INFO
			 WHERE DL_EXPD_ALTR_NO = P_EXPD_ALTR_NO;
			 
			 --법규의 경우에는 등록번호가 다른 방식으로 발부되므로 다른 항목으로 변경되거나 다른 항목이 법규로 전환될 수 없다. 
			 
			 /***
			 IF V_PREV_SHAP_CD = '05' AND P_RCPM_SHAP_CD <> '05' THEN
			 	
				--현재 항목이 법규가 아니면서 이전의 항목이 법규였던 경우에는 에러를 발생시킨다.
				
				RAISE_APPLICATION_ERROR(-20001, 'Invalid altr_no & shap_cd1 ' || 
			   								    'shap_cd:' || P_RCPM_SHAP_CD || ',' ||
												'prev_cd:' || V_PREV_SHAP_CD || ',' ||
											    'altr_no:' || P_EXPD_ALTR_NO);
		     
			 ELSIF V_PREV_SHAP_CD <> '05' AND P_RCPM_SHAP_CD = '05' THEN
			 	   
				   --현재 항목이 법규이면서 기존의 등록번호가 법규 등록번호가 아닌 경우에는 에러를 발생시킨다.
				   
				   RAISE_APPLICATION_ERROR(-20001, 'Invalid altr_no & shap_cd2 ' || 
			   								       'shap_cd:' || P_RCPM_SHAP_CD || ',' ||
												   'prev_cd:' || V_PREV_SHAP_CD || ',' ||
											       'altr_no:' || P_EXPD_ALTR_NO);
															
			 END IF;
			 ***/
			 
			 IF V_PREV_SHAP_CD IN ('05', '06', '07') AND P_RCPM_SHAP_CD NOT IN ('05', '06', '07') THEN
			 	
			     --현재 항목이 법규가 아니면서 이전의 항목이 법규였던 경우에는 에러를 발생시킨다.
				
				 RAISE_APPLICATION_ERROR(-20001, 'Invalid altr_no & shap_cd1 ' || 
			   								     'shap_cd:' || P_RCPM_SHAP_CD || ',' ||
												 'prev_cd:' || V_PREV_SHAP_CD || ',' ||
											     'altr_no:' || P_EXPD_ALTR_NO);
		     
			 ELSIF V_PREV_SHAP_CD NOT IN ('05', '06', '07') AND P_RCPM_SHAP_CD IN ('05', '06', '07') THEN
			 	   
				 --현재 항목이 법규이면서 기존의 등록번호가 법규 등록번호가 아닌 경우에는 에러를 발생시킨다.
				   
				 RAISE_APPLICATION_ERROR(-20001, 'Invalid altr_no & shap_cd2 ' || 
			   								     'shap_cd:' || P_RCPM_SHAP_CD || ',' ||
												 'prev_cd:' || V_PREV_SHAP_CD || ',' ||
											     'altr_no:' || P_EXPD_ALTR_NO);
			 
			 ELSIF V_PREV_SHAP_CD IN ('05', '06', '07') AND P_RCPM_SHAP_CD IN ('05', '06', '07') THEN
			 	   
				 --현재 항목이 법규이면서 기존의 등록번호 역시 법규 등록번호인 경우 
				   
				 IF V_PREV_SHAP_CD <> P_RCPM_SHAP_CD THEN
				   	
					/** [변경] 2010.10.18.김동근 '05', '07'은 동일방식으로 처리됨 
					IF P_RCPM_SHAP_CD IN ('05', '07') THEN
			 
			 		    --법규의 경우에는 변경번호 생성방식이 다르다...
				
						--변경번호 생성 
			 			SELECT 'R' || TO_CHAR(TO_DATE(V_ALTR_YMD, 'YYYYMMDD'), 'YY') || '-' ||
			           	  	   TRIM(TO_CHAR(NVL(TO_NUMBER(SUBSTR(MAX(DL_EXPD_ALTR_NO), 5, 4)) + 1, 1), '0000'))
			 			INTO V_EXPD_ALTR_NO
			 			FROM TB_CHKLIST_INFO
			 			WHERE ALTR_YMD LIKE SUBSTR(V_ALTR_YMD, 1, 4) || '%'
						AND RCPM_SHAP_CD IN ('05', '07');
				 
				    **/
					
			        --ELSIF P_RCPM_SHAP_CD = '06' THEN
			 	    IF P_RCPM_SHAP_CD = '06' THEN
					
					    --법규1의 경우에는 변경번호 생성방식이 다르다...
				
						--변경번호 생성 
			 			SELECT 'V' || TO_CHAR(TO_DATE(V_ALTR_YMD, 'YYYYMMDD'), 'YY') || '-' ||
			           	  	   TRIM(TO_CHAR(NVL(TO_NUMBER(SUBSTR(MAX(DL_EXPD_ALTR_NO), 5, 4)) + 1, 1), '0000'))
			 			INTO V_EXPD_ALTR_NO
			 			FROM TB_CHKLIST_INFO
			 			WHERE ALTR_YMD LIKE SUBSTR(V_ALTR_YMD, 1, 4) || '%'
						AND RCPM_SHAP_CD = '06';
				
				
			        ELSE
				
					    --법규/법규2 의 경우에는 변경번호 생성방식이 다르다...
				
						--변경번호 생성 
			 			SELECT 'R' || TO_CHAR(TO_DATE(V_ALTR_YMD, 'YYYYMMDD'), 'YY') || '-' ||
			           	  	   TRIM(TO_CHAR(NVL(TO_NUMBER(SUBSTR(MAX(DL_EXPD_ALTR_NO), 5, 4)) + 1, 1), '0000'))
			 			INTO V_EXPD_ALTR_NO
			 			FROM TB_CHKLIST_INFO
			 			WHERE ALTR_YMD LIKE SUBSTR(V_ALTR_YMD, 1, 4) || '%'
						AND RCPM_SHAP_CD IN ('05', '07');
				
				
			 		END IF;
				   
				 ELSE
				   	   
					 V_EXPD_ALTR_NO := P_EXPD_ALTR_NO;
					   
				 END IF;
				 
			 ELSE
			 	   
				 V_EXPD_ALTR_NO := P_EXPD_ALTR_NO;
				   	
			 END IF;
			 
			 UPDATE TB_CHKLIST_INFO
			 SET DL_EXPD_ALTR_NO = V_EXPD_ALTR_NO,
			 	 ALTR_YMD = V_ALTR_YMD, 
		         RCPM_SHAP_CD = P_RCPM_SHAP_CD,
                 DSPP_NM = P_DSPP_NM, 
		         CHGR_EENO = P_CHGR_EENO,
                 CRGR_NM = P_CRGR_NM, 
		         ALTR_SBC = P_ALTR_SBC,
                 UPDR_EENO = P_USER_EENO,
                 MDFY_DTM = SYSDATE
			 WHERE DL_EXPD_ALTR_NO = P_EXPD_ALTR_NO;
			 
			 --변경번호가 변경된 경우에는 기존의 변경번호를 신변경번호로 변경하여 준다. 
			 IF P_EXPD_ALTR_NO <> V_EXPD_ALTR_NO THEN
				 	
			     UPDATE TB_CHKLIST_DTL_INFO
				 SET DL_EXPD_ALTR_NO = V_EXPD_ALTR_NO,
				     UPDR_EENO = P_USER_EENO,
					 MDFY_DTM = SYSDATE
				 WHERE DL_EXPD_ALTR_NO = P_EXPD_ALTR_NO;
				 
			 END IF;
				 
			 --EO번호 내역 저장 
			 IF P_RCPM_SHAP_CD = '04' THEN
			 	
				SP_CHKLIST_EONO_SAVE(V_EXPD_ALTR_NO, P_ALTR_SBC, P_USER_EENO);
				
			 END IF;
			 
			 FOR VEHL_NUM IN 1..V_VEHL_CNT LOOP
			 	 
				 --신인쇄발간번호가 이미 발부된 항목은 삭제하지 않는다. 
			 	 DELETE FROM TB_CHKLIST_DTL_INFO
			 	 WHERE DL_EXPD_ALTR_NO = V_EXPD_ALTR_NO
				 AND QLTY_VEHL_CD = V_VEHL_LIST(VEHL_NUM)
			 	 AND N_PRNT_PBCN_NO IS NULL;
				 
				 FOR LANG_NUM IN 1..V_LANG_CNT LOOP
				 	 
					 --언어코드 테이블에 존재하는 항목만 저장한다. 
					 SELECT COUNT(*) INTO V_CNT
					 FROM TB_LANG_MGMT
					 WHERE QLTY_VEHL_CD = V_VEHL_LIST(VEHL_NUM)
					 AND LANG_CD = V_LANG_LIST(LANG_NUM)
					 AND ROWNUM <= 1;
					 
					 IF V_CNT > 0 THEN
					 	
						--이미 변경내역 상세 테이블에 데이터가 존재하는 경우에는 저장하지 않는다. 
						
						SELECT COUNT(*) INTO V_CNT
						FROM TB_CHKLIST_DTL_INFO
						WHERE DL_EXPD_ALTR_NO = V_EXPD_ALTR_NO
						AND QLTY_VEHL_CD = V_VEHL_LIST(VEHL_NUM)
						AND LANG_CD = V_LANG_LIST(LANG_NUM);
						
						IF V_CNT = 0 THEN
						   
						   INSERT INTO TB_CHKLIST_DTL_INFO
					       (DL_EXPD_ALTR_NO,
					        QLTY_VEHL_CD,
					        LANG_CD,
					        PPRR_EENO,
					        FRAM_DTM,
					        UPDR_EENO,
					        MDFY_DTM
					       )
					       VALUES
					       (V_EXPD_ALTR_NO,
					        V_VEHL_LIST(VEHL_NUM),
					        V_LANG_LIST(LANG_NUM),
					        P_USER_EENO,
					        SYSDATE,
					        P_USER_EENO,
					        SYSDATE
					       );
						
						END IF;
						
					 END IF;
					 
				 END LOOP;
				 
			 END LOOP;
			 
		  END IF;
		  
		END SP_CHKLIST_INFO_SAVE;
        
		--법규및 변경관리에서 처리(저장)된 EO번호 내역을 보관					   								   
		PROCEDURE SP_CHKLIST_EONO_SAVE(P_EXPD_ALTR_NO VARCHAR2, 
			  					       P_ALTR_SBC     VARCHAR2,
									   P_USER_EENO    VARCHAR2)
		IS
		  
		  V_CURR_IDX PLS_INTEGER;
		  V_EO_NO    VARCHAR2(100);
		  V_CNT		 NUMBER;
		  
		BEGIN
			 
			 V_CURR_IDX := INSTR(P_ALTR_SBC, '-');
			 
			 IF V_CURR_IDX > 0 AND V_CURR_IDX <= 101 THEN
			 	
				V_EO_NO := TRIM(SUBSTR(P_ALTR_SBC, 1, V_CURR_IDX - 1));
				
				IF V_EO_NO IS NOT NULL THEN
				   
				   IF V_EO_NO <> '' THEN
				   	  
					  SELECT COUNT(*)
					  INTO V_CNT
					  FROM TB_EO_CD_INFO
					  WHERE DL_EXPD_ALTR_NO = P_EXPD_ALTR_NO
					  AND EO_CD = V_EO_NO;
					  
					  IF V_CNT = 0 THEN
					  	 
						 INSERT INTO TB_EO_CD_INFO
						 VALUES(P_EXPD_ALTR_NO,
						 		V_EO_NO,
								P_USER_EENO,
								SYSDATE
							   );
					  END IF;
					  
				   END IF;
				   
				END IF;

			 END IF;
			 
		END SP_CHKLIST_EONO_SAVE;    
		
		--법규및 변경관리 내역에 EO번호가 저장되어 있는지의 여부를 확인 
		--속도개선을 위하여 BOM 차종에 해당하는 품질차종코드를 같이 얻어온다.
	    PROCEDURE SP_CHKLIST_EONO_EXIST(P_PRDN_VEHL_CD VARCHAR2,
                                        P_PRVS_SCN_CD  VARCHAR2, -- A: APS차종, B:생산마스터차종, C:BOM차종 (참고: 코드테이블 '0023') 
									    P_EO_CD		   VARCHAR2,
									    P_VEHL_CD	   OUT VARCHAR2,
			  						    P_EXIST_YN     OUT VARCHAR2)
		IS
		
		  V_CNT NUMBER;
		
		BEGIN
			 
			 PG_COMMON.SP_GET_VEHL_CD_BY_PRDN(P_PRDN_VEHL_CD, P_PRVS_SCN_CD, P_VEHL_CD);
			 
			 SELECT COUNT(*)
			 INTO V_CNT
			 FROM TB_EO_CD_INFO
			 WHERE EO_CD = TRIM(P_EO_CD)
			 AND ROWNUM <= 1;
						  
			 IF V_CNT = 0 THEN
			 	
				P_EXIST_YN := 'N';
			 
			 ELSE
			    
				P_EXIST_YN := 'Y';
				
			 END IF;
						  
		END SP_CHKLIST_EONO_EXIST;
									
       --체크리스트 변경 내역 조회 
	   PROCEDURE SP_GET_CHK_CHANG_LIST(P_MENU_ID 	     VARCHAR2,
								       P_USER_EENO       VARCHAR2,
	   			 					   P_FROM_YMD	     VARCHAR2,
 								       P_TO_YMD          VARCHAR2,
									   P_EXPD_CO_CD      VARCHAR2,
									   P_EXPD_PAC_SCN_CD VARCHAR2,
								       P_VEHL_CD		 VARCHAR2,	
									   P_CHANG_USER_EENO VARCHAR2,
									   P_FROM_NUM        NUMBER,
									   P_TO_NUM          NUMBER,
                                       P_CONTENT         VARCHAR2,
									   P_EXPD_ALTR_NO    VARCHAR2,
									   P_CNT OUT NUMBER,                                                                        
                                       RS 	 OUT REFCUR)
	  IS
	  
	  	V_FROM_MDL_MDY VARCHAR(2);
	 	V_TO_MDL_MDY   VARCHAR(2);
	    
		V_END_NUM      NUMBER;
		
	  BEGIN
	  	   
		   PG_COMMON.SP_GET_VALID_MDL_MDY4(P_FROM_YMD, P_TO_YMD, V_FROM_MDL_MDY, V_TO_MDL_MDY);
		   
		   --[2009/03/18] 차종과 언어가 입력되지 않는 경우가 없다고 함...
		   --그리고 OUTER JOIN으로 처리하는 경우 다른 문제가 발생될수 있음(권한이 없는 차종으로 등록된 내용도 같이 조회됨)
		   --그래서 아래와 같이 불필요한 부분 주석 처리함 
		   
--		   --차종과 관계된 항목이 선택된 경우에는 차종에 관계된 항목만 조회해 준다.
--		   IF P_EXPD_CO_CD = 'ALL' AND P_EXPD_PAC_SCN_CD = 'ALL' AND P_VEHL_CD = 'ALL' THEN
--		   	  
--			  WITH T AS (SELECT A.QLTY_VEHL_CD
--				      	 FROM (SELECT QLTY_VEHL_CD
--                         	   FROM TB_AUTH_VEHL_MGMT
--                               WHERE MENU_ID = PG_COMMON.FU_RPAD(P_MENU_ID, 10)
--                               AND USER_EENO = PG_COMMON.FU_RPAD(P_USER_EENO, 7)
--                               AND QLTY_VEHL_CD = DECODE(P_VEHL_CD, 'ALL', QLTY_VEHL_CD, P_VEHL_CD)
--                               GROUP BY QLTY_VEHL_CD
--							  ) A,
--							  TB_VEHL_MGMT B
--						 WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
--					     AND B.MDL_MDY_CD BETWEEN V_FROM_MDL_MDY AND V_TO_MDL_MDY
--					     AND B.DL_EXPD_CO_CD = DECODE(P_EXPD_CO_CD, 'ALL', DL_EXPD_CO_CD, P_EXPD_CO_CD)
--                         AND B.DL_EXPD_PAC_SCN_CD = DECODE(P_EXPD_PAC_SCN_CD, 'ALL', DL_EXPD_PAC_SCN_CD, P_EXPD_PAC_SCN_CD)
--						 AND B.USE_YN = 'Y'
--					     GROUP BY A.QLTY_VEHL_CD
--                        )
--		      SELECT COUNT(*)
--		      INTO P_CNT
--		      FROM TB_CHKLIST_INFO A,
--		   		   (SELECT A.DL_EXPD_ALTR_NO,
--						   A.QLTY_VEHL_CD
--				    FROM TB_CHKLIST_DTL_INFO A,
--					     T B
--				    WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
--				    GROUP BY A.DL_EXPD_ALTR_NO, A.QLTY_VEHL_CD
--				   ) B
--		      WHERE A.DL_EXPD_ALTR_NO = B.DL_EXPD_ALTR_NO(+)
--		      AND A.ALTR_YMD BETWEEN P_FROM_YMD AND P_TO_YMD
--		      AND A.CHGR_EENO = DECODE(P_CHANG_USER_EENO, '', A.CHGR_EENO, PG_COMMON.FU_RPAD(P_CHANG_USER_EENO, 7))
--              AND UPPER(A.ALTR_SBC) LIKE '%' || P_CONTENT || '%'
--			  AND A.DL_EXPD_ALTR_NO LIKE DECODE(P_EXPD_ALTR_NO, '', A.DL_EXPD_ALTR_NO, P_EXPD_ALTR_NO || '%')
--			  AND A.DEL_YN = 'N';
--		   
--		      IF P_TO_NUM > P_CNT THEN
--		   	  
--			     V_END_NUM := P_CNT;
--			  
--		      ELSE
--		      
--			     V_END_NUM := P_TO_NUM;
--			  
--		      END IF;
--		   
--	  	      OPEN RS FOR
--		   		   WITH T AS (SELECT A.QLTY_VEHL_CD
--				      	  	  FROM (SELECT QLTY_VEHL_CD
--                         	   	    FROM TB_AUTH_VEHL_MGMT
--                               		WHERE MENU_ID = PG_COMMON.FU_RPAD(P_MENU_ID, 10)
--                               		AND USER_EENO = PG_COMMON.FU_RPAD(P_USER_EENO, 7)
--                               		AND QLTY_VEHL_CD = DECODE(P_VEHL_CD, 'ALL', QLTY_VEHL_CD, P_VEHL_CD)
--                               		GROUP BY QLTY_VEHL_CD
--							       ) A,
--							  	   TB_VEHL_MGMT B
--						      WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
--					     	  AND B.MDL_MDY_CD BETWEEN V_FROM_MDL_MDY AND V_TO_MDL_MDY
--					     	  AND B.DL_EXPD_CO_CD = DECODE(P_EXPD_CO_CD, 'ALL', DL_EXPD_CO_CD, P_EXPD_CO_CD)
--                         	  AND B.DL_EXPD_PAC_SCN_CD = DECODE(P_EXPD_PAC_SCN_CD, 'ALL', DL_EXPD_PAC_SCN_CD, P_EXPD_PAC_SCN_CD)
--						 	  AND B.USE_YN = 'Y'
--					     	  GROUP BY A.QLTY_VEHL_CD
--                            ),
--				       U AS (--페이징처리를 위하여 추가된 부분임.
--					  	     SELECT DL_EXPD_ALTR_NO,
--						  		    QLTY_VEHL_CD
--						     FROM (SELECT DL_EXPD_ALTR_NO,
--							              QLTY_VEHL_CD,
--										  ROWNUM AS ROWNM
--								   FROM (SELECT A.DL_EXPD_ALTR_NO,
--						  	                    B.QLTY_VEHL_CD
--					                     FROM TB_CHKLIST_INFO A,
--									          (SELECT A.DL_EXPD_ALTR_NO,
--						  	   		                  A.QLTY_VEHL_CD
--								               FROM TB_CHKLIST_DTL_INFO A,
--					                                T B
--				 					           WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
--				 					           GROUP BY A.DL_EXPD_ALTR_NO, A.QLTY_VEHL_CD
--							   		          ) B
--								         WHERE A.DL_EXPD_ALTR_NO = B.DL_EXPD_ALTR_NO(+)
--								         AND A.ALTR_YMD BETWEEN P_FROM_YMD AND P_TO_YMD
--				 				         AND A.CHGR_EENO = DECODE(P_CHANG_USER_EENO, '', A.CHGR_EENO, PG_COMMON.FU_RPAD(P_CHANG_USER_EENO, 7))
--								         AND A.DEL_YN = 'N'
--                                         AND UPPER(A.ALTR_SBC) LIKE '%' || P_CONTENT || '%'
--										 AND A.DL_EXPD_ALTR_NO LIKE DECODE(P_EXPD_ALTR_NO, '', A.DL_EXPD_ALTR_NO, P_EXPD_ALTR_NO || '%')
--								         ORDER BY A.DL_EXPD_ALTR_NO, B.QLTY_VEHL_CD
--										)
--							      )
--						     WHERE ROWNM BETWEEN P_FROM_NUM AND V_END_NUM
--				 	  	    )
--				    SELECT A.DL_EXPD_ALTR_NO,
--				 		   B.QLTY_VEHL_CD,
--						   FU_GET_LANG_LIST_BY_VEHL(A.DL_EXPD_ALTR_NO, B.QLTY_VEHL_CD) AS LANG_CD,
--						   FU_GET_PBCN_LIST_BY_VEHL(A.DL_EXPD_ALTR_NO, B.QLTY_VEHL_CD) AS N_PRNT_PBCN_NO,
--				 		   TO_CHAR(TO_DATE(ALTR_YMD, 'YYYYMMDD'),'YYYY-MM-DD') AS ALTR_YMD,
--						   RCPM_SHAP_CD,
--						   DSPP_NM,
--						   CHGR_EENO,
--						   C.USER_NM AS CHGR_NM,
--						   CRGR_NM,
--                           N1AFP2_ADR,
--						   N1AFP2_ADR1,
--						   ALTR_SBC
--				    FROM TB_CHKLIST_INFO A,
--				         U B,
--						 TB_USR_MGMT C
--				    WHERE A.DL_EXPD_ALTR_NO = B.DL_EXPD_ALTR_NO
--					AND A.CHGR_EENO = C.USER_EENO
--				    --GROUP BY A.DL_EXPD_ALTR_NO, B.QLTY_VEHL_CD
--				    ORDER BY A.DL_EXPD_ALTR_NO, B.QLTY_VEHL_CD
--				    ;				 
--				 
--		   ELSE
		   
		   	   WITH T AS (SELECT A.QLTY_VEHL_CD
				      	  FROM (SELECT QLTY_VEHL_CD
                         	    FROM TB_AUTH_VEHL_MGMT
                                WHERE MENU_ID = PG_COMMON.FU_RPAD(P_MENU_ID, 10)
                                AND USER_EENO = PG_COMMON.FU_RPAD(P_USER_EENO, 7)
                               	AND QLTY_VEHL_CD = DECODE(P_VEHL_CD, 'ALL', QLTY_VEHL_CD, P_VEHL_CD)
                               	GROUP BY QLTY_VEHL_CD
							   ) A,
							   TB_VEHL_MGMT B
						  WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
					      AND B.MDL_MDY_CD BETWEEN V_FROM_MDL_MDY AND V_TO_MDL_MDY
					      AND B.DL_EXPD_CO_CD = DECODE(P_EXPD_CO_CD, 'ALL', DL_EXPD_CO_CD, P_EXPD_CO_CD)
                          AND B.DL_EXPD_PAC_SCN_CD = DECODE(P_EXPD_PAC_SCN_CD, 'ALL', DL_EXPD_PAC_SCN_CD, P_EXPD_PAC_SCN_CD)
						  AND B.USE_YN = 'Y'
					      GROUP BY A.QLTY_VEHL_CD
                         )
		      SELECT COUNT(*)
		      INTO P_CNT
		      FROM TB_CHKLIST_INFO A,
		   		   (SELECT A.DL_EXPD_ALTR_NO,
						   A.QLTY_VEHL_CD
				    FROM TB_CHKLIST_DTL_INFO A,
					     T B
				    WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
				    GROUP BY A.DL_EXPD_ALTR_NO, A.QLTY_VEHL_CD
				   ) B
		      WHERE A.DL_EXPD_ALTR_NO = B.DL_EXPD_ALTR_NO
		      AND A.ALTR_YMD BETWEEN P_FROM_YMD AND P_TO_YMD
		      AND A.CHGR_EENO = DECODE(P_CHANG_USER_EENO, '', A.CHGR_EENO, PG_COMMON.FU_RPAD(P_CHANG_USER_EENO, 7))
              AND (UPPER(A.ALTR_SBC) LIKE '%' || UPPER(P_CONTENT) || '%' OR (A.ALTR_SBC IS NULL AND P_CONTENT IS NULL))
			  AND A.DL_EXPD_ALTR_NO LIKE DECODE(P_EXPD_ALTR_NO, '', A.DL_EXPD_ALTR_NO, P_EXPD_ALTR_NO || '%')
			  AND A.DEL_YN = 'N';
		   
		   
		      IF P_TO_NUM > P_CNT THEN
		   	  
			     V_END_NUM := P_CNT;
			  
		      ELSE
		      
			     V_END_NUM := P_TO_NUM;
			  
		      END IF;
		   
	  	      OPEN RS FOR
		   		   WITH T AS (SELECT A.QLTY_VEHL_CD
				      	      FROM (SELECT QLTY_VEHL_CD
                         	   	    FROM TB_AUTH_VEHL_MGMT
                               		WHERE MENU_ID = PG_COMMON.FU_RPAD(P_MENU_ID, 10)
                               		AND USER_EENO = PG_COMMON.FU_RPAD(P_USER_EENO, 7)
                               		AND QLTY_VEHL_CD = DECODE(P_VEHL_CD, 'ALL', QLTY_VEHL_CD, P_VEHL_CD)
                               		GROUP BY QLTY_VEHL_CD
							       ) A,
							       TB_VEHL_MGMT B
						      WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
					     	  AND B.MDL_MDY_CD BETWEEN V_FROM_MDL_MDY AND V_TO_MDL_MDY
					     	  AND B.DL_EXPD_CO_CD = DECODE(P_EXPD_CO_CD, 'ALL', DL_EXPD_CO_CD, P_EXPD_CO_CD)
                         	  AND B.DL_EXPD_PAC_SCN_CD = DECODE(P_EXPD_PAC_SCN_CD, 'ALL', DL_EXPD_PAC_SCN_CD, P_EXPD_PAC_SCN_CD)
						 	  AND B.USE_YN = 'Y'
					     	  GROUP BY A.QLTY_VEHL_CD
                             ),
				       U AS (--페이징처리를 위하여 추가된 부분임.
					  	     SELECT DL_EXPD_ALTR_NO,
						  		    QLTY_VEHL_CD,
									IDX
						     FROM (SELECT DL_EXPD_ALTR_NO,
							              QLTY_VEHL_CD,
										  IDX,
										  ROWNUM AS ROWNM
								   FROM (SELECT A.DL_EXPD_ALTR_NO,
						  	                    B.QLTY_VEHL_CD,
												CASE WHEN A.RCPM_SHAP_CD = '05' THEN 2 
												     WHEN A.RCPM_SHAP_CD = '06' THEN 0
													 WHEN A.RCPM_SHAP_CD = '07' THEN 1
						   							 ELSE 3
						   						END AS IDX
					                     FROM TB_CHKLIST_INFO A,
									          (SELECT A.DL_EXPD_ALTR_NO,
						  	   		                  A.QLTY_VEHL_CD
								               FROM TB_CHKLIST_DTL_INFO A,
					                                T B
				 					           WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
				 					           GROUP BY A.DL_EXPD_ALTR_NO, A.QLTY_VEHL_CD
							   		          ) B
								         WHERE A.DL_EXPD_ALTR_NO = B.DL_EXPD_ALTR_NO
								         AND A.ALTR_YMD BETWEEN P_FROM_YMD AND P_TO_YMD
				 				         AND A.CHGR_EENO = DECODE(P_CHANG_USER_EENO, '', A.CHGR_EENO, PG_COMMON.FU_RPAD(P_CHANG_USER_EENO, 7))
								         AND A.DEL_YN = 'N'
                                         AND (UPPER(A.ALTR_SBC) LIKE '%' || UPPER(P_CONTENT) || '%' OR (A.ALTR_SBC IS NULL AND P_CONTENT IS NULL))
										 AND A.DL_EXPD_ALTR_NO LIKE DECODE(P_EXPD_ALTR_NO, '', A.DL_EXPD_ALTR_NO, P_EXPD_ALTR_NO || '%')
										 --[변경]. 2010.01.27.김동근 정렬순서 변경 - 변경번호 역순
								         --ORDER BY A.DL_EXPD_ALTR_NO, B.QLTY_VEHL_CD
										 ORDER BY IDX, A.DL_EXPD_ALTR_NO DESC, B.QLTY_VEHL_CD
										)
							      )
						     WHERE ROWNM BETWEEN P_FROM_NUM AND V_END_NUM
				 	  	    )
				    SELECT A.DL_EXPD_ALTR_NO,
				 		   B.QLTY_VEHL_CD,
						   FU_GET_LANG_LIST_BY_VEHL(A.DL_EXPD_ALTR_NO, B.QLTY_VEHL_CD) AS LANG_CD,
						   FU_GET_PBCN_LIST_BY_VEHL(A.DL_EXPD_ALTR_NO, B.QLTY_VEHL_CD) AS N_PRNT_PBCN_NO,
				 		   TO_CHAR(TO_DATE(ALTR_YMD, 'YYYYMMDD'),'YYYY-MM-DD') AS ALTR_YMD,
						   RCPM_SHAP_CD,
						   DSPP_NM,
						   CHGR_EENO,
						   C.USER_NM AS CHGR_NM,
						   CRGR_NM,
                           N1AFP2_ADR,
						   N1AFP2_ADR1,
						   ALTR_SBC,
						   ATTC_YN
				    FROM TB_CHKLIST_INFO A,
				         U B,
						 TB_USR_MGMT C
				    WHERE A.DL_EXPD_ALTR_NO = B.DL_EXPD_ALTR_NO
					AND A.CHGR_EENO = C.USER_EENO
				    --GROUP BY A.DL_EXPD_ALTR_NO, B.QLTY_VEHL_CD
				    --[변경]. 2010.01.27.김동근 정렬순서 변경 - 변경번호 역순
					--ORDER BY A.DL_EXPD_ALTR_NO, B.QLTY_VEHL_CD 
					ORDER BY B.IDX, A.DL_EXPD_ALTR_NO DESC, B.QLTY_VEHL_CD
				    ;				 
					
--		   END IF;

	  END SP_GET_CHK_CHANG_LIST;
	  
	  --변경번호, 차종에 관계된  언어코드 리스트를 얻어오는 함수
	  FUNCTION FU_GET_LANG_LIST_BY_VEHL(P_EXPD_ALTR_NO TB_CHKLIST_DTL_INFO.DL_EXPD_ALTR_NO%TYPE,
			 						    P_QLTY_VEHL_CD TB_CHKLIST_DTL_INFO.QLTY_VEHL_CD%TYPE) RETURN VARCHAR2
	  IS
	  	
		V_LANG_LIST VARCHAR2(8000);
		
		CURSOR CHK_DTL_LANG_LIST IS SELECT LANG_CD
	   	                            FROM TB_CHKLIST_DTL_INFO
									WHERE DL_EXPD_ALTR_NO = P_EXPD_ALTR_NO
									AND QLTY_VEHL_CD = P_QLTY_VEHL_CD
									GROUP BY LANG_CD
									ORDER BY LANG_CD;
											 
	  BEGIN
	  	
		V_LANG_LIST := '';
		
		FOR LANG_LIST IN CHK_DTL_LANG_LIST LOOP
			
			V_LANG_LIST := V_LANG_LIST || LANG_LIST.LANG_CD || ',';
			
		END LOOP;
		
		IF LENGTH(V_LANG_LIST) > 0 THEN
		   
		   V_LANG_LIST := SUBSTR(V_LANG_LIST, 1, LENGTH(V_LANG_LIST) - 1);
		   
		END IF;
		
		RETURN V_LANG_LIST;
		   
	  END FU_GET_LANG_LIST_BY_VEHL;
	  
	  --변경번호, 차종에 관계된  신인쇄발간코드 리스트를 얻어오는 함수 
	  --언어와 신인쇄발간코드를 - 로 구분지어서 표시해 준다. 
	  FUNCTION FU_GET_PBCN_LIST_BY_VEHL(P_EXPD_ALTR_NO TB_CHKLIST_DTL_INFO.DL_EXPD_ALTR_NO%TYPE,
			 						    P_QLTY_VEHL_CD TB_CHKLIST_DTL_INFO.QLTY_VEHL_CD%TYPE) RETURN VARCHAR2
	  IS
	  
	  	V_PBCN_LIST VARCHAR2(8000);
		
		CURSOR CHK_DTL_PBCN_LIST IS SELECT LANG_CD, NVL(SUBSTR(MAX(N_PRNT_PBCN_NO), -3), '') AS N_PRNT_PBCN_NO
	   	                            FROM TB_CHKLIST_DTL_INFO
									WHERE DL_EXPD_ALTR_NO = P_EXPD_ALTR_NO
									AND QLTY_VEHL_CD = P_QLTY_VEHL_CD
									GROUP BY LANG_CD
									ORDER BY LANG_CD;
	  BEGIN
	  	   
		   V_PBCN_LIST := '';
		
		FOR PBCN_LIST IN CHK_DTL_PBCN_LIST LOOP
			
			V_PBCN_LIST := V_PBCN_LIST || PBCN_LIST.LANG_CD || '-' || PBCN_LIST.N_PRNT_PBCN_NO || ',';
			
		END LOOP;
		
		IF LENGTH(V_PBCN_LIST) > 0 THEN
		   
		   V_PBCN_LIST := SUBSTR(V_PBCN_LIST, 1, LENGTH(V_PBCN_LIST) - 1);
		   
		END IF;
		
		RETURN V_PBCN_LIST;
		   
	  END FU_GET_PBCN_LIST_BY_VEHL;
	
									  
      --현재의 사용자가 수정가능한 차종의 리스트를 조회(팝업화면용) 
	  PROCEDURE SP_GET_VEHL_LIST(P_FROM_YMD  VARCHAR2,
 								 P_TO_YMD    VARCHAR2,
								 RS    OUT REFCUR)
	  IS
	  	
		V_FROM_MDL_MDY VARCHAR(2);
	 	V_TO_MDL_MDY   VARCHAR(2);
		
	  BEGIN
	  	   
		   PG_COMMON.SP_GET_VALID_MDL_MDY4(P_FROM_YMD, P_TO_YMD, V_FROM_MDL_MDY, V_TO_MDL_MDY);
		   
		   OPEN RS FOR
		   		
		   		SELECT QLTY_VEHL_CD, 
					   '(' || QLTY_VEHL_CD || ')' || MAX(QLTY_VEHL_NM) AS QLTY_VEHL_NM
				FROM TB_VEHL_MGMT
				WHERE MDL_MDY_CD BETWEEN V_FROM_MDL_MDY AND V_TO_MDL_MDY
				AND USE_YN = 'Y'
				GROUP BY QLTY_VEHL_CD;
				
		   		/**
		   		SELECT B.QLTY_VEHL_CD,
                       '(' || B.QLTY_VEHL_CD || ')' || MAX(B.QLTY_VEHL_NM) AS QLTY_VEHL_NM
                FROM (SELECT QLTY_VEHL_CD
                      FROM TB_AUTH_VEHL_MGMT
                      WHERE MENU_ID = PG_COMMON.FU_RPAD(P_MENU_ID, 10)
                      AND USER_EENO = PG_COMMON.FU_RPAD(P_USER_EENO, 7)
                      AND CL_SCN_CD = 'U'
                     ) A,
                     TB_VEHL_MGMT B 
			    WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
				AND B.USE_YN = 'Y'
				GROUP BY B.QLTY_VEHL_CD; 
			    **/
				
	  END SP_GET_VEHL_LIST;
	  
	  --현재의 사용자가 수정가능한 차종의 리스트를 조회(팝업화면용)2  
	  PROCEDURE SP_GET_VEHL_LIST2(P_MENU_ID 	    VARCHAR2,
								  P_USER_EENO       VARCHAR2,
	  							  P_FROM_YMD        VARCHAR2,
                 			      P_TO_YMD          VARCHAR2,
							      P_EXPD_CO_CD      VARCHAR2,
                			      P_EXPD_PAC_SCN_CD VARCHAR2,
				                  RS OUT REFCUR)
	  IS
	  	
		V_FROM_MDL_MDY VARCHAR(2);
	 	V_TO_MDL_MDY   VARCHAR(2);
		
	  BEGIN
	  	   
		   PG_COMMON.SP_GET_VALID_MDL_MDY4(P_FROM_YMD, P_TO_YMD, V_FROM_MDL_MDY, V_TO_MDL_MDY);
		   
		   OPEN RS FOR
		   		SELECT B.QLTY_VEHL_CD,
					   '(' || B.QLTY_VEHL_CD || ')' || MAX(B.QLTY_VEHL_NM) AS QLTY_VEHL_NM
				FROM (SELECT QLTY_VEHL_CD
                      FROM TB_AUTH_VEHL_MGMT
					  WHERE MENU_ID = PG_COMMON.FU_RPAD(P_MENU_ID, 10)
					  AND USER_EENO = PG_COMMON.FU_RPAD(P_USER_EENO, 7)
					  AND CL_SCN_CD = 'U' 
					  GROUP BY QLTY_VEHL_CD
				     ) A,
					 TB_VEHL_MGMT B
				WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
				AND B.MDL_MDY_CD BETWEEN V_FROM_MDL_MDY AND V_TO_MDL_MDY
				AND B.DL_EXPD_CO_CD = DECODE(P_EXPD_CO_CD, 'ALL', DL_EXPD_CO_CD, P_EXPD_CO_CD)
				AND B.DL_EXPD_PAC_SCN_CD = DECODE(P_EXPD_PAC_SCN_CD, 'ALL', DL_EXPD_PAC_SCN_CD, P_EXPD_PAC_SCN_CD)
				AND B.USE_YN = 'Y'
				GROUP BY B.QLTY_VEHL_CD;
				
		   		/***
		   		SELECT QLTY_VEHL_CD, 
					   '(' || QLTY_VEHL_CD || ')' || MAX(QLTY_VEHL_NM) AS QLTY_VEHL_NM
				FROM TB_VEHL_MGMT
				WHERE MDL_MDY_CD BETWEEN V_FROM_MDL_MDY AND V_TO_MDL_MDY
				AND DL_EXPD_CO_CD = DECODE(P_EXPD_CO_CD, 'ALL', DL_EXPD_CO_CD, P_EXPD_CO_CD)
                AND DL_EXPD_PAC_SCN_CD = DECODE(P_EXPD_PAC_SCN_CD, 'ALL', DL_EXPD_PAC_SCN_CD, P_EXPD_PAC_SCN_CD)
				AND USE_YN = 'Y'
				GROUP BY QLTY_VEHL_CD;
				***/
				
	  END SP_GET_VEHL_LIST2;
							   
	  --현재 선택된 차종내역에 해당하는 언어코드 리스트를 조회(팝업화면용) 
	  PROCEDURE SP_GET_LANG_LIST(P_FROM_YMD	 VARCHAR2,
 								 P_TO_YMD    VARCHAR2,
							     P_VEHL_LIST VARCHAR2,
							     RS 	   OUT REFCUR)
	  IS

		V_FROM_MDL_MDY VARCHAR(2);
	 	V_TO_MDL_MDY   VARCHAR(2);
		
		V_QUERY        VARCHAR2(8000);
		
		V_VEHL_LIST    VARCHAR2(8000);
		
	  BEGIN
	  	   
		   PG_COMMON.SP_GET_VALID_MDL_MDY4(P_FROM_YMD, P_TO_YMD, V_FROM_MDL_MDY, V_TO_MDL_MDY);
		   
		   V_VEHL_LIST := PG_COMMON.FU_GET_VARCHAR_LIST(P_VEHL_LIST);
		   
		   V_QUERY :=            'SELECT LANG_CD, MAX(LANG_CD_NM) AS LANG_CD_NM ';
		   V_QUERY := V_QUERY || 'FROM TB_LANG_MGMT ';
		   V_QUERY := V_QUERY || 'WHERE MDL_MDY_CD BETWEEN ''' || V_FROM_MDL_MDY || ''' AND ''' || V_TO_MDL_MDY  || ''' ';
		   
		   IF V_VEHL_LIST IS NOT NULL AND LENGTH(V_VEHL_LIST) > 0 THEN
		   	  
			  V_QUERY := V_QUERY || 'AND QLTY_VEHL_CD IN (' || V_VEHL_LIST || ') ';
			  
		   END IF;
		   
		   V_QUERY := V_QUERY || 'AND USE_YN = ''Y'' '; 
		   V_QUERY := V_QUERY || 'GROUP BY LANG_CD ';
		   
		   OPEN RS FOR V_QUERY;
		
	  END SP_GET_LANG_LIST;
	  
      --조회화면 컬럼 헤더에 표시될 언어코드 리스트 조회 
	  PROCEDURE SP_GET_HEADER_LANG_LIST(P_FROM_YMD   VARCHAR2,
                 					    P_TO_YMD     VARCHAR2,
					                    RS OUT REFCUR)
      IS
	  	
		V_FROM_MDL_MDY VARCHAR(2);
	 	V_TO_MDL_MDY   VARCHAR(2);
		
	  BEGIN
	  	   
		   PG_COMMON.SP_GET_VALID_MDL_MDY4(P_FROM_YMD, P_TO_YMD, V_FROM_MDL_MDY, V_TO_MDL_MDY);
		   	  	   
		   OPEN RS FOR
		   		SELECT LANG_CD, MAX(LANG_CD_NM) AS LANG_CD_NM
				FROM TB_LANG_MGMT
				WHERE MDL_MDY_CD BETWEEN V_FROM_MDL_MDY AND V_TO_MDL_MDY
				AND USE_YN = 'Y'
				GROUP BY LANG_CD;
				
		   		/**
		   		SELECT C.LANG_CD AS LANG_CD
                FROM (SELECT QLTY_VEHL_CD
                      FROM TB_AUTH_VEHL_MGMT
                      WHERE MENU_ID = PG_COMMON.FU_RPAD(P_MENU_ID, 10)
                      AND USER_EENO = PG_COMMON.FU_RPAD(P_USER_EENO, 7)
                      GROUP BY QLTY_VEHL_CD
                     ) A,
                     TB_VEHL_MGMT B,
					 TB_LANG_MGMT C
                WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
				AND A.QLTY_VEHL_CD = C.QLTY_VEHL_CD
			    AND B.MDL_MDY_CD = C.MDL_MDY_CD
			    GROUP BY C.LANG_CD
				ORDER BY C.LANG_CD; 
			    **/
						   
	  END SP_GET_HEADER_LANG_LIST;
      
      --체크리스트 파일이름 조회 
	PROCEDURE SP_GET_CHKLIST_FILE_NAME(P_DL_EXPD_ALTR_NO   VARCHAR2,
					                   P_N1AFP2_ADR    OUT VARCHAR2)
    IS
    
    BEGIN 
        
        SELECT NVL(N1AFP2_ADR,'ZZ') || '!' || NVL(N1AFP2_ADR1,'ZZ') INTO P_N1AFP2_ADR FROM TB_CHKLIST_INFO
        WHERE DL_EXPD_ALTR_NO = P_DL_EXPD_ALTR_NO;
        
    END SP_GET_CHKLIST_FILE_NAME;
                                       
     --체크리스트 파일이름 수정 
	PROCEDURE SP_CHKLIST_FILE_NAME_SAVE(P_DL_EXPD_ALTR_NO   VARCHAR2,
                                        P_N1AFP2_ADR VARCHAR2,
                                        P_N1AFP2_ADR1 VARCHAR2)
    IS
    
    BEGIN
        
        UPDATE TB_CHKLIST_INFO
        SET N1AFP2_ADR = P_N1AFP2_ADR,  N1AFP2_ADR1 = P_N1AFP2_ADR1
        WHERE DL_EXPD_ALTR_NO = P_DL_EXPD_ALTR_NO;
        
    END SP_CHKLIST_FILE_NAME_SAVE;
	   	  
END PG_CHK_LIST_CHANG_INFO;