CREATE OR REPLACE PACKAGE BODY PG_SFTY_IV_MGMT AS
  
  /**
  -- 안전재고관리 조건정보검색
  PROCEDURE SP_SFTY_IV_MGMT_LIST(P_DL_EXPD_PRVS_CD IN VARCHAR2,
                                 P_DL_EXPD_PAC_SCN_CD IN VARCHAR2,
                                 P_DL_EXPD_PDI_CD IN VARCHAR2,
                                 P_UPDR_EENO IN VARCHAR2,
                                 RS OUT REFCUR) 
     AS
  BEGIN
    OPEN RS FOR
     SELECT * FROM(       
         SELECT
             A.DL_EXPD_PRVS_CD AS DL_EXPD_PRVS_CD,
             A.DL_EXPD_PRVS_NM AS DL_EXPD_PRVS_NM, 
             B.QLTY_VEHL_CD AS QLTY_VEHL_CD,
             B.QLTY_VEHL_NM AS QLTY_VEHL_NM,
             B.MDL_MDY_CD AS MDL_MDY_CD, 
             C.LANG_CD AS LANG_CD,
             C.LANG_CD_NM AS LANG_CD_NM,
             C.DL_EXPD_REGN_CD AS DL_EXPD_REGN_CD,
             D.MO_AVG_ORD_QTY AS MO_AVG_ORD_QTY,
             D.MAPP1_QTY AS MAPP1_QTY,
             D.MO_AVG_PRDN_QTY AS MO_AVG_PRDN_QTY,
             D.TSID141_QTY AS TSID141_QTY,
             D.TSID31_QTY AS TSID31_QTY,
             D.DSID141_QTY AS DSID141_QTY,
             D.DSID31_QTY AS DSID31_QTY,
             D.USE_YN AS USE_YN,
             D.PPRR_EENO AS PPRR_EENO,
             D.FRAM_DTM AS FRAM_DTM,
             E.DL_EXPD_PRVS_NM AS DL_EXPD_REGN_NM
           FROM 
             TB_CODE_MGMT A,
             TB_VEHL_MGMT B,
             TB_LANG_MGMT C,           
             TB_SFTY_IV_MGMT D,
             TB_CODE_MGMT E
            WHERE     
               A.DL_EXPD_G_CD = '0003'
            AND
               A.DL_EXPD_PRVS_CD = B.DL_EXPD_CO_CD
            AND 
               E.DL_EXPD_G_CD = '0005'
            AND
               E.DL_EXPD_PRVS_CD = B.DL_EXPD_PDI_CD 
            AND
               B.QLTY_VEHL_CD = C.QLTY_VEHL_CD 
            AND
               B.MDL_MDY_CD = C.MDL_MDY_CD
            AND   
               C.QLTY_VEHL_CD = D.QLTY_VEHL_CD
            AND
               C.MDL_MDY_CD = D.MDL_MDY_CD
            AND
               C.LANG_CD = D.LANG_CD             
            AND			
              B.DL_EXPD_CO_CD = DECODE(P_DL_EXPD_PRVS_CD, 'ALL', B.DL_EXPD_CO_CD, P_DL_EXPD_PRVS_CD)
            AND
              B.DL_EXPD_PDI_CD = DECODE(P_DL_EXPD_PDI_CD, 'ALL', B.DL_EXPD_PDI_CD, P_DL_EXPD_PDI_CD)
            AND
              B.DL_EXPD_PAC_SCN_CD = DECODE(P_DL_EXPD_PAC_SCN_CD, 'ALL', B.DL_EXPD_PAC_SCN_CD, P_DL_EXPD_PAC_SCN_CD)
            AND
              D.UPDR_EENO = DECODE(P_UPDR_EENO, '', D.UPDR_EENO, PG_COMMON.FU_RPAD(P_UPDR_EENO, 7))           
            ORDER BY
              D.FRAM_DTM
            DESC);
   END SP_SFTY_IV_MGMT_LIST;
   **/
   
  -- 안전재고관리 조건정보검색2 
  PROCEDURE SP_SFTY_IV_MGMT_LIST2(P_MENU_ID 		   VARCHAR2,
							  	  P_USER_EENO 	       VARCHAR2,
  								  P_DL_EXPD_PRVS_CD    IN VARCHAR2,
                                  P_DL_EXPD_PAC_SCN_CD IN VARCHAR2,
                                  P_DL_EXPD_PDI_CD     IN VARCHAR2,
                                  P_UPDR_EENO          IN VARCHAR2,
                                  RS OUT REFCUR)
  IS
  	
	V_FROM_MDL_MDY VARCHAR(2);
	V_TO_MDL_MDY   VARCHAR(2);
	 
  BEGIN
  	   
	   PG_COMMON.SP_GET_VALID_MDL_MDY4(TO_CHAR(SYSDATE, 'YYYYMMDD'), '', V_FROM_MDL_MDY, V_TO_MDL_MDY);
	   
	   OPEN RS FOR
       		SELECT A.DL_EXPD_PRVS_CD AS DL_EXPD_PRVS_CD,
             	   A.DL_EXPD_PRVS_NM AS DL_EXPD_PRVS_NM, 
             	   B.QLTY_VEHL_CD AS QLTY_VEHL_CD,
             	   '(' || B.QLTY_VEHL_CD || ')' || B.QLTY_VEHL_NM AS QLTY_VEHL_NM,
             	   B.MDL_MDY_CD AS MDL_MDY_CD, 
             	   C.LANG_CD AS LANG_CD,
             	   C.LANG_CD_NM AS LANG_CD_NM,
             	   C.DL_EXPD_REGN_CD AS DL_EXPD_REGN_CD,
             	   NVL(G.TMM_ORD_QTY, 0) AS MO_AVG_ORD_QTY,
             	   NVL(G.TMM_PRDN_PLN_QTY, 0) AS MAPP1_QTY,
             	   NVL(G.MTH3_MO_AVG_TRWI_QTY, 0) AS MO_AVG_PRDN_QTY,
             	   NVL(G.YER1_DLY_AVG_TRWI_QTY * 14, 0) AS TSID141_QTY,
             	   NVL(G.YER1_DLY_AVG_TRWI_QTY * 3, 0) AS TSID31_QTY,
             	   D.DSID141_QTY AS DSID141_QTY,
             	   D.DSID31_QTY AS DSID31_QTY,
             	   D.USE_YN AS USE_YN,
             	   D.PPRR_EENO AS PPRR_EENO,
             	   D.FRAM_DTM AS FRAM_DTM,
             	   E.DL_EXPD_PRVS_NM AS DL_EXPD_REGN_NM
             FROM TB_CODE_MGMT A,
             	  TB_VEHL_MGMT B,
             	  TB_LANG_MGMT C,           
             	  TB_SFTY_IV_MGMT D,
             	  TB_CODE_MGMT E,
				  (SELECT QLTY_VEHL_CD
                   FROM TB_AUTH_VEHL_MGMT
                   WHERE MENU_ID = PG_COMMON.FU_RPAD(P_MENU_ID, 10)
                   AND USER_EENO = PG_COMMON.FU_RPAD(P_USER_EENO, 7)
                   GROUP BY QLTY_VEHL_CD
                  ) F,
				  TB_APS_PROD_SUM_INFO G
             WHERE A.DL_EXPD_G_CD = '0003'
             AND A.DL_EXPD_PRVS_CD = B.DL_EXPD_CO_CD
             AND E.DL_EXPD_G_CD = '0005'
             AND E.DL_EXPD_PRVS_CD = B.DL_EXPD_PDI_CD 
             AND B.QLTY_VEHL_CD = C.QLTY_VEHL_CD 
             AND B.MDL_MDY_CD = C.MDL_MDY_CD
             AND C.QLTY_VEHL_CD = D.QLTY_VEHL_CD
             AND C.MDL_MDY_CD = D.MDL_MDY_CD
             AND C.LANG_CD = D.LANG_CD
			 AND C.QLTY_VEHL_CD = G.QLTY_VEHL_CD
			 AND C.MDL_MDY_CD = G.MDL_MDY_CD
			 AND C.LANG_CD = G.LANG_CD
			 AND G.APL_YMD = TO_CHAR(SYSDATE, 'YYYYMMDD')
			 AND B.QLTY_VEHL_CD = F.QLTY_VEHL_CD
			 AND B.MDL_MDY_CD BETWEEN V_FROM_MDL_MDY AND V_TO_MDL_MDY
			 AND B.USE_YN = 'Y'
			 AND C.USE_YN = 'Y'    
             AND B.DL_EXPD_CO_CD = DECODE(P_DL_EXPD_PRVS_CD, 'ALL', B.DL_EXPD_CO_CD, P_DL_EXPD_PRVS_CD)
             AND B.DL_EXPD_PDI_CD = DECODE(P_DL_EXPD_PDI_CD, 'ALL', B.DL_EXPD_PDI_CD, P_DL_EXPD_PDI_CD)
             AND B.DL_EXPD_PAC_SCN_CD = DECODE(P_DL_EXPD_PAC_SCN_CD, 'ALL', B.DL_EXPD_PAC_SCN_CD, P_DL_EXPD_PAC_SCN_CD)
             AND D.UPDR_EENO = DECODE(P_UPDR_EENO, '', D.UPDR_EENO, PG_COMMON.FU_RPAD(P_UPDR_EENO, 7))           
             --ORDER BY E.SORT_SN, B.QLTY_VEHL_CD, C.SORT_SN, B.MDL_MDY_CD;
			 ORDER BY B.QLTY_VEHL_CD, C.SORT_SN, B.MDL_MDY_CD;
			
  END SP_SFTY_IV_MGMT_LIST2;
  
   -- 안전재고관리 정보입력
  PROCEDURE SP_INSERT(P_QLTY_VEHL_CD IN VARCHAR2,
                      P_MDL_MDY_CD IN VARCHAR2,
                      P_LANG_CD IN VARCHAR2,             
                      P_DSID141_QTY IN NUMBER,
                      P_DSID31_QTY IN NUMBER,
                      P_USE_YN IN VARCHAR2,
                      P_PPRR_EENO IN VARCHAR2,
                      P_UPDR_EENO IN VARCHAR2)
    IS
  BEGIN
     INSERT INTO
      TB_SFTY_IV_MGMT(QLTY_VEHL_CD,
                      MDL_MDY_CD,   
                      LANG_CD,                    
                      DSID141_QTY,
                      DSID31_QTY,
                      USE_YN,
                      PPRR_EENO,
                      FRAM_DTM,
                      UPDR_EENO,
                      MDFY_DTM)
                              VALUES (P_QLTY_VEHL_CD,
                                      P_MDL_MDY_CD,
                                      P_LANG_CD,
                                      P_DSID141_QTY,
                                      P_DSID31_QTY,
                                      P_USE_YN,
                                      P_PPRR_EENO,
                                      SYSDATE,
                                      P_UPDR_EENO,
                                      SYSDATE);
   
  END SP_INSERT;    
  
  -- 안전재고관리 수정내용검색
  PROCEDURE SP_UPDATE_VIEW(P_QLTY_VEHL_CD IN VARCHAR2,
                           P_MDL_MDY_CD IN VARCHAR2,
                           P_LANG_CD IN VARCHAR2,
                           RS OUT REFCUR)
    IS
  BEGIN
    OPEN RS FOR
      SELECT
        QLTY_VEHL_CD,
        MDL_MDY_CD,
        LANG_CD,     
        DSID141_QTY,
        DSID31_QTY,
        USE_YN
      FROM
        TB_SFTY_IV_MGMT
      WHERE
        TB_SFTY_IV_MGMT.QLTY_VEHL_CD = P_QLTY_VEHL_CD
      AND
        TB_SFTY_IV_MGMT.MDL_MDY_CD = P_MDL_MDY_CD
      AND
        TB_SFTY_IV_MGMT.LANG_CD = P_LANG_CD;
    END SP_UPDATE_VIEW;      
  
   -- 안전재고관리 정보수정                        
   PROCEDURE SP_UPDATE(P_QLTY_VEHL_CD IN VARCHAR2,
                       P_MDL_MDY_CD IN VARCHAR2,
                       P_LANG_CD IN VARCHAR2,
                       P_DSID141_QTY IN NUMBER,
                       P_DSID31_QTY IN NUMBER,
                       P_USE_YN IN VARCHAR2,
                       P_UPDR_EENO IN VARCHAR2)
    IS  
   BEGIN
      UPDATE
        TB_SFTY_IV_MGMT
      SET
        DSID141_QTY = P_DSID141_QTY,
        DSID31_QTY = P_DSID31_QTY,
        USE_YN = P_USE_YN,
        UPDR_EENO = P_UPDR_EENO,
        MDFY_DTM = SYSDATE
      WHERE
        QLTY_VEHL_CD = P_QLTY_VEHL_CD
      AND
        MDL_MDY_CD = P_MDL_MDY_CD
      AND
        LANG_CD = P_LANG_CD;
    END SP_UPDATE;
  
  -- 안전재고관리 삭제(사용안함으로 UPDATE)
  PROCEDURE SP_DELETE(P_QLTY_VEHL_CD IN VARCHAR2,
                      P_MDL_MDY_CD IN VARCHAR2,
                      P_LANG_CD IN VARCHAR2)
    AS
  BEGIN
    UPDATE 
      TB_SFTY_IV_MGMT
    SET
      USE_YN = 'N'
    WHERE
      QLTY_VEHL_CD = P_QLTY_VEHL_CD
    AND
      MDL_MDY_CD = P_MDL_MDY_CD
    AND
      LANG_CD = P_LANG_CD;
  END SP_DELETE;  

  -- 안전재고관리 정보삭제(실제삭제)
  PROCEDURE SP_REAL_DELETE(P_QLTY_VEHL_CD IN VARCHAR2,
                           P_MDL_MDY_CD IN VARCHAR2,
                           P_LANG_CD IN VARCHAR2)
    IS
   BEGIN
    DELETE FROM    
        TB_SFTY_IV_MGMT
      WHERE
        QLTY_VEHL_CD = P_QLTY_VEHL_CD
      AND
        MDL_MDY_CD = P_MDL_MDY_CD
      AND
        LANG_CD = P_LANG_CD;
    END SP_REAL_DELETE;    

END PG_SFTY_IV_MGMT;