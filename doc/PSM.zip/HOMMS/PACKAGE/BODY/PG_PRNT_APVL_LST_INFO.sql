CREATE OR REPLACE PACKAGE BODY PG_PRNT_APVL_LST_INFO AS
	   
	   --제작승인 내역 조회 
	   PROCEDURE SP_GET_PRNT_APVL_INFO(P_MENU_ID 	    VARCHAR2,
								       P_USER_EENO      VARCHAR2,
									   P_PDI_CD	        VARCHAR2,
	   			 					   P_VEHL_CD	    VARCHAR2,
	   			 	                   P_MDL_MDY_CD     VARCHAR2,
									   P_REGN_CD		VARCHAR2,
					                   P_LANG_CD	    VARCHAR2,
					                   P_N_PRNT_PBCN_NO VARCHAR2,
									   P_FROM_YMD	    VARCHAR2,
									   P_TO_YMD		    VARCHAR2,
									   P_I_WAY_CD       VARCHAR2,
									   P_PRNT_WAY_CD2   VARCHAR2,
									   P_DEPQ1_CD       VARCHAR2,
									   --P_FROM_NUM NUMBER,
							 		   --P_TO_NUM   NUMBER,
									   --P_CNT OUT NUMBER,
					                   RS    OUT REFCUR)
	   IS
	   	 
		 V_FROM_MDL_MDY VARCHAR(2);
	 	 V_TO_MDL_MDY   VARCHAR(2);
		 
		 --V_END_NUM      NUMBER;
		 
	   BEGIN
	   		
			PG_COMMON.SP_GET_VALID_MDL_MDY4(P_FROM_YMD, P_TO_YMD, V_FROM_MDL_MDY, V_TO_MDL_MDY);
			
			/**
			WITH T AS (SELECT C.QLTY_VEHL_CD,
                              C.MDL_MDY_CD,
                              C.LANG_CD
                       FROM (SELECT QLTY_VEHL_CD
                             FROM TB_AUTH_VEHL_MGMT
                             WHERE MENU_ID = PG_COMMON.FU_RPAD(P_MENU_ID, 10)
                             AND USER_EENO = PG_COMMON.FU_RPAD(P_USER_EENO, 7)
                             AND QLTY_VEHL_CD = DECODE(P_VEHL_CD, 'ALL', QLTY_VEHL_CD, P_VEHL_CD)
                             GROUP BY QLTY_VEHL_CD
                            ) A,
                            TB_VEHL_MGMT B,
                            TB_LANG_MGMT C
                       WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
                       AND A.QLTY_VEHL_CD = C.QLTY_VEHL_CD
                       AND B.MDL_MDY_CD = C.MDL_MDY_CD
                       AND B.MDL_MDY_CD BETWEEN V_FROM_MDL_MDY AND V_TO_MDL_MDY
                       AND B.MDL_MDY_CD = DECODE(P_MDL_MDY_CD , '', B.MDL_MDY_CD, P_MDL_MDY_CD)
					   AND B.DL_EXPD_PDI_CD = DECODE(P_PDI_CD, 'ALL', B.DL_EXPD_PDI_CD, P_PDI_CD)
					   AND C.DL_EXPD_REGN_CD = DECODE(P_REGN_CD, 'ALL', C.DL_EXPD_REGN_CD, P_REGN_CD)
                       AND C.LANG_CD = DECODE(P_LANG_CD, 'ALL', C.LANG_CD, P_LANG_CD)
					  )
			SELECT COUNT(*)
			INTO P_CNT
			FROM T A,
				 TB_PRNT_REQ_INFO B,
				 TB_PRNT_BKGD_INFO C
			WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
			AND A.MDL_MDY_CD = B.MDL_MDY_CD
			AND A.LANG_CD = B.LANG_CD
			AND A.QLTY_VEHL_CD = C.QLTY_VEHL_CD
			AND A.MDL_MDY_CD = C.MDL_MDY_CD
			AND A.LANG_CD = C.LANG_CD
			AND B.N_PRNT_PBCN_NO = C.N_PRNT_PBCN_NO
			AND B.N_PRNT_PBCN_NO = DECODE(P_N_PRNT_PBCN_NO, '', B.N_PRNT_PBCN_NO, P_N_PRNT_PBCN_NO)
			AND B.ORDN_RQST_YMD BETWEEN P_FROM_YMD AND P_TO_YMD
			AND C.DL_EXPD_RDCS_ST_CD = '02'; -- 승인된 목록만 가져온다. 
			
			IF P_TO_NUM > P_CNT THEN
		   	  
			  V_END_NUM := P_CNT;
			  
		   ELSE
		      
			  V_END_NUM := P_TO_NUM;
			  
		   END IF;
		   
			**/
			
			OPEN RS FOR
				 WITH T AS (SELECT A.CL_SCN_CD,
			  					   C.QLTY_VEHL_CD,
                                   C.MDL_MDY_CD,
                                   C.LANG_CD,
                                  '(' || C.QLTY_VEHL_CD || ')' || B.QLTY_VEHL_NM AS QLTY_VEHL_NM,
								   C.MDL_MDY_CD || 'MY' AS MDL_MDY_NM,
                                  '(' || C.LANG_CD || ')' || C.LANG_CD_NM AS LANG_CD_NM,
                                   C.DL_EXPD_REGN_CD,
								   C.SORT_SN AS LANG_SORT_SN 
                            FROM (SELECT QLTY_VEHL_CD,
                                         MAX(CL_SCN_CD) AS CL_SCN_CD
                                  FROM TB_AUTH_VEHL_MGMT
                                  WHERE MENU_ID = PG_COMMON.FU_RPAD(P_MENU_ID, 10)
                                  AND USER_EENO = PG_COMMON.FU_RPAD(P_USER_EENO, 7)
                                  AND QLTY_VEHL_CD = DECODE(P_VEHL_CD, 'ALL', QLTY_VEHL_CD, P_VEHL_CD)
                                  GROUP BY QLTY_VEHL_CD
                                 ) A,
                                 TB_VEHL_MGMT B,
                                 TB_LANG_MGMT C
                            WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
                            AND A.QLTY_VEHL_CD = C.QLTY_VEHL_CD
                            AND B.MDL_MDY_CD = C.MDL_MDY_CD
                            AND B.MDL_MDY_CD BETWEEN V_FROM_MDL_MDY AND V_TO_MDL_MDY
                            AND B.MDL_MDY_CD = DECODE(P_MDL_MDY_CD , '', B.MDL_MDY_CD, P_MDL_MDY_CD)
						    AND B.DL_EXPD_PDI_CD = DECODE(P_PDI_CD, 'ALL', B.DL_EXPD_PDI_CD, P_PDI_CD)
						    AND C.DL_EXPD_REGN_CD = DECODE(P_REGN_CD, 'ALL', C.DL_EXPD_REGN_CD, P_REGN_CD)
                            AND C.LANG_CD = DECODE(P_LANG_CD, 'ALL', C.LANG_CD, P_LANG_CD)
							--AND B.USE_YN = 'Y'
							--AND C.USE_YN = 'Y'
					       )
		   		 SELECT A.N_PRNT_PBCN_NO,
				 		D.QLTY_VEHL_NM,
					    D.LANG_CD_NM,
					    TO_CHAR(TO_DATE(B.PRNT_PARR_YMD, 'YYYYMMDD'), 'YYYY-MM-DD') AS PRNT_PARR_YMD,
						--TO_CHAR(TO_DATE(B.ORDN_RQST_YMD, 'YYYYMMDD'), 'YYYY-MM-DD') AS PRNT_PARR_YMD,
					    TO_CHAR(TO_DATE(B.DLVG_PARR_YMD, 'YYYYMMDD'), 'YYYY-MM-DD') AS DLVG_PARR_YMD,
					    B.PRNT_PARR_QTY,
					    B.PRNT_PARR_QTY * B.SALE_UNP AS PRNT_PARR_BGT,
						B.SALE_UNP,
						B.PRTL_IMTR_SBC,
						FU_GET_REVICE_COUNT(A.QLTY_VEHL_CD, A.LANG_CD, A.N_PRNT_PBCN_NO) AS REVISE_QTY,
					    A.QLTY_VEHL_CD,
					    A.MDL_MDY_CD,
					    A.LANG_CD,
						D.CL_SCN_CD,
                        D.DL_EXPD_REGN_CD,
						B.PRTL_IMTR_SBC2
				 FROM (--페이징처리를 위하여 추가된 부분임.
					   SELECT N_PRNT_PBCN_NO,
					          QLTY_VEHL_CD,
							  MDL_MDY_CD,
							  LANG_CD
				       FROM (SELECT N_PRNT_PBCN_NO,
					  	   		    QLTY_VEHL_CD,
								    MDL_MDY_CD,
								    LANG_CD,
					  		        ROWNUM AS ROWNM
							 FROM (SELECT B.N_PRNT_PBCN_NO,
					  	   		          A.QLTY_VEHL_CD,
								          A.MDL_MDY_CD,
								          A.LANG_CD
								   FROM T A,
					  	                TB_PRNT_REQ_INFO B,
						                TB_PRNT_BKGD_INFO C
					               WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
					               AND A.MDL_MDY_CD = B.MDL_MDY_CD
					               AND A.LANG_CD = B.LANG_CD
					         	   AND A.QLTY_VEHL_CD = C.QLTY_VEHL_CD
					         	   AND A.MDL_MDY_CD = C.MDL_MDY_CD
					         	   AND A.LANG_CD = C.LANG_CD
					         	   AND B.N_PRNT_PBCN_NO = C.N_PRNT_PBCN_NO
					         	   AND B.N_PRNT_PBCN_NO = DECODE(P_N_PRNT_PBCN_NO, '', B.N_PRNT_PBCN_NO, P_N_PRNT_PBCN_NO)
					         	   AND B.ORDN_RQST_YMD BETWEEN P_FROM_YMD AND P_TO_YMD
					         	   AND C.DL_EXPD_RDCS_ST_CD = '02' -- 승인된 목록만 가져온다.
								   AND B.I_WAY_CD = DECODE(P_I_WAY_CD, 'ALL', B.I_WAY_CD, P_I_WAY_CD)
								   AND B.PRNT_WAY_CD2 = DECODE(P_PRNT_WAY_CD2, 'ALL', B.PRNT_WAY_CD2, P_PRNT_WAY_CD2)
								   AND B.DEPQ1_CD = DECODE(P_DEPQ1_CD, 'ALL', B.DEPQ1_CD, P_DEPQ1_CD)
								   ORDER BY A.QLTY_VEHL_CD, A.LANG_SORT_SN, C.TRTM_YMD DESC
								  ) 
						   )
					   --WHERE ROWNM BETWEEN P_FROM_NUM AND V_END_NUM 
					  ) A,
					  TB_PRNT_REQ_INFO B,
				      TB_PRNT_BKGD_INFO C,
					  T D
				 WHERE A.N_PRNT_PBCN_NO = B.N_PRNT_PBCN_NO
				 AND A.N_PRNT_PBCN_NO = C.N_PRNT_PBCN_NO
				 AND A.QLTY_VEHL_CD = D.QLTY_VEHL_CD
				 AND A.MDL_MDY_CD = D.MDL_MDY_CD
				 AND A.LANG_CD = D.LANG_CD
				 ORDER BY A.QLTY_VEHL_CD, D.LANG_SORT_SN, C.TRTM_YMD DESC;
 
	   END SP_GET_PRNT_APVL_INFO;
	   
	   --제작승인 내역 조회(엑셀 전용) 									   
	  PROCEDURE SP_GET_PRNT_APVL_INFO_EXCEL(P_MENU_ID 	     VARCHAR2,
								       		P_USER_EENO      VARCHAR2,
									   		P_PDI_CD	     VARCHAR2,
	   			 					   		P_VEHL_CD	     VARCHAR2,
	   			 	                   		P_MDL_MDY_CD     VARCHAR2,
									   		P_REGN_CD		 VARCHAR2,
					                   		P_LANG_CD	     VARCHAR2,
					                   		P_N_PRNT_PBCN_NO VARCHAR2,
									   		P_FROM_YMD	     VARCHAR2,
									   		P_TO_YMD		 VARCHAR2,
											P_I_WAY_CD       VARCHAR2,
									   		P_PRNT_WAY_CD2   VARCHAR2,
									   		P_DEPQ1_CD       VARCHAR2,
					                   		RS    OUT REFCUR)
	  IS
	  	
		V_FROM_MDL_MDY VARCHAR(2);
	 	V_TO_MDL_MDY   VARCHAR(2);
		 
	  BEGIN
	  	   
		   PG_COMMON.SP_GET_VALID_MDL_MDY4(P_FROM_YMD, P_TO_YMD, V_FROM_MDL_MDY, V_TO_MDL_MDY);
		   
		   OPEN RS FOR
				 WITH T AS (SELECT A.CL_SCN_CD,
			  					   C.QLTY_VEHL_CD,
                                   C.MDL_MDY_CD,
                                   C.LANG_CD,
                                  '(' || C.QLTY_VEHL_CD || ')' || B.QLTY_VEHL_NM AS QLTY_VEHL_NM,
								   C.MDL_MDY_CD || 'MY' AS MDL_MDY_NM,
                                  '(' || C.LANG_CD || ')' || C.LANG_CD_NM AS LANG_CD_NM,
                                   C.DL_EXPD_REGN_CD,
								   C.SORT_SN AS LANG_SORT_SN 
                            FROM (SELECT QLTY_VEHL_CD,
                                         MAX(CL_SCN_CD) AS CL_SCN_CD
                                  FROM TB_AUTH_VEHL_MGMT
                                  WHERE MENU_ID = PG_COMMON.FU_RPAD(P_MENU_ID, 10)
                                  AND USER_EENO = PG_COMMON.FU_RPAD(P_USER_EENO, 7)
                                  AND QLTY_VEHL_CD = DECODE(P_VEHL_CD, 'ALL', QLTY_VEHL_CD, P_VEHL_CD)
                                  GROUP BY QLTY_VEHL_CD
                                 ) A,
                                 TB_VEHL_MGMT B,
                                 TB_LANG_MGMT C
                            WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
                            AND A.QLTY_VEHL_CD = C.QLTY_VEHL_CD
                            AND B.MDL_MDY_CD = C.MDL_MDY_CD
                            AND B.MDL_MDY_CD BETWEEN V_FROM_MDL_MDY AND V_TO_MDL_MDY
                            AND B.MDL_MDY_CD = DECODE(P_MDL_MDY_CD , '', B.MDL_MDY_CD, P_MDL_MDY_CD)
						    AND B.DL_EXPD_PDI_CD = DECODE(P_PDI_CD, 'ALL', B.DL_EXPD_PDI_CD, P_PDI_CD)
						    AND C.DL_EXPD_REGN_CD = DECODE(P_REGN_CD, 'ALL', C.DL_EXPD_REGN_CD, P_REGN_CD)
                            AND C.LANG_CD = DECODE(P_LANG_CD, 'ALL', C.LANG_CD, P_LANG_CD)
							--AND B.USE_YN = 'Y'
							--AND C.USE_YN = 'Y'
					       )
				 SELECT A.N_PRNT_PBCN_NO,
				 		C.QLTY_VEHL_NM,
					    C.LANG_CD_NM,
					    TO_CHAR(TO_DATE(A.PRNT_PARR_YMD, 'YYYYMMDD'), 'YYYY-MM-DD') AS PRNT_PARR_YMD,
						--TO_CHAR(TO_DATE(A.ORDN_RQST_YMD, 'YYYYMMDD'), 'YYYY-MM-DD') AS PRNT_PARR_YMD,
					    TO_CHAR(TO_DATE(A.DLVG_PARR_YMD, 'YYYYMMDD'), 'YYYY-MM-DD') AS DLVG_PARR_YMD,
					    A.PRNT_PARR_QTY,
					    A.PRNT_PARR_QTY * A.SALE_UNP AS PRNT_PARR_BGT,
						A.SALE_UNP,
						A.PRTL_IMTR_SBC,
						A.QLTY_VEHL_CD,
					    A.MDL_MDY_CD,
					    A.LANG_CD,
						C.CL_SCN_CD,
                        C.DL_EXPD_REGN_CD,
						A.PRTL_IMTR_SBC2,
						E.DL_EXPD_ALTR_NO,
						E.ALTR_SBC
				 FROM TB_PRNT_REQ_INFO A,
				      TB_PRNT_BKGD_INFO B,
					  T C,
					  TB_CHKLIST_DTL_INFO D,
					  TB_CHKLIST_INFO E
				 WHERE A.N_PRNT_PBCN_NO = B.N_PRNT_PBCN_NO
				 AND A.QLTY_VEHL_CD = C.QLTY_VEHL_CD
				 AND A.MDL_MDY_CD = C.MDL_MDY_CD
				 AND A.LANG_CD = C.LANG_CD
				 AND A.QLTY_VEHL_CD = D.QLTY_VEHL_CD
				 AND A.LANG_CD = D.LANG_CD
				 AND A.N_PRNT_PBCN_NO = D.N_PRNT_PBCN_NO
				 AND D.DL_EXPD_ALTR_NO = E.DL_EXPD_ALTR_NO
				 AND A.N_PRNT_PBCN_NO = DECODE(P_N_PRNT_PBCN_NO, '', A.N_PRNT_PBCN_NO, P_N_PRNT_PBCN_NO)
				 AND A.ORDN_RQST_YMD BETWEEN P_FROM_YMD AND P_TO_YMD
				 AND B.DL_EXPD_RDCS_ST_CD = '02' -- 승인된 목록만 가져온다. 
				 AND A.I_WAY_CD = DECODE(P_I_WAY_CD, 'ALL', A.I_WAY_CD, P_I_WAY_CD)
				 AND A.PRNT_WAY_CD2 = DECODE(P_PRNT_WAY_CD2, 'ALL', A.PRNT_WAY_CD2, P_PRNT_WAY_CD2)
				 AND A.DEPQ1_CD = DECODE(P_DEPQ1_CD, 'ALL', A.DEPQ1_CD, P_DEPQ1_CD)
				 ORDER BY A.QLTY_VEHL_CD, C.LANG_SORT_SN, B.TRTM_YMD DESC, CASE WHEN E.RCPM_SHAP_CD IN ('05', '06', '07') THEN 1 ELSE 2 END, E.DL_EXPD_ALTR_NO;	
				 
	  END SP_GET_PRNT_APVL_INFO_EXCEL;
	  
	  --제작승인 내역 조회(엑셀 전용2) 									   
	  PROCEDURE SP_GET_PRNT_APVL_INFO_EXCEL2(P_MENU_ID 	      VARCHAR2,
								       		 P_USER_EENO      VARCHAR2,
									   		 P_PDI_CD	      VARCHAR2,
	   			 					   		 P_VEHL_CD	      VARCHAR2,
	   			 	                   		 P_MDL_MDY_CD     VARCHAR2,
									   		 P_REGN_CD		  VARCHAR2,
					                   		 P_LANG_CD	      VARCHAR2,
					                   		 P_N_PRNT_PBCN_NO VARCHAR2,
									   		 P_FROM_YMD	      VARCHAR2,
									   		 P_TO_YMD		  VARCHAR2,
											 P_I_WAY_CD       VARCHAR2,
									   		 P_PRNT_WAY_CD2   VARCHAR2,
									   		 P_DEPQ1_CD       VARCHAR2,
					                   		 RS    OUT REFCUR)
	  IS
	  	
		V_FROM_MDL_MDY VARCHAR(2);
	 	V_TO_MDL_MDY   VARCHAR(2);
		 
	  BEGIN
	  	   
		   PG_COMMON.SP_GET_VALID_MDL_MDY4(P_FROM_YMD, P_TO_YMD, V_FROM_MDL_MDY, V_TO_MDL_MDY);
		   
		   OPEN RS FOR
				 WITH T AS (SELECT A.CL_SCN_CD,
			  					   C.QLTY_VEHL_CD,
                                   C.MDL_MDY_CD,
                                   C.LANG_CD,
                                   B.QLTY_VEHL_NM AS QLTY_VEHL_NM,
								   C.MDL_MDY_CD || 'MY' AS MDL_MDY_NM,
                                   C.LANG_CD_NM AS LANG_CD_NM,
                                   C.DL_EXPD_REGN_CD,
								   C.SORT_SN AS LANG_SORT_SN 
                            FROM (SELECT QLTY_VEHL_CD,
                                         MAX(CL_SCN_CD) AS CL_SCN_CD
                                  FROM TB_AUTH_VEHL_MGMT
                                  WHERE MENU_ID = PG_COMMON.FU_RPAD(P_MENU_ID, 10)
                                  AND USER_EENO = PG_COMMON.FU_RPAD(P_USER_EENO, 7)
                                  AND QLTY_VEHL_CD = DECODE(P_VEHL_CD, 'ALL', QLTY_VEHL_CD, P_VEHL_CD)
                                  GROUP BY QLTY_VEHL_CD
                                 ) A,
                                 TB_VEHL_MGMT B,
                                 TB_LANG_MGMT C
                            WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
                            AND A.QLTY_VEHL_CD = C.QLTY_VEHL_CD
                            AND B.MDL_MDY_CD = C.MDL_MDY_CD
                            AND B.MDL_MDY_CD BETWEEN V_FROM_MDL_MDY AND V_TO_MDL_MDY
                            AND B.MDL_MDY_CD = DECODE(P_MDL_MDY_CD , '', B.MDL_MDY_CD, P_MDL_MDY_CD)
						    AND B.DL_EXPD_PDI_CD = DECODE(P_PDI_CD, 'ALL', B.DL_EXPD_PDI_CD, P_PDI_CD)
						    AND C.DL_EXPD_REGN_CD = DECODE(P_REGN_CD, 'ALL', C.DL_EXPD_REGN_CD, P_REGN_CD)
                            AND C.LANG_CD = DECODE(P_LANG_CD, 'ALL', C.LANG_CD, P_LANG_CD)
							--AND B.USE_YN = 'Y'
							--AND C.USE_YN = 'Y'
					       )
		   		 SELECT A.N_PRNT_PBCN_NO,
				 		D.QLTY_VEHL_NM,
					    D.LANG_CD_NM,
					    TO_CHAR(TO_DATE(B.PRNT_PARR_YMD, 'YYYYMMDD'), 'YYYY-MM-DD') AS PRNT_PARR_YMD,
						--TO_CHAR(TO_DATE(B.ORDN_RQST_YMD, 'YYYYMMDD'), 'YYYY-MM-DD') AS PRNT_PARR_YMD,
					    TO_CHAR(TO_DATE(B.DLVG_PARR_YMD, 'YYYYMMDD'), 'YYYY-MM-DD') AS DLVG_PARR_YMD,
					    B.PRNT_PARR_QTY,
					    B.PRNT_PARR_QTY * B.SALE_UNP AS PRNT_PARR_BGT,
						B.SALE_UNP,
						B.PRTL_IMTR_SBC,
						FU_GET_REVICE_COUNT(A.QLTY_VEHL_CD, A.LANG_CD, A.N_PRNT_PBCN_NO) AS REVISE_QTY,
					    A.QLTY_VEHL_CD,
					    A.MDL_MDY_CD,
					    A.LANG_CD,
						D.CL_SCN_CD,
                        D.DL_EXPD_REGN_CD,
						B.PRTL_IMTR_SBC2,
						E.DL_EXPD_PRVS_NM AS I_WAY_NM,
						F.DL_EXPD_PRVS_NM AS PRNT_WAY_NM,
						G.DL_EXPD_PRVS_NM AS DEPQ1_NM,
						H.DL_EXPD_PRVS_NM AS PRNT_WAY_NM2,
						B.PG_MGN_SBC,
						B.PG_NL,
						B.OORD_EDIT_PG_NL,
						B.GRN_DOC_NL,
						B.MDFY_PG_NL,
						DECODE(B.DEPC1_YN, 'Y', '사용', '사용안함') AS DEPC1_NM,
						A.USER_NM,
						A.RNK AS ROWNM
						--A.ROWNM
				 FROM (--페이징처리를 위하여 추가된 부분임.
					   SELECT N_PRNT_PBCN_NO,
					          QLTY_VEHL_CD,
							  MDL_MDY_CD,
							  LANG_CD,
							  USER_NM,
							  RNK,
							  ROWNM
				       FROM (SELECT N_PRNT_PBCN_NO,
					  	   		    QLTY_VEHL_CD,
								    MDL_MDY_CD,
								    LANG_CD,
									USER_NM,
									RNK,
					  		        ROWNUM AS ROWNM
							 FROM (SELECT B.N_PRNT_PBCN_NO,
					  	   		          A.QLTY_VEHL_CD,
								          A.MDL_MDY_CD,
								          A.LANG_CD,
										  MAX(D.USER_NM) AS USER_NM,
										  RANK() OVER (PARTITION BY D.USER_EENO ORDER BY A.QLTY_VEHL_CD, MAX(A.LANG_SORT_SN), MAX(C.TRTM_YMD) DESC) AS RNK
								   FROM T A,
					  	                TB_PRNT_REQ_INFO B,
						                TB_PRNT_BKGD_INFO C,
										TB_USR_MGMT D
					               WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
					               AND A.MDL_MDY_CD = B.MDL_MDY_CD
					               AND A.LANG_CD = B.LANG_CD
					         	   AND A.QLTY_VEHL_CD = C.QLTY_VEHL_CD
					         	   AND A.MDL_MDY_CD = C.MDL_MDY_CD
					         	   AND A.LANG_CD = C.LANG_CD
					         	   AND B.N_PRNT_PBCN_NO = C.N_PRNT_PBCN_NO
					         	   AND B.N_PRNT_PBCN_NO = DECODE(P_N_PRNT_PBCN_NO, '', B.N_PRNT_PBCN_NO, P_N_PRNT_PBCN_NO)
					         	   AND B.ORDN_RQST_YMD BETWEEN P_FROM_YMD AND P_TO_YMD
					         	   AND C.DL_EXPD_RDCS_ST_CD = '02' -- 승인된 목록만 가져온다.
								   AND B.I_WAY_CD = DECODE(P_I_WAY_CD, 'ALL', B.I_WAY_CD, P_I_WAY_CD)
								   AND B.PRNT_WAY_CD2 = DECODE(P_PRNT_WAY_CD2, 'ALL', B.PRNT_WAY_CD2, P_PRNT_WAY_CD2)
								   AND B.DEPQ1_CD = DECODE(P_DEPQ1_CD, 'ALL', B.DEPQ1_CD, P_DEPQ1_CD)
								   AND B.CSET_CRGR_EENO = D.USER_EENO
								   GROUP BY D.USER_EENO, A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD, B.N_PRNT_PBCN_NO
								   ORDER BY D.USER_EENO, A.QLTY_VEHL_CD, MAX(A.LANG_SORT_SN), MAX(C.TRTM_YMD) DESC
								  ) 
						   )
					   --WHERE ROWNM BETWEEN P_FROM_NUM AND V_END_NUM 
					  ) A,
					  TB_PRNT_REQ_INFO B,
				      TB_PRNT_BKGD_INFO C,
					  T D,
					  TB_CODE_MGMT E,
					  TB_CODE_MGMT F,
					  TB_CODE_MGMT G,
					  TB_CODE_MGMT H
				 WHERE A.N_PRNT_PBCN_NO = B.N_PRNT_PBCN_NO
				 AND A.N_PRNT_PBCN_NO = C.N_PRNT_PBCN_NO
				 AND A.QLTY_VEHL_CD = D.QLTY_VEHL_CD
				 AND A.MDL_MDY_CD = D.MDL_MDY_CD
				 AND A.LANG_CD = D.LANG_CD
				 AND E.DL_EXPD_G_CD = '0024'
				 AND B.I_WAY_CD = E.DL_EXPD_PRVS_CD
				 AND F.DL_EXPD_G_CD = '0025'
				 AND B.PRNT_WAY_CD = F.DL_EXPD_PRVS_CD
				 AND G.DL_EXPD_G_CD = '0026'
				 AND B.DEPQ1_CD = G.DL_EXPD_PRVS_CD
				 AND H.DL_EXPD_G_CD = '0029'
				 AND B.PRNT_WAY_CD2 = H.DL_EXPD_PRVS_CD
				 ORDER BY A.ROWNM, A.QLTY_VEHL_CD, D.LANG_SORT_SN, C.TRTM_YMD DESC;
		   
	  END SP_GET_PRNT_APVL_INFO_EXCEL2;
	  
	  --개정내역 개수 조회 
	  FUNCTION FU_GET_REVICE_COUNT(P_VEHL_CD	    VARCHAR2,
	   			 	               P_LANG_CD	    VARCHAR2,
								   P_N_PRNT_PBCN_NO VARCHAR2) RETURN NUMBER
	  IS
	  	V_COUNT NUMBER;
		
	  BEGIN
	  	   
		   SELECT COUNT(*)
		   INTO V_COUNT
		   FROM (SELECT DL_EXPD_ALTR_NO
				 FROM TB_CHKLIST_DTL_INFO
				 WHERE QLTY_VEHL_CD = P_VEHL_CD
			     AND LANG_CD = P_LANG_CD
				 AND N_PRNT_PBCN_NO = P_N_PRNT_PBCN_NO
		         GROUP BY DL_EXPD_ALTR_NO
				);
				
		   RETURN V_COUNT;
							   
	  END FU_GET_REVICE_COUNT;
	  
	  --발간번호에 해당하는 개정내역 조회 								   
	  PROCEDURE SP_GET_REVICE_INFO(P_VEHL_CD	    VARCHAR2,
	   			 	               P_LANG_CD	    VARCHAR2,
								   P_N_PRNT_PBCN_NO VARCHAR2,
								   RS           OUT REFCUR)
	  IS
	  BEGIN
	  	   
		   OPEN RS FOR
		   		SELECT --TO_CHAR(TO_DATE(ALTR_YMD, 'YYYYMMDD'), 'YYYY-MM-DD') AS ALTR_YMD,
					   --C.DL_EXPD_PRVS_NM AS RCPM_SHAP_NM,
                       A.DL_EXPD_ALTR_NO,
					   B.ALTR_SBC
		   		FROM (SELECT DL_EXPD_ALTR_NO
				 	  FROM TB_CHKLIST_DTL_INFO
				 	  WHERE QLTY_VEHL_CD = P_VEHL_CD
			     	  AND LANG_CD = P_LANG_CD
				 	  AND N_PRNT_PBCN_NO = P_N_PRNT_PBCN_NO
		         	  GROUP BY DL_EXPD_ALTR_NO
					 ) A,
					 TB_CHKLIST_INFO B,
					 TB_CODE_MGMT C
				WHERE A.DL_EXPD_ALTR_NO = B.DL_EXPD_ALTR_NO
				AND B.RCPM_SHAP_CD = C.DL_EXPD_PRVS_CD
				AND C.DL_EXPD_G_CD = '0010'
				AND B.DEL_YN = 'N'
				ORDER BY CASE WHEN B.RCPM_SHAP_CD IN ('05', '06', '07') THEN 1 ELSE 2 END, B.DL_EXPD_ALTR_NO;
	  
	  END SP_GET_REVICE_INFO;
	  
	  --특이사항 조회 
	  PROCEDURE SP_PRNT_REQ_SBC_INFO(P_N_PRNT_PBCN_NO VARCHAR2,
	  								 RS 		  OUT REFCUR)
	  IS
	  BEGIN
	  	   
		   OPEN RS FOR
		   		SELECT PRTL_IMTR_SBC2,DLVG_PARR_YMD
				FROM TB_PRNT_REQ_INFO
				WHERE N_PRNT_PBCN_NO = P_N_PRNT_PBCN_NO;
				
	  END SP_PRNT_REQ_SBC_INFO;
	  
	  --특이사항 저장 						   
	  PROCEDURE SP_PRNT_REQ_SBC_SAVE(P_N_PRNT_PBCN_NO VARCHAR2,
	                                 P_PRTL_IMTR_SBC2 VARCHAR2,
	                                 P_USER_EENO      VARCHAR2)
	  IS
	  BEGIN
	  	   
		   UPDATE TB_PRNT_REQ_INFO
		   SET PRTL_IMTR_SBC2 = P_PRTL_IMTR_SBC2,
		       UPDR_EENO = P_USER_EENO,
			   MDFY_DTM = SYSDATE
		   WHERE N_PRNT_PBCN_NO = P_N_PRNT_PBCN_NO;
		   
	  END SP_PRNT_REQ_SBC_SAVE;
	  
	  --납품예정일 변경 									 
	  PROCEDURE SP_DLVG_PARR_YMD_UPDATE(P_N_PRNT_PBCN_NO VARCHAR2,
	                                    P_DLVG_PARR_YMD  VARCHAR2,
										P_USER_EENO      VARCHAR2)
	  IS
	  	
		V_QLTY_VEHL_CD    VARCHAR2(4);
		V_MDL_MDY_CD	  VARCHAR2(2);
		V_LANG_CD		  VARCHAR2(3);
		V_EXPD_MDL_MDY_CD VARCHAR2(2);
		V_CSET_CDT		  VARCHAR2(8);
		
	  BEGIN
	  	   
		   --납품예정일 변경 
		   UPDATE TB_PRNT_REQ_INFO
		   SET DLVG_PARR_YMD = P_DLVG_PARR_YMD,
		       UPDR_EENO = P_USER_EENO,
			   MDFY_DTM = SYSDATE
		   WHERE N_PRNT_PBCN_NO = P_N_PRNT_PBCN_NO;
		   
		   SELECT QLTY_VEHL_CD,
		   		  MDL_MDY_CD, 
				  LANG_CD,
				  DL_EXPD_MDL_MDY_CD,  
				  ORDN_CSET_CDT
		   INTO V_QLTY_VEHL_CD,
		   		V_MDL_MDY_CD, 
				V_LANG_CD,
				V_EXPD_MDL_MDY_CD,  
				V_CSET_CDT
		   FROM TB_PRNT_REQ_INFO
		   WHERE N_PRNT_PBCN_NO = P_N_PRNT_PBCN_NO;
		   
		   --세화재고에서 납품예정일을 변경하여 준다. 
		   PG_SEWHA_IV_INFO.SP_SEWHA_DLVG_PARR_YMD_UPDATE(V_CSET_CDT, 
		   											      V_QLTY_VEHL_CD, 
														  V_MDL_MDY_CD,
														  V_LANG_CD, 
														  V_EXPD_MDL_MDY_CD, 
														  P_N_PRNT_PBCN_NO, 
		                                                  P_DLVG_PARR_YMD,
														  P_USER_EENO);
														  
	  END SP_DLVG_PARR_YMD_UPDATE;
	  
END PG_PRNT_APVL_LST_INFO;