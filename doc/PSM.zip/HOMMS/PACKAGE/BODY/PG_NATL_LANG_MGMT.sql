CREATE OR REPLACE PACKAGE BODY PG_NATL_LANG_MGMT AS

/**********************************************************/
       --차종 내역 조회(컬럼 헤더 구성용/ 신규작성시에 차종내역 구성용)
	   PROCEDURE SP_GET_VEHL_LIST(P_MENU_ID    VARCHAR2,
							      P_USER_EENO  VARCHAR2,
	   			 				  P_EXPD_CO_CD VARCHAR2,
	   			 				  P_MDL_MDY_CD VARCHAR2,
								  RS OUT REFCUR)
       IS
	   BEGIN
	   		OPEN RS FOR
				 /**
				 SELECT QLTY_VEHL_CD, 
				        MDL_MDY_CD
				 FROM TB_VEHL_MGMT
				 WHERE DL_EXPD_CO_CD = P_EXPD_CO_CD
				 AND MDL_MDY_CD = P_MDL_MDY_CD
				 ORDER BY QLTY_VEHL_CD;
				 **/
				 
				 --권한설정된 차종정보만을 가져오도록 한다. 
				 SELECT B.QLTY_VEHL_CD, 
				        B.MDL_MDY_CD
                 FROM (SELECT QLTY_VEHL_CD,
				              MAX(CL_SCN_CD) AS CL_SCN_CD
                       FROM TB_AUTH_VEHL_MGMT
                       WHERE MENU_ID = PG_COMMON.FU_RPAD(P_MENU_ID, 10)
                       AND USER_EENO = PG_COMMON.FU_RPAD(P_USER_EENO, 7)
                       GROUP BY QLTY_VEHL_CD
                      ) A,
                      TB_VEHL_MGMT B
                 WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
                 AND B.MDL_MDY_CD = P_MDL_MDY_CD
				 AND B.DL_EXPD_CO_CD = P_EXPD_CO_CD
				 ORDER BY B.QLTY_VEHL_CD;
				 
	   END SP_GET_VEHL_LIST;
	   
	   --차종 내역 조회2(컬럼 헤더 구성용/ 신규작성시에 차종내역 구성용)
	   PROCEDURE SP_GET_VEHL_LIST2(P_MENU_ID    VARCHAR2,
							       P_USER_EENO  VARCHAR2,
	   			 				   P_EXPD_CO_CD VARCHAR2,
								   P_PDI_CD		VARCHAR2,
								   P_VEHL_CD	VARCHAR2,
	   			 				   P_MDL_MDY_CD VARCHAR2,
								   RS OUT REFCUR)
	   IS
	   BEGIN
	   		
			OPEN RS FOR
				 /**
				 SELECT QLTY_VEHL_CD, 
				        MDL_MDY_CD
				 FROM TB_VEHL_MGMT
				 WHERE DL_EXPD_CO_CD = P_EXPD_CO_CD
				 AND MDL_MDY_CD = P_MDL_MDY_CD
				 ORDER BY QLTY_VEHL_CD;
				 **/
				 
				 --권한설정된 차종정보만을 가져오도록 한다. 
				 SELECT B.QLTY_VEHL_CD, 
				        B.MDL_MDY_CD
                 FROM (SELECT QLTY_VEHL_CD,
				              MAX(CL_SCN_CD) AS CL_SCN_CD
                       FROM TB_AUTH_VEHL_MGMT
                       WHERE MENU_ID = PG_COMMON.FU_RPAD(P_MENU_ID, 10)
                       AND USER_EENO = PG_COMMON.FU_RPAD(P_USER_EENO, 7)
					   AND QLTY_VEHL_CD = DECODE(P_VEHL_CD, 'ALL', QLTY_VEHL_CD, P_VEHL_CD)
                       GROUP BY QLTY_VEHL_CD
                      ) A,
                      TB_VEHL_MGMT B
                 WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
                 AND B.MDL_MDY_CD = P_MDL_MDY_CD
				 AND B.DL_EXPD_CO_CD = P_EXPD_CO_CD
				 AND DL_EXPD_PDI_CD = DECODE(P_PDI_CD, 'ALL', DL_EXPD_PDI_CD, P_PDI_CD) 
				 ORDER BY B.QLTY_VEHL_CD;
				 
	   END SP_GET_VEHL_LIST2;		  
/**********************************************************/
       --회사에 소속된 국가리스트 조회 							  
	   PROCEDURE SP_GET_NATL_LIST(P_EXPD_CO_CD VARCHAR2,
	   			 				  RS OUT REFCUR)
	   IS
	   BEGIN
	   		
			OPEN RS FOR
				 SELECT DL_EXPD_NAT_CD, NAT_NM
				 FROM TB_NATL_MGMT
				 WHERE DL_EXPD_CO_CD = P_EXPD_CO_CD
				 ORDER BY NAT_NM;
				 
	   END SP_GET_NATL_LIST;
/**********************************************************/	   
	   --차종에 적용가능한 언어내역 조회 									   
	   PROCEDURE SP_GET_LANG_LIST(P_QLTY_VEHL_CD VARCHAR2,
	                              P_MDL_MDY_CD   VARCHAR2,
								  RS OUT REFCUR)
	   IS
	   BEGIN
	   		
			OPEN RS FOR
				 SELECT LANG_CD, MAX(LANG_CD_NM) AS LANG_CD_NM
				 FROM TB_LANG_MGMT
				 WHERE QLTY_VEHL_CD = P_QLTY_VEHL_CD
				 AND MDL_MDY_CD = P_MDL_MDY_CD
				 GROUP BY LANG_CD;
				 
	   END SP_GET_LANG_LIST;
	   
/**********************************************************/
       --국가/언어코드 내역 조회 
	   PROCEDURE SP_GET_NATL_LANT_MGMT(P_MENU_ID     VARCHAR2,
							      	   P_USER_EENO   VARCHAR2,
	   			 					   P_EXPD_CO_CD  TB_NATL_MGMT.DL_EXPD_CO_CD%TYPE,
	   			 					   P_EXPD_NAT_CD TB_NATL_MGMT.DL_EXPD_NAT_CD%TYPE,
									   P_MDL_MDY_CD	 VARCHAR2,
									   P_FROM_NUM    NUMBER,
									   P_TO_NUM      NUMBER,
									   P_CNT     OUT NUMBER,
									   RS OUT REFCUR)
	   IS
	   	 
		 V_QUERY    VARCHAR2(8000);
		 V_SUBQRY   VARCHAR2(8000);
		 
		 V_TMP_CNT  NUMBER;
		  		 
		 V_COL_NUM  NUMBER;
		 
		 V_FROM_NUM NUMBER;
		 V_TO_NUM   NUMBER;
		 
		 
		 CURSOR VEHL_LIST_INFO IS SELECT B.QLTY_VEHL_CD, 
		                                 B.MDL_MDY_CD
                 				  FROM (SELECT QLTY_VEHL_CD,
				              	  	   		   MAX(CL_SCN_CD) AS CL_SCN_CD
                                        FROM TB_AUTH_VEHL_MGMT
                       			        WHERE MENU_ID = PG_COMMON.FU_RPAD(P_MENU_ID, 10)
                       					AND USER_EENO = PG_COMMON.FU_RPAD(P_USER_EENO, 7)
                       					GROUP BY QLTY_VEHL_CD
                                       ) A,
                                       TB_VEHL_MGMT B
                                  WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
                                  AND B.MDL_MDY_CD = P_MDL_MDY_CD
				                  AND B.DL_EXPD_CO_CD = P_EXPD_CO_CD
				                  ORDER BY B.QLTY_VEHL_CD;
								 
	   BEGIN
	   		
			SELECT COUNT(*)
			INTO P_CNT
			FROM TB_NATL_MGMT
		    WHERE DL_EXPD_CO_CD = P_EXPD_CO_CD
		    AND DL_EXPD_NAT_CD LIKE P_EXPD_NAT_CD || '%';
			
			SELECT COUNT(*)
			INTO V_TMP_CNT
			FROM TB_NATL_NOAPIM_MGMT
			WHERE DL_EXPD_CO_CD = P_EXPD_CO_CD;
			
			P_CNT := P_CNT + V_TMP_CNT;
			
			V_QUERY := '';
			
			--미지정 국가정보가 존재한다면 이것을 우선 표시하여 준다. 
			IF P_FROM_NUM <= V_TMP_CNT THEN
			   
			   
			   V_QUERY := 'SELECT DL_EXPD_CO_CD,' ||
			   		   	  		 'DL_EXPD_NAT_CD,' ||
								 '''' || P_MDL_MDY_CD || ''' AS MDL_MDY_CD,' ||
								 'NAT_NM,' ||
								 'DYTM_PLN_NAT_CD AS DYTM_NATL_LIST,';
			   
			   V_COL_NUM := 1;
			   V_SUBQRY  := '';
			
			   FOR VEHL_LIST IN VEHL_LIST_INFO LOOP
			   	   
				   V_SUBQRY := V_SUBQRY ||
						      ''''' AS COL' || TO_CHAR(V_COL_NUM) || ',';
							  
				   V_COL_NUM := V_COL_NUM + 1;
				
			   END LOOP;
			   
			   IF LENGTH(V_SUBQRY) > 0 THEN
			   
			   	  V_SUBQRY := SUBSTR(V_SUBQRY, 1, LENGTH(V_SUBQRY) - 1);
			
			   ELSE
			   
			   	  V_QUERY := SUBSTR(V_QUERY, 1, LENGTH(V_QUERY) - 1);
			    
			   END IF;
			
			 
			   V_QUERY := V_QUERY || V_SUBQRY || ' ';
			   
			   V_QUERY := V_QUERY ||
			              'FROM (SELECT DL_EXPD_CO_CD,' ||
						  		       'DL_EXPD_NAT_CD,' ||
									   'NAT_NM,' ||
									   'DYTM_PLN_NAT_CD, ' ||
									   'ROWNUM AS ROWNM ' ||
								'FROM TB_NATL_NOAPIM_MGMT ' ||
								'WHERE DL_EXPD_CO_CD = ''' || P_EXPD_CO_CD || ''' ' ||
							   ') ' ||
						  'WHERE ROWNM BETWEEN ' || TO_CHAR(P_FROM_NUM) || ' AND ' || TO_CHAR(P_TO_NUM) || ' ';
			   			  
			END IF;
			
			--미지정국가 정보를 표시하고 남은 경우에 국가코드 정보를 표시하여 준다.
			IF P_TO_NUM > V_TMP_CNT THEN
			   
			   V_FROM_NUM := P_FROM_NUM - V_TMP_CNT;
			   
			   IF V_FROM_NUM <= 0 THEN
			   	  
				  V_FROM_NUM := 1;
				  
			   END IF;
			   
			   V_TO_NUM := P_TO_NUM - V_TMP_CNT;
			   
			   IF P_FROM_NUM <= V_TMP_CNT THEN
			   	  
				  V_QUERY := V_QUERY ||
				             'UNION ALL ';
							 
			   END IF;

			   V_QUERY := V_QUERY ||
			   		      'SELECT DL_EXPD_CO_CD,' ||
				                 'DL_EXPD_NAT_CD,' ||
								 '''' || P_MDL_MDY_CD || ''' AS MDL_MDY_CD,' ||
				                 'NAT_NM,' ||
				                 'DYTM_NATL_LIST,';
				
			   V_COL_NUM := 1;
   			   V_SUBQRY  := '';
			      		 
			   FOR VEHL_LIST IN VEHL_LIST_INFO LOOP
					
			   	  V_SUBQRY := V_SUBQRY ||
   						      'CASE WHEN COL' || TO_CHAR(V_COL_NUM) || ' = '''' THEN '''' ELSE PG_NATL_LANG_MGMT.FU_GET_LANG_LIST(DL_EXPD_CO_CD, DL_EXPD_NAT_CD, COL' || TO_CHAR(V_COL_NUM) || ', ''' || P_MDL_MDY_CD || ''') END AS COL' || TO_CHAR(V_COL_NUM) ||  ',';
   							  
   				  V_COL_NUM := V_COL_NUM + 1;
				   
			   END LOOP;
				
			   IF LENGTH(V_SUBQRY) > 0 THEN
   			   
   			      V_SUBQRY := SUBSTR(V_SUBQRY, 1, LENGTH(V_SUBQRY) - 1);
   			
   			   ELSE
   			   
   			      V_QUERY := SUBSTR(V_QUERY, 1, LENGTH(V_QUERY) - 1);
   			    
   			   END IF;
			  
			   V_QUERY := V_QUERY || V_SUBQRY || ' ';
			  	 
			   V_QUERY := V_QUERY ||				 
						  'FROM (SELECT A.DL_EXPD_CO_CD,' ||
				                       'A.DL_EXPD_NAT_CD,' ||
				                       'MAX(C.NAT_NM) AS NAT_NM,' ||
				                       'PG_NATL_LANG_MGMT.FU_GET_DYTM_NATL_LIST(A.DL_EXPD_CO_CD, A.DL_EXPD_NAT_CD) AS DYTM_NATL_LIST,';
							  
   			   V_COL_NUM := 1;
   			   V_SUBQRY  := '';
   			
   			   FOR VEHL_LIST IN VEHL_LIST_INFO LOOP
   				
   				   V_SUBQRY := V_SUBQRY ||
   						             --'MAX(CASE WHEN B.QLTY_VEHL_CD = ''' || VEHL_LIST.QLTY_VEHL_CD || ''' THEN PG_NATL_LANG_MGMT.FU_GET_LANG_LIST(A.DL_EXPD_CO_CD, A.DL_EXPD_NAT_CD, B.QLTY_VEHL_CD, B.MDL_MDY_CD) ' ||
   							         --         'ELSE '''' ' ||
   							         --    'END) AS COL' || TO_CHAR(V_COL_NUM) || ',';
							           'MAX(CASE WHEN B.QLTY_VEHL_CD = ''' || VEHL_LIST.QLTY_VEHL_CD || ''' THEN B.QLTY_VEHL_CD ' ||
   							                    'ELSE '''' ' ||
   							               'END) AS COL' || TO_CHAR(V_COL_NUM) || ',';
   							  
   				   V_COL_NUM := V_COL_NUM + 1;
   							  
   			  END LOOP;
   			
   			  IF LENGTH(V_SUBQRY) > 0 THEN
   			   
   			     V_SUBQRY := SUBSTR(V_SUBQRY, 1, LENGTH(V_SUBQRY) - 1);
   			
   			  ELSE
   			   
   			     V_QUERY := SUBSTR(V_QUERY, 1, LENGTH(V_QUERY) - 1);
   			    
   			  END IF;
   			
   			 
   			  V_QUERY := V_QUERY || V_SUBQRY || ' ';
   			
   			  V_QUERY := V_QUERY ||
   			                    'FROM (SELECT DL_EXPD_CO_CD,' ||
   					                         'DL_EXPD_NAT_CD ' ||
   					                  'FROM (SELECT DL_EXPD_CO_CD,' ||
   					                               'DL_EXPD_NAT_CD, ' ||
   										           'ROWNUM AS ROWNM ' ||
   				                            'FROM TB_NATL_MGMT ' ||
   				                            'WHERE DL_EXPD_CO_CD = ''' || P_EXPD_CO_CD || ''' ' ||
   				                            'AND DL_EXPD_NAT_CD LIKE ''' || P_EXPD_NAT_CD || '%'' ' ||
   				                           ') ' ||
   							          'WHERE ROWNM BETWEEN ' || TO_CHAR(V_FROM_NUM) || ' AND ' || TO_CHAR(V_TO_NUM) || ' ' ||
   						             ') A,' ||
   					                 'TB_NATL_LANG_MGMT B,' ||
   				                     'TB_NATL_MGMT C ' ||
   		                       'WHERE A.DL_EXPD_CO_CD = B.DL_EXPD_CO_CD(+) ' ||
   		                       'AND A.DL_EXPD_NAT_CD = B.DL_EXPD_NAT_CD(+) ' ||
						       'AND B.MDL_MDY_CD(+) = ''' || P_MDL_MDY_CD || ''' ' ||
   			                   'AND A.DL_EXPD_CO_CD = C.DL_EXPD_CO_CD ' ||
   			                   'AND A.DL_EXPD_NAT_CD = C.DL_EXPD_NAT_CD ' ||
   			                   'GROUP BY A.DL_EXPD_CO_CD, A.DL_EXPD_NAT_CD' ||
						      ')';
			END IF;
			
			OPEN RS FOR V_QUERY;		  
			 
			/***  테스트용 쿼리 
			SELECT A.DL_EXPD_CO_CD, 
				   A.DL_EXPD_NAT_CD,
				   MAX(C.NAT_NM) AS NAT_NM,
				   FU_GET_DYTM_NATL_LIST(A.DL_EXPD_CO_CD, A.DL_EXPD_NAT_CD) AS DYTM_NATL_LIST,
				   MAX(CASE WHEN B.QLTY_VEHL_CD = 'AM' THEN PG_NATL_LANG_MGMT.FU_GET_LANG_LIST(A.DL_EXPD_CO_CD, A.DL_EXPD_NAT_CD, B.QLTY_VEHL_CD, B.MDL_MDY_CD)
							ELSE ''
					   END
					  ) AS COL1,
				   MAX(CASE WHEN B.QLTY_VEHL_CD = 'BH' THEN PG_NATL_LANG_MGMT.FU_GET_LANG_LIST(A.DL_EXPD_CO_CD, A.DL_EXPD_NAT_CD, B.QLTY_VEHL_CD, B.MDL_MDY_CD)
							ELSE ''
					   END
					  ) AS COL2
		    FROM (SELECT DL_EXPD_CO_CD,
					     DL_EXPD_NAT_CD
				  FROM TB_NATL_MGMT
				  WHERE DL_EXPD_CO_CD = :P_EXPD_CO_CD
				  AND DL_EXPD_NAT_CD LIKE :P_EXPD_NAT_CD || '%'
				 ) A,
				 TB_NATL_LANG_MGMT B,
				 TB_NATL_MGMT C
		    WHERE A.DL_EXPD_CO_CD = B.DL_EXPD_CO_CD(+)
		    AND A.DL_EXPD_NAT_CD = B.DL_EXPD_NAT_CD(+)
			AND A.DL_EXPD_CO_CD = C.DL_EXPD_CO_CD
			AND A.DL_EXPD_NAT_CD = C.DL_EXPD_NAT_CD
			GROUP BY A.DL_EXPD_CO_CD, A.DL_EXPD_NAT_CD;
			***/
				 
	   END SP_GET_NATL_LANT_MGMT;
	   
	   --국가/언어코드 내역 조회2 
	   PROCEDURE SP_GET_NATL_LANT_MGMT2(P_MENU_ID     VARCHAR2,
							      	    P_USER_EENO   VARCHAR2,
									    P_EXPD_CO_CD  TB_NATL_MGMT.DL_EXPD_CO_CD%TYPE,
									    P_EXPD_NAT_CD TB_NATL_MGMT.DL_EXPD_NAT_CD%TYPE,
                                        P_EXPD_NAT_NM VARCHAR2,
										P_PDI_CD	  VARCHAR2,
								   		P_VEHL_CD	  VARCHAR2,
										P_MDL_MDY_CD  VARCHAR2,
										P_REGN_CD	  VARCHAR2,
										P_LANG_CD	  VARCHAR2,
									    P_FROM_NUM    NUMBER,
									    P_TO_NUM      NUMBER,
									    P_CNT     OUT NUMBER,        
	   								    RS OUT REFCUR)

	   IS
	   	 
		 V_QUERY    VARCHAR2(32767);
		 V_SUBQRY   VARCHAR2(32767);
		 
		 V_TMP_CNT  NUMBER;
		  		 
		 V_COL_NUM  NUMBER;
		 
		 V_FROM_NUM NUMBER;
		 V_TO_NUM   NUMBER;
		 
		 
		 CURSOR VEHL_LIST_INFO IS SELECT B.QLTY_VEHL_CD, 
		                                 B.MDL_MDY_CD
                 				  FROM (SELECT QLTY_VEHL_CD,
				              	  	   		   MAX(CL_SCN_CD) AS CL_SCN_CD
                                        FROM TB_AUTH_VEHL_MGMT
                       			        WHERE MENU_ID = PG_COMMON.FU_RPAD(P_MENU_ID, 10)
                       					AND USER_EENO = PG_COMMON.FU_RPAD(P_USER_EENO, 7)
										AND QLTY_VEHL_CD = DECODE(P_VEHL_CD, 'ALL', QLTY_VEHL_CD, P_VEHL_CD)
                       					GROUP BY QLTY_VEHL_CD
                                       ) A,
                                       TB_VEHL_MGMT B
                                  WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
                                  AND B.MDL_MDY_CD = P_MDL_MDY_CD
				                  AND B.DL_EXPD_CO_CD = P_EXPD_CO_CD
								  AND DL_EXPD_PDI_CD = DECODE(P_PDI_CD, 'ALL', DL_EXPD_PDI_CD, P_PDI_CD) 
				                  ORDER BY B.QLTY_VEHL_CD;
								 
	   BEGIN
	   		
			IF P_VEHL_CD <> 'ALL' OR P_LANG_CD <> 'ALL' THEN
			   
			   SELECT COUNT(*)
			   INTO P_CNT
			   FROM (SELECT A.DL_EXPD_NAT_CD
			   		 FROM TB_NATL_LANG_MGMT A,
					 	  TB_NATL_MGMT B
					 WHERE A.DL_EXPD_CO_CD = P_EXPD_CO_CD
					 AND A.DL_EXPD_CO_CD = B.DL_EXPD_CO_CD
					 AND A.DL_EXPD_NAT_CD = B.DL_EXPD_NAT_CD
					 AND B.DL_EXPD_NAT_CD LIKE P_EXPD_NAT_CD || '%'
                     AND B.NAT_NM LIKE P_EXPD_NAT_NM || '%'
					 AND A.QLTY_VEHL_CD = DECODE(P_VEHL_CD, 'ALL', QLTY_VEHL_CD, P_VEHL_CD)
					 AND A.MDL_MDY_CD = P_MDL_MDY_CD
					 AND A.LANG_CD = DECODE(P_LANG_CD, 'ALL', LANG_CD, P_LANG_CD)
					 GROUP BY A.DL_EXPD_NAT_CD
					);
			ELSE
				
				SELECT COUNT(*)
				INTO P_CNT
				FROM TB_NATL_MGMT
		    	WHERE DL_EXPD_CO_CD = P_EXPD_CO_CD
		    	AND DL_EXPD_NAT_CD LIKE P_EXPD_NAT_CD || '%'
                AND NAT_NM LIKE P_EXPD_NAT_NM || '%';
			
			END IF;
			
			SELECT COUNT(*)
			INTO V_TMP_CNT
			FROM TB_NATL_NOAPIM_MGMT
			WHERE DL_EXPD_CO_CD = P_EXPD_CO_CD;
			
			P_CNT := P_CNT + V_TMP_CNT;
			
			V_QUERY := '';
			
			--미지정 국가정보가 존재한다면 이것을 우선 표시하여 준다. 
			IF P_FROM_NUM <= V_TMP_CNT THEN
			   
			   
			   V_QUERY := 'SELECT DL_EXPD_CO_CD,' ||
			   		   	  		 'DL_EXPD_NAT_CD,' ||
								 '''' || P_MDL_MDY_CD || ''' AS MDL_MDY_CD,' ||
								 'NAT_NM,' ||
								 ''''' AS DL_EXPD_REGN_NM,' ||
								 'DYTM_PLN_NAT_CD AS DYTM_NATL_LIST,';
			   
			   V_COL_NUM := 1;
			   V_SUBQRY  := '';
			
			   FOR VEHL_LIST IN VEHL_LIST_INFO LOOP
			   	   
				   V_SUBQRY := V_SUBQRY ||
						      ''''' AS COL' || TO_CHAR(V_COL_NUM) || ',';
							  
				   V_COL_NUM := V_COL_NUM + 1;
				
			   END LOOP;
			   
			   IF LENGTH(V_SUBQRY) > 0 THEN
			   
			   	  V_SUBQRY := SUBSTR(V_SUBQRY, 1, LENGTH(V_SUBQRY) - 1);
			
			   ELSE
			   
			   	  V_QUERY := SUBSTR(V_QUERY, 1, LENGTH(V_QUERY) - 1);
			    
			   END IF;
			
			 
			   V_QUERY := V_QUERY || V_SUBQRY || ' ';
			   
			   V_QUERY := V_QUERY ||
			              'FROM (SELECT DL_EXPD_CO_CD,' ||
						  		       'DL_EXPD_NAT_CD,' ||
									   'NAT_NM,' ||
									   'DYTM_PLN_NAT_CD, ' ||
									   'ROWNUM AS ROWNM ' ||
								'FROM TB_NATL_NOAPIM_MGMT ' ||
								'WHERE DL_EXPD_CO_CD = ''' || P_EXPD_CO_CD || ''' ' ||
							   ') ' ||
						  'WHERE ROWNM BETWEEN ' || TO_CHAR(P_FROM_NUM) || ' AND ' || TO_CHAR(P_TO_NUM) || ' ';
			   			  
			END IF;
			
			--미지정국가 정보를 표시하고 남은 경우에 국가코드 정보를 표시하여 준다.
			IF P_TO_NUM > V_TMP_CNT THEN
			   
			   V_FROM_NUM := P_FROM_NUM - V_TMP_CNT;
			   
			   IF V_FROM_NUM <= 0 THEN
			   	  
				  V_FROM_NUM := 1;
				  
			   END IF;
			   
			   V_TO_NUM := P_TO_NUM - V_TMP_CNT;
			   
			   IF P_FROM_NUM <= V_TMP_CNT THEN
			   	  
				  V_QUERY := V_QUERY ||
				             'UNION ALL ';
							 
			   END IF;

			   V_QUERY := V_QUERY ||
			   		      'SELECT DL_EXPD_CO_CD,' ||
				                 'DL_EXPD_NAT_CD,' ||
								 '''' || P_MDL_MDY_CD || ''' AS MDL_MDY_CD,' ||
				                 'NAT_NM,' ||
								 'DL_EXPD_REGN_NM,' ||
				                 'DYTM_NATL_LIST,';
				
			   V_COL_NUM := 1;
   			   V_SUBQRY  := '';
			      		 
			   FOR VEHL_LIST IN VEHL_LIST_INFO LOOP
					
			   	  V_SUBQRY := V_SUBQRY ||
   						      'CASE WHEN COL' || TO_CHAR(V_COL_NUM) || ' = '''' THEN '''' ELSE PG_NATL_LANG_MGMT.FU_GET_LANG_LIST(DL_EXPD_CO_CD, DL_EXPD_NAT_CD, COL' || TO_CHAR(V_COL_NUM) || ', ''' || P_MDL_MDY_CD || ''') END AS COL' || TO_CHAR(V_COL_NUM) ||  ',';
   							  
   				  V_COL_NUM := V_COL_NUM + 1;
				   
			   END LOOP;
				
			   IF LENGTH(V_SUBQRY) > 0 THEN
   			   
   			      V_SUBQRY := SUBSTR(V_SUBQRY, 1, LENGTH(V_SUBQRY) - 1);
   			
   			   ELSE
   			   
   			      V_QUERY := SUBSTR(V_QUERY, 1, LENGTH(V_QUERY) - 1);
   			    
   			   END IF;
			  
			   V_QUERY := V_QUERY || V_SUBQRY || ' ';
			  	 
			   V_QUERY := V_QUERY ||				 
						  'FROM (SELECT A.DL_EXPD_CO_CD,' ||
				                       'A.DL_EXPD_NAT_CD,' ||
				                       'MAX(C.NAT_NM) AS NAT_NM,' ||
									   'MAX(D.DL_EXPD_PRVS_NM) AS DL_EXPD_REGN_NM,' ||
				                       'PG_NATL_LANG_MGMT.FU_GET_DYTM_NATL_LIST(A.DL_EXPD_CO_CD, A.DL_EXPD_NAT_CD) AS DYTM_NATL_LIST,';
							  
   			   V_COL_NUM := 1;
   			   V_SUBQRY  := '';
   			
   			   FOR VEHL_LIST IN VEHL_LIST_INFO LOOP
   				
   				   V_SUBQRY := V_SUBQRY ||
   						             --'MAX(CASE WHEN B.QLTY_VEHL_CD = ''' || VEHL_LIST.QLTY_VEHL_CD || ''' THEN PG_NATL_LANG_MGMT.FU_GET_LANG_LIST(A.DL_EXPD_CO_CD, A.DL_EXPD_NAT_CD, B.QLTY_VEHL_CD, B.MDL_MDY_CD) ' ||
   							         --         'ELSE '''' ' ||
   							         --    'END) AS COL' || TO_CHAR(V_COL_NUM) || ',';
							           'MAX(CASE WHEN B.QLTY_VEHL_CD = ''' || VEHL_LIST.QLTY_VEHL_CD || ''' THEN B.QLTY_VEHL_CD ' ||
   							                    'ELSE '''' ' ||
   							               'END) AS COL' || TO_CHAR(V_COL_NUM) || ',';
   							  
   				   V_COL_NUM := V_COL_NUM + 1;
   							  
   			  END LOOP;
   			
   			  IF LENGTH(V_SUBQRY) > 0 THEN
   			   
   			     V_SUBQRY := SUBSTR(V_SUBQRY, 1, LENGTH(V_SUBQRY) - 1);
   			
   			  ELSE
   			   
   			     V_QUERY := SUBSTR(V_QUERY, 1, LENGTH(V_QUERY) - 1);
   			    
   			  END IF;
   			 
   			  V_QUERY := V_QUERY || V_SUBQRY || ' ';
			  
			  IF P_VEHL_CD <> 'ALL' OR P_LANG_CD <> 'ALL' THEN
			  	 
				 V_QUERY := V_QUERY ||
   			                    'FROM (SELECT DL_EXPD_CO_CD,' ||
   					                         'DL_EXPD_NAT_CD ' ||
   					                  'FROM (SELECT DL_EXPD_CO_CD,' ||
   					                               'DL_EXPD_NAT_CD, ' ||
   										           'ROWNUM AS ROWNM ' ||
   				                            'FROM (SELECT A.DL_EXPD_CO_CD,' ||
											             'A.DL_EXPD_NAT_CD ' ||
												  'FROM TB_NATL_LANG_MGMT A,' ||
												       'TB_NATL_MGMT B ' ||
   				                            	  'WHERE A.DL_EXPD_CO_CD = ''' || P_EXPD_CO_CD || ''' ' ||
												  'AND A.DL_EXPD_CO_CD = B.DL_EXPD_CO_CD ' ||
												  'AND A.DL_EXPD_NAT_CD = B.DL_EXPD_NAT_CD ' ||
   				                            	  'AND B.DL_EXPD_NAT_CD LIKE ''' || P_EXPD_NAT_CD || '%'' ' ||
                                                  'AND B.NAT_NM LIKE ''' || P_EXPD_NAT_NM || '%'' ' ||
												  'AND A.MDL_MDY_CD = ''' || P_MDL_MDY_CD || ''' ';
				 
				 IF P_VEHL_CD <> 'ALL' THEN
			  	 
				 	V_QUERY := V_QUERY ||
				                            	  'AND A.QLTY_VEHL_CD = ''' || P_VEHL_CD || ''' ';
			  	 END IF;
			  
			     IF P_LANG_CD <> 'ALL' THEN
			  	 
				    V_QUERY := V_QUERY ||
				                            	  'AND A.LANG_CD = ''' || P_LANG_CD || ''' ';
			     END IF;
											
				 V_QUERY := V_QUERY ||	    	  'GROUP BY A.DL_EXPD_CO_CD, A.DL_EXPD_NAT_CD ' ||
				 		 						  'ORDER BY MAX(B.NAT_NM) ' ||
				 		 						 ') ' ||
   				                           ') ' ||
   							         'WHERE ROWNM BETWEEN ' || TO_CHAR(V_FROM_NUM) || ' AND ' || TO_CHAR(V_TO_NUM) || ' ' ||
   						             ') A,' ||
   					                 'TB_NATL_LANG_MGMT B,' ||
   				                     'TB_NATL_MGMT C,' ||
									 'TB_CODE_MGMT D ' ||
   		                       'WHERE A.DL_EXPD_CO_CD = B.DL_EXPD_CO_CD ' ||
   		                       'AND A.DL_EXPD_NAT_CD = B.DL_EXPD_NAT_CD ' ||
						       'AND B.MDL_MDY_CD = ''' || P_MDL_MDY_CD || ''' ' ||
							   'AND A.DL_EXPD_CO_CD = C.DL_EXPD_CO_CD ' ||
   			                   'AND A.DL_EXPD_NAT_CD = C.DL_EXPD_NAT_CD ' ||
							   'AND C.DL_EXPD_REGN_CD = D.DL_EXPD_PRVS_CD(+) ' ||
							   'AND D.DL_EXPD_G_CD(+) = ''0008'' ' ||
   			                   'GROUP BY A.DL_EXPD_CO_CD, A.DL_EXPD_NAT_CD ' ||
							   'ORDER BY MAX(C.NAT_NM) ' ||
						      ') ';
			  ELSE
			  
			  	 V_QUERY := V_QUERY ||
   			                   'FROM (SELECT DL_EXPD_CO_CD,' ||
   					                        'DL_EXPD_NAT_CD ' ||
   					                 'FROM (SELECT DL_EXPD_CO_CD,' ||
									 	   		  'DL_EXPD_NAT_CD,' ||
												  'ROWNUM AS ROWNM ' ||
										   'FROM (SELECT DL_EXPD_CO_CD,' ||
   					                                    'DL_EXPD_NAT_CD ' ||
   				                                 'FROM TB_NATL_MGMT ' ||
   				                                 'WHERE DL_EXPD_CO_CD = ''' || P_EXPD_CO_CD || ''' ' ||
   				                                 'AND DL_EXPD_NAT_CD LIKE ''' || P_EXPD_NAT_CD || '%'' ' ||
                                                 'AND NAT_NM LIKE ''' || P_EXPD_NAT_NM || '%'' ' ||
										         'ORDER BY NAT_NM ' ||
												') ' ||
   				                          ') ' ||
   							         'WHERE ROWNM BETWEEN ' || TO_CHAR(V_FROM_NUM) || ' AND ' || TO_CHAR(V_TO_NUM) || ' ' ||
   						            ') A,' ||
   					                'TB_NATL_LANG_MGMT B,' ||
   				                    'TB_NATL_MGMT C,' ||
									'TB_CODE_MGMT D ' ||
   		                       'WHERE A.DL_EXPD_CO_CD = B.DL_EXPD_CO_CD(+) ' ||
   		                       'AND A.DL_EXPD_NAT_CD = B.DL_EXPD_NAT_CD(+) ' ||
						       'AND B.MDL_MDY_CD(+) = ''' || P_MDL_MDY_CD || ''' ' ||
							   'AND A.DL_EXPD_CO_CD = C.DL_EXPD_CO_CD ' ||
   			                   'AND A.DL_EXPD_NAT_CD = C.DL_EXPD_NAT_CD ' ||
							   'AND C.DL_EXPD_REGN_CD = D.DL_EXPD_PRVS_CD(+) ' ||
							   'AND D.DL_EXPD_G_CD(+) = ''0008'' ' ||
   			                   'GROUP BY A.DL_EXPD_CO_CD, A.DL_EXPD_NAT_CD ' ||
							   'ORDER BY MAX(C.NAT_NM) ' ||
						     ') ';  
			  END IF;
			  
			END IF;
			  
			OPEN RS FOR V_QUERY;	
			
	   END SP_GET_NATL_LANT_MGMT2;
/**********************************************************/
	   --국가/언어코드 내역 조회(엑셀전용) 					
	   PROCEDURE SP_GET_NATL_LANT_MGMT_EXCEL(P_MENU_ID     VARCHAR2,
							      	         P_USER_EENO   VARCHAR2,
									         P_EXPD_CO_CD  TB_NATL_MGMT.DL_EXPD_CO_CD%TYPE,
									         P_EXPD_NAT_CD TB_NATL_MGMT.DL_EXPD_NAT_CD%TYPE,
											 P_PDI_CD	   VARCHAR2,
								   			 P_VEHL_CD	   VARCHAR2,
									         P_MDL_MDY_CD  VARCHAR2,
											 P_REGN_CD	   VARCHAR2,
											 P_LANG_CD	   VARCHAR2,
									    	 RS OUT REFCUR)
	   IS
		 V_QUERY    VARCHAR2(8000);
		 V_SUBQRY   VARCHAR2(8000);
		 
		 V_COL_NUM  NUMBER;
		 	 
		 CURSOR VEHL_LIST_INFO IS SELECT B.QLTY_VEHL_CD, B.MDL_MDY_CD
                 				  FROM (SELECT QLTY_VEHL_CD,
				              	  	   		   MAX(CL_SCN_CD) AS CL_SCN_CD
                                        FROM TB_AUTH_VEHL_MGMT
                       			        WHERE MENU_ID = PG_COMMON.FU_RPAD(P_MENU_ID, 10)
                       					AND USER_EENO = PG_COMMON.FU_RPAD(P_USER_EENO, 7)
										AND QLTY_VEHL_CD = DECODE(P_VEHL_CD, 'ALL', QLTY_VEHL_CD, P_VEHL_CD)
                       					GROUP BY QLTY_VEHL_CD
                                       ) A,
                                       TB_VEHL_MGMT B
                                  WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
                                  AND B.MDL_MDY_CD = P_MDL_MDY_CD
				                  AND B.DL_EXPD_CO_CD = P_EXPD_CO_CD
								  AND DL_EXPD_PDI_CD = DECODE(P_PDI_CD, 'ALL', DL_EXPD_PDI_CD, P_PDI_CD) 
				                  ORDER BY B.QLTY_VEHL_CD;
								 
	   BEGIN
	   		
			V_QUERY := '';
			
			--미지정 국가정보가 존재한다면 이것을 우선 표시하여 준다. 
			V_QUERY := 'SELECT DL_EXPD_CO_CD,' ||
			   		   	  	  'DL_EXPD_NAT_CD,' ||
							  '''' || P_MDL_MDY_CD || ''' AS MDL_MDY_CD,' ||
							  'NAT_NM,' ||
							  ''''' AS DL_EXPD_REGN_NM,' ||
							  'DYTM_PLN_NAT_CD AS DYTM_NATL_LIST,';
			   
			V_COL_NUM := 1;
			V_SUBQRY  := '';
			
			FOR VEHL_LIST IN VEHL_LIST_INFO LOOP
			   	   
			    V_SUBQRY := V_SUBQRY ||
						      ''''' AS COL' || TO_CHAR(V_COL_NUM) || ',';
							  
				V_COL_NUM := V_COL_NUM + 1;
				
			END LOOP;
			   
			IF LENGTH(V_SUBQRY) > 0 THEN
			   
			   	V_SUBQRY := SUBSTR(V_SUBQRY, 1, LENGTH(V_SUBQRY) - 1);
			
			ELSE
			   
			    V_QUERY := SUBSTR(V_QUERY, 1, LENGTH(V_QUERY) - 1);
			    
			END IF;
			
			 
			V_QUERY := V_QUERY || V_SUBQRY || ' ';
			   
			V_QUERY := V_QUERY ||
			          'FROM TB_NATL_NOAPIM_MGMT ' ||
					  'WHERE DL_EXPD_CO_CD = ''' || P_EXPD_CO_CD || ''' ' ||
					  'UNION ALL ' ||
					  'SELECT DL_EXPD_CO_CD,' ||
				             'DL_EXPD_NAT_CD,' ||
							 '''' || P_MDL_MDY_CD || ''' AS MDL_MDY_CD,' ||
				             'NAT_NM,' ||
							 'DL_EXPD_REGN_NM,' ||
				             'DYTM_NATL_LIST,';  
			
			V_COL_NUM := 1;
   			V_SUBQRY  := '';
			      		 
			FOR VEHL_LIST IN VEHL_LIST_INFO LOOP
					
			   V_SUBQRY := V_SUBQRY ||
   						     'CASE WHEN COL' || TO_CHAR(V_COL_NUM) || ' = '''' THEN '''' ELSE PG_NATL_LANG_MGMT.FU_GET_LANG_LIST(DL_EXPD_CO_CD, DL_EXPD_NAT_CD, COL' || TO_CHAR(V_COL_NUM) || ', ''' || P_MDL_MDY_CD || ''') END AS COL' || TO_CHAR(V_COL_NUM) ||  ',';
   							  
   			   V_COL_NUM := V_COL_NUM + 1;
				   
			END LOOP;
				
			IF LENGTH(V_SUBQRY) > 0 THEN
   			   
   			   V_SUBQRY := SUBSTR(V_SUBQRY, 1, LENGTH(V_SUBQRY) - 1);
   			
   			ELSE
   			   
   			   V_QUERY := SUBSTR(V_QUERY, 1, LENGTH(V_QUERY) - 1);
   			    
   			END IF;
			
			V_QUERY := V_QUERY || V_SUBQRY || ' ';
			  	 
 		    V_QUERY := V_QUERY ||				 
 					 'FROM (SELECT A.DL_EXPD_CO_CD,' ||
 			                      'A.DL_EXPD_NAT_CD,' ||
 			                      'MAX(C.NAT_NM) AS NAT_NM,' ||
								  'MAX(D.DL_EXPD_PRVS_NM) AS DL_EXPD_REGN_NM,' ||
 			                      'PG_NATL_LANG_MGMT.FU_GET_DYTM_NATL_LIST(A.DL_EXPD_CO_CD, A.DL_EXPD_NAT_CD) AS DYTM_NATL_LIST,';
 						  
   			V_COL_NUM := 1;
   			V_SUBQRY  := '';
   			
   			FOR VEHL_LIST IN VEHL_LIST_INFO LOOP
   				
   				V_SUBQRY := V_SUBQRY ||
 						         'MAX(CASE WHEN B.QLTY_VEHL_CD = ''' || VEHL_LIST.QLTY_VEHL_CD || ''' THEN B.QLTY_VEHL_CD ' ||
   							              'ELSE '''' ' ||
   							         'END) AS COL' || TO_CHAR(V_COL_NUM) || ',';
   							  
   				V_COL_NUM := V_COL_NUM + 1;
   							  
   		    END LOOP;
   			
   			IF LENGTH(V_SUBQRY) > 0 THEN
   			   
   			    V_SUBQRY := SUBSTR(V_SUBQRY, 1, LENGTH(V_SUBQRY) - 1);
   			
   			ELSE
   			   
   			    V_QUERY := SUBSTR(V_QUERY, 1, LENGTH(V_QUERY) - 1);
   			    
   			END IF;
   			
   			V_QUERY := V_QUERY || V_SUBQRY || ' ';
   			
			
			IF P_VEHL_CD <> 'ALL' OR P_LANG_CD <> 'ALL' THEN
			  	 
				 V_QUERY := V_QUERY ||
   			                    'FROM (SELECT DL_EXPD_CO_CD,' ||
   					                         'DL_EXPD_NAT_CD ' ||
   					                  'FROM TB_NATL_LANG_MGMT ' ||
									  'WHERE DL_EXPD_CO_CD = ''' || P_EXPD_CO_CD || ''' ' ||
   				                      'AND DL_EXPD_NAT_CD LIKE ''' || P_EXPD_NAT_CD || '%'' ' ||
									  'AND A.MDL_MDY_CD = ''' || P_MDL_MDY_CD || ''' ';
				 
				 IF P_VEHL_CD <> 'ALL' THEN
			  	 
				 	V_QUERY := V_QUERY ||
				                      'AND QLTY_VEHL_CD = ''' || P_VEHL_CD || ''' ';
			  	 END IF;
			  
			     IF P_LANG_CD <> 'ALL' THEN
			  	 
				    V_QUERY := V_QUERY ||
				                      'AND LANG_CD = ''' || P_LANG_CD || ''' ';
			     END IF;
									  
				 V_QUERY := V_QUERY ||
				                      'GROUP BY DL_EXPD_CO_CD, DL_EXPD_NAT_CD ' ||
				 		 		    ') A,' ||
									'TB_NATL_LANG_MGMT B,' ||
   				                    'TB_NATL_MGMT C,' ||
									'TB_CODE_MGMT D ' ||
   		                       'WHERE A.DL_EXPD_CO_CD = B.DL_EXPD_CO_CD ' ||
   		                       'AND A.DL_EXPD_NAT_CD = B.DL_EXPD_NAT_CD ' ||
						       'AND B.MDL_MDY_CD = ''' || P_MDL_MDY_CD || ''' ' ||
							   'AND A.DL_EXPD_CO_CD = C.DL_EXPD_CO_CD ' ||
   			                   'AND A.DL_EXPD_NAT_CD = C.DL_EXPD_NAT_CD ' ||
							   'AND C.DL_EXPD_REGN_CD = D.DL_EXPD_PRVS_CD(+) ' ||
							   'AND D.DL_EXPD_G_CD(+) = ''0008'' ' ||
   			                   'GROUP BY A.DL_EXPD_CO_CD, A.DL_EXPD_NAT_CD ' ||
							   'ORDER BY MAX(C.NAT_NM) ' ||
						      ')';			 				  
									  
			ELSE
			  
			  	 V_QUERY := V_QUERY ||
   			               	   'FROM (SELECT DL_EXPD_CO_CD,' ||
   					                        'DL_EXPD_NAT_CD ' ||
   					                 'FROM TB_NATL_MGMT ' ||
   				                     'WHERE DL_EXPD_CO_CD = ''' || P_EXPD_CO_CD || ''' ' ||
   				                     'AND DL_EXPD_NAT_CD LIKE ''' || P_EXPD_NAT_CD || '%'' ' ||
   						            ') A,' ||
   					                'TB_NATL_LANG_MGMT B,' ||
   				                    'TB_NATL_MGMT C,' ||
									'TB_CODE_MGMT D ' ||
   		                       'WHERE A.DL_EXPD_CO_CD = B.DL_EXPD_CO_CD(+) ' ||
   		                       'AND A.DL_EXPD_NAT_CD = B.DL_EXPD_NAT_CD(+) ' ||
						       'AND B.MDL_MDY_CD(+) = ''' || P_MDL_MDY_CD || ''' ' ||
							   'AND A.DL_EXPD_CO_CD = C.DL_EXPD_CO_CD ' ||
   			                   'AND A.DL_EXPD_NAT_CD = C.DL_EXPD_NAT_CD ' ||
							   'AND C.DL_EXPD_REGN_CD = D.DL_EXPD_PRVS_CD(+) ' ||
							   'AND D.DL_EXPD_G_CD(+) = ''0008'' ' ||
   			                   'GROUP BY A.DL_EXPD_CO_CD, A.DL_EXPD_NAT_CD ' ||
							   'ORDER BY MAX(C.NAT_NM) ' ||
						      ')';			   
			
   			               
			END IF;

			OPEN RS FOR V_QUERY;		
				   
	   END SP_GET_NATL_LANT_MGMT_EXCEL;
	   
       --취급설명서 국가코드에 해당하는 APS국가코드 내역 리턴 	   
	   FUNCTION FU_GET_DYTM_NATL_LIST(P_EXPD_CO_CD   TB_NATL_MGMT.DL_EXPD_CO_CD%TYPE,
	   								  P_EXPD_NAT_CD  TB_NATL_MGMT.DL_EXPD_NAT_CD%TYPE) RETURN VARCHAR2
	   IS
	   	 
		 V_NATL_LIST VARCHAR2(8000);
		 
		 CURSOR DYTM_NATL_LIST IS SELECT DYTM_PLN_NAT_CD
	   	                          FROM TB_ALTN_NATL_MGMT
								  WHERE DL_EXPD_CO_CD = P_EXPD_CO_CD
								  AND DL_EXPD_NAT_CD = P_EXPD_NAT_CD
								  AND PRVS_SCN_CD = 'A'
								  ORDER BY DYTM_PLN_NAT_CD;
									
	   BEGIN
	   	
			V_NATL_LIST := '';
			
			FOR NATL_LIST IN DYTM_NATL_LIST LOOP
			
				V_NATL_LIST := V_NATL_LIST || NATL_LIST.DYTM_PLN_NAT_CD || ',';
			
		    END LOOP;
		
		IF LENGTH(V_NATL_LIST) > 0 THEN
		   
		   V_NATL_LIST := SUBSTR(V_NATL_LIST, 1, LENGTH(V_NATL_LIST) - 1);
		   
		END IF;
		
		   RETURN V_NATL_LIST;	
			
	   END FU_GET_DYTM_NATL_LIST;
/**********************************************************/
	   /**
	   FUNCTION FU_GET_VEL_LANG_LIST(P_MENU_ID     VARCHAR2,
							      	 P_USER_EENO   VARCHAR2,
	   								 P_EXPD_CO_CD  TB_NATL_MGMT.DL_EXPD_CO_CD%TYPE,
	   								 P_EXPD_NAT_CD TB_NATL_MGMT.DL_EXPD_NAT_CD%TYPE,
									 P_MDL_MDY_CD  VARCHAR2) RETURN VARCHAR2
	   IS
	   	 
		 V_VEHL_LIST VARCHAR2(8000);
		 
		 CURSOR NATL_VEHL_LIST IS SELECT QLTY_VEHL_CD, MDL_MDY_CD
	   	                          FROM TB_NATL_LANG_MGMT A,
								       (SELECT QLTY_VEHL_CD
                       				    FROM TB_AUTH_VEHL_MGMT
                       					WHERE MENU_ID = PG_COMMON.FU_RPAD(P_MENU_ID, 10)
                       					AND USER_EENO = PG_COMMON.FU_RPAD(P_USER_EENO, 7)
                       					GROUP BY QLTY_VEHL_CD
                                       ) B
								  WHERE DL_EXPD_CO_CD = P_EXPD_CO_CD
								  AND DL_EXPD_NAT_CD = P_EXPD_NAT_CD
								  AND A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
								  AND A.MDL_MDY_CD = P_MDL_MDY_CD
								  ORDER BY A.QLTY_VEHL_CD;
								  
	   BEGIN
	   
	   END FU_GET_VEL_LANG_LIST; 
	   **/
/**********************************************************/
       --취급설명서 국가코드, 차종, 연식에 해당하는 언어코드 내역 리턴   
	   FUNCTION FU_GET_LANG_LIST(P_EXPD_CO_CD   TB_NATL_MGMT.DL_EXPD_CO_CD%TYPE,
	   							 P_EXPD_NAT_CD  TB_NATL_MGMT.DL_EXPD_NAT_CD%TYPE,
								 P_QLTY_VEHL_CD TB_NATL_LANG_MGMT.QLTY_VEHL_CD%TYPE,
								 P_MDL_MDY_CD	TB_NATL_LANG_MGMT.MDL_MDY_CD%TYPE) RETURN VARCHAR2
	   IS
	   	 
		 V_LANG_LIST VARCHAR2(8000);
		 
		 CURSOR NATL_LANG_LIST IS SELECT LANG_CD
	   	                          FROM TB_NATL_LANG_MGMT
								  WHERE DL_EXPD_CO_CD = P_EXPD_CO_CD
								  AND DL_EXPD_NAT_CD = P_EXPD_NAT_CD
								  AND QLTY_VEHL_CD = P_QLTY_VEHL_CD
								  AND MDL_MDY_CD = P_MDL_MDY_CD;
									
	   BEGIN
	   	
			V_LANG_LIST := '';
			
			FOR LANG_LIST IN NATL_LANG_LIST LOOP
			
				V_LANG_LIST := V_LANG_LIST || LANG_LIST.LANG_CD || ',';
			
		    END LOOP;
		
		IF LENGTH(V_LANG_LIST) > 0 THEN
		   
		   V_LANG_LIST := SUBSTR(V_LANG_LIST, 1, LENGTH(V_LANG_LIST) - 1);
		   
		END IF;
		
		   RETURN V_LANG_LIST;	
	   
	   END FU_GET_LANG_LIST;
/**********************************************************/
	   --수정시에 해당국가정보에 해당하는 정보를 조회 
	   PROCEDURE SP_GET_NATL_INFO(P_EXPD_CO_CD  VARCHAR2,
								  P_EXPD_NAT_CD TB_NATL_MGMT.DL_EXPD_NAT_CD%TYPE,
								  RS OUT REFCUR)
	   IS
	   	 
		 V_CNT NUMBER;
		 
	   BEGIN
	   		
			--현재의 국가정보가 국가코드 테이블에 있는 것인지 아니면 미지정국가코드 테이블에 있는 것인지 확인해야 한다.
			SELECT COUNT(*)
			INTO V_CNT
			FROM TB_NATL_NOAPIM_MGMT
			WHERE DL_EXPD_CO_CD = P_EXPD_CO_CD
			AND DL_EXPD_NAT_CD = P_EXPD_NAT_CD;
			
			--미지정국가정보에 있는 국가정보이다. 
			IF V_CNT > 0 THEN
			   
			   OPEN RS FOR
			   		SELECT DL_EXPD_CO_CD AS EXPD_CO_CD,
					       DL_EXPD_NAT_CD AS EXPD_NAT_CD,
						   NAT_NM,
						   DYTM_PLN_NAT_CD DYTM_PLN_NAT_LIST,
						   '' AS DL_EXPD_REGN_CD
					FROM TB_NATL_NOAPIM_MGMT
					WHERE DL_EXPD_CO_CD = P_EXPD_CO_CD
					AND DL_EXPD_NAT_CD = P_EXPD_NAT_CD;
			ELSE
				
				OPEN RS FOR
					SELECT DL_EXPD_CO_CD AS EXPD_CO_CD,
					       DL_EXPD_NAT_CD AS EXPD_NAT_CD,
						   NAT_NM,
						   FU_GET_DYTM_NATL_LIST(DL_EXPD_CO_CD, DL_EXPD_NAT_CD) AS DYTM_PLN_NAT_LIST,
						   DL_EXPD_REGN_CD
					FROM TB_NATL_MGMT
					WHERE DL_EXPD_CO_CD = P_EXPD_CO_CD
					AND DL_EXPD_NAT_CD = P_EXPD_NAT_CD;
			END IF;
	 
	   END SP_GET_NATL_INFO;
	   
	   --수정시에 현재 선택된 국가에 대한 차종-언어정보를 조회 
	   PROCEDURE SP_GET_VEHL_LANG_LIST(P_MENU_ID     VARCHAR2,
							           P_USER_EENO   VARCHAR2,
	   			 				       P_EXPD_CO_CD  VARCHAR2,
									   P_EXPD_NAT_CD TB_NATL_MGMT.DL_EXPD_NAT_CD%TYPE,
	   			 				       P_MDL_MDY_CD  VARCHAR2,
								       RS OUT REFCUR)
	   IS
	   BEGIN
	   		
			OPEN RS FOR
				 SELECT P_EXPD_CO_CD AS EXPD_CO_CD,
				 		P_EXPD_NAT_CD AS EXPD_NAT_CD,
				 		B.QLTY_VEHL_CD, 
				        B.MDL_MDY_CD,
						FU_GET_LANG_LIST(P_EXPD_CO_CD, P_EXPD_NAT_CD, B.QLTY_VEHL_CD, B.MDL_MDY_CD) AS LANG_LIST
                 FROM (SELECT QLTY_VEHL_CD,
				              MAX(CL_SCN_CD) AS CL_SCN_CD
                       FROM TB_AUTH_VEHL_MGMT
                       WHERE MENU_ID = PG_COMMON.FU_RPAD(P_MENU_ID, 10)
                       AND USER_EENO = PG_COMMON.FU_RPAD(P_USER_EENO, 7)
                       GROUP BY QLTY_VEHL_CD
                      ) A,
                      TB_VEHL_MGMT B
                 WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
                 AND B.MDL_MDY_CD = P_MDL_MDY_CD
				 AND B.DL_EXPD_CO_CD = P_EXPD_CO_CD
				 ORDER BY B.QLTY_VEHL_CD;
			
	   END SP_GET_VEHL_LANG_LIST;

	   --국가정보 수정 
	   PROCEDURE SP_NATL_INFO_SAVE(P_EXPD_CO_CD        TB_NATL_MGMT.DL_EXPD_CO_CD%TYPE,
                                   P_EXPD_NAT_CD       TB_NATL_MGMT.DL_EXPD_NAT_CD%TYPE,
								   P_NEW_EXPD_NAT_CD   TB_NATL_MGMT.DL_EXPD_NAT_CD%TYPE,
								   P_NAT_NM            VARCHAR2,
								   P_DYTM_PLN_NAT_LIST VARCHAR2,
								   P_USER_EENO         VARCHAR2,
								   P_REGION			   VARCHAR2
								   )
	   IS
	   	 
		 V_CNT NUMBER;
		 
	   BEGIN
	   		
			SP_NOAPIM_DYTM_NATL_INFO_DEL(P_EXPD_CO_CD, P_EXPD_NAT_CD);
			   
			--국가코드 변경 없이 내역만 수정하는 경우 
			IF P_NEW_EXPD_NAT_CD IS NULL OR P_NEW_EXPD_NAT_CD = '' THEN
			   
			   UPDATE TB_NATL_MGMT
			   SET NAT_NM = P_NAT_NM,
			   	   DL_EXPD_REGN_CD = P_REGION,
			       UPDR_EENO = P_USER_EENO,
				   MDFY_DTM = SYSDATE
			   WHERE DL_EXPD_CO_CD = P_EXPD_CO_CD
			   AND DL_EXPD_NAT_CD = P_EXPD_NAT_CD;
			   
			   IF SQL%NOTFOUND THEN
			   	  
				  INSERT INTO TB_NATL_MGMT
				  (DL_EXPD_CO_CD,
				   DL_EXPD_NAT_CD,
				   DL_EXPD_REGN_CD,
				   NAT_NM,
				   PPRR_EENO,
				   FRAM_DTM,
				   UPDR_EENO,
				   MDFY_DTM
				  )
				  VALUES
				  (P_EXPD_CO_CD,
				   P_EXPD_NAT_CD,
				   P_REGION,
				   P_NAT_NM,
				   P_USER_EENO,
				   SYSDATE,
				   P_USER_EENO,
				   SYSDATE
				  );
				  
			   END IF;
			   
			   SP_DYTM_NATL_INFO_SAVE(P_EXPD_CO_CD, 
								      P_EXPD_NAT_CD, 
								      P_DYTM_PLN_NAT_LIST,
									  'R', 
								      P_USER_EENO); 
									  
			--국가코드를 변경하는 경우 
		    ELSE
			   
			   --이전의 국가코드 정보를 제거하여 준다.
			   DELETE FROM TB_NATL_MGMT
			   WHERE DL_EXPD_CO_CD = P_EXPD_CO_CD
			   AND DL_EXPD_NAT_CD = P_EXPD_NAT_CD;
			   
			   --이전의 국가코드 정보에 들어있던 APS국가 정보를 삭제하여 준다.
			   DELETE FROM TB_ALTN_NATL_MGMT
			   WHERE DL_EXPD_CO_CD = P_EXPD_CO_CD
			   AND DL_EXPD_NAT_CD = P_EXPD_NAT_CD;
			   
			   --추가하고자 하는 국가코드 정보가 존재하는지의 여부를 확인한다.
			   SELECT COUNT(*)
			   INTO V_CNT
			   FROM TB_NATL_MGMT
			   WHERE DL_EXPD_CO_CD = P_EXPD_CO_CD
			   AND DL_EXPD_NAT_CD = P_NEW_EXPD_NAT_CD;
			   
			   IF V_CNT = 0 THEN
			   	  
				  /**
				  UPDATE TB_NATL_MGMT
			   	  SET DL_EXPD_NAT_CD = P_NEW_EXPD_NAT_CD,
			   	   	  NAT_NM = P_NAT_NM,
			       	  UPDR_EENO = P_USER_EENO,
				   	  MDFY_DTM = SYSDATE
			      WHERE DL_EXPD_CO_CD = P_EXPD_CO_CD
			      AND DL_EXPD_NAT_CD = P_EXPD_NAT_CD;
				  **/
				  
				  --추가하고자 하는 국가코드 정보가 존재하지 않는 경우에만 추가해 준다. 
				  --IF SQL%NOTFOUND THEN
			   	  
   				    INSERT INTO TB_NATL_MGMT
   				    (DL_EXPD_CO_CD,
   				     DL_EXPD_NAT_CD,
   				     NAT_NM,
   				     PPRR_EENO,
   				     FRAM_DTM,
   				     UPDR_EENO,
   				     MDFY_DTM
   				    )
   				    VALUES
   				    (P_EXPD_CO_CD,
   				     P_NEW_EXPD_NAT_CD,
   				     P_NAT_NM,
   				     P_USER_EENO,
   				     SYSDATE,
   				     P_USER_EENO,
   				     SYSDATE
   				    );
				  
			      --END IF;
				  
			   END IF;
			   
			   --새로운 국가코드에 대한 APS국가정보를 저장하여 준다.
			   SP_DYTM_NATL_INFO_SAVE(P_EXPD_CO_CD, 
								      P_NEW_EXPD_NAT_CD, 
								      P_DYTM_PLN_NAT_LIST,
									  'U',
								      P_USER_EENO); 
								   
			END IF;
			
	   END SP_NATL_INFO_SAVE;
	   
	   --국가정보 신규 입력 
	   PROCEDURE SP_NATL_INFO_INSERT(P_EXPD_CO_CD        TB_NATL_MGMT.DL_EXPD_CO_CD%TYPE,
                                     P_EXPD_NAT_CD       TB_NATL_MGMT.DL_EXPD_NAT_CD%TYPE,
								     P_NAT_NM            VARCHAR2,
								     P_DYTM_PLN_NAT_LIST VARCHAR2,
								     P_USER_EENO         VARCHAR2,
									 P_REGION			 VARCHAR2
								    )
	   IS
	   BEGIN
	   		
			INSERT INTO TB_NATL_MGMT
		    (DL_EXPD_CO_CD,
		     DL_EXPD_NAT_CD,
			 DL_EXPD_REGN_CD,
		     NAT_NM,
		     PPRR_EENO,
		     FRAM_DTM,
		     UPDR_EENO,
		     MDFY_DTM
		    )
		    VALUES
		    (P_EXPD_CO_CD,
		     P_EXPD_NAT_CD,
			 P_REGION,
		     P_NAT_NM,
		     P_USER_EENO,
		     SYSDATE,
		     P_USER_EENO,
		     SYSDATE
		    );
			
			SP_DYTM_NATL_INFO_INSERT(P_EXPD_CO_CD,
			                         P_EXPD_NAT_CD,
									 P_DYTM_PLN_NAT_LIST,
									 P_USER_EENO);
									 
	   END SP_NATL_INFO_INSERT;
	   
	   --취급설명서 국가코드에 해당하는 APS 국가코드 리스트 저장 
	   PROCEDURE SP_DYTM_NATL_INFO_SAVE(P_EXPD_CO_CD        TB_NATL_MGMT.DL_EXPD_CO_CD%TYPE,
	                                    P_EXPD_NAT_CD       TB_NATL_MGMT.DL_EXPD_NAT_CD%TYPE,
										P_DYTM_PLN_NAT_LIST VARCHAR2,
										P_UPDATE_MODE		VARCHAR2,
								        P_USER_EENO         VARCHAR2)
	   IS
	   	  V_NATL_LIST       PG_COMMON.LIST_TYPE;
		  V_NATL_CNT        BINARY_INTEGER;
		  
		  V_CNT             NUMBER;
		  
		  V_DYTM_PLN_NAT_CD VARCHAR2(5);
		  
	   BEGIN
	   		
			V_NATL_LIST := PG_COMMON.FU_SPLIT(P_DYTM_PLN_NAT_LIST, V_NATL_CNT);
			
			IF P_UPDATE_MODE = 'R' THEN
			   				 
			   --기존의 국가코드 정보에 들어있던 APS국가 정보를 삭제하여 준다.
			   DELETE FROM TB_ALTN_NATL_MGMT
			   WHERE DL_EXPD_CO_CD = P_EXPD_CO_CD
			   AND DL_EXPD_NAT_CD = P_EXPD_NAT_CD
			   AND PRVS_SCN_CD = 'A';
			   
			   FOR NATL_NUM IN 1..V_NATL_CNT LOOP
			   	   
				   IF V_NATL_LIST(NATL_NUM) IS NOT NULL THEN
				   	  
					  V_DYTM_PLN_NAT_CD := PG_COMMON.FU_RPAD(V_NATL_LIST(NATL_NUM), 5);
					  
					  --이미 다른 국가의 연계 국가로 등록되어 있는 경우라면 에러를 발생시킨다.
				  	  SELECT COUNT(*)
				  	  INTO V_CNT
				  	  FROM TB_ALTN_NATL_MGMT
				  	  WHERE DL_EXPD_CO_CD = P_EXPD_CO_CD
				  	  AND DYTM_PLN_NAT_CD = V_DYTM_PLN_NAT_CD
					  AND PRVS_SCN_CD = 'A';
				  
				  	  IF V_CNT > 0 THEN
				  	 
					      RAISE_APPLICATION_ERROR(-20001, 'Invalid altn natl information. existing altn natl code - altn_natl:[' || V_DYTM_PLN_NAT_CD || '] co_cd:[' || P_EXPD_CO_CD || ']');
					 
				  	  END IF;
					  
					  SP_NOAPIM_DYTM_NATL_INFO_DEL(P_EXPD_CO_CD, V_DYTM_PLN_NAT_CD);
					  
					  INSERT INTO TB_ALTN_NATL_MGMT
    			      (DL_EXPD_CO_CD,
    			       DL_EXPD_NAT_CD,
    			       DYTM_PLN_NAT_CD,
    				   PRVS_SCN_CD,
    			       PPRR_EENO,
    			       FRAM_DTM,
    			       UPDR_EENO,
    			       MDFY_DTM
    			      )
    			      VALUES
    			      (P_EXPD_CO_CD,
    			       P_EXPD_NAT_CD,
    			       V_DYTM_PLN_NAT_CD,
    				   'A',
    			       P_USER_EENO,
    			       SYSDATE,
    			       P_USER_EENO,
    			       SYSDATE
    			      );
				   				   
				   END IF;

			   END LOOP;
			   		   
			ELSE
			   
			   FOR NATL_NUM IN 1..V_NATL_CNT LOOP
			   	   
				   IF V_NATL_LIST(NATL_NUM) IS NOT NULL THEN
				   	  
					  V_DYTM_PLN_NAT_CD := PG_COMMON.FU_RPAD(V_NATL_LIST(NATL_NUM), 5);
					  
					  --이미 다른 국가의 연계 국가로 등록되어 있는 경우라면 에러를 발생시킨다.
				  	  SELECT COUNT(*)
				  	  INTO V_CNT
				  	  FROM TB_ALTN_NATL_MGMT
				  	  WHERE DL_EXPD_CO_CD = P_EXPD_CO_CD
					  AND DL_EXPD_NAT_CD <> P_EXPD_NAT_CD
				  	  AND DYTM_PLN_NAT_CD = V_DYTM_PLN_NAT_CD
					  AND PRVS_SCN_CD = 'A';
				  
				  	  IF V_CNT > 0 THEN
				  	 
					      RAISE_APPLICATION_ERROR(-20001, 'Invalid altn natl information. existing altn natl code - altn_natl:[' || V_DYTM_PLN_NAT_CD || '] co_cd:[' || P_EXPD_CO_CD || ']');
					 
				  	  END IF;
					  
					  SELECT COUNT(*)
				   	  INTO V_CNT
				   	  FROM TB_ALTN_NATL_MGMT
				   	  WHERE DL_EXPD_CO_CD = P_EXPD_CO_CD
				   	  AND DL_EXPD_NAT_CD = P_EXPD_NAT_CD
				   	  AND DYTM_PLN_NAT_CD = V_DYTM_PLN_NAT_CD
				   	  AND PRVS_SCN_CD = 'A';
					  
					  IF V_CNT = 0 THEN
				   	     
						 SP_NOAPIM_DYTM_NATL_INFO_DEL(P_EXPD_CO_CD, V_DYTM_PLN_NAT_CD);
					  
					  	 INSERT INTO TB_ALTN_NATL_MGMT
  					     (DL_EXPD_CO_CD,
  					      DL_EXPD_NAT_CD,
  					      DYTM_PLN_NAT_CD,
  					      PRVS_SCN_CD,
  					      PPRR_EENO,
  					      FRAM_DTM,
  					      UPDR_EENO,
  					      MDFY_DTM
  					     )
  					     VALUES
  					     (P_EXPD_CO_CD,
  					      P_EXPD_NAT_CD,
  					      V_DYTM_PLN_NAT_CD,
  					      'A',
  					      P_USER_EENO,
  					      SYSDATE,
  					      P_USER_EENO,
  					      SYSDATE
  					     );
						
				   	  END IF;
				   				   
				   END IF;
			 
			   END LOOP;
			   
			END IF;
			
	   END SP_DYTM_NATL_INFO_SAVE;
	   
	   --취급설명서 국가코드에 해당하는 APS 국가코드 리스트 신규 입력
	   PROCEDURE SP_DYTM_NATL_INFO_INSERT(P_EXPD_CO_CD        TB_NATL_MGMT.DL_EXPD_CO_CD%TYPE,
	                                      P_EXPD_NAT_CD       TB_NATL_MGMT.DL_EXPD_NAT_CD%TYPE,
								          P_DYTM_PLN_NAT_LIST VARCHAR2,
										  P_USER_EENO         VARCHAR2)
	   IS
	   	 
		 V_NATL_LIST       PG_COMMON.LIST_TYPE;
		 V_NATL_CNT        BINARY_INTEGER;
		 
		 V_CNT		       NUMBER;
		 
		 V_DYTM_PLN_NAT_CD VARCHAR2(5);
		 
	   BEGIN
	   		
			V_NATL_LIST := PG_COMMON.FU_SPLIT(P_DYTM_PLN_NAT_LIST, V_NATL_CNT);
			
			FOR NATL_NUM IN 1..V_NATL_CNT LOOP
		   	   
			   IF V_NATL_LIST(NATL_NUM) IS NOT NULL THEN
			   	  
				  V_DYTM_PLN_NAT_CD := PG_COMMON.FU_RPAD(V_NATL_LIST(NATL_NUM), 5);
				  
				  --이미 다른 국가의 연계 국가로 등록되어 있는 경우라면 에러를 발생시킨다.
				  SELECT COUNT(*)
				  INTO V_CNT
				  FROM TB_ALTN_NATL_MGMT
				  WHERE DL_EXPD_CO_CD = P_EXPD_CO_CD
				  --AND DL_EXPD_NAT_CD <> P_EXPD_NAT_CD 
				  AND DYTM_PLN_NAT_CD = V_DYTM_PLN_NAT_CD
				  AND PRVS_SCN_CD = 'A';
				  
				  IF V_CNT > 0 THEN
				  	 
				      RAISE_APPLICATION_ERROR(-20001, 'Invalid altn natl information. existing altn natl code - altn_natl:[' || V_DYTM_PLN_NAT_CD || '] co_cd:[' || P_EXPD_CO_CD || ']');
					 
				  END IF;
					  
				  SP_NOAPIM_DYTM_NATL_INFO_DEL(P_EXPD_CO_CD, V_DYTM_PLN_NAT_CD);
			
				  INSERT INTO TB_ALTN_NATL_MGMT
		       	  (DL_EXPD_CO_CD,
		           DL_EXPD_NAT_CD,
		           DYTM_PLN_NAT_CD,
			       PRVS_SCN_CD,
		           PPRR_EENO,
		           FRAM_DTM,
		           UPDR_EENO,
		           MDFY_DTM
		       	  )
		       	  VALUES
		       	  (P_EXPD_CO_CD,
		           P_EXPD_NAT_CD,
		           V_DYTM_PLN_NAT_CD,
			       'A',
		           P_USER_EENO,
		           SYSDATE,
		           P_USER_EENO,
		           SYSDATE
		          );
			   			   
			   END IF;

		   END LOOP;
			   
	   END SP_DYTM_NATL_INFO_INSERT;
	   
	   --미지정 국가 코드 내역 삭제 
	   PROCEDURE SP_NOAPIM_DYTM_NATL_INFO_DEL(P_EXPD_CO_CD    VARCHAR2,
	                                          P_EXPD_NAT_CD   VARCHAR2)
	   IS
	   	 
		 V_CNT NUMBER;
		 
	   BEGIN
	   		
			--현재의 국가정보가 국가코드 테이블에 있는 것인지 아니면 미지정국가코드 테이블에 있는 것인지 확인해야 한다.
			SELECT COUNT(*)
			INTO V_CNT
			FROM TB_NATL_NOAPIM_MGMT
			WHERE DL_EXPD_CO_CD = P_EXPD_CO_CD
			AND DL_EXPD_NAT_CD = P_EXPD_NAT_CD;
			
			--미지정 국가코드 정보에 있는 내역이면 그 내역을 삭제해 준다.
			IF V_CNT > 0 THEN
			   
			   DELETE FROM TB_NATL_NOAPIM_MGMT
			   WHERE DL_EXPD_CO_CD = P_EXPD_CO_CD
			   AND DL_EXPD_NAT_CD = P_EXPD_NAT_CD;
			
			END IF;
			
	   END SP_NOAPIM_DYTM_NATL_INFO_DEL;
	   
	   
	   --국가별 차종-언어 정보 저장 								  
	   PROCEDURE SP_VEHL_LANG_INFO_SAVE(P_EXPD_CO_CD      TB_NATL_MGMT.DL_EXPD_CO_CD%TYPE,
	                                    P_EXPD_NAT_CD     TB_NATL_MGMT.DL_EXPD_NAT_CD%TYPE,
										P_NEW_EXPD_NAT_CD TB_NATL_MGMT.DL_EXPD_NAT_CD%TYPE,
										P_MDL_MDY_CD      VARCHAR2,
										P_QLTY_VEHL_CD    VARCHAR2,
										P_LANG_LIST       VARCHAR2,
										P_USER_EENO       VARCHAR2)
	   IS
	   	  
		  V_LANG_LIST PG_COMMON.LIST_TYPE;
		  V_LANG_CNT  BINARY_INTEGER;
		  
		  V_CNT NUMBER;
		  
	   BEGIN
	   		
			V_LANG_LIST := PG_COMMON.FU_SPLIT(P_LANG_LIST, V_LANG_CNT);
			
			--기존의 차종-언어 정보를 삭제한다.
			DELETE FROM TB_NATL_LANG_MGMT
			WHERE DL_EXPD_CO_CD = P_EXPD_CO_CD
			AND DL_EXPD_NAT_CD = P_EXPD_NAT_CD
			AND QLTY_VEHL_CD = P_QLTY_VEHL_CD
			AND MDL_MDY_CD = P_MDL_MDY_CD;
			   
			--국가코드 변경 없이 내역만 수정하는 경우 
			IF P_NEW_EXPD_NAT_CD IS NULL OR P_NEW_EXPD_NAT_CD = '' THEN
			   
			   FOR LANG_NUM IN 1..V_LANG_CNT LOOP
		   	   	   
				   IF V_LANG_LIST(LANG_NUM) IS NOT NULL THEN
				   	  
					  INSERT INTO TB_NATL_LANG_MGMT
    		       	  (DL_EXPD_CO_CD,
    		           DL_EXPD_NAT_CD,
    		           QLTY_VEHL_CD,
					   MDL_MDY_CD,
    			       LANG_CD,
					   USE_YN,
					   NAPC_YN,
    		           PPRR_EENO,
    		           FRAM_DTM,
    		           UPDR_EENO,
    		           MDFY_DTM
    		          )
    		          VALUES
    		          (P_EXPD_CO_CD,
    		           P_EXPD_NAT_CD,
					   P_QLTY_VEHL_CD,
					   P_MDL_MDY_CD,
    		           V_LANG_LIST(LANG_NUM),
    			       'Y',
					   'N',
    		           P_USER_EENO,
    		           SYSDATE,
    		           P_USER_EENO,
    		           SYSDATE
    		         );
				   
				     SP_NATL_VEHL_SAVE(P_EXPD_CO_CD,
	   							       P_EXPD_NAT_CD,
								       P_QLTY_VEHL_CD,
								       P_MDL_MDY_CD,
								       V_LANG_LIST(LANG_NUM),
								       P_USER_EENO);
									 
				   END IF;
		   
		        END LOOP;
			
			ELSE
				
				--이전 국가에 대한 차종-국가정보 삭제 
				DELETE FROM TB_NATL_VEHL_MGMT
				WHERE DL_EXPD_CO_CD = P_EXPD_CO_CD
				AND DL_EXPD_NAT_CD = P_EXPD_NAT_CD
				AND QLTY_VEHL_CD = P_QLTY_VEHL_CD;
				
				FOR LANG_NUM IN 1..V_LANG_CNT LOOP
		   	       
				   IF V_LANG_LIST(LANG_NUM) IS NOT NULL THEN
				   	  
					  SELECT COUNT(*)
				   	  INTO V_CNT
				   	  FROM TB_NATL_LANG_MGMT
				   	  WHERE DL_EXPD_CO_CD = P_EXPD_CO_CD
				   	  AND DL_EXPD_NAT_CD = P_NEW_EXPD_NAT_CD
				   	  AND QLTY_VEHL_CD = P_QLTY_VEHL_CD
				   	  AND MDL_MDY_CD = P_MDL_MDY_CD
				   	  AND LANG_CD = V_LANG_LIST(LANG_NUM);
				   
				   	  IF V_CNT = 0 THEN
				   	  
					  	 INSERT INTO TB_NATL_LANG_MGMT
       		          	 (DL_EXPD_CO_CD,
       		           	  DL_EXPD_NAT_CD,
       		           	  QLTY_VEHL_CD,
   					   	  MDL_MDY_CD,
       			       	  LANG_CD,
   					   	  USE_YN,
   					   	  NAPC_YN,
       		           	  PPRR_EENO,
       		           	  FRAM_DTM,
       		           	  UPDR_EENO,
       		           	  MDFY_DTM
       		             )
       		          	 VALUES
       		          	 (P_EXPD_CO_CD,
       		           	  P_NEW_EXPD_NAT_CD,
   					   	  P_QLTY_VEHL_CD,
   					   	  P_MDL_MDY_CD,
       		           	  V_LANG_LIST(LANG_NUM),
       			       	  'Y',
   					   	  'N',
       		           	  P_USER_EENO,
       		           	  SYSDATE,
       		           	  P_USER_EENO,
       		           	  SYSDATE
       		             );
				      
					  	 SP_NATL_VEHL_SAVE(P_EXPD_CO_CD,
	   							           P_NEW_EXPD_NAT_CD,
								           P_QLTY_VEHL_CD,
								           P_MDL_MDY_CD,
								           V_LANG_LIST(LANG_NUM),
								           P_USER_EENO);
									 
				   	 END IF;
				   
				   END IF;
				   
		        END LOOP;
				
			END IF;
			
	   END SP_VEHL_LANG_INFO_SAVE;
	   
	   --국가별 차종-언어 정보 신규입력 								  
	   PROCEDURE SP_VEHL_LANG_INFO_INSERT(P_EXPD_CO_CD      TB_NATL_MGMT.DL_EXPD_CO_CD%TYPE,
	                                      P_EXPD_NAT_CD     TB_NATL_MGMT.DL_EXPD_NAT_CD%TYPE,
										  P_MDL_MDY_CD      VARCHAR2,
										  P_QLTY_VEHL_CD    VARCHAR2,
										  P_LANG_LIST       VARCHAR2,
										  P_USER_EENO       VARCHAR2)
	   IS
	   	 
		  V_LANG_LIST PG_COMMON.LIST_TYPE;
		  V_LANG_CNT  BINARY_INTEGER;
		  
	   BEGIN
	   		
			V_LANG_LIST := PG_COMMON.FU_SPLIT(P_LANG_LIST, V_LANG_CNT);
			
			FOR LANG_NUM IN 1..V_LANG_CNT LOOP
		   	   	   
				   IF V_LANG_LIST(LANG_NUM) IS NOT NULL THEN
				   	  
					  INSERT INTO TB_NATL_LANG_MGMT
    		       	  (DL_EXPD_CO_CD,
    		           DL_EXPD_NAT_CD,
    		           QLTY_VEHL_CD,
					   MDL_MDY_CD,
    			       LANG_CD,
					   USE_YN,
					   NAPC_YN,
    		           PPRR_EENO,
    		           FRAM_DTM,
    		           UPDR_EENO,
    		           MDFY_DTM
    		          )
    		       	  VALUES
    		       	  (P_EXPD_CO_CD,
    		           P_EXPD_NAT_CD,
					   P_QLTY_VEHL_CD,
					   P_MDL_MDY_CD,
    		           V_LANG_LIST(LANG_NUM),
    			       'Y',
					   'N',
    		           P_USER_EENO,
    		           SYSDATE,
    		           P_USER_EENO,
    		           SYSDATE
    		          );
				   
				   	  SP_NATL_VEHL_SAVE(P_EXPD_CO_CD,
	   							        P_EXPD_NAT_CD,
								        P_QLTY_VEHL_CD,
								        P_MDL_MDY_CD,
								        V_LANG_LIST(LANG_NUM),
								        P_USER_EENO);
									 
				   END IF;
				   			   
		     END LOOP;
				
	   END SP_VEHL_LANG_INFO_INSERT;
	   
	   
	   --국가에 언어코드 등록시에 국가/차종/지역 을 매핑하는 작업을 수행하는 프로시저
	   --저장시 반드시 같이 호출되어야 함 								 
	   PROCEDURE SP_NATL_VEHL_SAVE(P_EXPD_CO_CD   VARCHAR2,
	   							   P_EXPD_NAT_CD  VARCHAR2,
								   P_QLTY_VEHL_CD VARCHAR2,
								   P_MDL_MDY_CD	  VARCHAR2,
								   P_LANG_CD      VARCHAR2,
								   P_USER_EENO	  VARCHAR2)
	   IS
	   	 
		 V_EXPD_REGN_CD VARCHAR2(4);
		 
		 
		 
	   BEGIN
	   		
			SELECT DL_EXPD_REGN_CD
			INTO V_EXPD_REGN_CD
			FROM TB_LANG_MGMT
			WHERE QLTY_VEHL_CD = P_QLTY_VEHL_CD
			AND MDL_MDY_CD = P_MDL_MDY_CD
			AND LANG_CD = P_LANG_CD;
			
			
			
			UPDATE TB_NATL_VEHL_MGMT
			SET DL_EXPD_REGN_CD = V_EXPD_REGN_CD,
			    UPDR_EENO = P_USER_EENO,
				MDFY_DTM = SYSDATE
		    WHERE DL_EXPD_CO_CD = P_EXPD_CO_CD
			AND DL_EXPD_NAT_CD = P_EXPD_NAT_CD
			AND QLTY_VEHL_CD = P_QLTY_VEHL_CD;
			
			
			IF SQL%NOTFOUND THEN
			   
			   INSERT INTO TB_NATL_VEHL_MGMT
			   (DL_EXPD_CO_CD,
			    DL_EXPD_NAT_CD,
				QLTY_VEHL_CD,
				DL_EXPD_REGN_CD,
				PPRR_EENO,
				FRAM_DTM,
				UPDR_EENO,
				MDFY_DTM
			   )
			   VALUES
			   (P_EXPD_CO_CD,
			    P_EXPD_NAT_CD,
				P_QLTY_VEHL_CD,
				V_EXPD_REGN_CD,
				P_USER_EENO,
				SYSDATE,
				P_USER_EENO,
				SYSDATE
			   );
			   
			END IF;
            
            
            EXCEPTION WHEN OTHERS THEN
                    RAISE_APPLICATION_ERROR(-20001, SQLERRM || ' ' || 
			   								        'vehl:[' || P_QLTY_VEHL_CD || '],' || 
											        'mkyr:[' || P_MDL_MDY_CD || '],' || 
											        'lang:[' || P_LANG_CD || ']');
			
	   END SP_NATL_VEHL_SAVE;


END PG_NATL_LANG_MGMT;