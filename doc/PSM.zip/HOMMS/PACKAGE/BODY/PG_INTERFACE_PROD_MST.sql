CREATE OR REPLACE PACKAGE BODY HOMMS_ADM.PG_INTERFACE_PROD_MST AS
	   
/**********************************************************/	   
	   --현대 생산마스터 인터페이스(외부 호출)
	PROCEDURE PROD_MST_INTERFACE_HMC
	IS
	   	 
		CURR_YMD   VARCHAR2(8);
		APL_YMD     VARCHAR2(8); -- 일 2회 전송 구분용
		ET_GUBN_CD  VARCHAR2(2);
			 
	BEGIN
	   	 
		CURR_YMD := TO_CHAR(SYSDATE, 'YYYYMMDD');
		 
		APL_YMD  := TO_CHAR(SYSDATE - 12/24, 'YYYYMMDD');
	
		IF CURR_YMD = APL_YMD THEN
			-- 오후 전송
			ET_GUBN_CD := '01';
		ELSE
			-- 오전 전송
			ET_GUBN_CD := '02';
		END IF;
		 
		PROD_MST_INTERFACE_HMC2(CURR_YMD, ET_GUBN_CD);
		
		WRITE_BATCH_LOG_DTL('배치로그');		
		 
	END PROD_MST_INTERFACE_HMC;
/**********************************************************/

/**********************************************************/	   						
	PROCEDURE WRITE_BATCH_LOG_DTL(BTCH_NM          IN VARCHAR2)
	IS

		PRAGMA AUTONOMOUS_TRANSACTION;
		STRT_DATE  DATE;
		
	BEGIN
	
	   	STRT_DATE := SYSDATE;
		
		INSERT INTO TB_BATCH_RSLT_INFO
		(BTCH_NM,
		 BTCH_FIN_STRT_DTM,
		 BTCH_FNH_DTM,
		 BTCH_WK_CD,
		 BTCH_WK_RSLT_SBC
		)
		SELECT ID, STRT_DATE, SYSDATE, 'S' AS WK_CD, TRX_CNT AS RSLT_SBC
		FROM (
			SELECT '처리결과상세-001' AS ID, 'TB_PROD_MST_INFO_ERP_HMC - 대상:' || TRIM(TO_CHAR(COUNT(*), '99,999,999'))  || '건' AS TRX_CNT FROM TB_PROD_MST_INFO_ERP_HMC WHERE APL_YMD = TO_CHAR(SYSDATE-1, 'YYYYMMDD') 
			UNION ALL 
			SELECT '처리결과상세-002' AS ID, 'SY_PMS03FB_HMC - 대상:' || TRIM(TO_CHAR(COUNT(*), '99,999,999'))  || '건' AS TRX_CNT  FROM SY_PMS03FB_HMC 
			UNION ALL
			SELECT '처리결과상세-003' AS ID, 'SY_PSE06AC_HMC - 대상:' || TRIM(TO_CHAR(COUNT(*), '99,999,999'))   || '건' AS TRX_CNT  FROM SY_PSE06AC_HMC WHERE SUBSTR(TO_CHAR(PS06A_STTM), 1, 8) = TO_CHAR(STRT_DATE, 'YYYYMMDD')
			UNION ALL
			SELECT '처리결과상세-004' AS ID, 'SY_PSE07HB_HMC - 대상:' || TRIM(TO_CHAR(COUNT(*), '99,999,999'))   || '건' AS TRX_CNT  FROM SY_PSE07HB_HMC 
			UNION ALL	
			SELECT '처리결과상세-01' ID, 'TB_APS_ODR__INFO - 추가:' || TRIM(TO_CHAR(SUM(INS_CNT), '99,999,999')) || '건,  변경:' ||TRIM(TO_CHAR(SUM(UPD_CNT), '99,999,999'))  || '건' TRX_CNT FROM (
				SELECT COUNT(*) INS_CNT, 0 UPD_CNT FROM TB_APS_ODR_INFO	WHERE FRAM_DTM > TO_DATE(TO_CHAR(SYSDATE, 'YYYYMMDD'))	UNION ALL	
				SELECT 0 INS_CNT, COUNT(*) UPD_CNT FROM TB_APS_ODR_INFO	WHERE MDFY_DTM > TO_DATE(TO_CHAR(SYSDATE, 'YYYYMMDD')) AND FRAM_DTM < TO_DATE(TO_CHAR(SYSDATE, 'YYYYMMDD')))
			UNION ALL	
			SELECT '처리결과상세-02' ID, 'TB_APS_ODR_SUM_INFO - 추가:' || TRIM(TO_CHAR(SUM(INS_CNT), '99,999,999')) || '건,  변경:' ||TRIM(TO_CHAR(SUM(UPD_CNT), '99,999,999'))  || '건' TRX_CNT FROM (
				SELECT COUNT(*) INS_CNT, 0 UPD_CNT FROM TB_APS_ODR_SUM_INFO	WHERE FRAM_DTM > TO_DATE(TO_CHAR(SYSDATE, 'YYYYMMDD'))	UNION ALL	
				SELECT 0 INS_CNT, COUNT(*) UPD_CNT FROM TB_APS_ODR_SUM_INFO	WHERE MDFY_DTM > TO_DATE(TO_CHAR(SYSDATE, 'YYYYMMDD')) AND FRAM_DTM < TO_DATE(TO_CHAR(SYSDATE, 'YYYYMMDD')))
			UNION ALL
			SELECT '처리결과상세-03' ID, 'TB_APS_PROD_PLAN_INFO - 추가:' || TRIM(TO_CHAR(SUM(INS_CNT), '99,999,999')) || '건,  변경:' ||TRIM(TO_CHAR(SUM(UPD_CNT), '99,999,999'))  || '건' TRX_CNT FROM (
				SELECT COUNT(*) INS_CNT, 0 UPD_CNT FROM TB_APS_PROD_PLAN_INFO	WHERE FRAM_DTM > TO_DATE(TO_CHAR(SYSDATE, 'YYYYMMDD'))	UNION ALL	
				SELECT 0 INS_CNT, COUNT(*) UPD_CNT FROM TB_APS_PROD_PLAN_INFO	WHERE MDFY_DTM > TO_DATE(TO_CHAR(SYSDATE, 'YYYYMMDD')) AND FRAM_DTM < TO_DATE(TO_CHAR(SYSDATE, 'YYYYMMDD')))
			UNION ALL
			SELECT '처리결과상세-04' ID, 'TB_APS_PROD_PLAN_SUM_INFO - 추가:' || TRIM(TO_CHAR(SUM(INS_CNT), '99,999,999')) || '건,  변경:' ||TRIM(TO_CHAR(SUM(UPD_CNT), '99,999,999'))  || '건' TRX_CNT FROM (
				SELECT COUNT(*) INS_CNT, 0 UPD_CNT FROM TB_APS_PROD_PLAN_SUM_INFO	WHERE FRAM_DTM > TO_DATE(TO_CHAR(SYSDATE, 'YYYYMMDD'))	UNION ALL	
				SELECT 0 INS_CNT, COUNT(*) UPD_CNT FROM TB_APS_PROD_PLAN_SUM_INFO	WHERE MDFY_DTM > TO_DATE(TO_CHAR(SYSDATE, 'YYYYMMDD')) AND FRAM_DTM < TO_DATE(TO_CHAR(SYSDATE, 'YYYYMMDD')))
			UNION ALL
			SELECT '처리결과상세-05' ID, 'TB_APS_PROD_SUM_INFO - 추가:' || TRIM(TO_CHAR(SUM(INS_CNT), '99,999,999')) || '건,  변경:' ||TRIM(TO_CHAR(SUM(UPD_CNT), '99,999,999'))  || '건' TRX_CNT FROM (
				SELECT COUNT(*) INS_CNT, 0 UPD_CNT FROM TB_APS_PROD_SUM_INFO	WHERE FRAM_DTM > TO_DATE(TO_CHAR(SYSDATE, 'YYYYMMDD'))	UNION ALL	
				SELECT 0 INS_CNT, COUNT(*) UPD_CNT FROM TB_APS_PROD_SUM_INFO	WHERE MDFY_DTM > TO_DATE(TO_CHAR(SYSDATE, 'YYYYMMDD')) AND FRAM_DTM < TO_DATE(TO_CHAR(SYSDATE, 'YYYYMMDD')))
			UNION ALL
			SELECT '처리결과상세-06' ID, 'TB_NATL_NOAPIM_MGMT - 추가:' || TRIM(TO_CHAR(SUM(INS_CNT), '99,999,999')) || '건,  변경:' ||TRIM(TO_CHAR(SUM(UPD_CNT), '99,999,999'))  || '건, 국가/언어코드 미지정 국가 : ' ||
				NVL(( SELECT AGGR_CONCAT(QLTY_VEHL_CD || ':' ||  MDL_MDY_CD || ':' || PRDN_MST_NAT_CD, ', ') FROM TB_PROD_MST_NOAPIM_INFO WHERE FRAM_DTM > TO_DATE(TO_CHAR(SYSDATE-1, 'YYYYMMDD'))	OR (MDFY_DTM > TO_DATE(TO_CHAR(SYSDATE, 'YYYYMMDD')) AND FRAM_DTM < TO_DATE(TO_CHAR(SYSDATE, 'YYYYMMDD')))), '없음') AS TRX_CNT FROM (
				SELECT COUNT(*) INS_CNT, 0 UPD_CNT FROM TB_NATL_NOAPIM_MGMT	WHERE FRAM_DTM > TO_DATE(TO_CHAR(SYSDATE, 'YYYYMMDD'))	UNION ALL	
				SELECT 0 INS_CNT, COUNT(*) UPD_CNT FROM TB_NATL_NOAPIM_MGMT	WHERE MDFY_DTM > TO_DATE(TO_CHAR(SYSDATE, 'YYYYMMDD')) AND FRAM_DTM < TO_DATE(TO_CHAR(SYSDATE, 'YYYYMMDD')))
			UNION ALL
			SELECT '처리결과상세-07' ID, 'TB_ALTN_WIOUT_NATL_MGMT - 추가:' || TRIM(TO_CHAR(SUM(INS_CNT), '99,999,999')) || '건,  변경:' ||TRIM(TO_CHAR(SUM(UPD_CNT), '99,999,999'))  || '건, 제외대리점코드 : ' ||
				NVL(( SELECT AGGR_CONCAT(DYTM_PLN_NAT_CD, ',') FROM TB_ALTN_WIOUT_NATL_MGMT WHERE FRAM_DTM > TO_DATE(TO_CHAR(SYSDATE-1, 'YYYYMMDD')) OR (MDFY_DTM > TO_DATE(TO_CHAR(SYSDATE, 'YYYYMMDD')) AND FRAM_DTM < TO_DATE(TO_CHAR(SYSDATE, 'YYYYMMDD')))), '없음') AS TRX_CNT FROM (
				SELECT COUNT(*) INS_CNT, 0 UPD_CNT FROM TB_ALTN_WIOUT_NATL_MGMT	WHERE FRAM_DTM > TO_DATE(TO_CHAR(SYSDATE, 'YYYYMMDD'))	UNION ALL	
				SELECT 0 INS_CNT, COUNT(*) UPD_CNT FROM TB_ALTN_WIOUT_NATL_MGMT	WHERE MDFY_DTM > TO_DATE(TO_CHAR(SYSDATE, 'YYYYMMDD')) AND FRAM_DTM < TO_DATE(TO_CHAR(SYSDATE, 'YYYYMMDD')))
			UNION ALL
			SELECT '처리결과상세-08' ID, 'TB_PROD_MST_NOAPIM_INFO - 추가:' || TRIM(TO_CHAR(SUM(INS_CNT), '99,999,999')) || '건,  변경:' ||TRIM(TO_CHAR(SUM(UPD_CNT), '99,999,999'))  || '건, 연식 미지정 차랑 : ' ||
				NVL(( SELECT AGGR_CONCAT(QLTY_VEHL_CD || '-' || MDL_MDY_CD, ', ') FROM TB_PROD_MST_NOAPIM_INFO WHERE FRAM_DTM > TO_DATE(TO_CHAR(SYSDATE-1, 'YYYYMMDD'))	OR (MDFY_DTM > TO_DATE(TO_CHAR(SYSDATE, 'YYYYMMDD')) AND FRAM_DTM < TO_DATE(TO_CHAR(SYSDATE, 'YYYYMMDD')))), '없음') AS TRX_CNT FROM (
				SELECT COUNT(*) INS_CNT, 0 UPD_CNT FROM TB_PROD_MST_NOAPIM_INFO	WHERE FRAM_DTM > TO_DATE(TO_CHAR(SYSDATE, 'YYYYMMDD'))	UNION ALL	
				SELECT 0 INS_CNT, COUNT(*) UPD_CNT FROM TB_PROD_MST_NOAPIM_INFO	WHERE MDFY_DTM > TO_DATE(TO_CHAR(SYSDATE, 'YYYYMMDD')) AND FRAM_DTM < TO_DATE(TO_CHAR(SYSDATE, 'YYYYMMDD')))
			UNION ALL			 
			SELECT '처리결과상세-09' ID, 'TB_PROD_MST_INFO - 추가:' || TRIM(TO_CHAR(SUM(INS_CNT), '99,999,999')) || '건,  변경:' ||TRIM(TO_CHAR(SUM(UPD_CNT), '99,999,999'))  || '건' TRX_CNT FROM (
				SELECT COUNT(*) INS_CNT, 0 UPD_CNT FROM TB_PROD_MST_INFO	WHERE FRAM_DTM > TO_DATE(TO_CHAR(SYSDATE, 'YYYYMMDD'))	UNION ALL	
				SELECT 0 INS_CNT, COUNT(*) UPD_CNT FROM TB_PROD_MST_INFO	WHERE MDFY_DTM > TO_DATE(TO_CHAR(SYSDATE, 'YYYYMMDD')) AND FRAM_DTM < TO_DATE(TO_CHAR(SYSDATE, 'YYYYMMDD')))
			UNION ALL
			SELECT '처리결과상세-10' ID, 'TB_PROD_MST_PROG_INFO - 추가:' || TRIM(TO_CHAR(SUM(INS_CNT), '99,999,999')) || '건,  변경:' ||TRIM(TO_CHAR(SUM(UPD_CNT), '99,999,999'))  || '건' TRX_CNT FROM (
				SELECT COUNT(*) INS_CNT, 0 UPD_CNT FROM TB_PROD_MST_PROG_INFO	WHERE FRAM_DTM > TO_DATE(TO_CHAR(SYSDATE, 'YYYYMMDD'))	UNION ALL	
				SELECT 0 INS_CNT, COUNT(*) UPD_CNT FROM TB_PROD_MST_PROG_INFO	WHERE MDFY_DTM > TO_DATE(TO_CHAR(SYSDATE, 'YYYYMMDD')) AND FRAM_DTM < TO_DATE(TO_CHAR(SYSDATE, 'YYYYMMDD')))
			UNION ALL
			SELECT '처리결과상세-11' ID, 'TB_PROD_MST_SUM_INFO - 추가:' || TRIM(TO_CHAR(SUM(INS_CNT), '99,999,999')) || '건,  변경:' ||TRIM(TO_CHAR(SUM(UPD_CNT), '99,999,999'))  || '건' TRX_CNT FROM (
				SELECT COUNT(*) INS_CNT, 0 UPD_CNT FROM TB_PROD_MST_SUM_INFO	WHERE FRAM_DTM > TO_DATE(TO_CHAR(SYSDATE, 'YYYYMMDD'))	UNION ALL	
				SELECT 0 INS_CNT, COUNT(*) UPD_CNT FROM TB_PROD_MST_SUM_INFO	WHERE MDFY_DTM > TO_DATE(TO_CHAR(SYSDATE, 'YYYYMMDD')) AND FRAM_DTM < TO_DATE(TO_CHAR(SYSDATE, 'YYYYMMDD')))
			UNION ALL
			SELECT '처리결과상세-12' ID, 'TB_PROD_MST_TRWI_INFO - 추가:' || TRIM(TO_CHAR(SUM(INS_CNT), '99,999,999')) || '건,  변경:' ||TRIM(TO_CHAR(SUM(UPD_CNT), '99,999,999'))  || '건' TRX_CNT FROM (
				SELECT COUNT(*) INS_CNT, 0 UPD_CNT FROM TB_PROD_MST_TRWI_INFO	WHERE FRAM_DTM > TO_DATE(TO_CHAR(SYSDATE, 'YYYYMMDD'))	UNION ALL	
				SELECT 0 INS_CNT, COUNT(*) UPD_CNT FROM TB_PROD_MST_TRWI_INFO	WHERE MDFY_DTM > TO_DATE(TO_CHAR(SYSDATE, 'YYYYMMDD')) AND FRAM_DTM < TO_DATE(TO_CHAR(SYSDATE, 'YYYYMMDD')))
			UNION ALL
			SELECT '처리결과상세-13' ID, 'TB_PROD_ODR_INFO - 추가:' || TRIM(TO_CHAR(SUM(INS_CNT), '99,999,999')) || '건,  변경:' ||TRIM(TO_CHAR(SUM(UPD_CNT), '99,999,999'))  || '건' TRX_CNT FROM (
				SELECT COUNT(*) INS_CNT, 0 UPD_CNT FROM TB_PROD_ODR_INFO	WHERE FRAM_DTM > TO_DATE(TO_CHAR(SYSDATE, 'YYYYMMDD'))	UNION ALL	
				SELECT 0 INS_CNT, COUNT(*) UPD_CNT FROM TB_PROD_ODR_INFO	WHERE MDFY_DTM > TO_DATE(TO_CHAR(SYSDATE, 'YYYYMMDD')) AND FRAM_DTM < TO_DATE(TO_CHAR(SYSDATE, 'YYYYMMDD')))
			UNION ALL
			SELECT '처리결과상세-14' ID, 'TB_PDI_IV_INFO - 추가:' || TRIM(TO_CHAR(SUM(INS_CNT), '99,999,999')) || '건,  변경:' ||TRIM(TO_CHAR(SUM(UPD_CNT), '99,999,999'))  || '건' TRX_CNT FROM (
				SELECT COUNT(*) INS_CNT, 0 UPD_CNT FROM TB_PDI_IV_INFO	WHERE FRAM_DTM > TO_DATE(TO_CHAR(SYSDATE, 'YYYYMMDD'))	UNION ALL	
				SELECT 0 INS_CNT, COUNT(*) UPD_CNT FROM TB_PDI_IV_INFO	WHERE MDFY_DTM > TO_DATE(TO_CHAR(SYSDATE, 'YYYYMMDD')) AND FRAM_DTM < TO_DATE(TO_CHAR(SYSDATE, 'YYYYMMDD')))
			UNION ALL
			SELECT '처리결과상세-15' ID, 'TB_SEWHA_IV_INFO - 추가:' || TRIM(TO_CHAR(SUM(INS_CNT), '99,999,999')) || '건,  변경:' ||TRIM(TO_CHAR(SUM(UPD_CNT), '99,999,999'))  || '건' TRX_CNT FROM (
				SELECT COUNT(*) INS_CNT, 0 UPD_CNT FROM TB_SEWHA_IV_INFO	WHERE FRAM_DTM > TO_DATE(TO_CHAR(SYSDATE, 'YYYYMMDD'))	UNION ALL	
				SELECT 0 INS_CNT, COUNT(*) UPD_CNT FROM TB_SEWHA_IV_INFO	WHERE MDFY_DTM > TO_DATE(TO_CHAR(SYSDATE, 'YYYYMMDD')) AND FRAM_DTM < TO_DATE(TO_CHAR(SYSDATE, 'YYYYMMDD')))				
			);
		COMMIT;
		
		EXCEPTION
		WHEN OTHERS THEN
		ROLLBACK;

	END WRITE_BATCH_LOG_DTL;
/**********************************************************/


/**********************************************************/
	PROCEDURE PROD_MST_INTERFACE_HMC2(P_CURR_YMD VARCHAR2,
									 P_ET_GUBN_CD VARCHAR2)
	IS
	   	 
		CURR_YMD   VARCHAR2(8);
		PREV_YMD   VARCHAR2(8);
		STRT_DATE  DATE;
		V_FROM_YMD VARCHAR2(8);
		V_TO_YMD   VARCHAR2(8);
		V_PRD_STAT VARCHAR2(1);
		V_FNH_STAT VARCHAR2(1);
		 
		V_APL_YMD     VARCHAR2(8); -- 일 2회 전송 구분용
		V_CURR_YMD    VARCHAR2(8);
		V_ET_GUBN_CD  VARCHAR2(2);
		V_CHK_HMC     NUMBER;
		 
	BEGIN
	   		
		--[주의] 이전의 데이터를 배치작업 진행하여야 할 경우에는 CURR_YMD, 기간(DATE_DIFF_CNT) 값을 적절하게 변경하여 준다. 
		CURR_YMD := P_CURR_YMD;
		PREV_YMD := TO_CHAR(TO_DATE(CURR_YMD, 'YYYYMMDD') - DATE_DIFF_CNT, 'YYYYMMDD');

		IF P_ET_GUBN_CD = '01' THEN
			-- 12시 이후 오후에 들어오는 데이터는 적용일자가 오늘
			V_APL_YMD := CURR_YMD;
		ELSE
			-- 오전에 들어오는 데이터는 적용일자가 어제 기준이다.
			V_APL_YMD := TO_CHAR(TO_DATE(CURR_YMD, 'YYYYMMDD') - 1, 'YYYYMMDD');
		END IF;

		V_PRD_STAT := PG_INTERFACE_ERP_ET_INFO.GET_ERP_ET_INFO_EXIST_YN(V_APL_YMD, EXPD_CO_CD_HMC, P_ET_GUBN_CD); 
		
		PG_INTERFACE_APS.WRITE_BATCH_EXE_LOG('생산마스터배치작업_HMC', SYSDATE, 'S', 'PG_INTERFACE_ERP_ET_INFO.GET_ERP_ET_INFO_EXIST_YN : ' || V_PRD_STAT);

		V_FNH_STAT := GET_BTCH_FNH_YN(CURR_YMD, EXPD_CO_CD_HMC, P_ET_GUBN_CD);

		PG_INTERFACE_APS.WRITE_BATCH_EXE_LOG('생산마스터배치작업_HMC', SYSDATE, 'S', 'GET_BTCH_FNH_YN : ' || V_FNH_STAT);

		STRT_DATE := SYSDATE;

		PG_INTERFACE_APS.WRITE_BATCH_LOG('2.1 생산마스터배치작업_HMC', STRT_DATE, 'S', 'ERP내역존재:' || V_PRD_STAT || ', 기처리여부:' ||V_FNH_STAT); 


		--현재 ERP 내역이 존재하지 않거나 이미 처리된 경우에는 작업을 진행하지 않는다. 
		IF V_PRD_STAT = 'N' OR V_FNH_STAT = 'Y' THEN

			RETURN;
				 
		END IF;

		--2012.12.27. ERP 데이터 만을 이용하여 재고 보정하도록 로직 변경 
		--ALC_MST_INTERFACE_BY_TIME(EXPD_CO_CD_HMC); -- ALC 데이터 가져옴(6 시~9 시 분, 6 시 이전거는 6 시 DB 스케쥴러-3 일치) 


		SELECT COUNT(*) AS CNT
		  INTO V_CHK_HMC
		  FROM TB_PROD_MST_INFO_ERP_HMC
		 WHERE APL_YMD = V_APL_YMD
		   AND (ET_GUBN_CD IS NULL OR ET_GUBN_CD = P_ET_GUBN_CD)
		;
	--PG_INTERFACE_APS.WRITE_BATCH_EXE_LOG('생산마스터배치작업_HMC', SYSDATE, 'S', 'PROD_MST_INTERFACE_HMC2 > V_CHK_HMC(ERP 데이터 건수) : ' || V_CHK_HMC);
		 
		 STRT_DATE := SYSDATE;
		 
		 LOAD_PROD_MST_INFO(CURR_YMD, EXPD_CO_CD_HMC, P_ET_GUBN_CD ); -- ERP 데이터 가져옴 
		 
		 PG_INTERFACE_APS.WRITE_BATCH_EXE_LOG('생산마스터배치작업_HMC', SYSDATE, 'S', 'LOAD_PROD_MST_INFO');
		 		 		 
		 GET_PROD_MST_SUM2(PREV_YMD, CURR_YMD, V_APL_YMD, EXPD_CO_CD_HMC);  -- 재고보정 함
	
		 PG_INTERFACE_APS.WRITE_BATCH_EXE_LOG('생산마스터배치작업_HMC', SYSDATE, 'S', 'GET_PROD_MST_SUM2');

		 --배치완료 정보 저장 
		 SAVE_PROD_MST_BTCH_FNH_INFO(CURR_YMD, EXPD_CO_CD_HMC, P_ET_GUBN_CD);

		 PG_INTERFACE_APS.WRITE_BATCH_EXE_LOG('생산마스터배치작업_HMC', SYSDATE, 'S', 'SAVE_PROD_MST_BTCH_FNH_INFO');
		 
		 COMMIT;
		 
		 
		 --미지정 국가 항목 메일 전송 
		 PG_INTERFACE_APS.SEND_NOAPIM_NATL_INFO_MAIL(EXPD_CO_CD_HMC, '03', CURR_YMD);
		 
		 PG_INTERFACE_APS.WRITE_BATCH_LOG('2.2 생산마스터배치작업_HMC_' || P_ET_GUBN_CD, STRT_DATE, 'S', '배치처리완료');
		 
		 EXCEPTION
		     WHEN OTHERS THEN
			     ROLLBACK;
				 PG_INTERFACE_APS.WRITE_BATCH_LOG('2.ERR 생산마스터배치작업_HMC', STRT_DATE, 'F', '배치처리실패:[' || SQLERRM || ']');
                 COMMIT;
				 
	   END PROD_MST_INTERFACE_HMC2;
/**********************************************************/	   																									
/**********************************************************/	   
	   --현대 날짜가 변경될 경우 데이터 Summary 작업 수행(외부 호출, 오라클 스케쥴링) 
	   PROCEDURE PROD_MST_INTERFACE_DATE_HMC
	   IS
	   	 		 
	     STRT_DATE  DATE;
		 
		 CURR_YMD   VARCHAR2(8);
		 SRCH_YMD 	VARCHAR2(8);
		 
	   BEGIN

		 STRT_DATE  := SYSDATE;
		 
		 CURR_YMD := TO_CHAR(SYSDATE, 'YYYYMMDD');
		 
		 SELECT MAX(BTCH_FNH_YMD)
		 INTO SRCH_YMD
		 FROM TB_BATCH_FNH_INFO
		 WHERE AFFR_SCN_CD = '03'
		 AND DL_EXPD_CO_CD = EXPD_CO_CD_HMC;
		 
		 IF SRCH_YMD IS NULL THEN
		 	
			SRCH_YMD := CURR_YMD;
			
		 END IF;
		 
		 GET_PROD_MST_SUM_DTL(CURR_YMD, SRCH_YMD, EXPD_CO_CD_HMC);
		 
		 COMMIT;

		 PG_INTERFACE_APS.WRITE_BATCH_LOG('0.4 생산마스터일자변경배치작업_HMC', STRT_DATE, 'S', '배치처리완료');

		 EXCEPTION
		     WHEN OTHERS THEN
			     ROLLBACK;
				 PG_INTERFACE_APS.WRITE_BATCH_LOG('0.ERR 생산마스터일자변경배치작업_HMC', STRT_DATE, 'F', '배치처리실패:[' || SQLERRM || ']');
			
	   END PROD_MST_INTERFACE_DATE_HMC;
/**********************************************************/

/**********************************************************/
	   --용도차가 아닌지의 여부를 확인 
	   FUNCTION CHECK_VALID_DATA(P_PRDN_ORD_NO VARCHAR2,
	                             P_DEST_NAT_CD VARCHAR2)RETURN VARCHAR2
	   IS
	   BEGIN
	   		 
			IF SUBSTR(P_DEST_NAT_CD, -2, 1) = 'X' THEN
			
			   RETURN 'N';
			   
			ELSE
				
			   RETURN 'Y';
			   
			END IF;
			
	   END CHECK_VALID_DATA;
/**********************************************************/
/**********************************************************/	   
	   --생산마스터 모델년식코드 추출 함수
	   --생산마스터의 연식을 오너스매뉴얼 연식으로 변환하는 함수
	   FUNCTION GET_MDY_CD(MDL_MDY_CD IN VARCHAR2) RETURN VARCHAR2
	   IS

		 MDY_CD VARCHAR2(2);

	   BEGIN

	   		IF MDL_MDY_CD = '1' THEN
			   MDY_CD := '01';
			ELSIF MDL_MDY_CD = '2' THEN
			   MDY_CD := '02';
			ELSIF MDL_MDY_CD = '3' THEN
			   MDY_CD := '03';
			ELSIF MDL_MDY_CD = '4' THEN
			   MDY_CD := '04';
			ELSIF MDL_MDY_CD = '5' THEN
			   MDY_CD := '05';
			ELSIF MDL_MDY_CD = '6' THEN
			   MDY_CD := '06';
			ELSIF MDL_MDY_CD = '7' THEN
			   MDY_CD := '07';
			ELSIF MDL_MDY_CD = '8' THEN
			   MDY_CD := '08';
			ELSIF MDL_MDY_CD = '9' THEN
			   MDY_CD := '09';
			ELSIF MDL_MDY_CD = 'A' THEN
			   MDY_CD := '10';
			ELSIF MDL_MDY_CD = 'B' THEN
			   MDY_CD := '11';
			ELSIF MDL_MDY_CD = 'C' THEN
			   MDY_CD := '12';
			ELSIF MDL_MDY_CD = 'D' THEN
			   MDY_CD := '13';
			ELSIF MDL_MDY_CD = 'E' THEN
			   MDY_CD := '14';
			ELSIF MDL_MDY_CD = 'F' THEN
			   MDY_CD := '15';
			ELSIF MDL_MDY_CD = 'G' THEN
			   MDY_CD := '16';
			ELSIF MDL_MDY_CD = 'H' THEN
			   MDY_CD := '17';
			ELSIF MDL_MDY_CD = 'J' THEN
			   MDY_CD := '18';
			ELSIF MDL_MDY_CD = 'K' THEN
			   MDY_CD := '19';
			ELSIF MDL_MDY_CD = 'M' THEN
			   MDY_CD := '20';
			ELSIF MDL_MDY_CD = 'N' THEN
			   MDY_CD := '21';
			ELSIF MDL_MDY_CD = 'O' THEN 
			   MDY_CD := '22';
			ELSIF MDL_MDY_CD = 'P' THEN
			   MDY_CD := '23';
			ELSIF MDL_MDY_CD = 'Q' THEN
			   MDY_CD := '24';
			ELSIF MDL_MDY_CD = 'R' THEN
			   MDY_CD := '25';
			ELSIF MDL_MDY_CD = 'S' THEN
			   MDY_CD := '26';
			ELSIF MDL_MDY_CD = 'T' THEN
			   MDY_CD := '27';
			ELSIF MDL_MDY_CD = 'U' THEN
			   MDY_CD := '28';
			ELSIF MDL_MDY_CD = 'V' THEN
			   MDY_CD := '29';
			ELSIF MDL_MDY_CD = 'W' THEN
			   MDY_CD := '30';
			ELSIF MDL_MDY_CD = 'X' THEN
			   MDY_CD := '31';
			ELSIF MDL_MDY_CD = 'Y' THEN
			   MDY_CD := '32';
			ELSIF MDL_MDY_CD = 'Z' THEN
			   MDY_CD := '33';
			END IF; -- 영문자 I, L은 숫자 1과 혼동 될 수 있으므로 제외함

			RETURN MDY_CD;

	   END GET_MDY_CD;
/**********************************************************/
/**********************************************************/
	   -- 국가마스터에서 5자리 OR 3자리 국가코드 반환하는 함수
	   FUNCTION GET_NAT_CD(P_DL_EXPD_NAT_CD IN VARCHAR2) RETURN VARCHAR2
	   IS
	   	NAT_CD VARCHAR2(5);
	   BEGIN
	   
	   	NAT_CD := NULL;
	   
	   	SELECT MAX(DL_EXPD_NAT_CD)
	   	INTO NAT_CD
	   	FROM TB_NATL_MGMT
	   	WHERE DL_EXPD_CO_CD = EXPD_CO_CD_HMC
	   	AND (DL_EXPD_NAT_CD = P_DL_EXPD_NAT_CD OR DL_EXPD_NAT_CD = SUBSTR(P_DL_EXPD_NAT_CD, 1, 3))
	   	;
	   	
	   	RETURN NAT_CD;

		 EXCEPTION
		     WHEN OTHERS THEN
			 PG_INTERFACE_APS.WRITE_BATCH_EXE_LOG('PG_INTERFACE_PROD_MST.GET_NAT_CD', SYSDATE, 'F', 'P_DL_EXPD_NAT_CD : ' || P_DL_EXPD_NAT_CD);
			 RETURN NAT_CD;
	   END GET_NAT_CD;
/**********************************************************/
/**********************************************************/       
	   --[변경] 2011-08-05.김동근 HMC ERP 적용으로 프로그램 수정
	   --[추가] 2010-08-11.김동근 ERP 공정위치 코드를 01 ~ 16 사이의 공정위치 코드로 변환하는 함수 
	   FUNCTION GET_POW_LOC_CD_ERP(P_POW_LOC_CD IN CHAR,
                                   P_EXPD_CO_CD IN VARCHAR2) RETURN VARCHAR2
	   IS
	   	 V_POW_LOC_CD VARCHAR(2);
		 
	   BEGIN
	     
         IF P_EXPD_CO_CD = EXPD_CO_CD_HMC THEN
             
             --현재의 공정 위치 코드(P_POW_LOC_CD)는 현재 공정이 진행중인 것을 의미한다.
             --그래서 현재 공정의 바로 이전 공정 위치에 있는 것으로 변경처리 하여 준다.
             
             -- 차체IN, 차체OUT
             IF P_POW_LOC_CD IN ('B010', 'B020') THEN
        		 	
                V_POW_LOC_CD := '01';
        		 
             -- 도장IN, UBS, 중도IN, 상도IN
             ELSIF P_POW_LOC_CD IN ('P010', 'P020', 'P030') THEN
        		    
                V_POW_LOC_CD := '02';
             
             ELSIF P_POW_LOC_CD IN ('P040') THEN
             	
             	V_POW_LOC_CD := '03';
                
             -- 도장OUT, PBS
             ELSIF P_POW_LOC_CD IN ('P050', 'P060') THEN
        		    
                V_POW_LOC_CD := '04';
        		 
             -- PBS
             ELSIF P_POW_LOC_CD = 'T000' THEN
        		    
                V_POW_LOC_CD := '05';
        		 
             -- 트림1, 트림2, 트림3, 샤시1, 샤시2, 화이날1, 화이날2, 화이날3, 화이날4 
             ELSIF P_POW_LOC_CD IN ('T010', 'T020', 'T030', 'T040', 'T050', 'T060', 'T070', 'T080', 'T090') THEN
        		    
                V_POW_LOC_CD := '06';
        		 
             -- C/F(OK)
             ELSIF P_POW_LOC_CD = 'T100' THEN
        		    
                V_POW_LOC_CD := '07';
        		 
             -- S/OFF
             ELSIF P_POW_LOC_CD = 'T110' THEN
        		    
                V_POW_LOC_CD := '08';
        		 
             -- 통제소
             ELSIF P_POW_LOC_CD = 'T120' THEN
        		    
                V_POW_LOC_CD := '09';
        		 
             ELSIF P_POW_LOC_CD IN ('V010') THEN
        		    
                V_POW_LOC_CD := '10';
                
             ELSIF P_POW_LOC_CD IN ('V020') THEN
        		    
                V_POW_LOC_CD := '10';
        		 
             ELSIF P_POW_LOC_CD IN ('V030', 'V040', 'V050', 'V060') THEN
        		    
                V_POW_LOC_CD := '10';
        		 
             -- 선적,출문
             ELSIF P_POW_LOC_CD = 'V070' THEN
        		    
                V_POW_LOC_CD := '10';
        	 
             ELSE
                
                V_POW_LOC_CD := '00';
                	 
             END IF;
         
         ELSE
             
             -- 차체투입
             IF P_POW_LOC_CD IN ('B010', 'B020') THEN
    		 	
                V_POW_LOC_CD := '01';
    		 
             -- 도장투입
             ELSIF P_POW_LOC_CD IN ('P010', 'P020', 'P030') THEN
    		    
                V_POW_LOC_CD := '02';
    		 
             -- 상도입구
             ELSIF P_POW_LOC_CD IN ('P040') THEN
    		    
                V_POW_LOC_CD := '03';
    		 
             -- 도장완료
             ELSIF P_POW_LOC_CD IN ('P050', 'P060') THEN
    		    
                V_POW_LOC_CD := '04';
    		 
             -- PBS입구
             ELSIF P_POW_LOC_CD IN ('T000') THEN
    		    
                V_POW_LOC_CD := '05';
    		 
             -- PBS OUT
             ELSIF P_POW_LOC_CD IN ('T010', 'T020', 'T030', 'T040', 'T050', 'T060', 'T070', 'T080', 'T090') THEN
    		    
                V_POW_LOC_CD := '06';
    		 
             -- OK LINE(C/FINAL)
             ELSIF P_POW_LOC_CD IN ('T100') THEN
    		    
                V_POW_LOC_CD := '07';
    		 
             -- S/OFF
             ELSIF P_POW_LOC_CD = 'T110' THEN
    		    
                V_POW_LOC_CD := '08';
    		 
             -- 통제소
             ELSIF P_POW_LOC_CD IN ('T120') THEN
    		    
                V_POW_LOC_CD := '09';
    		 
             -- PDI IN 
             ELSIF P_POW_LOC_CD IN ('V010') THEN
    		    
                V_POW_LOC_CD := '10';
             
             -- PDI OUT 
             ELSIF P_POW_LOC_CD IN ('V020') THEN
             
                V_POW_LOC_CD := '11';   
             
             -- MP 입고
             ELSIF P_POW_LOC_CD IN ('V030', 'V040', 'V050', 'V060') THEN
             
                V_POW_LOC_CD := '11';
    		 
             -- 선적
             ELSIF P_POW_LOC_CD IN ('V070', 'V080', 'V090') THEN
    		    
                V_POW_LOC_CD := '11';
    		 
             ELSE
                
                V_POW_LOC_CD := '00';
                
             END IF;
           
         END IF;

		 RETURN V_POW_LOC_CD;
		 
	   END GET_POW_LOC_CD_ERP;
/**********************************************************/

/**********************************************************/       
	   --인터페이스 시에 현재 년월일시분 정보를 기반으로 마감기준일자를 리턴 
	   FUNCTION GET_CLOSING_YMD(CURR_YMDHM   IN VARCHAR2,
	                            P_EXPD_CO_CD IN VARCHAR2) RETURN VARCHAR2
	   IS
	   	 
		 V_CLOSING_YMD CHAR(8);
		 V_CURR_YMD CHAR(8);
		 V_CURR_HM	CHAR(4);
		 V_CURR_YER CHAR(4);
		 V_CURR_MTH CHAR(2);
		 V_CURR_DAY CHAR(2);
		 
	   BEGIN
	   		
			V_CURR_YMD := SUBSTR(CURR_YMDHM, 1, 8);
			V_CURR_HM  := SUBSTR(CURR_YMDHM, 9, 4);
			V_CURR_YER := SUBSTR(V_CURR_YMD, 1, 4);
			V_CURR_MTH := SUBSTR(V_CURR_YMD, 5, 2);
			V_CURR_DAY := SUBSTR(V_CURR_YMD, 7, 2);
			
			--적절한 날짜 데이터가 전달되지 않은 경우를 대비한 조건 검사 부분 
			IF V_CURR_YMD = '00000000' OR 
			   V_CURR_YER = '0000' OR
			   V_CURR_MTH = '00' OR
			   V_CURR_DAY = '00' THEN
			   
			   V_CLOSING_YMD := V_CURR_YMD;
			
			ELSE
				--현대 데이터인 경우 
			    V_CLOSING_YMD := TO_CHAR(TO_DATE(V_CURR_YMD, 'YYYYMMDD') - 1, 'YYYYMMDD');

			END IF;
						   
	   		RETURN V_CLOSING_YMD;
	   
	   END GET_CLOSING_YMD; 
/**********************************************************/

/**********************************************************/
       --APS 차종, 월팩, 목적국 코드에 해당하는 품질차종코드, 연식, 취급설명서 국가코드를 추출 
	   --생산마스터 차종이 일정하지 않으므로(2자리 또는 3자리) 이곳에서 해당 차종코드값을 얻어오는 작업도 병행한다. 
	   PROCEDURE GET_MANUAL_INFO(P_APL_YMD		 IN  VARCHAR2,
	   			 				 P_EXPD_CO_CD    IN  VARCHAR2,
	   			 				 P_PRDN_VEHL_CD  IN  VARCHAR2,
	   			 				 P_MO_PACK_CD    IN  VARCHAR2,
								 P_DEST_NAT_CD   IN  VARCHAR2,
								 P_BASC_MDL_CD   IN  VARCHAR2,
								 P_QLTY_VEHL_CD  OUT VARCHAR2,
								 P_MDL_MDY_CD    OUT VARCHAR2,
								 P_EXPD_NAT_CD   OUT VARCHAR2,
								 P_PRDN2_VEHL_CD OUT VARCHAR2)
	   IS
	   	 
		 V_EXPD_REGN_CD VARCHAR2(4);
		 V_EXPD_WIOUT_NAT_CD VARCHAR2(5);	--제외 대리점 코드 체크
		 
	   BEGIN
	   		
			V_EXPD_WIOUT_NAT_CD := NULL;
			P_QLTY_VEHL_CD  := NULL;
			P_PRDN2_VEHL_CD := NULL;
			
			--품질차종코드 조회(생산차종코드가 3자리 이상으로 되어 있는 경우가 있으므로
			--                  COMMON에 정의되어 있는 함수를 사용하여 조회한다.)
			PG_COMMON.SP_GET_VEHL_CD_BY_PRDN2(P_PRDN_VEHL_CD, 'B', P_QLTY_VEHL_CD, P_PRDN2_VEHL_CD); 

			--취급설명서 국가코드 조회
			-- TB_ALTN_NATL_MGMT 테이블 사용안함으로 제외
			-- TB_ALTN_WIOUT_NATL_MGMT에 포함되는 경우 제외
			SELECT MAX(DL_EXPD_NAT_CD)
			INTO V_EXPD_WIOUT_NAT_CD
			FROM TB_ALTN_WIOUT_NATL_MGMT
			WHERE DL_EXPD_CO_CD = P_EXPD_CO_CD
			AND DYTM_PLN_NAT_CD = P_DEST_NAT_CD
			AND PRVS_SCN_CD = 'A';
			
			P_MDL_MDY_CD := NULL;
			-- 제외 대리점 코드가 아닌 경우 처리
			IF V_EXPD_WIOUT_NAT_CD IS NULL THEN
			
				-- 국가코드 체크
				SELECT MAX(DL_EXPD_NAT_CD)
				INTO P_EXPD_NAT_CD
				FROM TB_NATL_MGMT
				WHERE DL_EXPD_CO_CD = P_EXPD_CO_CD
				AND (DL_EXPD_NAT_CD = P_DEST_NAT_CD OR DL_EXPD_NAT_CD = SUBSTR(P_DEST_NAT_CD, 1, 3))
				;
											
				IF P_QLTY_VEHL_CD IS NOT NULL AND
				   P_EXPD_NAT_CD IS NOT NULL THEN
	
				   --이전 방식 나중에 주석 처리 요망
				   SELECT MAX(B.MDL_MDY_CD)
				   INTO P_MDL_MDY_CD
				   FROM TB_NATL_VEHL_MGMT A,
				        TB_VEHL_MDY_MGMT B
				   WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
				   AND A.DL_EXPD_REGN_CD = B.DL_EXPD_REGN_CD
				   AND A.DL_EXPD_CO_CD = P_EXPD_CO_CD
				   AND A.DL_EXPD_NAT_CD = P_EXPD_NAT_CD
				   AND A.QLTY_VEHL_CD = P_QLTY_VEHL_CD
				   AND P_MO_PACK_CD >= B.DESMP1_CD
	       		   AND P_MO_PACK_CD <= B.DEFMP1_CD;
	
				   /*** 신규 방식 현재는 주석 처리함(국가/언어코드 관리 화면에서 지역이 입력되어 있어야만 사용 가능)  */
	               IF P_MDL_MDY_CD IS NULL THEN
	                   SELECT MAX(DL_EXPD_REGN_CD)
	                   INTO V_EXPD_REGN_CD
	                   FROM TB_NATL_MGMT
	                   WHERE DL_EXPD_CO_CD = P_EXPD_CO_CD
	                   AND DL_EXPD_NAT_CD = P_EXPD_NAT_CD;
	
	                   IF V_EXPD_REGN_CD IS NOT NULL THEN
	
	                      SELECT MAX(MDL_MDY_CD)
	                      INTO P_MDL_MDY_CD
	                      FROM TB_VEHL_MDY_MGMT
	                         WHERE QLTY_VEHL_CD = P_QLTY_VEHL_CD
	                         AND DL_EXPD_REGN_CD = V_EXPD_REGN_CD
							 AND P_MO_PACK_CD >= DESMP1_CD
	                         AND P_MO_PACK_CD <= DEFMP1_CD;
	
	                   END IF;
	               END IF;
				   /***/
	
				   --특수한 경우의 연식변경 작업 수행
				   PG_INTERFACE_APS.GET_MDL_MDY_CD_EXTRA(P_APL_YMD,
				   										 P_EXPD_CO_CD,
				   						                 P_QLTY_VEHL_CD,
										                 P_EXPD_NAT_CD,
										                 P_MO_PACK_CD,
														 '03',
														 P_BASC_MDL_CD,
										                 P_MDL_MDY_CD);
				END IF;
			END IF;

	   END GET_MANUAL_INFO;			
/**********************************************************/

/**********************************************************/

       PROCEDURE LOAD_PROD_MST_INFO(P_CURR_YMD   IN VARCHAR2,
	                                P_EXPD_CO_CD IN VARCHAR2,
	                                P_ET_GUBN_CD VARCHAR2)
	   IS
	     
		 PRAGMA AUTONOMOUS_TRANSACTION;
		 
   		 V_APL_YMD     VARCHAR2(8); -- 일 2회 전송 구분용
		 
		 
       BEGIN
	   	
			IF P_ET_GUBN_CD = '01' THEN
				-- 12시 이후 오후에 들어오는 데이터는 적용일자가 오늘
				V_APL_YMD := P_CURR_YMD;
			ELSE
				-- 오전에 들어오는 데이터는 적용일자가 어제 기준이다.
				V_APL_YMD := TO_CHAR(TO_DATE(P_CURR_YMD, 'YYYYMMDD') - 1, 'YYYYMMDD');
			END IF;
	   	
	   		
		   --작업전 I/F 테이블에서 작업내역 I/F 처리로 표시 
			   UPDATE TB_PROD_MST_INFO_ERP_HMC
			      SET RCPM_TRTM_YN = 'N'
			    WHERE APL_YMD = V_APL_YMD
			    ;
			    
			LOAD_PROD_MST_ERP_HMC(P_CURR_YMD, V_APL_YMD, P_EXPD_CO_CD, P_ET_GUBN_CD); 
			    

			   UPDATE TB_PROD_MST_INFO_ERP_HMC
			      SET RCPM_TRTM_YN = 'Y',
			   	      TRTM_YMD = P_CURR_YMD,
			   	      ET_GUBN_CD = P_ET_GUBN_CD
 			    WHERE APL_YMD = V_APL_YMD
			      AND RCPM_TRTM_YN = 'N'
			   ;


			COMMIT;
			
			EXCEPTION
				WHEN OTHERS THEN
					PG_INTERFACE_APS.WRITE_BATCH_EXE_LOG('생산마스터배치작업_HMC', SYSDATE, 'S', 'LOAD_PROD_MST_INFO 배치처리실패 : [' || SQLERRM || ']');
					RAISE;
						   
	   END LOAD_PROD_MST_INFO;
	   
	   --[추가] 2010-08-11.김동근 현대 ERP로 부터 생산실적 로드 				
	   PROCEDURE LOAD_PROD_MST_ERP_HMC(P_CURR_YMD   IN VARCHAR2,
	   								   P_APL_YMD    IN VARCHAR2,
	                                   P_EXPD_CO_CD IN VARCHAR2,
	                                   P_ET_GUBN_CD IN VARCHAR2
	                                   )
	   IS

		 V_CURR_YMD		VARCHAR2(8); -- 일 2회 전송 구분용

		 LOOP_CNT		NUMBER;

	   	 CURSOR PROD_MST_ERP_LIST IS
                SELECT SUBSTR(PRDN_MST_VEHL_CD, 1, 3) AS PRDN_MST_VEHL_CD,
                       BN_SN,
                       APL_YMD,
                       USF_CD,
                       MO_PACK_CD,
                       PRDN_ORD_NO,
                       PRDN_MST_NAT_CD,
                       BASC_MDL_CD,
                       PRDN_OCN_CD,
                       VER_CD,
                       DEST_NAT_CD,
                       POW_LOC_CD,
                       TRIM(TH1_POW_STRT_YMDHM) AS TH1_POW_STRT_YMDHM,
                       TRIM(TH2_POW_STRT_YMDHM) AS TH2_POW_STRT_YMDHM,
                       TRIM(TH3_POW_STRT_YMDHM) AS TH3_POW_STRT_YMDHM,
                       TRIM(TH4_POW_STRT_YMDHM) AS TH4_POW_STRT_YMDHM,
                       TRIM(TH5_POW_STRT_YMDHM) AS TH5_POW_STRT_YMDHM,
                       TRIM(TH6_POW_STRT_YMDHM) AS TH6_POW_STRT_YMDHM,
                       TRIM(TH7_POW_STRT_YMDHM) AS TH7_POW_STRT_YMDHM,
                       TRIM(TH8_POW_STRT_YMDHM) AS TH8_POW_STRT_YMDHM,
                       TRIM(TH9_POW_STRT_YMDHM) AS TH9_POW_STRT_YMDHM,
                       TRIM(T10PS1_YMDHM) AS T10PS1_YMDHM,
                       TRIM(T11PS1_YMDHM) AS T11PS1_YMDHM,
                       MDL_MDY_CD,
                       VIN,
                       PLNT_CD,
                       TH1_POW_STRT_YMD,
                       TH2_POW_STRT_YMD,
                       TH3_POW_STRT_YMD,
                       TH4_POW_STRT_YMD,
                       TH5_POW_STRT_YMD,
                       TH6_POW_STRT_YMD,
                       TH7_POW_STRT_YMD,
                       TH8_POW_STRT_YMD,
                       TH9_POW_STRT_YMD,
                       T10PS1_YMD,
                       T11PS1_YMD
                  FROM TB_PROD_MST_INFO_ERP_HMC
                 WHERE APL_YMD = P_APL_YMD
                   AND RCPM_TRTM_YN = 'N'                 
                ;

		 SAM_PRDN_MST_VEHL_CD       CHAR(3);
         SAM_BN_SN                  CHAR(6);
         SAM_USF_CD                 CHAR(1);
         SAM_MO_PACK_CD             CHAR(4);
         SAM_PRDN_ORD_NO            CHAR(9);
         SAM_PRDN_MST_NAT_CD        CHAR(5);
         SAM_BASC_MDL_CD            CHAR(12);
         SAM_PRDN_OCN_CD            CHAR(4);
         SAM_VER_CD                 CHAR(3);
         SAM_DEST_NAT_CD            CHAR(5);
         SAM_TH1_POW_STRT_YMDHM     CHAR(12);
         SAM_TH2_POW_STRT_YMDHM     CHAR(12);
         SAM_TH3_POW_STRT_YMDHM     CHAR(12);
         SAM_TH4_POW_STRT_YMDHM     CHAR(12);
         SAM_TH5_POW_STRT_YMDHM     CHAR(12);
         SAM_TH6_POW_STRT_YMDHM     CHAR(12);
         SAM_TH7_POW_STRT_YMDHM     CHAR(12);
         SAM_TH8_POW_STRT_YMDHM     CHAR(12);
         SAM_TH9_POW_STRT_YMDHM     CHAR(12);
         SAM_T10PS1_YMDHM           CHAR(12);
         SAM_T11PS1_YMDHM           CHAR(12);
         SAM_T12PS1_YMDHM           CHAR(12);
         SAM_T13PS1_YMDHM           CHAR(12);
         SAM_T14PS1_YMDHM           CHAR(12);
         SAM_T15PS1_YMDHM           CHAR(12);
         SAM_T16PS1_YMDHM           CHAR(12);
		 SAM_TH1_POW_STRT_YMD       CHAR(8);
         SAM_TH2_POW_STRT_YMD       CHAR(8);
         SAM_TH3_POW_STRT_YMD       CHAR(8);
         SAM_TH4_POW_STRT_YMD       CHAR(8);
         SAM_TH5_POW_STRT_YMD       CHAR(8);
         SAM_TH6_POW_STRT_YMD       CHAR(8);
         SAM_TH7_POW_STRT_YMD       CHAR(8);
         SAM_TH8_POW_STRT_YMD       CHAR(8);
         SAM_TH9_POW_STRT_YMD       CHAR(8);
         SAM_T10PS1_YMD             CHAR(8);
         SAM_T11PS1_YMD             CHAR(8);
         SAM_T12PS1_YMD             CHAR(8);
         SAM_T13PS1_YMD             CHAR(8);
         SAM_T14PS1_YMD             CHAR(8);
         SAM_T15PS1_YMD             CHAR(8);
         SAM_T16PS1_YMD             CHAR(8);
         SAM_VIN                    CHAR(17);

		 SAM_POW_LOC_CD             CHAR(2);     --PPMS 공정위치코드
		 V_FNL_LOC_CD               VARCHAR2(2); --최종 공정위치 코드
		 V_TRWI_LOC_CD              VARCHAR2(2); --승용,상용,내수 구분에 따른 투입 기준 공정 위치 값을 보관하는 변수
		                                         --(10, 11, 16 공정 코드 중 하나임)

		 SAM_MDL_MDY_CD             CHAR(2);     --PPMS 연식코드
		 V_MDL_MDY_CD               VARCHAR2(2); --연식코드

		 SAM_APL_YMD                CHAR(8);     --현재공정위치 일자
		 V_TRWI_YMD                 VARCHAR2(8); --투입일자
		 V_TRWI_USED_YN             CHAR(1);     --이전에 이미 투입되었는지의 여부를 보관하는 변수
		 V_PREV_TRWI_YMD            VARCHAR2(8); --이전에 이미 투입된 경우의 해당 투입일을 보관하는 변수
		 V_PREV_APL_YMD				VARCHAR2(8); --이전에 이미 투입된 경우의 해당 투입처리된 적용일을 보관하는 변수. 추가 : 임용석 - 2016.07.01

		 V_QLTY_VEHL_CD  			VARCHAR2(4); --품질차종코드
		 V_EXPD_NAT_CD   			VARCHAR2(5); --취급설명서국가코드
		 V_PRDN2_VEHL_CD            VARCHAR2(4); --생산차종코드

		 V_PAC_SCN_CD               VARCHAR2(4); --승상구분코드
		 V_PDI_CD		            VARCHAR2(4); --PDI구분코드

		 V_TMP_TRWI_YMDHM           VARCHAR2(12);
		 V_TMP_TRWI_YMD			    VARCHAR2(8);

		 SAM_PLNT_CD				VARCHAR2(3); --[추가]. 2010.04.13.김동근 공장코드 신규 추가
		 V_SALE_YMD					VARCHAR2(8); --[추가] 내수용 판매일자 보관 
		 V_WIOUT_DESNAT             VARCHAR2(1); --[추가]. 2016.06.13.블랙리스트 제외처리 JHKIM

	   BEGIN

	   		LOOP_CNT := 0;
	   		
	   		PG_INTERFACE_APS.WRITE_BATCH_EXE_LOG('생산마스터배치작업_HMC', SYSDATE, 'S', LOOP_CNT || ':LOAD_PROD_MST_ERP_HMC > CURR_YMD:' || P_CURR_YMD || ':APL_YMD:' || P_APL_YMD || ':ET_GUBN_CD:' || P_ET_GUBN_CD || ':');

			FOR PROD_MST_ERP_INFO IN PROD_MST_ERP_LIST LOOP

			   LOOP_CNT := LOOP_CNT + 1;

			  /***************
		       * DATA PARSING *
		       ***************/
			   SAM_PRDN_MST_VEHL_CD   := PROD_MST_ERP_INFO.PRDN_MST_VEHL_CD;
               SAM_BN_SN              := PROD_MST_ERP_INFO.BN_SN;
               SAM_USF_CD             := PROD_MST_ERP_INFO.USF_CD;
               SAM_MO_PACK_CD         := PROD_MST_ERP_INFO.MO_PACK_CD;
               SAM_PRDN_ORD_NO        := PROD_MST_ERP_INFO.PRDN_ORD_NO;
               SAM_PRDN_MST_NAT_CD    := PROD_MST_ERP_INFO.PRDN_MST_NAT_CD;
               SAM_BASC_MDL_CD        := PROD_MST_ERP_INFO.BASC_MDL_CD;
               SAM_PRDN_OCN_CD        := PROD_MST_ERP_INFO.PRDN_OCN_CD;
               SAM_VER_CD             := PROD_MST_ERP_INFO.VER_CD;

			   IF SAM_USF_CD = 'D' THEN
			   	   SAM_DEST_NAT_CD := EXPD_DOM_NAT_CD;  --내수인 경우에는 국가코드를 A99VA로 입력하도록 한다.
			   ELSE
			   	   SAM_DEST_NAT_CD := PROD_MST_ERP_INFO.DEST_NAT_CD;
			   END IF;

               SAM_TH1_POW_STRT_YMDHM := NVL(PROD_MST_ERP_INFO.TH1_POW_STRT_YMDHM, '000000000000');

               IF SAM_TH1_POW_STRT_YMDHM IS NULL OR
                  SAM_TH1_POW_STRT_YMDHM = '000000000000' THEN

					 SAM_TH1_POW_STRT_YMDHM := P_APL_YMD || '0000';

               END IF;

               SAM_TH2_POW_STRT_YMDHM := NVL(PROD_MST_ERP_INFO.TH2_POW_STRT_YMDHM, '000000000000');
               SAM_TH3_POW_STRT_YMDHM := NVL(PROD_MST_ERP_INFO.TH2_POW_STRT_YMDHM, '000000000000');
               SAM_TH4_POW_STRT_YMDHM := NVL(PROD_MST_ERP_INFO.TH3_POW_STRT_YMDHM, '000000000000');
               SAM_TH5_POW_STRT_YMDHM := NVL(PROD_MST_ERP_INFO.TH4_POW_STRT_YMDHM, '000000000000');
               SAM_TH6_POW_STRT_YMDHM := NVL(PROD_MST_ERP_INFO.TH5_POW_STRT_YMDHM, '000000000000');
               SAM_TH7_POW_STRT_YMDHM := NVL(PROD_MST_ERP_INFO.TH6_POW_STRT_YMDHM, '000000000000');
               SAM_TH8_POW_STRT_YMDHM := NVL(PROD_MST_ERP_INFO.TH7_POW_STRT_YMDHM, '000000000000');
               SAM_TH9_POW_STRT_YMDHM := NVL(PROD_MST_ERP_INFO.TH8_POW_STRT_YMDHM, '000000000000');
               SAM_T10PS1_YMDHM       := NVL(PROD_MST_ERP_INFO.TH9_POW_STRT_YMDHM, '000000000000');
               SAM_T11PS1_YMDHM       := NVL(PROD_MST_ERP_INFO.T10PS1_YMDHM,       '000000000000');
               SAM_T12PS1_YMDHM       := NVL(PROD_MST_ERP_INFO.T10PS1_YMDHM,       '000000000000');
               SAM_T13PS1_YMDHM       := NVL(PROD_MST_ERP_INFO.T10PS1_YMDHM,       '000000000000');
               SAM_T14PS1_YMDHM       := NVL(PROD_MST_ERP_INFO.T10PS1_YMDHM,       '000000000000');
               SAM_T15PS1_YMDHM       := NVL(PROD_MST_ERP_INFO.T10PS1_YMDHM,       '000000000000');
               SAM_T16PS1_YMDHM       := NVL(PROD_MST_ERP_INFO.T10PS1_YMDHM,       '000000000000');

			   SAM_TH1_POW_STRT_YMD   := NVL(PROD_MST_ERP_INFO.TH1_POW_STRT_YMD, '00000000');
               SAM_TH2_POW_STRT_YMD   := NVL(PROD_MST_ERP_INFO.TH2_POW_STRT_YMD, '00000000');
               SAM_TH3_POW_STRT_YMD   := NVL(PROD_MST_ERP_INFO.TH2_POW_STRT_YMD, '00000000');
               SAM_TH4_POW_STRT_YMD   := NVL(PROD_MST_ERP_INFO.TH3_POW_STRT_YMD, '00000000');
               SAM_TH5_POW_STRT_YMD   := NVL(PROD_MST_ERP_INFO.TH4_POW_STRT_YMD, '00000000');
               SAM_TH6_POW_STRT_YMD   := NVL(PROD_MST_ERP_INFO.TH5_POW_STRT_YMD, '00000000');
               SAM_TH7_POW_STRT_YMD   := NVL(PROD_MST_ERP_INFO.TH6_POW_STRT_YMD, '00000000');
               SAM_TH8_POW_STRT_YMD   := NVL(PROD_MST_ERP_INFO.TH7_POW_STRT_YMD, '00000000');
               SAM_TH9_POW_STRT_YMD   := NVL(PROD_MST_ERP_INFO.TH8_POW_STRT_YMD, '00000000');
               SAM_T10PS1_YMD         := NVL(PROD_MST_ERP_INFO.TH9_POW_STRT_YMD, '00000000');
               SAM_T11PS1_YMD         := NVL(PROD_MST_ERP_INFO.T10PS1_YMD, '00000000');
               SAM_T12PS1_YMD         := NVL(PROD_MST_ERP_INFO.T10PS1_YMD, '00000000');
               SAM_T13PS1_YMD         := NVL(PROD_MST_ERP_INFO.T10PS1_YMD, '00000000');
               SAM_T14PS1_YMD         := NVL(PROD_MST_ERP_INFO.T10PS1_YMD, '00000000');
               SAM_T15PS1_YMD         := NVL(PROD_MST_ERP_INFO.T10PS1_YMD, '00000000');
               SAM_T16PS1_YMD         := NVL(PROD_MST_ERP_INFO.T10PS1_YMD, '00000000');

			   SAM_MDL_MDY_CD         := GET_MDY_CD(TRIM(PROD_MST_ERP_INFO.MDL_MDY_CD));        --PPMS 연식 코드
               SAM_VIN                := PROD_MST_ERP_INFO.VIN;
			   SAM_PLNT_CD            := ' '; -- GET_PRDN_PLNT_CD_ERP(PROD_MST_ERP_INFO.PLNT_CD, P_EXPD_CO_CD); --[추가]. 2010.04.13.김동근 공장코드 신규 추가

               SAM_POW_LOC_CD         := GET_POW_LOC_CD_ERP(PROD_MST_ERP_INFO.POW_LOC_CD, P_EXPD_CO_CD); --PPMS 공정위치 코드

			   --[추가- 2009-02-09] 00공정 데이터 역시 읽어들이지 않는다.(현재 필요없어짐)
			   --용도차가 아닌 경우에만 작업을 진행한다.
			   IF SAM_POW_LOC_CD <> '00' AND
			      CHECK_VALID_DATA(SAM_PRDN_ORD_NO, SAM_DEST_NAT_CD) = 'Y' THEN

				   IF SAM_POW_LOC_CD = '01' THEN
    			   	  SAM_APL_YMD := SAM_TH1_POW_STRT_YMD;
    			   ELSIF SAM_POW_LOC_CD = '02' THEN
				   	  SAM_APL_YMD := SAM_TH2_POW_STRT_YMD;
    			   ELSIF SAM_POW_LOC_CD = '03' THEN
    			      SAM_APL_YMD := SAM_TH3_POW_STRT_YMD;
    			   ELSIF SAM_POW_LOC_CD = '04' THEN
    			      SAM_APL_YMD := SAM_TH4_POW_STRT_YMD;
    			   ELSIF SAM_POW_LOC_CD = '05' THEN
    			      SAM_APL_YMD := SAM_TH5_POW_STRT_YMD;
    			   ELSIF SAM_POW_LOC_CD = '06' THEN
    			      SAM_APL_YMD := SAM_TH6_POW_STRT_YMD;
    			   ELSIF SAM_POW_LOC_CD = '07' THEN
    			      SAM_APL_YMD := SAM_TH7_POW_STRT_YMD;
    			   ELSIF SAM_POW_LOC_CD = '08' THEN
    			      SAM_APL_YMD := SAM_TH8_POW_STRT_YMD;
    			   ELSIF SAM_POW_LOC_CD = '09' THEN
    			      SAM_APL_YMD := SAM_TH9_POW_STRT_YMD;
    			   ELSIF SAM_POW_LOC_CD = '10' THEN
    			      SAM_APL_YMD := SAM_T10PS1_YMD;
    			   ELSIF SAM_POW_LOC_CD = '11' THEN
    			      SAM_APL_YMD := SAM_T11PS1_YMD;
    			   ELSIF SAM_POW_LOC_CD = '12' THEN
    			      SAM_APL_YMD := SAM_T12PS1_YMD;
    			   ELSIF SAM_POW_LOC_CD = '13' THEN
    			      SAM_APL_YMD := SAM_T13PS1_YMD;
    			   ELSIF SAM_POW_LOC_CD = '14' THEN
    			      SAM_APL_YMD := SAM_T14PS1_YMD;
    			   ELSIF SAM_POW_LOC_CD = '15' THEN
    			      SAM_APL_YMD := SAM_T15PS1_YMD;
    			   ELSIF SAM_POW_LOC_CD = '16' THEN
    			      SAM_APL_YMD := SAM_T16PS1_YMD;
    			   END IF;

				   GET_MANUAL_INFO(SAM_APL_YMD,
				   				   P_EXPD_CO_CD,
	   			 				   SAM_PRDN_MST_VEHL_CD,
	   			 				   SAM_MO_PACK_CD,
								   SAM_DEST_NAT_CD,
								   SAM_BASC_MDL_CD,
								   V_QLTY_VEHL_CD,
								   V_MDL_MDY_CD,
								   V_EXPD_NAT_CD,
								   V_PRDN2_VEHL_CD);

				   IF V_MDL_MDY_CD IS NOT NULL THEN

					   SELECT MAX(DL_EXPD_PAC_SCN_CD),
					          MAX(DL_EXPD_PDI_CD)
				       INTO V_PAC_SCN_CD,
		 				    V_PDI_CD
				       FROM TB_VEHL_MGMT
				       WHERE QLTY_VEHL_CD = V_QLTY_VEHL_CD
				       AND MDL_MDY_CD = V_MDL_MDY_CD;
				   ELSE
					   --연식이 지정되지 않은 경우에는 임시로 PPMS 연식을 이용하여 정보를 조회한다.
				   	   --(상용 차종을 위한 조치사항)
				   	   SELECT MAX(DL_EXPD_PAC_SCN_CD),
					          MAX(DL_EXPD_PDI_CD)
				       INTO V_PAC_SCN_CD,
		 				    V_PDI_CD
				       FROM TB_VEHL_MGMT
				       WHERE QLTY_VEHL_CD = V_QLTY_VEHL_CD
				       AND MDL_MDY_CD = SAM_MDL_MDY_CD;
				   END IF;
				       
					-- DEBUG용
					IF ( V_PAC_SCN_CD IS NULL  OR V_PDI_CD IS NULL ) THEN -- AND SAM_DEST_NAT_CD <> 'A99VA' 
								PG_INTERFACE_APS.WRITE_BATCH_EXE_LOG('생산마스터배치작업_HMC', SYSDATE, 'F', 'TB_VEHL_MGMT에 해당 차종,연식 없음!!!   PRDN_MST_VEHL_CD : ' || SAM_PRDN_MST_VEHL_CD || 
								', MO_PACK_CD : ' || SAM_MO_PACK_CD || ', DEST_NAT_CD : ' || SAM_DEST_NAT_CD || ', BASC_MDL_CD : ' || SAM_BASC_MDL_CD || ', QLTY_VEHL_CD : ' || V_QLTY_VEHL_CD || 
								', MDL_MDY_CD : ' || SAM_MDL_MDY_CD || ', PAC_SCN_CD : '   || V_PAC_SCN_CD    || ', PDI_CD : '        || V_PDI_CD );
					END IF;

				   --[중요] 투입일자를 현재공정위치일자와 동일하게 처리해 준다.
				   V_TRWI_YMD    := SAM_APL_YMD;

				   V_FNL_LOC_CD  := SAM_POW_LOC_CD;
				   V_TRWI_LOC_CD := NULL;
				   V_TMP_TRWI_YMD := NULL;	-- 추가. 임용석 2016.07.01


					  --승용차종의 경우
					  IF V_PAC_SCN_CD = '01' THEN

						 --광주공장의 경우에는 PDI OUT 공정에서 취급설명서를 투입한다. (기아 ERP 적용을 고려하여 소스 삭제하지 않고 그대로 둠)
						 IF V_PDI_CD = '04' THEN

							IF SAM_POW_LOC_CD >= '11' THEN

			  				    V_TRWI_LOC_CD  := '11';
							    V_TMP_TRWI_YMD := SAM_T11PS1_YMD;

							END IF;

						 ELSE

							--그외 PDI 승용의 경우에는 10공정 부터 투입된 것으로 본다.
						    IF SAM_POW_LOC_CD >= '10' THEN

                                V_TRWI_LOC_CD := '10';
								V_TMP_TRWI_YMD := SAM_T10PS1_YMD;

							END IF; --[END IF] 현재공정코드 10공정 이상 여부

						 END IF; --[END IF] PDI 구분

					  --상용차종의 경우
					  ELSIF V_PAC_SCN_CD = '02' THEN

						 --상용의 경우 11공정 부터 투입된 것으로 본다.
						 IF SAM_POW_LOC_CD >= '11' THEN

							V_TRWI_LOC_CD  := '11';
							V_TMP_TRWI_YMD := SAM_T11PS1_YMD;

						 END IF;

					  END IF; --[END IF] 승상 구분 여부

				   --[점검]
				   --라인백, 이미 투입된 공정에 대하여 선적등의 값 변경하여 인터페이스에 포함되어 들어온 경우를
				   --대비한 설정(이미 투입이 된 경우에 해당 적용일과 투입일을 얻어온다.)
				   SELECT MAX(APL_YMD), MAX(TRWI_YMD)
				   INTO V_PREV_APL_YMD, V_PREV_TRWI_YMD
				   FROM TB_PROD_MST_TRWI_INFO
				   WHERE PRDN_MST_VEHL_CD = V_PRDN2_VEHL_CD
				   AND BN_SN              = SAM_BN_SN
				   AND DL_EXPD_CO_CD      = P_EXPD_CO_CD
                   AND VIN                = SAM_VIN
				   ;

-- =======================================================================
-- 블랙 리스트 관련 조회 후 처리

				SELECT DECODE(COUNT(*),0,'Y','N')
				  INTO V_WIOUT_DESNAT
				  FROM TB_ALTN_WIOUT_NATL_MGMT
				 WHERE DL_EXPD_CO_CD = P_EXPD_CO_CD
				   AND DL_EXPD_NAT_CD = SUBSTR(SAM_PRDN_MST_NAT_CD,1,3)
				   AND DYTM_PLN_NAT_CD = SAM_DEST_NAT_CD
				   AND PRVS_SCN_CD = 'A';
				
               IF V_WIOUT_DESNAT = 'Y' THEN   -- 제외 대리점 코드가 아니면 실행
-- =======================================================================

				   --현재 공정이 투입공정 이전의 공정이라면 아래의 작업을 수행한다.
				   IF V_TRWI_LOC_CD IS NULL THEN
								
					  --특수한 경우의 연식변경 작업 다시 한번 수행
					  --(APL_YMD가 바뀔 경우 연식이 달라질 수 있음)
			   		  PG_INTERFACE_APS.GET_MDL_MDY_CD_EXTRA(SAM_APL_YMD,
			   										        P_EXPD_CO_CD,
			   						                        V_QLTY_VEHL_CD,
									                 		V_EXPD_NAT_CD,
									                 		SAM_MO_PACK_CD,
													 		'03',
															SAM_BASC_MDL_CD,
									                 		V_MDL_MDY_CD);
                      --[점검]
					  UPDATE TB_PROD_MST_INFO
	    			  SET USF_CD = SAM_USF_CD,
	                      MO_PACK_CD = SAM_MO_PACK_CD,
	                      PRDN_ORD_NO = SAM_PRDN_ORD_NO,
	                      PRDN_MST_NAT_CD = SAM_PRDN_MST_NAT_CD,
	                      BASC_MDL_CD = SAM_BASC_MDL_CD,
	                      PRDN_OCN_CD = SAM_PRDN_OCN_CD,
	                      VER_CD = SAM_VER_CD,
	                      DEST_NAT_CD = SAM_DEST_NAT_CD,
						  POW_LOC_CD = V_FNL_LOC_CD,       --현재 실제의 공정위치코드
	                      TH1_POW_STRT_YMDHM = SAM_TH1_POW_STRT_YMDHM,
	                      TH2_POW_STRT_YMDHM = SAM_TH2_POW_STRT_YMDHM,
	                      TH3_POW_STRT_YMDHM = SAM_TH3_POW_STRT_YMDHM,
	                      TH4_POW_STRT_YMDHM = SAM_TH4_POW_STRT_YMDHM,
	                      TH5_POW_STRT_YMDHM = SAM_TH5_POW_STRT_YMDHM,
	                      TH6_POW_STRT_YMDHM = SAM_TH6_POW_STRT_YMDHM,
	                      TH7_POW_STRT_YMDHM = SAM_TH7_POW_STRT_YMDHM,
	                      TH8_POW_STRT_YMDHM = SAM_TH8_POW_STRT_YMDHM,
	                      TH9_POW_STRT_YMDHM = SAM_TH9_POW_STRT_YMDHM,
	                      T10PS1_YMDHM = SAM_T10PS1_YMDHM,
	                      T11PS1_YMDHM = SAM_T11PS1_YMDHM,
	                      T12PS1_YMDHM = SAM_T12PS1_YMDHM,
	                      T13PS1_YMDHM = SAM_T13PS1_YMDHM,
	                      T14PS1_YMDHM = SAM_T14PS1_YMDHM,
	                      T15PS1_YMDHM = SAM_T15PS1_YMDHM,
	                      T16PS1_YMDHM = SAM_T16PS1_YMDHM,
						  MDL_MDY_CD = V_MDL_MDY_CD,        --현재 실제의 연식코드
	    				  MDFY_DTM = SYSDATE,
						  TRWI_YMD = V_TRWI_YMD,
						  --이미 투입된 물량의 라인백인지의 여부를 확인해 준다.
						  TRWI_USED_YN = (CASE WHEN V_PREV_TRWI_YMD IS NOT NULL AND V_PREV_TRWI_YMD <= V_TRWI_YMD THEN 'Y' ELSE NULL END),
						  PRDN_POW_LOC_CD = SAM_POW_LOC_CD,--PPMS 공정위치코드
						  PRDN_MDL_MDY_CD = SAM_MDL_MDY_CD,--PPMS 연식코드
						  QLTY_VEHL_CD = V_QLTY_VEHL_CD,
						  DL_EXPD_NAT_CD = V_EXPD_NAT_CD,
						  TH1_POW_STRT_YMD = SAM_TH1_POW_STRT_YMD,
	                      TH2_POW_STRT_YMD = SAM_TH2_POW_STRT_YMD,
	                      TH3_POW_STRT_YMD = SAM_TH3_POW_STRT_YMD,
	                      TH4_POW_STRT_YMD = SAM_TH4_POW_STRT_YMD,
	                      TH5_POW_STRT_YMD = SAM_TH5_POW_STRT_YMD,
	                      TH6_POW_STRT_YMD = SAM_TH6_POW_STRT_YMD,
	                      TH7_POW_STRT_YMD = SAM_TH7_POW_STRT_YMD,
	                      TH8_POW_STRT_YMD = SAM_TH8_POW_STRT_YMD,
	                      TH9_POW_STRT_YMD = SAM_TH9_POW_STRT_YMD,
	                      T10PS1_YMD = SAM_T10PS1_YMD,
	                      T11PS1_YMD = SAM_T11PS1_YMD,
	                      T12PS1_YMD = SAM_T12PS1_YMD,
	                      T13PS1_YMD = SAM_T13PS1_YMD,
	                      T14PS1_YMD = SAM_T14PS1_YMD,
	                      T15PS1_YMD = SAM_T15PS1_YMD,
	                      T16PS1_YMD = SAM_T16PS1_YMD,
						  PRDN_PLNT_CD = SAM_PLNT_CD
	    			   WHERE PRDN_MST_VEHL_CD = V_PRDN2_VEHL_CD
	    			   AND BN_SN              = SAM_BN_SN
	    			   AND DL_EXPD_CO_CD      = P_EXPD_CO_CD
	    			   AND APL_YMD            = SAM_APL_YMD
                       AND VIN                = SAM_VIN
                       ;

	    			   IF SQL%NOTFOUND THEN

                          --[점검]
	    				  INSERT INTO TB_PROD_MST_INFO
	    				  (PRDN_MST_VEHL_CD,
	    				   BN_SN,
	    				   DL_EXPD_CO_CD,
	    				   APL_YMD,
	    				   USF_CD,
	    				   MO_PACK_CD,
	    				   PRDN_ORD_NO,
	    				   PRDN_MST_NAT_CD,
	    				   BASC_MDL_CD,
	    				   PRDN_OCN_CD,
	    				   VER_CD,
	    				   DEST_NAT_CD,
	    				   POW_LOC_CD,
	    				   TH1_POW_STRT_YMDHM,
	    				   TH2_POW_STRT_YMDHM,
	    				   TH3_POW_STRT_YMDHM,
	    				   TH4_POW_STRT_YMDHM,
	    				   TH5_POW_STRT_YMDHM,
	    				   TH6_POW_STRT_YMDHM,
	    				   TH7_POW_STRT_YMDHM,
	    				   TH8_POW_STRT_YMDHM,
	    				   TH9_POW_STRT_YMDHM,
	    				   T10PS1_YMDHM,
	    				   T11PS1_YMDHM,
	    				   T12PS1_YMDHM,
	    				   T13PS1_YMDHM,
	    				   T14PS1_YMDHM,
	    				   T15PS1_YMDHM,
	    				   T16PS1_YMDHM,
	    				   MDL_MDY_CD,
	    				   VIN,
	    				   FRAM_DTM,
	    				   MDFY_DTM,
--						   TH0_POW_STRT_YMD,
						   TRWI_YMD,
						   TRWI_USED_YN,
						   PRDN_POW_LOC_CD,
						   PRDN_MDL_MDY_CD,
						   QLTY_VEHL_CD,
						   DL_EXPD_NAT_CD,
						   TH1_POW_STRT_YMD,
	    				   TH2_POW_STRT_YMD,
	    				   TH3_POW_STRT_YMD,
	    				   TH4_POW_STRT_YMD,
	    				   TH5_POW_STRT_YMD,
	    				   TH6_POW_STRT_YMD,
	    				   TH7_POW_STRT_YMD,
	    				   TH8_POW_STRT_YMD,
	    				   TH9_POW_STRT_YMD,
	    				   T10PS1_YMD,
	    				   T11PS1_YMD,
	    				   T12PS1_YMD,
	    				   T13PS1_YMD,
	    				   T14PS1_YMD,
	    				   T15PS1_YMD,
	    				   T16PS1_YMD,
						   PRDN_PLNT_CD
	    				  )
	    				  VALUES
	    				  (V_PRDN2_VEHL_CD,
	    				   SAM_BN_SN,
	    				   P_EXPD_CO_CD,
	    				   SAM_APL_YMD,
	    				   SAM_USF_CD,
	    				   SAM_MO_PACK_CD,
	    				   SAM_PRDN_ORD_NO,
	    				   SAM_PRDN_MST_NAT_CD,
	    				   SAM_BASC_MDL_CD,
	    				   SAM_PRDN_OCN_CD,
	    				   SAM_VER_CD,
	    				   SAM_DEST_NAT_CD,
	    				   V_FNL_LOC_CD,
	    				   SAM_TH1_POW_STRT_YMDHM,
	    				   SAM_TH2_POW_STRT_YMDHM,
	    				   SAM_TH3_POW_STRT_YMDHM,
	    				   SAM_TH4_POW_STRT_YMDHM,
	    				   SAM_TH5_POW_STRT_YMDHM,
	    				   SAM_TH6_POW_STRT_YMDHM,
	    				   SAM_TH7_POW_STRT_YMDHM,
	    				   SAM_TH8_POW_STRT_YMDHM,
	    				   SAM_TH9_POW_STRT_YMDHM,
	    				   SAM_T10PS1_YMDHM,
	    				   SAM_T11PS1_YMDHM,
	    				   SAM_T12PS1_YMDHM,
	    				   SAM_T13PS1_YMDHM,
	    				   SAM_T14PS1_YMDHM,
	    				   SAM_T15PS1_YMDHM,
	    				   SAM_T16PS1_YMDHM,
	    				   V_MDL_MDY_CD,
	    				   SAM_VIN,
	    				   SYSDATE,
	    				   SYSDATE,
						   V_TRWI_YMD,
						   --이미 투입된 물량의 라인백인지의 여부를 확인해 준다.
						   (CASE WHEN V_PREV_TRWI_YMD IS NOT NULL AND V_PREV_TRWI_YMD <= V_TRWI_YMD THEN 'Y' ELSE NULL END),
						   SAM_POW_LOC_CD,
						   SAM_MDL_MDY_CD,
						   V_QLTY_VEHL_CD,
						   V_EXPD_NAT_CD,
						   SAM_TH1_POW_STRT_YMD,
	                       SAM_TH2_POW_STRT_YMD,
	                       SAM_TH3_POW_STRT_YMD,
	                       SAM_TH4_POW_STRT_YMD,
	                       SAM_TH5_POW_STRT_YMD,
	                       SAM_TH6_POW_STRT_YMD,
	                       SAM_TH7_POW_STRT_YMD,
	                       SAM_TH8_POW_STRT_YMD,
	                       SAM_TH9_POW_STRT_YMD,
	                       SAM_T10PS1_YMD,
	                       SAM_T11PS1_YMD,
	                       SAM_T12PS1_YMD,
	                       SAM_T13PS1_YMD,
	                       SAM_T14PS1_YMD,
	                       SAM_T15PS1_YMD,
	                       SAM_T16PS1_YMD,
						   SAM_PLNT_CD
	    				  );

						END IF;

				   --현재 공정이 투입공정 이후의 공정이라면 아래의 작업을 수행한다.
				   ELSE
				
					   IF V_PREV_TRWI_YMD IS NULL THEN

						 -- V_TMP_TRWI_YMD : PDI-IN OR OUT 공정에 투입된 일자
                         IF V_TMP_TRWI_YMD < TO_CHAR(TO_DATE(P_APL_YMD) - DATE_DIFF_CNT, 'YYYYMMDD')  THEN

						  	--Summary 작업 시작 이전일이 투입일 이라면 투입여부를 이미 투입된 것으로 처리해 준다.
						    --즉 투입 물량에서 빼주지 않게 된다. 그리고 투입 테이블에도 저장하지 않는다.
                            V_TRWI_USED_YN := 'Y';
						
                         ELSE

                            --Summary 작업 시작일 이내이고 아직 한번도 투입되지 않은 경우에는 적용일과 투입일을 모두 실제로 투입된 일자로 변경하여 준다.

                            V_TRWI_USED_YN := 'N';

							V_TRWI_YMD  := V_TMP_TRWI_YMD;
							SAM_APL_YMD := V_TMP_TRWI_YMD;
							
                         END IF;

					   ELSE

						  --당일 투입처리된 항목이 있다면 그것을 덮어 쓰게 되므로 아래와 같이 V_TRWI_USED_YN 값을 'N' 으로 해 주어야 한다.
						  IF V_PREV_TRWI_YMD = V_TRWI_YMD THEN

							 V_TRWI_USED_YN := 'N';

						  ELSIF V_TRWI_YMD < V_PREV_TRWI_YMD THEN

                               --[점검]
							   UPDATE TB_PROD_MST_INFO
						 	   SET TRWI_USED_YN = 'Y',
						     	   MDFY_DTM = SYSDATE,
						     	   PRDN_PLNT_CD = SAM_PLNT_CD
						       WHERE PRDN_MST_VEHL_CD = V_PRDN2_VEHL_CD
						 	   AND BN_SN              = SAM_BN_SN
						 	   AND DL_EXPD_CO_CD      = P_EXPD_CO_CD
						 	   AND APL_YMD            = V_PREV_TRWI_YMD
                               AND VIN                = SAM_VIN
                               ;

							   V_TRWI_USED_YN := 'N';

						  ELSE

							 V_TRWI_USED_YN := 'Y';

						  END IF;

					   END IF;

					   --특수한 경우의 연식변경 작업 다시 한번 수행
					   --(APL_YMD가 바뀔 경우 연식이 달라질 수 있음)
			   		   PG_INTERFACE_APS.GET_MDL_MDY_CD_EXTRA(SAM_APL_YMD,
			   										         P_EXPD_CO_CD,
			   						                         V_QLTY_VEHL_CD,
									                 		 V_EXPD_NAT_CD,
									                 		 SAM_MO_PACK_CD,
													 		 '03',
															 SAM_BASC_MDL_CD,
									                 		 V_MDL_MDY_CD);

					   --아직 한번도 투입되지 않은 공정이라면...
					   --투입정보 테이블에 데이터를 추가해 준다.
					   
					   IF V_TRWI_USED_YN = 'N' THEN

                          --[점검]
						  UPDATE TB_PROD_MST_TRWI_INFO
	    			   	  SET APL_YMD         = SAM_APL_YMD,
						  	  TRWI_YMD        = V_TRWI_YMD,
						      USF_CD          = SAM_USF_CD,
	                          MO_PACK_CD      = SAM_MO_PACK_CD,
	                          DEST_NAT_CD     = SAM_DEST_NAT_CD,
	                          POW_LOC_CD      = V_FNL_LOC_CD,
	                       	  MDL_MDY_CD      = V_MDL_MDY_CD,
	    				      MDFY_DTM        = SYSDATE,
							  PRDN_MDL_MDY_CD = SAM_MDL_MDY_CD,
							  QLTY_VEHL_CD    = V_QLTY_VEHL_CD,
						      DL_EXPD_NAT_CD  = V_EXPD_NAT_CD,
							  PRDN_PLNT_CD    = SAM_PLNT_CD
	    			      WHERE PRDN_MST_VEHL_CD = V_PRDN2_VEHL_CD
	    				  AND BN_SN              = SAM_BN_SN
	    				  AND DL_EXPD_CO_CD      = P_EXPD_CO_CD
                          AND VIN                = SAM_VIN
                          ;

				
						  IF SQL%NOTFOUND THEN
						  						
                              --[점검]
							  INSERT INTO TB_PROD_MST_TRWI_INFO
	    				      (PRDN_MST_VEHL_CD,
	    				       BN_SN,
	    					   DL_EXPD_CO_CD,
	    					   APL_YMD,
	    					   TRWI_YMD,
							   USF_CD,
	    					   MO_PACK_CD,
	    					   DEST_NAT_CD,
	    					   POW_LOC_CD,
	    					   MDL_MDY_CD,
	    					   VIN,
	    					   FRAM_DTM,
	    					   MDFY_DTM,
							   PRDN_MDL_MDY_CD,
							   QLTY_VEHL_CD,
							   DL_EXPD_NAT_CD,
							   PRDN_PLNT_CD
	    				      )
	    				      VALUES
	    				      (V_PRDN2_VEHL_CD,
	    				       SAM_BN_SN,
	    				       P_EXPD_CO_CD,
	    				       SAM_APL_YMD,
							   V_TRWI_YMD,
	    					   SAM_USF_CD,
	    					   SAM_MO_PACK_CD,
	    					   SAM_DEST_NAT_CD,
	    					   V_FNL_LOC_CD,
	    					   V_MDL_MDY_CD,
	    					   SAM_VIN,
	    					   SYSDATE,
	    					   SYSDATE,
							   SAM_MDL_MDY_CD,
							   V_QLTY_VEHL_CD,
							   V_EXPD_NAT_CD,
							   SAM_PLNT_CD
	    				      );

						  END IF;

					   END IF;

					   
                       --[점검]
					   UPDATE TB_PROD_MST_INFO
	    			   SET USF_CD = SAM_USF_CD,
	                      MO_PACK_CD = SAM_MO_PACK_CD,
	                      PRDN_ORD_NO = SAM_PRDN_ORD_NO,
	                      PRDN_MST_NAT_CD = SAM_PRDN_MST_NAT_CD,
	                      BASC_MDL_CD = SAM_BASC_MDL_CD,
	                      PRDN_OCN_CD = SAM_PRDN_OCN_CD,
	                      VER_CD = SAM_VER_CD,
	                      DEST_NAT_CD = SAM_DEST_NAT_CD,
						  POW_LOC_CD = V_FNL_LOC_CD,       --현재 실제의 공정위치코드
	                      TH1_POW_STRT_YMDHM = SAM_TH1_POW_STRT_YMDHM,
	                      TH2_POW_STRT_YMDHM = SAM_TH2_POW_STRT_YMDHM,
	                      TH3_POW_STRT_YMDHM = SAM_TH3_POW_STRT_YMDHM,
	                      TH4_POW_STRT_YMDHM = SAM_TH4_POW_STRT_YMDHM,
	                      TH5_POW_STRT_YMDHM = SAM_TH5_POW_STRT_YMDHM,
	                      TH6_POW_STRT_YMDHM = SAM_TH6_POW_STRT_YMDHM,
	                      TH7_POW_STRT_YMDHM = SAM_TH7_POW_STRT_YMDHM,
	                      TH8_POW_STRT_YMDHM = SAM_TH8_POW_STRT_YMDHM,
	                      TH9_POW_STRT_YMDHM = SAM_TH9_POW_STRT_YMDHM,
	                      T10PS1_YMDHM = SAM_T10PS1_YMDHM,
	                      T11PS1_YMDHM = SAM_T11PS1_YMDHM,
	                      T12PS1_YMDHM = SAM_T12PS1_YMDHM,
	                      T13PS1_YMDHM = SAM_T13PS1_YMDHM,
	                      T14PS1_YMDHM = SAM_T14PS1_YMDHM,
	                      T15PS1_YMDHM = SAM_T15PS1_YMDHM,
	                      T16PS1_YMDHM = SAM_T16PS1_YMDHM,
						  MDL_MDY_CD = V_MDL_MDY_CD,        --현재 실제의 연식코드
	    				  MDFY_DTM = SYSDATE,
						  TRWI_YMD = V_TRWI_YMD,
						  TRWI_USED_YN = V_TRWI_USED_YN,
						  PRDN_POW_LOC_CD = SAM_POW_LOC_CD,--PPMS 공정위치코드
						  PRDN_MDL_MDY_CD = SAM_MDL_MDY_CD,--PPMS 연식코드
						  QLTY_VEHL_CD = V_QLTY_VEHL_CD,
						  DL_EXPD_NAT_CD = V_EXPD_NAT_CD,
						  TH1_POW_STRT_YMD = SAM_TH1_POW_STRT_YMD,
	                      TH2_POW_STRT_YMD = SAM_TH2_POW_STRT_YMD,
	                      TH3_POW_STRT_YMD = SAM_TH3_POW_STRT_YMD,
	                      TH4_POW_STRT_YMD = SAM_TH4_POW_STRT_YMD,
	                      TH5_POW_STRT_YMD = SAM_TH5_POW_STRT_YMD,
	                      TH6_POW_STRT_YMD = SAM_TH6_POW_STRT_YMD,
	                      TH7_POW_STRT_YMD = SAM_TH7_POW_STRT_YMD,
	                      TH8_POW_STRT_YMD = SAM_TH8_POW_STRT_YMD,
	                      TH9_POW_STRT_YMD = SAM_TH9_POW_STRT_YMD,
	                      T10PS1_YMD = SAM_T10PS1_YMD,
	                      T11PS1_YMD = SAM_T11PS1_YMD,
	                      T12PS1_YMD = SAM_T12PS1_YMD,
	                      T13PS1_YMD = SAM_T13PS1_YMD,
	                      T14PS1_YMD = SAM_T14PS1_YMD,
	                      T15PS1_YMD = SAM_T15PS1_YMD,
	                      T16PS1_YMD = SAM_T16PS1_YMD,
	                      PRDN_PLNT_CD = SAM_PLNT_CD
	    			   WHERE PRDN_MST_VEHL_CD = V_PRDN2_VEHL_CD
	    			   AND BN_SN              = SAM_BN_SN
	    			   AND DL_EXPD_CO_CD      = P_EXPD_CO_CD
	    			   AND APL_YMD            = SAM_APL_YMD
                       AND VIN                = SAM_VIN
					   ;

	    			   IF SQL%NOTFOUND THEN

                          --[점검]
	    				  INSERT INTO TB_PROD_MST_INFO
	    				  (PRDN_MST_VEHL_CD,
	    				   BN_SN,
	    				   DL_EXPD_CO_CD,
	    				   APL_YMD,
	    				   USF_CD,
	    				   MO_PACK_CD,
	    				   PRDN_ORD_NO,
	    				   PRDN_MST_NAT_CD,
	    				   BASC_MDL_CD,
	    				   PRDN_OCN_CD,
	    				   VER_CD,
	    				   DEST_NAT_CD,
	    				   POW_LOC_CD,
	    				   TH1_POW_STRT_YMDHM,
	    				   TH2_POW_STRT_YMDHM,
	    				   TH3_POW_STRT_YMDHM,
	    				   TH4_POW_STRT_YMDHM,
	    				   TH5_POW_STRT_YMDHM,
	    				   TH6_POW_STRT_YMDHM,
	    				   TH7_POW_STRT_YMDHM,
	    				   TH8_POW_STRT_YMDHM,
	    				   TH9_POW_STRT_YMDHM,
	    				   T10PS1_YMDHM,
	    				   T11PS1_YMDHM,
	    				   T12PS1_YMDHM,
	    				   T13PS1_YMDHM,
	    				   T14PS1_YMDHM,
	    				   T15PS1_YMDHM,
	    				   T16PS1_YMDHM,
	    				   MDL_MDY_CD,
	    				   VIN,
	    				   FRAM_DTM,
	    				   MDFY_DTM,
						   TRWI_YMD,
						   TRWI_USED_YN,
						   PRDN_POW_LOC_CD,
						   PRDN_MDL_MDY_CD,
						   QLTY_VEHL_CD,
						   DL_EXPD_NAT_CD,
						   TH1_POW_STRT_YMD,
	    				   TH2_POW_STRT_YMD,
	    				   TH3_POW_STRT_YMD,
	    				   TH4_POW_STRT_YMD,
	    				   TH5_POW_STRT_YMD,
	    				   TH6_POW_STRT_YMD,
	    				   TH7_POW_STRT_YMD,
	    				   TH8_POW_STRT_YMD,
	    				   TH9_POW_STRT_YMD,
	    				   T10PS1_YMD,
	    				   T11PS1_YMD,
	    				   T12PS1_YMD,
	    				   T13PS1_YMD,
	    				   T14PS1_YMD,
	    				   T15PS1_YMD,
	    				   T16PS1_YMD,
						   PRDN_PLNT_CD
	    				  )
	    				  VALUES
	    				  (V_PRDN2_VEHL_CD,
	    				   SAM_BN_SN,
	    				   P_EXPD_CO_CD,
	    				   SAM_APL_YMD,
	    				   SAM_USF_CD,
	    				   SAM_MO_PACK_CD,
	    				   SAM_PRDN_ORD_NO,
	    				   SAM_PRDN_MST_NAT_CD,
	    				   SAM_BASC_MDL_CD,
	    				   SAM_PRDN_OCN_CD,
	    				   SAM_VER_CD,
	    				   SAM_DEST_NAT_CD,
	    				   V_FNL_LOC_CD,
	    				   SAM_TH1_POW_STRT_YMDHM,
	    				   SAM_TH2_POW_STRT_YMDHM,
	    				   SAM_TH3_POW_STRT_YMDHM,
	    				   SAM_TH4_POW_STRT_YMDHM,
	    				   SAM_TH5_POW_STRT_YMDHM,
	    				   SAM_TH6_POW_STRT_YMDHM,
	    				   SAM_TH7_POW_STRT_YMDHM,
	    				   SAM_TH8_POW_STRT_YMDHM,
	    				   SAM_TH9_POW_STRT_YMDHM,
	    				   SAM_T10PS1_YMDHM,
	    				   SAM_T11PS1_YMDHM,
	    				   SAM_T12PS1_YMDHM,
	    				   SAM_T13PS1_YMDHM,
	    				   SAM_T14PS1_YMDHM,
	    				   SAM_T15PS1_YMDHM,
	    				   SAM_T16PS1_YMDHM,
	    				   V_MDL_MDY_CD,
	    				   SAM_VIN,
	    				   SYSDATE,
	    				   SYSDATE,
						   V_TRWI_YMD,
						   V_TRWI_USED_YN,
						   SAM_POW_LOC_CD,
						   SAM_MDL_MDY_CD,
						   V_QLTY_VEHL_CD,
						   V_EXPD_NAT_CD,
						   SAM_TH1_POW_STRT_YMD,
	                       SAM_TH2_POW_STRT_YMD,
	                       SAM_TH3_POW_STRT_YMD,
	                       SAM_TH4_POW_STRT_YMD,
	                       SAM_TH5_POW_STRT_YMD,
	                       SAM_TH6_POW_STRT_YMD,
	                       SAM_TH7_POW_STRT_YMD,
	                       SAM_TH8_POW_STRT_YMD,
	                       SAM_TH9_POW_STRT_YMD,
	                       SAM_T10PS1_YMD,
	                       SAM_T11PS1_YMD,
	                       SAM_T12PS1_YMD,
	                       SAM_T13PS1_YMD,
	                       SAM_T14PS1_YMD,
	                       SAM_T15PS1_YMD,
	                       SAM_T16PS1_YMD,
						   SAM_PLNT_CD
	    				  );

						END IF;	-- IF SQL%NOTFOUND THEN

				   END IF;

                   --[점검]
				   --현재 진행중인 물량 정보 업데이트 작업 수행
				   SP_UPDATE_PROD_MST_PROG_INFO(V_PRDN2_VEHL_CD,
	    				   					    SAM_BN_SN,
	    				   						P_EXPD_CO_CD,
	    				   						SAM_APL_YMD,
                                                SAM_VIN
                                                );

			   END IF;
			   
			  END IF;     -- 제외 대리점 코드가 아니면 실행

			END LOOP;

			--PG_INTERFACE_APS.WRITE_BATCH_EXE_LOG('생산마스터배치작업_HMC', SYSDATE, 'S', 'LOAD_PROD_MST_ERP_HMC LOOP COUNT : [' || LOOP_CNT || ']');

			EXCEPTION
				WHEN OTHERS THEN
					--PG_INTERFACE_APS.WRITE_BATCH_EXE_LOG('생산마스터배치작업_HMC', SYSDATE, 'S', 'LOAD_PROD_MST_ERP_HMC 배치처리실패 : [' || SQLERRM || ']');
					RAISE;
						
	   END LOAD_PROD_MST_ERP_HMC;
/****************************************************************************************************************************/

/****************************************************************************************************************************/	   
	   PROCEDURE SP_UPDATE_PROD_MST_PROG_INFO(P_PRDN_MST_VEHL_CD IN VARCHAR2,
	    				   					  P_BN_SN            IN VARCHAR2,
											  P_EXPD_CO_CD       IN VARCHAR2,
	   			 							  P_APL_YMD          IN VARCHAR2,
                                              P_VIN              IN VARCHAR2)
	   IS
	   	 
		 V_PAC_SCN_CD  VARCHAR2(4); --승상구분코드 
		 V_PDI_CD	   VARCHAR2(4); --PDI구분코드 
		 
		 V_POW_LOC_CD  VARCHAR2(2);
		 V_APL_FNH_YMD VARCHAR2(8);
		 
		 V_DTL_SN	   NUMBER;
		 
         --[점검] 	 
		 CURSOR PROD_MST_INFO IS SELECT PRDN_MST_VEHL_CD,
		 					  	 		BN_SN,
										DL_EXPD_CO_CD,
										APL_YMD,
										USF_CD,
										MO_PACK_CD,
										DEST_NAT_CD,
										POW_LOC_CD,
										TH1_POW_STRT_YMDHM,
	    				   				TH2_POW_STRT_YMDHM,
	    				   				TH3_POW_STRT_YMDHM,
	    				   				TH4_POW_STRT_YMDHM,
	    				   				TH5_POW_STRT_YMDHM,
	    				   				TH6_POW_STRT_YMDHM,
	    				   				TH7_POW_STRT_YMDHM,
	    				   				TH8_POW_STRT_YMDHM,
	    				   				TH9_POW_STRT_YMDHM,
	    				   				T10PS1_YMDHM,
	    				   				T11PS1_YMDHM,
	    				   				T12PS1_YMDHM,
	    				   				T13PS1_YMDHM,
	    				   				T14PS1_YMDHM,
	    				   				T15PS1_YMDHM,
	    				   				T16PS1_YMDHM,
										MDL_MDY_CD,
										VIN,
										TH0_POW_STRT_YMD,
										TRWI_YMD,
										TRWI_USED_YN,
										PRDN_MDL_MDY_CD,
										QLTY_VEHL_CD,
										DL_EXPD_NAT_CD,
										PRDN_PLNT_CD
		                         FROM TB_PROD_MST_INFO
								 WHERE PRDN_MST_VEHL_CD = P_PRDN_MST_VEHL_CD
                                 AND BN_SN              = P_BN_SN
								 AND DL_EXPD_CO_CD      = P_EXPD_CO_CD
								 AND APL_YMD            = P_APL_YMD
                                 AND VIN                = P_VIN;
								 
	   BEGIN
	   		
			FOR PROD_LIST IN PROD_MST_INFO LOOP
				
				SELECT MAX(DL_EXPD_PAC_SCN_CD),
				       MAX(DL_EXPD_PDI_CD)
				INTO V_PAC_SCN_CD,
				     V_PDI_CD
				FROM TB_VEHL_MGMT
				WHERE QLTY_VEHL_CD = PROD_LIST.QLTY_VEHL_CD
				AND MDL_MDY_CD     = PROD_LIST.MDL_MDY_CD;
				
				--승용인 경우의 처리 
				--(승용의 경우에는 투입된 이후의 라인모니터링 정보가 필요없으므로 별도로 처리하지 않고,
				-- 현재 진행중인 항목만 추가해 주도록 한다.) 
				IF V_PAC_SCN_CD = '01' THEN
				   
				    --이미 투입된 물량인지의 여부를 체크한다.
					--(투입된 항목 이거나 투입된 물량이 라인백 된 경우는 TRWI_USED_YN값이 NULL이 아니어서 제외된다.)  
					IF PROD_LIST.TRWI_USED_YN IS NOT NULL THEN
				   	   
                       --[점검]
					   V_DTL_SN := GET_PROD_MST_PROG_MAX_DTL_SN(PROD_LIST.PRDN_MST_VEHL_CD,
								 					            PROD_LIST.BN_SN,
							     							    PROD_LIST.DL_EXPD_CO_CD,
							     							    PROD_LIST.TRWI_YMD,
							     							    PROD_LIST.TRWI_YMD,
                                                                PROD_LIST.VIN);
																   
				   	   IF PROD_LIST.TRWI_USED_YN = 'N' THEN
				   	   	  
                          --[점검] 						
						  UPDATE TB_PROD_MST_PROG_INFO
				   	   	  SET 
					       	  APL_FNH_YMD = PROD_LIST.TRWI_YMD,
					   	   	  MDFY_DTM    = SYSDATE,
							  DTL_SN      = V_DTL_SN,
							  PRDN_PLNT_CD = PROD_LIST.PRDN_PLNT_CD
				          WHERE PRDN_MST_VEHL_CD = PROD_LIST.PRDN_MST_VEHL_CD
				   	   	  AND BN_SN              = PROD_LIST.BN_SN
				   	   	  AND DL_EXPD_CO_CD      = PROD_LIST.DL_EXPD_CO_CD
				   	   	  AND APL_STRT_YMD      <= PROD_LIST.TRWI_YMD
				   	   	  AND APL_FNH_YMD        > PROD_LIST.TRWI_YMD
                          AND VIN                = PROD_LIST.VIN;
					   	  
				       ELSE
				   	      
                          --[점검]
					   	  UPDATE TB_PROD_MST_PROG_INFO
				   	   	  SET 
					       	  APL_FNH_YMD = PROD_LIST.TRWI_YMD,
					   	   	  MDFY_DTM    = SYSDATE,
							  DTL_SN      = V_DTL_SN,
							  PRDN_PLNT_CD = PROD_LIST.PRDN_PLNT_CD
				          WHERE PRDN_MST_VEHL_CD = PROD_LIST.PRDN_MST_VEHL_CD
				   	   	  AND BN_SN              = PROD_LIST.BN_SN
				   	   	  AND DL_EXPD_CO_CD      = PROD_LIST.DL_EXPD_CO_CD
				   	   	  AND APL_STRT_YMD      <= PROD_LIST.TRWI_YMD
				   	   	  AND APL_FNH_YMD        = '99991231'
                          AND VIN                = PROD_LIST.VIN;
				   
				       END IF;
				   
				    ELSE
				   	   
                       --[점검]
				   	   SELECT MAX(APL_FNH_YMD)
				   	   INTO V_APL_FNH_YMD
				   	   FROM TB_PROD_MST_PROG_INFO
				   	   WHERE PRDN_MST_VEHL_CD = PROD_LIST.PRDN_MST_VEHL_CD
				   	   AND BN_SN = PROD_LIST.BN_SN
				   	   AND DL_EXPD_CO_CD = PROD_LIST.DL_EXPD_CO_CD
				   	   AND APL_STRT_YMD <= PROD_LIST.TRWI_YMD
				   	   AND APL_FNH_YMD   > PROD_LIST.TRWI_YMD
                       AND VIN           = PROD_LIST.VIN;
				   
				       IF V_APL_FNH_YMD IS NULL THEN
				          
                          --[점검]
					   	  --현재 한번도 저장된 적이 없는 데이터 이면 신규 추가해 준다. 
				   	  	  INSERT INTO TB_PROD_MST_PROG_INFO
					  	  VALUES(PROD_LIST.PRDN_MST_VEHL_CD,
		 					 	 PROD_LIST.BN_SN,
							     PROD_LIST.DL_EXPD_CO_CD,
							     PROD_LIST.TRWI_YMD,
							     '99991231',
							     PROD_LIST.USF_CD,
							     PROD_LIST.MO_PACK_CD,
							     PROD_LIST.DEST_NAT_CD,
							     PROD_LIST.POW_LOC_CD,
							     PROD_LIST.TH1_POW_STRT_YMDHM,
	    				   	     PROD_LIST.TH2_POW_STRT_YMDHM,
	    				   	     PROD_LIST.TH3_POW_STRT_YMDHM,
	    				   	     PROD_LIST.TH4_POW_STRT_YMDHM,
	    				   	     PROD_LIST.TH5_POW_STRT_YMDHM,
	    				   	     PROD_LIST.TH6_POW_STRT_YMDHM,
	    				   	     PROD_LIST.TH7_POW_STRT_YMDHM,
	    				   	     PROD_LIST.TH8_POW_STRT_YMDHM,
	    				   	     PROD_LIST.TH9_POW_STRT_YMDHM,
	    				   	     PROD_LIST.T10PS1_YMDHM,
	    				   	     PROD_LIST.T11PS1_YMDHM,
	    				   	     PROD_LIST.T12PS1_YMDHM,
	    				   	 	 PROD_LIST.T13PS1_YMDHM,
	    				   	 	 PROD_LIST.T14PS1_YMDHM,
	    				   	 	 PROD_LIST.T15PS1_YMDHM,
	    				   	 	 PROD_LIST.T16PS1_YMDHM,
							 	 PROD_LIST.MDL_MDY_CD,
							 	 PROD_LIST.VIN,
							 	 SYSDATE,
							 	 SYSDATE,
							 	 PROD_LIST.TH0_POW_STRT_YMD,
							 	 PROD_LIST.PRDN_MDL_MDY_CD,
							 	 PROD_LIST.QLTY_VEHL_CD,
							 	 PROD_LIST.DL_EXPD_NAT_CD,
								 PROD_LIST.TRWI_USED_YN,
								 1,
                                 PROD_LIST.PRDN_PLNT_CD 
								);
								 
				   	   --현재 진행중인 물량이 존재하는지의 여부를 확인한다.
				   	   --(과거에 진행된 물량은 업데이트 작업을 수행해 주지 않는다.)   
				   	   ELSIF V_APL_FNH_YMD = '99991231' THEN
					      
                          --[점검]
					      SELECT MAX(POW_LOC_CD)
				   	   	  INTO V_POW_LOC_CD
				   	   	  FROM TB_PROD_MST_PROG_INFO
				   	   	  WHERE PRDN_MST_VEHL_CD = PROD_LIST.PRDN_MST_VEHL_CD
				   	   	  AND BN_SN              = PROD_LIST.BN_SN
				   	   	  AND DL_EXPD_CO_CD      = PROD_LIST.DL_EXPD_CO_CD
				   	   	  AND APL_STRT_YMD      <= PROD_LIST.TRWI_YMD
				   	   	  AND APL_FNH_YMD        = '99991231'
                          AND VIN                = PROD_LIST.VIN;
				       
--[고려필요]		   	  --[참고] 당일날 I/F 데이터의 현재 진행공정이 당일날 또 바뀐다면 이곳에서 
					   	  --       에러가 발생할 수 있으니 주의 요망됨 
					   	  --과거 진행중인 물량과 현재 진행중인 물량의 공정위치코드가 다른 경우에는 
					   	  --과거 진행 물량의 종료일을 변경한 뒤에 현재 진행중인 물량의 정보를 추가해 준다. 
					   	  IF V_POW_LOC_CD <> PROD_LIST.POW_LOC_CD THEN
					   	  	 
                             --[점검]
							 V_DTL_SN := GET_PROD_MST_PROG_MAX_DTL_SN(PROD_LIST.PRDN_MST_VEHL_CD,
								 					                  PROD_LIST.BN_SN,
							     							          PROD_LIST.DL_EXPD_CO_CD,
							     							          PROD_LIST.TRWI_YMD,
							     							          PROD_LIST.TRWI_YMD,
                                                                      PROD_LIST.VIN);
                             --[점검]                                         
					   	  	 UPDATE TB_PROD_MST_PROG_INFO
					  	  	 SET 
						      	 APL_FNH_YMD = PROD_LIST.TRWI_YMD,
					      	  	 MDFY_DTM = SYSDATE,
								 DTL_SN = V_DTL_SN,
								 PRDN_PLNT_CD = PROD_LIST.PRDN_PLNT_CD
					         WHERE PRDN_MST_VEHL_CD = PROD_LIST.PRDN_MST_VEHL_CD
					      	 AND BN_SN              = PROD_LIST.BN_SN
					      	 AND DL_EXPD_CO_CD      = PROD_LIST.DL_EXPD_CO_CD
					      	 AND APL_STRT_YMD      <= PROD_LIST.TRWI_YMD
					      	 AND APL_FNH_YMD        = '99991231'
                             AND VIN                = PROD_LIST.VIN;
					         
                             --[점검]      
						     INSERT INTO TB_PROD_MST_PROG_INFO
						  	 VALUES(PROD_LIST.PRDN_MST_VEHL_CD,
		 					     	PROD_LIST.BN_SN,
							        PROD_LIST.DL_EXPD_CO_CD,
							        PROD_LIST.TRWI_YMD,
							        '99991231',
							        PROD_LIST.USF_CD,
							        PROD_LIST.MO_PACK_CD,
							        PROD_LIST.DEST_NAT_CD,
							        PROD_LIST.POW_LOC_CD,
							        PROD_LIST.TH1_POW_STRT_YMDHM,
	    				   	        PROD_LIST.TH2_POW_STRT_YMDHM,
	    				   	        PROD_LIST.TH3_POW_STRT_YMDHM,
	    				   	        PROD_LIST.TH4_POW_STRT_YMDHM,
	    				   	        PROD_LIST.TH5_POW_STRT_YMDHM,
	    				   	        PROD_LIST.TH6_POW_STRT_YMDHM,
	    				   	        PROD_LIST.TH7_POW_STRT_YMDHM,
	    				   	        PROD_LIST.TH8_POW_STRT_YMDHM,
	    				   	        PROD_LIST.TH9_POW_STRT_YMDHM,
	    				   	        PROD_LIST.T10PS1_YMDHM,
	    				   	        PROD_LIST.T11PS1_YMDHM,
	    				   	        PROD_LIST.T12PS1_YMDHM,
	    				   	        PROD_LIST.T13PS1_YMDHM,
	    				   	        PROD_LIST.T14PS1_YMDHM,
	    				   	        PROD_LIST.T15PS1_YMDHM,
	    				   	        PROD_LIST.T16PS1_YMDHM,
							        PROD_LIST.MDL_MDY_CD,
							        PROD_LIST.VIN,
							        SYSDATE,
							        SYSDATE,
							        PROD_LIST.TH0_POW_STRT_YMD,
							        PROD_LIST.PRDN_MDL_MDY_CD,
							        PROD_LIST.QLTY_VEHL_CD,
							        PROD_LIST.DL_EXPD_NAT_CD,
									PROD_LIST.TRWI_USED_YN,
									1,
                                    PROD_LIST.PRDN_PLNT_CD 
								  );
							   
					      END IF; 
					   
				       END IF;
				   	  
				    END IF; --[END IF] 투입여부 체크(TRWI_USED_YN IS NOT NULL) 
				
				--상용의 경우의 처리 
				ELSIF V_PAC_SCN_CD = '02' THEN
					
                    --[점검] 
                    SELECT MAX(APL_FNH_YMD)
				   	INTO V_APL_FNH_YMD
				   	FROM TB_PROD_MST_PROG_INFO
				   	WHERE PRDN_MST_VEHL_CD = PROD_LIST.PRDN_MST_VEHL_CD
				   	AND BN_SN              = PROD_LIST.BN_SN
				   	AND DL_EXPD_CO_CD      = PROD_LIST.DL_EXPD_CO_CD
				   	AND APL_STRT_YMD      <= PROD_LIST.TRWI_YMD
				   	AND APL_FNH_YMD        > PROD_LIST.TRWI_YMD
                    AND VIN                = PROD_LIST.VIN;
				   
				    IF V_APL_FNH_YMD IS NULL THEN
				      
					  --[점검] 
                      --현재 한번도 저장된 적이 없는 데이터 이면 신규 추가해 준다. 
					  INSERT INTO TB_PROD_MST_PROG_INFO
					  VALUES(PROD_LIST.PRDN_MST_VEHL_CD,
		 					 PROD_LIST.BN_SN,
							 PROD_LIST.DL_EXPD_CO_CD,
							 PROD_LIST.TRWI_YMD,
							 --마지막 공정인 경우에는 완료일을 투입일보다 하루 뒤로 설정해 준다. 
							 DECODE(PROD_LIST.POW_LOC_CD, '16', TO_CHAR(TO_DATE(PROD_LIST.TRWI_YMD, 'YYYYMMDD') + 1, 'YYYYMMDD'), '99991231'),
							 PROD_LIST.USF_CD,
							 PROD_LIST.MO_PACK_CD,
							 PROD_LIST.DEST_NAT_CD,
							 PROD_LIST.POW_LOC_CD,
							 PROD_LIST.TH1_POW_STRT_YMDHM,
	    				   	 PROD_LIST.TH2_POW_STRT_YMDHM,
	    				   	 PROD_LIST.TH3_POW_STRT_YMDHM,
	    				   	 PROD_LIST.TH4_POW_STRT_YMDHM,
	    				   	 PROD_LIST.TH5_POW_STRT_YMDHM,
	    				   	 PROD_LIST.TH6_POW_STRT_YMDHM,
	    				   	 PROD_LIST.TH7_POW_STRT_YMDHM,
	    				   	 PROD_LIST.TH8_POW_STRT_YMDHM,
	    				   	 PROD_LIST.TH9_POW_STRT_YMDHM,
	    				   	 PROD_LIST.T10PS1_YMDHM,
	    				   	 PROD_LIST.T11PS1_YMDHM,
	    				   	 PROD_LIST.T12PS1_YMDHM,
	    				   	 PROD_LIST.T13PS1_YMDHM,
	    				   	 PROD_LIST.T14PS1_YMDHM,
	    				   	 PROD_LIST.T15PS1_YMDHM,
	    				   	 PROD_LIST.T16PS1_YMDHM,
							 PROD_LIST.MDL_MDY_CD,
							 PROD_LIST.VIN,
							 SYSDATE,
							 SYSDATE,
							 PROD_LIST.TH0_POW_STRT_YMD,
							 PROD_LIST.PRDN_MDL_MDY_CD,
							 PROD_LIST.QLTY_VEHL_CD,
							 PROD_LIST.DL_EXPD_NAT_CD,
							 PROD_LIST.TRWI_USED_YN,
							 1,
                             PROD_LIST.PRDN_PLNT_CD 
						   );
								 
				   	 --현재 진행중인 물량이 존재하는지의 여부를 확인한다.
				   	 --(과거에 진행된 물량은 업데이트 작업을 수행해 주지 않는다.)   
				   	 ELSIF V_APL_FNH_YMD = '99991231' THEN
					     
                         --[점검]
					     SELECT MAX(POW_LOC_CD)
				   	   	 INTO V_POW_LOC_CD
				   	   	 FROM TB_PROD_MST_PROG_INFO
				   	   	 WHERE PRDN_MST_VEHL_CD = PROD_LIST.PRDN_MST_VEHL_CD
				   	   	 AND BN_SN              = PROD_LIST.BN_SN
				   	   	 AND DL_EXPD_CO_CD      = PROD_LIST.DL_EXPD_CO_CD
				   	   	 AND APL_STRT_YMD      <= PROD_LIST.TRWI_YMD
				   	   	 AND APL_FNH_YMD        = '99991231'
                         AND VIN                = PROD_LIST.VIN;
				       
--[고려필요]		   	 --[참고] 당일날 I/F 데이터의 현재 진행공정이 당일날 또 바뀐다면 이곳에서 
					   	 --       에러가 발생할 수 있으니 주의 요망됨 
					   	 --과거 진행중인 물량과 현재 진행중인 물량의 공정위치코드가 다른 경우에는 
					   	 --과거 진행 물량의 종료일을 변경한 뒤에 현재 진행중인 물량의 정보를 추가해 준다. 
					   	 IF V_POW_LOC_CD <> PROD_LIST.POW_LOC_CD THEN
					   	 	 
                             --[점검]
							 V_DTL_SN := GET_PROD_MST_PROG_MAX_DTL_SN(PROD_LIST.PRDN_MST_VEHL_CD,
								 					                  PROD_LIST.BN_SN,
							     							          PROD_LIST.DL_EXPD_CO_CD,
							     							          PROD_LIST.TRWI_YMD,
							     							          PROD_LIST.TRWI_YMD,
                                                                      PROD_LIST.VIN);
						     
                             --[점검]											   
					   	     UPDATE TB_PROD_MST_PROG_INFO
					  	  	 SET 
						      	 APL_FNH_YMD = PROD_LIST.TRWI_YMD,
					      	  	 MDFY_DTM    = SYSDATE,
								 DTL_SN      = V_DTL_SN,
								 PRDN_PLNT_CD = PROD_LIST.PRDN_PLNT_CD
					         WHERE PRDN_MST_VEHL_CD = PROD_LIST.PRDN_MST_VEHL_CD
					      	 AND BN_SN              = PROD_LIST.BN_SN
					      	 AND DL_EXPD_CO_CD      = PROD_LIST.DL_EXPD_CO_CD
					      	 AND APL_STRT_YMD      <= PROD_LIST.TRWI_YMD
					      	 AND APL_FNH_YMD        = '99991231'
                             AND VIN                = PROD_LIST.VIN;
					         
                             --[점검]
						     INSERT INTO TB_PROD_MST_PROG_INFO
						  	 VALUES(PROD_LIST.PRDN_MST_VEHL_CD,
		 					     	PROD_LIST.BN_SN,
							        PROD_LIST.DL_EXPD_CO_CD,
							        PROD_LIST.TRWI_YMD,
									--마지막 공정인 경우에는 완료일을 투입일보다 하루 뒤로 설정해 준다. 
							        DECODE(PROD_LIST.POW_LOC_CD, '16', TO_CHAR(TO_DATE(PROD_LIST.TRWI_YMD, 'YYYYMMDD') + 1, 'YYYYMMDD'), '99991231'),
							        PROD_LIST.USF_CD,
							        PROD_LIST.MO_PACK_CD,
							        PROD_LIST.DEST_NAT_CD,
							        PROD_LIST.POW_LOC_CD,
							        PROD_LIST.TH1_POW_STRT_YMDHM,
	    				   	        PROD_LIST.TH2_POW_STRT_YMDHM,
	    				   	        PROD_LIST.TH3_POW_STRT_YMDHM,
	    				   	        PROD_LIST.TH4_POW_STRT_YMDHM,
	    				   	        PROD_LIST.TH5_POW_STRT_YMDHM,
	    				   	        PROD_LIST.TH6_POW_STRT_YMDHM,
	    				   	        PROD_LIST.TH7_POW_STRT_YMDHM,
	    				   	        PROD_LIST.TH8_POW_STRT_YMDHM,
	    				   	        PROD_LIST.TH9_POW_STRT_YMDHM,
	    				   	        PROD_LIST.T10PS1_YMDHM,
	    				   	        PROD_LIST.T11PS1_YMDHM,
	    				   	        PROD_LIST.T12PS1_YMDHM,
	    				   	        PROD_LIST.T13PS1_YMDHM,
	    				   	        PROD_LIST.T14PS1_YMDHM,
	    				   	        PROD_LIST.T15PS1_YMDHM,
	    				   	        PROD_LIST.T16PS1_YMDHM,
							        PROD_LIST.MDL_MDY_CD,
							        PROD_LIST.VIN,
							        SYSDATE,
							        SYSDATE,
							        PROD_LIST.TH0_POW_STRT_YMD,
							        PROD_LIST.PRDN_MDL_MDY_CD,
							        PROD_LIST.QLTY_VEHL_CD,
							        PROD_LIST.DL_EXPD_NAT_CD,
									PROD_LIST.TRWI_USED_YN,
									1,
                                    PROD_LIST.PRDN_PLNT_CD 
								   );
							   
					      END IF; 
					   
				     END IF;
					
				END IF; --[END IF] 승상구분 체크

			END LOOP;
			
	   END SP_UPDATE_PROD_MST_PROG_INFO;

/****************************************************************************************************************************/

/****************************************************************************************************************************/
	   
	   FUNCTION GET_PROD_MST_PROG_MAX_DTL_SN(P_PRDN_MST_VEHL_CD IN VARCHAR2,
	    				   					 P_BN_SN            IN VARCHAR2,
											 P_EXPD_CO_CD       IN VARCHAR2,
											 P_APL_STRT_YMD     IN VARCHAR2,
											 P_APL_FNH_YMD      IN VARCHAR2,
                                             P_VIN              IN VARCHAR2) RETURN NUMBER
	   IS
	   	 
		 V_DTL_SN NUMBER;
		 
	   BEGIN
	   		
			SELECT NVL(MAX(DTL_SN), 0) + 1
			INTO V_DTL_SN
			FROM TB_PROD_MST_PROG_INFO
			WHERE PRDN_MST_VEHL_CD = P_PRDN_MST_VEHL_CD
			AND BN_SN              = P_BN_SN
			AND DL_EXPD_CO_CD      = P_EXPD_CO_CD
			AND APL_STRT_YMD       = P_APL_STRT_YMD
			AND APL_FNH_YMD        = P_APL_FNH_YMD
            AND VIN                = P_VIN;
			
			RETURN V_DTL_SN;
					
	   END GET_PROD_MST_PROG_MAX_DTL_SN;
/**********************************************************/
/**********************************************************/
       --신버전 							  
	   PROCEDURE GET_PROD_MST_SUM2(FROM_YMD   IN VARCHAR2,
	                               TO_YMD     IN VARCHAR2,
								   P_APL_YMD  IN VARCHAR2,
								   EXPD_CO_CD IN VARCHAR2)
	   IS
	   	 
		 V_FROM_DATE DATE;
		 V_DATE_CNT  NUMBER;
		 V_CURR_DATE DATE;
		 V_CURR_YMD	 VARCHAR2(8);
		 V_CNT		 NUMBER;

		 --국가미지정 정보를 가져오는 부분
		 CURSOR PROD_MST_NOAPIM_INFO IS WITH AAA AS (
										SELECT QLTY_VEHL_CD,
												SUBSTR(MDL_MDY_CD, 1,4) AS MDL_MDY_CD,			
												EXPD_NAT_CD,
												APL_YMD,
												CASE WHEN PAC_SCN_CD = '01' THEN PRDN_PAS_QTY  -- 승용 생산수량
												ELSE PRDN_COM_QTY                         -- 상용 생산수량
												END AS PRDN_QTY,
												CASE WHEN PAC_SCN_CD = '01' THEN TRWI_PAS_QTY  -- 승용 투입수량
												ELSE TRWI_COM_QTY                         -- 상용 투입수량
												END AS TRWI_QTY,
												CASE WHEN PAC_SCN_CD = '01' THEN PRDN_PAS_QTY2  -- 승용 생산수량2
												ELSE PRDN_COM_QTY2                         -- 상용 생산수량2
												END AS PRDN_QTY2
										FROM (SELECT A.QLTY_VEHL_CD,
													A.MDL_MDY_CD,
													A.EXPD_NAT_CD,
													A.APL_YMD,
													(SELECT MAX(DL_EXPD_PAC_SCN_CD)	FROM TB_VEHL_MGMT WHERE QLTY_VEHL_CD = A.QLTY_VEHL_CD AND MDL_MDY_CD = A.MDL_MDY_CD) AS PAC_SCN_CD,
													SUM(CASE WHEN A.USF_CD = 'D' THEN A.PRDN_DOM_QTY -- 글로비스 생산수량
													ELSE A.PRDN_PAS_QTY                     -- 승용 생산수량
													END											            ) AS PRDN_PAS_QTY,
													SUM(CASE WHEN A.USF_CD = 'D' THEN A.PRDN_DOM_QTY -- 글로비스 생산수량
													ELSE A.PRDN_COM_QTY                     -- 상용 생산수량
													END											            ) AS PRDN_COM_QTY,
													SUM(CASE WHEN A.USF_CD = 'D' THEN A.TRWI_DOM_QTY -- 글로비스 투입수량
													ELSE A.TRWI_PAS_QTY                     -- 승용 투입수량
													END											            ) AS TRWI_PAS_QTY,
													SUM(CASE WHEN A.USF_CD = 'D' THEN A.TRWI_DOM_QTY -- 글로비스 투입수량
													ELSE A.TRWI_COM_QTY                     -- 상용 투입수량
													END											            ) AS TRWI_COM_QTY,
													SUM(CASE WHEN A.USF_CD = 'D' THEN A.PRDN_DOM_QTY2 -- 글로비스 생산수량
													ELSE A.PRDN_PAS_QTY2                     -- 승용 생산수량
													END											            ) AS PRDN_PAS_QTY2,
													SUM(CASE WHEN A.USF_CD = 'D' THEN A.PRDN_DOM_QTY2 -- 글로비스 생산수량
													ELSE A.PRDN_COM_QTY2                     -- 상용 생산수량
													END											            ) AS PRDN_COM_QTY2
												FROM (
												--미지정 국가 항목의 경우에는 투입일 기준이 아닌 적용일 기준으로 계산해 주도록 한다.
														SELECT B.QLTY_VEHL_CD,
																AGGR_CONCAT(DISTINCT TRIM(C.MDL_MDY_CD),',') AS MDL_MDY_CD,
																(SELECT MAX(DL_EXPD_NAT_CD)	FROM TB_NATL_MGMT
																		WHERE DL_EXPD_CO_CD = EXPD_CO_CD AND (DL_EXPD_NAT_CD = A.DEST_NAT_CD OR DL_EXPD_NAT_CD = SUBSTR(A.DEST_NAT_CD, 1, 3))) AS DL_EXPD_NAT_CD,
																A.DEST_NAT_CD AS EXPD_NAT_CD,
																A.TRWI_YMD AS APL_YMD,
																MAX(A.USF_CD) AS USF_CD, -- D:내수, E:수출
																SUM(CASE WHEN A.USF_CD = 'E' AND A.POW_LOC_CD < '10' THEN 1 ELSE 0 END) AS PRDN_PAS_QTY,  --승용 생산수량
																SUM(CASE WHEN A.USF_CD = 'E' AND A.POW_LOC_CD < '11' THEN 1 ELSE 0 END) AS PRDN_COM_QTY,  --상용 생산수량
																SUM(CASE WHEN A.USF_CD = 'D' AND A.POW_LOC_CD < '16' THEN 1 ELSE 0 END) AS PRDN_DOM_QTY,  --내수 생산수량
																SUM(CASE WHEN A.USF_CD = 'E' AND A.TRWI_USED_YN = 'N' AND A.POW_LOC_CD >= '10' THEN 1 ELSE 0 END) AS TRWI_PAS_QTY,  --승용 투입수량
																SUM(CASE WHEN A.USF_CD = 'E' AND A.TRWI_USED_YN = 'N' AND A.POW_LOC_CD >= '11' THEN 1 ELSE 0 END) AS TRWI_COM_QTY,  --상용 투입수량
																SUM(CASE WHEN A.USF_CD = 'D' AND A.TRWI_USED_YN = 'N' AND A.POW_LOC_CD >= '16' THEN 1 ELSE 0 END) AS TRWI_DOM_QTY,  --내수 투입수량
																SUM(CASE WHEN A.USF_CD = 'E' AND A.POW_LOC_CD >= '08' AND A.POW_LOC_CD < '10' THEN 1 ELSE 0 END) AS PRDN_PAS_QTY2,  --승용 생산수량2
																SUM(CASE WHEN A.USF_CD = 'E' AND A.POW_LOC_CD >= '08' AND A.POW_LOC_CD < '11' THEN 1 ELSE 0 END) AS PRDN_COM_QTY2,  --상용 생산수량2
																SUM(CASE WHEN A.USF_CD = 'D' AND A.POW_LOC_CD >= '08' AND A.POW_LOC_CD < '16' THEN 1 ELSE 0 END) AS PRDN_DOM_QTY2   --내수 생산수량2
														FROM TB_PROD_MST_INFO A,
																TB_ALTN_VEHL_MGMT B, 
																TB_PROD_MST_INFO_ERP_HMC C
														WHERE A.DL_EXPD_CO_CD = EXPD_CO_CD
														AND A.TRWI_YMD  = P_APL_YMD
														AND A.PRDN_MST_VEHL_CD = B.PRDN_VEHL_CD(+)
														AND B.PRVS_SCN_CD = 'B'
														AND A.MDL_MDY_CD IS NULL														  
														AND A.BN_SN = C.BN_SN
														AND A.TRWI_YMD = C.APL_YMD
														GROUP BY B.QLTY_VEHL_CD,
																C.MDL_MDY_CD,
																A.DEST_NAT_CD,
																A.TRWI_YMD
												) A
										WHERE DL_EXPD_NAT_CD IS NOT NULL 
										-- 내수인 경우와 미투입 대리점 리스트에 해당하는 경우는 제외
										AND EXPD_NAT_CD <> EXPD_DOM_NAT_CD  -- 'A99VA' 
										AND EXPD_NAT_CD NOT IN (SELECT DYTM_PLN_NAT_CD FROM TB_ALTN_WIOUT_NATL_MGMT)
										-- 언어가 등록되어 있지 않은 국가는 제외
										AND SUBSTR(EXPD_NAT_CD,1,3) IN (SELECT DL_EXPD_NAT_CD FROM TB_NATL_LANG_MGMT WHERE DL_EXPD_CO_CD = '01')
										GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.APL_YMD, A.EXPD_NAT_CD 
										))
										SELECT QLTY_VEHL_CD,
													MDL_MDY_CD,			
													EXPD_NAT_CD,
													APL_YMD,
													PRDN_QTY,
													TRWI_QTY,
													PRDN_QTY2
										FROM (
												SELECT QLTY_VEHL_CD,
													MDL_MDY_CD,			
													EXPD_NAT_CD,
													APL_YMD,
													PRDN_QTY,
													TRWI_QTY,
													PRDN_QTY2,
													CASE 	WHEN MDL_MDY_CD = '1' THEN '01'
															WHEN MDL_MDY_CD = '2' THEN '02'
															WHEN MDL_MDY_CD = '3' THEN '03'
															WHEN MDL_MDY_CD = '4' THEN '04'
															WHEN MDL_MDY_CD = '5' THEN '05'
															WHEN MDL_MDY_CD = '6' THEN '06'
															WHEN MDL_MDY_CD = '7' THEN '07'
															WHEN MDL_MDY_CD = '8' THEN '08'
															WHEN MDL_MDY_CD = '9' THEN '09'
															WHEN MDL_MDY_CD = 'A' THEN '10'
															WHEN MDL_MDY_CD = 'B' THEN '11'
															WHEN MDL_MDY_CD = 'C' THEN '12'
															WHEN MDL_MDY_CD = 'D' THEN '13'
															WHEN MDL_MDY_CD = 'E' THEN '14'
															WHEN MDL_MDY_CD = 'F' THEN '15'
															WHEN MDL_MDY_CD = 'G' THEN '16'
															WHEN MDL_MDY_CD = 'H' THEN '17'
															WHEN MDL_MDY_CD = 'J' THEN '18'
															WHEN MDL_MDY_CD = 'K' THEN '19'
															WHEN MDL_MDY_CD = 'M' THEN '20'
															WHEN MDL_MDY_CD = 'N' THEN '21'
															WHEN MDL_MDY_CD = 'O' THEN '22' 
															WHEN MDL_MDY_CD = 'P' THEN '23'
															WHEN MDL_MDY_CD = 'Q' THEN '24'
															WHEN MDL_MDY_CD = 'R' THEN '25'
															WHEN MDL_MDY_CD = 'S' THEN '26'
															WHEN MDL_MDY_CD = 'T' THEN '27'
															WHEN MDL_MDY_CD = 'U' THEN '28'
															WHEN MDL_MDY_CD = 'V' THEN '29'
															WHEN MDL_MDY_CD = 'W' THEN '30'
															WHEN MDL_MDY_CD = 'X' THEN '31'
															WHEN MDL_MDY_CD = 'Y' THEN '32'
															WHEN MDL_MDY_CD = 'Z' THEN '33'
															ELSE 'XX'  END AS MDL_MDY_NUM  -- 영문자 I, L은 숫자 1과 혼동 될 수 있으므로 제외함
												FROM AAA
												)
										WHERE ( QLTY_VEHL_CD, MDL_MDY_NUM ) NOT IN ( SELECT DISTINCT QLTY_VEHL_CD, MDL_MDY_CD FROM TB_VEHL_MDY_MGMT)
										ORDER BY QLTY_VEHL_CD, MDL_MDY_CD, EXPD_NAT_CD;
	 
		 --오더별생산내역 조회를 위한 부분 
		 --(현재는 날짜별로 오더에 관계된 생산된 데이터 전체를 무조건 처리해 준다.
		 -- 그리고 국가/언어가 제대로 설정된 데이터만 가져오도록 한다.(OUTER JOIN 필요없음) 
		 --[변경] 2009.07.23 PDI 공통차종 오더내역 조회 부분 포함		
		 					 
		 CURSOR PROD_ODR_INFO IS WITH T AS (SELECT A.QLTY_VEHL_CD, 
		 					  	 		   		   A.MDL_MDY_CD, 
												   B.LANG_CD,
												   A.APL_YMD,
												   A.MO_PACK_CD,
												   SUM(A.TRWI_QTY) AS TRWI_QTY
		 					  	            FROM (SELECT QLTY_VEHL_CD,
								 	  		  	 		 MDL_MDY_CD,
											  			 DL_EXPD_NAT_CD AS EXPD_NAT_CD,
											  			 APL_YMD,
											  			 MO_PACK_CD,
											  			 COUNT(*) AS TRWI_QTY
									              FROM TB_PROD_MST_TRWI_INFO
									   			  WHERE DL_EXPD_CO_CD = EXPD_CO_CD
									   			  AND APL_YMD BETWEEN FROM_YMD AND TO_YMD
									   			  AND QLTY_VEHL_CD IS NOT NULL   --현재 사용중인 차종에 대해서만 가져오도록 한다. 
									   			  AND MDL_MDY_CD IS NOT NULL     --연식이 지정된 항목만 가져온다.
									   			  AND DL_EXPD_NAT_CD IS NOT NULL --취급설명서국가코드가 등록된 항목만 가져온다.  
									   			  GROUP BY QLTY_VEHL_CD,
									  		      		   MDL_MDY_CD,
														   DL_EXPD_NAT_CD,
														   APL_YMD,
       								            		   MO_PACK_CD
								 	             ) A,
									  			 TB_NATL_LANG_MGMT B
								            WHERE A.EXPD_NAT_CD = B.DL_EXPD_NAT_CD
								 		    AND B.DL_EXPD_CO_CD = EXPD_CO_CD
								 		    AND A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
								 		    AND A.MDL_MDY_CD = B.MDL_MDY_CD
								 		    GROUP BY A.QLTY_VEHL_CD, A.APL_YMD, B.LANG_CD, A.MDL_MDY_CD, A.MO_PACK_CD
		 					  	 	  	   )
								 SELECT QLTY_VEHL_CD,
								 		MDL_MDY_CD,
										LANG_CD,
										APL_YMD,
										MO_PACK_CD,
										TRWI_QTY
								 FROM T
								 
								 UNION ALL
								 
								 SELECT B.DIVS_QLTY_VEHL_CD AS QLTY_VEHL_CD,
								        B.MDL_MDY_CD,
									    B.LANG_CD,
										A.APL_YMD,
										A.MO_PACK_CD,
										SUM(A.TRWI_QTY) AS TRWI_QTY
								 FROM T A,
								      TB_PDI_COM_VEHL_MGMT B
								 WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
								 AND A.MDL_MDY_CD = B.MDL_MDY_CD
								 AND A.LANG_CD = B.LANG_CD
								 GROUP BY B.DIVS_QLTY_VEHL_CD, A.APL_YMD, B.LANG_CD, B.MDL_MDY_CD, A.MO_PACK_CD; 
								 
								 
		 --생산마스터내역 조회를 위한 부분 
		 --(PDI 공통차종 오더내역 조회 부분 포함) 						 
		 CURSOR PROD_MST_INFO IS WITH T AS (SELECT A.QLTY_VEHL_CD, 
		 					  	 		   		   A.MDL_MDY_CD, 
												   B.LANG_CD,
												   A.APL_YMD,
												   SUM(A.TRWI_QTY) AS TRWI_QTY
		 					  	            FROM (SELECT QLTY_VEHL_CD,
								 	  		  	 		 MDL_MDY_CD,
											  			 DL_EXPD_NAT_CD AS EXPD_NAT_CD,
											  			 APL_YMD,
											  			 COUNT(*) AS TRWI_QTY
									              FROM TB_PROD_MST_TRWI_INFO
									   			  WHERE DL_EXPD_CO_CD = EXPD_CO_CD
									   			  AND APL_YMD BETWEEN FROM_YMD AND TO_YMD
									   			  AND QLTY_VEHL_CD IS NOT NULL   --현재 사용중인 차종에 대해서만 가져오도록 한다. 
									   			  AND MDL_MDY_CD IS NOT NULL     --연식이 지정된 항목만 가져온다.
									   			  AND DL_EXPD_NAT_CD IS NOT NULL --취급설명서국가코드가 등록된 항목만 가져온다.  
									   			  GROUP BY QLTY_VEHL_CD,
									  		      		   MDL_MDY_CD,
														   DL_EXPD_NAT_CD,
														   APL_YMD
								                 ) A,
									  			 TB_NATL_LANG_MGMT B
								            WHERE A.EXPD_NAT_CD = B.DL_EXPD_NAT_CD
								 			AND B.DL_EXPD_CO_CD = EXPD_CO_CD
								 			AND A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
								 			AND A.MDL_MDY_CD = B.MDL_MDY_CD
								 			GROUP BY A.QLTY_VEHL_CD, A.APL_YMD, B.LANG_CD, A.MDL_MDY_CD
								 			--재고 수불 기준이 이전연식부터 처리되어야 하기 때문에 
								 			--ORDER BY 의 순서를 아래와 같이 준수하여야 한다. 
								 			ORDER BY A.QLTY_VEHL_CD, A.APL_YMD, B.LANG_CD, A.MDL_MDY_CD
		 					  	 	       )
								 SELECT QLTY_VEHL_CD,
								 		MDL_MDY_CD,
										LANG_CD,
										APL_YMD,
										TRWI_QTY
								 FROM T
								 
								 UNION ALL
								 
								 SELECT B.DIVS_QLTY_VEHL_CD AS QLTY_VEHL_CD,
								        B.MDL_MDY_CD,
									    B.LANG_CD,
										A.APL_YMD,
										SUM(A.TRWI_QTY) AS TRWI_QTY
								 FROM T A,
								      TB_PDI_COM_VEHL_MGMT B
								 WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
								 AND A.MDL_MDY_CD = B.MDL_MDY_CD
								 AND A.LANG_CD = B.LANG_CD
								 GROUP BY B.DIVS_QLTY_VEHL_CD, A.APL_YMD, B.LANG_CD, B.MDL_MDY_CD; 
								 
		
		--[추가] 2010.04.13.김동근 생산정보 현황 - 공장별 내역 조회 
	    CURSOR PLNT_PROD_MST_INFO IS WITH T AS (SELECT A.QLTY_VEHL_CD, 
		 					  	 		   		       A.MDL_MDY_CD, 
												       B.LANG_CD,
												       A.APL_YMD,
												       SUM(A.TRWI_QTY) AS TRWI_QTY
		 					  	                FROM (SELECT A.QLTY_VEHL_CD,
								 	  		  	 		     A.MDL_MDY_CD,
											  			     A.DL_EXPD_NAT_CD AS EXPD_NAT_CD,
											  			     A.APL_YMD,
															 MAX(B.SORT_SN) AS SORT_SN,
											  			     COUNT(*) AS TRWI_QTY
									                  FROM TB_PROD_MST_TRWI_INFO A,
												           TB_PLNT_VEHL_MGMT B
									   			      WHERE DL_EXPD_CO_CD = EXPD_CO_CD
									   			      AND APL_YMD BETWEEN FROM_YMD AND TO_YMD
												      AND A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
									   			      AND A.QLTY_VEHL_CD IS NOT NULL   --현재 사용중인 차종에 대해서만 가져오도록 한다. 
									   			      AND A.MDL_MDY_CD IS NOT NULL     --연식이 지정된 항목만 가져온다.
									   			      AND A.DL_EXPD_NAT_CD IS NOT NULL --취급설명서국가코드가 등록된 항목만 가져온다.  
									   			      GROUP BY A.QLTY_VEHL_CD,
									  		      		       A.MDL_MDY_CD,
														       A.DL_EXPD_NAT_CD,
														       A.APL_YMD
								                     ) A,
									  			     TB_NATL_LANG_MGMT B
								                WHERE A.EXPD_NAT_CD = B.DL_EXPD_NAT_CD
								 		        AND B.DL_EXPD_CO_CD = EXPD_CO_CD
								 		        AND A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
								 		        AND A.MDL_MDY_CD = B.MDL_MDY_CD
								 		        GROUP BY A.QLTY_VEHL_CD, A.APL_YMD, B.LANG_CD, A.MDL_MDY_CD
								 		        --재고 수불 기준이 이전연식부터 처리되어야 하기 때문에 
								 		        --ORDER BY 의 순서를 아래와 같이 준수하여야 한다. 
								 		        ORDER BY A.QLTY_VEHL_CD, A.APL_YMD, B.LANG_CD, A.MDL_MDY_CD, MAX(A.SORT_SN)
		 					  	 	           )
								     SELECT QLTY_VEHL_CD,
								 	        MDL_MDY_CD,
									        LANG_CD,
									        APL_YMD,
									        TRWI_QTY
								     FROM T
								 
								     UNION ALL
								 
								     SELECT B.DIVS_QLTY_VEHL_CD AS QLTY_VEHL_CD,
								            B.MDL_MDY_CD,
									        B.LANG_CD,
									        A.APL_YMD,
									        SUM(A.TRWI_QTY) AS TRWI_QTY
								     FROM T A,
								          TB_PDI_COM_VEHL_MGMT B
								     WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
								     AND A.MDL_MDY_CD = B.MDL_MDY_CD
								     AND A.LANG_CD = B.LANG_CD
								     GROUP BY B.DIVS_QLTY_VEHL_CD, A.APL_YMD, B.LANG_CD, B.MDL_MDY_CD; 

	   BEGIN
	   		
			--적용 기간동안의 미지정내역을 삭제한 뒤 작업을 진행한다.
			--[참고] 회사구분이 존재하지 않으므로 아래와 같이 차종이 회사에 소속된
			--       내역만을 삭제해 주어야 한다.
			DELETE FROM TB_PROD_MST_NOAPIM_INFO A
			WHERE 1 = 1 --APL_YMD BETWEEN FROM_YMD AND TO_YMD
			AND EXISTS (SELECT 'EXIST'
                        FROM TB_VEHL_MGMT
			            WHERE QLTY_VEHL_CD = A.QLTY_VEHL_CD
			            AND DL_EXPD_CO_CD = EXPD_CO_CD
		                AND ROWNUM <= 1
		               )
		    ;

			PG_INTERFACE_APS.WRITE_BATCH_EXE_LOG('생산마스터배치작업_HMC', SYSDATE, 'S', 'GET_PROD_MST_SUM2 : PROD_MST_NOAPIM_INFO START');

			FOR NOAPIM_LIST IN PROD_MST_NOAPIM_INFO LOOP
			
				UPDATE TB_PROD_MST_NOAPIM_INFO
				SET PRDN_TRWI_QTY = NOAPIM_LIST.TRWI_QTY,
					PRDN_QTY = NOAPIM_LIST.PRDN_QTY,
					MDFY_DTM = SYSDATE,
					PRDN_QTY2 = NOAPIM_LIST.PRDN_QTY2
				WHERE APL_YMD = NOAPIM_LIST.APL_YMD
					AND QLTY_VEHL_CD = NOAPIM_LIST.QLTY_VEHL_CD
					AND MDL_MDY_CD = NOAPIM_LIST.MDL_MDY_CD
					AND PRDN_MST_NAT_CD = NOAPIM_LIST.EXPD_NAT_CD
				;
				
				IF SQL%NOTFOUND THEN
					INSERT INTO TB_PROD_MST_NOAPIM_INFO
				    (APL_YMD,
					 QLTY_VEHL_CD,
					 MDL_MDY_CD,
					 PRDN_MST_NAT_CD,
					 PRDN_TRWI_QTY,
					 PRDN_QTY,
					 FRAM_DTM,
					 MDFY_DTM,
					 PRDN_QTY2
				    )
					VALUES
					(NOAPIM_LIST.APL_YMD,
					 NOAPIM_LIST.QLTY_VEHL_CD,
					 NOAPIM_LIST.MDL_MDY_CD,
					 NOAPIM_LIST.EXPD_NAT_CD,
					 NOAPIM_LIST.TRWI_QTY,
					 NOAPIM_LIST.PRDN_QTY,
					 SYSDATE,
					 SYSDATE,
					 NOAPIM_LIST.PRDN_QTY2
				    );
					END IF;

			END LOOP;
			
			PG_INTERFACE_APS.WRITE_BATCH_EXE_LOG('생산마스터배치작업_HMC', SYSDATE, 'S', 'GET_PROD_MST_SUM2 : PROD_MST_NOAPIM_INFO END');

			--해당기간동안의 데이터를 삭제해 준다.
			
			DELETE FROM TB_PROD_MST_SUM_INFO A
			WHERE APL_YMD BETWEEN FROM_YMD AND TO_YMD
			AND EXISTS (SELECT 'EXIST'
                        FROM TB_VEHL_MGMT
			            WHERE QLTY_VEHL_CD = A.QLTY_VEHL_CD
			            AND DL_EXPD_CO_CD = EXPD_CO_CD
		                AND ROWNUM <= 1
		               );
			
			DELETE FROM TB_PROD_ODR_INFO A
			WHERE APL_YMD BETWEEN FROM_YMD AND TO_YMD
			AND EXISTS (SELECT 'EXIST'
                        FROM TB_VEHL_MGMT
			            WHERE QLTY_VEHL_CD = A.QLTY_VEHL_CD
			            AND DL_EXPD_CO_CD = EXPD_CO_CD
		                AND ROWNUM <= 1
		               );
			
			--[추가] 2010.04.13.김동근 생산정보 현황 - 공장별 내역 삭제 기능 추가 
			DELETE FROM TB_PLNT_PROD_MST_SUM_INFO A
			WHERE APL_YMD BETWEEN FROM_YMD AND TO_YMD
			AND EXISTS (SELECT 'EXIST'
                        FROM TB_VEHL_MGMT
			            WHERE QLTY_VEHL_CD = A.QLTY_VEHL_CD
			            AND DL_EXPD_CO_CD = EXPD_CO_CD
		                AND ROWNUM <= 1
		               );

			PG_INTERFACE_APS.WRITE_BATCH_EXE_LOG('생산마스터배치작업_HMC', SYSDATE, 'S', 'GET_PROD_MST_SUM2 : PROD_ODR_INFO START');
						
			-- 1.선행생산 데이터 처리  
			FOR ODR_LIST IN PROD_ODR_INFO LOOP
				
				UPDATE TB_PROD_ODR_INFO
				SET PRDN_TRWI_QTY = ODR_LIST.TRWI_QTY, 
					MDFY_DTM = SYSDATE
				WHERE MO_PACK_CD = ODR_LIST.MO_PACK_CD
				AND APL_YMD = ODR_LIST.APL_YMD
				AND QLTY_VEHL_CD = ODR_LIST.QLTY_VEHL_CD
				AND MDL_MDY_CD = ODR_LIST.MDL_MDY_CD
				AND LANG_CD = ODR_LIST.LANG_CD;
				   
				IF SQL%NOTFOUND THEN
				   	  
				    INSERT INTO TB_PROD_ODR_INFO
					(MO_PACK_CD,
					 DATA_SN,
					 APL_YMD,
					 QLTY_VEHL_CD,
					 MDL_MDY_CD,
					 LANG_CD,
					 PRDN_TRWI_QTY,
					 FRAM_DTM,
					 MDFY_DTM
					)
					SELECT ODR_LIST.MO_PACK_CD,
					       A.DATA_SN,
						   ODR_LIST.APL_YMD,
						   ODR_LIST.QLTY_VEHL_CD,
						   ODR_LIST.MDL_MDY_CD,
						   ODR_LIST.LANG_CD,
						   ODR_LIST.TRWI_QTY,
						   SYSDATE,
						   SYSDATE
					FROM TB_LANG_MGMT A
					WHERE A.QLTY_VEHL_CD = ODR_LIST.QLTY_VEHL_CD
					AND A.MDL_MDY_CD = ODR_LIST.MDL_MDY_CD
					AND A.LANG_CD = ODR_LIST.LANG_CD;
					  
				END IF;
				   
			END LOOP;
			
			PG_INTERFACE_APS.WRITE_BATCH_EXE_LOG('생산마스터배치작업_HMC', SYSDATE, 'S', 'GET_PROD_MST_SUM2 : PROD_ODR_INFO END');

			PG_INTERFACE_APS.WRITE_BATCH_EXE_LOG('생산마스터배치작업_HMC', SYSDATE, 'S', 'GET_PROD_MST_SUM2 : PROD_MST_INFO START');
			-- 2.TB_PROD_MST_SUM_INFO 에 값 저장 
			FOR PROD_LIST IN PROD_MST_INFO LOOP
				
				UPDATE TB_PROD_MST_SUM_INFO
				SET PRDN_TRWI_QTY = PROD_LIST.TRWI_QTY,
				    PRDN_QTY = 0,
					PRDN_QTY2 = 0,
					PRDN_QTY3 = 0,
					MDFY_DTM = SYSDATE
				WHERE APL_YMD = PROD_LIST.APL_YMD
				AND QLTY_VEHL_CD = PROD_LIST.QLTY_VEHL_CD
				AND MDL_MDY_CD = PROD_LIST.MDL_MDY_CD
				AND LANG_CD = PROD_LIST.LANG_CD;
				
				IF SQL%NOTFOUND THEN
				   
				   INSERT INTO TB_PROD_MST_SUM_INFO
				   (APL_YMD,
				    DATA_SN,
					QLTY_VEHL_CD,
					MDL_MDY_CD,
					LANG_CD,
					PRDN_TRWI_QTY,
					PRDN_QTY,
					FRAM_DTM,
					MDFY_DTM,
					PRDN_QTY2,
					PRDN_QTY3
				   )
				   SELECT PROD_LIST.APL_YMD,
				          DATA_SN,
						  PROD_LIST.QLTY_VEHL_CD,
						  PROD_LIST.MDL_MDY_CD,
						  PROD_LIST.LANG_CD,
						  PROD_LIST.TRWI_QTY,
						  0,
						  SYSDATE,
						  SYSDATE,
						  0,
						  0
				   FROM TB_LANG_MGMT A
				   WHERE A.QLTY_VEHL_CD = PROD_LIST.QLTY_VEHL_CD
				   AND A.MDL_MDY_CD = PROD_LIST.MDL_MDY_CD
				   AND A.LANG_CD = PROD_LIST.LANG_CD;
					
				END IF;
				
				-- 3.PDI재고에서 투입수량 빼주기 
				
				IF PROD_LIST.APL_YMD >= FROM_YMD AND  PROD_LIST.APL_YMD <= TO_YMD THEN 
				   
				   PG_DATA.SP_PROD_MST_PDI_IV_UPDATE(PROD_LIST.QLTY_VEHL_CD,
	   			 			   		       			 PROD_LIST.MDL_MDY_CD,
							   			   			 PROD_LIST.LANG_CD,
							   			   			 PROD_LIST.APL_YMD,
										   			 PROD_LIST.TRWI_QTY,
										   			 BTCH_USER_EENO);
				END IF;
								 
			END LOOP; 
			PG_INTERFACE_APS.WRITE_BATCH_EXE_LOG('생산마스터배치작업_HMC', SYSDATE, 'S', 'GET_PROD_MST_SUM2 : PROD_MST_INFO END');
			
			PG_INTERFACE_APS.WRITE_BATCH_EXE_LOG('생산마스터배치작업_HMC', SYSDATE, 'S', 'GET_PROD_MST_SUM2 : PLNT_PROD_MST_INFO START');
			--[추가] 2010.04.13.김동근 생산정보 현황 - 공장별 내역 저장 기능 추가 
			FOR PLNT_PROD_LIST IN PLNT_PROD_MST_INFO LOOP
				
				UPDATE TB_PLNT_PROD_MST_SUM_INFO
				SET PRDN_TRWI_QTY = PLNT_PROD_LIST.TRWI_QTY,
				    PRDN_QTY = 0,
					PRDN_QTY2 = 0,
					PRDN_QTY3 = 0,
					MDFY_DTM = SYSDATE
				WHERE APL_YMD = PLNT_PROD_LIST.APL_YMD
				AND QLTY_VEHL_CD = PLNT_PROD_LIST.QLTY_VEHL_CD
				AND MDL_MDY_CD = PLNT_PROD_LIST.MDL_MDY_CD
				AND LANG_CD = PLNT_PROD_LIST.LANG_CD;
				
				IF SQL%NOTFOUND THEN
				   
				   INSERT INTO TB_PLNT_PROD_MST_SUM_INFO
				   (APL_YMD,
				    DATA_SN,
					QLTY_VEHL_CD,
					MDL_MDY_CD,
					LANG_CD,
					PRDN_TRWI_QTY,
					PRDN_QTY,
					FRAM_DTM,
					MDFY_DTM,
					PRDN_QTY2,
					PRDN_QTY3
				   )
				   SELECT PLNT_PROD_LIST.APL_YMD,
				          DATA_SN,
						  PLNT_PROD_LIST.QLTY_VEHL_CD,
						  PLNT_PROD_LIST.MDL_MDY_CD,
						  PLNT_PROD_LIST.LANG_CD,
						  PLNT_PROD_LIST.TRWI_QTY,
						  0,
						  SYSDATE,
						  SYSDATE,
						  0,
						  0
				   FROM TB_LANG_MGMT A
				   WHERE A.QLTY_VEHL_CD = PLNT_PROD_LIST.QLTY_VEHL_CD
				   AND A.MDL_MDY_CD = PLNT_PROD_LIST.MDL_MDY_CD
				   AND A.LANG_CD = PLNT_PROD_LIST.LANG_CD;
					
				END IF;
				
			END LOOP;
			PG_INTERFACE_APS.WRITE_BATCH_EXE_LOG('생산마스터배치작업_HMC', SYSDATE, 'S', 'GET_PROD_MST_SUM2 : PLNT_PROD_MST_INFO END');
			
			V_FROM_DATE := TO_DATE(FROM_YMD, 'YYYYMMDD');
			V_DATE_CNT  := ROUND(TO_DATE(TO_YMD, 'YYYYMMDD') - V_FROM_DATE);
			
			FOR NUM IN 0.. V_DATE_CNT LOOP
				
				V_CURR_DATE := V_FROM_DATE + NUM;
				
				V_CURR_YMD := TO_CHAR(V_CURR_DATE, 'YYYYMMDD');
				
				--로직변경... 하루 이전까지만 수행하지 않고 현재일까지 수행하도록 한다. 				
				--생산마스터 생산 진행정보 업데이트 
				GET_PROD_MST_PROG_SUM(V_CURR_YMD, EXPD_CO_CD);
				
				--생산마스터정보 취합 작업 수행 
				GET_PROD_MST_SUM_DTL(V_CURR_YMD, V_CURR_YMD, EXPD_CO_CD);
				
				--재고 상세 내역 재 계산 작업 수행(생산마스터 정보 취합 후 작업이 수행되어야 한다.)
				--(반드시 세원재고 재계산 작업이 이루어진 후에 PDI 재고 데이터 재계산이 이루어 져야 한다.) 
				PG_DATA.SP_RECALCULATE_SEWHA_IV_DTL2(V_CURR_YMD, BTCH_USER_EENO);
				PG_DATA.SP_RECALCULATE_PDI_IV_DTL2(V_CURR_YMD, BTCH_USER_EENO);
			    
			END LOOP;
					   
		 EXCEPTION
		     WHEN OTHERS THEN
			     ROLLBACK;
				 PG_INTERFACE_APS.WRITE_BATCH_LOG('2.ERR 생산마스터배치작업_HMC', SYSDATE, 'F', '배치처리실패:[' || SQLERRM || ']');
                 COMMIT;
	   END GET_PROD_MST_SUM2;
/**********************************************************/
/**********************************************************/
	   PROCEDURE GET_PROD_MST_PROG_SUM(CURR_YMD IN VARCHAR2,
	                                   EXPD_CO_CD IN VARCHAR2)
	   IS
		 --생산마스터내역 조회를 위한 부분
		 --(PDI 공통차종 오더내역 조회 부분 포함)  						 
		 CURSOR PROD_MST_INFO IS WITH T AS (SELECT A.QLTY_VEHL_CD, 
		 					  	 		   		   A.MDL_MDY_CD, 
												   B.LANG_CD,
												   A.APL_YMD,
												   SUM(A.PRDN_QTY) AS PRDN_QTY,
												   SUM(A.PRDN_QTY2) AS PRDN_QTY2,
												   SUM(A.PRDN_QTY3) AS PRDN_QTY3,
												   SUM(A.TH0_POW_TRWI_QTY) AS TH0_POW_TRWI_QTY,
												   MIN(A.TH0_POS_STRT_YMD) AS TH0_POS_STRT_YMD, 
												   MAX(A.TH0_POS_FNH_YMD) AS TH0_POS_FNH_YMD,
												   SUM(A.TH1_POW_TRWI_QTY) AS TH1_POW_TRWI_QTY,
												   MIN(A.TH1_POS_STRT_YMDHM) AS TH1_POS_STRT_YMDHM, 
												   MAX(A.TH1_POS_FNH_YMDHM) AS TH1_POS_FNH_YMDHM,
												   SUM(A.TH2_POW_TRWI_QTY) AS TH2_POW_TRWI_QTY, 
												   MIN(A.TH2_POS_STRT_YMDHM) AS TH2_POS_STRT_YMDHM, 
												   MAX(A.TH2_POS_FNH_YMDHM) AS TH2_POS_FNH_YMDHM,
												   SUM(A.TH3_POW_TRWI_QTY) AS TH3_POW_TRWI_QTY,
												   MIN(A.TH3_POS_STRT_YMDHM) AS TH3_POS_STRT_YMDHM,
												   MAX(A.TH3_POS_FNH_YMDHM) AS TH3_POS_FNH_YMDHM,
												   SUM(A.TH4_POW_TRWI_QTY) AS TH4_POW_TRWI_QTY,
												   MIN(A.TH4_POS_STRT_YMDHM) AS TH4_POS_STRT_YMDHM,
												   MAX(A.TH4_POS_FNH_YMDHM) AS TH4_POS_FNH_YMDHM,
												   SUM(A.TH5_POW_TRWI_QTY) AS TH5_POW_TRWI_QTY,
												   MIN(A.TH5_POS_STRT_YMDHM) AS TH5_POS_STRT_YMDHM,
												   MAX(A.TH5_POS_FNH_YMDHM) AS TH5_POS_FNH_YMDHM,
												   SUM(A.TH6_POW_TRWI_QTY) AS TH6_POW_TRWI_QTY,
												   MIN(A.TH6_POS_STRT_YMDHM) AS TH6_POS_STRT_YMDHM,
												   MAX(A.TH6_POS_FNH_YMDHM) AS TH6_POS_FNH_YMDHM,
												   SUM(A.TH7_POW_TRWI_QTY) AS TH7_POW_TRWI_QTY,
												   MIN(A.TH7_POS_STRT_YMDHM) AS TH7_POS_STRT_YMDHM,
												   MAX(A.TH7_POS_FNH_YMDHM) AS TH7_POS_FNH_YMDHM,
												   SUM(A.TH8_POW_TRWI_QTY) AS TH8_POW_TRWI_QTY,
												   MIN(A.TH8_POS_STRT_YMDHM) AS TH8_POS_STRT_YMDHM,
												   MAX(A.TH8_POS_FNH_YMDHM) AS TH8_POS_FNH_YMDHM,
												   SUM(A.TH9_POW_TRWI_QTY) AS TH9_POW_TRWI_QTY,
												   MIN(A.TH9_POS_STRT_YMDHM) AS TH9_POS_STRT_YMDHM,
												   MAX(A.TH9_POS_FNH_YMDHM) AS TH9_POS_FNH_YMDHM,
												   SUM(A.TH10_POW_TRWI_QTY) AS TH10_POW_TRWI_QTY,
												   MIN(A.T10PS1_YMDHM) AS T10PS1_YMDHM,
												   MAX(A.TH10_POS_FNH_YMDHM) AS TH10_POS_FNH_YMDHM,
												   SUM(A.TH11_POW_TRWI_QTY) AS TH11_POW_TRWI_QTY,
												   MIN(A.T11PS1_YMDHM) AS T11PS1_YMDHM,
												   MAX(A.TH11_POS_FNH_YMDHM) AS TH11_POS_FNH_YMDHM,
												   SUM(A.TH12_POW_TRWI_QTY) AS TH12_POW_TRWI_QTY,
												   MIN(A.T12PS1_YMDHM) AS T12PS1_YMDHM,
												   MAX(A.TH12_POS_FNH_YMDHM) AS TH12_POS_FNH_YMDHM,
												   SUM(A.TH13_POW_TRWI_QTY) AS TH13_POW_TRWI_QTY,
												   MIN(A.T13PS1_YMDHM) AS T13PS1_YMDHM,
												   MAX(A.TH13_POS_FNH_YMDHM) AS TH13_POS_FNH_YMDHM,
												   SUM(A.TH16_POW_TRWI_QTY) AS TH16_POW_TRWI_QTY,
												   MIN(A.T16PS1_YMDHM) AS T16PS1_YMDHM,
												   MAX(A.TH16_POS_FNH_YMDHM) AS TH16_POS_FNH_YMDHM
		 					  	            FROM (SELECT QLTY_VEHL_CD,
								 	  		  	 		 MDL_MDY_CD,
											  			 DL_EXPD_NAT_CD AS EXPD_NAT_CD,
											  			 CURR_YMD AS APL_YMD,
											  			 SUM(CASE WHEN TRWI_USED_YN IS NULL THEN 1 ELSE 0 END) AS PRDN_QTY,
											  			 SUM(CASE WHEN TRWI_USED_YN IS NULL AND POW_LOC_CD >= '08' THEN 1 ELSE 0 END) AS PRDN_QTY2,
											  			 SUM(CASE WHEN TRWI_USED_YN IS NULL AND POW_LOC_CD >= '09' THEN 1 ELSE 0 END) AS PRDN_QTY3,
											  			 SUM(CASE WHEN POW_LOC_CD = '00' THEN 1 ELSE 0 END) AS TH0_POW_TRWI_QTY,
											  			 MIN(CASE WHEN POW_LOC_CD = '00' THEN TH0_POW_STRT_YMD ELSE '' END) AS TH0_POS_STRT_YMD,
											  			 MAX(CASE WHEN POW_LOC_CD = '00' THEN TH0_POW_STRT_YMD ELSE '' END) AS TH0_POS_FNH_YMD,
											  			 SUM(CASE WHEN POW_LOC_CD = '01' THEN 1 ELSE 0 END) AS TH1_POW_TRWI_QTY,
											  			 MIN(CASE WHEN POW_LOC_CD = '01' THEN TH1_POW_STRT_YMDHM ELSE '' END) AS TH1_POS_STRT_YMDHM,
											  			 MAX(CASE WHEN POW_LOC_CD = '01' THEN TH1_POW_STRT_YMDHM ELSE '' END) AS TH1_POS_FNH_YMDHM,
											  			 SUM(CASE WHEN POW_LOC_CD = '02' THEN 1 ELSE 0 END) AS TH2_POW_TRWI_QTY,
											  			 MIN(CASE WHEN POW_LOC_CD = '02' THEN TH2_POW_STRT_YMDHM ELSE '' END) AS TH2_POS_STRT_YMDHM,
											  			 MAX(CASE WHEN POW_LOC_CD = '02' THEN TH2_POW_STRT_YMDHM ELSE '' END) AS TH2_POS_FNH_YMDHM,
											  			 SUM(CASE WHEN POW_LOC_CD = '03' THEN 1 ELSE 0 END) AS TH3_POW_TRWI_QTY,
											  			 MIN(CASE WHEN POW_LOC_CD = '03' THEN TH3_POW_STRT_YMDHM ELSE '' END) AS TH3_POS_STRT_YMDHM,
											  			 MAX(CASE WHEN POW_LOC_CD = '03' THEN TH3_POW_STRT_YMDHM ELSE '' END) AS TH3_POS_FNH_YMDHM,
											  			 SUM(CASE WHEN POW_LOC_CD = '04' THEN 1 ELSE 0 END) AS TH4_POW_TRWI_QTY,
											  			 MIN(CASE WHEN POW_LOC_CD = '04' THEN TH4_POW_STRT_YMDHM ELSE '' END) AS TH4_POS_STRT_YMDHM,
											  			 MAX(CASE WHEN POW_LOC_CD = '04' THEN TH4_POW_STRT_YMDHM ELSE '' END) AS TH4_POS_FNH_YMDHM,
											  			 SUM(CASE WHEN POW_LOC_CD = '05' THEN 1 ELSE 0 END) AS TH5_POW_TRWI_QTY,
											  			 MIN(CASE WHEN POW_LOC_CD = '05' THEN TH5_POW_STRT_YMDHM ELSE '' END) AS TH5_POS_STRT_YMDHM,
											  			 MAX(CASE WHEN POW_LOC_CD = '05' THEN TH5_POW_STRT_YMDHM ELSE '' END) AS TH5_POS_FNH_YMDHM,
											  			 SUM(CASE WHEN POW_LOC_CD = '06' THEN 1 ELSE 0 END) AS TH6_POW_TRWI_QTY,
											  			 MIN(CASE WHEN POW_LOC_CD = '06' THEN TH6_POW_STRT_YMDHM ELSE '' END) AS TH6_POS_STRT_YMDHM,
											  			 MAX(CASE WHEN POW_LOC_CD = '06' THEN TH6_POW_STRT_YMDHM ELSE '' END) AS TH6_POS_FNH_YMDHM,
											  			 SUM(CASE WHEN POW_LOC_CD = '07' THEN 1 ELSE 0 END) AS TH7_POW_TRWI_QTY,
											  			 MIN(CASE WHEN POW_LOC_CD = '07' THEN TH7_POW_STRT_YMDHM ELSE '' END) AS TH7_POS_STRT_YMDHM,
											  			 MAX(CASE WHEN POW_LOC_CD = '07' THEN TH7_POW_STRT_YMDHM ELSE '' END) AS TH7_POS_FNH_YMDHM,
											  			 SUM(CASE WHEN POW_LOC_CD = '08' THEN 1 ELSE 0 END) AS TH8_POW_TRWI_QTY,
											  			 MIN(CASE WHEN POW_LOC_CD = '08' THEN TH8_POW_STRT_YMDHM ELSE '' END) AS TH8_POS_STRT_YMDHM,
											  			 MAX(CASE WHEN POW_LOC_CD = '08' THEN TH8_POW_STRT_YMDHM ELSE '' END) AS TH8_POS_FNH_YMDHM,
											  			 SUM(CASE WHEN POW_LOC_CD = '09' THEN 1 ELSE 0 END) AS TH9_POW_TRWI_QTY,
											  			 MIN(CASE WHEN POW_LOC_CD = '09' THEN TH9_POW_STRT_YMDHM ELSE '' END) AS TH9_POS_STRT_YMDHM,
											  			 MAX(CASE WHEN POW_LOC_CD = '09' THEN TH9_POW_STRT_YMDHM ELSE '' END) AS TH9_POS_FNH_YMDHM,
											  			 SUM(CASE WHEN POW_LOC_CD = '10' THEN 1 ELSE 0 END) AS TH10_POW_TRWI_QTY,
											  			 MIN(CASE WHEN POW_LOC_CD = '10' THEN T10PS1_YMDHM ELSE '' END) AS T10PS1_YMDHM,
											  			 MAX(CASE WHEN POW_LOC_CD = '10' THEN T10PS1_YMDHM ELSE '' END) AS TH10_POS_FNH_YMDHM,
											  			 SUM(CASE WHEN POW_LOC_CD = '11' THEN 1 ELSE 0 END) AS TH11_POW_TRWI_QTY,
											 			 MIN(CASE WHEN POW_LOC_CD = '11' THEN T11PS1_YMDHM ELSE '' END) AS T11PS1_YMDHM,
											  			 MAX(CASE WHEN POW_LOC_CD = '11' THEN T11PS1_YMDHM ELSE '' END) AS TH11_POS_FNH_YMDHM,
											  			 SUM(CASE WHEN POW_LOC_CD = '12' THEN 1 ELSE 0 END) AS TH12_POW_TRWI_QTY,
											  			 MIN(CASE WHEN POW_LOC_CD = '12' THEN T12PS1_YMDHM ELSE '' END) AS T12PS1_YMDHM,
											  			 MAX(CASE WHEN POW_LOC_CD = '12' THEN T12PS1_YMDHM ELSE '' END) AS TH12_POS_FNH_YMDHM,
											  			 SUM(CASE WHEN POW_LOC_CD = '13' THEN 1 ELSE 0 END) AS TH13_POW_TRWI_QTY,
											  			 MIN(CASE WHEN POW_LOC_CD = '13' THEN T13PS1_YMDHM ELSE '' END) AS T13PS1_YMDHM,
											  			 MAX(CASE WHEN POW_LOC_CD = '13' THEN T13PS1_YMDHM ELSE '' END) AS TH13_POS_FNH_YMDHM,
											  			 SUM(CASE WHEN POW_LOC_CD = '16' THEN 1 ELSE 0 END) AS TH16_POW_TRWI_QTY,
											  			 MIN(CASE WHEN POW_LOC_CD = '16' THEN T16PS1_YMDHM ELSE '' END) AS T16PS1_YMDHM,
											  			 MAX(CASE WHEN POW_LOC_CD = '16' THEN T16PS1_YMDHM ELSE '' END) AS TH16_POS_FNH_YMDHM 
									               FROM TB_PROD_MST_PROG_INFO
									   			   WHERE DL_EXPD_CO_CD = EXPD_CO_CD
									   			   AND APL_STRT_YMD <= CURR_YMD
									   			   AND APL_FNH_YMD > CURR_YMD
									   			   AND QLTY_VEHL_CD IS NOT NULL   --현재 사용중인 차종에 대해서만 가져오도록 한다. 
									   			   AND MDL_MDY_CD IS NOT NULL     --연식이 지정된 항목만 가져온다.
									   			   AND DL_EXPD_NAT_CD IS NOT NULL --취급설명서국가코드가 등록된 항목만 가져온다.  
									   			   GROUP BY QLTY_VEHL_CD,
									  		       		 	MDL_MDY_CD,
															DL_EXPD_NAT_CD
								                 ) A,
									  			 TB_NATL_LANG_MGMT B
								            WHERE A.EXPD_NAT_CD = B.DL_EXPD_NAT_CD
								 			AND B.DL_EXPD_CO_CD = EXPD_CO_CD
								 			AND A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
								 			AND A.MDL_MDY_CD = B.MDL_MDY_CD
								 			GROUP BY A.QLTY_VEHL_CD, A.APL_YMD, B.LANG_CD, A.MDL_MDY_CD
		 					  	 	  	   )
								 SELECT QLTY_VEHL_CD, MDL_MDY_CD, LANG_CD, APL_YMD,
										PRDN_QTY, PRDN_QTY2, PRDN_QTY3,
										TH0_POW_TRWI_QTY,  TH0_POS_STRT_YMD,   TH0_POS_FNH_YMD,
										TH1_POW_TRWI_QTY,  TH1_POS_STRT_YMDHM, TH1_POS_FNH_YMDHM,
										TH2_POW_TRWI_QTY,  TH2_POS_STRT_YMDHM, TH2_POS_FNH_YMDHM,
										TH3_POW_TRWI_QTY,  TH3_POS_STRT_YMDHM, TH3_POS_FNH_YMDHM,
										TH4_POW_TRWI_QTY,  TH4_POS_STRT_YMDHM, TH4_POS_FNH_YMDHM,
										TH5_POW_TRWI_QTY,  TH5_POS_STRT_YMDHM, TH5_POS_FNH_YMDHM,
										TH6_POW_TRWI_QTY,  TH6_POS_STRT_YMDHM, TH6_POS_FNH_YMDHM,
										TH7_POW_TRWI_QTY,  TH7_POS_STRT_YMDHM, TH7_POS_FNH_YMDHM,
										TH8_POW_TRWI_QTY,  TH8_POS_STRT_YMDHM, TH8_POS_FNH_YMDHM,
										TH9_POW_TRWI_QTY,  TH9_POS_STRT_YMDHM, TH9_POS_FNH_YMDHM,
										TH10_POW_TRWI_QTY, T10PS1_YMDHM,       TH10_POS_FNH_YMDHM,
										TH11_POW_TRWI_QTY, T11PS1_YMDHM,       TH11_POS_FNH_YMDHM,
										TH12_POW_TRWI_QTY, T12PS1_YMDHM,       TH12_POS_FNH_YMDHM,
										TH13_POW_TRWI_QTY, T13PS1_YMDHM,       TH13_POS_FNH_YMDHM,
										TH16_POW_TRWI_QTY, T16PS1_YMDHM,       TH16_POS_FNH_YMDHM
								 FROM T
								 
								 UNION ALL
								 
								 SELECT B.DIVS_QLTY_VEHL_CD AS QLTY_VEHL_CD,
								        B.MDL_MDY_CD,
									    B.LANG_CD,
										A.APL_YMD,
										SUM(A.PRDN_QTY) AS PRDN_QTY,
										SUM(A.PRDN_QTY2) AS PRDN_QTY2,
										SUM(A.PRDN_QTY3) AS PRDN_QTY3,
										SUM(A.TH0_POW_TRWI_QTY) AS TH0_POW_TRWI_QTY,
										MIN(A.TH0_POS_STRT_YMD) AS TH0_POS_STRT_YMD, 
										MAX(A.TH0_POS_FNH_YMD) AS TH0_POS_FNH_YMD,
										SUM(A.TH1_POW_TRWI_QTY) AS TH1_POW_TRWI_QTY,
										MIN(A.TH1_POS_STRT_YMDHM) AS TH1_POS_STRT_YMDHM, 
										MAX(A.TH1_POS_FNH_YMDHM) AS TH1_POS_FNH_YMDHM,
										SUM(A.TH2_POW_TRWI_QTY) AS TH2_POW_TRWI_QTY, 
										MIN(A.TH2_POS_STRT_YMDHM) AS TH2_POS_STRT_YMDHM, 
										MAX(A.TH2_POS_FNH_YMDHM) AS TH2_POS_FNH_YMDHM,
										SUM(A.TH3_POW_TRWI_QTY) AS TH3_POW_TRWI_QTY,
										MIN(A.TH3_POS_STRT_YMDHM) AS TH3_POS_STRT_YMDHM,
										MAX(A.TH3_POS_FNH_YMDHM) AS TH3_POS_FNH_YMDHM,
										SUM(A.TH4_POW_TRWI_QTY) AS TH4_POW_TRWI_QTY,
										MIN(A.TH4_POS_STRT_YMDHM) AS TH4_POS_STRT_YMDHM,
										MAX(A.TH4_POS_FNH_YMDHM) AS TH4_POS_FNH_YMDHM,
										SUM(A.TH5_POW_TRWI_QTY) AS TH5_POW_TRWI_QTY,
										MIN(A.TH5_POS_STRT_YMDHM) AS TH5_POS_STRT_YMDHM,
										MAX(A.TH5_POS_FNH_YMDHM) AS TH5_POS_FNH_YMDHM,
										SUM(A.TH6_POW_TRWI_QTY) AS TH6_POW_TRWI_QTY,
										MIN(A.TH6_POS_STRT_YMDHM) AS TH6_POS_STRT_YMDHM,
										MAX(A.TH6_POS_FNH_YMDHM) AS TH6_POS_FNH_YMDHM,
										SUM(A.TH7_POW_TRWI_QTY) AS TH7_POW_TRWI_QTY,
										MIN(A.TH7_POS_STRT_YMDHM) AS TH7_POS_STRT_YMDHM,
										MAX(A.TH7_POS_FNH_YMDHM) AS TH7_POS_FNH_YMDHM,
										SUM(A.TH8_POW_TRWI_QTY) AS TH8_POW_TRWI_QTY,
										MIN(A.TH8_POS_STRT_YMDHM) AS TH8_POS_STRT_YMDHM,
										MAX(A.TH8_POS_FNH_YMDHM) AS TH8_POS_FNH_YMDHM,
										SUM(A.TH9_POW_TRWI_QTY) AS TH9_POW_TRWI_QTY,
										MIN(A.TH9_POS_STRT_YMDHM) AS TH9_POS_STRT_YMDHM,
										MAX(A.TH9_POS_FNH_YMDHM) AS TH9_POS_FNH_YMDHM,
										SUM(A.TH10_POW_TRWI_QTY) AS TH10_POW_TRWI_QTY,
										MIN(A.T10PS1_YMDHM) AS T10PS1_YMDHM,
										MAX(A.TH10_POS_FNH_YMDHM) AS TH10_POS_FNH_YMDHM,
										SUM(A.TH11_POW_TRWI_QTY) AS TH11_POW_TRWI_QTY,
										MIN(A.T11PS1_YMDHM) AS T11PS1_YMDHM,
										MAX(A.TH11_POS_FNH_YMDHM) AS TH11_POS_FNH_YMDHM,
										SUM(A.TH12_POW_TRWI_QTY) AS TH12_POW_TRWI_QTY,
										MIN(A.T12PS1_YMDHM) AS T12PS1_YMDHM,
										MAX(A.TH12_POS_FNH_YMDHM) AS TH12_POS_FNH_YMDHM,
										SUM(A.TH13_POW_TRWI_QTY) AS TH13_POW_TRWI_QTY,
										MIN(A.T13PS1_YMDHM) AS T13PS1_YMDHM,
										MAX(A.TH13_POS_FNH_YMDHM) AS TH13_POS_FNH_YMDHM,
										SUM(A.TH16_POW_TRWI_QTY) AS TH16_POW_TRWI_QTY,
										MIN(A.T16PS1_YMDHM) AS T16PS1_YMDHM,
										MAX(A.TH16_POS_FNH_YMDHM) AS TH16_POS_FNH_YMDHM
								 FROM T A,
								      TB_PDI_COM_VEHL_MGMT B
							     WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
								 AND A.MDL_MDY_CD = B.MDL_MDY_CD
								 AND A.LANG_CD = B.LANG_CD
								 GROUP BY B.DIVS_QLTY_VEHL_CD, A.APL_YMD, B.LANG_CD, B.MDL_MDY_CD; 
								  										 
		 
		 --[추가] 2010.04.13.김동근 생산정보 현황 - 공장별 내역 조회 
		 CURSOR PLNT_MST_INFO IS WITH T AS (SELECT A.QLTY_VEHL_CD, 
		 					  	 		   		   A.MDL_MDY_CD, 
												   B.LANG_CD,
												   A.APL_YMD,
												   A.PRDN_PLNT_CD,
												   SUM(A.PRDN_QTY) AS PRDN_QTY,
												   SUM(A.PRDN_QTY2) AS PRDN_QTY2,
												   SUM(A.PRDN_QTY3) AS PRDN_QTY3,
												   SUM(A.TH0_POW_TRWI_QTY) AS TH0_POW_TRWI_QTY,
												   MIN(A.TH0_POS_STRT_YMD) AS TH0_POS_STRT_YMD, 
												   MAX(A.TH0_POS_FNH_YMD) AS TH0_POS_FNH_YMD,
												   SUM(A.TH1_POW_TRWI_QTY) AS TH1_POW_TRWI_QTY,
												   MIN(A.TH1_POS_STRT_YMDHM) AS TH1_POS_STRT_YMDHM, 
												   MAX(A.TH1_POS_FNH_YMDHM) AS TH1_POS_FNH_YMDHM,
												   SUM(A.TH2_POW_TRWI_QTY) AS TH2_POW_TRWI_QTY, 
												   MIN(A.TH2_POS_STRT_YMDHM) AS TH2_POS_STRT_YMDHM, 
												   MAX(A.TH2_POS_FNH_YMDHM) AS TH2_POS_FNH_YMDHM,
												   SUM(A.TH3_POW_TRWI_QTY) AS TH3_POW_TRWI_QTY,
												   MIN(A.TH3_POS_STRT_YMDHM) AS TH3_POS_STRT_YMDHM,
												   MAX(A.TH3_POS_FNH_YMDHM) AS TH3_POS_FNH_YMDHM,
												   SUM(A.TH4_POW_TRWI_QTY) AS TH4_POW_TRWI_QTY,
												   MIN(A.TH4_POS_STRT_YMDHM) AS TH4_POS_STRT_YMDHM,
												   MAX(A.TH4_POS_FNH_YMDHM) AS TH4_POS_FNH_YMDHM,
												   SUM(A.TH5_POW_TRWI_QTY) AS TH5_POW_TRWI_QTY,
												   MIN(A.TH5_POS_STRT_YMDHM) AS TH5_POS_STRT_YMDHM,
												   MAX(A.TH5_POS_FNH_YMDHM) AS TH5_POS_FNH_YMDHM,
												   SUM(A.TH6_POW_TRWI_QTY) AS TH6_POW_TRWI_QTY,
												   MIN(A.TH6_POS_STRT_YMDHM) AS TH6_POS_STRT_YMDHM,
												   MAX(A.TH6_POS_FNH_YMDHM) AS TH6_POS_FNH_YMDHM,
												   SUM(A.TH7_POW_TRWI_QTY) AS TH7_POW_TRWI_QTY,
												   MIN(A.TH7_POS_STRT_YMDHM) AS TH7_POS_STRT_YMDHM,
												   MAX(A.TH7_POS_FNH_YMDHM) AS TH7_POS_FNH_YMDHM,
												   SUM(A.TH8_POW_TRWI_QTY) AS TH8_POW_TRWI_QTY,
												   MIN(A.TH8_POS_STRT_YMDHM) AS TH8_POS_STRT_YMDHM,
												   MAX(A.TH8_POS_FNH_YMDHM) AS TH8_POS_FNH_YMDHM,
												   SUM(A.TH9_POW_TRWI_QTY) AS TH9_POW_TRWI_QTY,
												   MIN(A.TH9_POS_STRT_YMDHM) AS TH9_POS_STRT_YMDHM,
												   MAX(A.TH9_POS_FNH_YMDHM) AS TH9_POS_FNH_YMDHM,
												   SUM(A.TH10_POW_TRWI_QTY) AS TH10_POW_TRWI_QTY,
												   MIN(A.T10PS1_YMDHM) AS T10PS1_YMDHM,
												   MAX(A.TH10_POS_FNH_YMDHM) AS TH10_POS_FNH_YMDHM,
												   SUM(A.TH11_POW_TRWI_QTY) AS TH11_POW_TRWI_QTY,
												   MIN(A.T11PS1_YMDHM) AS T11PS1_YMDHM,
												   MAX(A.TH11_POS_FNH_YMDHM) AS TH11_POS_FNH_YMDHM,
												   SUM(A.TH12_POW_TRWI_QTY) AS TH12_POW_TRWI_QTY,
												   MIN(A.T12PS1_YMDHM) AS T12PS1_YMDHM,
												   MAX(A.TH12_POS_FNH_YMDHM) AS TH12_POS_FNH_YMDHM,
												   SUM(A.TH13_POW_TRWI_QTY) AS TH13_POW_TRWI_QTY,
												   MIN(A.T13PS1_YMDHM) AS T13PS1_YMDHM,
												   MAX(A.TH13_POS_FNH_YMDHM) AS TH13_POS_FNH_YMDHM,
												   SUM(A.TH16_POW_TRWI_QTY) AS TH16_POW_TRWI_QTY,
												   MIN(A.T16PS1_YMDHM) AS T16PS1_YMDHM,
												   MAX(A.TH16_POS_FNH_YMDHM) AS TH16_POS_FNH_YMDHM
		 					  	            FROM (SELECT A.QLTY_VEHL_CD,
								 	  		  	 		 A.MDL_MDY_CD,
											  			 A.DL_EXPD_NAT_CD AS EXPD_NAT_CD,
											  			 CURR_YMD AS APL_YMD,
														 B.PRDN_PLNT_CD,
											  			 SUM(CASE WHEN TRWI_USED_YN IS NULL THEN 1 ELSE 0 END) AS PRDN_QTY,
											  			 SUM(CASE WHEN TRWI_USED_YN IS NULL AND POW_LOC_CD >= '08' THEN 1 ELSE 0 END) AS PRDN_QTY2,
											  			 SUM(CASE WHEN TRWI_USED_YN IS NULL AND POW_LOC_CD >= '09' THEN 1 ELSE 0 END) AS PRDN_QTY3,
											  			 SUM(CASE WHEN POW_LOC_CD = '00' THEN 1 ELSE 0 END) AS TH0_POW_TRWI_QTY,
											  			 MIN(CASE WHEN POW_LOC_CD = '00' THEN TH0_POW_STRT_YMD ELSE '' END) AS TH0_POS_STRT_YMD,
											  			 MAX(CASE WHEN POW_LOC_CD = '00' THEN TH0_POW_STRT_YMD ELSE '' END) AS TH0_POS_FNH_YMD,
											  			 SUM(CASE WHEN POW_LOC_CD = '01' THEN 1 ELSE 0 END) AS TH1_POW_TRWI_QTY,
											  			 MIN(CASE WHEN POW_LOC_CD = '01' THEN TH1_POW_STRT_YMDHM ELSE '' END) AS TH1_POS_STRT_YMDHM,
											  			 MAX(CASE WHEN POW_LOC_CD = '01' THEN TH1_POW_STRT_YMDHM ELSE '' END) AS TH1_POS_FNH_YMDHM,
											  			 SUM(CASE WHEN POW_LOC_CD = '02' THEN 1 ELSE 0 END) AS TH2_POW_TRWI_QTY,
											  			 MIN(CASE WHEN POW_LOC_CD = '02' THEN TH2_POW_STRT_YMDHM ELSE '' END) AS TH2_POS_STRT_YMDHM,
											  			 MAX(CASE WHEN POW_LOC_CD = '02' THEN TH2_POW_STRT_YMDHM ELSE '' END) AS TH2_POS_FNH_YMDHM,
											  			 SUM(CASE WHEN POW_LOC_CD = '03' THEN 1 ELSE 0 END) AS TH3_POW_TRWI_QTY,
											  			 MIN(CASE WHEN POW_LOC_CD = '03' THEN TH3_POW_STRT_YMDHM ELSE '' END) AS TH3_POS_STRT_YMDHM,
											  			 MAX(CASE WHEN POW_LOC_CD = '03' THEN TH3_POW_STRT_YMDHM ELSE '' END) AS TH3_POS_FNH_YMDHM,
											  			 SUM(CASE WHEN POW_LOC_CD = '04' THEN 1 ELSE 0 END) AS TH4_POW_TRWI_QTY,
											  			 MIN(CASE WHEN POW_LOC_CD = '04' THEN TH4_POW_STRT_YMDHM ELSE '' END) AS TH4_POS_STRT_YMDHM,
											  			 MAX(CASE WHEN POW_LOC_CD = '04' THEN TH4_POW_STRT_YMDHM ELSE '' END) AS TH4_POS_FNH_YMDHM,
											  			 SUM(CASE WHEN POW_LOC_CD = '05' THEN 1 ELSE 0 END) AS TH5_POW_TRWI_QTY,
											  			 MIN(CASE WHEN POW_LOC_CD = '05' THEN TH5_POW_STRT_YMDHM ELSE '' END) AS TH5_POS_STRT_YMDHM,
											  			 MAX(CASE WHEN POW_LOC_CD = '05' THEN TH5_POW_STRT_YMDHM ELSE '' END) AS TH5_POS_FNH_YMDHM,
											  			 SUM(CASE WHEN POW_LOC_CD = '06' THEN 1 ELSE 0 END) AS TH6_POW_TRWI_QTY,
											  			 MIN(CASE WHEN POW_LOC_CD = '06' THEN TH6_POW_STRT_YMDHM ELSE '' END) AS TH6_POS_STRT_YMDHM,
											  			 MAX(CASE WHEN POW_LOC_CD = '06' THEN TH6_POW_STRT_YMDHM ELSE '' END) AS TH6_POS_FNH_YMDHM,
											  			 SUM(CASE WHEN POW_LOC_CD = '07' THEN 1 ELSE 0 END) AS TH7_POW_TRWI_QTY,
											  			 MIN(CASE WHEN POW_LOC_CD = '07' THEN TH7_POW_STRT_YMDHM ELSE '' END) AS TH7_POS_STRT_YMDHM,
											  			 MAX(CASE WHEN POW_LOC_CD = '07' THEN TH7_POW_STRT_YMDHM ELSE '' END) AS TH7_POS_FNH_YMDHM,
											  			 SUM(CASE WHEN POW_LOC_CD = '08' THEN 1 ELSE 0 END) AS TH8_POW_TRWI_QTY,
											  			 MIN(CASE WHEN POW_LOC_CD = '08' THEN TH8_POW_STRT_YMDHM ELSE '' END) AS TH8_POS_STRT_YMDHM,
											  			 MAX(CASE WHEN POW_LOC_CD = '08' THEN TH8_POW_STRT_YMDHM ELSE '' END) AS TH8_POS_FNH_YMDHM,
											  			 SUM(CASE WHEN POW_LOC_CD = '09' THEN 1 ELSE 0 END) AS TH9_POW_TRWI_QTY,
											  			 MIN(CASE WHEN POW_LOC_CD = '09' THEN TH9_POW_STRT_YMDHM ELSE '' END) AS TH9_POS_STRT_YMDHM,
											  			 MAX(CASE WHEN POW_LOC_CD = '09' THEN TH9_POW_STRT_YMDHM ELSE '' END) AS TH9_POS_FNH_YMDHM,
											  			 SUM(CASE WHEN POW_LOC_CD = '10' THEN 1 ELSE 0 END) AS TH10_POW_TRWI_QTY,
											  			 MIN(CASE WHEN POW_LOC_CD = '10' THEN T10PS1_YMDHM ELSE '' END) AS T10PS1_YMDHM,
											  			 MAX(CASE WHEN POW_LOC_CD = '10' THEN T10PS1_YMDHM ELSE '' END) AS TH10_POS_FNH_YMDHM,
											  			 SUM(CASE WHEN POW_LOC_CD = '11' THEN 1 ELSE 0 END) AS TH11_POW_TRWI_QTY,
											 			 MIN(CASE WHEN POW_LOC_CD = '11' THEN T11PS1_YMDHM ELSE '' END) AS T11PS1_YMDHM,
											  			 MAX(CASE WHEN POW_LOC_CD = '11' THEN T11PS1_YMDHM ELSE '' END) AS TH11_POS_FNH_YMDHM,
											  			 SUM(CASE WHEN POW_LOC_CD = '12' THEN 1 ELSE 0 END) AS TH12_POW_TRWI_QTY,
											  			 MIN(CASE WHEN POW_LOC_CD = '12' THEN T12PS1_YMDHM ELSE '' END) AS T12PS1_YMDHM,
											  			 MAX(CASE WHEN POW_LOC_CD = '12' THEN T12PS1_YMDHM ELSE '' END) AS TH12_POS_FNH_YMDHM,
											  			 SUM(CASE WHEN POW_LOC_CD = '13' THEN 1 ELSE 0 END) AS TH13_POW_TRWI_QTY,
											  			 MIN(CASE WHEN POW_LOC_CD = '13' THEN T13PS1_YMDHM ELSE '' END) AS T13PS1_YMDHM,
											  			 MAX(CASE WHEN POW_LOC_CD = '13' THEN T13PS1_YMDHM ELSE '' END) AS TH13_POS_FNH_YMDHM,
											  			 SUM(CASE WHEN POW_LOC_CD = '16' THEN 1 ELSE 0 END) AS TH16_POW_TRWI_QTY,
											  			 MIN(CASE WHEN POW_LOC_CD = '16' THEN T16PS1_YMDHM ELSE '' END) AS T16PS1_YMDHM,
											  			 MAX(CASE WHEN POW_LOC_CD = '16' THEN T16PS1_YMDHM ELSE '' END) AS TH16_POS_FNH_YMDHM 
									               FROM TB_PROD_MST_PROG_INFO A,
												   		TB_PLNT_VEHL_MGMT B
									   			   WHERE A.DL_EXPD_CO_CD = EXPD_CO_CD
									   			   AND A.APL_STRT_YMD <= CURR_YMD
									   			   AND A.APL_FNH_YMD > CURR_YMD
												   AND A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
												   AND A.PRDN_PLNT_CD = B.PRDN_PLNT_CD
									   			   AND A.QLTY_VEHL_CD IS NOT NULL   --현재 사용중인 차종에 대해서만 가져오도록 한다. 
									   			   AND A.MDL_MDY_CD IS NOT NULL     --연식이 지정된 항목만 가져온다.
									   			   AND A.DL_EXPD_NAT_CD IS NOT NULL --취급설명서국가코드가 등록된 항목만 가져온다.  
									   			   GROUP BY A.QLTY_VEHL_CD,
									  		       		 	A.MDL_MDY_CD,
															A.DL_EXPD_NAT_CD,
															B.PRDN_PLNT_CD
								                 ) A,
									  			 TB_NATL_LANG_MGMT B
								            WHERE A.EXPD_NAT_CD = B.DL_EXPD_NAT_CD
								 			AND B.DL_EXPD_CO_CD = EXPD_CO_CD
								 			AND A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
								 			AND A.MDL_MDY_CD = B.MDL_MDY_CD
								 			GROUP BY A.QLTY_VEHL_CD, A.APL_YMD, B.LANG_CD, A.MDL_MDY_CD, A.PRDN_PLNT_CD
		 					  	 	  	   )
								 SELECT QLTY_VEHL_CD, MDL_MDY_CD, LANG_CD, APL_YMD,
										PRDN_QTY, PRDN_QTY2, PRDN_QTY3,
										TH0_POW_TRWI_QTY,  TH0_POS_STRT_YMD,   TH0_POS_FNH_YMD,
										TH1_POW_TRWI_QTY,  TH1_POS_STRT_YMDHM, TH1_POS_FNH_YMDHM,
										TH2_POW_TRWI_QTY,  TH2_POS_STRT_YMDHM, TH2_POS_FNH_YMDHM,
										TH3_POW_TRWI_QTY,  TH3_POS_STRT_YMDHM, TH3_POS_FNH_YMDHM,
										TH4_POW_TRWI_QTY,  TH4_POS_STRT_YMDHM, TH4_POS_FNH_YMDHM,
										TH5_POW_TRWI_QTY,  TH5_POS_STRT_YMDHM, TH5_POS_FNH_YMDHM,
										TH6_POW_TRWI_QTY,  TH6_POS_STRT_YMDHM, TH6_POS_FNH_YMDHM,
										TH7_POW_TRWI_QTY,  TH7_POS_STRT_YMDHM, TH7_POS_FNH_YMDHM,
										TH8_POW_TRWI_QTY,  TH8_POS_STRT_YMDHM, TH8_POS_FNH_YMDHM,
										TH9_POW_TRWI_QTY,  TH9_POS_STRT_YMDHM, TH9_POS_FNH_YMDHM,
										TH10_POW_TRWI_QTY, T10PS1_YMDHM,       TH10_POS_FNH_YMDHM,
										TH11_POW_TRWI_QTY, T11PS1_YMDHM,       TH11_POS_FNH_YMDHM,
										TH12_POW_TRWI_QTY, T12PS1_YMDHM,       TH12_POS_FNH_YMDHM,
										TH13_POW_TRWI_QTY, T13PS1_YMDHM,       TH13_POS_FNH_YMDHM,
										TH16_POW_TRWI_QTY, T16PS1_YMDHM,       TH16_POS_FNH_YMDHM,
										PRDN_PLNT_CD
								 FROM T
								 
								 UNION ALL
								 
								 SELECT B.DIVS_QLTY_VEHL_CD AS QLTY_VEHL_CD,
								        B.MDL_MDY_CD,
									    B.LANG_CD,
										A.APL_YMD,
										SUM(A.PRDN_QTY) AS PRDN_QTY,
										SUM(A.PRDN_QTY2) AS PRDN_QTY2,
										SUM(A.PRDN_QTY3) AS PRDN_QTY3,
										SUM(A.TH0_POW_TRWI_QTY) AS TH0_POW_TRWI_QTY,
										MIN(A.TH0_POS_STRT_YMD) AS TH0_POS_STRT_YMD, 
										MAX(A.TH0_POS_FNH_YMD) AS TH0_POS_FNH_YMD,
										SUM(A.TH1_POW_TRWI_QTY) AS TH1_POW_TRWI_QTY,
										MIN(A.TH1_POS_STRT_YMDHM) AS TH1_POS_STRT_YMDHM, 
										MAX(A.TH1_POS_FNH_YMDHM) AS TH1_POS_FNH_YMDHM,
										SUM(A.TH2_POW_TRWI_QTY) AS TH2_POW_TRWI_QTY, 
										MIN(A.TH2_POS_STRT_YMDHM) AS TH2_POS_STRT_YMDHM, 
										MAX(A.TH2_POS_FNH_YMDHM) AS TH2_POS_FNH_YMDHM,
										SUM(A.TH3_POW_TRWI_QTY) AS TH3_POW_TRWI_QTY,
										MIN(A.TH3_POS_STRT_YMDHM) AS TH3_POS_STRT_YMDHM,
										MAX(A.TH3_POS_FNH_YMDHM) AS TH3_POS_FNH_YMDHM,
										SUM(A.TH4_POW_TRWI_QTY) AS TH4_POW_TRWI_QTY,
										MIN(A.TH4_POS_STRT_YMDHM) AS TH4_POS_STRT_YMDHM,
										MAX(A.TH4_POS_FNH_YMDHM) AS TH4_POS_FNH_YMDHM,
										SUM(A.TH5_POW_TRWI_QTY) AS TH5_POW_TRWI_QTY,
										MIN(A.TH5_POS_STRT_YMDHM) AS TH5_POS_STRT_YMDHM,
										MAX(A.TH5_POS_FNH_YMDHM) AS TH5_POS_FNH_YMDHM,
										SUM(A.TH6_POW_TRWI_QTY) AS TH6_POW_TRWI_QTY,
										MIN(A.TH6_POS_STRT_YMDHM) AS TH6_POS_STRT_YMDHM,
										MAX(A.TH6_POS_FNH_YMDHM) AS TH6_POS_FNH_YMDHM,
										SUM(A.TH7_POW_TRWI_QTY) AS TH7_POW_TRWI_QTY,
										MIN(A.TH7_POS_STRT_YMDHM) AS TH7_POS_STRT_YMDHM,
										MAX(A.TH7_POS_FNH_YMDHM) AS TH7_POS_FNH_YMDHM,
										SUM(A.TH8_POW_TRWI_QTY) AS TH8_POW_TRWI_QTY,
										MIN(A.TH8_POS_STRT_YMDHM) AS TH8_POS_STRT_YMDHM,
										MAX(A.TH8_POS_FNH_YMDHM) AS TH8_POS_FNH_YMDHM,
										SUM(A.TH9_POW_TRWI_QTY) AS TH9_POW_TRWI_QTY,
										MIN(A.TH9_POS_STRT_YMDHM) AS TH9_POS_STRT_YMDHM,
										MAX(A.TH9_POS_FNH_YMDHM) AS TH9_POS_FNH_YMDHM,
										SUM(A.TH10_POW_TRWI_QTY) AS TH10_POW_TRWI_QTY,
										MIN(A.T10PS1_YMDHM) AS T10PS1_YMDHM,
										MAX(A.TH10_POS_FNH_YMDHM) AS TH10_POS_FNH_YMDHM,
										SUM(A.TH11_POW_TRWI_QTY) AS TH11_POW_TRWI_QTY,
										MIN(A.T11PS1_YMDHM) AS T11PS1_YMDHM,
										MAX(A.TH11_POS_FNH_YMDHM) AS TH11_POS_FNH_YMDHM,
										SUM(A.TH12_POW_TRWI_QTY) AS TH12_POW_TRWI_QTY,
										MIN(A.T12PS1_YMDHM) AS T12PS1_YMDHM,
										MAX(A.TH12_POS_FNH_YMDHM) AS TH12_POS_FNH_YMDHM,
										SUM(A.TH13_POW_TRWI_QTY) AS TH13_POW_TRWI_QTY,
										MIN(A.T13PS1_YMDHM) AS T13PS1_YMDHM,
										MAX(A.TH13_POS_FNH_YMDHM) AS TH13_POS_FNH_YMDHM,
										SUM(A.TH16_POW_TRWI_QTY) AS TH16_POW_TRWI_QTY,
										MIN(A.T16PS1_YMDHM) AS T16PS1_YMDHM,
										MAX(A.TH16_POS_FNH_YMDHM) AS TH16_POS_FNH_YMDHM,
										A.PRDN_PLNT_CD
								 FROM T A,
								      TB_PDI_COM_VEHL_MGMT B
							     WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
								 AND A.MDL_MDY_CD = B.MDL_MDY_CD
								 AND A.LANG_CD = B.LANG_CD
								 GROUP BY B.DIVS_QLTY_VEHL_CD, A.APL_YMD, B.LANG_CD, B.MDL_MDY_CD, A.PRDN_PLNT_CD; 
								  
	   BEGIN
	   	   	
			-- 2.TB_PROD_MST_SUM_INFO 에 값 저장 
			FOR PROD_LIST IN PROD_MST_INFO LOOP
				
				UPDATE TB_PROD_MST_SUM_INFO
				SET PRDN_QTY = PROD_LIST.PRDN_QTY,
					PRDN_QTY2 = PROD_LIST.PRDN_QTY2,
					PRDN_QTY3 = PROD_LIST.PRDN_QTY3,
					TH0_POW_TRWI_QTY = PROD_LIST.TH0_POW_TRWI_QTY,
					TH0_POW_STRT_YMD = PROD_LIST.TH0_POS_STRT_YMD,
					TH0_POW_FNH_YMD = PROD_LIST.TH0_POS_FNH_YMD,
					TH1_POW_TRWI_QTY = PROD_LIST.TH1_POW_TRWI_QTY,
					TH1_POW_STRT_YMDHM = PROD_LIST.TH1_POS_STRT_YMDHM,
					TH1_POW_FNH_YMDHM = PROD_LIST.TH1_POS_FNH_YMDHM,
					TH2_POW_TRWI_QTY = PROD_LIST.TH2_POW_TRWI_QTY,
					TH2_POW_STRT_YMDHM = PROD_LIST.TH2_POS_STRT_YMDHM,
					TH2_POW_FNH_YMDHM = PROD_LIST.TH2_POS_FNH_YMDHM,
					TH3_POW_TRWI_QTY = PROD_LIST.TH3_POW_TRWI_QTY,
					TH3_POW_STRT_YMDHM = PROD_LIST.TH3_POS_STRT_YMDHM,
					TH3_POW_FNH_YMDHM = PROD_LIST.TH3_POS_FNH_YMDHM,
					TH4_POW_TRWI_QTY = PROD_LIST.TH4_POW_TRWI_QTY,
					TH4_POW_STRT_YMDHM = PROD_LIST.TH4_POS_STRT_YMDHM,
					TH4_POW_FNH_YMDHM = PROD_LIST.TH4_POS_FNH_YMDHM,
					TH5_POW_TRWI_QTY = PROD_LIST.TH5_POW_TRWI_QTY,
					TH5_POW_STRT_YMDHM = PROD_LIST.TH5_POS_STRT_YMDHM,
					TH5_POW_FNH_YMDHM = PROD_LIST.TH5_POS_FNH_YMDHM,
					TH6_POW_TRWI_QTY = PROD_LIST.TH6_POW_TRWI_QTY,
					TH6_POW_STRT_YMDHM = PROD_LIST.TH6_POS_STRT_YMDHM,
					TH6_POW_FNH_YMDHM = PROD_LIST.TH6_POS_FNH_YMDHM,
					TH7_POW_TRWI_QTY = PROD_LIST.TH7_POW_TRWI_QTY,
					TH7_POW_STRT_YMDHM = PROD_LIST.TH7_POS_STRT_YMDHM,
					TH7_POW_FNH_YMDHM = PROD_LIST.TH7_POS_FNH_YMDHM,
					TH8_POW_TRWI_QTY = PROD_LIST.TH8_POW_TRWI_QTY,
					TH8_POW_STRT_YMDHM = PROD_LIST.TH8_POS_STRT_YMDHM,
					TH8_POW_FNH_YMDHM = PROD_LIST.TH8_POS_FNH_YMDHM,
					TH9_POW_TRWI_QTY = PROD_LIST.TH9_POW_TRWI_QTY,
					TH9_POW_STRT_YMDHM = PROD_LIST.TH9_POS_STRT_YMDHM,
					TH9_POW_FNH_YMDHM = PROD_LIST.TH9_POS_FNH_YMDHM,
					TH10_POW_TRWI_QTY = PROD_LIST.TH10_POW_TRWI_QTY,
					T10PS1_YMDHM = PROD_LIST.T10PS1_YMDHM,
					TH10_POW_FNH_YMDHM = PROD_LIST.TH10_POS_FNH_YMDHM,
					TH11_POW_TRWI_QTY = PROD_LIST.TH11_POW_TRWI_QTY,
					T11PS1_YMDHM = PROD_LIST.T11PS1_YMDHM,
					TH11_POW_FNH_YMDHM = PROD_LIST.TH11_POS_FNH_YMDHM,
					TH12_POW_TRWI_QTY = PROD_LIST.TH12_POW_TRWI_QTY,
					T12PS1_YMDHM = PROD_LIST.T12PS1_YMDHM,
					TH12_POW_FNH_YMDHM = PROD_LIST.TH12_POS_FNH_YMDHM,
					TH13_POW_TRWI_QTY = PROD_LIST.TH13_POW_TRWI_QTY,
					T13PS1_YMDHM = PROD_LIST.T13PS1_YMDHM,
					TH13_POW_FNH_YMDHM = PROD_LIST.TH13_POS_FNH_YMDHM,
					TH16_POW_TRWI_QTY = PROD_LIST.TH16_POW_TRWI_QTY,
					T16PS1_YMDHM = PROD_LIST.T16PS1_YMDHM,
					TH16_POW_FNH_YMDHM = PROD_LIST.TH16_POS_FNH_YMDHM,
					MDFY_DTM = SYSDATE
				WHERE APL_YMD = PROD_LIST.APL_YMD
				AND QLTY_VEHL_CD = PROD_LIST.QLTY_VEHL_CD
				AND MDL_MDY_CD = PROD_LIST.MDL_MDY_CD
				AND LANG_CD = PROD_LIST.LANG_CD;
				
				IF SQL%NOTFOUND THEN
				   
				   INSERT INTO TB_PROD_MST_SUM_INFO
				   (APL_YMD,
				    DATA_SN,
					QLTY_VEHL_CD,
					MDL_MDY_CD,
					LANG_CD,
					PRDN_TRWI_QTY,
					PRDN_QTY,
					TH1_POW_TRWI_QTY,
				   	TH1_POW_STRT_YMDHM,   
					TH1_POW_FNH_YMDHM,   
					TH2_POW_TRWI_QTY,    
					TH2_POW_STRT_YMDHM,  
					TH2_POW_FNH_YMDHM,   
					TH3_POW_TRWI_QTY,    
					TH3_POW_STRT_YMDHM,  
					TH3_POW_FNH_YMDHM,   
					TH4_POW_TRWI_QTY,     
					TH4_POW_STRT_YMDHM,  
					TH4_POW_FNH_YMDHM,   
					TH5_POW_TRWI_QTY,    
					TH5_POW_STRT_YMDHM,  
					TH5_POW_FNH_YMDHM,   
					TH6_POW_TRWI_QTY,    
					TH6_POW_STRT_YMDHM,  
					TH6_POW_FNH_YMDHM,   
					TH7_POW_TRWI_QTY,    
					TH7_POW_STRT_YMDHM,  
					TH7_POW_FNH_YMDHM,   
					TH8_POW_TRWI_QTY,    
					TH8_POW_STRT_YMDHM,  
					TH8_POW_FNH_YMDHM,   
					TH9_POW_TRWI_QTY,    
					TH9_POW_STRT_YMDHM,  
					TH9_POW_FNH_YMDHM,   
					TH10_POW_TRWI_QTY,   
					T10PS1_YMDHM,        
					TH10_POW_FNH_YMDHM,  
					TH11_POW_TRWI_QTY,   
					T11PS1_YMDHM,        
					TH11_POW_FNH_YMDHM,  
					TH12_POW_TRWI_QTY,   
					T12PS1_YMDHM,        
					TH12_POW_FNH_YMDHM,  
					TH13_POW_TRWI_QTY, 
					T13PS1_YMDHM,      
					TH13_POW_FNH_YMDHM,
					TH16_POW_TRWI_QTY,   
					T16PS1_YMDHM,        
					TH16_POW_FNH_YMDHM,
					FRAM_DTM,
					MDFY_DTM,
					TH0_POW_STRT_YMD,
					TH0_POW_FNH_YMD,
					TH0_POW_TRWI_QTY,
					PRDN_QTY2,
					PRDN_QTY3
				   )
				   SELECT PROD_LIST.APL_YMD,
				          DATA_SN,
						  PROD_LIST.QLTY_VEHL_CD,
						  PROD_LIST.MDL_MDY_CD,
						  PROD_LIST.LANG_CD,
						  0,
						  PROD_LIST.PRDN_QTY,
						  PROD_LIST.TH1_POW_TRWI_QTY,
					      PROD_LIST.TH1_POS_STRT_YMDHM,   
						  PROD_LIST.TH1_POS_FNH_YMDHM,    
						  PROD_LIST.TH2_POW_TRWI_QTY,     
						  PROD_LIST.TH2_POS_STRT_YMDHM,   
						  PROD_LIST.TH2_POS_FNH_YMDHM,    
						  PROD_LIST.TH3_POW_TRWI_QTY,     
						  PROD_LIST.TH3_POS_STRT_YMDHM,   
						  PROD_LIST.TH3_POS_FNH_YMDHM,    
						  PROD_LIST.TH4_POW_TRWI_QTY,     
						  PROD_LIST.TH4_POS_STRT_YMDHM,   
						  PROD_LIST.TH4_POS_FNH_YMDHM,    
						  PROD_LIST.TH5_POW_TRWI_QTY,     
						  PROD_LIST.TH5_POS_STRT_YMDHM,   
						  PROD_LIST.TH5_POS_FNH_YMDHM,    
						  PROD_LIST.TH6_POW_TRWI_QTY,     
						  PROD_LIST.TH6_POS_STRT_YMDHM,   
						  PROD_LIST.TH6_POS_FNH_YMDHM,    
						  PROD_LIST.TH7_POW_TRWI_QTY,     
						  PROD_LIST.TH7_POS_STRT_YMDHM,   
						  PROD_LIST.TH7_POS_FNH_YMDHM,    
						  PROD_LIST.TH8_POW_TRWI_QTY,     
						  PROD_LIST.TH8_POS_STRT_YMDHM,   
						  PROD_LIST.TH8_POS_FNH_YMDHM,    
						  PROD_LIST.TH9_POW_TRWI_QTY,     
						  PROD_LIST.TH9_POS_STRT_YMDHM,   
						  PROD_LIST.TH9_POS_FNH_YMDHM,    
						  PROD_LIST.TH10_POW_TRWI_QTY,    
						  PROD_LIST.T10PS1_YMDHM,         
						  PROD_LIST.TH10_POS_FNH_YMDHM,   
						  PROD_LIST.TH11_POW_TRWI_QTY,    
						  PROD_LIST.T11PS1_YMDHM,         
						  PROD_LIST.TH11_POS_FNH_YMDHM,   
						  PROD_LIST.TH12_POW_TRWI_QTY,    
						  PROD_LIST.T12PS1_YMDHM,         
						  PROD_LIST.TH12_POS_FNH_YMDHM,   
						  PROD_LIST.TH13_POW_TRWI_QTY,    
						  PROD_LIST.T13PS1_YMDHM,         
						  PROD_LIST.TH13_POS_FNH_YMDHM,   
						  PROD_LIST.TH16_POW_TRWI_QTY,    
						  PROD_LIST.T16PS1_YMDHM,         
						  PROD_LIST.TH16_POS_FNH_YMDHM,
						  SYSDATE,
						  SYSDATE,
						  PROD_LIST.TH0_POS_STRT_YMD,
						  PROD_LIST.TH0_POS_FNH_YMD,
						  PROD_LIST.TH0_POW_TRWI_QTY,
						  PROD_LIST.PRDN_QTY2,
						  PROD_LIST.PRDN_QTY3
				   FROM TB_LANG_MGMT A
				   WHERE A.QLTY_VEHL_CD = PROD_LIST.QLTY_VEHL_CD
				   AND A.MDL_MDY_CD = PROD_LIST.MDL_MDY_CD
				   AND A.LANG_CD = PROD_LIST.LANG_CD;
					
				END IF;
			 
			 END LOOP; 
			 
			 --[추가] 2010.04.13.김동근 생산정보 현황 - 공장별 내역 저장 기능 추가 
			 FOR PLNT_LIST IN PLNT_MST_INFO LOOP
				
				UPDATE TB_PLNT_PROD_MST_SUM_INFO
				SET PRDN_QTY = PLNT_LIST.PRDN_QTY,
					PRDN_QTY2 = PLNT_LIST.PRDN_QTY2,
					PRDN_QTY3 = PLNT_LIST.PRDN_QTY3,
					TH0_POW_TRWI_QTY = PLNT_LIST.TH0_POW_TRWI_QTY,
					TH0_POW_STRT_YMD = PLNT_LIST.TH0_POS_STRT_YMD,
					TH0_POW_FNH_YMD = PLNT_LIST.TH0_POS_FNH_YMD,
					TH1_POW_TRWI_QTY = PLNT_LIST.TH1_POW_TRWI_QTY,
					TH1_POW_STRT_YMDHM = PLNT_LIST.TH1_POS_STRT_YMDHM,
					TH1_POW_FNH_YMDHM = PLNT_LIST.TH1_POS_FNH_YMDHM,
					TH2_POW_TRWI_QTY = PLNT_LIST.TH2_POW_TRWI_QTY,
					TH2_POW_STRT_YMDHM = PLNT_LIST.TH2_POS_STRT_YMDHM,
					TH2_POW_FNH_YMDHM = PLNT_LIST.TH2_POS_FNH_YMDHM,
					TH3_POW_TRWI_QTY = PLNT_LIST.TH3_POW_TRWI_QTY,
					TH3_POW_STRT_YMDHM = PLNT_LIST.TH3_POS_STRT_YMDHM,
					TH3_POW_FNH_YMDHM = PLNT_LIST.TH3_POS_FNH_YMDHM,
					TH4_POW_TRWI_QTY = PLNT_LIST.TH4_POW_TRWI_QTY,
					TH4_POW_STRT_YMDHM = PLNT_LIST.TH4_POS_STRT_YMDHM,
					TH4_POW_FNH_YMDHM = PLNT_LIST.TH4_POS_FNH_YMDHM,
					TH5_POW_TRWI_QTY = PLNT_LIST.TH5_POW_TRWI_QTY,
					TH5_POW_STRT_YMDHM = PLNT_LIST.TH5_POS_STRT_YMDHM,
					TH5_POW_FNH_YMDHM = PLNT_LIST.TH5_POS_FNH_YMDHM,
					TH6_POW_TRWI_QTY = PLNT_LIST.TH6_POW_TRWI_QTY,
					TH6_POW_STRT_YMDHM = PLNT_LIST.TH6_POS_STRT_YMDHM,
					TH6_POW_FNH_YMDHM = PLNT_LIST.TH6_POS_FNH_YMDHM,
					TH7_POW_TRWI_QTY = PLNT_LIST.TH7_POW_TRWI_QTY,
					TH7_POW_STRT_YMDHM = PLNT_LIST.TH7_POS_STRT_YMDHM,
					TH7_POW_FNH_YMDHM = PLNT_LIST.TH7_POS_FNH_YMDHM,
					TH8_POW_TRWI_QTY = PLNT_LIST.TH8_POW_TRWI_QTY,
					TH8_POW_STRT_YMDHM = PLNT_LIST.TH8_POS_STRT_YMDHM,
					TH8_POW_FNH_YMDHM = PLNT_LIST.TH8_POS_FNH_YMDHM,
					TH9_POW_TRWI_QTY = PLNT_LIST.TH9_POW_TRWI_QTY,
					TH9_POW_STRT_YMDHM = PLNT_LIST.TH9_POS_STRT_YMDHM,
					TH9_POW_FNH_YMDHM = PLNT_LIST.TH9_POS_FNH_YMDHM,
					TH10_POW_TRWI_QTY = PLNT_LIST.TH10_POW_TRWI_QTY,
					T10PS1_YMDHM = PLNT_LIST.T10PS1_YMDHM,
					TH10_POW_FNH_YMDHM = PLNT_LIST.TH10_POS_FNH_YMDHM,
					TH11_POW_TRWI_QTY = PLNT_LIST.TH11_POW_TRWI_QTY,
					T11PS1_YMDHM = PLNT_LIST.T11PS1_YMDHM,
					TH11_POW_FNH_YMDHM = PLNT_LIST.TH11_POS_FNH_YMDHM,
					TH12_POW_TRWI_QTY = PLNT_LIST.TH12_POW_TRWI_QTY,
					T12PS1_YMDHM = PLNT_LIST.T12PS1_YMDHM,
					TH12_POW_FNH_YMDHM = PLNT_LIST.TH12_POS_FNH_YMDHM,
					TH13_POW_TRWI_QTY = PLNT_LIST.TH13_POW_TRWI_QTY,
					T13PS1_YMDHM = PLNT_LIST.T13PS1_YMDHM,
					TH13_POW_FNH_YMDHM = PLNT_LIST.TH13_POS_FNH_YMDHM,
					TH16_POW_TRWI_QTY = PLNT_LIST.TH16_POW_TRWI_QTY,
					T16PS1_YMDHM = PLNT_LIST.T16PS1_YMDHM,
					TH16_POW_FNH_YMDHM = PLNT_LIST.TH16_POS_FNH_YMDHM,
					MDFY_DTM = SYSDATE
				WHERE APL_YMD = PLNT_LIST.APL_YMD
				AND QLTY_VEHL_CD = PLNT_LIST.QLTY_VEHL_CD
				AND MDL_MDY_CD = PLNT_LIST.MDL_MDY_CD
				AND LANG_CD = PLNT_LIST.LANG_CD
				AND PRDN_PLNT_CD = PLNT_LIST.PRDN_PLNT_CD;
				
				IF SQL%NOTFOUND THEN
				   
				   INSERT INTO TB_PLNT_PROD_MST_SUM_INFO
				   (APL_YMD,
				    DATA_SN,
					QLTY_VEHL_CD,
					MDL_MDY_CD,
					LANG_CD,
					PRDN_TRWI_QTY,
					PRDN_QTY,
					TH1_POW_TRWI_QTY,
				   	TH1_POW_STRT_YMDHM,   
					TH1_POW_FNH_YMDHM,   
					TH2_POW_TRWI_QTY,    
					TH2_POW_STRT_YMDHM,  
					TH2_POW_FNH_YMDHM,   
					TH3_POW_TRWI_QTY,    
					TH3_POW_STRT_YMDHM,  
					TH3_POW_FNH_YMDHM,   
					TH4_POW_TRWI_QTY,     
					TH4_POW_STRT_YMDHM,  
					TH4_POW_FNH_YMDHM,   
					TH5_POW_TRWI_QTY,    
					TH5_POW_STRT_YMDHM,  
					TH5_POW_FNH_YMDHM,   
					TH6_POW_TRWI_QTY,    
					TH6_POW_STRT_YMDHM,  
					TH6_POW_FNH_YMDHM,   
					TH7_POW_TRWI_QTY,    
					TH7_POW_STRT_YMDHM,  
					TH7_POW_FNH_YMDHM,   
					TH8_POW_TRWI_QTY,    
					TH8_POW_STRT_YMDHM,  
					TH8_POW_FNH_YMDHM,   
					TH9_POW_TRWI_QTY,    
					TH9_POW_STRT_YMDHM,  
					TH9_POW_FNH_YMDHM,   
					TH10_POW_TRWI_QTY,   
					T10PS1_YMDHM,        
					TH10_POW_FNH_YMDHM,  
					TH11_POW_TRWI_QTY,   
					T11PS1_YMDHM,        
					TH11_POW_FNH_YMDHM,  
					TH12_POW_TRWI_QTY,   
					T12PS1_YMDHM,        
					TH12_POW_FNH_YMDHM,  
					TH13_POW_TRWI_QTY, 
					T13PS1_YMDHM,      
					TH13_POW_FNH_YMDHM,
					TH16_POW_TRWI_QTY,   
					T16PS1_YMDHM,        
					TH16_POW_FNH_YMDHM,
					FRAM_DTM,
					MDFY_DTM,
					TH0_POW_STRT_YMD,
					TH0_POW_FNH_YMD,
					TH0_POW_TRWI_QTY,
					PRDN_QTY2,
					PRDN_QTY3,
					PRDN_PLNT_CD
				   )
				   SELECT PLNT_LIST.APL_YMD,
				          DATA_SN,
						  PLNT_LIST.QLTY_VEHL_CD,
						  PLNT_LIST.MDL_MDY_CD,
						  PLNT_LIST.LANG_CD,
						  0,
						  PLNT_LIST.PRDN_QTY,
						  PLNT_LIST.TH1_POW_TRWI_QTY,
					      PLNT_LIST.TH1_POS_STRT_YMDHM,   
						  PLNT_LIST.TH1_POS_FNH_YMDHM,    
						  PLNT_LIST.TH2_POW_TRWI_QTY,     
						  PLNT_LIST.TH2_POS_STRT_YMDHM,   
						  PLNT_LIST.TH2_POS_FNH_YMDHM,    
						  PLNT_LIST.TH3_POW_TRWI_QTY,     
						  PLNT_LIST.TH3_POS_STRT_YMDHM,   
						  PLNT_LIST.TH3_POS_FNH_YMDHM,    
						  PLNT_LIST.TH4_POW_TRWI_QTY,     
						  PLNT_LIST.TH4_POS_STRT_YMDHM,   
						  PLNT_LIST.TH4_POS_FNH_YMDHM,    
						  PLNT_LIST.TH5_POW_TRWI_QTY,     
						  PLNT_LIST.TH5_POS_STRT_YMDHM,   
						  PLNT_LIST.TH5_POS_FNH_YMDHM,    
						  PLNT_LIST.TH6_POW_TRWI_QTY,     
						  PLNT_LIST.TH6_POS_STRT_YMDHM,   
						  PLNT_LIST.TH6_POS_FNH_YMDHM,    
						  PLNT_LIST.TH7_POW_TRWI_QTY,     
						  PLNT_LIST.TH7_POS_STRT_YMDHM,   
						  PLNT_LIST.TH7_POS_FNH_YMDHM,    
						  PLNT_LIST.TH8_POW_TRWI_QTY,     
						  PLNT_LIST.TH8_POS_STRT_YMDHM,   
						  PLNT_LIST.TH8_POS_FNH_YMDHM,    
						  PLNT_LIST.TH9_POW_TRWI_QTY,     
						  PLNT_LIST.TH9_POS_STRT_YMDHM,   
						  PLNT_LIST.TH9_POS_FNH_YMDHM,    
						  PLNT_LIST.TH10_POW_TRWI_QTY,    
						  PLNT_LIST.T10PS1_YMDHM,         
						  PLNT_LIST.TH10_POS_FNH_YMDHM,   
						  PLNT_LIST.TH11_POW_TRWI_QTY,    
						  PLNT_LIST.T11PS1_YMDHM,         
						  PLNT_LIST.TH11_POS_FNH_YMDHM,   
						  PLNT_LIST.TH12_POW_TRWI_QTY,    
						  PLNT_LIST.T12PS1_YMDHM,         
						  PLNT_LIST.TH12_POS_FNH_YMDHM,   
						  PLNT_LIST.TH13_POW_TRWI_QTY,    
						  PLNT_LIST.T13PS1_YMDHM,         
						  PLNT_LIST.TH13_POS_FNH_YMDHM,   
						  PLNT_LIST.TH16_POW_TRWI_QTY,    
						  PLNT_LIST.T16PS1_YMDHM,         
						  PLNT_LIST.TH16_POS_FNH_YMDHM,
						  SYSDATE,
						  SYSDATE,
						  PLNT_LIST.TH0_POS_STRT_YMD,
						  PLNT_LIST.TH0_POS_FNH_YMD,
						  PLNT_LIST.TH0_POW_TRWI_QTY,
						  PLNT_LIST.PRDN_QTY2,
						  PLNT_LIST.PRDN_QTY3,
						  PLNT_LIST.PRDN_PLNT_CD
				   FROM TB_LANG_MGMT A
				   WHERE A.QLTY_VEHL_CD = PLNT_LIST.QLTY_VEHL_CD
				   AND A.MDL_MDY_CD = PLNT_LIST.MDL_MDY_CD
				   AND A.LANG_CD = PLNT_LIST.LANG_CD;
					
				END IF;
			 
			 END LOOP; 
			 
	   END GET_PROD_MST_PROG_SUM;										
/**********************************************************/
/**********************************************************/	   
	   --화면에 표시되는 데이터의 형태로 생산마스터 정보를 취합하는 작업을 수행								  
	   PROCEDURE GET_PROD_MST_SUM_DTL(CURR_YMD   IN VARCHAR2,
	   			 					  SRCH_YMD	 IN VARCHAR2,
	                                  EXPD_CO_CD IN VARCHAR2)
	   IS
	   	 
		 V_SRCH_DATE	DATE := TO_DATE(SRCH_YMD, 'YYYYMMDD');
	     
		 V_PREV_YEAR_YMD VARCHAR2(8) := TO_CHAR(ADD_MONTHS(V_SRCH_DATE, -12), 'YYYYMM') || '01';
		 V_PREV_3MTH_YMD VARCHAR2(8) := TO_CHAR(ADD_MONTHS(V_SRCH_DATE, -3), 'YYYYMM') || '01';
		 V_PREV_1MTH_YMD VARCHAR2(8) := TO_CHAR(LAST_DAY(ADD_MONTHS(V_SRCH_DATE, -1)), 'YYYYMMDD');
		 V_CURR_FSTD_YMD VARCHAR2(8) := TO_CHAR(V_SRCH_DATE, 'YYYYMM') || '01';
		 
		 --실제 전일날짜 
		 V_PREV_1DAY_YMD1 VARCHAR2(8) := TO_CHAR(V_SRCH_DATE - 1, 'YYYYMMDD');
		 
		 --영업일 기준 전일날짜
		 V_PREV_1DAY_YMD2 VARCHAR2(8) := PG_COMMON.FU_GET_WRKDATE(SRCH_YMD, -1);
		 
		 --휴일을 포함한 전일 날짜 
		 V_PREV_1DAY_INCL_HLD_YMD2 VARCHAR2(8) := PG_COMMON.FU_GET_PRV1DAY_INCL_HOLIDAY(SRCH_YMD);

		 V_PREV_2WEK_YMD VARCHAR2(8) := TO_CHAR(V_SRCH_DATE - 14, 'YYYYMMDD');
		 
		 V_PREV_1WEK_YMD VARCHAR2(8) := TO_CHAR(V_SRCH_DATE - 7, 'YYYYMMDD');
		 
		 
		 CURSOR PROD_MST_SUM_INFO IS SELECT MAX(DATA_SN) AS DATA_SN,
									   		QLTY_VEHL_CD,
											MDL_MDY_CD,
											LANG_CD, 
									   		SUM(MTH3_MO_AVG_TRWI_QTY) AS MTH3_MO_AVG_TRWI_QTY, 
											SUM(TMM_TRWI_QTY) AS TMM_TRWI_QTY,
											SUM(BOD_TRWI_QTY) AS BOD_TRWI_QTY,
											SUM(BOD_TRWI_QTY_INCL) AS BOD_TRWI_QTY_INCL,
											SUM(TDD_PRDN_QTY) AS TDD_PRDN_QTY,
											SUM(YER1_DLY_AVG_TRWI_QTY) AS YER1_DLY_AVG_TRWI_QTY,
											SUM(MTH3_DLY_AVG_TRWI_QTY) AS MTH3_DLY_AVG_TRWI_QTY,
											SUM(WEK2_DLY_AVG_TRWI_QTY) AS WEK2_DLY_AVG_TRWI_QTY,
											SUM(TDD_PRDN_QTY2) AS TDD_PRDN_QTY2,
											SUM(TDD_PRDN_QTY3) AS TDD_PRDN_QTY3,
											SUM(WEK1_DLY_AVG_TRWI_QTY) AS WEK1_DLY_AVG_TRWI_QTY
				   					 FROM (
									   	     --3개월 월평균 투입수량, 3개월 일평균 투입수량 조회 
									   	     SELECT MAX(A.DATA_SN) AS DATA_SN,
									   			    A.QLTY_VEHL_CD,
												    A.MDL_MDY_CD,
												    A.LANG_CD, 
									   				ROUND(SUM(A.PRDN_TRWI_QTY) / 3) AS MTH3_MO_AVG_TRWI_QTY,
													0 AS TMM_TRWI_QTY,
													0 AS BOD_TRWI_QTY,
													0 AS BOD_TRWI_QTY_INCL,
													0 AS TDD_PRDN_QTY,
													0 AS YER1_DLY_AVG_TRWI_QTY,
													ROUND(AVG(PRDN_TRWI_QTY)) AS MTH3_DLY_AVG_TRWI_QTY,
													0 AS WEK2_DLY_AVG_TRWI_QTY,
													0 AS TDD_PRDN_QTY2,
													0 AS TDD_PRDN_QTY3,
													0 AS WEK1_DLY_AVG_TRWI_QTY
									   		 FROM TB_PROD_MST_SUM_INFO A,
									   		      TB_VEHL_MGMT B
											 WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
											 AND A.MDL_MDY_CD = B.MDL_MDY_CD
											 AND B.DL_EXPD_CO_CD = EXPD_CO_CD
											 AND A.APL_YMD BETWEEN V_PREV_3MTH_YMD AND V_PREV_1MTH_YMD
                                 			 GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD
 
											 UNION ALL
											 
											 --당월 투입수량 조회 
											 SELECT MAX(A.DATA_SN) AS DATA_SN,
									   				A.QLTY_VEHL_CD,
													A.MDL_MDY_CD,
													A.LANG_CD, 
									   				0 AS MTH3_MO_AVG_TRWI_QTY, 
													SUM(A.PRDN_TRWI_QTY) AS TMM_TRWI_QTY,
													0 AS BOD_TRWI_QTY,
													0 AS BOD_TRWI_QTY_INCL,
													0 AS TDD_PRDN_QTY,
													0 AS YER1_DLY_AVG_TRWI_QTY,
													0 AS MTH3_DLY_AVG_TRWI_QTY,
													0 AS WEK2_DLY_AVG_TRWI_QTY,
													0 AS TDD_PRDN_QTY2,
													0 AS TDD_PRDN_QTY3,
													0 AS WEK1_DLY_AVG_TRWI_QTY
									   		 FROM TB_PROD_MST_SUM_INFO A,
									   		      TB_VEHL_MGMT B
											 WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
											 AND A.MDL_MDY_CD = B.MDL_MDY_CD
											 AND B.DL_EXPD_CO_CD = EXPD_CO_CD
											 AND A.APL_YMD BETWEEN V_CURR_FSTD_YMD AND SRCH_YMD
											 GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD
											 
											 UNION ALL
											 
											 --전일 투입수량 조회 
											 SELECT MAX(A.DATA_SN) AS DATA_SN,
									   				A.QLTY_VEHL_CD,
													A.MDL_MDY_CD,
													A.LANG_CD, 
									   				0 AS MTH3_MO_AVG_TRWI_QTY, 
													0 AS TMM_TRWI_QTY,
													SUM(A.PRDN_TRWI_QTY) AS BOD_TRWI_QTY,
													0 AS BOD_TRWI_QTY_INCL,
													0 AS TDD_PRDN_QTY,
													0 AS YER1_DLY_AVG_TRWI_QTY,
													0 AS MTH3_DLY_AVG_TRWI_QTY,
													0 AS WEK2_DLY_AVG_TRWI_QTY,
													0 AS TDD_PRDN_QTY2,
													0 AS TDD_PRDN_QTY3,
													0 AS WEK1_DLY_AVG_TRWI_QTY
									   		 FROM TB_PROD_MST_SUM_INFO A,
									   		      TB_VEHL_MGMT B
											 WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
											 AND A.MDL_MDY_CD = B.MDL_MDY_CD
											 AND B.DL_EXPD_CO_CD = EXPD_CO_CD
											 --영업일기준(토,일 제외) 전일에서 실제날짜의 전일까지의 수량을 합해서 표시해 준다.
											 AND A.APL_YMD BETWEEN V_PREV_1DAY_YMD2 AND V_PREV_1DAY_YMD1
											 GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD
											 
											 UNION ALL
											 
											  --휴일 포함 기준 계산한 전일 투입수량 조회 
                                             SELECT MAX(A.DATA_SN) AS DATA_SN,
                                                    A.QLTY_VEHL_CD,
                                                    A.MDL_MDY_CD,
                                                    A.LANG_CD, 
                                                    0 AS MTH3_MO_AVG_TRWI_QTY, 
                                                    0 AS TMM_TRWI_QTY,
                                                    0 AS BOD_TRWI_QTY,
                                                    SUM(A.PRDN_TRWI_QTY) AS BOD_TRWI_QTY_INCL,
                                                    0 AS TDD_PRDN_QTY,
                                                    0 AS YER1_DLY_AVG_TRWI_QTY,
                                                    0 AS MTH3_DLY_AVG_TRWI_QTY,
                                                    0 AS WEK2_DLY_AVG_TRWI_QTY,
                                                    0 AS TDD_PRDN_QTY2,
                                                    0 AS TDD_PRDN_QTY3,
                                                    0 AS WEK1_DLY_AVG_TRWI_QTY
                                             FROM TB_PROD_MST_SUM_INFO A,
                                                  TB_VEHL_MGMT B
                                             WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
                                             AND A.MDL_MDY_CD = B.MDL_MDY_CD
                                             AND B.DL_EXPD_CO_CD = EXPD_CO_CD
                                             --휴일 포함한 전일기준에서 실제날짜의 전일까지의 수량을 합해서 표시해 준다.
                                             AND A.APL_YMD BETWEEN V_PREV_1DAY_INCL_HLD_YMD2 AND V_PREV_1DAY_YMD1
                                             GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD
                                             
                                             UNION ALL
											 
											 --당일 생산(예정)수량 조회 
											 SELECT MAX(A.DATA_SN) AS DATA_SN,
									   				A.QLTY_VEHL_CD,
													A.MDL_MDY_CD,
													A.LANG_CD, 
									   				0 AS MTH3_MO_AVG_TRWI_QTY, 
													0 AS TMM_TRWI_QTY,
													0 AS BOD_TRWI_QTY,
													0 AS BOD_TRWI_QTY_INCL,
													SUM(A.PRDN_QTY) AS TDD_PRDN_QTY,
													0 AS YER1_DLY_AVG_TRWI_QTY,
													0 AS MTH3_DLY_AVG_TRWI_QTY,
													0 AS WEK2_DLY_AVG_TRWI_QTY,
													SUM(A.PRDN_QTY2) AS TDD_PRDN_QTY2,
													SUM(A.PRDN_QTY3) AS TDD_PRDN_QTY3,
													0 AS WEK1_DLY_AVG_TRWI_QTY
									   		 FROM TB_PROD_MST_SUM_INFO A,
									   		      TB_VEHL_MGMT B
											 WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
											 AND A.MDL_MDY_CD = B.MDL_MDY_CD
											 AND B.DL_EXPD_CO_CD = EXPD_CO_CD
											 AND A.APL_YMD = SRCH_YMD
											 GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD
											 
											 UNION ALL
											 
											 --1년 일평균 투입수량 조회 
											 SELECT MAX(A.DATA_SN) AS DATA_SN,
									   				A.QLTY_VEHL_CD,
													A.MDL_MDY_CD,
													A.LANG_CD, 
									   				0 AS MTH3_MO_AVG_TRWI_QTY, 
													0 AS TMM_TRWI_QTY,
													0 AS BOD_TRWI_QTY,
													0 AS BOD_TRWI_QTY_INCL,
													0 AS TDD_PRDN_QTY,
													ROUND(AVG(PRDN_TRWI_QTY) + 1.96 + STDDEV(PRDN_TRWI_QTY)) AS YER1_DLY_AVG_TRWI_QTY,
													0 AS MTH3_DLY_AVG_TRWI_QTY,
													0 AS WEK2_DLY_AVG_TRWI_QTY,
													0 AS TDD_PRDN_QTY2,
													0 AS TDD_PRDN_QTY3,
													0 AS WEK1_DLY_AVG_TRWI_QTY
									   		 FROM TB_PROD_MST_SUM_INFO A,
									   		      TB_VEHL_MGMT B
											 WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
											 AND A.MDL_MDY_CD = B.MDL_MDY_CD
											 AND B.DL_EXPD_CO_CD = EXPD_CO_CD
											 AND A.APL_YMD BETWEEN V_PREV_YEAR_YMD AND V_PREV_1MTH_YMD
											 GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD
											 
											 UNION ALL
											 
											 --2주 일평균 생산수량 조회 
											 SELECT MAX(A.DATA_SN) AS DATA_SN,
									   				A.QLTY_VEHL_CD,
													A.MDL_MDY_CD,
													A.LANG_CD, 
									   				0 AS MTH3_MO_AVG_TRWI_QTY, 
													0 AS TMM_TRWI_QTY,
													0 AS BOD_TRWI_QTY,
													0 AS BOD_TRWI_QTY_INCL,
													0 AS TDD_PRDN_QTY,
													0 AS YER1_DLY_AVG_TRWI_QTY,
													0 AS MTH3_DLY_AVG_TRWI_QTY,
													ROUND(AVG(PRDN_TRWI_QTY)) AS WEK2_DLY_AVG_TRWI_QTY,
													0 AS TDD_PRDN_QTY2,
													0 AS TDD_PRDN_QTY3,
													0 AS WEK1_DLY_AVG_TRWI_QTY
									   		 FROM TB_PROD_MST_SUM_INFO A,
									   		      TB_VEHL_MGMT B
											 WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
											 AND A.MDL_MDY_CD = B.MDL_MDY_CD
											 AND B.DL_EXPD_CO_CD = EXPD_CO_CD
											 AND A.APL_YMD BETWEEN V_PREV_2WEK_YMD AND V_PREV_1DAY_YMD1
											 GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD
											 
											 UNION ALL
											 
											 --1주 일평균 생산수량 조회 
											 SELECT MAX(A.DATA_SN) AS DATA_SN,
									   				A.QLTY_VEHL_CD,
													A.MDL_MDY_CD,
													A.LANG_CD, 
									   				0 AS MTH3_MO_AVG_TRWI_QTY, 
													0 AS TMM_TRWI_QTY,
													0 AS BOD_TRWI_QTY,
													0 AS BOD_TRWI_QTY_INCL,
													0 AS TDD_PRDN_QTY,
													0 AS YER1_DLY_AVG_TRWI_QTY,
													0 AS MTH3_DLY_AVG_TRWI_QTY,
													0 AS WEK2_DLY_AVG_TRWI_QTY,
													0 AS TDD_PRDN_QTY2,
													0 AS TDD_PRDN_QTY3,
													ROUND(AVG(PRDN_TRWI_QTY)) AS WEK1_DLY_AVG_TRWI_QTY
									   		 FROM TB_PROD_MST_SUM_INFO A,
									   		      TB_VEHL_MGMT B
											 WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
											 AND A.MDL_MDY_CD = B.MDL_MDY_CD
											 AND B.DL_EXPD_CO_CD = EXPD_CO_CD
											 AND A.APL_YMD BETWEEN V_PREV_1WEK_YMD AND V_PREV_1DAY_YMD1
											 GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD
											 
											) A
									   WHERE A.MTH3_MO_AVG_TRWI_QTY + A.TMM_TRWI_QTY + A.BOD_TRWI_QTY + A.BOD_TRWI_QTY_INCL +
									         A.TDD_PRDN_QTY + A.YER1_DLY_AVG_TRWI_QTY + A.MTH3_DLY_AVG_TRWI_QTY +
											 A.WEK2_DLY_AVG_TRWI_QTY + A.TDD_PRDN_QTY2 + A.TDD_PRDN_QTY3 + WEK1_DLY_AVG_TRWI_QTY > 0
									   GROUP BY QLTY_VEHL_CD, MDL_MDY_CD, LANG_CD;

									   
		 --[추가] 2010.04.14.김동근 생산정보 현황 - 공장별 Summary 내역 조회				   
		 CURSOR PLNT_MST_SUM_INFO IS SELECT MAX(DATA_SN) AS DATA_SN,
									   		QLTY_VEHL_CD,
											MDL_MDY_CD,
											LANG_CD, 
									   		SUM(MTH3_MO_AVG_TRWI_QTY) AS MTH3_MO_AVG_TRWI_QTY, 
											SUM(TMM_TRWI_QTY) AS TMM_TRWI_QTY,
											SUM(BOD_TRWI_QTY) AS BOD_TRWI_QTY,
											SUM(BOD_TRWI_QTY_INCL) AS BOD_TRWI_QTY_INCL,
											SUM(TDD_PRDN_QTY) AS TDD_PRDN_QTY,
											SUM(YER1_DLY_AVG_TRWI_QTY) AS YER1_DLY_AVG_TRWI_QTY,
											SUM(MTH3_DLY_AVG_TRWI_QTY) AS MTH3_DLY_AVG_TRWI_QTY,
											SUM(WEK2_DLY_AVG_TRWI_QTY) AS WEK2_DLY_AVG_TRWI_QTY,
											SUM(TDD_PRDN_QTY2) AS TDD_PRDN_QTY2,
											SUM(TDD_PRDN_QTY3) AS TDD_PRDN_QTY3,
											SUM(WEK1_DLY_AVG_TRWI_QTY) AS WEK1_DLY_AVG_TRWI_QTY,
											PRDN_PLNT_CD
				   					 FROM (
									   	     --3개월 월평균 투입수량, 3개월 일평균 투입수량 조회 
									   	     SELECT MAX(A.DATA_SN) AS DATA_SN,
									   			    A.QLTY_VEHL_CD,
												    A.MDL_MDY_CD,
												    A.LANG_CD, 
									   				ROUND(SUM(A.PRDN_TRWI_QTY) / 3) AS MTH3_MO_AVG_TRWI_QTY,
													0 AS TMM_TRWI_QTY,
													0 AS BOD_TRWI_QTY,
													0 AS BOD_TRWI_QTY_INCL,
													0 AS TDD_PRDN_QTY,
													0 AS YER1_DLY_AVG_TRWI_QTY,
													ROUND(AVG(PRDN_TRWI_QTY)) AS MTH3_DLY_AVG_TRWI_QTY,
													0 AS WEK2_DLY_AVG_TRWI_QTY,
													0 AS TDD_PRDN_QTY2,
													0 AS TDD_PRDN_QTY3,
													0 AS WEK1_DLY_AVG_TRWI_QTY,
													A.PRDN_PLNT_CD
									   		 FROM TB_PLNT_PROD_MST_SUM_INFO A,
									   		      TB_VEHL_MGMT B
											 WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
											 AND A.MDL_MDY_CD = B.MDL_MDY_CD
											 AND B.DL_EXPD_CO_CD = EXPD_CO_CD
											 AND A.APL_YMD BETWEEN V_PREV_3MTH_YMD AND V_PREV_1MTH_YMD
                                 			 GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD, A.PRDN_PLNT_CD
 
											 UNION ALL
											 
											 --당월 투입수량 조회 
											 SELECT MAX(A.DATA_SN) AS DATA_SN,
									   				A.QLTY_VEHL_CD,
													A.MDL_MDY_CD,
													A.LANG_CD, 
									   				0 AS MTH3_MO_AVG_TRWI_QTY, 
													SUM(A.PRDN_TRWI_QTY) AS TMM_TRWI_QTY,
													0 AS BOD_TRWI_QTY,
												    0 AS BOD_TRWI_QTY_INCL,
													0 AS TDD_PRDN_QTY,
													0 AS YER1_DLY_AVG_TRWI_QTY,
													0 AS MTH3_DLY_AVG_TRWI_QTY,
													0 AS WEK2_DLY_AVG_TRWI_QTY,
													0 AS TDD_PRDN_QTY2,
													0 AS TDD_PRDN_QTY3,
													0 AS WEK1_DLY_AVG_TRWI_QTY,
													A.PRDN_PLNT_CD
									   		 FROM TB_PLNT_PROD_MST_SUM_INFO A,
									   		      TB_VEHL_MGMT B
											 WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
											 AND A.MDL_MDY_CD = B.MDL_MDY_CD
											 AND B.DL_EXPD_CO_CD = EXPD_CO_CD
											 AND A.APL_YMD BETWEEN V_CURR_FSTD_YMD AND SRCH_YMD
											 GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD, A.PRDN_PLNT_CD
											 
											 UNION ALL
											 
											 --전일 투입수량 조회 
											 SELECT MAX(A.DATA_SN) AS DATA_SN,
									   				A.QLTY_VEHL_CD,
													A.MDL_MDY_CD,
													A.LANG_CD, 
									   				0 AS MTH3_MO_AVG_TRWI_QTY, 
													0 AS TMM_TRWI_QTY,
													SUM(A.PRDN_TRWI_QTY) AS BOD_TRWI_QTY,
												    0 AS BOD_TRWI_QTY_INCL,
													0 AS TDD_PRDN_QTY,
													0 AS YER1_DLY_AVG_TRWI_QTY,
													0 AS MTH3_DLY_AVG_TRWI_QTY,
													0 AS WEK2_DLY_AVG_TRWI_QTY,
													0 AS TDD_PRDN_QTY2,
													0 AS TDD_PRDN_QTY3,
													0 AS WEK1_DLY_AVG_TRWI_QTY,
													A.PRDN_PLNT_CD
									   		 FROM TB_PLNT_PROD_MST_SUM_INFO A,
									   		      TB_VEHL_MGMT B
											 WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
											 AND A.MDL_MDY_CD = B.MDL_MDY_CD
											 AND B.DL_EXPD_CO_CD = EXPD_CO_CD
											    --영업일기준(토,일 제외) 전일에서 실제날짜의 전일까지의 수량을 합해서 표시해 준다.
                                             AND A.APL_YMD BETWEEN V_PREV_1DAY_YMD2 AND V_PREV_1DAY_YMD1
											 GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD, A.PRDN_PLNT_CD
											 
											 UNION ALL
											 
                                              --휴일 포함 기준 계산한 전일 투입수량 조회 
                                             SELECT MAX(A.DATA_SN) AS DATA_SN,
                                                    A.QLTY_VEHL_CD,
                                                    A.MDL_MDY_CD,
                                                    A.LANG_CD, 
                                                    0 AS MTH3_MO_AVG_TRWI_QTY, 
                                                    0 AS TMM_TRWI_QTY,
                                                    0 AS BOD_TRWI_QTY,
                                                    SUM(A.PRDN_TRWI_QTY) AS BOD_TRWI_QTY_INCL,
                                                    0 AS TDD_PRDN_QTY,
                                                    0 AS YER1_DLY_AVG_TRWI_QTY,
                                                    0 AS MTH3_DLY_AVG_TRWI_QTY,
                                                    0 AS WEK2_DLY_AVG_TRWI_QTY,
                                                    0 AS TDD_PRDN_QTY2,
                                                    0 AS TDD_PRDN_QTY3,
                                                    0 AS WEK1_DLY_AVG_TRWI_QTY,
                                                    A.PRDN_PLNT_CD
                                             FROM TB_PLNT_PROD_MST_SUM_INFO A,
                                                  TB_VEHL_MGMT B
                                             WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
                                             AND A.MDL_MDY_CD = B.MDL_MDY_CD
                                             AND B.DL_EXPD_CO_CD = EXPD_CO_CD
                                                 --휴일 포함한 전일기준에서 실제날짜의 전일까지의 수량을 합해서 표시해 준다.                                             
                                             AND A.APL_YMD BETWEEN V_PREV_1DAY_INCL_HLD_YMD2 AND V_PREV_1DAY_YMD1
                                             GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD, A.PRDN_PLNT_CD
                                             
                                             UNION ALL
											 
											 --당일 생산(예정)수량 조회 
											 SELECT MAX(A.DATA_SN) AS DATA_SN,
									   				A.QLTY_VEHL_CD,
													A.MDL_MDY_CD,
													A.LANG_CD, 
									   				0 AS MTH3_MO_AVG_TRWI_QTY, 
													0 AS TMM_TRWI_QTY,
													0 AS BOD_TRWI_QTY,
												    0 AS BOD_TRWI_QTY_INCL,
													SUM(A.PRDN_QTY) AS TDD_PRDN_QTY,
													0 AS YER1_DLY_AVG_TRWI_QTY,
													0 AS MTH3_DLY_AVG_TRWI_QTY,
													0 AS WEK2_DLY_AVG_TRWI_QTY,
													SUM(A.PRDN_QTY2) AS TDD_PRDN_QTY2,
													SUM(A.PRDN_QTY3) AS TDD_PRDN_QTY3,
													0 AS WEK1_DLY_AVG_TRWI_QTY,
													A.PRDN_PLNT_CD
									   		 FROM TB_PLNT_PROD_MST_SUM_INFO A,
									   		      TB_VEHL_MGMT B
											 WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
											 AND A.MDL_MDY_CD = B.MDL_MDY_CD
											 AND B.DL_EXPD_CO_CD = EXPD_CO_CD
											 AND A.APL_YMD = SRCH_YMD
											 GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD, A.PRDN_PLNT_CD
											 
											 UNION ALL
											 
											 --1년 일평균 투입수량 조회 
											 SELECT MAX(A.DATA_SN) AS DATA_SN,
									   				A.QLTY_VEHL_CD,
													A.MDL_MDY_CD,
													A.LANG_CD, 
									   				0 AS MTH3_MO_AVG_TRWI_QTY, 
													0 AS TMM_TRWI_QTY,
													0 AS BOD_TRWI_QTY,
												    0 AS BOD_TRWI_QTY_INCL,
													0 AS TDD_PRDN_QTY,
													ROUND(AVG(PRDN_TRWI_QTY) + 1.96 + STDDEV(PRDN_TRWI_QTY)) AS YER1_DLY_AVG_TRWI_QTY,
													0 AS MTH3_DLY_AVG_TRWI_QTY,
													0 AS WEK2_DLY_AVG_TRWI_QTY,
													0 AS TDD_PRDN_QTY2,
													0 AS TDD_PRDN_QTY3,
													0 AS WEK1_DLY_AVG_TRWI_QTY,
													A.PRDN_PLNT_CD
									   		 FROM TB_PLNT_PROD_MST_SUM_INFO A,
									   		      TB_VEHL_MGMT B
											 WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
											 AND A.MDL_MDY_CD = B.MDL_MDY_CD
											 AND B.DL_EXPD_CO_CD = EXPD_CO_CD
											 AND A.APL_YMD BETWEEN V_PREV_YEAR_YMD AND V_PREV_1MTH_YMD
											 GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD, A.PRDN_PLNT_CD
											 
											 UNION ALL
											 
											 --2주 일평균 생산수량 조회 
											 SELECT MAX(A.DATA_SN) AS DATA_SN,
									   				A.QLTY_VEHL_CD,
													A.MDL_MDY_CD,
													A.LANG_CD, 
									   				0 AS MTH3_MO_AVG_TRWI_QTY, 
													0 AS TMM_TRWI_QTY,
													0 AS BOD_TRWI_QTY,
												    0 AS BOD_TRWI_QTY_INCL,
													0 AS TDD_PRDN_QTY,
													0 AS YER1_DLY_AVG_TRWI_QTY,
													0 AS MTH3_DLY_AVG_TRWI_QTY,
													ROUND(AVG(PRDN_TRWI_QTY)) AS WEK2_DLY_AVG_TRWI_QTY,
													0 AS TDD_PRDN_QTY2,
													0 AS TDD_PRDN_QTY3,
													0 AS WEK1_DLY_AVG_TRWI_QTY,
													A.PRDN_PLNT_CD
									   		 FROM TB_PLNT_PROD_MST_SUM_INFO A,
									   		      TB_VEHL_MGMT B
											 WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
											 AND A.MDL_MDY_CD = B.MDL_MDY_CD
											 AND B.DL_EXPD_CO_CD = EXPD_CO_CD
											 AND A.APL_YMD BETWEEN V_PREV_2WEK_YMD AND V_PREV_1DAY_YMD1
											 GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD, A.PRDN_PLNT_CD
											 
											 UNION ALL
											 
											 --1주 일평균 생산수량 조회 
											 SELECT MAX(A.DATA_SN) AS DATA_SN,
									   				A.QLTY_VEHL_CD,
													A.MDL_MDY_CD,
													A.LANG_CD, 
									   				0 AS MTH3_MO_AVG_TRWI_QTY, 
													0 AS TMM_TRWI_QTY,
													0 AS BOD_TRWI_QTY,
												    0 AS BOD_TRWI_QTY_INCL,
													0 AS TDD_PRDN_QTY,
													0 AS YER1_DLY_AVG_TRWI_QTY,
													0 AS MTH3_DLY_AVG_TRWI_QTY,
													0 AS WEK2_DLY_AVG_TRWI_QTY,
													0 AS TDD_PRDN_QTY2,
													0 AS TDD_PRDN_QTY3,
													ROUND(AVG(PRDN_TRWI_QTY)) AS WEK1_DLY_AVG_TRWI_QTY,
													A.PRDN_PLNT_CD
									   		 FROM TB_PLNT_PROD_MST_SUM_INFO A,
									   		      TB_VEHL_MGMT B
											 WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
											 AND A.MDL_MDY_CD = B.MDL_MDY_CD
											 AND B.DL_EXPD_CO_CD = EXPD_CO_CD
											 AND A.APL_YMD BETWEEN V_PREV_1WEK_YMD AND V_PREV_1DAY_YMD1
											 GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD, A.PRDN_PLNT_CD
											 
											) A
									   WHERE A.MTH3_MO_AVG_TRWI_QTY + A.TMM_TRWI_QTY + A.BOD_TRWI_QTY + A.BOD_TRWI_QTY_INCL +
									         A.TDD_PRDN_QTY + A.YER1_DLY_AVG_TRWI_QTY + A.MTH3_DLY_AVG_TRWI_QTY +
											 A.WEK2_DLY_AVG_TRWI_QTY + A.TDD_PRDN_QTY2 + A.TDD_PRDN_QTY3 + WEK1_DLY_AVG_TRWI_QTY > 0
									   GROUP BY QLTY_VEHL_CD, MDL_MDY_CD, LANG_CD, PRDN_PLNT_CD;
									   
	   BEGIN
	   		
			--이미 입력되었던 항목이 있다면 초기화 해준 후 진행한다. 
			--[참고] 회사구분이 존재하지 않으므로 아래와 같이 차종이 회사에 소속된 내역만을 삭제해 주어야 한다. 
			UPDATE TB_APS_PROD_SUM_INFO A
			SET MTH3_MO_AVG_TRWI_QTY = 0,
			    TMM_TRWI_QTY = 0,
				BOD_TRWI_QTY = 0,
				TDD_PRDN_QTY = 0,
				YER1_DLY_AVG_TRWI_QTY = 0,
				MTH3_DLY_AVG_TRWI_QTY = 0,
				WEK2_DLY_AVG_TRWI_QTY = 0,
				TDD_PRDN_QTY2 = 0,
				TDD_PRDN_QTY3 = 0,
				WEK1_DLY_AVG_TRWI_QTY = 0,
				MDFY_DTM = SYSDATE
			WHERE APL_YMD = CURR_YMD
			AND EXISTS (SELECT 'EXIST'
                        FROM TB_VEHL_MGMT
			            WHERE QLTY_VEHL_CD = A.QLTY_VEHL_CD
			            AND DL_EXPD_CO_CD = EXPD_CO_CD
		                AND ROWNUM <= 1
		               );
			
			--[추가] 2010.04.14.김동근 생산정보 현황 - 공장별 Summary 내역 초기화  
			UPDATE TB_PLNT_APS_PROD_SUM_INFO A
			SET MTH3_MO_AVG_TRWI_QTY = 0,
			    TMM_TRWI_QTY = 0,
				BOD_TRWI_QTY = 0,
				TDD_PRDN_QTY = 0,
				YER1_DLY_AVG_TRWI_QTY = 0,
				MTH3_DLY_AVG_TRWI_QTY = 0,
				WEK2_DLY_AVG_TRWI_QTY = 0,
				TDD_PRDN_QTY2 = 0,
				TDD_PRDN_QTY3 = 0,
				WEK1_DLY_AVG_TRWI_QTY = 0,
				MDFY_DTM = SYSDATE
			WHERE APL_YMD = CURR_YMD
			AND EXISTS (SELECT 'EXIST'
                        FROM TB_VEHL_MGMT
			            WHERE QLTY_VEHL_CD = A.QLTY_VEHL_CD
			            AND DL_EXPD_CO_CD = EXPD_CO_CD
		                AND ROWNUM <= 1
		               );
			
			FOR PROD_MST_SUM_LIST IN PROD_MST_SUM_INFO LOOP
			
			
				UPDATE TB_APS_PROD_SUM_INFO
				SET MTH3_MO_AVG_TRWI_QTY = PROD_MST_SUM_LIST.MTH3_MO_AVG_TRWI_QTY,
				    TMM_TRWI_QTY = PROD_MST_SUM_LIST.TMM_TRWI_QTY,
					BOD_TRWI_QTY = CASE 
					               WHEN PROD_MST_SUM_LIST.BOD_TRWI_QTY_INCL > 0 THEN PROD_MST_SUM_LIST.BOD_TRWI_QTY_INCL
                                   ELSE PROD_MST_SUM_LIST.BOD_TRWI_QTY 
                                   END,
					TDD_PRDN_QTY = PROD_MST_SUM_LIST.TDD_PRDN_QTY,
					YER1_DLY_AVG_TRWI_QTY = PROD_MST_SUM_LIST.YER1_DLY_AVG_TRWI_QTY,
					MTH3_DLY_AVG_TRWI_QTY = PROD_MST_SUM_LIST.MTH3_DLY_AVG_TRWI_QTY,
					WEK2_DLY_AVG_TRWI_QTY = PROD_MST_SUM_LIST.WEK2_DLY_AVG_TRWI_QTY,
					TDD_PRDN_QTY2 = PROD_MST_SUM_LIST.TDD_PRDN_QTY2,
					TDD_PRDN_QTY3 = PROD_MST_SUM_LIST.TDD_PRDN_QTY3,
					WEK1_DLY_AVG_TRWI_QTY = PROD_MST_SUM_LIST.WEK1_DLY_AVG_TRWI_QTY,
					MDFY_DTM = SYSDATE
				WHERE APL_YMD = CURR_YMD
				AND DATA_SN = PROD_MST_SUM_LIST.DATA_SN;
				
				IF SQL%NOTFOUND THEN
				   
				   UPDATE TB_APS_PROD_SUM_INFO
					SET DATA_SN = PROD_MST_SUM_LIST.DATA_SN,
						MTH3_MO_AVG_TRWI_QTY = PROD_MST_SUM_LIST.MTH3_MO_AVG_TRWI_QTY,
					    TMM_TRWI_QTY = PROD_MST_SUM_LIST.TMM_TRWI_QTY,
                        BOD_TRWI_QTY = CASE 
                                       WHEN PROD_MST_SUM_LIST.BOD_TRWI_QTY_INCL > 0 THEN PROD_MST_SUM_LIST.BOD_TRWI_QTY_INCL
                                       ELSE PROD_MST_SUM_LIST.BOD_TRWI_QTY 
                                       END,
						TDD_PRDN_QTY = PROD_MST_SUM_LIST.TDD_PRDN_QTY,
						YER1_DLY_AVG_TRWI_QTY = PROD_MST_SUM_LIST.YER1_DLY_AVG_TRWI_QTY,
						MTH3_DLY_AVG_TRWI_QTY = PROD_MST_SUM_LIST.MTH3_DLY_AVG_TRWI_QTY,
						WEK2_DLY_AVG_TRWI_QTY = PROD_MST_SUM_LIST.WEK2_DLY_AVG_TRWI_QTY,
						TDD_PRDN_QTY2 = PROD_MST_SUM_LIST.TDD_PRDN_QTY2,
						TDD_PRDN_QTY3 = PROD_MST_SUM_LIST.TDD_PRDN_QTY3,
						WEK1_DLY_AVG_TRWI_QTY = PROD_MST_SUM_LIST.WEK1_DLY_AVG_TRWI_QTY,
						MDFY_DTM = SYSDATE
					WHERE APL_YMD = CURR_YMD
						AND QLTY_VEHL_CD = PROD_MST_SUM_LIST.QLTY_VEHL_CD
						AND MDL_MDY_CD = PROD_MST_SUM_LIST.MDL_MDY_CD
						AND LANG_CD = PROD_MST_SUM_LIST.LANG_CD;
	
					IF SQL%NOTFOUND THEN
	
					   INSERT INTO TB_APS_PROD_SUM_INFO
					   (APL_YMD,
					    DATA_SN,
						QLTY_VEHL_CD,
						MDL_MDY_CD,
						LANG_CD,
						MTH3_MO_AVG_TRWI_QTY,
						TMM_TRWI_QTY,
						BOD_TRWI_QTY,
						TDD_PRDN_QTY,
						YER1_DLY_AVG_TRWI_QTY,
						MTH3_DLY_AVG_TRWI_QTY,
						WEK2_DLY_AVG_TRWI_QTY,
						FRAM_DTM,
						MDFY_DTM,
						TDD_PRDN_QTY2,
						TDD_PRDN_QTY3,
						WEK1_DLY_AVG_TRWI_QTY
					   )
					   VALUES
					   (CURR_YMD,
					    PROD_MST_SUM_LIST.DATA_SN,
						PROD_MST_SUM_LIST.QLTY_VEHL_CD,
						PROD_MST_SUM_LIST.MDL_MDY_CD,
						PROD_MST_SUM_LIST.LANG_CD,
						PROD_MST_SUM_LIST.MTH3_MO_AVG_TRWI_QTY,
						PROD_MST_SUM_LIST.TMM_TRWI_QTY,
						CASE 
                                   WHEN PROD_MST_SUM_LIST.BOD_TRWI_QTY_INCL > 0 THEN PROD_MST_SUM_LIST.BOD_TRWI_QTY_INCL
                                   ELSE PROD_MST_SUM_LIST.BOD_TRWI_QTY 
                                   END,
						PROD_MST_SUM_LIST.TDD_PRDN_QTY,
						PROD_MST_SUM_LIST.YER1_DLY_AVG_TRWI_QTY,
						PROD_MST_SUM_LIST.MTH3_DLY_AVG_TRWI_QTY,
						PROD_MST_SUM_LIST.WEK2_DLY_AVG_TRWI_QTY,
						SYSDATE,
						SYSDATE,
						PROD_MST_SUM_LIST.TDD_PRDN_QTY2,
						PROD_MST_SUM_LIST.TDD_PRDN_QTY3,
						PROD_MST_SUM_LIST.WEK1_DLY_AVG_TRWI_QTY
					   );
	
					END IF;
				   
				END IF;
				
			END LOOP;
			
			--[추가] 2010.04.14.김동근 생산정보 현황 - 공장별 Summary 내역 저장 기능 추가 
			FOR PLNT_MST_SUM_LIST IN PLNT_MST_SUM_INFO LOOP
				
				UPDATE TB_PLNT_APS_PROD_SUM_INFO
				SET MTH3_MO_AVG_TRWI_QTY = PLNT_MST_SUM_LIST.MTH3_MO_AVG_TRWI_QTY,
				    TMM_TRWI_QTY = PLNT_MST_SUM_LIST.TMM_TRWI_QTY,
                    BOD_TRWI_QTY = CASE 
                                   WHEN PLNT_MST_SUM_LIST.BOD_TRWI_QTY_INCL > 0 THEN PLNT_MST_SUM_LIST.BOD_TRWI_QTY_INCL
                                   ELSE PLNT_MST_SUM_LIST.BOD_TRWI_QTY 
                                   END,					
                    TDD_PRDN_QTY = PLNT_MST_SUM_LIST.TDD_PRDN_QTY,
					YER1_DLY_AVG_TRWI_QTY = PLNT_MST_SUM_LIST.YER1_DLY_AVG_TRWI_QTY,
					MTH3_DLY_AVG_TRWI_QTY = PLNT_MST_SUM_LIST.MTH3_DLY_AVG_TRWI_QTY,
					WEK2_DLY_AVG_TRWI_QTY = PLNT_MST_SUM_LIST.WEK2_DLY_AVG_TRWI_QTY,
					TDD_PRDN_QTY2 = PLNT_MST_SUM_LIST.TDD_PRDN_QTY2,
					TDD_PRDN_QTY3 = PLNT_MST_SUM_LIST.TDD_PRDN_QTY3,
					WEK1_DLY_AVG_TRWI_QTY = PLNT_MST_SUM_LIST.WEK1_DLY_AVG_TRWI_QTY,
					MDFY_DTM = SYSDATE
				WHERE APL_YMD = CURR_YMD
				AND DATA_SN = PLNT_MST_SUM_LIST.DATA_SN
				AND PRDN_PLNT_CD = PLNT_MST_SUM_LIST.PRDN_PLNT_CD;
				
				IF SQL%NOTFOUND THEN
				   
				   INSERT INTO TB_PLNT_APS_PROD_SUM_INFO
				   (APL_YMD,
				    DATA_SN,
					QLTY_VEHL_CD,
					MDL_MDY_CD,
					LANG_CD,
					MTH3_MO_AVG_TRWI_QTY,
					TMM_TRWI_QTY,
					BOD_TRWI_QTY,
					TDD_PRDN_QTY,
					YER1_DLY_AVG_TRWI_QTY,
					MTH3_DLY_AVG_TRWI_QTY,
					WEK2_DLY_AVG_TRWI_QTY,
					FRAM_DTM,
					MDFY_DTM,
					TDD_PRDN_QTY2,
					TDD_PRDN_QTY3,
					WEK1_DLY_AVG_TRWI_QTY,
					PRDN_PLNT_CD
				   )
				   VALUES
				   (CURR_YMD,
				    PLNT_MST_SUM_LIST.DATA_SN,
					PLNT_MST_SUM_LIST.QLTY_VEHL_CD,
					PLNT_MST_SUM_LIST.MDL_MDY_CD,
					PLNT_MST_SUM_LIST.LANG_CD,
					PLNT_MST_SUM_LIST.MTH3_MO_AVG_TRWI_QTY,
					PLNT_MST_SUM_LIST.TMM_TRWI_QTY,
                    CASE 
                                   WHEN PLNT_MST_SUM_LIST.BOD_TRWI_QTY_INCL > 0 THEN PLNT_MST_SUM_LIST.BOD_TRWI_QTY_INCL
                                   ELSE PLNT_MST_SUM_LIST.BOD_TRWI_QTY 
                                   END,					
                    PLNT_MST_SUM_LIST.TDD_PRDN_QTY,
					PLNT_MST_SUM_LIST.YER1_DLY_AVG_TRWI_QTY,
					PLNT_MST_SUM_LIST.MTH3_DLY_AVG_TRWI_QTY,
					PLNT_MST_SUM_LIST.WEK2_DLY_AVG_TRWI_QTY,
					SYSDATE,
					SYSDATE,
					PLNT_MST_SUM_LIST.TDD_PRDN_QTY2,
					PLNT_MST_SUM_LIST.TDD_PRDN_QTY3,
					PLNT_MST_SUM_LIST.WEK1_DLY_AVG_TRWI_QTY,
					PLNT_MST_SUM_LIST.PRDN_PLNT_CD
				   );
				   
				END IF;
				
			END LOOP;
				 
	   END GET_PROD_MST_SUM_DTL;					  	  
/**********************************************************/
/**********************************************************/	   

	   --배치결과 정보 존재 여부 조회
	   FUNCTION GET_BTCH_FNH_YN(CURR_YMD   IN VARCHAR2,
	                            EXPD_CO_CD IN VARCHAR2,
	                            P_ET_GUBN_CD IN VARCHAR2)RETURN VARCHAR2
	   IS

		 V_BTCH_YMD VARCHAR2(8);
		 V_STATE    VARCHAR2(1);
	     V_AFFR_SCN_CD VARCHAR2(2);

	   BEGIN

			IF P_ET_GUBN_CD = '01' THEN
 			   -- 당일 인터페이스
               V_AFFR_SCN_CD := '04';
			ELSE
			   -- 전일 인터페이스
               V_AFFR_SCN_CD := '03';
			END IF;

			SELECT MAX(BTCH_FNH_YMD)
			  INTO V_BTCH_YMD
			  FROM TB_BATCH_FNH_INFO
			 WHERE AFFR_SCN_CD = V_AFFR_SCN_CD
			   AND DL_EXPD_CO_CD = EXPD_CO_CD
			   AND BTCH_FNH_YMD = CURR_YMD;

			IF V_BTCH_YMD IS NULL THEN

			   V_STATE := 'N';

			ELSIF CURR_YMD = V_BTCH_YMD THEN

			   V_STATE := 'Y';

			ELSE

			   V_STATE := 'N';

			END IF;

			RETURN V_STATE;

	   END GET_BTCH_FNH_YN;

/**********************************************************/
/**********************************************************/
	   --인터페이스 성공시에 완료일자를 저장
	   PROCEDURE SAVE_PROD_MST_BTCH_FNH_INFO(CURR_YMD   IN VARCHAR2,
	                                         EXPD_CO_CD IN VARCHAR2,
	                                         P_ET_GUBN_CD IN VARCHAR2)
	   IS
	     V_AFFR_SCN_CD VARCHAR2(2);
	   BEGIN

			V_AFFR_SCN_CD := '03';

			IF P_ET_GUBN_CD = '01' THEN
 			   -- 당일 인터페이스 성공시
               V_AFFR_SCN_CD := '04';
			END IF;

				INSERT INTO TB_BATCH_FNH_INFO
				(
				 AFFR_SCN_CD,
				 DL_EXPD_CO_CD,
				 BTCH_FNH_YMD,
				 FRAM_DTM
				)
				VALUES
				(
				 V_AFFR_SCN_CD,
				 EXPD_CO_CD,
				 CURR_YMD,
				 SYSDATE
				);

	   END SAVE_PROD_MST_BTCH_FNH_INFO;
/**********************************************************/
	   	   
END PG_INTERFACE_PROD_MST;