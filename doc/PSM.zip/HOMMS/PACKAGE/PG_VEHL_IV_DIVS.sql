CREATE OR REPLACE PACKAGE PG_VEHL_IV_DIVS AS
	   
	   TYPE REFCUR IS REF CURSOR;
	   
	   --세화 재고 전환 내역 조회 
	   PROCEDURE SP_GET_SEWHA_DIVS_INFO(P_MENU_ID 	   VARCHAR2,
								        P_USER_EENO    VARCHAR2,
	   			 						P_DATA_SN_LIST VARCHAR2,
			  						    P_CURR_YMD     VARCHAR2,
			  						    RS OUT REFCUR);
										
	   PROCEDURE SP_SEWHA_DIVS_INFO_SAVE(P_VEHL_CD              VARCHAR2,
	   			 				         P_MDL_MDY_CD	        VARCHAR2,
								         P_LANG_CD              VARCHAR2,
										 P_EXPD_MDL_MDY_CD      VARCHAR2,
								         P_N_PRNT_PBCN_NO       VARCHAR2,
								         P_WHOT_YMD             VARCHAR2,
								         P_EXPD_RQ_SCN_CD       VARCHAR2,
								         P_RQ_QTY		   		NUMBER,
										 P_DIVS_VEHL_CD	        VARCHAR2,
										 P_DIVS_EXPD_MDL_MDY_CD VARCHAR2,
										 P_DIVS_LANG_CD			VARCHAR2,
								         P_USER_EENO	        VARCHAR2,
										 P_PRTL_IMTR_SBC        VARCHAR2);
										 
	   PROCEDURE SP_SEWHA_DIVS_INFO_DELETE(P_VEHL_CD              VARCHAR2,
	   			 				           P_MDL_MDY_CD	          VARCHAR2,
								           P_LANG_CD              VARCHAR2,
										   P_EXPD_MDL_MDY_CD      VARCHAR2,
								           P_N_PRNT_PBCN_NO       VARCHAR2,
								           P_WHOT_YMD             VARCHAR2,
								           P_EXPD_RQ_SCN_CD       VARCHAR2,
								           P_RQ_QTY		   		  NUMBER,
										   P_DIVS_VEHL_CD	      VARCHAR2,
										   P_DIVS_EXPD_MDL_MDY_CD VARCHAR2,
										   P_DIVS_LANG_CD		  VARCHAR2,
								           P_USER_EENO	          VARCHAR2,
										   P_PRTL_IMTR_SBC        VARCHAR2);
										   
										   
	   --PDI 재고 전환 내역 조회 
	   PROCEDURE SP_GET_PDI_DIVS_INFO(P_MENU_ID 	 VARCHAR2,
								      P_USER_EENO    VARCHAR2,
	   			 					  P_DATA_SN_LIST VARCHAR2,
			  						  P_CURR_YMD     VARCHAR2,
			  						  RS OUT REFCUR);
									  
	   PROCEDURE SP_PDI_DIVS_INFO_SAVE(P_VEHL_CD              VARCHAR2,
	   			 				       P_MDL_MDY_CD	          VARCHAR2,
								       P_LANG_CD              VARCHAR2,
									   P_EXPD_MDL_MDY_CD      VARCHAR2,
								       P_N_PRNT_PBCN_NO       VARCHAR2,
								       P_WHOT_YMD             VARCHAR2,
								       P_EXPD_RQ_SCN_CD       VARCHAR2,
								       P_RQ_QTY		   		  NUMBER,
									   P_DIVS_VEHL_CD	      VARCHAR2,
									   P_DIVS_EXPD_MDL_MDY_CD VARCHAR2,
									   P_DIVS_LANG_CD		  VARCHAR2,
								       P_USER_EENO	          VARCHAR2,
									   P_PRTL_IMTR_SBC        VARCHAR2);
									   
	   PROCEDURE SP_PDI_DIVS_INFO_DELETE(P_VEHL_CD              VARCHAR2,
	   			 				         P_MDL_MDY_CD	        VARCHAR2,
								         P_LANG_CD              VARCHAR2,
										 P_EXPD_MDL_MDY_CD      VARCHAR2,
								         P_N_PRNT_PBCN_NO       VARCHAR2,
								         P_WHOT_YMD             VARCHAR2,
								         P_EXPD_RQ_SCN_CD       VARCHAR2,
								         P_RQ_QTY		   		NUMBER,
										 P_DIVS_VEHL_CD	        VARCHAR2,
										 P_DIVS_EXPD_MDL_MDY_CD VARCHAR2,
										 P_DIVS_LANG_CD		    VARCHAR2,
								         P_USER_EENO	        VARCHAR2,
										 P_PRTL_IMTR_SBC        VARCHAR2);
	   
END PG_VEHL_IV_DIVS;