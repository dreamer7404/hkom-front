CREATE OR REPLACE PACKAGE PG_PRNT_PAGE_MGMT AS
 TYPE REFCUR IS REF CURSOR; 
 
  /** 인쇄페이지 관리 */
  -- 인쇄페이지 관리 입력
  PROCEDURE SP_INSERT(P_N_PRNT_PBCN_NO IN VARCHAR2,
                      P_QLTY_VEHL_CD   IN VARCHAR2,
                      P_MDL_MDY_CD     IN VARCHAR2,
                      P_LANG_CD        IN VARCHAR2,
                      P_RGST_YMD       IN VARCHAR2,
                      P_DEPPC1_SN      IN NUMBER,
                      P_END_PG_SN      IN NUMBER,
                      P_PPRR_EENO      IN VARCHAR2,
                      P_UPDR_EENO      IN VARCHAR2,
                      P_LRNK_CD        IN VARCHAR2);
                     
   /**					  
   --인쇄페이지관리 리스트 조회
   PROCEDURE SP_PRNT_PAGE_MGMT(P_DL_EXPD_PRVS_CD    IN VARCHAR2,
                               P_DL_EXPD_PAC_SCN_CD IN VARCHAR2,
                               P_DL_EXPD_PDI_CD     IN VARCHAR2,
                               P_UPDR_EENO          IN VARCHAR2,
                               RS OUT REFCUR);  
   **/
							   
   --인쇄페이지관리 리스트 조회2 
   PROCEDURE SP_PRNT_PAGE_MGMT2(P_MENU_ID 	       IN VARCHAR2,
								P_USER_EENO 	   IN VARCHAR2,
   			 					P_QLTY_VEHL_CD     IN VARCHAR2,
                                P_MDL_MDY_CD       IN VARCHAR2,
                                P_DL_EXPD_REGN_CD  IN VARCHAR2, 
                                P_LANG_CD          IN VARCHAR2,
                                RS OUT REFCUR);  
                          
   -- 인쇄페이지관리 수정내용조회
   PROCEDURE SP_UPDATE_VIEW(P_N_PRNT_PBCN_NO IN VARCHAR2,
                            P_LRNK_CD        IN VARCHAR2,
                            RS OUT REFCUR);
                          
   -- 인쇄페이지관리 삭제
   PROCEDURE SP_DELETE(P_N_PRNT_PBCN_NO IN VARCHAR2,
                       P_LRNK_CD        IN VARCHAR2);
                      
   /** 인쇄배열표 */                     
   -- 인쇄발간번호로 인쇄배열표 조회(POP-UP화면용) 인쇄배열표 정보가 없을 때
   PROCEDURE SP_GET_PAGE_INFO(P_N_PRNT_PBCN_NO IN VARCHAR2,
                              P_QLTY_VEHL_CD   IN VARCHAR2,
                              P_MDL_MDY_CD     IN VARCHAR2,
                              P_LANG_CD        IN VARCHAR2,
                              P_LRNK_CD        IN VARCHAR2,
                              RS OUT REFCUR);   
                              
   -- 인쇄발간번호로 인쇄배열표 조회(POP-UP화면용) 인쇄배열표 정보가 있을 때                           
   PROCEDURE SP_GET_ALGN_INFO(P_N_PRNT_PBCN_NO IN VARCHAR2,
                              P_QLTY_VEHL_CD   IN VARCHAR2,
                              P_MDL_MDY_CD     IN VARCHAR2,
                              P_LANG_CD        IN VARCHAR2,
                              P_LRNK_CD        IN VARCHAR2,
                              RS OUT REFCUR);
                             
   -- 인쇄배열표 삭제
   PROCEDURE SP_DELETE_ARRAY(P_N_PRNT_PBCN_NO IN VARCHAR2,
                             p_LRNK_CD        IN VARCHAR2);
                             
   -- 인쇄배열표 저장 
   PROCEDURE SP_INSERT_ARRAY(P_N_PRNT_PBCN_NO     IN VARCHAR2,
                             P_QLTY_VEHL_CD       IN VARCHAR2,
                             P_MDL_MDY_CD         IN VARCHAR2,
                             P_LANG_CD            IN VARCHAR2,
                             P_DEPPC1_SN          IN NUMBER,
                             P_DL_EXPD_PRNT_PG_SN IN NUMBER,
                             P_PRNT_INSD_PG_SBC   IN VARCHAR2,
                             P_DEPPR1_YN          IN VARCHAR2,
                             P_PPRR_EENO 		  IN VARCHAR2,
                             P_UPDR_EENO 		  IN VARCHAR2,
                             P_LRNK_CD 			  IN VARCHAR2);
                             
     -- 제작의뢰 수정페이지 카운트구하기
     PROCEDURE SP_GET_MDFY_PAGE_COUNT(P_N_PRNT_PBCN_NO VARCHAR2,
                                      RS OUT REFCUR);
									  
	 PROCEDURE SP_GET_MDFY_PAGE_COUNT2(P_N_PRNT_PBCN_NO VARCHAR2,
	                                   P_LRNK_CD 	    VARCHAR2,
                                       RS OUT REFCUR);
                             
   /** 인쇄세부내역 */
   -- 인쇄세부내역 저장
   PROCEDURE SP_INSERT_ARRAY_DETAIL(P_QLTY_VEHL_CD       IN VARCHAR2,
                                    P_MDL_MDY_CD         IN VARCHAR2,
                                    P_LANG_CD 	         IN VARCHAR2,
                                    P_RQ_QTY 	         IN VARCHAR2,
                                    P_DLVG_PARR_YMD      IN VARCHAR2,
                                    P_DL_EXPD_DLVG_PL_CD IN VARCHAR2,
                                    P_N_PRNT_PBCN_NO     IN VARCHAR2,
                                    P_OLD_PRNT_PBCN_NO 	 IN VARCHAR2,
                                    P_I_WAY_SBC 		 IN VARCHAR2,
                                    P_BKBD_WAY_SBC 		 IN VARCHAR2,
                                    P_PG_MGN_SBC 		 IN VARCHAR2,
                                    P_DEPCQ1_SBC 		 IN VARCHAR2,
                                    P_DEIPQ1_SBC 		 IN VARCHAR2,
                                    P_PRNT_CVR_SBC 		 IN VARCHAR2,
                                    P_PRNT_INSD_PG_SBC 	 IN VARCHAR2,
                                    P_C_PRNT_CVR_SBC 	 IN VARCHAR2,
                                    P_C_PRNT_INSD_PG_SBC IN VARCHAR2,
                                    P_CVR_CEG_SBC 		 IN VARCHAR2,
                                    P_PG_NL 			 IN NUMBER,
                                    P_CVR_NL 			 IN NUMBER,
                                    P_EXPD_NL 			 IN NUMBER,
                                    P_GRN_DOC_NL 		 IN NUMBER,
                                    P_POST_CRD_NL 		 IN NUMBER,
                                    P_EOFU1_NL 			 IN NUMBER,
                                    P_NR_FLM_MKO_NL 	 IN NUMBER,
                                    P_DGTL_PRNT_NL 		 IN NUMBER,
                                    P_OORD_EDIT_PG_NL 	 IN NUMBER,
                                    P_DEPC1_QTY 		 IN NUMBER,
                                    P_REM 				 IN VARCHAR2,
                                    P_IV_QTY 			 IN NUMBER,
                                    P_ORD_QTY 			 IN NUMBER,
                                    P_MO_AVG_PRDN_QTY 	 IN NUMBER,
                                    P_PPRR_EENO 		 IN VARCHAR2,
                                    P_UPDR_EENO 		 IN VARCHAR2);
    
   -- 인쇄세부내역 삭제
   PROCEDURE SP_DELETE_ARRAY_DETAIL(P_N_PRNT_PBCN_NO IN VARCHAR2);
   
   -- 인쇄세부내역 조회
   PROCEDURE SP_GET_ARRAY_DETAIL(P_N_PRNT_PBCN_NO IN VARCHAR2,
                                 P_QLTY_VEHL_CD   IN VARCHAR2,
                                 P_MDL_MDY_CD 	  IN VARCHAR2,
                                 P_LANG_CD 		  IN VARCHAR2,
                                 RS OUT REFCUR);
   
   --인쇄세부내역 초기 작성시인쇄시 재고, 당월오더수량, 3개월 평균 생산량 조회 								 
   PROCEDURE SP_GET_IV_ORD_QTY(P_QLTY_VEHL_CD IN VARCHAR2,
                               P_MDL_MDY_CD   IN VARCHAR2,
                               P_LANG_CD      IN VARCHAR2,
                               RS OUT REFCUR);
  
  /** PG_COMMON 으로 이동 
  
  --신인쇄발간번호를 이용하여 정렬처리 위한 문자열 생성 							   
  FUNCTION FU_GET_SORT_PBCN(P_N_PRNT_PBCN_NO IN VARCHAR2) RETURN VARCHAR2; 
  **/
     
END PG_PRNT_PAGE_MGMT;