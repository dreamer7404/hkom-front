import React from 'react';
import {Button, Modal, Table} from 'react-bootstrap';
import { Input, InputGroup, Form, SelectPicker, Schema,Notification,useToaster,TagGroup,Tag } from 'rsuite';

import { useQuery,useMutation} from 'react-query';
const { StringType, NumberType,  ArrayType, ObjectType } = Schema.Types;
const model = Schema.Model({
    qltyVehlNm: StringType().isRequired('차종명을 입력해주세요.')
                            .pattern(/^[가-힣a-zA-Z0-9]+$/, '특수문자는 _ . 만 입력가능합니다')
                            .rangeLength(2, 30, '2-30자로 입력해주세요'),
    mdlMdyCd: StringType().isRequired('차종코드 및 연식을 입력해주세요.'),
    dlExpdPacScnCd: StringType().isRequired('승상구분을 선택해주세요.'),
    dlExpdPdiCd: StringType().isRequired('PDI구분을 선택해주세요.'),
    useYn: StringType().isRequired('사용유무를 선택해 주세요.')
});
const VehlMdyUpdate = ({show,data, onHide}) => {
const formRef = React.useRef();
const [formError, setFormError] = React.useState({});
const [formValue, setFormValue] = React.useState({
    qltyVehlCd: '',             // 차종코드
        
});  

    return (
        <>
            <Form
                ref={formRef}
                checkTrigger="change"
                onChange={setFormValue}
                onCheck={setFormError}
                formValue={formValue}
                model={model}>
                <Modal show={show} onHide={onHide} backdrop="static" keyboard={false} centered size="md" className="modal-custom">
                    <Modal.Header closeButton>
                        <Modal.Title>차종연식 상세/수정</Modal.Title>
                    </Modal.Header>
                        <Modal.Body>
                            <Table className="tbl-hor" bordered>
                                <colgroup>
                                    <col style={{width:'30%'}}></col>
                                    <col style={{width:''}}></col>
                                </colgroup>
                                <tbody>
                                    <tr>
                                        <th>차종</th>
                                        <td><Form.Control name = "qltyVehlNm" size="sm" /></td>
                                    </tr>
                                    <tr>
                                        <th className="essen">지역</th>
                                        <td>
                                        <Form.Control name = "regnNm" size="sm" />
                                        </td>
                                    </tr>
                                    <tr>
                                        <th className="essen">시작월팩</th>
                                        <td>
                                            <Form.Control name = "desmp1Cd" size="sm" type="text"/> 
                                        </td>
                                    </tr>
                                    <tr>
                                        <th>종료월팩</th>
                                        <td>
                                            <Form.Control name = "defmp1Cd" size="sm" type="text" /> 
                                        </td>
                                    </tr>
                                    <tr>
                                        <th className="essen">연식</th>
                                        <td>
                                            <Form.Control name = "mdlMdyCd" size="sm" type="text"/> 
                                        </td>
                                    </tr>
                                </tbody>
                            </Table>
                        </Modal.Body>

                        <Modal.Footer>
                            <Button variant="light" size="md" onClick={onHide}>취소</Button>
                            <Button variant="outline-danger" size="md" onClick={onHide}>삭제</Button>
                            <Button variant="primary" size="md" onClick={onHide} >저장</Button>
                        </Modal.Footer>
                </Modal>
            </Form>

        </>
    );

};
export default VehlMdyUpdate;