import React from 'react';
import {Tab,Tabs} from 'react-bootstrap';

import YongsanIvmTot from './YongsanIvmTot';
import RequestState from './RequestState';

const YongsanIvmContainer = () => {

    const [leftWidth, setLeftWidth] = React.useState('150px')
    const element = React.useRef(null);
   
    React.useEffect(() => {
        const getTitle = document.getElementById('section-title-width');
        const titleWidth = getTitle.clientWidth + 40;
        setLeftWidth(titleWidth)
    }, []);

    return (
        <>
            <Tabs  defaultActiveKey="tab1" style={{left: leftWidth}} ref={element}>
                <Tab eventKey="tab1" title={"용산재고관리 현황"}>
                    <YongsanIvmTot />
                </Tab>
                <Tab eventKey="tab2" title="요청현황">
                    <RequestState />
                </Tab>
            </Tabs>
        </>
    );

};
export default YongsanIvmContainer;