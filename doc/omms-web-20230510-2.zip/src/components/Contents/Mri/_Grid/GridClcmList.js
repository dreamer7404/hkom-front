import React, {useEffect, useMemo, useRef} from 'react';
import { AgGridReact } from 'ag-grid-react';
import { CONSTANTS } from '../../../../utils/constants';
import AttachmentIcon from '@rsuite/icons/Attachment';

import 'ag-grid-community/styles/ag-grid.css';
import 'ag-grid-community/styles/ag-theme-alpine.css';

const GridRequestState = ({gridHeight, filterValue, queryResult, limit, activePage,onCellClicked}) => {

  const gridRef = useRef();

  const columnDefs = [
        {
            checkboxSelection: true,
            spanHeaderHeight: true,
            headerCheckboxSelection: true,
            width:'45',
            maxWidth:45,
            minWidth:45,
            pinned:'left'
        },
        {
            headerName: '등록번호',
            field: 'clcm1',
            spanHeaderHeight: true,
            pinned:'left',
            width:'100',
            minWidth:'80',
        },
        {
            headerName: '수신형태',
            field: 'clcm2',
            spanHeaderHeight: true,
            pinned:'left',
            minWidth:'80',
        },
        {
            headerName: '발신처',
            field: 'clcm3',
            spanHeaderHeight: true,
            pinned:'left',
            minWidth:'80',
        },
        {
          headerName: '적용차종',
          children: [
            { headerName:'차종코드', field: 'carCd', minWidth:'80', pinned:'left'},
            { headerName:'차종명', field: 'carName', minWidth:'80', pinned:'left' },
          ],
        },
        {
            headerName: '적용언어',
            field: 'langCd',
            spanHeaderHeight: true,
            pinned:'left',
            minWidth:'80',
        },
        {
          headerName: '제목',
          field: 'clcm4',
          spanHeaderHeight: true,
          cellStyle: () => ({textDecoration: 'underline', cursor: 'pointer', color:'#2589f5'}),
          pinned:'left',
          minWidth:'130',
        },
        {
          headerName: '첨부',
          field: 'clcm5',
          spanHeaderHeight: true,
          minWidth:'50',
          pinned:'left',
          cellRenderer: function(params) {
            return <AttachmentIcon style={{fontSize:'14px', cursor: 'pointer'}} />
          }
        },
        {
          headerName: '등록자',
          field: 'clcm6',
          spanHeaderHeight: true,
          minWidth:'70',
          pinned:'left'
        },  
        {
          headerName: '등록일',
          field: 'clcm7',
          spanHeaderHeight: true,
          minWidth:'100',
          pinned:'left'
        },
        {
          headerName: '언어(X:차기반영불필요)',
          children: [
            { headerName:'AR', field: 'ar', minWidth:'65'},
            { headerName:'AS', field: 'as', minWidth:'65' },
            { headerName:'BS', field: 'bs', minWidth:'65' },
            { headerName:'AR', field: 'ar', minWidth:'65'},
            { headerName:'AS', field: 'as', minWidth:'65' },
            { headerName:'BS', field: 'bs', minWidth:'65' },
            { headerName:'AR', field: 'ar', minWidth:'65'},
            { headerName:'AS', field: 'as', minWidth:'65' },
            { headerName:'BS', field: 'bs', minWidth:'65' },
            { headerName:'AS', field: 'as', minWidth:'65' },
            { headerName:'BS', field: 'bs', minWidth:'65' },
            { headerName:'AS', field: 'as', minWidth:'65' },
            { headerName:'BS', field: 'bs', minWidth:'65' },
          ],
        },
    ]

 

    const defaultColDef = useMemo(() => {
        return {
            initialWidth: 10,
            sortable: true,
            resizable:true,
        };
    }, []);

  const onFirstDataRendered = (params) => {
      params.api.sizeColumnsToFit();
  };

  useEffect(()=>{
    if(queryResult.status === 'loading' && gridRef && gridRef.current && gridRef.current.api){
        gridRef.current.api.showLoadingOverlay();
    }
  },[queryResult]);

  useEffect(()=> {
    if(gridRef && gridRef.current && gridRef.current.api){
      gridRef.current.api.setQuickFilter(filterValue);
    }
  },[filterValue]);

  useEffect(()=> {
    if(gridRef && gridRef.current && gridRef.current.api){
      gridRef.current.api.paginationGoToPage(activePage-1);
    }
  },[activePage]);


  return(
      <div className="ag-theme-alpine" style={{height: gridHeight, transition:'all ease .3s'}}>
        <AgGridReact
            ref={gridRef} 
            rowData={queryResult && queryResult.data} 
            columnDefs={columnDefs}
            defaultColDef={defaultColDef}

            // paging
            pagination={true}
            paginationPageSize={limit} //
            suppressPaginationPanel={true} 
            // onPaginationChanged={onPaginationChanged}

            //  filter
            cacheQuickFilter={true}

            onCellClicked={onCellClicked}

            rowSelection={'multiple'}
            suppressRowClickSelection= {true} 

            // overlay
            overlayLoadingTemplate={CONSTANTS.gridLoading}
            overlayNoRowsTemplate={CONSTANTS.gridNoRows}

            onFirstDataRendered={onFirstDataRendered}
            suppressSizeToFit={true}    
            onGridSizeChanged={onFirstDataRendered}    
            >
        </AgGridReact>
    </div>
  )


};
export default GridRequestState;