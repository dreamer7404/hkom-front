import React, {useEffect, useMemo, useRef} from 'react';
import { AgGridReact } from 'ag-grid-react';
import { CONSTANTS } from '../../../../utils/constants';

const GridPrintOrderList = ({gridHeight, filterValue, queryResult, limit, activePage,onCellClicked}) => {

  const gridRef = useRef();

  const columnDefs = [
        {
            checkboxSelection: true,
            spanHeaderHeight: true,
            headerCheckboxSelection: true,
            width:'45',
            maxWidth:45,
            minWidth:45,
        },
        {
            headerName: '발행구분',
            field: 'print1',
            spanHeaderHeight: true,
        },
        {
            headerName: '발간번호',
            field: 'print2',
            spanHeaderHeight: true,
            cellStyle: () => ({textDecoration: 'underline', cursor: 'pointer', color:'#2589f5'})
        },
        {
          headerName: '차종',
          children: [
            { headerName:'차종코드', field: 'carCd'},
            { headerName:'차종명', field: 'carName' },
            { headerName:'연식', field: 'monthYear' },
          ],
        },
        {
          headerName: '언어',
          children: [
            { headerName:'지역', field: 'region'},
            { headerName:'언어코드', field: 'langCd' },
            { headerName:'언어명', field: 'langName'},
          ],
        },
        {
          headerName: '납품 요청일',
          spanHeaderHeight: true,
          field: 'print3',
        },
        {
          headerName: '인쇄부수',
          spanHeaderHeight: true,
          field: 'print4',
        },  
        {
          headerName: '발주자',
          spanHeaderHeight: true,
          field: 'print5',
        },  
        {
          headerName: '발주상태',
          spanHeaderHeight: true,
          field: 'print6',
          cellRenderer:'statusComponent'
        },  
        {
          headerName: '발주일',
          spanHeaderHeight: true,
          field: 'print7',
        },  
    ]

    const defaultColDef = useMemo(() => {
        return {
            initialWidth: 90,
            sortable: true,
            resizable:true,
        };
    }, []);

  const statusComponent = (props) => {
        
      if(props.value === "발주완료"){
        return(
            <div className="status-title status-1">
            {props.value}
            </div>
        )
      }else if(props.value === "임시저장"){
        return(
            <div className="status-title status-2">
            {props.value}
            </div>
        )
      }else{
        return(
            <div className="status-title status-4" style={{cursor:'pointer'}}>
            {props.value}
            </div>
        )
      }

  }

  const onFirstDataRendered = (params) => {
      params.api.sizeColumnsToFit();
  };

  useEffect(()=>{
    if(queryResult.status === 'loading' && gridRef && gridRef.current && gridRef.current.api){
        gridRef.current.api.showLoadingOverlay();
    }
  },[queryResult]);

  useEffect(()=> {
    if(gridRef && gridRef.current && gridRef.current.api){
      gridRef.current.api.setQuickFilter(filterValue);
    }
  },[filterValue]);

  useEffect(()=> {
    if(gridRef && gridRef.current && gridRef.current.api){
      gridRef.current.api.paginationGoToPage(activePage-1);
    }
  },[activePage]);


  return(
      <div className="ag-theme-alpine" style={{height: gridHeight, transition:'all ease .3s'}}>
        <AgGridReact
            ref={gridRef} 
            rowData={queryResult && queryResult.data} 
            columnDefs={columnDefs}
            defaultColDef={defaultColDef}

            // paging
            pagination={true}
            paginationPageSize={limit} //
            suppressPaginationPanel={true} 
            // onPaginationChanged={onPaginationChanged}

            //  filter
            cacheQuickFilter={true}

            onCellClicked={onCellClicked}

            rowSelection={'multiple'}
            suppressRowClickSelection= {true} 

            frameworkComponents={{
                statusComponent
            }}
            // overlay
            overlayLoadingTemplate={CONSTANTS.gridLoading}
            overlayNoRowsTemplate={CONSTANTS.gridNoRows}

            onFirstDataRendered={onFirstDataRendered}
            suppressSizeToFit={true}    
            onGridSizeChanged={onFirstDataRendered}    
            >
        </AgGridReact>
    </div>
  )


};
export default GridPrintOrderList;