import React, {useEffect, useMemo, useRef} from 'react';
import { AgGridReact } from 'ag-grid-react';
import { CONSTANTS } from '../../../../utils/constants';

import { formatNumber, escapeCharChangeForGrid } from '../../../../utils/commUtils';
const GridPrintStateList = ({gridHeight, filterValue, queryResult, limit, activePage, onCellClicked}) => {

  const gridRef = useRef();

  
  // 수량 천단위 콤마 찍기 시작
  const currencyFormatter = (params) => {
    return formatNumber(params.value);
  };
  const columnDefs = [
        {
            headerName: '발행구분',
            field: 'iwayCd',
            spanHeaderHeight: true,
        },
        {
            headerName: '발간번호',
            field: 'newPrntPbcnNo',
            spanHeaderHeight: true,
            cellStyle: () => ({textDecoration: 'underline', cursor: 'pointer', color:'#2589f5'})
        },
        {
          headerName: '차종',
          children: [
            { headerName:'차종코드', field: 'qltyVehlCd'},
            { headerName:'차종명', field: 'qltyVehlNm' , cellRenderer:"escapeCharChangeForGrid"},
            { headerName:'연식', field: 'mdlMdyCd'},
          ],
        },
        {
          headerName: '언어',
          children: [
            { headerName:'지역', field: 'dlExpdRegnCd'},
            { headerName:'언어코드', field: 'langCd'},
            { headerName:'언어명', field: 'langCdNm', cellRenderer:"escapeCharChangeForGrid"},
          ],
        },
        {
          headerName: '발주일',
          spanHeaderHeight: true,
          field: 'prntParrYmd',
        },
        {
          headerName: '납품 요청일',
          spanHeaderHeight: true,
          field: 'dlvgParrYmd',
        },
        {
          headerName: '인쇄부수',
          spanHeaderHeight: true,
          field: 'prntParrQty',
          valueFormatter: currencyFormatter
        },  
        {
          headerName: '평균단가',
          spanHeaderHeight: true,
          field: 'saleUnp',
          valueFormatter: currencyFormatter
        },  
        {
          headerName: '소요예산',
          spanHeaderHeight: true,
          field: 'prntParrBgt',
          valueFormatter: currencyFormatter
        },  
        {
          headerName: '견적서',
          spanHeaderHeight: true,
          field: 'nPrntPbcnNo',
        },  
        {
          headerName: '인쇄비 품의번호',
          spanHeaderHeight: true,
          field: 'prtlImtrSbc3',
        },  
        {
          headerName: '메모',
          spanHeaderHeight: true,
          field: 'prtlImtrSbc',
        },  
        {
          headerName: '개정내용',
          spanHeaderHeight: true,
          field: 'reviseQty',
        }
  ]

  const defaultColDef = useMemo(() => {
      return {
          initialWidth: 90,
          sortable: true,
          resizable:true,
      };
  }, []);

  const onFirstDataRendered = (params) => {
      params.api.sizeColumnsToFit();
  };

  useEffect(()=>{
    if(queryResult.status === 'loading' && gridRef && gridRef.current && gridRef.current.api){
        gridRef.current.api.showLoadingOverlay();
    }
  },[queryResult]);

  useEffect(()=> {
    if(gridRef && gridRef.current && gridRef.current.api){
      gridRef.current.api.setQuickFilter(filterValue);
    }
  },[filterValue]);

  useEffect(()=> {
    if(gridRef && gridRef.current && gridRef.current.api){
      gridRef.current.api.paginationGoToPage(activePage-1);
    }
  },[activePage]);


  return(
      <div className="ag-theme-alpine" style={{height: gridHeight, transition:'all ease .3s'}}>
        <AgGridReact
            ref={gridRef} 
            rowData={queryResult && queryResult.data.printStateList} 
            columnDefs={columnDefs}
            defaultColDef={defaultColDef}

            // paging
            pagination={true}
            paginationPageSize={limit} //
            suppressPaginationPanel={true} 
            // onPaginationChanged={onPaginationChanged}

            //  filter
            cacheQuickFilter={true}

            onCellClicked={onCellClicked}
            frameworkComponents={{
              escapeCharChangeForGrid
            }}
            // overlay
            overlayLoadingTemplate={CONSTANTS.gridLoading}
            overlayNoRowsTemplate={CONSTANTS.gridNoRows}

            onFirstDataRendered={onFirstDataRendered}
            suppressSizeToFit={true}    
            onGridSizeChanged={onFirstDataRendered}    
            >
        </AgGridReact>
    </div>
  )


};
export default GridPrintStateList;