import React from 'react';
import {Tab,Tabs} from 'react-bootstrap';

import AuthMenuList from './AuthMenuList';
import AuthGroupList from './AuthGroupList';

const AuthContainer = () => {
    
    const [leftWidth, setLeftWidth] = React.useState('150px')
    React.useEffect(() => {
        const getTitle = document.getElementById('section-title-width');
        const titleWidth = getTitle.clientWidth + 40;
        setLeftWidth(titleWidth);
    }, []);

    const [activeTab, setActiveTab] = React.useState('tab1');

    return (
        <>
            <Tabs  defaultActiveKey={activeTab} onSelect={tab => setActiveTab(tab)} style={{left: leftWidth}} >
                <Tab eventKey="tab1" title="메뉴별 권한관리">
                {activeTab === 'tab1' && <AuthMenuList /> }
                </Tab>
                <Tab eventKey="tab2" title="그룹별 권한관리">
                {activeTab === 'tab2' && <AuthGroupList /> }
                </Tab>
            </Tabs>
        </>
    );

};
export default AuthContainer;