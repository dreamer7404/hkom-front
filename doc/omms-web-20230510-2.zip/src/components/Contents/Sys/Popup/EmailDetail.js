import React from 'react';
import {Button, Modal, Table} from 'react-bootstrap';
import {Form} from 'rsuite';

const EmailDetail = ({show, onHide}) => {

    return (
        <>
            <Form>
                <Modal show={show} onHide={onHide} backdrop="static" keyboard={false} centered size="lg" className="modal-custom">
                    <Modal.Header closeButton>
                        <Modal.Title>이력 상세</Modal.Title>
                    </Modal.Header>
                        <Modal.Body>
                            <Table className="tbl-hor" bordered>
                                <colgroup>
                                    <col style={{width:'30%'}}></col>
                                    <col style={{width:''}}></col>
                                </colgroup>
                                <tbody>
                                    <tr>
                                        <th className="">수신인</th>
                                        <td>
                                            user1@hmc.com.kr
                                        </td>
                                    </tr>
                                    <tr>
                                        <th className="">제목</th>
                                        <td>
                                            이메일 제목입니다.
                                        </td>
                                    </tr>
                                    <tr>
                                        <th className="">내용</th>
                                        <td>
                                            이메일 내용입니다.
                                        </td>
                                    </tr>
                                </tbody>
                            </Table>
                        </Modal.Body>

                        <Modal.Footer>
                            <Button variant="primary" size="md" onClick={onHide} >확인</Button>
                        </Modal.Footer>
                </Modal>
            </Form>
        </>
    );

};
export default EmailDetail;