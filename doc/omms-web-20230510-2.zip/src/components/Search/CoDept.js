/* eslint-disable react-hooks/exhaustive-deps */
import React, {useState} from 'react';
import {Row, Col} from 'react-bootstrap';
import { SelectPicker, Form } from 'rsuite';

//--------------  서버데이터용 필수 -------------------------------
import { useQuery} from 'react-query';
import { getData } from '../../utils/async';
import { API, CONSTANTS } from '../../utils/constants';
import useStore from '../../utils/store';
//--------------// 서버데이터용 필수 -------------------------------


const CoDept = () => {

    
    const {keyword, 
        setCoCd, // 회사코드 setter
        setDeptCd,
    } = useStore(); 


    const onChangeCo = val => {
        setCoCd(val);
    };
    const onChangeDept = val => {
        setDeptCd(val);
    };
    

    // 회사
    const paramsCo = {
        dlExpdGCd: '0001'
    };
    const coCombo = useQuery([API.codeCombo, paramsCo], () => getData(API.codeCombo, paramsCo), {
            select: data => [{label: CONSTANTS.labelAll, value: CONSTANTS.valueAll}].concat(data)
    });

    // 부서
    const paramsDept = {
        dlExpdGCd: '0011'
    };
    const deptCombo = useQuery([API.codeCombo, paramsDept], () => getData(API.codeCombo, paramsDept), {
            select: data => [{label: CONSTANTS.labelAll, value: CONSTANTS.valueAll}].concat(data.filter(d => (d.value === 'ALL' || d.value === '02' || d.value === '07' || d.value === '08' )))
    });

   
    const [readOnly, setReadOnly] = useState(false);

    React.useEffect(() => {
        if(keyword.coCd === '03'){ // 외주용역사 일때, 용역회사 리스트보여준다.
            setReadOnly(false);
        }else{
            setDeptCd(CONSTANTS.valueAll);
            setReadOnly(true);
        }
    },[keyword.coCd])

    return (
        <>
            
            <Form.ControlLabel column="sm" >회사</Form.ControlLabel>
            <Row className="select-wrap">
                <Col sm={6}> 
                    <SelectPicker size="sm" style={{width: '100%'}}
                        value={keyword.coCd} 
                        data={coCombo && coCombo.data ? coCombo.data : []} 
                        onChange={onChangeCo}
                        placeholder={CONSTANTS.labelAll}
                        cleanable={false}
                        searchable={false}
                        block={true}
                    />
                </Col>
                <Col sm={6}> 
                    <SelectPicker size="sm" style={{width: '100%'}}
                        value={keyword.deptCd} 
                        data={deptCombo && deptCombo.data ? deptCombo.data : []} 
                        onChange={onChangeDept}
                        placeholder={CONSTANTS.labelAll}
                        cleanable={false}
                        searchable={false}
                        block={true}

                        readOnly={readOnly}
                    />
                </Col>
            </Row>
            
        </>
    );

};
export default CoDept;