package com.oms.sys.dto;

import java.sql.Timestamp;

import org.apache.ibatis.type.Alias;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @author 안경수
 * @since 2023. 4. 6.
 * @see
 */
@Alias("authVehlSaveDTO")
@Data
@AllArgsConstructor
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown=true)
public class AuthVehlSaveDTO {

    private String userEeno;
    private String qltyVehlCd;
    private String dlExpdCoCd;
    private String clScnCd;
    private String pprrEeno;
    private String updrEeno;
    private String blnsCoCd;
    private String mdlMdyCd;

    public AuthVehlSaveDTO (String userEeno, String qltyVehlCd, String dlExpdCoCd, String pprrEeno){
        this.userEeno = userEeno;
        this.dlExpdCoCd = dlExpdCoCd;
        this.qltyVehlCd = qltyVehlCd;
        this.pprrEeno = pprrEeno;
    }
    public AuthVehlSaveDTO (String qltyVehlCd, String mdlMdyCd, String dlExpdCoCd, String userEeno, String pprrEeno,String clScnCd,String blnsCoCd){
        this.qltyVehlCd = qltyVehlCd;
        this.mdlMdyCd = mdlMdyCd;
        this.dlExpdCoCd= dlExpdCoCd;
        this.userEeno = userEeno;
        this.pprrEeno = pprrEeno;
        this.clScnCd = clScnCd;
        this.blnsCoCd = blnsCoCd;
    }
}
