package com.oms.sys.service.impl;

import java.util.List;

import able.cloud.core.service.HService;

import org.springframework.stereotype.Service;

import com.oms.sys.dao.UsrGrpMgmtDAO;
import com.oms.sys.dto.UsrGrpMgmtReqDTO;
import com.oms.sys.dto.UsrGrpMgmtResDTO;
import com.oms.sys.service.UsrGrpMgmtService;

import lombok.RequiredArgsConstructor;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @author 안경수
 * @since 2023. 4. 18.
 * @see
 */

@RequiredArgsConstructor
@Service("usrGrpMgmtService")
public class UsrGrpMgmtServiceImpl extends HService implements UsrGrpMgmtService {

    private final UsrGrpMgmtDAO usrGrpMgmtDAO;

    @Override
    public List<UsrGrpMgmtResDTO> selectUsrGrpMgmtList() throws Exception {
       return usrGrpMgmtDAO.selectUsrGrpMgmtList();
    }

    @Override
    public Integer insertUsrGrpMgmt(UsrGrpMgmtReqDTO usrGrpMgmtReqDTO) throws Exception {
        return usrGrpMgmtDAO.insertUsrGrpMgmt(usrGrpMgmtReqDTO) ;
    }

    @Override
    public UsrGrpMgmtResDTO selectUsrGrpMgmt(UsrGrpMgmtReqDTO usrGrpMgmtReqDTO) throws Exception {
        return usrGrpMgmtDAO.selectUsrGrpMgmt(usrGrpMgmtReqDTO);
    }

    @Override
    public Integer updateUsrGrpMgmt(UsrGrpMgmtReqDTO usrGrpMgmtReqDTO) throws Exception {
        return usrGrpMgmtDAO.updateUsrGrpMgmt(usrGrpMgmtReqDTO);
    }






}
