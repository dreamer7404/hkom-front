package com.oms.common.service.impl;

import java.util.List;

import javax.mail.Message;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import org.apache.commons.text.StringEscapeUtils;
import org.apache.commons.validator.routines.EmailValidator;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
//import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

import com.oms.common.dao.MailDAO;
import com.oms.common.dto.MailDTO;
import com.oms.common.model.Mail;
import com.oms.common.service.MailService;

import lombok.RequiredArgsConstructor;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @author 안경수
 * @since 2023. 5. 16.
 * @see
 */

@RequiredArgsConstructor
@Service
public class MailServiceImpl implements MailService {

    private final JavaMailSender mailSender;
    private final MailDAO mailDao;


    @Value("${spring.mail.from}")
    private String from;

    @Override
    public int send(MailDTO mailDTO)  {
        int sendResult = 0;
        try {

            //  메일전송
            MimeMessage mimeMessage = mailSender.createMimeMessage();

            // 수신자 이메일 리스트
            int size = mailDTO.getRcvList().size();
            InternetAddress[] toAddr = new InternetAddress[size];
            for(int i=0; i<size; i++) {
                toAddr[i] = new InternetAddress(mailDTO.getRcvList().get(i).getEmlAdr());
            }
            mimeMessage.setRecipients(Message.RecipientType.TO, toAddr);

            MimeMessageHelper mimeMessageHelper = new MimeMessageHelper(mimeMessage, false, "UTF-8");
            mimeMessageHelper.setFrom(from); // 보낸이 주소
//            mimeMessageHelper.setTo("9426036@ict-companion.com"); // 수신자 주소
//            mimeMessageHelper.setTo("A678102@hyundai-autoever.com");
            mimeMessageHelper.setSubject(mailDTO.getEmlTitl()); // 제목
            mimeMessageHelper.setText(StringEscapeUtils.unescapeHtml4(mailDTO.getEmlSbc()), true); // 내용

            mailSender.send(mimeMessage);
            sendResult = 1;


        } catch (Exception e) {
            sendResult = -1;

        }finally {
            // 로그저장 -  TB_LOG_EML 저장
            mailDao.insertLogEml(mailDTO);
        }

        return sendResult;

    }

    /*
     * TB_LOG_EML 저장
     */
    @Override
    public int insertLogEml(MailDTO mailDTO) {
        return mailDao.insertLogEml(mailDTO);
    }

    @Override
    public List<Mail> selectEmlAdrList(List<String> list) {
        return mailDao.selectEmlAdrList(list);
    }




}
