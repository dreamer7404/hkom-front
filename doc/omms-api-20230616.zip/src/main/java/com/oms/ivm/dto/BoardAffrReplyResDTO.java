package com.oms.ivm.dto;

import java.sql.Timestamp;

import org.apache.ibatis.type.Alias;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @author 안경수
 * @since 2023. 6. 15.
 * @see
 */
@NoArgsConstructor
@Alias("boardAffrReplyResDTO")
@Data
public class BoardAffrReplyResDTO {

    private Long blcSn;
    private Long blcReplySn;
    private String blcReplySbc;
    private String delYn;
    private String pprrEeno;
    private Timestamp framDtm;
    private String updrEeno;
    private Timestamp mdfyDtm;

    private String userNm;
    private String coNm;
    private String deptNm;

}
