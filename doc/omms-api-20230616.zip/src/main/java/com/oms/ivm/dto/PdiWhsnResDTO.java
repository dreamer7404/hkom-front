package com.oms.ivm.dto;

import org.apache.ibatis.type.Alias;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @author 김정웅
 * @since 2023. 5. 8.
 * @see
 */

@Alias("pdiWhsnResDTO")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class PdiWhsnResDTO {

    private String qltyVehlCd;
    private String qltyVehlNm;
    private String dlExpdMdlMdyCd;
    private String dlExpdRegnCd;
    private String dlExpdPrvsNm;
    private String langCdNm;
    private String newPrntPbcnNo;
    private String expdWhsnStNm;
    private String dlExpdBoxQty;
    private String rqQty;
    private String deei1Qty;
    private String whsnYmd;
    private String crgrNm;
    private String langCd;
    private String dtlSn;
    private String expdWhsnStCd;
    private String crgrEeno;
    private String clScnCd;
    private String mdlMdyCd;
    private String pwtiNm;

}
