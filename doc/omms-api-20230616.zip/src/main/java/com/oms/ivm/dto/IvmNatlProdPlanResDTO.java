package com.oms.ivm.dto;

import org.apache.ibatis.type.Alias;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @author 김정웅
 * @since 2023. 3. 22.
 * @see
 */

@Alias("ivmNatlProdPlanResDTO")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class IvmNatlProdPlanResDTO {

    private String qltyVehlCd;      //차종코드
    private String qltyVehlNm;      //차종명
    private String mdlMdyCd;        //연식
    private String dlExpdPrvsNm;    //지역명
    private String langCd;          //언어코드
    private String langCdNm;        //언어명
    private String dlExpdNatCd;     //국가코드
    private String natNm;           //국가명
    private String prodPlan2week;   //생산계획(2주)
    private String prodPlan3Day;    //단기계획(3일)
    private String a00;
    private String a01;
    private String a02;
    private String a03;
    private String a04;
    private String a05;
    private String a06;
    private String a07;
    private String a08;
    private String a09;
    private String a10;
    private String a11;
    private String a12;
    private String a13;
    private String a14;

    //private String totsum;

}
