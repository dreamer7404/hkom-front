package com.oms.ivm.dto;

import java.util.List;

import org.apache.ibatis.type.Alias;

import com.oms.common.model.Mail;

import lombok.AllArgsConstructor;
import lombok.Data;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @author 안경수
 * @since 2023. 6. 12.
 * @see
 */


@AllArgsConstructor
@Alias("boardAffrRcvUsersSaveDTO")
@Data
public class BoardAffrRcvUsersSaveDTO {
    private Long blcSn;         // 게시문번호
    private String userEeno;    // 발신자, 작성자
    private List<Mail> rcvList; // 수신자 리스트
}
