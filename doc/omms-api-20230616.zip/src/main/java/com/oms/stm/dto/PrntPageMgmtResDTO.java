package com.oms.stm.dto;

import org.apache.ibatis.type.Alias;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName : PrntPageMgmtResDTO.java
 * @Description :
 * @author 김경훈
 * @since 2023. 4. 4.
 * @see
 */
@Alias("prntPageMgmtResDTO")
@Data
@NoArgsConstructor
@AllArgsConstructor

public class PrntPageMgmtResDTO {
    private String newPrntPbcnNo;
    private String lrnkCd;
    private int deppc1Sn;
    private int deppc2sn;
    private String qltyVehlCd;
    private String qltyVehlNm;
    private String mdlMdyCd;
    private String langCd;
    private String langNm;
    private String rgstYmd;
    private int endPgSn;
    private String pprrEeno;
    private String framDtm;
    private String updrEeno;
    private String mdfyDtm;
    private String prntPbcnNm;
    //ivOrdQty  인쇄시 재고,오더,생산량  조회

    private String ivQty;
    private String ordQty;
    private String moAvgPrdnQty;
    private String dlExpdPdiCd;



}
