package com.oms.common.dto;

import java.sql.Timestamp;

import org.apache.ibatis.type.Alias;

import lombok.Data;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @author 안경수
 * @since 2023. 5. 17.
 * @see
 */
@Data
@Alias("mailDTO")
public class MailDTO {
    private Integer EmlCd; // tb_log_eml의 pk

    private String emlScdCd; // 상태 ex: "발송 ", "실패"
    private String emlId; // 메일아이디

    private String sndrId;  // 발신자 사번
    private String emlTitl; // 제목
    private String emlSbc;  // 내용
    private Timestamp fsSndDate; //발송일

    private String AdreEml;
}
