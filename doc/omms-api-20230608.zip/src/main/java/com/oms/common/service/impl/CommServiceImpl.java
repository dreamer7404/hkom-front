package com.oms.common.service.impl;

import java.util.List;

import able.cloud.core.service.HService;

import org.springframework.stereotype.Service;

import com.oms.common.dao.ComboDAO;
import com.oms.common.dao.CommDAO;
import com.oms.common.dto.ComboReqDTO;
import com.oms.common.dto.CommReqDTO;
import com.oms.common.dto.PdiComboResDTO;
import com.oms.common.dto.VehlComboResDTO;
import com.oms.common.service.ComboService;
import com.oms.common.service.CommService;
import com.oms.stm.dto.LangMgmtResDTO;
import com.oms.stm.dto.VehlMgmtResDTO;
import com.oms.sys.dto.UsrMgmtReqDTO;
import com.oms.sys.dto.UsrMgmtResDTO;

import lombok.RequiredArgsConstructor;


/**
 * <pre>
 * Statements
 * </pre>
 * @ClassName : CommServiceImpl.java
 * @Description :
 * @author 김경훈
 * @since 2023. 3. 22.
 * @see
 */
@RequiredArgsConstructor
@Service("commService")
public class CommServiceImpl  extends HService implements CommService {

    private final CommDAO commDao;

    /*
     * @see com.oms.common.service.CommService#selectCodeList(com.oms.common.dto.CommReqDTO)
     */
    @Override
    public List<VehlMgmtResDTO> selectCodeList(CommReqDTO comDto) {
        // TODO Auto-generated method stub
        return commDao.selectCodeList(comDto);
    }

    /*
     * @see com.oms.common.service.CommService#selectDlExpdRegnCdList(com.oms.common.dto.CommReqDTO)
     */
    @Override
    public List<LangMgmtResDTO> selectDlExpdRegnCdList(CommReqDTO comDto) {

        return commDao.selectDlExpdRegnCdList(comDto);
    }

    /*
     * @see com.oms.common.service.CommService#selectLangCdList(com.oms.common.dto.CommReqDTO)
     */
    @Override
    public List<LangMgmtResDTO> selectLangCdList(CommReqDTO comDto) {
        // TODO Auto-generated method stub
        return commDao.selectLangCdList(comDto);
    }

    /*
     * @see com.oms.common.service.CommService#selectQltyVehlCdList(com.oms.common.dto.CommReqDTO)
     */
    @Override
    public List<LangMgmtResDTO> selectQltyVehlCdList(CommReqDTO comDto) {
        // TODO Auto-generated method stub
        return commDao.selectQltyVehlCdList(comDto);
    }

    /*
     * @see com.oms.common.service.CommService#selectUsrMgmt(com.oms.sys.dto.UsrMgmtReqDTO)
     */
    @Override
    public List<UsrMgmtResDTO> userMgmtPop(UsrMgmtReqDTO dto) {
        // TODO Auto-generated method stub
        return commDao.userMgmtPop(dto);
    }



}
