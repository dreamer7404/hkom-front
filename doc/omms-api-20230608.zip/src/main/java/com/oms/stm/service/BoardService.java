package com.oms.stm.service;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import com.oms.stm.dto.BoardReqDTO;
import com.oms.stm.dto.BoardResDTO;



/**
 * <pre>
 * BoardService
 * </pre>
 *
 * @ClassName   : BoardService.java
 * @Description :
 * @author 안경수
 * @since 2023.1.6
 * @see
 */

public interface BoardService {

    /**
     * Statements
     *
     * @param boardReqDTO
     * @return
     */
    public List<BoardResDTO> selectBoardList(BoardReqDTO boardReqDTO) throws Exception;

    /**
     * Statements
     *
     * @param boardReqDTO
     * @return
     */
    public List<BoardResDTO> selectBoardGrpList(BoardReqDTO boardReqDTO) throws Exception;


    /**
     * Statements
     *
     * @param boardReqDTO
     * @param request
     */
    public void insertBoard(BoardReqDTO boardReqDTO, HttpServletRequest request);

    /**
     * Statements
     *
     * @param boardReqDTO
     */
    public void insertRcvrMgmt(BoardReqDTO boardReqDTO);
    /**
     * Statements
     *
     * @param boardReqDTO
     */
    public void deleteBoard(BoardReqDTO boardReqDTO);

    /**
     * Statements
     *
     * @param boardReqDTO
     */
    public void updateBoard(BoardReqDTO boardReqDTO);




}
