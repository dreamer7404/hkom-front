package com.oms.print.dto;


import org.apache.ibatis.type.Alias;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;



/**
 * <pre>
 * Statements
 * </pre>
 * @ClassName : PrintStateResDTO.java
 * @Description :
 * @author 김경훈
 * @since 2023. 5. 3.
 * @see
 */
@Alias("PrintStateComDTO")
@Data
@NoArgsConstructor
@AllArgsConstructor

public class PrintStateComDTO {

private String qltyVehlCd; //차종코드
private String userEeno;
private String mdlMdyCd;
private String expdPdiCd;
private String dlExpdRegnCd;
private String langCd;
private String oldPrntPbcnNo;
private String newPrntPbcnNo;
private String dlExpdPdiCd;
private String iWayCd;
private String dlExpdCoCd;
private String bDate;

}
