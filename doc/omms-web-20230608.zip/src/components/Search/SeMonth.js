import React from 'react';
import {Row, Col} from 'react-bootstrap';
import {Form, DatePicker,  InputGroup} from 'rsuite';
import { utcToLocalDate } from '../../utils/commUtils'; //'../../../utils/commUtils';

//--------------  서버데이터용 필수 -------------------------------
import useStore from '../../utils/store';
//--------------// 서버데이터용 필수 -------------------------------


const SeMonth = () => {

    const {keyword, setSMonth, setEMonth } = useStore(); 

    const onChangeDateStart = val => {
        setSMonth(utcToLocalDate(val.setDate(1)));
        
        // 시작월 변경시 종료월 13개월 후로 세팅
        // setEMonth(utcToLocalDate(new Date(val.setMonth(val.getMonth() + 14)).setDate(0) ));
        //alert(utcToLocalDate(new Date(val.setMonth(val.getMonth() + 14)).setDate(0) ))
    }
    const onChangeDateEnd = val => {
        // let endDate = utcToLocalDate(val);
        // let endYYYY = endDate.substring(0,4);
        // let endMM = endDate.substring(5,7);
        // const endDate = ;
        setEMonth(utcToLocalDate(new Date(val.getUTCFullYear(), val.getMonth()+1, 0)));
        
        // 종료월 변경시 시작월 13개월 전으로 세팅
        // setSMonth(utcToLocalDate(new Date(val.setMonth(val.getMonth() - 13))));
    }

    return (
        <>
            <Form.ControlLabel column="sm">기간</Form.ControlLabel>
            <Row className="select-wrap">
                <Col>
                    <InputGroup>
                        <DatePicker oneTap block size="sm" style={{width: '100%'}} 
                            value={keyword.sMonth ? new Date(keyword.sMonth)  : new Date()}
                            ranges={[
                                {
                                label: '이번달',
                                value: new Date()
                                }
                            ]}
                            format="yyyy-MM"
                            onChange={onChangeDateStart} 
                            cleanable={false}
                        />
                        <InputGroup.Addon>~</InputGroup.Addon>
                        <DatePicker oneTap  block size="sm" style={{width: '100%'}} 
                            value={keyword.eMonth ? new Date(keyword.eMonth)  : new Date()}
                            ranges={[
                                {
                                label: '이번달',
                                value: new Date()
                                }
                            ]}
                            format="yyyy-MM"
                            onChange={onChangeDateEnd} 
                            cleanable={false}
                        />
                    </InputGroup>
                </Col>
            </Row>
        </>
    );

};
export default SeMonth;