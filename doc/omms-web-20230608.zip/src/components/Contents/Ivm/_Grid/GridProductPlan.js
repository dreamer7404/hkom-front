import React, {useEffect, useMemo, useRef} from 'react';
import { AgGridReact } from 'ag-grid-react';
import { CONSTANTS } from '../../../../utils/constants';

const GridProductPlan = ({gridHeight, filterValue, queryResult, limit, activePage, onCellClicked}) => {

    const gridRef = useRef();

    const columnDefs = [
        {
        headerName: '차종',
        children: [
            { headerName:'차종코드', field: 'qltyVehlCd',},
            { headerName:'차종명', field: 'qltyVehlNm' },
            { headerName:'연식', field: 'mdlMdyCd' },
        ],
        },
        {
        headerName: '언어',
        children: [
            { headerName:'지역', field: 'dlExpdPrvsNm',sortable: true},
            { headerName:'언어코드', field: 'langCd',sortable: true},
            { headerName:'언어명', field: 'langCdNm',sortable: true},
        ],
        },
        {
            headerName: '국가코드',
            field: 'dlExpdNatCd',
            spanHeaderHeight: true,
        },
        {
            headerName: '국가명',
            field: 'natNm',
            spanHeaderHeight: true,
        },
        {
            headerName: '생산계획(2주)',
            field: 'prodPlan2week',
            spanHeaderHeight: true,
        },  
        {
            headerName: '단기계획(3일)',
            field: 'prodPlan3Day',
            spanHeaderHeight: true,
        },  
        {
            headerName: 'D+1',
            field: 'a01',
            spanHeaderHeight: true,
        },
        {
            headerName: 'D+2',
            field: 'a02',
            spanHeaderHeight: true,
        },
        {
            headerName: 'D+3',
            field: 'a03',
            spanHeaderHeight: true,
        },
        {
            headerName: 'D+4',
            field: 'a04',
            spanHeaderHeight: true, 
        },
        {
            headerName: 'D+5',
            field: 'a05',
            spanHeaderHeight: true,
        },
        {
            headerName: 'D+6',
            field: 'a06',
            spanHeaderHeight: true,
        },
        {
            headerName: 'D+7',
            field: 'a07',
            spanHeaderHeight: true,
        },
        {
            headerName: 'D+8',
            field: 'a08',
            spanHeaderHeight: true,
        },
        {
            headerName: 'D+9',
            field: 'a09',
            spanHeaderHeight: true,
        },
        {
            headerName: 'D+10',
            field: 'a10',
            spanHeaderHeight: true,
        },
        {
            headerName: 'D+11',
            field: 'a11',
            spanHeaderHeight: true,
        },
        {
            headerName: 'D+12',
            field: 'a12',
            spanHeaderHeight: true,
        },
        {
            headerName: 'D+13',
            field: 'a13',
            spanHeaderHeight: true,
        },
        {
            headerName: 'D+14',
            field: 'a14',
            spanHeaderHeight: true,
        }
    ];

  const defaultColDef = useMemo(() => {
      return {
          initialWidth: 90,
          sortable: true,
          resizable:true,
      };
  }, []);

  const onFirstDataRendered = (params) => {
      params.api.sizeColumnsToFit();
  };

  useEffect(()=>{
    if(queryResult.status === 'loading' && gridRef && gridRef.current && gridRef.current.api){
        gridRef.current.api.showLoadingOverlay();
    }
  },[queryResult]);

  useEffect(()=> {
    if(gridRef && gridRef.current && gridRef.current.api){
      gridRef.current.api.setQuickFilter(filterValue);
    }
  },[filterValue]);

  useEffect(()=> {
    if(gridRef && gridRef.current && gridRef.current.api){
      gridRef.current.api.paginationGoToPage(activePage-1);
    }
  },[activePage]);


  return(
      <div className="ag-theme-alpine" style={{height: gridHeight, transition:'all ease .3s'}}>
        <AgGridReact
            ref={gridRef} 
            rowData={queryResult && queryResult.data} 
            columnDefs={columnDefs}
            defaultColDef={defaultColDef}

            // paging
            pagination={true}
            paginationPageSize={limit} //
            suppressPaginationPanel={true} 

            //  filter
            cacheQuickFilter={true}

            // overlay
            overlayLoadingTemplate={CONSTANTS.gridLoading}
            overlayNoRowsTemplate={CONSTANTS.gridNoRows}

            onFirstDataRendered={onFirstDataRendered}
            suppressSizeToFit={true}    
            onGridSizeChanged={onFirstDataRendered}    
            >
        </AgGridReact>
    </div>
  )


};
export default GridProductPlan;