package com.oms.stm.controller;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import able.cloud.core.web.HController;

import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.oms.cmm.global.Consts;
import com.oms.cmm.utils.Utils;
import com.oms.common.dto.CommReqDTO;
import com.oms.common.service.CommService;
import com.oms.stm.dto.LangMgmtReqDTO;
import com.oms.stm.dto.LangMgmtResDTO;
import com.oms.stm.dto.NatlMgmtReqDTO;
import com.oms.stm.dto.NatlMgmtResDTO;
import com.oms.stm.dto.StmComReqDTO;
import com.oms.stm.model.NatlMgmt;
import com.oms.stm.service.NatlMgmtService;
import com.oms.sys.dto.CodeMgmtReqDTO;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;


/**
 * <pre>
 * NatlMgmt Controller
 * </pre>
 *
 * @ClassName   : NatlMgmtController.java
 * @Description : 클래스 설명을 기술합니다.
 * @author 안경수
 * @since 2023.1.6
 * @see
 */
@Tag(name = "NatlMgmtController", description = "")
@RequiredArgsConstructor
@RestController
@RequestMapping("/api")
public class NatlMgmtController extends HController {

    /**
     * 클래스 Injection
     */
    private final HttpServletRequest request;
	private final NatlMgmtService natlMgmtService;
    private final CommService commService;


    @Operation(summary = "국가별 언어코드목록")
    @GetMapping("/natlMsts")
     public List<NatlMgmtResDTO>natlMsts(StmComReqDTO dto) throws Exception {
        NatlMgmtResDTO resDto = new NatlMgmtResDTO();
        CommReqDTO comDto = new CommReqDTO();


            dto.setUserEeno(Utils.getUserEeno(request));
            comDto.setUserEeno(Utils.getUserEeno(request));
            List<NatlMgmtResDTO> natlCdMstList = natlMgmtService.selectNatlCdMstList(dto);//국가언어코드
            resDto.setNatlCdMstList(natlCdMstList);
//            List<LangMgmtResDTO> dlExpdRegnCdList = commService.selectDlExpdRegnCdList(comDto); //쿼리확인필요
//            resDto.setVehlList(dlExpdRegnCdList);
            return natlCdMstList;
    }
    @Operation(summary = "국가별 언어코드저장")
    @Parameter(in = ParameterIn.HEADER, name="_method", schema=@Schema(type="string"))
    @PostMapping("/natlMst")
    public Integer natlMst(NatlMgmtResDTO dto) throws Exception {

        String method = Utils.getMethod(request);
        int result =0;
        dto.setUserEeno(Utils.getUserEeno(request));
//            hmap.put("dlExpdNatCd", request.getParameter("RdlExpdNatCd"));
//            hmap.put("natNm", request.getParameter("RnatNm"));
//            hmap.put("dlExpdRegnCd", request.getParameter("RdlExpdRegnCd"));
        //화면에서 전달해줄 내용
        if(method.equals(Consts.INSERT)) {
            result += natlMgmtService.insertNatlCdMst(dto);
        }  else if (method.equals(Consts.UPDATE)) {
            result +=natlMgmtService.updateNatlCdMst(dto);
        }   else if (method.equals(Consts.DELETE)) {
            result +=natlMgmtService.deleteNatlCdMst(dto);
        }
        return result;
    }

//
//    @RequestMapping(value = "natlLangMgmts", method = {RequestMethod.GET, RequestMethod.POST})
//
//    @Operation(summary = "국가별 언어코드목록")
//    @GetMapping("/natlMsts")
//    public NatlMgmtResDTO natlLangList(StmComReqDTO dto) throws Exception {
//        NatlMgmtResDTO resDto = new NatlMgmtResDTO();
//        HMap sysDate = commService.getSysdate(hmap);
//        String myDate = (String) sysDate.get("sysDate");
//        myDate = myDate.substring(2, 4);
//
//        String mdlMdyCd = dto.getMdlMdyCd() == null ? myDate : dto.getMdlMdyCd();
//        String natlCd = request.getParameter("natlCd");
//        String natlNm = request.getParameter("natlNm");
//
//        if(natlCd != null  ){
//            natlCd = natlCd.toUpperCase();
//        }
//        if(natlNm != null  ){
//            natlNm = natlNm.toUpperCase();
//        }
//            hmap.put("natlCd",natlCd);
//            hmap.put("natlNm",natlNm);
//
//        String dlExpdRegnCd = request.getParameter("dlExpdRegnCd");
//        String langCd = request.getParameter("langCd");
//        String qltyVehlCd = request.getParameter("qltyVehlCd");
//
//            mv.addObject("mdlMdyCd", mdlMdyCd);
//            mv.addObject("natlCd", natlCd);
//            mv.addObject("natlNm", natlNm);
//            mv.addObject("dlExpdRegnCd", dlExpdRegnCd);
//            mv.addObject("langCd", langCd);
//            mv.addObject("qltyVehlCd", qltyVehlCd);
//
//        List<NatlMgmtResDTO> dlExpdRegnCdList = commService.selectDlExpdRegnCdList(dto);
//            mv.addObject("dlExpdRegnCdList", dlExpdRegnCdList);
//            resDto.setDlExpdRegnCdList(dlExpdRegnCdList);
//
//            hmap.put( "dlExpdGCd", "0008" );
//        List<NatlMgmtResDTO> regnCdList = commService.selectCodeList(dto);
//            mv.addObject("regnCdList", regnCdList);
//
//        List<NatlMgmtResDTO> langCdList = commService.selectLangCdList(hmap);
//            mv.addObject("langCdList", langCdList);
//
//        List<NatlMgmtResDTO> vehlList = commService.selectQltyVehlCdList(comDto);
//
//            mv.addObject("vehlList", vehlList);
//
//        List<NatlMgmtResDTO> LangClumList = natlMgmtService.selectNatlLangClumList(dto);
//            mv.addObject("LangClumList", LangClumList);
//            mv.addObject("clumSize", LangClumList.size());
//
//            hmap.put("col1","X");
//            hmap.put("col2","X");
//            hmap.put("col3","X");
//            hmap.put("col4","X");
//            hmap.put("col5","X");
//            hmap.put("col6","X");
//            hmap.put("col7","X");
//            hmap.put("col8","X");
//            hmap.put("col9","X");
//            hmap.put("col10","X");
//            hmap.put("col11","X");
//            hmap.put("col12","X");
//            hmap.put("col13","X");
//            hmap.put("col14","X");
//            hmap.put("col15","X");
//            hmap.put("col16","X");
//            hmap.put("col17","X");
//            hmap.put("col18","X");
//            hmap.put("col19","X");
//            hmap.put("col20","X");
//            hmap.put("col21","X");
//            hmap.put("col22","X");
//            hmap.put("col23","X");
//            hmap.put("col24","X");
//            hmap.put("col25","X");
//            hmap.put("col26","X");
//            hmap.put("col27","X");
//            hmap.put("col28","X");
//            hmap.put("col29","X");
//            hmap.put("col30","X");
//            hmap.put("col31","X");
//            hmap.put("col32","X");
//            hmap.put("col33","X");
//            hmap.put("col34","X");
//            hmap.put("col35","X");
//            hmap.put("col36","X");
//            hmap.put("col37","X");
//            hmap.put("col38","X");
//            hmap.put("col39","X");
//            hmap.put("col40","X");
//            hmap.put("col41","X");
//            hmap.put("col42","X");
//            hmap.put("col43","X");
//            hmap.put("col44","X");
//            hmap.put("col45","X");
//            hmap.put("col46","X");
//            hmap.put("col47","X");
//            hmap.put("col48","X");
//            hmap.put("col49","X");
//            hmap.put("col50","X");
//
//            for(int i = 0 ; i < LangClumList.size() ; i++ ){
//
//                String col = "col"+(i+1);
//                String colVehl = LangClumList.get(i).get("qltyVehlCd").toString();
//                if("col1".equals(col)){  hmap.put("col1", colVehl);}
//                if("col2".equals(col)){  hmap.put("col2", colVehl);}
//                if("col3".equals(col)){  hmap.put("col3", colVehl);}
//                if("col4".equals(col)){  hmap.put("col4", colVehl);}
//                if("col5".equals(col)){  hmap.put("col5", colVehl);}
//                if("col6".equals(col)){  hmap.put("col6", colVehl);}
//                if("col7".equals(col)){  hmap.put("col7", colVehl);}
//                if("col8".equals(col)){  hmap.put("col8", colVehl);}
//                if("col9".equals(col)){  hmap.put("col9", colVehl);}
//                if("col10".equals(col)){ hmap.put("col10", colVehl);}
//                if("col11".equals(col)){ hmap.put("col11", colVehl);}
//                if("col12".equals(col)){ hmap.put("col12", colVehl);}
//                if("col13".equals(col)){ hmap.put("col13", colVehl);}
//                if("col14".equals(col)){ hmap.put("col14", colVehl);}
//                if("col15".equals(col)){ hmap.put("col15", colVehl);}
//                if("col16".equals(col)){ hmap.put("col16", colVehl);}
//                if("col17".equals(col)){ hmap.put("col17", colVehl);}
//                if("col18".equals(col)){ hmap.put("col18", colVehl);}
//                if("col19".equals(col)){ hmap.put("col19", colVehl);}
//                if("col20".equals(col)){ hmap.put("col20", colVehl);}
//                if("col21".equals(col)){ hmap.put("col21", colVehl);}
//                if("col22".equals(col)){ hmap.put("col22", colVehl);}
//                if("col23".equals(col)){ hmap.put("col23", colVehl);}
//                if("col24".equals(col)){ hmap.put("col24", colVehl);}
//                if("col25".equals(col)){ hmap.put("col25", colVehl);}
//                if("col26".equals(col)){ hmap.put("col26", colVehl);}
//                if("col27".equals(col)){ hmap.put("col27", colVehl);}
//                if("col28".equals(col)){ hmap.put("col28", colVehl);}
//                if("col29".equals(col)){ hmap.put("col29", colVehl);}
//                if("col30".equals(col)){ hmap.put("col30", colVehl);}
//                if("col31".equals(col)){ hmap.put("col31", colVehl);}
//                if("col32".equals(col)){ hmap.put("col32", colVehl);}
//                if("col33".equals(col)){ hmap.put("col33", colVehl);}
//                if("col34".equals(col)){ hmap.put("col34", colVehl);}
//                if("col35".equals(col)){ hmap.put("col35", colVehl);}
//                if("col36".equals(col)){ hmap.put("col36", colVehl);}
//                if("col37".equals(col)){ hmap.put("col37", colVehl);}
//                if("col38".equals(col)){ hmap.put("col38", colVehl);}
//                if("col39".equals(col)){ hmap.put("col39", colVehl);}
//                if("col40".equals(col)){ hmap.put("col40", colVehl);}
//                if("col41".equals(col)){ hmap.put("col41", colVehl);}
//                if("col42".equals(col)){ hmap.put("col42", colVehl);}
//                if("col43".equals(col)){ hmap.put("col43", colVehl);}
//                if("col44".equals(col)){ hmap.put("col44", colVehl);}
//                if("col45".equals(col)){ hmap.put("col45", colVehl);}
//                if("col46".equals(col)){ hmap.put("col46", colVehl);}
//                if("col47".equals(col)){ hmap.put("col47", colVehl);}
//                if("col48".equals(col)){ hmap.put("col48", colVehl);}
//                if("col49".equals(col)){ hmap.put("col49", colVehl);}
//                if("col50".equals(col)){ hmap.put("col50", colVehl);}
//            }
//
//        List<HMap> NatlLangList = natlMgmtService.selectNatlLangList(hmap);
//            mv.addObject("NatlLangList", NatlLangList);
//
//        List<HMap> natlMstList = natlMgmtService.selectNatlCdMstList(hmap);
//            mv.addObject("natlMstList", natlMstList);
//
//        List<HMap> blkListCd = natlMgmtService.selectNatlBlkList(hmap);
//            mv.addObject("blkListCd", blkListCd);
//
//
//        return mv;
//    }
    @Operation(summary = "국가별 언어코드저장")
    @Parameter(in = ParameterIn.HEADER, name="_method", schema=@Schema(type="string"))
    @PostMapping("/natlVehlMgmtRegnUpd")
    public Integer natlVehlMgmtRegnUpd(NatlMgmtReqDTO dto) {
        int result = 0;
        dto.setUserEeno(Utils.getUserEeno(request));



//            String qltyVehlCd = request.getParameter("qltyVehlCd");
//            String dlExpdNatCd = request.getParameter("dlExpdNatCd");
//            String dlExpdRegnCd = request.getParameter("dlExpdRegnCd");
//                hmap.put("qltyVehlCd", qltyVehlCd);
//                hmap.put("dlExpdNatCd", dlExpdNatCd);
//                hmap.put("dlExpdRegnCd", dlExpdRegnCd);

        result = natlMgmtService.updateNatlVehlMgmt(dto);

        /** LOG_USE Start =========================================================*/

        /** LOG_USE END ===========================================================*/

        return result;
    }

















}