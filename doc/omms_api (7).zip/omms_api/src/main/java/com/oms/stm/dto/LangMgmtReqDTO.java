package com.oms.stm.dto;

import java.sql.Timestamp;
import java.util.List;

import org.apache.ibatis.type.Alias;

import com.oms.common.dto.CommReqDTO;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;


/**
 * <pre>
 * Statements
 * </pre>
 * @ClassName : LangMgmtReqDTO.java
 * @Description :
 * @author 김경훈
 * @since 2023. 3. 23.
 * @see
 */
@Alias("langMgmtReqDTO")
@Data
@AllArgsConstructor
public class LangMgmtReqDTO extends CommReqDTO {

    @Schema(type = "string", example = " ")
    private String userId;
    @Schema(type = "string", example = " ")
    private String langCd;
    @Schema(type = "string", example = " ")
    private String langCdNm;
    @Schema(type = "string", example = " ")
    private String useYn;
    @Schema(type = "string", example = " ")
    private String dlExpdRegnCd;
    @Schema(type = "string", example = " ")
    private String pprrEeno;
    @Schema(type = "string", example = " ")
    private String chkVal;
    @Schema(type = "string", example = " ")
    private String multiGbn;
    List<String> itemList;



}
