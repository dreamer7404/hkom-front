package com.oms.stm.service.impl;

import java.util.List;

import able.cloud.core.service.HService;
import org.springframework.stereotype.Service;
import com.oms.stm.dao.PrntPageMgmtDAO;
import com.oms.stm.dto.PrntPageMgmtReqDTO;
import com.oms.stm.dto.PrntPageMgmtResDTO;
import com.oms.stm.dto.StmComReqDTO;
import com.oms.stm.service.PrntPageMgmtService;

import lombok.RequiredArgsConstructor;


/**
 * <pre>
 * Statements
 * </pre>
 * @ClassName : PrntPageMgmtServiceImpl.java
 * @Description :
 * @author 김경훈
 * @since 2023. 4. 4.
 * @see
 */
@RequiredArgsConstructor
@Service("PrntPageMgmtService")
public class PrntPageMgmtServiceImpl extends HService implements PrntPageMgmtService {

    private final PrntPageMgmtDAO prntPageMgmtDao;

    /*
     * @see com.oms.stm.service.PrntPageMgmtService#selectPrntPageList(com.oms.stm.dto.PrntPageMgmtReqDTO)
     */
    @Override
    public List<PrntPageMgmtResDTO> selectPrntPageList(StmComReqDTO dto) {
        // TODO Auto-generated method stub
        return prntPageMgmtDao.selectPrntPageList(dto);
    }

    /*
     * @see com.oms.stm.service.PrntPageMgmtService#selectMaxDeppc1Sn(com.oms.stm.dto.StmComReqDTO)
     */
    @Override
    public int selectMaxDeppc1Sn(StmComReqDTO dto) {
        // TODO Auto-generated method stub
        return prntPageMgmtDao.selectMaxDeppc1Sn(dto);
    }

    /*
     * @see com.oms.stm.service.PrntPageMgmtService#validChk(com.oms.stm.dto.PrntPageMgmtReqDTO)
     */
    @Override
    public String validChk(PrntPageMgmtReqDTO dto) {
        // TODO Auto-generated method stub
        return prntPageMgmtDao.validChk(dto);
    }

    /*
     * @see com.oms.stm.service.PrntPageMgmtService#insertPrntPage(com.oms.stm.dto.PrntPageMgmtReqDTO)
     */
    @Override
    public int insertPrntPage(PrntPageMgmtReqDTO dto) {
        return prntPageMgmtDao.insertPrntPage(dto);

    }

    /*
     * @see com.oms.stm.service.PrntPageMgmtService#deletePrntPage(com.oms.stm.dto.PrntPageMgmtReqDTO)
     */
    @Override
    public int deletePrntPage(PrntPageMgmtReqDTO dto) {
        // TODO Auto-generated method stub
        return prntPageMgmtDao.deletePrntPage(dto);
    }

}





