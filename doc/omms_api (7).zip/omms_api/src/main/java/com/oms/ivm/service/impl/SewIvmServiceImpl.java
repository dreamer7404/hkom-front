package com.oms.ivm.service.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import able.cloud.core.service.HService;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.oms.ivm.dao.SewIvmDAO;
import com.oms.ivm.dto.ComIvmReqDTO;
import com.oms.ivm.dto.SewonIvModReqDTO;
import com.oms.ivm.dto.SewonIvModResDTO;
import com.oms.ivm.dto.SewonIvmReqDTO;
import com.oms.ivm.dto.SewonIvmResDTO;
import com.oms.ivm.dto.SewonWhotReqDTO;
import com.oms.ivm.dto.SewonWhotResDTO;
import com.oms.ivm.model.TbSewhaWhotInfo;
import com.oms.ivm.service.SewIvmService;

import lombok.RequiredArgsConstructor;

/**
 * <pre>
 * totalStockService
 * </pre>
 *
 * @author 김정웅
 * @since 2023. 3. 7.
 * @see
 */
@RequiredArgsConstructor
@Service("sewIvmService")
public class SewIvmServiceImpl extends HService implements SewIvmService {

    private final SewIvmDAO sewIvmDAO;

    @Override
    public List<SewonIvmResDTO> selectSewonIvmList(SewonIvmReqDTO sewonIvmReqDTO) throws Exception {
        String bDate = sewonIvmReqDTO.getBDate();
        HashMap<String, String> validMdlMdy4 = sewIvmDAO.selectValidMdlMdy4(bDate);

        sewonIvmReqDTO.setPFromMdlMdy(validMdlMdy4.get("P_FROM_MDL_MDY"));
        sewonIvmReqDTO.setPToMdlMdy(validMdlMdy4.get("P_TO_MDL_MDY"));

        List<SewonIvmResDTO> result = new ArrayList<SewonIvmResDTO>();
        result = sewIvmDAO.selectSewonIvmListAll(sewonIvmReqDTO);

        return result;
    }

    @Override
    public List<SewonWhotResDTO> selectSewonWhotList(ComIvmReqDTO reqDto) throws Exception {

        List<SewonWhotResDTO> result = new ArrayList<SewonWhotResDTO>();
        result = sewIvmDAO.selectSewonWhotList(reqDto);
        return result;
    }

    @Override
    public Integer updateSewonWhotList(List<SewonWhotReqDTO> reqDto, String userEeno) throws Exception {
        Integer totalResult = 0;
        for(SewonWhotReqDTO param : reqDto) {
            param.setUserEeno(userEeno);
            int result = sewIvmDAO.updateSewonWhotList(param);
            if(result == 0) {
                result = sewIvmDAO.insertSewonWhotList(param);
            }
            totalResult += result;
        }
        return totalResult;
    }

    @Override
    public Integer deleteSewonWhotList(List<SewonWhotReqDTO> reqDto, String userEeno) throws Exception {
        Integer totalResult = 0;
        for(SewonWhotReqDTO param : reqDto) {
            totalResult += sewIvmDAO.deleteSewonWhotList(param);
        }
        return totalResult;
    }

    @Override
    public List<SewonIvModResDTO> selectIvModList(ComIvmReqDTO reqDto) throws Exception {
        List<SewonIvModResDTO> result = new ArrayList<SewonIvModResDTO>();
        result = sewIvmDAO.selectIvModList(reqDto);
        return result;
    }

    @Override
    @Transactional
    public Integer insertIvModList(List<SewonIvModReqDTO> reqDto, String userEeno, String dlExpdCoCd) throws Exception {
        Integer result = 1;
        try {
            for(SewonIvModReqDTO param : reqDto) {
                param.setUserEeno(userEeno);
                param.setDlExpdCoCd(dlExpdCoCd);

                //이전 보정을 수정 할 경우 원복 Start============================
                if(!"0".equals(param.getDtlSn())){

                    //--재고 보정 추가 삭제 구분 (삭제 이므로 - 를 + , + 를 -로
                    String modCd = param.getOriModCd();
                    if("05".equals(modCd) || "06".equals(modCd) || "11".equals(modCd)){
                        //여길 어떻게 처리할까........ 05/02
                        param.setOriModQty(Math.abs(param.getOriModQty()))  ;
                    }else{
                        param.setOriModQty(Math.abs(param.getOriModQty()) * (-1));
                    }

                    param.setModQty(param.getOriModQty());
                    param.setModCd(param.getOriModCd());

                    //출고 삭제 (del_yn : Y)
                    sewIvmDAO.deleteIvModInfo(param);
                    //수정 재고
                    sewIvmDAO.updateIvModInfo(param);
                    //수정 재고 상세
                    sewIvmDAO.updateIvDtlModInfo(param);
                }
                //이전 보정을 수정 할 경우 원복 End============================

                String modCd = param.getModCd();

                //--재고 보정 추가 삭제 구분
                if("05".equals(modCd) || "06".equals(modCd) || "11".equals(modCd)){
                    param.setModQty(Math.abs(param.getModQty()) * (-1));
                }else{
                    param.setModQty(Math.abs(param.getModQty()));
                }

                // 수정 Start : 출고 테이블 이므로 + 는 - 로 표기.......... - 는 + 로 표기.....
                    // 1. TB_SEWHA_IV_INFO, 2. TB_SEWHA_IV_INFO_DTL, 3.TB_SEWHA_IV_INFO_DTL
                    // 재고 - [07, 추가출고], [02, 별도지급], [03, 폐기], [08, 반출], 12, 재고실사(-)]
                    // 재고 + [05, 추가입고], [06, 전시차], [11, 재고실사(+)]

                // 출고 Table 입력
                sewIvmDAO.insertIvModList(param);
                // 수정 재고
                sewIvmDAO.updateIvModInfo(param);
                // 수정 재고 상세
                sewIvmDAO.updateIvDtlModInfo(param);
                // 수정 End
            }
            return result;
        } catch(RuntimeException e) {
            e.printStackTrace();
            return 0;
        } catch(Exception e) {
            e.printStackTrace();
            return 0;
        }
    }

    @Override
    public Integer deleteIvModList(List<SewonIvModReqDTO> reqDto, String userEeno, String dlExpdCoCd) throws Exception {
        Integer result = 1;
        try {
            for(SewonIvModReqDTO param : reqDto) {
                param.setUserEeno(userEeno);
                param.setDlExpdCoCd(dlExpdCoCd);

                String modCd = param.getModCd();

                if("05".equals(modCd) || "06".equals(modCd) || "11".equals(modCd)){
                    param.setModQty(Math.abs(param.getModQty()));
                }else{
                    param.setModQty(Math.abs(param.getModQty()) * (-1));
                }

                // 수정 Start : 출고 테이블 이므로 + 는 - 로 표기.......... - 는 + 로 표기.....
                // 1. TB_SEWHA_IV_INFO, 2. TB_SEWHA_IV_INFO_DTL, 3.TB_SEWHA_IV_INFO_DTL
                // 재고 - [07, 추가출고], [02, 별도지급], [03, 폐기], [08, 반출], 12, 재고실사(-)]
                // 재고 + [05, 추가입고], [06, 전시차], [11, 재고실사(+)]

                // 출고 삭제 (del_yn : Y)
                sewIvmDAO.deleteIvModInfo(param);
                // 수정 재고
                sewIvmDAO.updateIvModInfo(param);
                // 수정 재고 상세
                sewIvmDAO.updateIvDtlModInfo(param);
            }
        } catch(RuntimeException e) {
            e.printStackTrace();
            return 0;
        } catch(Exception e) {
            e.printStackTrace();
            return 0;
        }
        return result;
    }





}
