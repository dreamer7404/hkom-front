package com.oms.ivm.dto;

import org.apache.ibatis.type.Alias;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @author 김정웅
 * @since 2023. 3. 27.
 * @see
 */

@Alias("sewonWhotResDTO")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class SewonWhotResDTO {

    private String expdCoNm;
    private String expdRqScnNm;
    private String qltyVehlCd;
    private String qltyVehlNm;
    private String mdlMdyCd;
    private String dlExpdPrvsNm;
    private String langCd;
    private String langCdNm;
    private String newPrntPbcnNo;
    private String ivQty;
    private String rqQty;
    private String dlExpdBoxQty;
    private String dlvgParrYmd;
    private String dlvgParrHhmm;
    private String pwtiNm;
    private String pwtiTn;
    private String prtlImtrSbc;
    private String dlExpdMdlMdyCd;
    private String dtlSn;
    private String dlExpdRqScnCd;   //구분  ex)일반, 별도
    private String pwtiEeno;
    private String langSortSn;
    private String clScnCd;
    private String dataSn;

}
