package com.oms.ivm.dao;

import java.util.HashMap;
import java.util.List;

import com.oms.ivm.dto.ComIvmReqDTO;
import com.oms.ivm.dto.SewonIvModReqDTO;
import com.oms.ivm.dto.SewonIvModResDTO;
import com.oms.ivm.dto.SewonIvmReqDTO;
import com.oms.ivm.dto.SewonIvmResDTO;
import com.oms.ivm.dto.SewonWhotReqDTO;
import com.oms.ivm.dto.SewonWhotResDTO;

/**
 * <pre>
 * SewIvmDAO 인터페이스
 * </pre>
 *
 * @Class Name  : SewIvmDAO.java
 * @Description : 재고관리 > 세원재고관리 DAO
 * @author 김정웅
 * @since 2023.3.27
 * @see
*/
public interface SewIvmDAO {

    //기준일 기준 48개월 전 12개월 후의 연도 출력
    HashMap<String, String> selectValidMdlMdy4(String sdate)throws Exception;

    //날짜 정보
    List<SewonIvmResDTO> selectSewonIvmListAll(SewonIvmReqDTO sewonIvmReqDTO)throws Exception;
    List<SewonIvmResDTO> selectSewonIvmList01(SewonIvmReqDTO sewonIvmReqDTO)throws Exception;
    List<SewonIvmResDTO> selectSewonIvmList02(SewonIvmReqDTO sewonIvmReqDTO)throws Exception;


    //출고현황 조회
    List<SewonWhotResDTO> selectSewonWhotList(ComIvmReqDTO reqDto) throws Exception;
    //출고현황 등록
    Integer insertSewonWhotList(SewonWhotReqDTO reqDto) throws Exception;
    //출고현황 수정
    Integer updateSewonWhotList(SewonWhotReqDTO reqDto) throws Exception;
    //출고현황 삭제
    Integer deleteSewonWhotList(SewonWhotReqDTO reqDto) throws Exception;

    //재고보정 조회
    List<SewonIvModResDTO> selectIvModList(ComIvmReqDTO reqDto) throws Exception;
    //재고보정 수정
    Integer insertIvModList(SewonIvModReqDTO reqDto) throws Exception;
    //재고 삭제
    Integer deleteIvModInfo(SewonIvModReqDTO reqDto);
    //재고 수정
    Integer updateIvModInfo(SewonIvModReqDTO reqDto);
    //재고 상세 수정
    Integer updateIvDtlModInfo(SewonIvModReqDTO reqDto);

}
