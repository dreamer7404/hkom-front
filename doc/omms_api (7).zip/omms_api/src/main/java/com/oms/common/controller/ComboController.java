package com.oms.common.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.oms.cmm.security.JwtTokenProvider;
import com.oms.cmm.utils.Utils;
import com.oms.common.dto.CodeComboResDTO;
import com.oms.common.dto.ComboReqDTO;
import com.oms.common.dto.GrpComboResDTO;
import com.oms.common.dto.LangComboResDTO;
import com.oms.common.dto.PdiComboResDTO;
import com.oms.common.dto.RegionComboResDTO;
import com.oms.common.dto.SubCdComboResDTO;
import com.oms.common.dto.VehlComboResDTO;
import com.oms.common.service.ComboService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;

/**
 * <pre>
 * 조회조건 목록을 가져온다
 * </pre>
 *
 * @author 안경수
 * @since 2023. 3. 22.
 * @see
 */
@Tag(name = "ComboController", description = "")
@RequiredArgsConstructor
@RestController
@RequestMapping("/api")
public class ComboController {

    /**
     * 클래스 Injection
     */
    private final HttpServletRequest request;
    private final ComboService comboService;


    /**
     * PDI combo용 조회
     */
    @Operation(summary = "PDI combo용 조회")
    @GetMapping("/pdiCombo")
    public List<PdiComboResDTO> selectPdiComboList(@ModelAttribute ComboReqDTO comboReqDTO) throws Exception {
        comboReqDTO.setUserEeno(Utils.getUserEeno(request));
        comboReqDTO.setDlExpdCoCd(Utils.getDlExpdCoCd(request)); // 회사코드
        return comboService.selectPdiComboList(comboReqDTO);
    }
    /**
     * 차량코드 combo용 조회
     */
    @Operation(summary = "차량코드 combo용 조회")
    @GetMapping("/vehlCombo")
    public List<VehlComboResDTO> selectVehlComboList(@ModelAttribute ComboReqDTO comboReqDTO) throws Exception {
        comboReqDTO.setUserEeno(Utils.getUserEeno(request)); // 사원번호
        return comboService.selectVehlComboList(comboReqDTO);
    }

    /**
     * 차량연식 combo용 조회
     */
    @Operation(summary = "차량연식 combo용 조회")
    @GetMapping("/mdyCombo")
    public List<String> selectMdyComboList(@ModelAttribute ComboReqDTO comboReqDTO) throws Exception {
        return comboService.selectMdyComboList(comboReqDTO);
    }

    /***
     *
     * 지역코드 combo용 조회
     *
     * @param
     *  - bData        기준일(*)
     *  - userEeno     사원번호
     *  - dlExpdPdiCd  PDI코드
     *  - qltyVehlCd   차량안전코드
     *  - mdlMdyCd     차량연식
     */
    @Operation(summary = "지역코드 combo용 조회")
    @GetMapping("/regionCombo")
    public List<RegionComboResDTO> selectRegionComboList(@ModelAttribute ComboReqDTO comboReqDTO) throws Exception {
        comboReqDTO.setUserEeno(Utils.getUserEeno(request)); // 사원번호
        List<RegionComboResDTO> list = comboService.selectRegionComboList(comboReqDTO);
        return list;
    }

    /***
    *
    * 언어코드 combo용 조회
    *
    * @param
    *  - bData        기준일(*)
    *  - userEeno     사원번호
    *  - dlExpdPdiCd  PDI코드
    *  - qltyVehlCd   차량안전코드
    *  - mdlMdyCd     차량연식
    *  - dlExpdRegnCd  지역코드
    */
   @Operation(summary = "언어코드 combo용 조회")
   @GetMapping("/langCombo")
   public List<LangComboResDTO> selectLangComboList(@ModelAttribute ComboReqDTO comboReqDTO) throws Exception {
       comboReqDTO.setUserEeno(Utils.getUserEeno(request)); // 사원번호
       List<LangComboResDTO> list = comboService.selectLangComboList(comboReqDTO);
       return list;
   }

       /***
       *
       * 서브코드 combo용 조회
       *
       * @param
       *  - mainCd        그룹코드

       */
      @Operation(summary = "서브코드 combo용 조회")
      @GetMapping("/subCdCombo")
      public List<SubCdComboResDTO> selectSubCdComboList(@RequestParam String mainCd) throws Exception {
          List<SubCdComboResDTO> list = comboService.selectSubCdComboList(mainCd);
          return list;
      }

      /***
      *
      * 코드테이블 combo용 조회
      *
      */
     @Operation(summary = "코드테이블 combo용 조회")
     @GetMapping("/codeCombo")
     public List<CodeComboResDTO> selectCodeComboList(String dlExpdGCd) throws Exception {
         List<CodeComboResDTO> list = comboService.selectCodeComboList(dlExpdGCd);
         return list;
     }


     /***
     *
     * 그룹테이블 combo용 조회
     *
     */
    @Operation(summary = "그룹테이블 combo용 조회")
    @GetMapping("/grpCombo")
    public List<GrpComboResDTO> selectGrpComboList() throws Exception {
        List<GrpComboResDTO> list = comboService.selectGrpComboList();
        return list;
    }


}
