package com.oms.stm.dao;

import java.util.List;



import com.oms.stm.dto.PrntPageMgmtReqDTO;
import com.oms.stm.dto.PrntPageMgmtResDTO;
import com.oms.stm.dto.StmComReqDTO;


/**
 * <pre>
 * Statements
 * </pre>
 * @ClassName : PrntPageMgmtDAO.java
 * @Description :
 * @author 김경훈
 * @since 2023. 4. 4.
 * @see
 */
public interface PrntPageMgmtDAO {
        /**
     * Statements
     *
     * @param dto
     * @return
     */
        List<PrntPageMgmtResDTO> selectPrntPageList(StmComReqDTO dto);

        /**
         * Statements
         *
         * @param dto
         * @return
         */
        int selectMaxDeppc1Sn(StmComReqDTO dto);

        /**
         * Statements
         *
         * @param dto
         * @return
         */
        String validChk(PrntPageMgmtReqDTO dto);

        /**
         * Statements
         *
         * @param dto
         * @return
         */
        int insertPrntPage(PrntPageMgmtReqDTO dto);

        /**
         * Statements
         *
         * @param dto
         * @return
         */
        int deletePrntPage(PrntPageMgmtReqDTO dto);

}
