package com.oms.stm.service;

import java.util.List;

import com.oms.common.dto.CommReqDTO;
import com.oms.stm.dto.LangMgmtReqDTO;
import com.oms.stm.dto.LangMgmtResDTO;
import com.oms.stm.dto.NatlMgmtReqDTO;
import com.oms.stm.dto.NatlMgmtResDTO;
import com.oms.stm.dto.StmComReqDTO;


/**
 * <pre>
 * NatlMgmtService
 * </pre>
 *
 * @ClassName   : NatlMgmtService.java
 * @Description :
 * @author 안경수
 * @since 2023.1.6
 * @see
 */

public interface NatlMgmtService {


    /**
     * Statements
     *
     * @param dto
     * @return
     */
    List<NatlMgmtResDTO> selectNatlCdMstList(StmComReqDTO dto);

    /**
     * Statements
     *
     * @param dto
     * @return
     */
    int insertNatlCdMst(NatlMgmtResDTO dto);

    /**
     * Statements
     *
     * @param dto
     */
    int updateNatlCdMst(NatlMgmtResDTO dto);

    /**
     * Statements
     *
     * @param dto
     */
    int deleteNatlCdMst(NatlMgmtResDTO dto);

    /**
     * Statements
     *
     * @param dto
     * @return
     */
    int updateNatlVehlMgmt(NatlMgmtReqDTO dto);

}
