package com.oms.stm.service;

import java.util.HashMap;
import java.util.List;


import com.oms.stm.dto.NatlMgmtReqDTO;
import com.oms.stm.dto.NatlMgmtResDTO;
import com.oms.stm.dto.StmComReqDTO;
import com.oms.stm.dto.VehlMdyMgmtReqDTO;
import com.oms.stm.dto.VehlMdyMgmtResDTO;
import com.oms.stm.dto.VehlMgmtCrgDTO;
import com.oms.stm.dto.VehlMgmtReqDTO;
import com.oms.stm.dto.VehlMgmtResDTO;
import com.oms.sys.dto.AuthVehlSaveDTO;



/**
 * <pre>
 * Statements
 * </pre>
 * @ClassName : VehlMgmtService.java
 * @Description :
 * @author 김경훈
 * @since 2023. 3. 13.
 * @see
 */
public interface VehlMgmtService {

    /**
     * Statements
     *
     * @param vehlReqDTO
     * @return
     */
    List<VehlMgmtResDTO> selectVehlMgmtList(HashMap<String, Object> map);

    /**
     * Statements
     *
     * @param vehlReqDTO
     * @return
     */
    List<VehlMgmtResDTO> selectCpyTgVehl(StmComReqDTO dto);

    /**
     * Statements
     *
     * @param vehlReqDTO
     * @return
     */
    String selectNatlVehlChk(VehlMgmtReqDTO vehlReqDTO);

    /**
     * Statements
     *
     * @param vehlReqDTO
     */
    void insertNatlVehlMgmt(VehlMgmtReqDTO vehlReqDTO);

    /**
     * Statements
     *
     * @param vehlReqDTO
     */
    void deleteVehlLangCp(VehlMgmtReqDTO vehlReqDTO);

    /**
     * Statements
     *
     * @param vehlReqDTO
     */
    void insertVehlLangCopy(VehlMgmtReqDTO vehlReqDTO);

    /**
     * Statements
     *
     * @param vehlReqDTO
     */
    void deleteVehlNatlLang(VehlMgmtReqDTO vehlReqDTO);

    /**
     * Statements
     *
     * @param vehlReqDTO
     */
    void insertVehlNatlLangCpy(VehlMgmtReqDTO vehlReqDTO);

    /**
     * Statements
     *
     * @param vehlReqDTO
     * @return
     */
    List<VehlMgmtResDTO> selectCpyTgNatlVehl(VehlMgmtReqDTO vehlReqDTO);

    /**
     * Statements
     *
     * @param vehlReqDTO
     * @return
     */
    List<VehlMgmtResDTO> selectVehlMgmtNatlLangList(StmComReqDTO dto);

    /**
     *
     * Statements
     *
     * @param vehlReqDTO
     */
    void deleteVehlMgmtCrgr(VehlMgmtReqDTO vehlReqDTO);

    /**
     * Statements
     *
     * @param list
     * @return
     */
    int insertVehlMgmtCrgr(List<AuthVehlSaveDTO> list);

    /**
     * Statements
     *
     * @param vehlReqDTO
     */
    void deleteVehlMgmtRegnRelCd(VehlMgmtReqDTO vehlReqDTO);

    /**
     * Statements
     *
     * @param vehlReqDTO
     */
    void deleteVehlDlExpdMdyMgmt(VehlMgmtReqDTO vehlReqDTO);

    /**
     * Statements
     *
     * @param vehlReqDTO
     */
    void insertVehlMgmtRegnRelCd(VehlMgmtReqDTO vehlReqDTO);

    /**
     * Statements
     *
     * @param vehlReqDTO
     */
    void insertVehlDlExpdMdyMgmt(VehlMgmtReqDTO vehlReqDTO);

    /**
     * Statements
     *
     * @param vehlReqDTO
     */
    void deleteVehlMgmtAltn(VehlMgmtReqDTO vehlReqDTO);

    /**
     * Statements
     *
     * @param vehlReqDTO
     */
    void insertVehlMgmtAltn(VehlMgmtReqDTO vehlReqDTO);

    /**
     * Statements
     *
     * @param vehlReqDTO
     */
    void deleteNatlVehlLang(VehlMgmtReqDTO vehlReqDTO);

    /**
     * Statements
     *
     * @param vehlReqDTO
     */
    void insertNatlVehlLang(VehlMgmtReqDTO vehlReqDTO);

    /**
     * Statements
     *
     * @param vehlReqDTO
     */
    void updateVehlMgmtMain(VehlMgmtReqDTO vehlReqDTO);

    /**
     * Statements
     *
     * @param vo
     * @return
     */
    List<VehlMgmtReqDTO> selectDlExpdMdyPreList(VehlMgmtReqDTO vo);

    /**
     * Statements
     *
     * @param hmap
     * @return
     */
    List<VehlMgmtReqDTO> selectDlExpdMdyNextList(VehlMgmtReqDTO vo);

    /**
     * Statements
     *
     * @param hmap
     * @return
     */
    List<VehlMgmtReqDTO> selectVehlLangList(VehlMgmtReqDTO vo);

    /**
     * Statements
     *
     * @param vo
     */
    void deleteVehlLang(VehlMgmtReqDTO vo);

    /**
     * Statements
     *
     * @param vo
     */
    void insertVehlLangInfo(VehlMgmtReqDTO vo);

    /**
     * Statements
     *
     * @param vehlReqDTO
     * @return
     */
    String selectVehlMgmtCnt(VehlMgmtReqDTO vehlReqDTO);

    /**
     * Statements
     *
     * @param vehlReqDTO
     */
    void insertVehlMgmtMain(VehlMgmtReqDTO vehlReqDTO);

    /**
     * Statements
     *
     * @param vehlReqDTO
     * @return
     */
    List<VehlMgmtResDTO> selectPreVehlMdyChk(VehlMgmtReqDTO vehlReqDTO);

    /**
     * Statements
     *
     * @param reqDto
     * @return
     */
    List<VehlMgmtReqDTO> selectMdyMonth(StmComReqDTO dto);

    /**
     * Statements
     *
     * @param vehlReqDTO
     * @return
     */
    List<VehlMgmtResDTO> getVehlCombo(StmComReqDTO dto);

    /**
     * Statements
     *
     * @param vehlReqDTO
     * @return
     */
    List<VehlMgmtResDTO> getPdiCombo(StmComReqDTO vehlReqDTO);

    /**
     * Statements
     *
     * @param dto
     * @return
     */
    List<VehlMgmtResDTO> selectDlExpdPacScnCdList(StmComReqDTO dto);

    /**
     * Statements
     *
     * @param vehlReqDTO
     * @return
     */
    String selectVehlMdyChk(VehlMgmtReqDTO vehlReqDTO);

    /**
     * Statements
     *
     * @param map
     * @return
     */
    VehlMgmtResDTO selectVehlMgmtInfo(HashMap<String, Object> map);

    /**
     * Statements
     *
     * @param map
     * @return
     */
    List<VehlMgmtCrgDTO> selectVehlChrgList(HashMap<String, Object> map);

    /**
     * Statements
     *
     * @param crgDto
     * @return
     */
    int insertHmcVehlAuth(VehlMgmtCrgDTO crgDto);

    /**
     * Statements
     *
     * @param map
     * @return
     */
    List<HashMap<String, Object>> selectVehlMdyList(HashMap<String, Object> map);

    /**
     * Statements
     *
     * @param dto
     * @return
     */
    VehlMdyMgmtResDTO selectMdyChk1(VehlMdyMgmtReqDTO dto);

    /**
     * Statements
     *
     * @param dto
     * @return
     */
    VehlMdyMgmtResDTO selectMdyChk2(VehlMdyMgmtReqDTO dto);

    /**
     * Statements
     *
     * @param dto
     * @return
     */
    String selectMdyChk3(VehlMdyMgmtReqDTO dto);

    /**
     * Statements
     *
     * @param dto
     * @return
     */
    int insertVehlMdyInfo(VehlMdyMgmtReqDTO dto);

    /**
     * Statements
     *
     * @param dto
     * @return
     */
    int updateVehlMdyInfo(VehlMdyMgmtReqDTO dto);

    /**
     * Statements
     *
     * @param dto
     * @return
     */
    int updateVehlMdyEndInfo(VehlMdyMgmtReqDTO dto);

    /**
     * Statements
     *
     * @param dto
     * @return
     */
    int updateVehlPreMdyInfo(VehlMdyMgmtReqDTO dto);






}
