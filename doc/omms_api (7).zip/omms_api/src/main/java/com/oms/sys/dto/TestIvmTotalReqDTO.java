package com.oms.sys.dto;

import org.apache.ibatis.type.Alias;

import com.oms.common.dto.CommReqDTO;

import lombok.Data;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @author Windows ≫c¿eAU
 * @since 2023. 3. 28.
 * @see
 */
@Data
@Alias("testIvmTotalReqDTO")
public class TestIvmTotalReqDTO extends CommReqDTO {
    private String nTest;
    private String bDate;
    private String dlExpdPdiCd;
    private String qltyVehlCd;
    private String mdlMdyCd;
    private String dlExpdRegnCd;
    private String langCd;
    private String subCd;



}
