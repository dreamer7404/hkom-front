package com.oms.sys.dto;

import javax.validation.constraints.Pattern;

import org.apache.ibatis.type.Alias;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @author Windows ≫c¿eAU
 * @since 2023. 2. 20.
 * @see
 */


@Alias("authReqDTO")
@Data
@NoArgsConstructor
public class AuthReqDTO {
    private String userEeno;     // USER_EENO(tb_usr_mgmt) : VARCHAR(20)
    private String userPw;
    private String userPwNew;
    private String blnsCoCd;     // 회사소속 : VARCHAR(4)
    private String userDcd;     // 부서 : VARCHAR(8)
    private Integer pwErrOft;   // 오류횟수

    public AuthReqDTO(String userEeno, Integer pwErrOft) {
        this.userEeno = userEeno;
        this.pwErrOft = pwErrOft;
    }
}
