package com.oms.common.service;

import java.util.List;

import com.oms.common.dto.CommLangComboReqDTO;
import com.oms.common.dto.CommLangComboResDTO;


/**
 * <pre>
 * CommComboService
 * </pre>
 *
 * @ClassName   : CommComboService.java
 * @Description : 공통 콤보 호출 서비스
 * @author 김정웅
 * @since 2023.3.21.
 * @see
 */

public interface CommComboService {

    public List<CommLangComboResDTO> selectCommLangComboList(CommLangComboReqDTO commLangComboReqDTO) throws Exception;

}
