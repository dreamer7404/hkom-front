package com.oms.sys.model;

import java.sql.Timestamp;

import lombok.Data;

/**
 * <pre>
 * 그룹별 매뉴권한
 * </pre>
 *
 * @author 안경수
 * @since 2023. 3. 9.
 * @see
 */
@Data
public class AuthAffrMgmt {

   private String grpCd;        // 그룹코드 (이전에는 사용자번호 USER_EENO)
   private String menuId;
   private String menuAuthCd;
   private String useYn;
   private String pprrEeno;
   private String framDtm;
   private String updrEeno;
   private String mdfyDtm;
}
