package com.oms.sys.service;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @author Windows ≫c¿eAU
 * @since 2023. 3. 13.
 * @see
 */

public interface TestService {
    public String testBatch() throws Exception;
}
