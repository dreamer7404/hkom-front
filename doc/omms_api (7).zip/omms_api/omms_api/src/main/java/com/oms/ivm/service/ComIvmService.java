package com.oms.ivm.service;

import java.util.HashMap;
import java.util.List;

import com.oms.ivm.dto.ComIvmReqDTO;
import com.oms.ivm.dto.Ivm2WeekPlanReqDTO;
import com.oms.ivm.dto.Ivm2WeekPlanResDTO;
import com.oms.ivm.dto.Ivm3DayPlanReqDTO;
import com.oms.ivm.dto.Ivm3DayPlanResDTO;
import com.oms.ivm.dto.IvmPdiOrYongsanIvResDTO;
import com.oms.ivm.dto.IvmSewonIvReqDTO;
import com.oms.ivm.dto.IvmSewonIvResDTO;
import com.oms.ivm.dto.IvmThisMonTrwiReqDTO;
import com.oms.ivm.dto.IvmThisMonTrwiResDTO;


/**
 * <pre>
 * ComIvmService
 * </pre>
 *
 * @ClassName   : ComIvmService.java
 * @Description : 재고관리 > 공통 서비스
 * @author 김정웅
 * @since 2023.3.13
 * @see
 */

public interface ComIvmService {

    public List<Ivm2WeekPlanResDTO> selectIvm2WeekPlanList(Ivm2WeekPlanReqDTO ivm2WeekPlanReqDTO) throws Exception;
    public List<Ivm3DayPlanResDTO> selectIvm3DayPrdnPlanList(Ivm3DayPlanReqDTO ivm3DayPlanReqDTO) throws Exception;
    public List<IvmThisMonTrwiResDTO> selectIvmThisMonTrwiList(IvmThisMonTrwiReqDTO ivmThisMonTrwiReqDTO) throws Exception;
    public List<IvmSewonIvResDTO> selectIvmSewonIvList(IvmSewonIvReqDTO ivmSewonIvReqDTO) throws Exception;
    public List<IvmPdiOrYongsanIvResDTO> selectIvmPdiOrYongsanIvList(ComIvmReqDTO comIvmReqDTO) throws Exception;

    public HashMap<String,String> getSysDate2() throws Exception;
}
