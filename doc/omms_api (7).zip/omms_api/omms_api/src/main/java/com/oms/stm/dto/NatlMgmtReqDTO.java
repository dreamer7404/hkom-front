package com.oms.stm.dto;

import java.sql.Timestamp;

import org.apache.ibatis.type.Alias;

import com.oms.common.dto.CommReqDTO;

import lombok.AllArgsConstructor;
import lombok.Data;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @author Windows ≫c¿eAU
 * @since 2023. 3. 3.
 * @see
 */
@Alias("natlMgmtReqDTO")
@Data
@AllArgsConstructor
public class NatlMgmtReqDTO extends CommReqDTO {
    private String dlExpdCoCd;     // DL_EXPD_CO_CD(tb_natl_mgmt) : VARCHAR(4)
    private String dlExpdNatCd;     // DL_EXPD_NAT_CD(tb_natl_mgmt) : VARCHAR(5)
    private String dlExpdRegnCd;     // DL_EXPD_REGN_CD(tb_natl_mgmt) : VARCHAR(4)
    private String natNm;     // NAT_NM(tb_natl_mgmt) : VARCHAR(40)
    private String dytmPlnNatCd;     // DYTM_PLN_NAT_CD(tb_natl_mgmt) : VARCHAR(5)
    private String prdnMstNatCd;     // PRDN_MST_NAT_CD(tb_natl_mgmt) : VARCHAR(5)
    private String pprrEeno;     // PPRR_EENO(tb_natl_mgmt) : VARCHAR(20)
    private Timestamp framDtm;     // FRAM_DTM(tb_natl_mgmt) : DATETIME(19)
    private String updrEeno;     // UPDR_EENO(tb_natl_mgmt) : VARCHAR(20)
    private Timestamp mdfyDtm;     // MDFY_DTM(tb_natl_mgmt) : DATETIME(19)
}
