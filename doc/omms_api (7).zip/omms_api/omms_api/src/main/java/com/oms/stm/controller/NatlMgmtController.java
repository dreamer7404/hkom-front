package com.oms.stm.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import able.cloud.core.web.HController;

import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.oms.cmm.global.Consts;
import com.oms.cmm.utils.Utils;
import com.oms.stm.dto.CodeMgmtReqDTO;
import com.oms.stm.dto.NatlMgmtReqDTO;
import com.oms.stm.dto.NatlMgmtResDTO;
import com.oms.stm.model.NatlMgmt;
import com.oms.stm.service.NatlMgmtService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;


/**
 * <pre>
 * NatlMgmt Controller
 * </pre>
 *
 * @ClassName   : NatlMgmtController.java
 * @Description : 클래스 설명을 기술합니다.
 * @author 안경수
 * @since 2023.1.6
 * @see
 */
@Tag(name = "NatlMgmtController", description = "")
@CrossOrigin(origins="*")
@RequiredArgsConstructor
@RestController
@RequestMapping("/api")
public class NatlMgmtController extends HController {

    /**
     * 클래스 Injection
     */
    private final HttpServletRequest request;
	private final NatlMgmtService natlMgmtService;

	/**
     * 국가코드 조회
     */
    @Operation(summary = "국가코드 조회")
    @GetMapping("/natlMgmt")
    public NatlMgmtResDTO selectNatlMgmt(@ModelAttribute NatlMgmtReqDTO natlMgmtReqDTO) throws Exception {
        return natlMgmtService.selectNatlMgmt(natlMgmtReqDTO);
    }

	/**
     * 국가코드 목록을 조회
     */
    @Operation(summary = "국가코드 목록을 조회")
    @GetMapping("/natlMgmts")
    public List<NatlMgmtResDTO> selectNatlMgmtList(@ModelAttribute NatlMgmtReqDTO natlMgmtReqDTO) throws Exception {
        return natlMgmtService.selectNatlMgmtList(natlMgmtReqDTO);
    }

    /**
     * 국가코드정보 등록, 수정, 삭제
     */
    @Operation(summary = "국가코드정보 등록,수정,삭제", description = "")
    @Parameter(in = ParameterIn.HEADER, name="_method", schema=@Schema(type="string"))
    @PostMapping(value = "/natlMgmt")
    public Integer insertNatlMgmt(@RequestBody NatlMgmtReqDTO natlMgmtReqDTO) throws Exception {
        String method = Utils.getMethod(request);
        if(method.equals(Consts.INSERT)) {
            return natlMgmtService.insertNatlMgmt(natlMgmtReqDTO);
        }else if(method.equals(Consts.UPDATE)) {
            return natlMgmtService.updateNatlMgmt(natlMgmtReqDTO);
        }else if(method.equals(Consts.DELETE)) {
            return natlMgmtService.deleteNatlMgmt(natlMgmtReqDTO);
        }
        return 0;
    }


}