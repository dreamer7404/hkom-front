package com.oms.sys.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.oms.sys.dao.UsrMgmtDAO;
import com.oms.sys.dto.UsrMgmtReqDTO;
import com.oms.sys.dto.UsrMgmtResDTO;
import com.oms.sys.model.UsrMgmt;

import lombok.RequiredArgsConstructor;


/**
 * <pre>
 * UsrMgmtService
 * </pre>
 *
 * @ClassName   : UsrMgmtService.java
 * @Description :
 * @author 안경수
 * @since 2023.1.19
 * @see
 */


public interface UsrMgmtService {
    public void insertUsrMgmt(UsrMgmtReqDTO usrMgmtReqDTO) throws Exception;
    public void updateUsrMgmt(UsrMgmt usrMgmt) throws Exception ;
    public void deleteUsrMgmt(UsrMgmt usrMgmt) throws Exception;
    public UsrMgmtResDTO selectUsrMgmt(String id) throws Exception;
    public List<UsrMgmtResDTO> selectUsrMgmtList(UsrMgmtReqDTO usrMgmtReqDTO) throws Exception;
    public void deleteVehlAuth(UsrMgmtReqDTO usrDTO) throws Exception; //등록 or 수정하려는 차종 권한만 삭제 필요 khkim
    public void insertVehlAuth(UsrMgmtReqDTO usrMgmt) throws Exception; //등록 or 수정하려는 차종 권한만 삭제 필요 khkim
    /**
     * Statements
     *
     * @param usrDTO
     */

}
