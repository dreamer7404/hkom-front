package com.oms.stm.service;

import java.util.List;

import com.oms.stm.dto.NatlMgmtReqDTO;
import com.oms.stm.dto.NatlMgmtResDTO;


/**
 * <pre>
 * NatlMgmtService 
 * </pre>
 * 
 * @ClassName   : NatlMgmtService.java
 * @Description : 
 * @author 안경수
 * @since 2023.1.6
 * @see
 */

public interface NatlMgmtService {

    public NatlMgmtResDTO selectNatlMgmt(NatlMgmtReqDTO natlMgmtReqDTO) throws Exception;
    public List<NatlMgmtResDTO> selectNatlMgmtList(NatlMgmtReqDTO natlMgmtReqDTO) throws Exception;
    public Integer insertNatlMgmt(NatlMgmtReqDTO natlMgmtReqDTO) throws Exception;
    public Integer updateNatlMgmt(NatlMgmtReqDTO natlMgmtReqDTO) throws Exception;
    public Integer deleteNatlMgmt(NatlMgmtReqDTO natlMgmtReqDTO) throws Exception;
}
