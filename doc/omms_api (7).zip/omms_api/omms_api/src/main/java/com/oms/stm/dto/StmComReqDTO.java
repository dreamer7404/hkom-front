package com.oms.stm.dto;



import java.util.List;

import org.apache.ibatis.type.Alias;

import com.oms.common.dto.CommReqDTO;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


/**
 * <pre>
 * Statements
 * </pre>
 * @ClassName : VehlMgmtResDTO.java
 * @Description :
 * @author 김경훈
 * @since 2023. 3. 13.
 * @see
 */
@Alias("StmComReqDTO")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class StmComReqDTO extends CommReqDTO {


    //차종관리 공통
    @Schema(type = "string", example = " ")
    private String userId;
    @Schema(type = "string", example = " ")
    private String col1;
    @Schema(type = "string", example = " ")
    private String col2;
    @Schema(type = "string", example = " ")
    private String col3;
    @Schema(type = "string", example = " ")
    private String col4;
    @Schema(type = "string", example = " ")
    private String col5;
    @Schema(type = "string", example = " ")
    private String col6;
    @Schema(type = "string", example = " ")
    private String col7;
    @Schema(type = "string", example = " ")
    private String sdate;
    @Schema(type = "string", example = " ")
    private String mdlMdyCd;
    @Schema(type = "string", example = " ")
    private String pdi;
    @Schema(type = "string", example = " ")
    private String qltyVehlCd;
    @Schema(type = "string", example = " ")
    private String c2qltyVehlCd;
    @Schema(type = "string", example = " ")
    private String nqltyVehlCd;
    @Schema(type = "string", example = " ")
    private String eYm;
    @Schema(type = "string", example = " ")
    private String sYm;
    @Schema(type = "string", example = " ")
    private String dlExpdPacScnCd;
    @Schema(type = "string", example = " ")
    private String dlExpdRegnCd;
}
