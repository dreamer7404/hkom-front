package com.oms.common.service;

import java.util.List;

import com.oms.common.dto.ComboReqDTO;
import com.oms.common.dto.CommReqDTO;
import com.oms.common.dto.PdiComboResDTO;
import com.oms.common.dto.VehlComboResDTO;
import com.oms.stm.dto.LangMgmtResDTO;
import com.oms.stm.dto.StmComReqDTO;
import com.oms.stm.dto.VehlMgmtResDTO;



/**
 * <pre>
 * Statements
 * </pre>
 * @ClassName : CommService.java
 * @Description :
 * @author 김경훈
 * @since 2023. 3. 22.
 * @see
 */
public interface CommService {

    /**
     * Statements
     *
     * @param comDto
     * @return
     */
    List<VehlMgmtResDTO> selectCodeList(CommReqDTO comDto);

    /**
     * Statements
     *
     * @param comDto
     * @return
     */
    List<LangMgmtResDTO> selectDlExpdRegnCdList(CommReqDTO comDto);

    /**
     * Statements
     *
     * @param comDto
     * @return
     */
    List<LangMgmtResDTO> selectLangCdList(CommReqDTO comDto);

    /**
     * Statements
     *
     * @param comDto
     * @return
     */
    List<LangMgmtResDTO> selectQltyVehlCdList(CommReqDTO comDto);

}
