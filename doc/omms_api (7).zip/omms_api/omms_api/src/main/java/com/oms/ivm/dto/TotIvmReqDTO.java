package com.oms.ivm.dto;

import java.sql.Timestamp;

import org.apache.ibatis.type.Alias;

import com.oms.common.dto.CommReqDTO;

import lombok.AllArgsConstructor;
import lombok.Data;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @author 김정웅
 * @since 2023. 3. 7.
 * @see
 */
@Alias("totIvmReqDTO")
@Data
@AllArgsConstructor
public class TotIvmReqDTO extends CommReqDTO {

    private String userId;
    private String menuId;
    private String sdate;
    private String pdi;
    private String vehl;
    private String vehlCode;
    private String year;
    private String region;
    private String language;
    private String print;
    private String postback;
    private String mainCd;
}
