package com.oms.stm.dao;

import java.util.List;

import com.oms.stm.dto.CodeMgmtReqDTO;
import com.oms.stm.dto.NatlMgmtReqDTO;
import com.oms.stm.dto.NatlMgmtResDTO;

/**
 * <pre>
 * NatlMgmt DAO 인터페이스
 * </pre>
 *
 * @Class Name  : NatlMgmtDAO.java
 * @Description : 
 * @author 안경수 
 * @since 2023.1.6
 * @see 
*/
public interface NatlMgmtDAO {
    NatlMgmtResDTO selectNatlMgmt(NatlMgmtReqDTO natlMgmtReqDTO) throws Exception;
    List<NatlMgmtResDTO> selectNatlMgmtList(NatlMgmtReqDTO natlMgmtReqDTO) throws Exception;
    Integer insertNatlMgmt(NatlMgmtReqDTO natlMgmtReqDTO) throws Exception;
    Integer updateNatlMgmt(NatlMgmtReqDTO natlMgmtReqDTO) throws Exception;
    Integer deleteNatlMgmt(NatlMgmtReqDTO natlMgmtReqDTO) throws Exception;
}
