package com.oms.dao;

import lombok.Data;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @author 안경수
 * @since 2023. 1. 19.
 * @see
 */

@Data
public class UsrLogin {
    private String userId;
    private String userPw;
}
