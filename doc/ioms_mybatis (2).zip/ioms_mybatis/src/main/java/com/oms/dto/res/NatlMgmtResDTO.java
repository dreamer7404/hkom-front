package com.oms.dto.res;

import org.apache.ibatis.type.Alias;

import lombok.AllArgsConstructor;
import lombok.Data;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @author 안경수
 * @since 2023. 2. 9.
 * @see
 */

@Alias("natlMgmtResDTO")
@Data
@AllArgsConstructor
public class NatlMgmtResDTO {

}
