import React from 'react';
import { Form, SelectPicker } from 'rsuite';

//--------------  서버데이터용 필수 -------------------------------
import { useQuery} from 'react-query';
import { getData } from '../../utils/async';
import { API, CONSTANTS } from '../../utils/constants';
import useStore from '../../utils/store';
//--------------// 서버데이터용 필수 -------------------------------


const DlvtState = () => {

    const {keyword, 
        setIWayCd,  // sub코드 setter
    } = useStore(); 

    const onChangeIwayCombo = val => {
        setIWayCd(val);
    };

    // subCd API가져오기
    // const dlvtStateParams = {
    //     mainCd: '0017'
    // };
    // const dlvtStateCombo = useQuery([API.subCdCombo, dlvtStateParams], () => getData(API.subCdCombo, dlvtStateParams), {
    //         select: data => [{label: CONSTANTS.labelAll, value: CONSTANTS.valueAll}].concat(data.map((item) => ({ label: item.dlExpdPrvsNm, value: item.dlExpdPrvsCd })))
    // });

    //발행구분
    const iwayCdParam = {dlExpdGCd: CONSTANTS.grpCdIway};
    const iWayCdCombo = useQuery([API.codeCombo,iwayCdParam], () => getData(API.codeCombo,iwayCdParam), {
        select: data => [{label: CONSTANTS.labelAll, value: ''}].concat(data.map((item) => ({ label: item.label, value: item.value })))
    }) 

    return (
        <>
        <Form.ControlLabel column="sm" >발행구분</Form.ControlLabel>
            <SelectPicker size="sm"
                data={iWayCdCombo && iWayCdCombo.data ? iWayCdCombo.data : []}
                onChange={onChangeIwayCombo}
                placeholder={CONSTANTS.labelAll}
                cleanable={false}
                searchable={false}
                block={true}
                />
        </>
    )
}
export default DlvtState;