import React from 'react';
import { Form, SelectPicker } from 'rsuite';

//--------------  서버데이터용 필수 -------------------------------
import { useQuery} from 'react-query';
import { getData } from '../../utils/async';
import { API, CONSTANTS } from '../../utils/constants';
import useStore from '../../utils/store';
import { useState } from 'react';
import { useEffect } from 'react';
//--------------// 서버데이터용 필수 -------------------------------


const ComCombo = ({title, mainCd, useAll, updatedValue, parentCompSetValue}) => {

    const [selectedValue, setSelectedValue] = useState('01')

    const onChangeValue = val => {
        setSelectedValue(val);
        parentCompSetValue(val, mainCd);
    };

    useEffect(() => {
        if(updatedValue !== ''){
            setSelectedValue(updatedValue)
        }
    }, [updatedValue])

    
    // subCd API가져오기
    const param = {
        mainCd: mainCd
    };
    const comCombo = useQuery([API.subCdCombo, param], () => getData(API.subCdCombo, param), {
        select: data => 
        useAll
        ?[{label: CONSTANTS.labelAll, value: CONSTANTS.valueAll}].concat(data.map((item) => ({ label: item.dlExpdPrvsNm, value: item.dlExpdPrvsCd })))
        :data.map((item) => ({ label: item.dlExpdPrvsNm, value: item.dlExpdPrvsCd }))
    });
    
    useEffect(() => {
        if(comCombo.isSuccess){
            setSelectedValue(comCombo.data[0].value)
        }
    }, [comCombo.status])

    return (
        <>
            {
                title ?
                <Form.ControlLabel column="sm" >{title}</Form.ControlLabel>
                : null
            }
            <SelectPicker size="sm"
                value={selectedValue} 
                data={comCombo && comCombo.data ? comCombo.data : []} 
                onChange={onChangeValue}
                // placeholder={CONSTANTS.labelAll}
                cleanable={false}
                searchable={false}
                block={true}
            />
        </>
    )
}
export default ComCombo;