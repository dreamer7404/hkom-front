// react
import React, {useState, useEffect, useCallback} from 'react';
import {Col, Button, Collapse} from 'react-bootstrap';
import {Form, Input} from 'rsuite';
import SearchIcon from '@rsuite/icons/Search';

//--------------  서버데이터용 필수 -------------------------------
import { useQuery} from 'react-query';
import { CONSTANTS, API } from '../../../../utils/constants';
import useStore from '../../../../utils/store';
import SeDate from '../../../Search/SeDate';
import { getData } from '../../../../utils/async';
//--------------// 서버데이터용 필수 -------------------------------

import GridEmailHistory from '../_Grid/GridEmailHistory';
import Paging from '../../../Common/Paging';
import { CustomInputGroup } from '../../../Common/CustomInputGroup';

import EmailDetail from '../Popup/EmailDetail';

const EmailHistory = () => {

    //------------------- 필수 공통 ------------------------------
    const [open, setOpen] = useState(true); // 조건창 열기/닫기
    const {keyword } = useStore();  // 조회키워드 가져오기
    const [param, setParam] = useState();

    const [activePage, setActivePage] = useState(1);    // 페이지번호
    const [limit, setLimit] = useState(50);             // 페이지행수
    const [filterValue, setFilterValue] = useState(''); // 필터값

    const onChangePage = val => {
        setActivePage(val);
    };
    const onChangeLimit = val => {
        setLimit(val);
    };
    useEffect(()=>{
        onChangePage(1); // 페이지번호 리셋
    },[keyword]);

    // 필터
    const onFilterTextBoxChanged = useCallback((e) => {
        setFilterValue(e.target.value);
    }, []);

    // 검색창 열기/닫기 > 페이지네이션 여부에 따라 +-20px
    const [gridHeight, setGridHeight] = useState(575);
    const gridExpand = () =>{
        setOpen(!open);
        if(open){
            setTimeout(() => setGridHeight(650), 250);
        }else{
            setGridHeight(575)
        }
    }
    //-------------------// 필수 공통 ------------------------------

    const [rowData] = useState([
        {mailPt: "게시판", mailNm: "게시판 작성 메일링", mailUser1: "user1@hmc.com.kr 외 2명", mailUser2: "관리자", mailTime: '2023-03-31 19:00:00', mailSts:'발송'},
        {mailPt: "게시판", mailNm: "게시판 작성 메일링", mailUser1: "user1@hmc.com.kr 외 2명", mailUser2: "관리자", mailTime: '2023-03-31 19:00:00', mailSts:'발송'},
    ]);
    const queryResult = useQuery([API.emailLogs, {}], () => getData(API.emailLogs, {}), {staleTime: 0, cacheTime: 0, retry: 0});    
    // const queryResultTot = useQuery([API.batchLogsTot, {}], () => getData(API.batchLogsTot, {}), {staleTime: 0, cacheTime: 0, retry: 0}) ; 
    //  requestState 조회
    // const queryResult = useQuery(["EmailHistory"], () => {return rowData});

    // 셀 클릭
    const onCellClicked = e => {
        if(e.column.colId === 'mailNm'){
            setEmailDetailPop(true)
        }
    };

    const [emailDetailPop, setEmailDetailPop] = useState(false);


    // 조회버튼
    const onSearch = () => {
        queryResult.refetch(); // 수동쿼리실행
    };

    return (
        <>
            <div className="search-area">
                <Collapse in={open}>
                    <div className="form" id="example-collapse-text">
                        <div className="search-group">
                            <div className="row">
                                <Col sm={2} className=""> 
                                    <SeDate />
                                </Col>
                                <Col sm={2} className="" >
                                    <Form.ControlLabel column="sm" >수신인</Form.ControlLabel>
                                    <Input size="sm" type="text" />
                                </Col>
                                <Col sm={2} className="" >
                                    <Form.ControlLabel column="sm" >발송인</Form.ControlLabel>
                                    <Input size="sm" type="text" />
                                </Col>
                            </div>

                            <div className="search-btn-wrap">
                                <Button className="btn-search" variant="outline-primary" size="sm" onClick={onSearch}><SearchIcon />조회</Button>
                            </div>
                        </div>
                    </div>
                </Collapse>
                <Button size="sm" variant="outline-dark" className="search-control" aria-controls="example-collapse-text" 
                    aria-expanded={open} onClick={gridExpand}>
                    <span className={open === true ? "search-area-close" : "search-area-open"}>{open === true ? CONSTANTS.closeSearch : CONSTANTS.openSearch}</span>
                </Button>
            </div>
            
            <div className="grid-wrap">
                <div className="grid-btn-wrap">
                    <div className="left-align">
                        {/*--------- 필터 -----------*/}
                        <CustomInputGroup size="sm"   onInput={onFilterTextBoxChanged} />
                    </div>
                </div>
                {/*--------- Grid -----------*/}
                <GridEmailHistory 
                    gridHeight={gridHeight}
                    filterValue={filterValue}
                    queryResult={queryResult}
                    limit={limit}
                    activePage={activePage}
                    onCellClicked={onCellClicked}
                    />

                {/*--------- 페이징 -----------*/}
                <Paging 
                    total={queryResult && queryResult.data && queryResult.data.length}
                    limit={limit}
                    activePage={activePage}
                    onChangePage={onChangePage}
                    onChangeLimit={onChangeLimit}
                />
            </div>

            <EmailDetail show={emailDetailPop} onHide={() => setEmailDetailPop(false)} />
        </>
    )
};
export default EmailHistory;