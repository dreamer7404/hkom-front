import React from 'react';
import {Button, Modal, Table} from 'react-bootstrap';
import {Form, SelectPicker} from 'rsuite';

const MenuAdd = ({show, onHide}) => {

    const selectData = ['재고관리', '제작준비', '발간현황', '선적현황', '운영관리', '시스템관리'].map(
        item => ({ label: item, value: item })
    );

    return (
        <>
            <Form>
                <Modal show={show} onHide={onHide} backdrop="static" keyboard={false} centered size="md" className="modal-custom">
                    <Modal.Header closeButton>
                        <Modal.Title>메뉴 등록</Modal.Title>
                    </Modal.Header>
                        <Modal.Body>
                            <Table className="tbl-hor" bordered>
                                <colgroup>
                                    <col style={{width:'30%'}}></col>
                                    <col style={{width:''}}></col>
                                </colgroup>
                                <tbody>
                                    <tr>
                                        <th className="essen">메뉴그룹</th>
                                        <td>
                                            <SelectPicker size="sm" searchable={false} cleanable={false} data={selectData} defaultValue="재고관리" />
                                        </td>
                                    </tr>
                                    <tr>
                                        <th className="essen">메뉴명</th>
                                        <td colspan="3">
                                            <Form.Control size="sm" type="text"/> 
                                        </td>
                                    </tr>
                                    <tr>
                                        <th className="essen">순번</th>
                                        <td>
                                            <Form.Control size="sm" type="text"/>
                                        </td>
                                    </tr>
                                    <tr>
                                        <th className="essen">URL</th>
                                        <td colspan="3">
                                            <Form.Control size="sm" type="text"/> 
                                        </td>
                                    </tr>
                                    <tr>
                                        <th className="">사용여부</th>
                                        <td colspan="3">
                                            <SelectPicker size="sm" data={[{ label: "사용"}]} searchable={false} cleanable={false} />
                                        </td>
                                    </tr>
                                </tbody>
                            </Table>
                        </Modal.Body>

                        <Modal.Footer>
                            <Button variant="light" size="md" onClick={onHide}>취소</Button>
                            <Button variant="primary" size="md" onClick={onHide} >저장</Button>
                        </Modal.Footer>
                </Modal>
            </Form>
        </>
    );

};
export default MenuAdd;