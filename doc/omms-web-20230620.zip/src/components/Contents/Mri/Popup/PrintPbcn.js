import React, { useState, useMemo } from 'react';
import {Button, Modal} from 'react-bootstrap';
import { AgGridReact } from 'ag-grid-react';
import { CONSTANTS } from '../../../../utils/constants';

const PrintPbcn = ({show, onHide, queryResult, setSelectedPrntPbcnNo}) => {
    
    const defaultColDef = useMemo(() => {
    return {
        sortable: true,
        minWidth:100,
        resizable:true,
    };
    }, []);

    const onFirstDataRendered = (params) => {
        params.api.sizeColumnsToFit();
    };

    // 셀 클릭
    const onCellClicked = e => {
        
        if(e.column.colId === 'newPrntPbcnNo'){
            setSelectedPrntPbcnNo(e.data)
            onHide()
            // alert('선택한 발간번호에 해당되는 정보 o/m발주 화면에 자동 입력')
        }

    };
   
    const columnDefs = [

        {
        headerName: '신규번호',
        field: 'newPrntPbcnNo',
        spanHeaderHeight: true,
        cellStyle: () => ({textDecoration: 'underline', cursor: 'pointer', color:'#2589f5'})
        },
        {
        headerName: '기존번호',
        field: 'oldPrntPbcnNo',
        spanHeaderHeight: true
        },
        {
        headerName: '차종',
        children: [
            { headerName:'차종코드', field: 'qltyVehlCd' },
            { headerName:'차종명', field: 'qltyVehlNm', cellStyle:() => ({textAlign: 'center'})},
            { headerName:'연식', field: 'mdlMdyCd', },
        ],
        },
        {
        headerName: '언어',
        children: [
            { headerName:'지역', field: 'dlExpdRegnNm'},
            { headerName:'언어코드', field: 'langCd', },
            { headerName:'언어명', field: 'langCdNm',  cellStyle:() => ({textAlign: 'center'}) },
        ],
        }, 
        {
        headerName: '발주상태',
        field: 'dlExpdRdcsStCdNm',
        spanHeaderHeight: true
        },
    ]
    return (
        <>
            <Modal show={show} onHide={onHide} backdrop="static" keyboard={false} centered size="xl" className="modal-custom">
                <Modal.Header closeButton>
                    <Modal.Title>발간번호 검색</Modal.Title>
                </Modal.Header>
                <Modal.Body>
                    <div className="ag-theme-alpine" style={{height:300}}>
                        <AgGridReact
                            // rowData={rowData}
                            rowData={queryResult && queryResult.data} 
                            columnDefs={columnDefs}
                            defaultColDef={defaultColDef}
                            onFirstDataRendered={onFirstDataRendered}
                            suppressSizeToFit={true}    
                            onGridSizeChanged={onFirstDataRendered}   

                            onCellClicked={onCellClicked}
                            >
                        </AgGridReact>
                    </div>
                </Modal.Body>
                <Modal.Footer>
                    <Button variant="primary" size="md" onClick={onHide}>확인</Button>
                </Modal.Footer>
            </Modal>
        </>
    )
};
export default PrintPbcn;