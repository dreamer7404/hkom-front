import React, {useState, useEffect} from 'react';
import {Button, Modal, Table} from 'react-bootstrap';
import {Form, Radio, RadioGroup, Schema, Input, Notification, useToaster, SelectPicker, Checkbox, toaster} from 'rsuite';
import { formatNumber, escapeCharChange } from '../../../../utils/commUtils';
// //--------------  서버데이터용 필수 -------------------------------
import { useMutation, useQuery} from 'react-query';
import { postData, getData } from '../../../../utils/async';
import { API, CONSTANTS } from '../../../../utils/constants';
// //--------------// 서버데이터용 필수 -------------------------------

import { confirmAlert } from 'react-confirm-alert'; // Import
import ConfirmAlert from '../../../Common/ConfirmAlert';

//-------------------------------- accepter 컨트롤 시작 -------------------------------------
const ListControl =  ({ data, setCheckedValues, readOnly }) => {

    //전체 체크기능을 위한 작업 시작
    const [data2, setData2] = useState([]);
    const [value, setValue] = React.useState([['B'], ['C']]);
    useEffect(() => {
        setCheckedValues(value)
    }, [value])

    const [list, setList] = React.useState([]);
    
    useEffect(() => {
        setList(data.list)

        let tmpDataArr = [];
        data.list.forEach((item, i) => {
            tmpDataArr.push([])
            item.forEach(item2 => {
                if(item2.pageContent && item2.pageContent.length > 0){
                    tmpDataArr[i].push(item2.pageContent)
                }
            })
        });
        setData2(tmpDataArr)
        
        let tmpArr = [];
        data.list.forEach((item, i) => {
            tmpArr.push([])
            item.forEach(item2 => {
                if(item2.checked && item2.checked==='Y'){
                    tmpArr[i].push(item2.pageContent)
                }
            })
        });
        setValue(tmpArr);

    }, [data])

    const handleCheckAll = (index, checked, event) => {
        setValue(
            (data2.map((item, i) => {
                return i === index?checked?item:[]:value[i]
            }))
        )
    };
    const handleChange = (values, event, index) => {
        setValue(value => (value.map((item, i) => {
                return i === index?values:item
            }))
        )
    };

    const handleChange2 = (val, checked, event, index) => {
        let allValue = value
        let thisValuesArr = value[index]
        let arrForSetValue = [];
        if(checked){
            arrForSetValue = thisValuesArr.concat([val])
            
        }
        else {
            arrForSetValue = thisValuesArr.filter(item => {
                return item != val
            })
        } 
        setValue(
            value.map((item, i) => {
                if(i === index){
                    return arrForSetValue
                }
                else {
                    return item
                }
            })
        )
    };

    const checkTest = (e, val) => {
        if(e === val){
            return true
        } else {
            return false
        }
    }

    return (
        <Table className="tbl-ver">
            {/* {JSON.stringify(list)}
            <div>{JSON.stringify(data2)}</div>
            ----------------------------------
            <div>{JSON.stringify(value)}</div>   */}
        
            <tbody>
                <tr>
                    {list.length > 0 &&
                    list.map((item, index) => (
                        <td className="print-array-td">
                        <Table className="tbl-ver" bordered>
                            <thead>
                                <tr>
                                    <th style={{minWidth:30}}>
                                    {data2[index].length > 0
                                    ?
                                    <Checkbox
                                        indeterminate={value[index] && value[index].length > 0 && value[index].length < data2[index].length}
                                        checked={value[index] && value[index].length !== 0 && value[index].length === data2[index].length}
                                        onChange={handleCheckAll}
                                        value={index}
                                        readOnly={readOnly}
                                    />
                                    :
                                    <Checkbox
                                        indeterminate={value[index] && value[index].length > 0 && value[index].length < data2[index].length}
                                        checked={value[index] && value[index].length !== 0 && value[index].length === data2[index].length}
                                        onChange={handleCheckAll}
                                        value={index}
                                        disabled
                                    />
                                    }
                                    
                                    </th>
                                    <th style={{minWidth:50}}>페이지</th>
                                    <th style={{minWidth:50}}>내용</th>
                                    <th style={{minWidth:50}}>교체</th>
                                </tr>
                            </thead>
                            <tbody>
                                {item.map((item2, index2) => (
                                <tr>
                                    {item2.groupIndex
                                    ?<td rowSpan="8">{item2.groupIndex}</td>
                                    :null
                                    }
                                    <td>{item2.page}</td>
                                    <td>{item2.pageContent}</td>
                                    {item2.pageContent
                                    ?
                                    <Checkbox 
                                        key={item2.pageContent} 
                                        value={item2.pageContent} 
                                        checked={value[index].some(e => checkTest(e, item2.pageContent))} 
                                        onChange={(value, checked, event) => handleChange2(value, checked, event, index)}
                                        readOnly={readOnly}
                                    >
                                    </Checkbox>
                                    :
                                    <Checkbox disabled/>
                                    }
                                    
                                    
                                </tr>
                                ))}
                            </tbody>
                        </Table>
                        </td>
                    ))
                    }
                </tr>
            </tbody>
        </Table>
    )
}
//-------------------------------- accepter 컨트롤 끝 -------------------------------------




const PrintArrayTable = ({show, onHide, param, readOnly}) => {

    // 수량 천단위 콤마 찍기 시작
  const currencyFormatter2 = (params) => {
    return formatNumber(params);
  };

    const [localParam, setLocalParam] = useState({})

    const queryPrintOrderDetailResult = useQuery([API.printOrderPageInfo, localParam], () => getData(API.printOrderPageInfo, localParam), {
        enabled: false,
    });

    const queryNPrntPbcnNoLrnkCdResult = useQuery([API.newPrntPbcnNoLrnkCdInfos, param], () => getData(API.newPrntPbcnNoLrnkCdInfos, param), {
        enabled: false,
        select: data => data.map((item) => ({ label: item.newPrntPbcnNo+'-'+item.lrnkCd, value: item.lrnkCd})),
    });
    useEffect(() => {
        if(show) {
            setLocalParam(param)
            setTimeout(() => queryNPrntPbcnNoLrnkCdResult.refetch(), 100);
        } else {
            queryNPrntPbcnNoLrnkCdResult.remove()
            setNPrntPbcnNoLrnkCd('01')
        }
    }, [show])
    
    const [nPrntPbcnNoLrnkCd, setNPrntPbcnNoLrnkCd] = useState('01');
    const onChangeNPrntPbcnNoLrnkCd = e => {
        setNPrntPbcnNoLrnkCd(e)
    }
    useEffect(() => {
        setLocalParam(param => ({...param, lrnkCd : nPrntPbcnNoLrnkCd }))
        if(queryNPrntPbcnNoLrnkCdResult.isSuccess) {
            setTimeout(() => queryPrintOrderDetailResult.refetch(), 250);
        }
    }, [nPrntPbcnNoLrnkCd, queryNPrntPbcnNoLrnkCdResult.status])

    // Form 정의
    const formRef = React.useRef();
    const [formError, setFormError] = React.useState({});
    const [formValue, setFormValue] = React.useState({
        list: []
    });

    useEffect(() => {
        if(queryPrintOrderDetailResult.data) {
            setFormValue(item => ({...item, list: queryPrintOrderDetailResult.data.pageList}))
        }
    }, [queryPrintOrderDetailResult.data])

    const [checkedValues, setCheckedValues] = useState([])
    const [reqBody, setReqBody] = useState(localParam)
    useEffect(() => {
        // console.log(param)
        setReqBody(({...localParam, checkedValues : checkedValues.flat() }))
        // console.log(reqBody)
    }, [checkedValues])

    //데이터 등록(post)
    const submitResult = useMutation((params => postData(API.printOrderPageInfo, params, CONSTANTS.update)),{
        onSuccess: res => {
		    if(res > 0){
                toaster.push(
                    <Notification type='success' header='요청성공' closable >저장이 완료되었습니다.</Notification>
                );
                setTimeout(() => {queryPrintOrderDetailResult.refetch()}, 500); 
            }else{
                toaster.push(
                    <Notification type='error' header='요청실패' closable >저장을 실패했습니다.</Notification>
                );
            }
        }
    });

    const saveButton = () => {
        

        const onOk = () => {
            submitResult.mutate(reqBody)
            // console.log(reqBody)
        }
        confirmAlert({
            closeOnClickOutside: false,
            customUI: ({ onClose }) => <ConfirmAlert 
                                            onClose={onClose} 
                                            title={"알림"}
                                            msg={"저장하시겠습니까?"} 
                                            onOk={onOk}  
                                        />
        })
    }

    return (
        <>
            <Form
            ref={formRef}
            checkTrigger="change"
            onChange={setFormValue}
            formValue={formValue}
            >
                <Modal show={show} onHide={onHide} backdrop="static" keyboard={false} centered size="xl" className="modal-custom size-2xl">
                    <Modal.Header closeButton>
                        <Modal.Title>인쇄 배열표</Modal.Title>
                    </Modal.Header>
                    <Modal.Body>
                        <div className="grid-btn-wrap">
                            <div className="right-align">
                                <Button variant="outline-success" size="sm"><span className="excel-down"></span>{CONSTANTS.excelDownload}</Button>{' '}
                                <Button variant="outline-dark" size="sm"><span className="print"></span>{CONSTANTS.print}</Button>{' '}
                            </div>
                        </div>
                        <Table className="tbl-hor" bordered>
                            <colgroup>
                                <col style={{width:'10%'}}></col>
                                <col style={{width:'20%'}}></col>
                                <col style={{width:'10%'}}></col>
                                <col style={{width:'10%'}}></col>
                                <col style={{width:'10%'}}></col>
                                <col style={{width:'20%'}}></col>
                                <col style={{width:'10%'}}></col>
                                <col style={{width:'10%'}}></col>
                            </colgroup>
                            <tbody>
                                <tr>
                                    <th className="">발간번호</th>
                                    <td>
                                        <SelectPicker size="sm" 
                                            data={queryNPrntPbcnNoLrnkCdResult && queryNPrntPbcnNoLrnkCdResult.data ? queryNPrntPbcnNoLrnkCdResult.data : []} 
                                            searchable={false} 
                                            cleanable={false} 
                                            onChange={onChangeNPrntPbcnNoLrnkCd}
                                            value={nPrntPbcnNoLrnkCd}
                                        />
                                    </td>
                                    <th className="">수정</th>
                                    <td>
                                        {queryPrintOrderDetailResult && queryPrintOrderDetailResult.data && 
                                        queryPrintOrderDetailResult.data.modifyCount+'/'+queryPrintOrderDetailResult.data.finalCount}
                                    </td>
                                    <th className="">인쇄방법</th>
                                    <td>
                                        {queryPrintOrderDetailResult && queryPrintOrderDetailResult.data && queryPrintOrderDetailResult.data.prntWayCdNm}
                                    </td>
                                    <th className="">인쇄부수</th>
                                    <td>
                                        {queryPrintOrderDetailResult && queryPrintOrderDetailResult.data && 
                                        currencyFormatter2(queryPrintOrderDetailResult.data.prntParrQty)}
                                    </td>
                                </tr>
                            </tbody>
                        </Table>
                        <div className="print-array-wrap">
                        <Form.Group >
                            <Form.Control 
                                name="list"
                                data={formValue}
                                accepter={ListControl} 
                                fieldError={formError.list}
                                setCheckedValues={setCheckedValues}
                                readOnly={readOnly}
                                />
                        </Form.Group>
                        </div>
                        
                    </Modal.Body>
                    <Modal.Footer>
                        <Button variant="light" size="md" onClick={onHide}>취소</Button>
                        {!readOnly &&
                            <Button variant="primary" size="md" onClick={saveButton}>저장</Button>
                        }
                        
                    </Modal.Footer>
                </Modal>
            </Form>
        </>
    );

};
export default PrintArrayTable;