import React, {useEffect, useMemo, useRef, useState} from 'react';
import { AgGridReact } from 'ag-grid-react';
import { CONSTANTS } from '../../../../utils/constants';
import AttachmentIcon from '@rsuite/icons/Attachment';
import moment from 'moment';


const GridBoardList = ({gridHeight, filterValue, queryResult, limit, activePage, onCellClicked}) => {

  const gridRef = useRef();

  const [columnDefs, setColumnDefs] = useState([
        {
            headerName: '관리번호',
            field: 'blcSn',
            spanHeaderHeight: true,
            rowSpan: param => param.data.flag,
            cellClass: ['d-flex' ,'align-items-center' ,'justify-content-center', 'show-cell'],
        },
        {
            headerName: '분류',
            field: 'blcScnCdNm',
            spanHeaderHeight: true,
            rowSpan: param => param.data.flag,
          cellClass: ['d-flex' ,'align-items-center' ,'justify-content-center', 'show-cell'],
        },
        {
          headerName: '차종',
          children: [
            { headerName:'차종코드', field: 'qltyVehlCd'},
            { headerName:'차종명', field: 'qltyVehlNm' },
            { headerName:'연식', field: 'mdlMdyCd'},
          ],
        },
        {
          headerName: '언어',
          children: [
            { headerName:'지역', field: 'regnNm'},
            { headerName:'언어코드', field: 'langCd'},
            { headerName:'언어명', field: 'langCdNm'},
          ],
        },
        {
          headerName: '제목',
          field: 'blcTitlNm',
          minWidth:'400',
          spanHeaderHeight: true,
          rowSpan: param => param.data.flag,
          cellClass: ['d-flex' ,'align-items-center' ,'justify-content-center', 'show-cell'],
          cellStyle: () => ({ textDecoration: 'underline', cursor: 'pointer', color:'#2589f5'})
        },
        {
          headerName: '첨부',
          field: 'attcYn',
          spanHeaderHeight: true,
          rowSpan: param => param.data.flag,
          cellClass: ['d-flex' ,'align-items-center' ,'justify-content-center', 'show-cell'],
          cellRenderer: function(params) {
            return params.value === 'Y' ? <AttachmentIcon style={{fontSize:'14px'}} /> : '';
          }
        },
        {
          headerName: '등록자',
          field: 'pprrEeno',
          spanHeaderHeight: true,
          rowSpan: param => param.data.flag,
          cellClass: ['d-flex' ,'align-items-center' ,'justify-content-center', 'show-cell'],
        },  
        {
          headerName: '등록일',
          field: 'framDtm',
          spanHeaderHeight: true,
          cellRenderer: (param) => moment(param).format('YYYY-MM-DD'),
          rowSpan: param => param.data.flag,
          cellClass: ['d-flex' ,'align-items-center' ,'justify-content-center', 'show-cell'],
        }
    ])

    const defaultColDef = useMemo(() => {
        return {
            initialWidth: 90,
            sortable: true,
            resizable:true,
        };
    }, []);

  const onFirstDataRendered = (params) => {
      params.api.sizeColumnsToFit();
  };

  useEffect(()=>{
    if(queryResult.status === 'loading' && gridRef && gridRef.current && gridRef.current.api){
        gridRef.current.api.showLoadingOverlay();
    }
  },[queryResult]);

  useEffect(()=> {
    if(gridRef && gridRef.current && gridRef.current.api){
      gridRef.current.api.setQuickFilter(filterValue);
    }
  },[filterValue]);

  useEffect(()=> {
    if(gridRef && gridRef.current && gridRef.current.api){
      gridRef.current.api.paginationGoToPage(activePage-1);
    }
  },[activePage]);


  return(
      <div className="ag-theme-alpine" style={{height: gridHeight, transition:'all ease .3s'}}>
        <AgGridReact
            ref={gridRef} 
            rowData={queryResult && queryResult.data} 
            columnDefs={columnDefs}
            defaultColDef={defaultColDef}

            // paging
            pagination={true}
            paginationPageSize={limit} //
            suppressPaginationPanel={true} 
            // onPaginationChanged={onPaginationChanged}

            // click column
            onCellClicked={onCellClicked} //

            //  filter
            cacheQuickFilter={true}

            // overlay
            overlayLoadingTemplate={CONSTANTS.gridLoading}
            overlayNoRowsTemplate={CONSTANTS.gridNoRows}

            onFirstDataRendered={onFirstDataRendered}
            suppressSizeToFit={true}    
            onGridSizeChanged={onFirstDataRendered}    

            suppressRowTransform={true} // rowSpan 할때 필요!
            >
        </AgGridReact>
    </div>
  )


};
export default GridBoardList;