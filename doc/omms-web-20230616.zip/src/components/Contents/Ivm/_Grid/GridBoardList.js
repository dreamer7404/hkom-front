import React, {useEffect, useMemo, useRef, useState} from 'react';
import { AgGridReact } from 'ag-grid-react';
import { CONSTANTS } from '../../../../utils/constants';
import AttachmentIcon from '@rsuite/icons/Attachment';
import moment from 'moment';



const GridBoardList = ({gridHeight, filterValue, queryResult, limit, activePage, onCellClicked}) => {

  class ShowCellRenderer {
    init(params) {  
      const cellBlank = !params.value;
      if (cellBlank) {
          return;
      }
    
      this.ui = document.createElement('div');
      // this.ui.innerHTML = '<div class="rowspan-title" style="line-height:' + params.data.flag * '30' + 'px;">' + params.value + '</div>';
      if(params.data.flag === 0)   this.ui.innerHTML = '<div></div>'
      // // else{
        if(params.data.flag === 1) this.ui.innerHTML =  '<div>' + params.data.blcTitlNm +      '</div>'
      //   else this.ui.innerHTML = '<div style="line-height:' + params.data.flag * '30' + 'px;">' + params.data.blcTitlNm +      '</div>'
      // // } 
    }
  
    getGui() {
    return this.ui;
    }
  
    refresh() {
    return false;
    }
  }

  const gridRef = useRef();

  const rowSpan = (params) => {
    // console.log(params)
    if (params.data.blcSn === 99 && params.data.langCd === 'EC') {
      console.log('@@@@@@@@@@@@@@@@@@@@@@')
      return 2;
    } else {
      return 1;
    }
    // return (params.data.flag === 0 || params.data.flag ===1) ? 1 : params.data.flag;
  };

  const [columnDefs, setColumnDefs] = useState([
        {
            headerName: '관리번호',
            field: 'blcSn',
            // rowSpan: rowSpan,
            // cellClass: (rowSpan) => {
            //   return rowSpan.data.blcSn === 94 ? 'show-cell' : null;
            // },
        },
        {
            headerName: '분류',
            field: 'blcScnCdNm',
            spanHeaderHeight: true,
        },
        {
          headerName: '차종',
          children: [
            { headerName:'차종코드', field: 'qltyVehlCd'},
            { headerName:'차종명', field: 'qltyVehlNm' },
            { headerName:'연식', field: 'mdlMdyCd'},
          ],
        },
        {
          headerName: '언어',
          children: [
            { headerName:'지역', field: 'regnNm'},
            { headerName:'언어코드', field: 'langCd'},
            { headerName:'언어명', field: 'langCdNm'},
          ],
        },
        {
          headerName: '제목',
          field: 'blcTitlNm',
          spanHeaderHeight: true,
          minWidth:'400',
          rowSpan: rowSpan,
          // cellClassRules: {
          //   'cell-span': "value==='test01'",
          // },
          cellRenderer: ShowCellRenderer,
          cellClass: (param) => {
              console.log('param', param)
              return (param.data.langCd === 'EC' && param.data.blcSn === 99)  ? 'show-cell' : null;
          },
          cellStyle: () => ({ textDecoration: 'underline', cursor: 'pointer', color:'#2589f5'})
        },
        {
          headerName: '첨부',
          field: 'board4',
          spanHeaderHeight: true,
          cellRenderer: function(params) {
            return <AttachmentIcon style={{fontSize:'14px'}} />
          }
        },
        {
          headerName: '등록자',
          field: 'pprrEeno',
          spanHeaderHeight: true,
        },  
        {
          headerName: '등록일',
          field: 'framDtm',
          spanHeaderHeight: true,
          cellRenderer: (param) => moment(param).format('YYYY-MM-DD')
        }
    ])

    const defaultColDef = useMemo(() => {
        return {
            initialWidth: 90,
            sortable: true,
            resizable:true,
        };
    }, []);

  const onFirstDataRendered = (params) => {
      params.api.sizeColumnsToFit();
  };

  useEffect(()=>{
    if(queryResult.status === 'loading' && gridRef && gridRef.current && gridRef.current.api){
        gridRef.current.api.showLoadingOverlay();
    }
  },[queryResult]);

  useEffect(()=> {
    if(gridRef && gridRef.current && gridRef.current.api){
      gridRef.current.api.setQuickFilter(filterValue);
    }
  },[filterValue]);

  useEffect(()=> {
    if(gridRef && gridRef.current && gridRef.current.api){
      gridRef.current.api.paginationGoToPage(activePage-1);
    }
  },[activePage]);


  return(
      <div className="ag-theme-alpine" style={{height: gridHeight, transition:'all ease .3s'}}>
        <AgGridReact
            ref={gridRef} 
            rowData={queryResult && queryResult.data} 
            columnDefs={columnDefs}
            defaultColDef={defaultColDef}

            // paging
            pagination={true}
            paginationPageSize={limit} //
            suppressPaginationPanel={true} 
            // onPaginationChanged={onPaginationChanged}

            // click column
            onCellClicked={onCellClicked} //

            //  filter
            cacheQuickFilter={true}

            // overlay
            overlayLoadingTemplate={CONSTANTS.gridLoading}
            overlayNoRowsTemplate={CONSTANTS.gridNoRows}

            onFirstDataRendered={onFirstDataRendered}
            suppressSizeToFit={true}    
            onGridSizeChanged={onFirstDataRendered}    
            >
        </AgGridReact>
    </div>
  )


};
export default GridBoardList;