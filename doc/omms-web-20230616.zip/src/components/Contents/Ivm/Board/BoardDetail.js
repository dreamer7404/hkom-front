// react
import React, {useState, useMemo, useEffect} from 'react';
import { useLocation } from "react-router";
import { AgGridReact } from 'ag-grid-react';

import {Form, Button, Table, Row, Col} from 'react-bootstrap';
import { Parser } from 'html-to-react'
import { useNavigate } from 'react-router-dom';

//--------------  서버데이터용 필수 -------------------------------
import { useQuery, useQueryClient, useMutation} from 'react-query';
import { getData, postData } from '../../../../utils/async';
import { API, CONSTANTS } from '../../../../utils/constants';
import useStore from '../../../../utils/store';
//--------------// 서버데이터용 필수 -------------------------------
import { confirmAlert } from 'react-confirm-alert'; 
import ConfirmAlert from   '../../../Common/ConfirmAlert'; 
import moment from 'moment';

import { DEXT5Editor } from 'dext5editor-react';
import { DEXT5Upload } from 'dext5upload-react';

import {unescapeHtml, escapeCharChange, convertYmd} from '../../../../utils/commUtils';


const BoardDetail = () => {

    const navigate = useNavigate();

    const { state } = useLocation();
    const [data, setData] = useState(null)
    const [files, setFiles] = useState(null)
    const [users, setUsers] = useState(null)
    const [vehls, setVehls] = useState(null)
    const [replyData, setReplyData] = useState([])

    // 게시판 목록
    const queryParam = {blcSn: state};
    const queryResult = useQuery([API.boardAffrMgmt, queryParam], () => getData(API.boardAffrMgmt, queryParam));

    // 게시판댓글 목록
    const queryReplyResult = useQuery([API.boardAffrMgmtReplys, queryParam], () => getData(API.boardAffrMgmtReplys, queryParam));

    useEffect(()=> {
       if(queryResult.isFetched){
           console.log('queryResult', queryResult.data);
           setData(queryResult.data.detail);
           setFiles(queryResult.data.files);
           setUsers(queryResult.data.users.map(item => ({...item, deptNm: item.coNm + '(' + item.deptNm + ')'})));
           setVehls(queryResult.data.vehls);
       }
    },[queryResult.status])

    useEffect(()=> {
        if(queryReplyResult.data){
            console.log('queryReplyResult', queryReplyResult.data);
            setReplyData(queryReplyResult.data);
        }
     },[queryReplyResult.status])





    const columnDefs = [
        {
            headerName: '차종',
            field: 'qltyVehlNm',
        },
        {
            headerName: '연식',
            field: 'mdlMdyCd',
        },
        {
            headerName: '언어',
            field: 'langCdNm',
        },
    ]

    // const [rowData2] = useState([
    //         {userPart: "현대자동차", userName: "홍길동"},
    //         {userPart: "현대자동차", userName: "김삼순"},
    //         {userPart: "현대자동차", userName: "김삼순"},
    //         {userPart: "현대자동차", userName: "김삼순"},
    // ]);

    const columnDefs2 = [
        {
          headerName: '소속',
          field: 'deptNm',
        },
        {
          headerName: '이름',
          field: 'userNm',
        },
    ]

    const defaultColDef = useMemo(() => {
        return {
            initialWidth: 90,
            sortable: true,
        };
    }, []);


    const onFirstDataRendered = (params) => {
        params.api.sizeColumnsToFit();
    };

    const updateButton = () => {
        navigate('/board/update', {state: state});
    }

    const listButton = () => {
        navigate('/board');
    }


    const [showEditor, setShowEditor ] = useState(false)

    // 기존업로드된 파일리스트 (수정화면에서 사용)
    const onCreationComplete = e => {
        if(files){
            for(let i=0; i<files.length; i++){
                DEXT5UPLOAD.AddUploadedFile(''+(i+1), escapeCharChange(files[i].fileNm), '', files[i].fileSize, files[i].attcSn, 'dext5upload1');
            }
        }
    }

    //  댓글등록                                             
    const replyMudate = useMutation((params => postData(API.boardAffrMgmtReply, params, CONSTANTS.insert)),{
        onSuccess: res => {
            if(res === 1){
                // 댓글 리플래시
                queryReplyResult.remove();
                queryReplyResult.refetch();
                DEXT5.setBodyValue('', 'editor1');
                setShowEditor(false);
            }else{
                confirmAlert({
                    closeOnClickOutside: false,
                    customUI: ({ onClose }) => <ConfirmAlert onClose={onClose} title={"알림"} msg={"저장실패했습니다"}   />
                });
            }
        }
    });


    const onSaveReply = () => {
       // 내용
       const textValue = DEXT5.getBodyTextValue();
       if(DEXT5.getBodyTextValue().length === 0){
           confirmAlert({
               closeOnClickOutside: false,
               customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}  title={"알림"} msg={"댓글내용을 입력해주세요."}  />
           })
           return;
       }

       const replyParam = {
            blcSn: state,
            blcReplySn: replyData.length === 0 ? 1 : parseInt(replyData[0].blcReplySn)+1,
            blcReplySbc: DEXT5.getBodyValue(),
       };
       console.log('replyParam',replyParam)
       replyMudate.mutate(replyParam);

    }


    if(!data) return;

    return (
        <>
            <div className="write-wrap">
               
                <Table className="tbl-hor" bordered>
                    <colgroup>
                        <col style={{width:'15%'}}></col>
                        <col style={{width:'35%'}}></col>
                        <col style={{width:'15%'}}></col>
                        <col style={{width:'35%'}}></col>
                    </colgroup>
                    <tbody>
                        <tr>
                            <th>분류</th>
                            <td>
                                {data.blcScnCdNm}
                            </td>
                            <th>등록자</th>
                            <td>{data.userNm}</td>
                        </tr>
                        <tr>
                            <th>적용 차종 및 언어</th>
                            <td>
                                <div className="ag-theme-alpine" style={{height: 130, transition:'all ease .3s'}}>
                                    <AgGridReact
                                        rowData={vehls && vehls}
                                        columnDefs={columnDefs}
                                        defaultColDef={defaultColDef}
                                        onFirstDataRendered={onFirstDataRendered}
                                        suppressSizeToFit={true}    
                                        onGridSizeChanged={onFirstDataRendered}    
                                        >
                                    </AgGridReact>
                                </div>
                            </td>
                            <th>수신인</th>
                            <td>
                                <div className="ag-theme-alpine" style={{height: 130, transition:'all ease .3s'}}>
                                    <AgGridReact
                                        rowData={users && users}
                                        columnDefs={columnDefs2}
                                        defaultColDef={defaultColDef}
                                        onFirstDataRendered={onFirstDataRendered}
                                        suppressSizeToFit={true}    
                                        onGridSizeChanged={onFirstDataRendered}    
                                        >
                                    </AgGridReact>
                                </div>
                            </td>
                        </tr>
                        <tr>
                            <th>교체투입 여부(이전매뉴얼 폐기)</th>
                            <td>{data.altrTrwiYn === 'Y' ? '예' : '아니오'}</td>
                            <th>신규매뉴얼 투입 요청일</th>
                            <td>{convertYmd(data.nmtrwiRqYmd)}</td>
                        </tr>
                        <tr>
                            <th>제목</th>
                            <td colSpan="3">
                                {data.blcTitlNm}
                            </td>
                        </tr>
                        <tr>
                            <th>내용</th>
                            <td colSpan="3">
                                <div dangerouslySetInnerHTML={{__html: unescapeHtml(data.blcSbc)}} /> 
                                {/* <div dangerouslySetInnerHTML={{__html: html}} />  */}
                                {/* {Parser().parse(data.blcSbc)} */}
                            </td>
                        </tr>
                        <tr>
                            <th>첨부파일</th>
                            <td colSpan="3">
                                {files && files.length > 0 && <DEXT5Upload
                                        onCreationComplete={onCreationComplete}
                                        // onTransferComplete={onTransferComplete}
                                        // onBeforeAddItem={onBeforeAddItem}
                                        debug={false}
                                        id="dext5upload1"
                                        // mode='edit' 
                                        mode='view'  // view Mode
                                        runtimes='html5'
                                        componentUrl="/dext5upload/js/dext5upload.js"
                                        config={{MaxTotalFileSize:'100MB', MaxOneFileSize:'30MB', DevelopLangage:'NONE',
                                        // ButtonBarEdit: "add,remove,remove_all",
                                        ButtonBarView: 'download,download_all', // view Mode
                                        Width:'100%'}}
                                        
                                    />}
                            </td>
                        </tr>
                    </tbody>
                </Table>
                <div className="reply-wrap">
                    <div className="reply-write">
                            {/* <Form.Control as="textarea" placeholder="내용을 입력해주세요"></Form.Control> */}
                            {showEditor && <DEXT5Editor
                                debug={true}
                                id="editor1"
                                componentUrl="/dext5editor/js/dext5editor.js"
                                config={{ DevelopLangage:'NONE', Width:'100%', Height: '300px' }}
                            />} 
                             
                        </div>
                        <div >
                            <div className="mt-2" style={{ textAlign: 'right'}}>
                                {!showEditor && <Button variant="primary" size="sm" style={{marginRight: '6px'}} onClick={()=>setShowEditor(true)}>댓글 쓰기</Button>}
                                {showEditor && <Button variant="primary" size="sm" onClick={onSaveReply}>댓글 등록</Button>}
                            </div>
                        </div>
                    <p className="reply-count">댓글 <span>{replyData && replyData.length}</span>건</p>
                    <div className="reply-body">
                        {replyData && replyData.map((item, index) => (
                        <div className="reply-detail" key={index}>
                                <ul >
                                    <li>
                                        <div className="reply-user">{item.deptNm}{' '}{item.userNm}</div>
                                        <div className="reply-cont"><div dangerouslySetInnerHTML={{__html: unescapeHtml(item.blcReplySbc)}} /> </div>
                                        <div className="reply-date">{moment(item.mdfyDtm).format('YYYY-MM-DD HH:mm')}</div>
                                    </li>
                                </ul>
                         </div>
                         ))}
                    </div>
                </div>
                <div className="btn-wrap">
                    <div className="left-align">
                        <Button variant="light" onClick={listButton}>목록</Button>{' '}
                    </div>
                    <div className="right-align">
                        <Button variant="outline-danger" onClick={listButton}>삭제</Button>{' '}
                        <Button className="" variant="primary" size="md" onClick={updateButton}>수정</Button>
                    </div>
                </div>
            </div>
        </>
    )
};
export default BoardDetail;