// react
import React, {useState, useMemo,useEffect,useRef} from 'react';
import { AgGridReact } from 'ag-grid-react';
import {Button, Table} from 'react-bootstrap';
import {Form, SelectPicker, InputGroup, DatePicker, Schema, Grid} from 'rsuite';
import { useQuery, useMutation} from 'react-query';
import { API, CONSTANTS } from '../../../../utils/constants';
import { getData, postData } from '../../../../utils/async';
import { utcToLocalDate } from '../../../../utils/commUtils'; //'../../../utils/commUtils';
import useStore from '../../../../utils/store';
import { useNavigate  } from 'react-router-dom';
import { confirmAlert } from 'react-confirm-alert'; // Import
import ConfirmAlert from '../../../Common/ConfirmAlert';


const { StringType} = Schema.Types;
const model = Schema.Model({
    // qltyVehlCd: StringType().isRequired('차종코드를 선택해 주세요.'),
    affrScnCd: StringType().isRequired('업무구분을 선택해주세요.'),
    blcTitlNm: StringType().isRequired('게시물 제목을 입력해주세요.'),
    blcSbc: StringType().isRequired('게시물 내용을 입력해주세요.'),
    
});

const NoticeAdd = () => {

    const gridRef = useRef();
    const {keyword} = useStore(); 
    const [bulDate , setBulDate] = useState({
        sDate : '',
        eDate : ''
    })
    const [bulYn, setbulYn] = useState('N');
    const [affrScnCd,setAffrScnCd] = useState('');
    const navigate = useNavigate();
    const formRef = useRef();
    const [formError, setFormError] = useState({});
    const [formValue, setFormValue] = useState({
        bulYn : 'N',                 //게시여부
        affrScnCd : '',             //업무구분
        blcTitlNm : '',             // 게시물제목
        blcSbc:'',                  // 게시내용
        bulStrtYmd : new Date(),            // 게시시작일자
        bulFnhYmd : new Date(),             // 게시종료일자
        usrList  :[],
    }); 

   
    const columnDefs = [
        {
          checkboxSelection: true,
          headerCheckboxSelection: true,
          width:45,
          maxWidth:45,
          minWidth:45
        },
        {
          headerName: '회사명',
          field: 'coNm',
        },
        {
          headerName: '부서명',
          field: 'deptNm',
        },
        {
          headerName: '아이디',
          field: 'userEeno',
        },
        {
          headerName: '이름',
          field: 'userNm',
        },
    ]
    const usrData = useQuery([API.userMgmtPop,{}], () => getData(API.userMgmtPop, {})) //사용자 리스트

    const defaultColDef = useMemo(() => {
        return {
            initialWidth: 90,
            sortable: true,
        };
    }, []);

    //버튼이벤트
    const saveButton = () => {

      
        handleSubmit();
        
    }

    const listButton = () => {
        navigate('/notice',{ state: '' }); 
    }
    
    useEffect(()=>{
        console.log("formValue",formValue);
    },[formValue]) 

    const handleSubmit = () => {
        if (!formRef.current.check()) { //validation chk
            return;
        }

        confirmAlert({
            closeOnClickOutside: false,
            customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}   title={"알림"}
            msg={"입력하신 내용으로 저장하시겠습니까?"} 
            onOk={onOk}  />
        });
        
    };
    const noticeSave = useMutation((params => postData(API.boardMgmt, params, CONSTANTS.insert)),{
        onSuccess: res => {
           if(res>0){
                confirmAlert({
                    closeOnClickOutside: false,
                    customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}   title={"알림"}
                    msg={"저장이 완료되었습니다."}   />
                   
                });
           
           }else{
                confirmAlert({
                    closeOnClickOutside: false,
                    customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}   title={"알림"}
                    msg={"에러가 발생했습니다 관리자에게 문의해주세요."}   />
                    
                });
           }
           navigate('/notice',{ state: '' });   
        }
    });
    const onOk = () => {

        noticeSave.mutate(formValue);
    }

    const onSelectionChanged = ()=>{
        const selectedRows = gridRef.current.api.getSelectedRows();
        console.log(selectedRows);
        setFormValue(p => ({...p, usrList: selectedRows}));
    }

    //changeEvent
    const bulYnChangeEvent = (e)=>{
        setbulYn(e)
    }

    const scnCdChangeEvent = (e)=>{
        setAffrScnCd(e);
    }

    const onChangeDateStart = (val) => {
        setBulDate(p=>({...p,sDate : utcToLocalDate(val)}))
        setFormValue(p=>({...p,bulStrtYmd : utcToLocalDate(val)}))
    }

    const onChangeDateEnd = (val) => {
        setBulDate(p=>({...p,sEate : utcToLocalDate(val)}))
        setFormValue(p=>({...p,bulFnhYmd : utcToLocalDate(val)}))
    }

    const onFirstDataRendered = (params) => {
        params.api.sizeColumnsToFit();
    };
    return (
        <>
            <div className="write-wrap">
            <Form
                ref={formRef}
                checkTrigger="change"
                onChange={setFormValue}
                onCheck={setFormError}
                formValue={formValue}
                model={model}>
                    <Table className="tbl-hor" bordered>
                        <colgroup>
                            <col style={{width:'15%'}}></col>
                            <col style={{width:'35%'}}></col>
                            <col style={{width:'15%'}}></col>
                            <col style={{width:'35%'}}></col>
                        </colgroup>
                        <tbody>
                            <tr>
                                <th className="">게시여부</th>
                                    <td>
                                        <Form.Control  name="bulYn" size="sm" style={{zIndex: 0}} 
                                            value={bulYn}
                                            accepter={SelectPicker} 
                                            searchable={false}
                                            cleanable={false}
                                            data={[
                                                {label: '게시', value: 'Y'},
                                                {label: '미게시', value: 'N'},
                                            ]} 
                                            onChange={bulYnChangeEvent}
                                            
                                        ></Form.Control>
                                    </td>
                                <th>게시기간</th>
                                <td>
                                    <InputGroup>
                                        <DatePicker oneTap block size="sm" style={{width: '100%'}} 
                                            value={bulDate && bulDate.sDate ? new Date(bulDate.sDate)  : new Date()}
                                            ranges={[
                                                {
                                                label: '오늘',
                                                value: new Date()
                                                }
                                            ]}
                                            format="yyyy-MM-dd"
                                            onChange={onChangeDateStart} 
                                            cleanable={false}
                                        />
                                        <InputGroup.Addon>~</InputGroup.Addon>
                                        <DatePicker oneTap block size="sm" style={{width: '100%'}} 
                                            value={bulDate && bulDate.eDate ? new Date(bulDate.eDate)  : new Date()}
                                            ranges={[
                                                {
                                                label: '오늘',
                                                value: new Date()
                                                }
                                            ]}
                                            format="yyyy-MM-dd"
                                            onChange={onChangeDateEnd} 
                                            cleanable={false}
                                        />
                                    </InputGroup>
                                </td>
                            </tr>
                            <tr>
                                <th className="essen">업무구분</th>
                                <td colSpan="3">
                                    <Form.Control  name="affrScnCd" size="sm" style={{zIndex: 0}} 
                                        value={affrScnCd}
                                        accepter={SelectPicker} 
                                        data={[
                                            {label: '선택', value: ''},
                                            {label: '재고관리', value: '01'},
                                            {label: '제작준비', value: '02'},
                                            {label: '발간현황', value: '03'},
                                        ]}  searchable={false} cleanable={false} 
                                        onChange={scnCdChangeEvent}
                                    ></Form.Control>
                                                                           
                                </td>
                            </tr>
                            <tr>
                                <th className="essen">게시대상</th>
                                
                                <td colSpan="3">
                                    <div className="ag-theme-alpine" style={{height: 250, transition:'all ease .3s'}}>
                                        <AgGridReact
                                            ref ={gridRef}
                                            rowData={usrData.data}
                                            columnDefs={columnDefs}
                                            defaultColDef={defaultColDef}
                                            rowSelection={'multiple'}
                                            suppressRowClickSelection= {true} 
                                            onFirstDataRendered={onFirstDataRendered}
                                            suppressSizeToFit={true}    
                                            onGridSizeChanged={onFirstDataRendered}    
                                            onSelectionChanged={onSelectionChanged}
                                            >
                                        </AgGridReact>
                                    </div>
                                </td>
                            </tr>
                            <tr>
                                <th className="essen">제목</th>
                                <td colSpan="3">
                                    <Form.Control size="sm" type="text" name='blcTitlNm' placeholder="제목을 입력해주세요" />
                                </td>
                            </tr>
                            <tr>
                                <th className="essen">내용</th>
                                <td colSpan="3">
                                    <Form.Control size="sm" type="text" name='blcSbc' placeholder="내용을 입력해주세요" />
                                </td>
                            </tr>
                            <tr>
                                <th>첨부파일</th>
                                <td colSpan="3">
                                    
                                </td>
                            </tr>
                        </tbody>
                    </Table>
                </Form>
                <div className="btn-wrap">
                    <div className="right-align">
                        <Button variant="light" onClick={listButton}>취소</Button>{' '}
                        <Button className="" variant="primary" size="md" onClick={saveButton}>저장</Button>
                    </div>
                </div>
            </div>
        </>
    )
};
export default NoticeAdd;