import React, {useState, useEffect} from 'react';
import {Button, Modal, Table} from 'react-bootstrap';
import {Form, Radio, RadioGroup, Schema, Input, Notification, useToaster, SelectPicker, Checkbox} from 'rsuite';
import { formatNumber, escapeCharChange } from '../../../../utils/commUtils';
// //--------------  서버데이터용 필수 -------------------------------
import { useMutation, useQuery} from 'react-query';
import { postData, getData } from '../../../../utils/async';
import { API, CONSTANTS } from '../../../../utils/constants';
// //--------------// 서버데이터용 필수 -------------------------------

import { confirmAlert } from 'react-confirm-alert'; // Import
import ConfirmAlert from '../../../Common/ConfirmAlert';

//-------------------------------- accepter validation 시작 -------------------------------------
const { StringType, ArrayType, ObjectType, NumberType } = Schema.Types;
const model = Schema.Model({
    list: ArrayType().of(
        ObjectType().shape({
            rqQty: NumberType('숫자만 입력해주세요.').isRequired('수량을 입력해주세요.'),
        })
    )
});
//-------------------------------- accepter validation 끝 -------------------------------------

//-------------------------------- accepter 컨트롤 시작 -------------------------------------
const ListControl =  ({ value = [], onChange, fieldError, data }) => {

    const errors = fieldError ? fieldError.array : [];
    const [list, setList] = React.useState(value); 
    useEffect(() => {
        setList(data.list)
    }, [data])

    return (
        <Table className="tbl-ver">
            {/* {JSON.stringify(list)} */}
            <tbody>
                <tr>
                    {list.length > 0 &&
                    list.map(item => (
                        <td className="print-array-td">
                        <Table className="tbl-ver" bordered>
                            <thead>
                                <tr>
                                    <th><Checkbox  /></th>
                                    <th>페이지</th>
                                    <th>내용</th>
                                    <th>교체</th>
                                </tr>
                            </thead>
                            <tbody>
                                {item.map(item2 => (
                                <tr>
                                    {item2.groupIndex
                                    ?<td rowSpan="8">{item2.groupIndex}</td>
                                    :null
                                    }
                                    <td>{item2.page}</td>
                                    <td>{item2.pageContent}</td>
                                    {item2.pageContent
                                    ? item2.checked ==='Y' ?<td><Checkbox checked /></td>:<td><Checkbox /></td>
                                    :<td><Checkbox disabled/></td>
                                    }
                                    
                                </tr>
                                ))}
                            </tbody>
                        </Table>
                        </td>
                    ))
                    }
                </tr>
            </tbody>
        </Table>
    )
}
//-------------------------------- accepter 컨트롤 끝 -------------------------------------




const PrintArrayTableTest = ({show, onHide, param}) => {

    // 수량 천단위 콤마 찍기 시작
  const currencyFormatter2 = (params) => {
    return formatNumber(params);
  };

    const [localParam, setLocalParam] = useState({})

    const queryPrintOrderDetailResult = useQuery([API.printOrderPageInfo, localParam], () => getData(API.printOrderPageInfo, localParam), {
        enabled: false,
    });

    const queryNPrntPbcnNoLrnkCdResult = useQuery([API.newPrntPbcnNoLrnkCdInfos, param], () => getData(API.newPrntPbcnNoLrnkCdInfos, param), {
        enabled: false,
        select: data => data.map((item) => ({ label: item.newPrntPbcnNo+'-'+item.lrnkCd, value: item.lrnkCd})),
    });
    useEffect(() => {
        if(show) {
            setLocalParam(param)
            // queryNPrntPbcnNoLrnkCdResult.refetch();
            setTimeout(() => queryNPrntPbcnNoLrnkCdResult.refetch(), 100);
        } else {
            queryNPrntPbcnNoLrnkCdResult.remove()
            setNPrntPbcnNoLrnkCd('01')
        }
        console.log('11111')
    }, [show])
    
    const [nPrntPbcnNoLrnkCd, setNPrntPbcnNoLrnkCd] = useState('01');
    const onChangeNPrntPbcnNoLrnkCd = e => {
        setNPrntPbcnNoLrnkCd(e)
    }
    useEffect(() => {
        setLocalParam(param => ({...param, lrnkCd : nPrntPbcnNoLrnkCd }))
        if(queryNPrntPbcnNoLrnkCdResult.isSuccess) {
            setTimeout(() => queryPrintOrderDetailResult.refetch(), 250);
        }
        console.log('22222')
    }, [nPrntPbcnNoLrnkCd, queryNPrntPbcnNoLrnkCdResult.status])

    // Form 정의
    const formRef = React.useRef();
    const [formError, setFormError] = React.useState({});
    const [formValue, setFormValue] = React.useState({
        list: []
    });

    
    useEffect(() => {
        if(queryPrintOrderDetailResult.data) {
            setFormValue(item => ({...item, list: queryPrintOrderDetailResult.data.pageList}))
        }
    }, [queryPrintOrderDetailResult.data])


    return (
        <>
            <Form
            ref={formRef}
            checkTrigger="change"
            onChange={setFormValue}
            formValue={formValue}
            >
                <Modal show={show} onHide={onHide} backdrop="static" keyboard={false} centered size="xl" className="modal-custom size-2xl">
                    <Modal.Header closeButton>
                        <Modal.Title>인쇄 배열표</Modal.Title>
                        {/* {JSON.stringify(formValue.list)} */}
                    </Modal.Header>
                    <Modal.Body>
                        <div className="grid-btn-wrap">
                            <div className="right-align">
                                <Button variant="outline-success" size="sm"><span className="excel-down"></span>{CONSTANTS.excelDownload}</Button>{' '}
                                <Button variant="outline-dark" size="sm"><span className="print"></span>{CONSTANTS.print}</Button>{' '}
                            </div>
                        </div>
                        <Table className="tbl-hor" bordered>
                            <colgroup>
                                <col style={{width:'10%'}}></col>
                                <col style={{width:'20%'}}></col>
                                <col style={{width:'10%'}}></col>
                                <col style={{width:'10%'}}></col>
                                <col style={{width:'10%'}}></col>
                                <col style={{width:'20%'}}></col>
                                <col style={{width:'10%'}}></col>
                                <col style={{width:'10%'}}></col>
                            </colgroup>
                            <tbody>
                                <tr>
                                    <th className="">발간번호</th>
                                    <td>
                                        <SelectPicker size="sm" 
                                            data={queryNPrntPbcnNoLrnkCdResult && queryNPrntPbcnNoLrnkCdResult.data ? queryNPrntPbcnNoLrnkCdResult.data : []} 
                                            searchable={false} 
                                            cleanable={false} 
                                            onChange={onChangeNPrntPbcnNoLrnkCd}
                                            value={nPrntPbcnNoLrnkCd}
                                        />
                                    </td>
                                    <th className="">수정</th>
                                    <td>
                                        {queryPrintOrderDetailResult && queryPrintOrderDetailResult.data && 
                                        queryPrintOrderDetailResult.data.modifyCount+'/'+queryPrintOrderDetailResult.data.finalCount}
                                    </td>
                                    <th className="">인쇄방법</th>
                                    <td>
                                        {queryPrintOrderDetailResult && queryPrintOrderDetailResult.data && queryPrintOrderDetailResult.data.prntWayCdNm}
                                    </td>
                                    <th className="">인쇄부수</th>
                                    <td>
                                        {queryPrintOrderDetailResult && queryPrintOrderDetailResult.data && 
                                        currencyFormatter2(queryPrintOrderDetailResult.data.prntParrQty)}
                                    </td>
                                </tr>
                            </tbody>
                        </Table>
                        <div className="print-array-wrap">
                        <Form.Group >
                            <Form.Control 
                                name="list"
                                data={formValue}
                                accepter={ListControl} 
                                fieldError={formError.list}
                                />
                        </Form.Group>
                        </div>
                        
                    </Modal.Body>
                    <Modal.Footer>
                        <Button variant="light" size="md" onClick={onHide}>취소</Button>
                        <Button variant="primary" size="md" onClick={onHide}>저장</Button>
                    </Modal.Footer>
                </Modal>
            </Form>
        </>
    );

};
export default PrintArrayTableTest;