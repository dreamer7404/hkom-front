// react
import React, {useState, useMemo, useCallback, useRef} from 'react';
import { AgGridReact } from 'ag-grid-react';
import {Button, Table} from 'react-bootstrap';
import {Form, SelectPicker, MultiCascader, Schema, Notification, toaster } from 'rsuite';
import { escapeCharChange, escapeCharChangeForGrid} from '../../../../utils/commUtils';
import { confirmAlert } from 'react-confirm-alert'; // Import
import ConfirmAlert from '../../../Common/ConfirmAlert';
import LangMultiByVehl from '../../../Search/LangMultiByVehl'

//--------------  서버데이터용 필수 -------------------------------
import { useQuery, useMutation} from 'react-query';
import { getData, postData } from '../../../../utils/async';
import { API, CONSTANTS } from '../../../../utils/constants';
import useStore from '../../../../utils/store';
import { useEffect } from 'react';
//--------------// 서버데이터용 필수 -------------------------------
import { useLocation } from 'react-router';
import { useNavigate  } from 'react-router-dom';

import qs from 'qs';

const { StringType, NumberType,  ArrayType, ObjectType, BooleanType } = Schema.Types;
const model = Schema.Model({
    langCdByVehlListVali: StringType().pattern(/^[ok]+$/, '차종 및 언어를 선택해주세요.'),
});

const ClcmUpdate = () => {

    const navigate = useNavigate();
    const location = useLocation();
    const [param, setParam] = useState(
        qs.parse(location.state, { ignoreQueryPrefix: true })
    )

    const gridRef = useRef();

    //수신형태 
    const rcpmShapParam = {dlExpdGCd: '0010'};
    const rcpmShapCombo = useQuery([API.codeCombo,rcpmShapParam], () => getData(API.codeCombo,rcpmShapParam), {
        select: data => data.map((item) => (item&&{ label: item.label, value: item.value }))
    })
    const [selectedRcpmShapCombo, setSelectedRcpmShapCombo] = useState('01')
    const onChangeRcpmShapCombo = e => {
        setSelectedRcpmShapCombo(e)
    }

    //차종 및 언어
    const langComboParam = {qltyVehlCd: param.qltyVehlCd};
    const langCombo = useQuery([API.mriClcmLangCdInfos,langComboParam], () => getData(API.mriClcmLangCdInfos,langComboParam), {
        select: data => data.map((item) => (item&&{ label: item.label, value: item.value }))
    })
    const [selectedLangCdByVehl, setSelectedLangCdByVehl] = useState(param.langCdByVehlList);
    const columnDefs = [
        {
          headerName: '차종',
          field: 'qltyVehlNm',
          cellRenderer: 'escapeCharChangeForGrid'
        },
        {
          headerName: '언어',
          field: 'langCdNm',
          cellRenderer: 'escapeCharChangeForGrid'
        },
    ]
    const [firstRender, setFirstRender] = useState(false)
    useEffect(() => {
        if(selectedLangCdByVehl.length > 0){
            setFirstRender(true)
            setFormValue(formValue => ({...formValue, langCdByVehlListVali:'ok'}))
            setFormError(formError => ({...formError, langCdByVehlListVali:''}))
        } else {
            setFormValue(formValue => ({...formValue, langCdByVehlListVali:'no'}))
            setFormError(formError => ({...formError, langCdByVehlListVali:'언어를 선택해주세요.'}))
        }
    }, [selectedLangCdByVehl])

    const [rowData2] = useState([
        {userPart: "현대자동차", userName: "홍길동"},
        {userPart: "현대자동차", userName: "김삼순"},
        {userPart: "현대자동차", userName: "김삼순"},
        {userPart: "현대자동차", userName: "김삼순"},
    ]);

    const columnDefs2 = [
        {
          checkboxSelection: true,
          headerCheckboxSelection: true,
          width:45,
          maxWidth:45,
          minWidth:45
        },
        {
          headerName: '소속',
          field: 'userPart',
        },
        {
          headerName: '이름',
          field: 'userName',
        },
    ]

    const defaultColDef = useMemo(() => {
        return {
            initialWidth: 90,
            sortable: true,
        };
    }, []);


    const onFirstDataRendered = useCallback((params) => {
        params.api.sizeColumnsToFit();
        gridRef.current.api.forEachNode((node) =>
        node.setSelected(!!node.data && node.data.userName === '김삼순')
        );
    }, []);

    // Form 정의 (for validation..)
    const formRef = React.useRef();
    const [formError, setFormError] = React.useState({});
    const [formValue, setFormValue] = React.useState({
        langCdByVehlListVali: 'no',   // 선택한 차종및언어 리스트(mutate 하기전에 가공필요..)
    });
    const reqBody = {
        dlExpdAltrNo: param.dlExpdAltrNo,
        qltyVehlCd: param.qltyVehlCd,
        langCdByVehlList: selectedLangCdByVehl,     // 선택한 차종및언어 리스트(mutate 하기전에 가공필요..)
    };

    //데이터 등록(post)
    const submitResult = useMutation((params => postData(API.mriClcmInfoPop, params, CONSTANTS.update)),{
        onSuccess: res => {
		    if(res > 0){
                toaster.push(
                    <Notification type='success' header='요청성공' closable >저장이 완료되었습니다.</Notification>
                );
                // window.location.href="./ClcmDetail"
                setTimeout(() => listButton(), 1000)
            }else{
                toaster.push(
                    <Notification type='error' header='요청실패' closable >저장을 실패했습니다.</Notification>
                );
            }
        }
    });

    const saveButton = () => {
        setFirstRender(true)
        if (!formRef.current.check()) {
            return;
        } else {
            const onOk = () => {
                submitResult.mutate(reqBody)
            }
            confirmAlert({
                closeOnClickOutside: false,
                customUI: ({ onClose }) => <ConfirmAlert 
                                                onClose={onClose} 
                                                title={"알림"}
                                                msg={"입력하신 내용으로 저장하시겠습니까?"} 
                                                onOk={onOk}  
                                            />
            })
        }
    }

    const listButton = () => {
        window.location.href="."
    }

    return (
        <>
            <div className="grid-wrap">
                <Form
                    ref={formRef}
                    checkTrigger="change"
                    onChange={setFormValue}
                    onCheck={setFormError}
                    formValue={formValue}
                    model={model}
                >
                    <Table className="tbl-hor" bordered>
                        <colgroup>
                            <col style={{width:'15%'}}></col>
                            <col style={{width:'35%'}}></col>
                            <col style={{width:'15%'}}></col>
                            <col style={{width:'35%'}}></col>
                        </colgroup>
                        <tbody>
                            <tr>
                                <th>수신형태</th>
                                <td>
                                {rcpmShapCombo && selectedRcpmShapCombo &&
                                    <SelectPicker 
                                        size="sm" 
                                        data={rcpmShapCombo&&rcpmShapCombo.data}
                                        onChange={onChangeRcpmShapCombo} 
                                        value={selectedRcpmShapCombo!==undefined?param.rcpmShapCd:'01'} 
                                        searchable={false} 
                                        cleanable={false} 
                                        disabled
                                    />
                                }
                                </td>
                                <th>등록자</th>
                                <td>{param.pprrEenoNm}</td>
                            </tr>
                            <tr>
                                <th>발신처</th>
                                <td>
                                    <Form.Control size="sm" type="text" defaultValue={param.dsppNm} disabled/>
                                </td>
                                <th>담당자</th>
                                <td>
                                    <Form.Control size="sm" type="text" defaultValue={param.crgrNm} disabled />
                                </td>
                            </tr>
                            <tr>
                                <th>차종 및 언어</th>
                                <td colSpan="3">
                                    <LangMultiByVehl 
                                        qltyVehlCd={param.qltyVehlCd} 
                                        qltyVehlNm={param.qltyVehlNm} 
                                        langCdByVehlList={param.langCdByVehlList}
                                        setSelectedLangCdByVehl={setSelectedLangCdByVehl}
                                        formErrorStatus={formError.langCdByVehlListVali} 
                                        firstRender={firstRender}
                                    />
                                </td>
                            </tr>
                            <tr>
                                <th>적용 차종 및 언어</th>
                                <td>
                                    <div className="ag-theme-alpine" style={{height: 130, transition:'all ease .3s'}}>
                                        <AgGridReact
                                            rowData={selectedLangCdByVehl}
                                            columnDefs={columnDefs}
                                            defaultColDef={defaultColDef}
                                            onFirstDataRendered={onFirstDataRendered}
                                            suppressSizeToFit={true}    
                                            onGridSizeChanged={onFirstDataRendered}   
                                            overlayNoRowsTemplate={'적용 언어를 선택하세요.'} 
                                            frameworkComponents={{escapeCharChangeForGrid}}
                                            >
                                        </AgGridReact>
                                    </div>
                                </td>
                                <th>송부인</th>
                                <td>
                                    <div className="ag-theme-alpine" style={{height: 130, transition:'all ease .3s'}}>
                                        <AgGridReact
                                            ref={gridRef}
                                            rowData={rowData2}
                                            columnDefs={columnDefs2}
                                            defaultColDef={defaultColDef}
                                            rowSelection={'multiple'}
                                            suppressRowClickSelection= {true} 
                                            onFirstDataRendered={onFirstDataRendered}
                                            suppressSizeToFit={true}    
                                            onGridSizeChanged={onFirstDataRendered}    
                                            >
                                        </AgGridReact>
                                    </div>
                                </td>
                            </tr>
                            <tr>
                                <th>제목</th>
                                <td colSpan="3">
                                    <Form.Control size="sm" type="text" defaultValue={param.altrTitl}  disabled/>
                                </td>
                            </tr>
                            <tr>
                                <th>내용</th>
                                <td colSpan="3">
                                    <Form.Control size="sm" defaultValue={param.altrSbc} disabled/>
                                </td>
                            </tr>
                            <tr>
                                <th>첨부파일</th>
                                {
                                param && param.attcYn === 'N'
                                ? <td colSpan="3">첨부파일이 없습니다.</td>
                                : <td colSpan="3">첨부파일 있음 처리 필요</td>
                                }
                            </tr>
                        </tbody>
                    </Table>
                </Form>
                <div className="btn-wrap">
                    <div className="right-align">
                        <Button variant="light" onClick={listButton}>취소</Button>{' '}
                        <Button className="" variant="primary" size="md" onClick={saveButton}>저장</Button>
                    </div>
                </div>
            </div>
        </>
    )
};
export default ClcmUpdate;