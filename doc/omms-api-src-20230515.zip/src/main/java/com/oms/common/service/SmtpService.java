package com.oms.common.service;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @author 안경수
 * @since 2023. 5. 15.
 * @see
 */

public interface SmtpService {
    void sendEmail(String[] to, String subject, String message);
}
