package com.oms.common.dto;

import org.apache.ibatis.type.Alias;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @author 안경수
 * @since 2023. 3. 22.
 * @see
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Alias("comboReqDTO")
public class ComboReqDTO {
    @Schema(type = "string", example = " ")
    private String userEeno;    // 사용자번호(아이디)

    @Schema(type = "string", example = " ")
    private String dlExpdPdiCd;  // PDI코드

    @Schema(type = "string", example = " ")
    private String dlExpdCoCd;  // 회사코드

    @Schema(type = "string", example = " ")
    private String dlExpdRegnCd;  // 지역코드

    @Schema(type = "string", example = " ")
    private String qltyVehlCd;  // 안전차량코드

    @Schema(type = "string", example = " ")
    private String mdlMdyCd;  // 연식


    @Schema(type = "string", example = " ")
    private String bDate;   // 기준일

    @Schema(type = "string", example = " ")
    private String sDate;   // 시작일

    @Schema(type = "string", example = " ")
    private String eDate; // 종료일
}
