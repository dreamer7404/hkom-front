package com.oms.common.dto;

import org.apache.ibatis.type.Alias;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @author 안경수
 * @since 2023. 2. 8.
 * @see
 */

@Data
@NoArgsConstructor
@AllArgsConstructor
@Alias("commReqDTO")
public class CommReqDTO  {
    @Schema(type = "string", example = " ")
    private String orderBy;         // order by

    private Integer pageNo;         // 페이지번호

    private Integer pageSize;       // 페이지크기

    @Schema(type = "string", example = " ")
    private String keyword;         // 키워드

    @Schema(type = "string", example = " ")
    private String userEeno;        // 사번

    @Schema(type = "string", example = " ")
    private String dlExpdGCd;       // 그룹코드

    @Schema(type = "string", example = " ")
    private String dlExpdCoCd;      // 회사코드


}
