package com.oms.common.service.impl;

import able.cloud.core.service.HService;

import org.springframework.stereotype.Service;

import com.oms.common.dao.CommDAO;
import com.oms.common.service.SmtpService;

import lombok.RequiredArgsConstructor;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @author 안경수
 * @since 2023. 5. 15.
 * @see
 */

@RequiredArgsConstructor
@Service("smtpService")
public class SmtpServiceImpl extends HService implements SmtpService {

    @Override
    public void sendEmail(String[] to, String subject, String message) {

    }

}
