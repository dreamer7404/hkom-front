package com.oms.ivm.dto;

import org.apache.ibatis.type.Alias;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @author 김정웅
 * @since 2023. 3. 13.
 * @see
 */
@Alias("totIvmRequestReqDTO")
@Data
@AllArgsConstructor
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown =true)
public class TotIvmRequestReqDTO extends ComIvmReqDTO {

    private String content;
    private String rqQty;
    private String dataSn;
    private String pExpdRqScnCd;

    //세원:sewon, PDI/용산:pdi
    private String radioType;
}
