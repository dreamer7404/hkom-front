package com.oms.ivm.dto;

import java.sql.Timestamp;

import org.apache.ibatis.type.Alias;

import com.oms.common.dto.CommReqDTO;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @author 김정웅
 * @since 2023. 3. 7.
 * @see
 */
@Alias("ivmMonthOrdPrdResDTO")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class IvmMonthOrdPrdResDTO extends CommReqDTO {

    private String gubun;
    private int flag;
    private String regnNm;
    private String langCd;
    private String langCdNm;
    private String col0;
    private String col1;
    private String col2;
    private String col3;
    private String col4;
    private String col5;
    private String col6;
    private String col7;
    private String col8;
    private String col9;
    private String col10;
    private String col11;
    private String col12;
    private String col13;

}
