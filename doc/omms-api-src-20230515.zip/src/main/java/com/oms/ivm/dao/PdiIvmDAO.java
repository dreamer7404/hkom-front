package com.oms.ivm.dao;

import java.util.HashMap;
import java.util.List;

import com.oms.ivm.dto.ComIvmReqDTO;
import com.oms.ivm.dto.PdiIvmReqDTO;
import com.oms.ivm.dto.PdiIvmResDTO;
import com.oms.ivm.dto.PdiPrndMonitorReqDTO;
import com.oms.ivm.dto.PdiPrndMonitorResDTO;
import com.oms.ivm.dto.PdiWhsnReqDTO;
import com.oms.ivm.dto.PdiWhsnResDTO;
import com.oms.ivm.dto.SewonIvModResDTO;

/**
 * <pre>
 * PdiIvmDAO 인터페이스
 * </pre>
 *
 * @Class Name  : PdiIvmDAO.java
 * @Description : 재고관리 > PDI 재고관리 DAO
 * @author 김정웅
 * @since 2023.5.4
 * @see
*/
public interface PdiIvmDAO {
    //PDI재고관리 현황 (배송여부 -> ALL:전체, 01:배송중, 02:배송완료)
    List<PdiIvmResDTO> selectPdiIvmListAll(PdiIvmReqDTO reqDto)throws Exception;
    List<PdiIvmResDTO> selectPdiIvmList01(PdiIvmReqDTO reqDto)throws Exception;
    List<PdiIvmResDTO> selectPdiIvmList02(PdiIvmReqDTO reqDto)throws Exception;

    //생산라인모니터링
    HashMap<String,String> selectPdiVFramYmd(String dlExpdCoCd, String bDate) throws Exception;
    PdiPrndMonitorResDTO selectPdiPrndMonitor(PdiPrndMonitorReqDTO reqDto) throws Exception;

    //입고확인 - 조회
    List<PdiWhsnResDTO> selectPdiWhsnList(ComIvmReqDTO reqDto)throws Exception;
    //입고확인 - 저장
    Integer getWhsnQty(PdiWhsnReqDTO reqDto) throws Exception;
    Integer insertPdiWhsnInfo (PdiWhsnReqDTO reqDto) throws Exception;
    Integer getPdiIvCnt (PdiWhsnReqDTO reqDto) throws Exception;
    Integer insertPdiIvInfo (PdiWhsnReqDTO reqDto) throws Exception;
    Integer getVQty(PdiWhsnReqDTO reqDto) throws Exception;
    Integer updatePdiIvInfoDtl5(HashMap<String, Object> param) throws Exception;
    Integer updateSewhaWhotInfo(PdiWhsnReqDTO reqDto) throws Exception;
    HashMap<String, Integer> getVQty1(PdiWhsnReqDTO reqDto) throws Exception;
    Integer updateSewhaIvInfo(PdiWhsnReqDTO reqDto) throws Exception;
    Integer insertSewhaIvInfo(PdiWhsnReqDTO reqDto) throws Exception;

    //재고보정 조회
    List<SewonIvModResDTO> selectIvPdiModList(ComIvmReqDTO reqDto) throws Exception;



    //spUpdatePdiIvDtlInfo
    HashMap<String, Object> getCmplYn (HashMap<String, Object> param) throws Exception;
    Integer updatePdiIvInfoDtl(HashMap<String, Object> param) throws Exception;
    void insertPdiIvInfoDtl(HashMap<String, Object> param) throws Exception;

    //spRecalculatePdiIvDtl4
    List<HashMap<String, Object>> getPdiIvListInfo(HashMap<String, Object> param) throws Exception;
    Integer deletePdiIvInfoDtl(HashMap<String, Object> param) throws Exception;
    Integer updatePdiIvInfoDtl2(HashMap<String, Object> param) throws Exception;
    List<HashMap<String, Object>> getMdlMdyCd(HashMap<String, Object> param) throws Exception;
    Integer getDay3PlanQty(HashMap<String, Object> param) throws Exception;
    Integer getCurrDay3PlanQty(HashMap<String, Object> param) throws Exception;
    Integer getCurrSftyIvQty(HashMap<String, Object> param) throws Exception;
    Integer getTempIvQty(HashMap<String, Object> param) throws Exception;
    Integer updatePdiIvInfoDtl3 (HashMap<String, Object> param) throws Exception;
    Integer updatePdiIvInfoDtl4 (HashMap<String, Object> param) throws Exception;
    Integer insertPdiIvInfoDtl1 (HashMap<String, Object> param) throws Exception;

    //spUpdateSewhaIvDtlInfo
    HashMap<String, Object> getSewhaCmplYn (HashMap<String, Object> param) throws Exception;
    Integer updateSewhaIvInfoDtl (HashMap<String, Object> param) throws Exception;
    void insertSewhaIvInfoDtl (HashMap<String, Object> param) throws Exception;

    //spRecalculateSewhaIvDtl4
    List<HashMap<String, Object>> getSewhaIvList(HashMap<String, Object> param) throws Exception;
    Integer deleteSewhaIvInfoDtl(HashMap<String, Object> param) throws Exception;
    Integer updateSewhaIvInfoDtl1(HashMap<String, Object> param) throws Exception;
    List<HashMap<String, Object>> getSewhaDtlIvList (HashMap<String, Object> param) throws Exception;
    HashMap<String, Object> getVDlIvQty (HashMap<String, Object> param) throws Exception;
    Integer getVDlWek2PlanQty(HashMap<String, Object> param) throws Exception;
    Integer getVDlPdiIvQty(HashMap<String, Object> param) throws Exception;
    Integer getVCurrWek2PlanQty(HashMap<String, Object> param) throws Exception;
    Integer getVCurrSftyIvQty(HashMap<String, Object> param) throws Exception;
    Integer getVCurrPdiIvQty(HashMap<String, Object> param) throws Exception;
    Integer getVTempIvQty(HashMap<String, Object> param) throws Exception;
    Integer updateSewhaIvInfoDtl2(HashMap<String, Object> param) throws Exception;
    Integer updateSewhaIvInfoDtl3(HashMap<String, Object> param) throws Exception;
    void insertSewhaIvInfoDtl1 (HashMap<String, Object> param) throws Exception;




}
