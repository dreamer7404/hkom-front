package com.oms.ivm.dto;

import org.apache.ibatis.type.Alias;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * <pre>
 * pdiIvmReqDTO
 * </pre>
 *
 * @author 김정웅
 * @since 2023. 5. 4.
 * @see
 */
@Alias("pdiIvmReqDTO")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class PdiIvmReqDTO extends ComIvmReqDTO {

    private String vSchYmd;
    private String pFromMdlMdy;
    private String pToMdlMdy;

    private String subCd; //재고상태 ex) OK, 긴급, 발주 등..
}
