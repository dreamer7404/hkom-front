package com.oms.sys.service.impl;

import java.util.List;

import able.cloud.core.service.HService;

import org.springframework.stereotype.Service;

import com.oms.common.dto.CommReqDTO;
import com.oms.sys.dao.UsrMgmtDAO;
import com.oms.sys.dto.AuthReqDTO;
import com.oms.sys.dto.AuthVehlSaveDTO;
import com.oms.sys.dto.UseYnReqDTO;
import com.oms.sys.dto.UsrMgmtReqDTO;
import com.oms.sys.dto.UsrMgmtResDTO;
import com.oms.sys.dto.UsrVehlResDTO;
import com.oms.sys.model.UsrMgmt;
import com.oms.sys.service.UsrMgmtService;

import lombok.RequiredArgsConstructor;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @author 안경수
 * @since 2023. 2. 24.
 * @see
 */

@RequiredArgsConstructor
@Service("usrMgmtService")
public class UsrMgmtServiceImpl extends HService implements UsrMgmtService {

    private final UsrMgmtDAO usrMgmtDAO;

    @Override
    public Integer insertUsrMgmt(UsrMgmtReqDTO usrMgmtReqDTO) throws Exception {
        return usrMgmtDAO.insertUsrMgmt(usrMgmtReqDTO);
    }

    @Override
    public Integer updateUsrMgmt(UsrMgmtReqDTO usrMgmtReqDTO) throws Exception {
        return usrMgmtDAO.updateUsrMgmt(usrMgmtReqDTO);
    }

    @Override
    public Integer deleteUsrMgmt(UsrMgmtReqDTO usrMgmtReqDTO) throws Exception {
        return usrMgmtDAO.deleteUsrMgmt(usrMgmtReqDTO);
    }

    @Override
    public UsrMgmtResDTO selectUsrMgmt(String id) throws Exception {
        return usrMgmtDAO.selectUsrMgmt(id);
    }

    @Override
    public List<UsrMgmtResDTO> selectUsrMgmtList(UsrMgmtReqDTO usrMgmtReqDTO) throws Exception {
        return usrMgmtDAO.selectUsrMgmtList(usrMgmtReqDTO);
    }

    @Override
    public Integer deleteVehlAuthList(AuthVehlSaveDTO dto) throws Exception {
        return usrMgmtDAO.deleteVehlAuthList(dto);

    }

    @Override
    public Integer insertVehlAuthList(List<AuthVehlSaveDTO> list) throws Exception {
        return usrMgmtDAO.insertVehlAuthList(list);
    }

    @Override
    public List<UsrVehlResDTO> selectUserVehlList(CommReqDTO commReqDTO) throws Exception {
        return usrMgmtDAO.selectUserVehlList(commReqDTO);
    }

    @Override
    public Integer updateUserPw(UsrMgmtReqDTO usrMgmtReqDTO) throws Exception {
        return usrMgmtDAO.updateUserPw(usrMgmtReqDTO);
    }

    @Override
    public Integer deleteVehlAuthListByUserEeno(String userEeno) throws Exception {
        return usrMgmtDAO.deleteVehlAuthListByUserEeno(userEeno);
    }

    @Override
    public Integer updateUserUseYn(UseYnReqDTO useYnReqDTO) throws Exception {
        return usrMgmtDAO.updateUserUseYn(useYnReqDTO);
    }

    @Override
    public Integer updateUserPwLock(String userEeno) throws Exception {
        return usrMgmtDAO.updateUserPwLock(userEeno);
    }

    @Override
    public Integer updateUserPwErrOft(AuthReqDTO authReqDTO) throws Exception {
        return usrMgmtDAO.updateUserPwErrOft(authReqDTO);
    }

    @Override
    public Integer updateUserBlnsCoCd(AuthReqDTO authReqDTO) throws Exception {
        return usrMgmtDAO.updateUserBlnsCoCd(authReqDTO);
    }

    @Override
    public UsrMgmt selectUsrMgmt4FindPw(UsrMgmtReqDTO usrMgmtReqDTO) throws Exception {
        return usrMgmtDAO.selectUsrMgmt4FindPw(usrMgmtReqDTO);
    }




}
