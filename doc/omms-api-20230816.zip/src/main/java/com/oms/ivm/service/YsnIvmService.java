package com.oms.ivm.service;

import java.util.List;

import com.oms.ivm.dto.ComIvmReqDTO;
import com.oms.ivm.dto.IvmRequestMonitorResDTO;
import com.oms.ivm.dto.YsnIvmResDTO;


/**
 * <pre>
 * YsnIvmService
 * </pre>
 *
 * @ClassName   : YsnIvmService.java
 * @Description : 재고관리 > 용산재고관리 서비스
 * @author 김정웅
 * @since 2023.6.26
 * @see
 */

public interface YsnIvmService {

    //세원재고관리 현황
    public List<YsnIvmResDTO> selectYongsanIvmList(ComIvmReqDTO reqDto);

    //요청현황
    public List<IvmRequestMonitorResDTO> selectIvmYsnReqStateList(ComIvmReqDTO reqDto) throws Exception;

    //용산배치종료일시 조회
    public String selectYongsanIvmFinBatchDtm(ComIvmReqDTO reqDto) throws Exception;
}
