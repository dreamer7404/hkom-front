package com.oms.ivm.dto;

import org.apache.ibatis.type.Alias;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @author 김정웅
 * @since 2023. 3. 15.
 * @see
 */

@Alias("ivmThisMonTrwiResDTO")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class IvmThisMonTrwiResDTO {

    private String wkYmd;   //날짜
    private int whsnQty;    //입고수량
    private int whotQty;    //투입수량
}