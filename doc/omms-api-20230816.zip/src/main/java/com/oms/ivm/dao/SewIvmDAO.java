package com.oms.ivm.dao;

import java.util.HashMap;
import java.util.List;

import com.oms.ivm.dto.ComIvmReqDTO;
import com.oms.ivm.dto.IvmRequestMonitorResDTO;
import com.oms.ivm.dto.IvmSewonPrintReqDTO;
import com.oms.ivm.dto.IvmSewonPrintResDTO;
import com.oms.ivm.dto.SewonIvModReqDTO;
import com.oms.ivm.dto.SewonIvModResDTO;
import com.oms.ivm.dto.SewonIvmReqDTO;
import com.oms.ivm.dto.SewonIvmResDTO;
import com.oms.ivm.dto.SewonWhotReqDTO;
import com.oms.ivm.dto.SewonWhotResDTO;

/**
 * <pre>
 * SewIvmDAO 인터페이스
 * </pre>
 *
 * @Class Name  : SewIvmDAO.java
 * @Description : 재고관리 > 세원재고관리 DAO
 * @author 김정웅
 * @since 2023.3.27
 * @see
*/
public interface SewIvmDAO {

    //기준일 기준 48개월 전 12개월 후의 연도 출력
    HashMap<String, String> selectValidMdlMdy4(String sdate)throws Exception;

    //세원재고현황 (배송여부 -> ALL:전체, 01:배송중, 02:배송완료)
    List<SewonIvmResDTO> selectSewonIvmListAll(SewonIvmReqDTO sewonIvmReqDTO)throws Exception;
    List<SewonIvmResDTO> selectSewonIvmList01(SewonIvmReqDTO sewonIvmReqDTO)throws Exception;
    List<SewonIvmResDTO> selectSewonIvmList02(SewonIvmReqDTO sewonIvmReqDTO)throws Exception;


    //출고현황 팝업-조회
    List<SewonWhotResDTO> selectSewonWhotList(ComIvmReqDTO reqDto) throws Exception;
    //출고현황 팝업-등록
    Integer insertSewonWhotList(SewonWhotReqDTO reqDto) throws Exception;
    //출고현황 팝업-수정
    Integer updateSewonWhotList(SewonWhotReqDTO reqDto) throws Exception;
    //출고현황 팝업-삭제
    Integer deleteSewonWhotList(SewonWhotReqDTO reqDto) throws Exception;

    //재고보정 조회
    List<SewonIvModResDTO> selectIvModList(ComIvmReqDTO reqDto) throws Exception;
    //재고보정 수정
    Integer insertIvModList(SewonIvModReqDTO reqDto) throws Exception;
    //재고 삭제
    Integer deleteIvModInfo(SewonIvModReqDTO reqDto);
    //재고 수정
    Integer updateIvModInfo(SewonIvModReqDTO reqDto);
    //재고 상세 수정
    Integer updateIvDtlModInfo(SewonIvModReqDTO reqDto);

    //출고현황
    List<SewonWhotResDTO> selectIvmSewonWhotList(ComIvmReqDTO reqDto) throws Exception;

    //요청현황
    List<IvmRequestMonitorResDTO> selectIvmSewonReqStateList(ComIvmReqDTO reqDto) throws Exception;

    //인쇄현황
    List<IvmSewonPrintResDTO> selectIvmSewonPrintList(ComIvmReqDTO reqDto) ;
    //인쇄현황 수정
    Integer updateIvmSewonPrintList(IvmSewonPrintReqDTO param);
    Integer updateIvmSewonDtlPrintList(IvmSewonPrintReqDTO param);
    //인쇄현황 인쇄취소
    Integer deleteIvmSewonPrintList(IvmSewonPrintReqDTO param);
    Integer deleteIvmSewonDtlPrintList(IvmSewonPrintReqDTO param);

    //재고보정 조회 - 월별엑셀다운로드
    List<SewonIvModResDTO> selectIvModMonthList(ComIvmReqDTO reqDto) throws Exception;

    //발주요청
    Integer insertSewonOrderRequestInfos(List<ComIvmReqDTO> reqDto) throws Exception;
}
