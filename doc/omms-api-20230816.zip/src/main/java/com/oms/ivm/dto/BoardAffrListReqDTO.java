package com.oms.ivm.dto;

import org.apache.ibatis.type.Alias;

import com.oms.common.dto.CommReqDTO;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @author 안경수
 * @since 2023. 8. 7.
 * @see
 */
@NoArgsConstructor
@Alias("boardAffrListReqDTO")
@Data
public class BoardAffrListReqDTO extends CommReqDTO{
       private String blcCoCd; // 회사코드
       private String blcScnCd; // 분류코드
       private String dlExpdPdiCd;
       private String qltyVehlCd;
       private String mdlMdyCd;
       private String regnCd; // 지역코드
       private String langCd;

       private String blcTitlNm; //제목
       private String pprrEeno; // 등록인
       private String blcSn; // 관리번호



}
