package com.oms.ivm.dto;

import org.apache.ibatis.type.Alias;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @author 김정웅
 * @since 2023. 3. 30.
 * @see
 */

@Alias("sewonIvModResDTO")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class SewonIvModResDTO {

    private String clsYmd;
    private String bDate;
    private String menuGubun;
    private String qltyVehlCd;
    private String mdlMdyCd;
    private String langCd;
    private String dlExpdMdlMdyCd;
    private String newPrntPbcnNo;
    private String qltyVehlNm;
    private String langCdNm;
    private String dtlSn;
    private String modCd;
    private String ivQty;
    private String modQty;
    private String fixedIvQty;
    private String modYmd;
    private String dlExpdRegnCd;
    private String prtlImtrSbc;
    private String clScnCd;
    private String crgrNm;
    private String dlExpdPrvsNm;
    private String oriModCd;
    private String oriModQty;
    private String oriFixedIvQty;
    private String prdnPlntCd;  //공장코드 추가

}
