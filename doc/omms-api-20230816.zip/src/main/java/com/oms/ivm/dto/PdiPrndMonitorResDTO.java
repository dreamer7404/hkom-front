package com.oms.ivm.dto;

import org.apache.ibatis.type.Alias;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @author 김정웅
 * @since 2023. 5. 8.
 * @see
 */

@Alias("pdiPrndMonitorResDTO")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class PdiPrndMonitorResDTO {

    //
    private String vFramYmd;
    private String vLocalChar;
    private int planTotQty;// = vTddPrdnPlanQty.add(vTddPrdnQty3);

    //
    private String th0PowStrtYmdhm;
    private String th0PowFnhYmdhm;
    private String th0PowTrwiQty;
    private String th1PowStrtYmdhm;
    private String th1PowFnhYmdhm;
    private String th1PowTrwiQty;
    private String th2PowStrtYmdhm;
    private String th2PowFnhYmdhm;
    private String th2PowTrwiQty;
    private String th3PowStrtYmdhm;
    private String th3PowFnhYmdhm;
    private String th3PowTrwiQty;
    private String th4PowStrtYmdhm;
    private String th4PowFnhYmdhm;
    private String th4PowTrwiQty;
    private String th5PowStrtYmdhm;
    private String th5PowFnhYmdhm;
    private String th5PowTrwiQty;
    private String th6PowStrtYmdhm;
    private String th6PowFnhYmdhm;
    private String th6PowTrwiQty;
    private String th7PowStrtYmdhm;
    private String th7PowFnhYmdhm;
    private String th7PowTrwiQty;
    private String th8PowStrtYmdhm;
    private String th8PowFnhYmdhm;
    private String th8PowTrwiQty;
    private String th9PowStrtYmdhm;
    private String th9PowFnhYmdhm;
    private String th9PowTrwiQty;
    private String th10PowStrtYmdhm;
    private String th10PowFnhYmdhm;
    private String th10PowTrwiQty;
    private String th11PowStrtYmdhm;
    private String th11PowFnhYmdhm;
    private String th11PowTrwiQty;
    private String th12PowStrtYmdhm;
    private String th12PowFnhYmdhm;
    private String th12PowTrwiQty;
    private String th13PowStrtYmdhm;
    private String th13PowFnhYmdhm;
    private String th13PowTrwiQty;
    private String th14PowStrtYmdhm;
    private String th14PowFnhYmdhm;
    private String th14PowTrwiQty;
    private String th15PowStrtYmdhm;
    private String th15PowFnhYmdhm;
    private String th15PowTrwiQty;
    private String th16PowStrtYmdhm;
    private String th16PowFnhYmdhm;
    private String th16PowTrwiQty;
    private String powStrtYmdhm;
    private String powFnhYmdhm;
    private String powTrwiQty;

//    private Ivm3DayPlanReqDTO ivm3DayPlanReqDTO;

    private String batchFinTime;
}