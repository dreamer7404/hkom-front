package com.oms.ivm.service.impl;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import able.cloud.core.service.HService;

import org.apache.poi.hpsf.Array;
import org.springframework.stereotype.Service;
import org.springframework.web.util.HtmlUtils;

import com.oms.cmm.utils.Utils;
import com.oms.common.dao.CommComboDAO;
import com.oms.common.dto.CommLangComboReqDTO;
import com.oms.common.dto.CommLangComboResDTO;
import com.oms.common.dto.MailDTO;
import com.oms.common.service.MailService;
import com.oms.ivm.dao.ComIvmDAO;
import com.oms.ivm.dao.TotIvmDAO;
import com.oms.ivm.dto.ComIvmReqDTO;
import com.oms.ivm.dto.IvmMonthOrdPrdReqDTO;
import com.oms.ivm.dto.IvmMonthOrdPrdResDTO;
import com.oms.ivm.dto.IvmNatlProdPlanResDTO;
import com.oms.ivm.dto.IvmNoapimResDTO;
import com.oms.ivm.dto.IvmRequestMonitorResDTO;
import com.oms.ivm.dto.IvmVehlIvResDTO;
import com.oms.ivm.dto.TotIvmReqDTO;
import com.oms.ivm.dto.TotIvmRequestReqDTO;
import com.oms.ivm.dto.TotIvmResDTO;
import com.oms.ivm.model.TbWrkDateMgmt;
import com.oms.ivm.service.TotIvmService;
import com.oms.common.model.Mail;

import lombok.RequiredArgsConstructor;

/**
 * <pre>
 * totalStockService
 * </pre>
 *
 * @author 김정웅
 * @since 2023. 3. 7.
 * @see
 */
@RequiredArgsConstructor
@Service("totIvmService")
public class TotIvmServiceImpl extends HService implements TotIvmService {

    private final TotIvmDAO totIvmDAO;
    private final MailService mailService;

    @Override
    public List<TotIvmResDTO> selectTotalIvmList(TotIvmReqDTO totIvmReqDTO) throws Exception {
        List<TotIvmResDTO> result = new ArrayList<TotIvmResDTO>();
//        if("02".equals(totIvmReqDTO.getDlExpdCoCd())) {
//            result = totIvmDAO.selectTotalIvmListKia(totIvmReqDTO);
//        } else {
            result = totIvmDAO.selectTotalIvmList(totIvmReqDTO);
//        }
        return result;
    }

    @Override
    public Integer intsertSeparatelyRequest(List<TotIvmRequestReqDTO> totIvmRequestReqDTO, String userEeno) throws Exception {
        int result = 0;
        List<TotIvmRequestReqDTO> params = new ArrayList<TotIvmRequestReqDTO>();

        //차종별 해당 그룹의 담당자 조회(PDI, 인쇄)


        for(TotIvmRequestReqDTO param : totIvmRequestReqDTO) {
            List<String> grpCds = new ArrayList<String>();

            param.setUserEeno(userEeno);
            // 세원 선택시 품질차종코드는 '05'로  설정
            if("sewon".equals(param.getRadioType())) {
                grpCds.add("105"); //인쇄
                param.setPExpdRqScnCd("05");
            }
            // 'PDI/용산' 선택시 언어에따라 품질차종코드를 구분해준다.
            else {
                grpCds.add("104"); //PDI
                if("KO".equals(param.getLangCd())) {
                    param.setPExpdRqScnCd("04");
                } else {
                    param.setPExpdRqScnCd("04");
                }
            }

            //이메일 세팅
            //메일용 body 세팅
            StringBuilder preSetBody = new StringBuilder();
            preSetBody.append(
                    "<tr>\n" +
                    "<td>("+param.getQltyVehlCd()+" / "+param.getMdlMdyCd()+") "+param.getQltyVehlNm()+"</td>\n" +
                    "<td>("+param.getLangCd()+")"+param.getLangCdNm()+"</td>\n" +
                    "<td>"+param.getRqQty()+"</td>\n" +
                    "</tr>"
            );
            //해당 차종의 수신자 조회
            MailDTO mailDTO = new MailDTO();
            mailDTO.setQltyVehlCd(param.getQltyVehlCd());
            mailDTO.setMdlMdyCd(param.getMdlMdyCd());
            mailDTO.setGrpCds(grpCds);
            List<Mail> rcvList = mailService.selectEmlAdrListByVehlAndGrpCd(mailDTO);

            if(rcvList.size() > 0) {
                try {
                    String content;
                    content = Utils.getEmailContent("IvmSeparatelyRequest");
                    String body = HtmlUtils.htmlEscape(content.replace("{tr}",preSetBody).replace("{comment}",totIvmRequestReqDTO.get(0).getContent()));
                    mailDTO.setEmlTitl("[Owner’s Manual System] 별도요청 메일입니다.");
                    mailDTO.setEmlSbc(body);  //본문 내용
                    mailDTO.setRcvList(rcvList); //수신자 목록
                    mailDTO.setEmlScdCd("17"); //별도요청:17
                    mailService.send(mailDTO);
                } catch (IOException e) {
                    return 0;
                }
            }
            //이메일 세팅 끝
            params.add(param);
        };
        result = totIvmDAO.intsertSeparatelyRequest(params);



        return result;
    }

    @Override
    public List<IvmMonthOrdPrdResDTO> selectMonthOrdPrdList(IvmMonthOrdPrdReqDTO reqDto) throws Exception {

        List<TbWrkDateMgmt> dlist = totIvmDAO.selectTbWrkDateMgmtList(reqDto);
        for(int i = 0 ; i < dlist.size() ; i++ ){
            String col = "col"+i;
            String ymd = dlist.get(i).getYmd2();
            if("col0".equals(col)){  reqDto.setCol0(ymd); };
            if("col1".equals(col)){  reqDto.setCol1(ymd); };
            if("col2".equals(col)){  reqDto.setCol2(ymd); };
            if("col3".equals(col)){  reqDto.setCol3(ymd); };
            if("col4".equals(col)){  reqDto.setCol4(ymd); };
            if("col5".equals(col)){  reqDto.setCol5(ymd); };
            if("col6".equals(col)){  reqDto.setCol6(ymd); };
            if("col7".equals(col)){  reqDto.setCol7(ymd); };
            if("col8".equals(col)){  reqDto.setCol8(ymd); };
            if("col9".equals(col)){  reqDto.setCol9(ymd); };
            if("col10".equals(col)){ reqDto.setCol10(ymd); };
            if("col11".equals(col)){ reqDto.setCol11(ymd); };
            if("col12".equals(col)){ reqDto.setCol12(ymd); };
            if("col13".equals(col)){ reqDto.setCol13(ymd); };
        }

        List<IvmMonthOrdPrdResDTO> result = new ArrayList<IvmMonthOrdPrdResDTO>();

        String mode = reqDto.getMode();

        HashMap<String, String> selectMsgOdrMap = new HashMap<String, String>();
        selectMsgOdrMap = totIvmDAO.selectMsgOdr(reqDto);

        reqDto.setVFramYmd(selectMsgOdrMap.get("V_FRAM_YMD"));
        reqDto.setFirstYm(dlist.get(0).getYmd2());
        reqDto.setLastYm(dlist.get(dlist.size()-1).getYmd2());

        //월간 생산 정보
        if("monPrd".equals(mode)) {
            result = totIvmDAO.selectMonthPrdList(reqDto);
        }
        //월간 오더 정보
        if("monOrd".equals(mode)) {
            result = totIvmDAO.selectMonthOrdList(reqDto);
        }
        //월간 오더대비생산 정보
        if("monOrdPrd".equals(mode)) {
            result = totIvmDAO.selectMonthOrdPrdList(reqDto);
        }

        return result;
    }

    @Override
    public List<IvmNatlProdPlanResDTO> selectNatlProdPlanList(ComIvmReqDTO comIvmReqDTO) throws Exception {
        List<IvmNatlProdPlanResDTO> result = new ArrayList<IvmNatlProdPlanResDTO>();
        result= totIvmDAO.selectNatlProdPlanList(comIvmReqDTO);

        return result;
    }

    @Override
    public List<IvmVehlIvResDTO> selectVehlIvList(ComIvmReqDTO reqDto) throws Exception {
        List<IvmVehlIvResDTO> result = new ArrayList<IvmVehlIvResDTO>();

        String mode = reqDto.getMode();
        //언어별분석
        if("lang".equals(mode)) {
            result= totIvmDAO.selectVehlIvByLangList(reqDto);
        }
        //일자별분석
        if("day".equals(mode)) {
            result= totIvmDAO.selectVehlIvByDayList(reqDto);
        }

        return result;
    }

    @Override
    public List<IvmRequestMonitorResDTO> selectOrderRequestList(ComIvmReqDTO reqDto) throws Exception {
        List<IvmRequestMonitorResDTO> result = new ArrayList<IvmRequestMonitorResDTO>();
        result = totIvmDAO.selectOrderRequestList(reqDto);
        return result;
    }

    @Override
    public List<IvmNoapimResDTO> selectNoapimList(ComIvmReqDTO reqDto) throws Exception {
        List<IvmNoapimResDTO> result = new ArrayList<IvmNoapimResDTO>();
        result = totIvmDAO.selectNoapimList(reqDto);
        return result;
    }

}
