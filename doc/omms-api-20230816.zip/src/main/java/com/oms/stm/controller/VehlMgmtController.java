package com.oms.stm.controller;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import javax.servlet.http.HttpServletRequest;

import able.cloud.core.web.HController;

import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.oms.cmm.global.Consts;
import com.oms.cmm.utils.Utils;
import com.oms.common.dto.CommReqDTO;
import com.oms.common.service.CommService;
import com.oms.stm.dto.StmComReqDTO;
import com.oms.stm.dto.VehlCrgrMgmtSaveDTO;
import com.oms.stm.dto.VehlMdyMgmtReqDTO;
import com.oms.stm.dto.VehlMdyMgmtResDTO;
import com.oms.stm.dto.VehlMgmtCrgDTO;
import com.oms.stm.dto.VehlMgmtReqDTO;
import com.oms.stm.dto.VehlMgmtResDTO;
import com.oms.stm.dto.VehlMgmtSaveDTO;
import com.oms.stm.service.VehlMgmtService;
import com.oms.sys.dto.AuthVehlSaveDTO;
import com.oms.sys.dto.UsrMgmtReqDTO;
import com.oms.sys.service.UsrMgmtService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName : VehlMgmtController.java
 * @Description :
 * @author 김경훈
 * @since 2023. 3. 13.
 * @see
 */
@Tag(name = "VehlMgmtController", description = "")
@RequiredArgsConstructor
@RestController
@RequestMapping("/api")
public class VehlMgmtController extends HController {
    /**
     * 클래스 Injection
     */
    private final VehlMgmtService vehlMgmtService;

    private final UsrMgmtService usrService;
    private final CommService commonService;
    private final HttpServletRequest request;

    @Operation(summary = "차종 조회")
    @GetMapping("/vehlMgmts")
    public HashMap<String, Object> vehlMgmts(@ModelAttribute StmComReqDTO dto) throws Exception {

        CommReqDTO comDto = new CommReqDTO();
        comDto.setDlExpdGCd("0008");

        HashMap<String, Object> map = new HashMap<String, Object>();
        map.put("userEeno", Utils.getUserEeno(request));
        map.put("dlExpdCoCd", Utils.getDlExpdCoCd(request));
        map.put("qltyVehlCd", dto.getQltyVehlCd());
        map.put("mdlMdyCd", dto.getMdlMdyCd());
        map.put("dlExpdPdiCd", dto.getDlExpdPdiCd());
        map.put("userEenoSch", dto.getChrgId());
        map.put("grpCd", Utils.getDlExpdCoCd(request).equals("01")?"101" : "102");
        List<String>chrgId = dto.getChrgId();
        dto.setChrgId(chrgId);
        map.put("chrgId", chrgId);


        List<VehlMgmtResDTO> regnList = commonService.selectCodeList(comDto); // 지역 구분 코드리스트
        for (int i = 0; i < regnList.size(); i++) {
            String column = "col" + Integer.toString(i + 1);
            map.put(column, regnList.get(i).getDlExpdPrvsCd()); // 지역코드(북미..)
        }
        // {col1: '01'}....

        List<VehlMgmtResDTO> vehlList = vehlMgmtService.selectVehlMgmtList(map);

        HashMap<String, Object> resultMap = new HashMap<String, Object>();
        resultMap.put("regnList", regnList); // 지역코드리스트 - 지역코드 이름필요해서
        resultMap.put("vehlList", vehlList); // 치종코드관리리스트
        return resultMap;

    }
    @Operation(summary = "PDI박스")
    @GetMapping("/pdiComboAll")
    public List<VehlMgmtResDTO> pdiComboAll() throws Exception {

        List<VehlMgmtResDTO> pdiCombo = vehlMgmtService.selectAllPdiList();
        return pdiCombo;
    }
    @Operation(summary = "승상코드콤보박스")
    @GetMapping("/dlExpdPacScnCombo")
    public List<VehlMgmtResDTO> dlExpdPacScnCombo(@ModelAttribute StmComReqDTO dto) throws Exception {
        dto.setUserEeno(Utils.getUserEeno(request)); // 사용자
        dto.setDlExpdCoCd(Utils.getDlExpdCoCd(request)); // 회사구분
        List<VehlMgmtResDTO> dlExpdPacScnCombo = vehlMgmtService.selectDlExpdPacScnCdList(dto);
        return dlExpdPacScnCombo;
    }

    @Operation(summary = "수신형태콤보박스")
    @GetMapping("/dlExpdPrvsCombo")
    public List<VehlMgmtResDTO> dlExpdPrvsCombo(@ModelAttribute StmComReqDTO dto) throws Exception {
        CommReqDTO comDto = new CommReqDTO();
        dto.setUserEeno(Utils.getUserEeno(request)); // 사용자
        dto.setDlExpdCoCd(Utils.getDlExpdCoCd(request)); // 회사구분
        comDto.setDlExpdGCd("0007");// 수신형태
        List<VehlMgmtResDTO> codeList = commonService.selectCodeList(comDto);
        return codeList;
    }

    @Operation(summary = "기존 차종 연식별 조회(콤보박스)")
    @GetMapping("/qltyVehlMdyCombo")
    public List<VehlMgmtResDTO> qltyVehlMdyCombo(@ModelAttribute StmComReqDTO dto) throws Exception {
        dto.setUserEeno(Utils.getUserEeno(request)); // 토큰 사용자
        dto.setDlExpdCoCd(Utils.getDlExpdCoCd(request));

        return vehlMgmtService.selectCpyTgVehl(dto);

    }

    @Operation(summary = "차종복사")
    @GetMapping("/langCopys")
    public HashMap<String, Object> langCopys(@ModelAttribute StmComReqDTO dto, HttpServletRequest request)
            throws Exception {

        HashMap<String, Object> resultMap = new HashMap();
        dto.setDlExpdCoCd(Utils.getDlExpdCoCd(request));

        List<HashMap<String, Object>> copyLangList = vehlMgmtService.selectVehlMgmtNatlLangList(dto);

        resultMap.put("copyLangList", copyLangList);
        return resultMap;
    }

    @Operation(summary = "상세조회")
    @GetMapping("/vehlMgmt")
    public HashMap<String, Object> vehlMgmtDetail(@ModelAttribute StmComReqDTO dto, HttpServletRequest request)
            throws Exception {

        HashMap<String, Object> resultMap = new HashMap<String, Object>();
        dto.setUserEeno(Utils.getUserEeno(request)); // 토큰 사용자
        dto.setDlExpdCoCd(Utils.getDlExpdCoCd(request));
        HashMap<String, Object> map = new HashMap<String, Object>();
        CommReqDTO comDto = new CommReqDTO();
        comDto.setDlExpdGCd("0008");

        List<VehlMgmtResDTO> regnList = commonService.selectCodeList(comDto); // 지역 구분 코드리스트
        for (int i = 0; i < regnList.size(); i++) {
            int num = i + 1;
            String column = "col" + Integer.toString(num);
            map.put(column, regnList.get(i).getDlExpdPrvsCd());
        }

        map.put("qltyVehlCd", dto.getQltyVehlCd());
        map.put("mdlMdyCd", dto.getMdlMdyCd());
        map.put("dlExpdPdiCd", dto.getDlExpdPdiCd());
        map.put("dlExpdCoCd", dto.getDlExpdCoCd());
        if(  dto.getDlExpdCoCd().equals("01")) {
            map.put("grpCd", "101");
        }else {
            map.put("grpCd", "102");
        }
        // 상세 리스트
        VehlMgmtResDTO vehlMgmtInfo = vehlMgmtService.selectVehlMgmtInfo(map);


        List<VehlMgmtCrgDTO> usrList01 = vehlMgmtService.selectVehlChrgList(map);
        map.put("grpCd", "103");
        List<VehlMgmtCrgDTO> usrList03 = vehlMgmtService.selectVehlChrgList(map);
        map.put("grpCd", "104");
        List<VehlMgmtCrgDTO> usrList04 = vehlMgmtService.selectVehlChrgList(map);
        map.put("grpCd", "105");
        List<VehlMgmtCrgDTO> usrList05 = vehlMgmtService.selectVehlChrgList(map);

        map.put("grpCd", "106");
        List<VehlMgmtCrgDTO> usrList06 = vehlMgmtService.selectVehlChrgList(map);

        List<HashMap<String, Object>> natlLangList = vehlMgmtService.selectVehlMgmtNatlLangList(dto);

        List<Map<String, String>> regnDlpvList = new ArrayList<>();
        if (vehlMgmtInfo.getRegn01() != null) {
            regnDlpvList.add(Map.of("regnCd", "01", "mdlRelCd", vehlMgmtInfo.getRegn01()));
        }
        if (vehlMgmtInfo.getRegn02() != null) {
            regnDlpvList.add(Map.of("regnCd", "02", "mdlRelCd", vehlMgmtInfo.getRegn02()));
        }
        if (vehlMgmtInfo.getRegn03() != null) {
            regnDlpvList.add(Map.of("regnCd", "03", "mdlRelCd", vehlMgmtInfo.getRegn03()));
        }
        if (vehlMgmtInfo.getRegn04() != null) {
            regnDlpvList.add(Map.of("regnCd", "04", "mdlRelCd", vehlMgmtInfo.getRegn04()));
        }
        if (vehlMgmtInfo.getRegn05() != null) {
            regnDlpvList.add(Map.of("regnCd", "05", "mdlRelCd", vehlMgmtInfo.getRegn05()));
        }
        if (vehlMgmtInfo.getRegn06() != null) {
            regnDlpvList.add(Map.of("regnCd", "06", "mdlRelCd", vehlMgmtInfo.getRegn06()));
        }

        resultMap.put("regnDlpvList", regnDlpvList); // 저장용 연식(지역)정보
        resultMap.put("usrList01", usrList01);
        resultMap.put("usrList03", usrList03);
        resultMap.put("usrList06", usrList06);
        resultMap.put("usrList04", usrList04);
        resultMap.put("usrList05", usrList05);
        resultMap.put("natlLangList", natlLangList);
        resultMap.put("vehlMgmtInfo", vehlMgmtInfo);

        return resultMap;
    }

    @Transactional
    @Operation(summary = "차종 관리 등록")
    @PostMapping("/vehlMgmt")
    public HashMap<String, Object> vehlMgmtReg(@RequestBody VehlMgmtReqDTO vehlReqDTO, HttpServletRequest request)
            throws Exception {
        String method = Utils.getMethod(request);
        String dlExpdCoCd = Utils.getDlExpdCoCd(request);
        int result = 0;
        HashMap<String, Object> resultMap = new HashMap<String, Object>();

        VehlMgmtCrgDTO crgDto = new VehlMgmtCrgDTO();

        if (method.equals(Consts.INSERT)) { // dto

            vehlReqDTO.setUserEeno(Utils.getUserEeno(request));
            vehlReqDTO.setDlExpdCoCd(Utils.getDlExpdCoCd(request));

            String oriQltyVehlCd = vehlReqDTO.getQltyVehlCd(); // 차종코드
            String oriMdlMdyCd = vehlReqDTO.getMdlMdyCd(); // 연식

            vehlReqDTO.setOriQltyVehlCd(oriQltyVehlCd);
            vehlReqDTO.setOriMdlMdyCd(oriMdlMdyCd);

            String qltyVehlNm = vehlReqDTO.getQltyVehlNm();
            vehlReqDTO.setQltyVehlNm(qltyVehlNm.replace("&#40;", "(").replace("&#41;", ")")); // 차종명
            String blnsCoCd = "";
            String grpCd = "";
            try {
                String vehlcd = vehlMgmtService.selectVehlMgmtCnt(vehlReqDTO); // 차종코드 중복 확인 Y일경우 저장가능, N일경우 저장불가
                String cocdChk = vehlMgmtService.selectVehlCoCdCnt(vehlReqDTO); // 차종코드 중복 확인 Y일경우 저장가능, N일경우 저장불가
                if("N".equals(cocdChk)) {
                    resultMap.put("coCdChk", "err1"); //다른 회사 차종코드에 중복된 차종코드가 있습니다.
                    return resultMap;
                }

                if ("Y".equals(vehlcd)) {

                    vehlMgmtService.insertVehlMgmtMain(vehlReqDTO);
                    // 해당 차종에 대해서 연식이 있을 경우에는 팝업을 열지 않음
                    String mdychk = vehlMgmtService.selectVehlMdyChk(vehlReqDTO);
                    if ("P".equals(mdychk)) { // 연식 쪽에서 자동 매핑시켜주기위해
                        resultMap.put("qltyVehlCd", vehlReqDTO.getQltyVehlCd());
                        resultMap.put("dlExpdPdiCd", vehlReqDTO.getDlExpdPdiCd());
                        resultMap.put("dlExpdRegnCd", vehlReqDTO.getDlExpdRegnCd());
                    }
                    resultMap.put("mdyChk", mdychk);

                    // 담당자 처리 Start
                    vehlMgmtService.deleteVehlMgmtCrgr(vehlReqDTO); // 담당자 전체 삭제 후 재등록
                    List<AuthVehlSaveDTO> list = new ArrayList<>();
                    // 본인 할당
                    for (int i = 0; i < 1; i++) {
                        list.add(new AuthVehlSaveDTO(vehlReqDTO.getQltyVehlCd(), null, dlExpdCoCd,
                                vehlReqDTO.getUserEeno(), vehlReqDTO.getUserEeno(), "U", null));
                        result = usrService.deleteVehlAuthList(list.get(i));
                    }
                    result = usrService.insertVehlAuthList(list);
                    if(vehlReqDTO.getDlExpdCoCd().equals("01")) {
                        blnsCoCd ="01";
                        grpCd = "101";
                    }else {
                        blnsCoCd ="02";
                        grpCd = "102";
                    }
                    if (vehlReqDTO.getUsrList01() != null && vehlReqDTO.getUsrList01().size() > 0) {
                        List<VehlCrgrMgmtSaveDTO> listCrgr = new ArrayList<>();
                        for (int i = 0; i < vehlReqDTO.getUsrList01().size(); i++) {
                            listCrgr.add(new VehlCrgrMgmtSaveDTO(vehlReqDTO.getQltyVehlCd(), vehlReqDTO.getMdlMdyCd(),
                                    blnsCoCd, vehlReqDTO.getUsrList01().get(i), // 해당 차종 담당자
                                    vehlReqDTO.getUserEeno(),grpCd));
                        }
                        if (dlExpdCoCd.equals("01")) {
                            crgDto.setGrpCd("101");
                        } else {
                            crgDto.setGrpCd("102");
                        }

                        crgDto.setQltyVehlCd(vehlReqDTO.getQltyVehlCd());
                        crgDto.setDlExpdCoCd(dlExpdCoCd);

                        crgDto.setClScnCd("U");
                        crgDto.setUserEeno(vehlReqDTO.getUserEeno());

                        result = vehlMgmtService.insertHmcVehlAuth(crgDto);
                        result = vehlMgmtService.insertVehlMgmtCrgr(listCrgr);
                    }
                    // 외주업체
                    if (vehlReqDTO.getUsrList03() != null && vehlReqDTO.getUsrList03().size() > 0) {
                        List<VehlCrgrMgmtSaveDTO> listCrgr = new ArrayList<>();
                        List<AuthVehlSaveDTO> listUser = new ArrayList<>();

                        for (int i = 0; i < vehlReqDTO.getUsrList03().size(); i++) {
                            listCrgr.add(new VehlCrgrMgmtSaveDTO(vehlReqDTO.getQltyVehlCd(), vehlReqDTO.getMdlMdyCd(),
                                    "03", vehlReqDTO.getUsrList03().get(i), // 해당 차종 담당자
                                    vehlReqDTO.getUserEeno(),"103"));

                            listUser.add(new AuthVehlSaveDTO(vehlReqDTO.getUsrList03().get(i), // 해당 차종 담당자
                                    vehlReqDTO.getQltyVehlCd(), "03", vehlReqDTO.getUserEeno()));
                            result = usrService.deleteVehlAuthList(listUser.get(i)); // 권한등록
                        }
                        result = usrService.deleteVehlAuthList(listUser.get(0)); // 권한등록
                        result = usrService.insertVehlAuthList(listUser); // 권한등록
                        result = vehlMgmtService.insertVehlMgmtCrgr(listCrgr); // 담당자 등록
                    }

                    // 세원
                    if (vehlReqDTO.getUsrList04() != null && vehlReqDTO.getUsrList04().size() > 0) {
                        List<VehlCrgrMgmtSaveDTO> listCrgr = new ArrayList<>();
                        List<AuthVehlSaveDTO> listUser = new ArrayList<>();

                        for (int i = 0; i < vehlReqDTO.getUsrList04().size(); i++) {
                            listCrgr.add(new VehlCrgrMgmtSaveDTO(vehlReqDTO.getQltyVehlCd(), vehlReqDTO.getMdlMdyCd(),
                                    "04", vehlReqDTO.getUsrList04().get(i), // 해당 차종 담당자
                                    vehlReqDTO.getUserEeno(),"104"));

                            listUser.add(new AuthVehlSaveDTO(vehlReqDTO.getUsrList04().get(i), // 해당 차종 담당자
                                    vehlReqDTO.getQltyVehlCd(), "04", vehlReqDTO.getUserEeno()));
                            result = usrService.deleteVehlAuthList(listUser.get(i)); // 권한등록
                        }



                        result = usrService.insertVehlAuthList(listUser); // 권한등록
                        result = vehlMgmtService.insertVehlMgmtCrgr(listCrgr); // 담당자 등록

                    }
                    // PDI
                    if (vehlReqDTO.getUsrList06() != null && vehlReqDTO.getUsrList06().size() > 0) {

                        List<VehlCrgrMgmtSaveDTO> listCrgr = new ArrayList<>();
                        List<AuthVehlSaveDTO> listUser = new ArrayList<>();

                        for (int i = 0; i < vehlReqDTO.getUsrList06().size(); i++) {
                            listCrgr.add(new VehlCrgrMgmtSaveDTO(vehlReqDTO.getQltyVehlCd(), vehlReqDTO.getMdlMdyCd(),
                                    "06", vehlReqDTO.getUsrList06().get(i), // 해당 차종 담당자
                                    vehlReqDTO.getUserEeno(),"106"));

                            listUser.add(new AuthVehlSaveDTO(vehlReqDTO.getUsrList06().get(i), // 해당 차종 담당자
                                    vehlReqDTO.getQltyVehlCd(), "06", vehlReqDTO.getUserEeno()));
                            result = usrService.deleteVehlAuthList(listUser.get(i)); // 권한등록
                        }

                        result = usrService.insertVehlAuthList(listUser); // 권한등록
                        result = vehlMgmtService.insertVehlMgmtCrgr(listCrgr); // 담당자 등록

                    }
                    // 용산
                    if (vehlReqDTO.getUsrList05() != null && vehlReqDTO.getUsrList05().size() > 0) {

                        List<VehlCrgrMgmtSaveDTO> listCrgr = new ArrayList<>();
                        List<AuthVehlSaveDTO> listUser = new ArrayList<>();

                        for (int i = 0; i < vehlReqDTO.getUsrList05().size(); i++) {
                            listCrgr.add(new VehlCrgrMgmtSaveDTO(vehlReqDTO.getQltyVehlCd(), vehlReqDTO.getMdlMdyCd(),
                                    "05", vehlReqDTO.getUsrList05().get(i), // 해당 차종 담당자
                                    vehlReqDTO.getUserEeno(),"105"));

                            listUser.add(new AuthVehlSaveDTO(vehlReqDTO.getUsrList05().get(i), // 해당 차종 담당자
                                    vehlReqDTO.getQltyVehlCd(), "05", vehlReqDTO.getUserEeno()));
                            result = usrService.deleteVehlAuthList(listUser.get(i)); // 권한등록
                        }


                        result = usrService.insertVehlAuthList(listUser); // 권한등록
                        result = vehlMgmtService.insertVehlMgmtCrgr(listCrgr); // 담당자 등록

                    }
                    result = vehlMgmtService.insertALLVehlAuthList(vehlReqDTO); // 권한 추가

                    // 담당자 처리 End
                    // 연식관계 처리 Start
                    vehlMgmtService.deleteVehlMgmtRegnRelCd(vehlReqDTO); // 연식관계 전체 삭제 후 재등록
                    vehlMgmtService.deleteVehlDlExpdMdyMgmt(vehlReqDTO); // 차량별 이전연식관계 전체 삭제

                    List<VehlMgmtReqDTO> regnDlpvList = vehlReqDTO.getRegnDlpvList();

                    int length = regnDlpvList.size();

                    for (int i = 0; i < length; i++) {
                        String regnCd = vehlReqDTO.getRegnDlpvList().get(i).getRegnCd();

                        String mdyRelCd = vehlReqDTO.getRegnDlpvList().get(i).getMdlRelCd();
                        if (mdyRelCd != null && !"".equals(mdyRelCd)) {
                            vehlReqDTO.getRegnDlpvList().get(i).setQltyVehlCd(vehlReqDTO.getQltyVehlCd());
                            vehlReqDTO.getRegnDlpvList().get(i).setMdlMdyCd(vehlReqDTO.getMdlMdyCd());
                            vehlReqDTO.getRegnDlpvList().get(i).setDlExpdRegnCd(regnCd);
                            vehlReqDTO.getRegnDlpvList().get(i).setJbMdyRelCd(mdyRelCd);
                            vehlReqDTO.getRegnDlpvList().get(i).setUserEeno(vehlReqDTO.getUserEeno());

                            vehlMgmtService.insertVehlMgmtRegnRelCd(regnDlpvList.get(i));
                            // TB_DL_EXPD_MDY_MGMT 차량별 이전연식관계 재등록

                            if ("01".equals(mdyRelCd)) { // 완전통합 (미사용)
                                vehlReqDTO.setDlExpdMdlMdyCd(oriMdlMdyCd);
                                vehlReqDTO.getRegnDlpvList().get(i).setDlExpdMdlMdyCd(oriMdlMdyCd);
                                vehlMgmtService.insertVehlDlExpdMdyMgmt(regnDlpvList.get(i)); // 기본 연식관계 등록
                                // 이전연식 조회
                                preDlExpdMdyList(regnDlpvList.get(i));
                                // 이후연식 조회
                                nextDlExpdMdyList(regnDlpvList.get(i));
                            } else if ("02".equals(mdyRelCd)) { // 후 MY 가능 (미사용)
                                vehlReqDTO.getRegnDlpvList().get(i).setDlExpdMdlMdyCd(oriMdlMdyCd);
                                vehlMgmtService.insertVehlDlExpdMdyMgmt(regnDlpvList.get(i)); // 기본 연식관계 등록
                                // 이후연식 조회
                                nextDlExpdMdyList(regnDlpvList.get(i));
                            } else if ("03".equals(mdyRelCd)) { // 전 MY 가능
                                vehlReqDTO.getRegnDlpvList().get(i).setDlExpdMdlMdyCd(oriMdlMdyCd);
                                vehlMgmtService.insertVehlDlExpdMdyMgmt(regnDlpvList.get(i)); // 기본 연식관계 등록
                                // 이전연식 조회
                                preDlExpdMdyList(regnDlpvList.get(i));
                            } else { // 완전분리
                                vehlReqDTO.getRegnDlpvList().get(i).setDlExpdMdlMdyCd(oriMdlMdyCd);
                                vehlMgmtService.insertVehlDlExpdMdyMgmt(regnDlpvList.get(i)); // 기본 연식관계 등록
                            }
                            // 차종별 언어 코드 등록
                            langMdyMgntSave(regnDlpvList.get(i));
                        }
                    }
                    // 세화재고 재계산
                    // PG_DATA.SP_RECALCULATE_SEWHA_IV_DTL3(V_SYST_YMD, P_VEHL_CD, P_USER_EENO);
                    // vehlMgmtService.spRecalculateSewonIvDtl3(vehlReqDTO);

                    // PDI재고 재계산
                    // PG_DATA.SP_RECALCULATE_PDI_IV_DTL3(V_SYST_YMD, P_VEHL_CD, P_USER_EENO);
                    // vehlMgmtService.spRecalculatePdiIvDtl3(vehlReqDTO);
                    // 공정코드 처리 Start
                    vehlMgmtService.deleteVehlMgmtAltn(vehlReqDTO);

                    String dytmPlnCd = vehlReqDTO.getDytmPlnCd();
                    if (dytmPlnCd != null && !"".equals(dytmPlnCd)) {
                        vehlReqDTO.setPrdnVehlCd(dytmPlnCd);

                        vehlReqDTO.setPrvsScnCd("A");
                        vehlMgmtService.insertVehlMgmtAltn(vehlReqDTO);
                    }
                    String prdnMstCd = vehlReqDTO.getPrdnMstCd();
                    if (prdnMstCd != null && !"".equals(prdnMstCd)) {
                        vehlReqDTO.setPrdnVehlCd(prdnMstCd);
                        vehlReqDTO.setPrvsScnCd("B");
                        vehlMgmtService.insertVehlMgmtAltn(vehlReqDTO);
                    }
                    String bomVehlCd = vehlReqDTO.getBomVehlCd();
                    if (bomVehlCd != null && !"".equals(bomVehlCd)) {
                        vehlReqDTO.setPrdnVehlCd(bomVehlCd);
                        vehlReqDTO.setPrvsScnCd("C");
                        vehlMgmtService.insertVehlMgmtAltn(vehlReqDTO);
                    }
                    String saleVehlCd = vehlReqDTO.getSaleVehlCd();
                    if (saleVehlCd != null && !"".equals(saleVehlCd)) {
                        vehlReqDTO.setPrdnVehlCd(saleVehlCd);
                        vehlReqDTO.setPrvsScnCd("D");
                        vehlMgmtService.insertVehlMgmtAltn(vehlReqDTO);
                    }

                    // 국가별 언어코드 등록
                    vehlMgmtService.deleteNatlVehlLang(vehlReqDTO); // 차량의 국가별 언어 리스트 전체 삭제

                    for (int i = 0; i < vehlReqDTO.getNatlList().size(); i++) {
                        VehlMgmtSaveDTO vehlMgmtSaveDTO = vehlReqDTO.getNatlList().get(i);
                        vehlReqDTO.setDlExpdNatCd(vehlMgmtSaveDTO.getDlExpdNatCd());
                        String chkVehl = vehlMgmtService.selectNatlVehlChk(vehlReqDTO); // 연식마다 다를 수 있어서 확인 후 추가 등록
                        if ("N".equals(chkVehl)) { // 확인 카운트가 없으면 등록
                            vehlMgmtSaveDTO.setDlExpdCoCd(dlExpdCoCd);
                            vehlMgmtSaveDTO.setQltyVehlCd(vehlReqDTO.getQltyVehlCd());
                            vehlMgmtSaveDTO.setPprrEeno(vehlReqDTO.getUserEeno());
                            result = vehlMgmtService.insertNatlVehlMgmt(vehlMgmtSaveDTO); // 국가별 차량코드 등록
                        }

                        for (int j = 0; j < vehlMgmtSaveDTO.getLangs().size(); j++) {
                            vehlMgmtSaveDTO.setLangCd(vehlMgmtSaveDTO.getLangs().get(j)); // 차량별 언어코드 등록
                            vehlMgmtSaveDTO.setMdlMdyCd(vehlReqDTO.getMdlMdyCd());
                            vehlMgmtSaveDTO.setDlExpdCoCd(dlExpdCoCd);
                            vehlMgmtSaveDTO.setQltyVehlCd(vehlReqDTO.getQltyVehlCd());
                            vehlMgmtSaveDTO.setPprrEeno(vehlReqDTO.getUserEeno());
                            result = vehlMgmtService.insertNatlVehlLang(vehlMgmtSaveDTO); // 차량별 언어코드 등록
                        }
                    }
                    // 저장
//                    vehlMgmtService.updateVehlMgmtMain(vehlReqDTO);
                    resultMap.put("resultCode", 200);
                } else if ("N".equals(vehlcd)) { // 중복
                    resultMap.put("resultCode", 300);
                } else {
                    resultMap.put("resultCode", -1);
                }

            } catch (Exception ex) {
                ex.printStackTrace();
            }

        } else if (method.equals(Consts.UPDATE)) {
            vehlReqDTO.setUserEeno(Utils.getUserEeno(request));
            vehlReqDTO.setDlExpdCoCd(Utils.getDlExpdCoCd(request)); // 회사코드

            String oriQltyVehlCd = vehlReqDTO.getQltyVehlCd(); // 차종코드
            String oriMdlMdyCd = vehlReqDTO.getMdlMdyCd(); // 연식
            String blnsCoCd = "";
            String grpCd = "";
            vehlReqDTO.setOriQltyVehlCd(oriQltyVehlCd);
            vehlReqDTO.setOriMdlMdyCd(oriMdlMdyCd);

            String qltyVehlNm = vehlReqDTO.getQltyVehlNm();
            vehlReqDTO.setQltyVehlNm(qltyVehlNm.replace("&#40;", "(").replace("&#41;", ")")); // 차종명

            try {
                // 해당 차종에 대해서 연식이 있을 경우에는 팝업을 열지 않음 (mdychk == 'P' CONFIRM ALERT뜬다, 'Y' 그냥 패스)
                String mdychk = vehlMgmtService.selectVehlMdyChk(vehlReqDTO);
                if ("P".equals(mdychk)) { // 연식 쪽에서 자동 매핑시켜주기위해
                    resultMap.put("qltyVehlCd", vehlReqDTO.getQltyVehlCd());
                    resultMap.put("dlExpdPdiCd", vehlReqDTO.getDlExpdPdiCd());
                    resultMap.put("dlExpdRegnCd", vehlReqDTO.getDlExpdRegnCd());
                }
                resultMap.put("mdyChk", mdychk);

                // --------------------- 담당자 처리
                // ----------------------------------------------------------
                // 담당자 전체 삭제
                result = vehlMgmtService.deleteVehlMgmtCrgr(vehlReqDTO);
                List<AuthVehlSaveDTO> list = new ArrayList<>();

                // ------------- 로그인한 사용자 [차종권한] 전체삭제후
                // 저장----------------------------------------
                for (int i = 0; i < 1; i++) {
                    list.add(new AuthVehlSaveDTO(vehlReqDTO.getQltyVehlCd(), null, dlExpdCoCd, vehlReqDTO.getUserEeno(),
                            vehlReqDTO.getUserEeno(), "U", null));
                    result = usrService.deleteVehlAuthList(list.get(i));
                }
                result = usrService.insertVehlAuthList(list);

                // ------------- 해당차종에 관한 담당자 등록----------------------------------------
                // hmc/kmc
                if (vehlReqDTO.getUsrList01() != null && vehlReqDTO.getUsrList01().size() > 0) {
                    List<VehlCrgrMgmtSaveDTO> listCrgr = new ArrayList<>();
                    if(vehlReqDTO.getDlExpdCoCd().equals("01")) {
                        blnsCoCd ="01";
                        grpCd = "101";

                    }else {
                        blnsCoCd ="02";
                        grpCd = "102";
                    }

                    for (int i = 0; i < vehlReqDTO.getUsrList01().size(); i++) {
                        listCrgr.add(new VehlCrgrMgmtSaveDTO(vehlReqDTO.getQltyVehlCd(), vehlReqDTO.getMdlMdyCd(),
                                blnsCoCd, vehlReqDTO.getUsrList01().get(i), // 해당 차종 담당자
                                vehlReqDTO.getUserEeno(),grpCd));
                    }
                    result = vehlMgmtService.insertVehlMgmtCrgr(listCrgr);
                }
                // 외주업체
                if (vehlReqDTO.getUsrList03() != null && vehlReqDTO.getUsrList03().size() > 0) {
                    List<VehlCrgrMgmtSaveDTO> listCrgr = new ArrayList<>();
                    List<AuthVehlSaveDTO> listUser = new ArrayList<>();

                    for (int i = 0; i < vehlReqDTO.getUsrList03().size(); i++) {
                        listCrgr.add(new VehlCrgrMgmtSaveDTO(vehlReqDTO.getQltyVehlCd(), vehlReqDTO.getMdlMdyCd(),
                                "03", vehlReqDTO.getUsrList03().get(i), // 해당 차종 담당자
                                vehlReqDTO.getUserEeno(),"103"));

                        listUser.add(new AuthVehlSaveDTO(vehlReqDTO.getUsrList03().get(i), // 해당 차종 담당자
                                vehlReqDTO.getQltyVehlCd(), "03", vehlReqDTO.getUserEeno()));
                        result = usrService.deleteVehlAuthList(listUser.get(i)); // 권한등록
                    }


                    result = usrService.insertVehlAuthList(listUser); // 권한등록
                    result = vehlMgmtService.insertVehlMgmtCrgr(listCrgr); // 담당자 등록
                }

                // pdi
                if (vehlReqDTO.getUsrList04() != null && vehlReqDTO.getUsrList04().size() > 0) {
                    List<VehlCrgrMgmtSaveDTO> listCrgr = new ArrayList<>();
                    List<AuthVehlSaveDTO> listUser = new ArrayList<>();

                    for (int i = 0; i < vehlReqDTO.getUsrList04().size(); i++) {
                        listCrgr.add(new VehlCrgrMgmtSaveDTO(vehlReqDTO.getQltyVehlCd(), vehlReqDTO.getMdlMdyCd(),
                                "04", vehlReqDTO.getUsrList04().get(i), // 해당 차종 담당자
                                vehlReqDTO.getUserEeno(),"104"));

                        listUser.add(new AuthVehlSaveDTO(vehlReqDTO.getUsrList04().get(i), // 해당 차종 담당자
                                vehlReqDTO.getQltyVehlCd(), "04", vehlReqDTO.getUserEeno()));
                        result = usrService.deleteVehlAuthList(listUser.get(i)); // 권한등록
                    }

                    result = usrService.insertVehlAuthList(listUser); // 권한등록
                    result = vehlMgmtService.insertVehlMgmtCrgr(listCrgr); // 담당자 등록

                }

                // 인쇄
                if (vehlReqDTO.getUsrList05() != null && vehlReqDTO.getUsrList05().size() > 0) {

                    List<VehlCrgrMgmtSaveDTO> listCrgr = new ArrayList<>();
                    List<AuthVehlSaveDTO> listUser = new ArrayList<>();

                    for (int i = 0; i < vehlReqDTO.getUsrList05().size(); i++) {
                        listCrgr.add(new VehlCrgrMgmtSaveDTO(vehlReqDTO.getQltyVehlCd(), vehlReqDTO.getMdlMdyCd(),
                                "05", vehlReqDTO.getUsrList05().get(i), // 해당 차종 담당자
                                vehlReqDTO.getUserEeno(),"105"));

                        listUser.add(new AuthVehlSaveDTO(vehlReqDTO.getUsrList05().get(i), // 해당 차종 담당자
                                vehlReqDTO.getQltyVehlCd(), "05", vehlReqDTO.getUserEeno()));
                        result = usrService.deleteVehlAuthList(listUser.get(i)); // 권한등록
                    }

                    result = usrService.insertVehlAuthList(listUser); // 권한등록
                    result = vehlMgmtService.insertVehlMgmtCrgr(listCrgr); // 담당자 등록

                }
                // 용산
                if (vehlReqDTO.getUsrList06() != null && vehlReqDTO.getUsrList06().size() > 0) {

                    List<VehlCrgrMgmtSaveDTO> listCrgr = new ArrayList<>();
                    List<AuthVehlSaveDTO> listUser = new ArrayList<>();

                    for (int i = 0; i < vehlReqDTO.getUsrList06().size(); i++) {
                        listCrgr.add(new VehlCrgrMgmtSaveDTO(vehlReqDTO.getQltyVehlCd(), vehlReqDTO.getMdlMdyCd(),
                                "06", vehlReqDTO.getUsrList06().get(i), // 해당 차종 담당자
                                vehlReqDTO.getUserEeno(),"106"));

                        listUser.add(new AuthVehlSaveDTO(vehlReqDTO.getUsrList06().get(i), // 해당 차종 담당자
                                vehlReqDTO.getQltyVehlCd(), "06", vehlReqDTO.getUserEeno()));
                        result = usrService.deleteVehlAuthList(listUser.get(i)); // 권한등록
                    }

                    result = usrService.insertVehlAuthList(listUser); // 권한등록
                    result = vehlMgmtService.insertVehlMgmtCrgr(listCrgr); // 담당자 등록

                }
                // [연식]관계 처리 Start
                vehlMgmtService.deleteVehlMgmtRegnRelCd(vehlReqDTO); // 연식관계 전체 삭제
                vehlMgmtService.deleteVehlDlExpdMdyMgmt(vehlReqDTO); // 차량별 이전연식관계 전체 삭제

                List<VehlMgmtReqDTO> regnDlpvList = vehlReqDTO.getRegnDlpvList();
                if (regnDlpvList != null) {
                    for (int i = 0; i < regnDlpvList.size(); i++) {
                        String regnCd = vehlReqDTO.getRegnDlpvList().get(i).getRegnCd();

                        String mdyRelCd = vehlReqDTO.getRegnDlpvList().get(i).getMdlRelCd();
                        if (mdyRelCd != null && !"".equals(mdyRelCd)) {
                            vehlReqDTO.getRegnDlpvList().get(i).setQltyVehlCd(vehlReqDTO.getQltyVehlCd());
                            vehlReqDTO.getRegnDlpvList().get(i).setMdlMdyCd(vehlReqDTO.getMdlMdyCd());
                            vehlReqDTO.getRegnDlpvList().get(i).setDlExpdRegnCd(regnCd);
                            vehlReqDTO.getRegnDlpvList().get(i).setJbMdyRelCd(mdyRelCd);
                            vehlReqDTO.getRegnDlpvList().get(i).setUserEeno(vehlReqDTO.getUserEeno());
                            vehlMgmtService.insertVehlMgmtRegnRelCd(regnDlpvList.get(i));
                            // TB_DL_EXPD_MDY_MGMT 차량별 이전연식관계 재등록

                            if ("01".equals(mdyRelCd)) { // 완전통합 (미사용)
                                vehlReqDTO.setDlExpdMdlMdyCd(oriMdlMdyCd);
                                vehlReqDTO.getRegnDlpvList().get(i).setDlExpdMdlMdyCd(oriMdlMdyCd);
                                vehlMgmtService.insertVehlDlExpdMdyMgmt(regnDlpvList.get(i)); // 기본 연식관계 등록
                                // 이전연식 조회
                                preDlExpdMdyList(regnDlpvList.get(i));
                                // 이후연식 조회
                                nextDlExpdMdyList(regnDlpvList.get(i));
                            } else if ("02".equals(mdyRelCd)) { // 후 MY 가능 (미사용)
                                vehlReqDTO.getRegnDlpvList().get(i).setDlExpdMdlMdyCd(oriMdlMdyCd);
                                vehlMgmtService.insertVehlDlExpdMdyMgmt(regnDlpvList.get(i)); // 기본 연식관계 등록
                                // 이후연식 조회
                                nextDlExpdMdyList(regnDlpvList.get(i));
                            } else if ("03".equals(mdyRelCd)) { // 전 MY 가능
                                vehlReqDTO.getRegnDlpvList().get(i).setDlExpdMdlMdyCd(oriMdlMdyCd);
                                vehlMgmtService.insertVehlDlExpdMdyMgmt(regnDlpvList.get(i)); // 기본 연식관계 등록
                                // 이전연식 조회
                                preDlExpdMdyList(regnDlpvList.get(i));
                            } else { // 완전분리
                                vehlReqDTO.getRegnDlpvList().get(i).setDlExpdMdlMdyCd(oriMdlMdyCd);
                                vehlMgmtService.insertVehlDlExpdMdyMgmt(regnDlpvList.get(i)); // 기본 연식관계 등록
                            }
                            // 차종별 언어 코드 등록
                            langMdyMgntSave(regnDlpvList.get(i));
                        }
                    }
                }
                // 세화재고 재계산
                // PG_DATA.SP_RECALCULATE_SEWHA_IV_DTL3(V_SYST_YMD, P_VEHL_CD, P_USER_EENO);
                // vehlMgmtService.spRecalculateSewonIvDtl3(vehlReqDTO);

                // PDI재고 재계산
                // PG_DATA.SP_RECALCULATE_PDI_IV_DTL3(V_SYST_YMD, P_VEHL_CD, P_USER_EENO);
                // vehlMgmtService.spRecalculatePdiIvDtl3(vehlReqDTO);
                // ------ [연계차종코드] 공정코드 처리 -----------------------------------
                vehlMgmtService.deleteVehlMgmtAltn(vehlReqDTO); // 삭제

                String dytmPlnCd = vehlReqDTO.getDytmPlnCd();
                if (dytmPlnCd != null && !"".equals(dytmPlnCd)) {
                    vehlReqDTO.setPrdnVehlCd(dytmPlnCd);

                    vehlReqDTO.setPrvsScnCd("A"); // aps
                    vehlMgmtService.insertVehlMgmtAltn(vehlReqDTO); // 저장
                }
                String prdnMstCd = vehlReqDTO.getPrdnMstCd();
                if (prdnMstCd != null && !"".equals(prdnMstCd)) {
                    vehlReqDTO.setPrdnVehlCd(prdnMstCd);
                    vehlReqDTO.setPrvsScnCd("B"); // 생산
                    vehlMgmtService.insertVehlMgmtAltn(vehlReqDTO);
                }
                String bomVehlCd = vehlReqDTO.getBomVehlCd();
                if (bomVehlCd != null && !"".equals(bomVehlCd)) {
                    vehlReqDTO.setPrdnVehlCd(bomVehlCd);
                    vehlReqDTO.setPrvsScnCd("C"); // bom
                    vehlMgmtService.insertVehlMgmtAltn(vehlReqDTO);
                }
                String saleVehlCd = vehlReqDTO.getSaleVehlCd();
                if (saleVehlCd != null && !"".equals(saleVehlCd)) {
                    vehlReqDTO.setPrdnVehlCd(saleVehlCd);
                    vehlReqDTO.setPrvsScnCd("D"); // 판매
                    vehlMgmtService.insertVehlMgmtAltn(vehlReqDTO);
                }

                // ------// [연계차종코드] 공정코드 처리 -----------------------------------

                // 국가별 언어코드 등록
                vehlMgmtService.deleteNatlVehlLang(vehlReqDTO); // 차량의 국가별 언어 리스트 전체 삭제

                for (int i = 0; i < vehlReqDTO.getNatlList().size(); i++) {
                    VehlMgmtSaveDTO vehlMgmtSaveDTO = vehlReqDTO.getNatlList().get(i);
                    vehlReqDTO.setDlExpdNatCd(vehlMgmtSaveDTO.getDlExpdNatCd());
                    String chkVehl = vehlMgmtService.selectNatlVehlChk(vehlReqDTO); // 연식마다 다를 수 있어서 확인 후 추가 등록
                    if ("N".equals(chkVehl)) { // 확인 카운트가 없으면 등록
                        vehlMgmtSaveDTO.setDlExpdCoCd(dlExpdCoCd);
                        vehlMgmtSaveDTO.setQltyVehlCd(vehlReqDTO.getQltyVehlCd());
                        vehlMgmtSaveDTO.setPprrEeno(vehlReqDTO.getUserEeno());
                        result = vehlMgmtService.insertNatlVehlMgmt(vehlMgmtSaveDTO); // 국가별 차량코드 등록
                    }

                    for (int j = 0; j < vehlMgmtSaveDTO.getLangs().size(); j++) {
                        vehlMgmtSaveDTO.setLangCd(vehlMgmtSaveDTO.getLangs().get(j)); // 차량별 언어코드 등록
                        vehlMgmtSaveDTO.setMdlMdyCd(vehlReqDTO.getMdlMdyCd());
                        vehlMgmtSaveDTO.setDlExpdCoCd(dlExpdCoCd);
                        vehlMgmtSaveDTO.setQltyVehlCd(vehlReqDTO.getQltyVehlCd());
                        vehlMgmtSaveDTO.setPprrEeno(vehlReqDTO.getUserEeno());
                        result = vehlMgmtService.insertNatlVehlLang(vehlMgmtSaveDTO); // 차량별 언어코드 등록
                    }
                }

                // 차종코드 저장
                vehlMgmtService.updateVehlMgmtMain(vehlReqDTO);
                resultMap.put("resultCode", 200);

            } catch (Exception ex) {
                ex.printStackTrace();
                resultMap.put("resultCode", -1);
            }
        }

        return resultMap;

    }

    @Operation(summary = "차종관리 엑실다운로드")
    @GetMapping("/vehlMgmtExcelList")

    public List<VehlMgmtResDTO> vehlMgmtExcel(StmComReqDTO dto) throws Exception {
        dto.setUserEeno(Utils.getUserEeno(request));

        return null;
        // return vehlMgmtService.selectVehlMgmtList(dto);
    }

    @Operation(summary = "연식 조회")
    @GetMapping("/vehlMdyMgmts")
    public HashMap<String, Object> vehlMdyMgmts(@ModelAttribute VehlMdyMgmtReqDTO mdyDto) throws Exception {

        HashMap<String, Object> resultMap = new HashMap<String, Object>();
        HashMap<String, Object> map = new HashMap<String, Object>();
        List<HashMap<String, Object>> mdlMdyCdList = new ArrayList();

        List<LocalDate> dateList = new ArrayList();
        List<HashMap<String, Object>> dateList2 = new ArrayList<HashMap<String, Object>>();

        String qltyVehlCd = mdyDto.getQltyVehlCd();
        String dlExpdRegnCd = mdyDto.getDlExpdRegnCd();
        String dlExpdPacScnCd = mdyDto.getDlExpdPacScnCd();
        String dlExpdPdiCd = mdyDto.getDlExpdPdiCd();
        try {

        LocalDate sDate = LocalDate.parse(mdyDto.getSYm()); // 시작 일자
        LocalDate endDate = LocalDate.parse(mdyDto.getEYm()); // 종료 일자
        LocalDate eDate = endDate.plusMonths(1); // 1을 더해서 마지막 달이 포함되도록
        dateList = getDatesBetweenTwoDates(sDate, eDate); // 날짜 사이 목록 구하기

        for (int i = 0; i < dateList.size(); i++) {
            HashMap<String, Object> param = new HashMap<String, Object>();

//            map.put("col" + (i + 1), dateList.get(i).toString()); // hashMap에 날짜 리스트 추가
//            param.put("col" + (i + 1), dateList.get(i).toString());
//            param.put("key", "col" + (i + 1));

            String col = String.format("col%02d", (i + 1));
            map.put(col, dateList.get(i).toString()); // hashMap에 날짜 리스트 추가
            param.put(col, dateList.get(i).toString());
            param.put("key", col);
            param.put("value", dateList.get(i).toString());
            dateList2.add(i, param);
        }

        // String nqltyVehlCd = mdyDto.getNqltyVehlCd();
        //
        //
        //
        // if("ALL".equals(qltyVehlCd)){
        // qltyVehlCd = nqltyVehlCd;
        // mdyDto.setQltyVehlCd(nqltyVehlCd);
        // }

        if ("ALL".equals(dlExpdPacScnCd)) {
            mdyDto.setDlExpdPacScnCd("");
        } // 데이터 ALL이 파싱될 경우
        if ("ALL".equals(qltyVehlCd)) {
            mdyDto.setQltyVehlCd("");
        } // 데이터 ALL이 파싱될 경우
        if ("ALL".equals(dlExpdRegnCd)) {
            mdyDto.setDlExpdRegnCd("");
        } // 데이터 ALL이 파싱될 경우
        if ("ALL".equals(dlExpdPdiCd)) {
            mdyDto.setDlExpdPdiCd("");
        } // 데이터 ALL이 파싱될 경우

        map.put("qltyVehlCd", mdyDto.getQltyVehlCd());
        map.put("dlExpdRegnCd", mdyDto.getDlExpdRegnCd());
        map.put("dlExpdPacScnCd", mdyDto.getDlExpdPacScnCd());
        map.put("dlExpdPdiCd", mdyDto.getDlExpdPdiCd());
        map.put("dlExpdCoCd", Utils.getDlExpdCoCd(request));
        map.put("sYm", mdyDto.getSYm());
        map.put("eYm", mdyDto.getEYm());

            mdlMdyCdList = vehlMgmtService.selectVehlMdyList(map);
        }
        catch(Exception e) {
            resultMap.put("err", "데이터 오류가 있습니다. 중복된 월팩을 삭제해주세요." );
            resultMap.put("mdyList", mdlMdyCdList); // 데이터 리스트
            resultMap.put("dateList", dateList2); // 날짜 컬럼리스트 컬럼 할당해야함..
            return resultMap;
        }

        // mv.addObject("mdyList", mdyList);
        //// mv.addObject("qltyVehlCd", qltyVehlCd);
        //// mv.addObject("dlExpdRegnCd", dlExpdRegnCd);
        //// mv.addObject("dlExpdPacScnCd", dlExpdPacScnCd);
        // mv.addObject("sYm", sYm);
        // mv.addObject("eYm", eYm);
        // mv.addObject("nqltyVehlCd", nqltyVehlCd);
        // mv.addObject("mdyMonth", mdyMonth);
        // mv.addObject("okmsg", request.getParameter("okmsg"));

        resultMap.put("mdyList", mdlMdyCdList); // 데이터 리스트
        resultMap.put("dateList", dateList2); // 날짜 컬럼리스트 컬럼 할당해야함..

        return resultMap;
    }

    @Operation(summary = "연식 상세")
    @GetMapping("/vehlMdyMgmt")
    public HashMap<String, Object> vehlMdyMgmt(@ModelAttribute VehlMdyMgmtReqDTO mdyDto) throws Exception {

        HashMap<String, Object> resultMap = new HashMap<String, Object>();
        VehlMdyMgmtResDTO detailInfo = vehlMgmtService.selectVehlMdyMgmt(mdyDto);

        String maxInfoYn = vehlMgmtService.selectMaxInfoYn(mdyDto);

        resultMap.put("detailInfo", detailInfo);
        resultMap.put("maxInfoYn", maxInfoYn);

        return resultMap;
    }

    @Operation(summary = "연식 관리 저장")
    @PostMapping("/vehlMdyMgmt")
    public HashMap<String, Object> vehlMdyMgmt(@RequestBody VehlMdyMgmtReqDTO dto, HttpServletRequest request)
            throws Exception {
        HashMap<String, Object> resultMap = new HashMap<String, Object>();
        String method = Utils.getMethod(request);
        String userEeno = Utils.getUserEeno(request);
        dto.setUserEeno(userEeno);
        int sMonth = dto.getDesmp1Cd();
        int eMonth = dto.getDefmp1Cd();
        int result = 0;

        if ("".equals(dto.getDefmp1Cd()) || dto.getDefmp1Cd() == 0) {
            dto.setDefmp1Cd(9999);
        }
        VehlMdyMgmtResDTO MdyChk = vehlMgmtService.selectMdyChk1(dto); // 현 연식 조회
        VehlMdyMgmtResDTO MdyChk2 = vehlMgmtService.selectMdyChk2(dto); // 이전 연식 조회
        String chk = MdyChk.getChk(); // 마지막으로 등록된 연식값이 있는지?
        String prevStrtPack = MdyChk.getPrevStrtPack(); // 있으면 당시 시작월팩 없으면 'N'
        String prevEndPack = MdyChk.getPrevEndPack(); // 있으면 당시 종료월팩 없으면 'N'
        dto.setPrevMdlMdyCd(MdyChk.getPrevMdlMdyCd());

        if (method.equals(Consts.INSERT)) { // dto
            try {
                if ("N".equals(chk)) { // 등록된 연식 없음 바로 등록

                    vehlMgmtService.insertVehlMdyInfo(dto); // 연식 등록
                    resultMap.put("msg", "ok");
                } else { // 등록된 이전 연식이 있다면
                    int preMonth = Integer.parseInt(prevStrtPack);// 이전시작월팩
                    int preEMonth = Integer.parseInt(prevEndPack); // 마지막에 등록된 종료월팩

                    dto.setPrevStrtPack(preMonth);
                    String prechk = MdyChk2.getChk();// 입력하려는 연식과 같은 연식데이터가 있는지?

                    if ("N".equals(prechk)) { // 등록됐던 연식중에 없을 경우

                        dto.setPrevEndPack(preEMonth);
                        if (sMonth <= preMonth) {
                            //
                            resultMap.put("msg", "err1"); // 신규 시작월팩이 기존시작월팩 보다 보다 커야 합니다.
                        } else if (sMonth <= preEMonth && 9999 != preEMonth) {
                            //
                            resultMap.put("msg", "err2");// 현 시작월팩이 기존 종료월팩 보다 작은경우 알림
                        } else {
                            result = vehlMgmtService.updateVehlMdyEndInfo(dto); // 신규 등록시 현 연식 마감월팩 수정(9999 에서 등록월 -1)

                            // 마감원팩이 있을경우 마감월팩을 넣어줌
                            result = vehlMgmtService.insertVehlMdyInfo(dto); // asis ==마감연일 9999default Tobe== 입력받은값
                                                                             // null일경우 9999
                            resultMap.put("msg", "ok");
                        }
                    } else { // 등록할때 중복데이터가 있다면
                        resultMap.put("msg", "dup");

                    }
                }
            } catch (Exception ex) {

                ex.printStackTrace();
            }
        } else if (method.equals(Consts.UPDATE)) {
            VehlMdyMgmtReqDTO prvsMdyInfo = vehlMgmtService.prvsVehlMdyInfo(dto);
            VehlMdyMgmtReqDTO nextMdyInfo = vehlMgmtService.nextVehlMdyInfo(dto);

            if (prvsMdyInfo != null) {
                prvsMdyInfo.setOrgnDesmp1Cd(sMonth); // 업데이트 구분할 값
                prvsMdyInfo.setOrgnDefmp1Cd(eMonth);
                vehlMgmtService.updateVehlPreMdyInfo(prvsMdyInfo);// 이전연식 수정 마감월팩 수정 (등록할 시작월팩 -1)
            }

            vehlMgmtService.updateVehlMdyInfo(dto); // 입력한 해당 연식 월팩 수정

            if (nextMdyInfo != null) {
                nextMdyInfo.setOrgnDesmp1Cd(sMonth);
                nextMdyInfo.setOrgnDefmp1Cd(eMonth);
                vehlMgmtService.updateVehlNextMdyInfo(nextMdyInfo);// 다음연식 수정 시작월팩 수정 (등록할 마감월팩 +1)
            }

            resultMap.put("msg", "ok");// 현 시작월팩이 이전 종료월팩 보다 작은경우 알림

        } else if (method.equals(Consts.DELETE)) {

            vehlMgmtService.deleteVehlMdy(dto); // 현 연식 삭제
            VehlMdyMgmtResDTO mdyChk = vehlMgmtService.selectMdyChk3(dto); // 이전 연식 조회
            String prechk = mdyChk.getChk();

            if ("N".equals(prechk)) {

                dto.setMdlMdyCd(mdyChk.getPprevMdlMdyCd());
                vehlMgmtService.updateAftDelMdyInfo(dto); // 이전연식 업데이트
            }
            resultMap.put("msg", "ok");// 현 시작월팩이 이전 종료월팩 보다 작은경우 알림
        }

        return resultMap;
    }

    private void preDlExpdMdyList(VehlMgmtReqDTO vo) throws Exception {

        // 이후연식 조회
        List<VehlMgmtResDTO> preMdyList = vehlMgmtService.selectDlExpdMdyPreList(vo);
        if (preMdyList.isEmpty() == false) {
            for (int i = 0; i < preMdyList.size(); i++) {
                String preMdlMdyCd = preMdyList.get(i).getMdlMdyCd();
                String preChkMdy = preMdyList.get(i).getChkMdy();

                if ("Y".equals(preChkMdy)) {
                    vo.setDlExpdMdlMdyCd(preMdlMdyCd);
                    vehlMgmtService.insertVehlDlExpdMdyMgmt(vo);
                } else {
                    vo.setDlExpdMdlMdyCd(preMdlMdyCd);
                    vehlMgmtService.insertVehlDlExpdMdyMgmt(vo);
                    break;
                }
            }
        }
    }

    private void nextDlExpdMdyList(VehlMgmtReqDTO vo) throws Exception {
        // 이후연식 조회
        List<VehlMgmtResDTO> nextMdyList = vehlMgmtService.selectDlExpdMdyNextList(vo);
        if (nextMdyList.isEmpty() == false) {
            for (int i = 0; i < nextMdyList.size(); i++) {
                String nextMdlMdyCd = nextMdyList.get(i).getMdlMdyCd();
                String nextChkMdy = nextMdyList.get(i).getChkMdy();

                if ("Y".equals(nextChkMdy)) {
                    vo.setDlExpdMdlMdyCd(nextMdlMdyCd);
                    vehlMgmtService.insertVehlDlExpdMdyMgmt(vo);
                } else {
                    vo.setDlExpdMdlMdyCd(nextMdlMdyCd);
                    vehlMgmtService.insertVehlDlExpdMdyMgmt(vo);
                    break;
                }
            }
        }
    }

    private void langMdyMgntSave(VehlMgmtReqDTO vo) throws Exception {

        List<VehlMgmtResDTO> langListInfo = vehlMgmtService.selectVehlLangList(vo);

        if (langListInfo.isEmpty() == false) {
            for (int i = 0; i < langListInfo.size(); i++) {
                String langCd = langListInfo.get(i).getLangCd();

                vo.setLangCd(langCd);
                vehlMgmtService.deleteVehlLang(vo);
                vehlMgmtService.insertVehlLangInfo(vo);
            }
        }
    }

    public static List<LocalDate> getDatesBetweenTwoDates(LocalDate startDate, LocalDate endDate) {
        int numOfMonthsBetween = (int) ChronoUnit.MONTHS.between(startDate, endDate);
        return IntStream.iterate(0, i -> i + 1).limit(numOfMonthsBetween).mapToObj(i -> startDate.plusMonths(i))
                .collect(Collectors.toList());
    }

}