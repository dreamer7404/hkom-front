package com.oms.stm.service;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import com.oms.common.dto.RcvrResDTO;
import com.oms.stm.dto.BoardReqDTO;
import com.oms.stm.dto.BoardResDTO;
import com.oms.sys.dto.UsrMgmtResDTO;



/**
 * <pre>
 * BoardService
 * </pre>
 *
 * @ClassName   : BoardService.java
 * @Description :
 * @author 안경수
 * @since 2023.1.6
 * @see
 */

public interface BoardService {

    /**
     * Statements
     *
     * @param boardReqDTO
     * @return
     */
    public List<BoardResDTO> selectBoardList(BoardReqDTO boardReqDTO) throws Exception;

    /**
     * Statements
     *
     * @param boardReqDTO
     * @return
     */
    public List<BoardResDTO> selectBoardGrpList(BoardReqDTO boardReqDTO) throws Exception;


    /**
     * Statements
     *
     * @param boardReqDTO
     */
    public Integer insertBoard(BoardReqDTO boardReqDTO);

    /**
     * Statements
     *
     * @param boardReqDTO
     */
    public Integer insertRcvrMgmt(BoardReqDTO boardReqDTO);
    /**
     * Statements
     *
     * @param boardReqDTO
     * @return
     */
    public Integer deleteBoard(BoardReqDTO boardReqDTO);

    /**
     * Statements
     *
     * @param boardReqDTO
     * @return
     */
    public Integer updateBoard(BoardReqDTO boardReqDTO);

    /**
     * Statements
     *
     * @param boardReqDTO
     * @return
     */
    public BoardResDTO selectBoardOne(BoardReqDTO boardReqDTO);

    /**
     * Statements
     *
     * @param boardReqDTO
     * @return
     */
    public List<UsrMgmtResDTO> selectRcvrList(BoardReqDTO boardReqDTO);

    /**
     * Statements
     *
     * @param boardReqDTO
     * @return
     */
    public List<RcvrResDTO> selectRcvrChkList(BoardReqDTO boardReqDTO);

    /**
     * Statements
     *
     * @param boardReqDTO
     * @return
     */
    public int deleteBoardRecvr(BoardReqDTO boardReqDTO);

    /**
     * Statements
     *
     * @param boardReqDTO
     * @return
     */
    public int deleteBoardMulti(BoardReqDTO boardReqDTO);

    /**
     * Statements
     *
     * @param boardReqDTO
     * @return
     */
    public int deleteBoardRecvrMulti(BoardReqDTO boardReqDTO);




}
