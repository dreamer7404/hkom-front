package com.oms.stm.dto;

import org.apache.ibatis.type.Alias;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;




/**
 * <pre>
 * Statements
 * </pre>
 * @ClassName : VehlJobDTO.java
 * @Description :
 * @author 김경훈
 * @since 2023. 6. 26.
 * @see
 */
@Alias("vehlJobDto")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class VehlJobDTO {
    private String qltyVehlCd;
    private String qltyVehlNm;
    private String mdlMdyCd;
    private String userEeno;
    private String userEmlAdr;
    private String desmp1Cd;
    private String defmp1Cd;
    private String dlExpdRegnNm;


}
