package com.oms.common.dao;

import java.util.List;

import com.oms.common.dto.MailDTO;
import com.oms.common.model.Mail;


/**
 * <pre>
 * Statements
 * </pre>
 * @ClassName : MailDAO.java
 * @Description :
 * @author 안경수
 * @since 2023. 5. 26.
 * @see
 */
public interface MailDAO {

    int insertLogEml(MailDTO mailDTO);
    int insertLogEmlSnd(MailDTO mailDTO);
    int updateLogEmlSnd(MailDTO mailDTO);
    List<Mail> selectEmlAdrList(List<String> list);
    /**
     * Statements
     *
     * @param mailDTO
     * @return
     */
    List<Mail> selectRcvLIst(MailDTO mailDTO);

    //긴급인쇄조회
    List<MailDTO> selectUrgentPrintList();

    //차종별 담당자 조회(+그룹코드 구분)
    List<Mail> selectEmlAdrListByVehlAndGrpCd(MailDTO mailDTO);



}
