package com.oms.common.scheduler;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.web.util.HtmlUtils;

import com.oms.cmm.utils.Utils;
import com.oms.common.dto.MailDTO;
import com.oms.common.model.Mail;
import com.oms.common.service.MailService;

import lombok.RequiredArgsConstructor;
import net.javacrumbs.shedlock.spring.annotation.EnableSchedulerLock;
import net.javacrumbs.shedlock.spring.annotation.SchedulerLock;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @author 김정웅
 * @since 2023. 7. 23.
 * @see
 */
//@EnableScheduling
@RequiredArgsConstructor
@Component
@EnableSchedulerLock(defaultLockAtMostFor = "PT4S")
public class UrgentPrintList {

    private final MailService mailService;

//    @SchedulerLock(name="Scheduler_UrgentPrint",    lockAtMostFor = "PT10S", lockAtLeastFor = "PT10S")
//    @Scheduled(initialDelay = 1000 * 2, fixedDelay=1000 * 60 * 10)
    public void runSendMail() {
        List<MailDTO> result = new ArrayList<MailDTO>();

        result = mailService.selectUrgentPrintList();
        if(result.size() > 0) {
            try {
                for(MailDTO item : result) {
                    StringBuilder preSetBody = new StringBuilder();

                    List<Mail> rcvList = new ArrayList<Mail>();
                    Mail rcv = new Mail();
                    rcv.setEmlId(item.getRcvrId());
                    rcv.setEmlAdr(item.getAdreEml());
                    rcvList.add(rcv);

                    preSetBody.append(item.getEmlSbc());
                    MailDTO mailDTO = new MailDTO();
                    String content;
                    content = Utils.getEmailContent("UrgentPrintListSendMail");
                    String body = HtmlUtils.htmlEscape(content.replace("{table}",preSetBody));
                    mailDTO.setEmlTitl(item.getEmlTitl());
                    mailDTO.setEmlSbc(body);  //본문 내용
                    mailDTO.setEmlScdCd("03"); //긴급인쇄리스트:03, 별도요청:17, PDI배송요청:18, PDI발주요청:19, 용산발주요청:20
                    mailDTO.setRcvList(rcvList);
                    mailDTO.setEmlCd(item.getEmlCd());
                    mailService.send(mailDTO);
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

}
