package com.oms.common.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.oms.cmm.utils.Utils;
import com.oms.common.dto.AttcFileReqDTO;
import com.oms.common.dto.AttcFileResDTO;
import com.oms.common.service.AttcFileService;
import com.oms.common.service.CommService;
import com.oms.stm.dto.BoardReqDTO;
import com.oms.stm.dto.BoardResDTO;
import com.oms.sys.dto.UsrMgmtReqDTO;
import com.oms.sys.dto.UsrMgmtResDTO;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;



/**
 * <pre>
 * Statements
 * </pre>
 * @ClassName : CommController.java
 * @Description :
 * @author 김경훈
 * @since 2023. 3. 22.
 * @see
 */
@Tag(name = "CommController", description = "")
@RequiredArgsConstructor
@RestController
@RequestMapping("/api")
public class CommController {

    private final AttcFileService attcFileService;
    private final CommService commService;



    @Operation(summary = "사용자 정보 조회")
    @GetMapping(value = "/userMgmtPop")
    public List<UsrMgmtResDTO> userMgmtPop(@ModelAttribute UsrMgmtReqDTO dto, HttpServletRequest request) throws Exception {

        dto.setDlExpdCoCd(Utils.getDlExpdCoCd(request));

        if("101".equals(dto.getGrpCd())) {
            if("01".equals(Utils.getDlExpdCoCd(request))) {
                dto.setGrpCd("101"); //현대
            }else {
                dto.setGrpCd("102");  //기아
            }
        }
        List<UsrMgmtResDTO> userList =commService.userMgmtPop(dto);

        return  userList;
    }

    @Operation(summary = "공지사항 팝업 조회")
    @GetMapping(value = "/noticeList")
    public List<BoardResDTO> noticeList(@ModelAttribute BoardReqDTO dto, HttpServletRequest request) throws Exception {


        List<BoardResDTO> userList =commService.selectNoticeList(dto);

        return  userList;
    }
    @Operation(summary = "공지사항 팝업 여부")
    @GetMapping(value = "/noticePopYn")
    public String  noticePopYn(@ModelAttribute BoardReqDTO dto, HttpServletRequest request) throws Exception {

        dto.setUserEeno(Utils.getUserEeno(request));




        return  commService.noticePopYn(dto);
    }

    @GetMapping(value = "/fileDownload")
    public List<AttcFileResDTO> downloadFiles(@ModelAttribute AttcFileReqDTO attcFileReqDTO) throws IOException {

        List<AttcFileResDTO> fileList = new ArrayList<>();

        // attcSn 으로 가져오기
        if(attcFileReqDTO.getAttcSnOld() != null && !attcFileReqDTO.getAttcSnOld().isEmpty()) {
            fileList = attcFileService.selectAttcFileListByAttcSn(attcFileReqDTO.getAttcSnOld());
        }
        // attcGbn & gbnSn 으로 가져오기
        else{
            fileList =  attcFileService.selectAttcFileList(attcFileReqDTO);
        }
        return fileList;
    }



}
