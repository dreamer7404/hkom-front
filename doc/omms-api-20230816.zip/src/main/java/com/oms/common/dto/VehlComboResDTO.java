package com.oms.common.dto;

import org.apache.ibatis.type.Alias;

import lombok.Data;

/**
 * <pre>
 * 차량코드 combo용
 * </pre>
 *
 * @author 안경수
 * @since 2023. 3. 22.
 * @see
 */
@Data
@Alias("vehlComboResDTO")
public class VehlComboResDTO {
    private String qltyVehlCd;
    private String qltyVehlNm;
    private String clScnCd;
    private String expdCoCd;
    private String expdCoNm;
    private String expdPacScnCd;
    private String expdPacScnNm;
    private String expdPdiCd;
    private String expdPdiNm;
    private String label;
    private String value;
}
