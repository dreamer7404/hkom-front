package com.oms.cmm.global;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @author 안경수
 * @since 2023. 2. 8.
 * @see
 */

public class Consts {
    public static final String JASPYT_ALGORITHM = "PBEWithMD5AndDES";

    public static final String INSERT = "insert";
    public static final String UPDATE = "update";
    public static final String DELETE = "delete";

    public static final String SECRET_KEY  = "HyundaiAndKiaOwnersManualSystemSecretKey";
    public static final String METHOD = "_method";
    public static final String X_AUTH_TOKEN = "x-auth-token";
    public static final String X_AUTH_BROWSER = "x-auth-browser";
    public static final String X_FORWARDED_FOR = "X-FORWARDED-FOR";

    public static final String[] ALLOWED_ORIGINS = {
            "http://localhost:3000",
            "https://devoms.hmc.co.kr",
            "https://oms.hmc.co.kr",
            "https://oms.kia.com"
            };


    public static final String CLAIM_USER_EENO = "userEeno";
    public static final String CLAIM_BLNS_CO_CD = "blnsCoCd";
    public static final String CLAIM_GRP_CD = "grpCd";


    public static final long PW_LOCK_MINUTE = 60; // 로그인잠금시간(비번5회오류)
    public static final long NOT_ACCESS_MINUTE = 120; // 로그인후 접근안함시간(로그아웃처리)
    public static final long ACCESS_TOKEN_VALID_TIME = 12 * 60 * 60 * 1000L; // 12시간
    public static final long REFRESH_TOKEN_VALID_TIME = 14 * 24 * 60 * 60 * 1000L; // 14일

    public static final String CODE_SYSADM = "100";

}
