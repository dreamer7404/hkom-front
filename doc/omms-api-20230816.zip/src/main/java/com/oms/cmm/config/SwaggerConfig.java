package com.oms.cmm.config;

import org.springdoc.core.GroupedOpenApi;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import io.swagger.v3.oas.annotations.OpenAPIDefinition;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import io.swagger.v3.oas.annotations.info.Info;
import io.swagger.v3.oas.models.Components;
import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.media.StringSchema;
import io.swagger.v3.oas.models.parameters.Parameter;
import io.swagger.v3.oas.models.security.SecurityRequirement;
import io.swagger.v3.oas.models.security.SecurityScheme;
import lombok.RequiredArgsConstructor;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @author 안경수
 * @since 2023. 2. 9.
 * @see
 */
@OpenAPIDefinition(
        info = @Info(
                title = "OMS API 명세서",
                description = "OMS API 명세서 설명",
                version = "v1"
        )
)
@RequiredArgsConstructor
@Configuration
public class SwaggerConfig  {
    
    @Bean
    public GroupedOpenApi groupedOpenApi() {
        String[] paths = {"/**"};
 
        return GroupedOpenApi.builder()
                .group("api")
                .pathsToMatch("/**")
                .build();
    }
    
    @Bean
    public OpenAPI openAPI() {

//        Info info = new Info()
//                .version("v1.0.0")
//                .title("API 타이틀")
//                .description("API Description");

        // SecuritySecheme명
        String jwtSchemeName = "jwtAuth";
//        String methodSchemeName = "_method";
        
        // API 요청헤더에  포함
        SecurityRequirement securityRequirement = new SecurityRequirement().addList(jwtSchemeName)
//                .addList(methodSchemeName)
                ;
        
        // SecuritySchemes 등록
        Components components = new Components()
                .addSecuritySchemes(jwtSchemeName, new SecurityScheme()
                                .name(jwtSchemeName)
                                .type(SecurityScheme.Type.HTTP) // HTTP 방식
                                .scheme("bearer")
                                .bearerFormat("JWT")) // 토큰 형식을 지정하는 임의의 문자(Optional)
//                .addSecuritySchemes(methodSchemeName, new SecurityScheme()
//                                .name(methodSchemeName)
//                                .type(SecurityScheme.Type.HTTP) // HTTP 방식
//                                .scheme("_method")
////                                .bearerFormat("JWT")
//                                .in(SecurityScheme.In.HEADER)
//                                )
//                .addHeaders(methodSchemeName, new Header().description("_method").schema(new StringSchema()))
//                .addParameters(methodSchemeName, new Parameter().in(ParameterIn.HEADER.toString())
//                    .schema(new StringSchema())
//                    .name("_method")
//                    .description("_method")
//                    .required(false))
                ;

        return new OpenAPI()
//                .info(info)
                .addSecurityItem(securityRequirement)
                .components(components)
                ;
    }
    

}
