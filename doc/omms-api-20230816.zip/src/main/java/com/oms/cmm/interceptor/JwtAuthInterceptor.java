package com.oms.cmm.interceptor;

import java.io.Writer;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.util.WebUtils;

import com.oms.cmm.global.Consts;
import com.oms.cmm.security.JwtTokenProvider;
import com.oms.cmm.utils.Utils;
import com.oms.sys.dto.ApiMgmtReqDTO;
import com.oms.sys.dto.LogLgiReqDTO;
import com.oms.sys.dto.UsrTokenReqDTO;
import com.oms.sys.dto.UsrTokenResDTO;
import com.oms.sys.service.ApiMgmtService;
import com.oms.sys.service.LogLgiService;
import com.oms.sys.service.UsrTokenService;

import lombok.extern.slf4j.Slf4j;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @author 안경수
 * @since 2023. 2. 14.
 * @see
 */
@Slf4j
public class JwtAuthInterceptor implements HandlerInterceptor {

    @Autowired
    private UsrTokenService usrTokenService;

    @Autowired
    private ApiMgmtService apiMgmtService;

    @Autowired
    private LogLgiService logLgiService;


    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)
            throws Exception {

        if(request.getMethod().equals("OPTIONS")){
            return true;
        }

        String url = request.getRequestURI(); // SWAGGER
        if(url.startsWith("http://localhost")) {
            if (url.contains("swagger-ui") || url.contains("api-docs") || url.contains("webjars")) {
                return true;
            }
        }

        if (url.contains("uploadImages")){ // DEXT5Editor
            return true;
        }
        if (url.contains("downloadFiles")){ // DEXT5Upload
            return true;
        }
        if (url.contains("vehlGis")){ // 선적현황 - 현대 새창띄울때
            return true;
        }
        if(url.contains("shipExcelDown")) { // 선적엑셀다운 - 테스트
            return true;
        }

        String token = request.getHeader(Consts.X_AUTH_TOKEN);

        try {

            // token있음
            if (token != null && !token.isEmpty()) {

                // 토큰의 유효성 + 만료일자 확인
                JwtTokenProvider jwtTokenProvider = new JwtTokenProvider();
                boolean validToken = jwtTokenProvider.checkJwt(token);

                if(validToken) { // OK valid
                    // 브라우처 체크
                    String browserId = request.getHeader(Consts.X_AUTH_BROWSER);
                    String userEeno = jwtTokenProvider.getMapInfo(token, Consts.CLAIM_USER_EENO);

                    UsrTokenReqDTO usrTokenReqDTO = new UsrTokenReqDTO();
                    usrTokenReqDTO.setUserEeno(userEeno);
                    UsrTokenResDTO usrTokenResDTO = usrTokenService.selectUsrToken(usrTokenReqDTO);

                    // DB browserId와 다르면 로그인으로(중복로그인)=> 부하테스트관계로 임시로 풀어놓음
    //                if(!usrTokenResDTO.getBrowserId().equals(browserId)) {
    //
    //                    // remote ip
    //                    String msg = usrTokenResDTO.getIp();
    //
    //                    // Cookie 삭제
    //                    Cookie cookie = new Cookie("rt", null);
    //                    cookie.setMaxAge(0);
    //                    cookie.setHttpOnly(true);
    //                    cookie.setPath("/");
    //                    response.addCookie(cookie);
    //
    //                    response.setContentType("application/json");
    //                    response.setCharacterEncoding("UTF-8");
    //                    response.getWriter().write("{\"result\":\"2\", \"msg\":\"" + msg + "\"}"); // 브라우저 다름
    //                    response.setStatus(401);
    //                    return false;
    //                }




                    // update accessTime
    //                usrTokenService.updateUsrTokenAccessTime(usrTokenResDTO.getUserEeno());

                    // => 브라우저아이디(로그인시 발행-변동없음)


                    // 프로그램권한체크
                    String requestPath = request.getServletPath();
                    if(requestPath.startsWith("/api/")) {
                        String method = Utils.getMethod(request).isEmpty() ? RequestMethod.GET.name() : RequestMethod.POST.name();
                        String apiUrl = requestPath.substring(4);

                        ApiMgmtReqDTO apiMgmtReqDTO = new ApiMgmtReqDTO(apiUrl, method,  userEeno);
                        String menuId = apiMgmtService.selectApiUrlMenuId(apiMgmtReqDTO);
                        if(!menuId.equals("9999")) { // 공통 apiUrl은 패스
                            int cnt = apiMgmtService.selectApiUrlCheck(apiMgmtReqDTO);
                            if(cnt == 0) {
                                // 로그아웃 로그저장
                                logLgiService.updateLogLgiHistory(new LogLgiReqDTO(browserId, "A")); // A: 권한오류

                                response.setContentType("application/json");
                                response.setCharacterEncoding("UTF-8");
                                response.getWriter().write("{\"result\":\"6\", \"msg\":\"" + apiUrl + "\"}"); // 권한없음
                                response.setStatus(401);
                                return false;
                            }
                        }
                    }


                    // OK
                    return true;

                }else { // NOT valid
                    // 재발급 => rt 가져오기
                    Cookie refreshToken = WebUtils.getCookie(request, "rt");
                    if(refreshToken != null) {
                        boolean validRefreshToken = jwtTokenProvider.checkJwt(refreshToken.getValue());
                        if(!validRefreshToken) {
                            // refreshToken 만료 => 재발급?
                            int ttt = 1;





                        }

                        UsrTokenReqDTO usrTokenReqDTO = new UsrTokenReqDTO();
                        usrTokenReqDTO.setRefreshToken(refreshToken.getValue());
                        UsrTokenResDTO usrTokenResDTO = usrTokenService.selectUsrToken(usrTokenReqDTO);

                        // refresh token없으면 token만료되었고, 다른곳에서 로그인
                        if(usrTokenResDTO == null) {

                            // 로그아웃 로그저장
                            String browserId = request.getHeader(Consts.X_AUTH_BROWSER);
                            logLgiService.updateLogLgiHistory(new LogLgiReqDTO(browserId, "R")); //RT없음

                            // Cookie 삭제
                            Cookie cookie = new Cookie("rt", null);
                            cookie.setMaxAge(0);
                            cookie.setHttpOnly(true);
                            cookie.setPath("/");
                            response.addCookie(cookie);

                            response.setContentType("application/json");
                            response.setCharacterEncoding("UTF-8");
                            response.getWriter().write("{\"result\":\"5\"}");
                            response.setStatus(401);
                            return false;
                        }

                        // 일정시간 사용안하면 로그아웃(2시간)
                        if(usrTokenResDTO.getAccessTimeDiff() > Consts.NOT_ACCESS_MINUTE) {

                            // 로그아웃 로그저장
                            String browserId = request.getHeader(Consts.X_AUTH_BROWSER);
                            logLgiService.updateLogLgiHistory(new LogLgiReqDTO(browserId, "S")); // 타임아웃

                            // Cookie 삭제
                            Cookie cookie = new Cookie("rt", null);
                            cookie.setMaxAge(0);
                            cookie.setHttpOnly(true);
                            cookie.setPath("/");
                            response.addCookie(cookie);

                            response.setContentType("application/json");
                            response.setCharacterEncoding("UTF-8");
                            response.getWriter().write("{\"result\":\"3\"}");
                            response.setStatus(401);
                            return false;
                        }

                        // 토큰 재발급
                        String newToken = jwtTokenProvider.createToken(
                                usrTokenResDTO.getUserEeno(),
                                usrTokenResDTO.getBlnsCoCd(),
                                usrTokenResDTO.getGrpCd(),
                                Consts.ACCESS_TOKEN_VALID_TIME);

                        // 토큰전송
                        response.setContentType("application/json");
                        response.setCharacterEncoding("UTF-8");
                        response.getWriter().write("{\"result\":\"1\", \"token\":\"" + newToken + "\"}");
                        response.setStatus(401);
                        return false;
                    }
                    // token은 invalid, rt는없음
                    response.setContentType("application/json");
                    response.setCharacterEncoding("UTF-8");
                    response.getWriter().write("{\"result\":\"4\"}");
                    response.setStatus(401);
                    return false;
                }
            }
            // access token 없음
            else {

            // token을 메모리에 위치할때 => token없으나, browserId & rt있음 => reload() 이므로 재발급
    //        else {
    //            JwtTokenProvider jwtTokenProvider = new JwtTokenProvider();
    //
    //            // 브라우처 체크
    //            String browserId = request.getHeader(Consts.X_AUTH_BROWSER);
    //            String userEeno = jwtTokenProvider.getMapInfo(token, Consts.CLAIM_USER_EENO);
    //            UsrTokenResDTO usrTokenResDTO = usrTokenService.selectUsrToken(userEeno);
    //
    //            // rt체크
    //            Cookie rt = WebUtils.getCookie(request, "rt");
    //            if(rt != null) {
    //                boolean validRefreshToken = jwtTokenProvider.checkJwt(rt.getValue());
    //                // 재발급
    //            }
    //        }

                // 로그아웃 로그저장
                String browserId = request.getHeader(Consts.X_AUTH_BROWSER);
                logLgiService.updateLogLgiHistory(new LogLgiReqDTO(browserId, "T")); // 세션아웃

                // access token없음
                response.setContentType("application/json");
                response.setCharacterEncoding("UTF-8");
                response.getWriter().write("{\"result\":\"5\"}"); // 토큰정보가 없거나 만료되었습니다.
                response.setStatus(401);
                return false;
            }
        }catch(Exception e) {
            e.printStackTrace();
            throw e;
        }
    }




}
