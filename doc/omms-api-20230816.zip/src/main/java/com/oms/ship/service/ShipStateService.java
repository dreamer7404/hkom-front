package com.oms.ship.service;

import java.util.List;

import com.oms.ship.dto.ShipStateReqDTO;
import com.oms.ship.dto.ShipStateResDTO;

/**
 * <pre>
 * Statements
 * </pre>
 * @ClassName : ShipStateService.java
 * @Description :
 * @author 김경훈
 * @since 2023. 7. 7.
 * @see
 */

public interface ShipStateService {

    /**
     * Statements
     *
     * @param dto
     * @return
     */
    List<ShipStateResDTO> selectShipStateList(ShipStateReqDTO dto);

    /**
     * Statements
     *
     * @param dto
     * @return
     */
    Integer selectShipStateTotList(ShipStateReqDTO dto);

}
