package com.oms.ship.dto;

import java.util.List;

import org.apache.ibatis.type.Alias;

import com.oms.common.dto.CommReqDTO;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;



/**
 * <pre>
 * Statements
 * </pre>
 * @ClassName : ShipStateReqDTO.java
 * @Description :
 * @author 김경훈
 * @since 2023. 7. 14.
 * @see
 */
@Alias("shipStateReqDTO")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class ShipStateReqDTO extends CommReqDTO {

 private String vin;
 private String sDate;
 private String eDate;
}


