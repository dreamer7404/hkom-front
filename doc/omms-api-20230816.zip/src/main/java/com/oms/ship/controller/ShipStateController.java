package com.oms.ship.controller;


import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.Writer;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.http.HttpHeaders;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import javax.servlet.ServletOutputStream;
//import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
//import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpServletResponse;

import able.cloud.core.web.HController;

import org.apache.commons.io.IOUtils;
import org.apache.http.HttpStatus;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.usermodel.BorderStyle;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.FillPatternType;
import org.apache.poi.ss.usermodel.HorizontalAlignment;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFColor;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
//import org.apache.poi.ss.usermodel.BorderStyle;
//import org.apache.poi.ss.usermodel.Cell;
//import org.apache.poi.ss.usermodel.FillPatternType;
//import org.apache.poi.ss.usermodel.Row;
//import org.apache.poi.ss.usermodel.Sheet;
//import org.apache.poi.ss.usermodel.Workbook;
//import org.apache.poi.xssf.streaming.SXSSFWorkbook;
//import org.apache.poi.xssf.usermodel.XSSFCellStyle;
//import org.apache.poi.xssf.usermodel.XSSFColor;
//import org.apache.poi.xssf.usermodel.XSSFFont;
//import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
//import org.springframework.web.bind.annotation.PostMapping;
//import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import com.oms.cmm.utils.AES256Util;
import com.oms.ship.dto.ExcelTest;
//import com.oms.ship.dto.ExcelTest;
import com.oms.ship.dto.ShipStateReqDTO;
import com.oms.ship.dto.ShipStateResDTO;
import com.oms.ship.service.ShipStateService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;



/**
 * <pre>
 * Statements
 * </pre>
 * @ClassName : ShipStateController.java
 * @Description :
 * @author 김경훈
 * @since 2023. 7. 7.
 * @see
 */
@CrossOrigin(originPatterns = "http://localhost:3000")
@Tag(name = "ShipStateController", description = "")
@RequiredArgsConstructor
@RestController
@RequestMapping("/api")
public class ShipStateController extends HController {

    @Value("${ship.oms-url}")
    private String omsUrl;

    @Value("${ship.iels-url}")
    private String ielsUrl;

    /**
     * 클래스 Injection
     */
    private final ShipStateService shipStateService;
    private final HttpServletRequest request;
    private final AES256Util aes256Util;

    @Operation(summary = "선적현황조회")
    @GetMapping("/shipInfos")
    public  List<ShipStateResDTO>  shipStates(@ModelAttribute ShipStateReqDTO dto) throws Exception {
        List<ShipStateResDTO> list = shipStateService.selectShipStateList(dto);
        return list;
    }
    @Operation(summary = "선적현황조회")
    @GetMapping("/shipInfoTots")
    public  Integer shipStateTots(@ModelAttribute ShipStateReqDTO dto) throws Exception {
        return shipStateService.selectShipStateTotList(dto);
    }

    /***
     *
     * 기아 선적 엑셀 다운로드
     *
     * @param sDate, eDate
     * @throws Exception
     */
    @GetMapping("/shipExcelDown")
    public void excelDownload(HttpServletResponse response, ShipStateReqDTO dto ) throws Exception {

        // 데이타 리스트
        dto.setOffset(0);
        dto.setPageSize(2000); // 최대싸이즈 지정
        List<ShipStateResDTO> excelList = shipStateService.selectShipStateList(dto);

//        // 엑셀만들기
//        ByteArrayInputStream stream = createListToExcel(excelList);
//
//        // 전송
//        response.setContentType("application/octet-stream");
//        OutputStream  out = response.getOutputStream();
//        out.flush();
//        IOUtils.copy(stream, out);
//
//
//    }
//
//
//
//    private ByteArrayInputStream createListToExcel( List<ShipStateResDTO> excelList) {

        Workbook workbook = new HSSFWorkbook();
          try {
              Sheet sheet = workbook.createSheet("선적현황");
              Row row;
              Cell cell;
              int rowNo = 0;

              // 엑셀 파일 헤더
              List<String> header = Arrays.asList(
                      "V.I.N",
                      "Description",
                      "Model Year",
                      "Port",
                      "Current Status",
                      "Shipping Distributor",
                      "Sales Distributor",
                      "Sign Off",
                      "Motor Pool",
                      "Ship Out",
                      "Port Arrival(ETA)",
                      "Compound In",
                      "Wholesale",
                      "Retail");

              int headerSize = header.size();

              // 테이블 헤더 스타일 설정
              CellStyle headStyle = workbook.createCellStyle();
              // 경계선 설정
              headStyle.setBorderTop(BorderStyle.THIN);
              headStyle.setBorderBottom(BorderStyle.THIN);
              headStyle.setBorderLeft(BorderStyle.THIN);
              headStyle.setBorderRight(BorderStyle.THIN);
              // 색상
              headStyle.setFillForegroundColor(HSSFColor.HSSFColorPredefined.YELLOW.getIndex());
              headStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);
              // 헤더 가운데 정렬
              headStyle.setAlignment(HorizontalAlignment.CENTER);

              // 헤더 생성
              row = sheet.createRow(rowNo++);
              for (int i=0; i<headerSize; i++) {
                  cell = row.createCell(i);
                  cell.setCellStyle(headStyle);
                  cell.setCellValue(header.get(i));
              }

              // 내용 생성
              for (int j=0; j<excelList.size(); j++) {
                  Row dataRow = sheet.createRow(j + 1);

                  int idx = 0;
                  dataRow.createCell(idx++).setCellValue(excelList.get(j).getVin());
                  dataRow.createCell(idx++).setCellValue(excelList.get(j).getDescription());
                  dataRow.createCell(idx++).setCellValue(excelList.get(j).getOpt());
                  dataRow.createCell(idx++).setCellValue(excelList.get(j).getPortNm());
                  dataRow.createCell(idx++).setCellValue(excelList.get(j).getStatNm());
                  dataRow.createCell(idx++).setCellValue(excelList.get(j).getShipDistNm());
                  dataRow.createCell(idx++).setCellValue(excelList.get(j).getSaleDistNm());
                  dataRow.createCell(idx++).setCellValue(excelList.get(j).getProdYmd());
                  dataRow.createCell(idx++).setCellValue(excelList.get(j).getMpoolYmd());
                  dataRow.createCell(idx++).setCellValue(excelList.get(j).getShipYmd());
                  dataRow.createCell(idx++).setCellValue(excelList.get(j).getPortArrvYmd());
                  dataRow.createCell(idx++).setCellValue(excelList.get(j).getCompInYmd());
                  dataRow.createCell(idx++).setCellValue(excelList.get(j).getWholSaleYmd());
                  dataRow.createCell(idx++).setCellValue(excelList.get(j).getRtYmd());


//                  dataRow.createCell(2).setCellValue(excelList.get(j).getSaleDistCd());
//                  dataRow.createCell(4).setCellValue(excelList.get(j).getPortCd());
//                  dataRow.createCell(6).setCellValue(excelList.get(j).getMdlCd());
//                  dataRow.createCell(7).setCellValue(excelList.get(j).getMdyCd());
//                  dataRow.createCell(8).setCellValue(excelList.get(j).getStatCd());
//                  dataRow.createCell(12).setCellValue(excelList.get(j).getEtaYmd());
//                  dataRow.createCell(17).setCellValue(excelList.get(j).getCrDt());
//                  dataRow.createCell(18).setCellValue(excelList.get(j).getExclCd());
//                  dataRow.createCell(19).setCellValue(excelList.get(j).getExclNm());
//                  dataRow.createCell(20).setCellValue(excelList.get(j).getCdgb());


              }

              // Making size of column auto resize to fit with data
              for (int i=0; i<14; i++) {
                  sheet.autoSizeColumn(i);
              }

//              ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
//              workbook.write(outputStream);
//              return new ByteArrayInputStream(outputStream.toByteArray());

//              response.setContentType("ms-vnd/excel");
//              response.setHeader("Content-Disposition", "attachment;filename=student.xlsx");
              workbook.write(response.getOutputStream());



          } catch (IOException e) {
              e.printStackTrace();
//              return null;
          } finally{
              workbook.close();
          }
    }



    /**
     * 현대 선적현황
     */
    @ResponseBody
    @RequestMapping(value = "/vehlGis", method = { RequestMethod.GET })
    public void locationPageTest(HttpServletRequest request, final String vin) throws Exception {

        // 수출물류(IELS) 개발계
//        String iels_URL = "https://10.7.138.57";
        // 수출물류(IELS) 운영계
        String iels_URL = "https://" + ielsUrl;

        URL obj = new URL(iels_URL + "/api/vehl_gis.do?vin=" + vin);
        HttpURLConnection urlConnection = (HttpURLConnection) obj.openConnection();
        urlConnection.setRequestMethod("GET");
        urlConnection.setDoInput(true);
        urlConnection.setDoOutput(true);
        urlConnection.setRequestProperty("Content-Type", "text/html");

        // 호출시스템의 URL
        urlConnection.setRequestProperty("Referer", omsUrl);

        String reqIp = request.getRemoteAddr();
        SimpleDateFormat dayTime = new SimpleDateFormat("yyyyMMddHHmmss", Locale.KOREA);
        String tStamp = dayTime.format(new Date(System.currentTimeMillis()));

        // Authentication
        String Authentication = aes256Util.encryptAES("66b7b86e0195ecb2", "1.0&hkoms&vehl_gis&view&" + reqIp + "&" + tStamp, false);
        urlConnection.setRequestProperty("Authentication", Authentication);

        // check Authentication
//        Map<String, List<String>> reqList = urlConnection.getRequestProperties();
//        String value = aes256Util.decryptAES("66b7b86e0195ecb2", Authentication)

        try {
            int ielsResponseCode = urlConnection.getResponseCode();

            if (ielsResponseCode == HttpURLConnection.HTTP_OK) {
                BufferedReader in = new BufferedReader(new InputStreamReader(urlConnection.getInputStream()));
                String inputLine;
                StringBuffer ielsResponse = new StringBuffer();

                while ((inputLine = in.readLine()) != null) {
                    ielsResponse.append(inputLine).append("\n");
                }
                in.close();

                renderOutput(MediaType.TEXT_HTML, ielsResponse.toString());

            } else {
                System.out.println("GET request not worked");
            }
        }catch(Exception e) {
           logger.info(e.getMessage());
        }

    }

    private void renderOutput(final MediaType mediaType, final String output) throws Exception {
        try {
            final HttpServletResponse response = ((ServletRequestAttributes) RequestContextHolder.currentRequestAttributes()).getResponse();
            response.reset();
            response.setContentType(mediaType.toString());
            response.setCharacterEncoding("UTF-8");
            response.addHeader("Cache-Control", "no-cache, no-store, max-age=0, must-revalidate");
            response.addHeader("Expires", "0");
            response.addHeader("Pragma", "no-cache");
            response.addHeader("X-Content-Type-Options", "nosniff");
            response.addHeader("X-Frame-Options", "SAMEORIGIN");
            response.addHeader("X-XSS-Protection", "1; mode=block");
            response.addHeader("Strict-Transport-Security", "max-age=31536000; includeSubDomains");

            final Writer out = response.getWriter();
            out.write(output);
            out.close();
            response.flushBuffer();
        } catch (final IOException e) {
            logger.error("IOException : ", e);
        } catch (final Exception e) {
            logger.error("Exception : ", e);
        }
    }





}