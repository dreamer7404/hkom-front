package com.oms.ship.dto;

import org.apache.ibatis.type.Alias;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @author Windows i¿½i¿½i¿½i¿½i¿½
 * @since 2023. 7. 25.
 * @see
 */

@Data
@AllArgsConstructor
public class ExcelTest {
   // "이름", "생년월일", "연락처", "주소"
    private String name;
    private String birth;
    private String phone;
    private String addr;
}
