package com.oms.print.dto;

import java.util.List;
import java.util.Set;

import org.apache.ibatis.type.Alias;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;



/**
 * <pre>
 * Statements
 * </pre>
 * @ClassName : PrintStateReqDTO.java
 * @Description :
 * @author 김경훈
 * @since 2023. 5. 3.
 * @see
 */
@Alias("printStateReqDTO")
@Data
@AllArgsConstructor
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown =true)
public class PrintStateReqDTO extends PrintStateComDTO {

    private String sDate;
    private String eDate;

    private String dlvgParrYmd;
    private String newPrntPbcnNo;
    private int prntParrBgt;
    private int saleUnp;
    private String rqQty;
    private String attcYn; //견적서 첨부파일 여부
    private String prtlImtrSbc; //특이사항
    private String prtlImtrSbc2; //발간현황특별사항
    private String prtlImtrSbc3; //인쇄비 품의번호
    private String prntParrYmd;
    private Set<String> langCds;    //언어코드 다중 선택

  //-------- 첨부파일 정보 ---------------------
    private List<String> attcSn; // 새로추가한 첨부파일 저장 tb_attc_mgmt PK
    private List<String> size;
    private List<String> extension;
    private List<String> originalName;

    //private List<String> attcSnOld; // 기존 첨부파일 tb_attc_mgmt PK (업데이트시)
    private List<String> attcSnDeleted;

}


