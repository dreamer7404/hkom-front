package com.oms.print.dto;


import org.apache.ibatis.type.Alias;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;



/**
 * <pre>
 * Statements
 * </pre>
 * @ClassName : MonthPutInfosResDTO.java
 * @Description :
 * @author 김정웅
 * @since 2023. 6. 16.
 * @see
 */
@Alias("monthPutInfosResDTO")
@Data
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown =true)
public class MonthPutInfosResDTO {

    private String qltyVehlCd;      //차종코드
    private String qltyVehlNm;      //차종코드명
    private String mdlMdyCd;        //차량연식
    private String langCd;          //언어코드 ex) EU(영어/미국) 등..
    private String langCdNm;        //언어코드명
    private String gubun;           //항목명 (제작수량, 제작예산, 투입수량)
    private int flag;            //화면 rowSpan용 플래그

    private String col0;
    private String col1;
    private String col2;
    private String col3;
    private String col4;
    private String col5;
    private String col6;
    private String col7;
    private String col8;
    private String col9;
    private String col10;
    private String col11;
    private String col12;
    private String col13;

    private String pcol0;
    private String pcol1;
    private String pcol2;
    private String pcol3;
    private String pcol4;
    private String pcol5;
    private String pcol6;
    private String pcol7;
    private String pcol8;
    private String pcol9;
    private String pcol10;
    private String pcol11;
    private String pcol12;
    private String pcol13;

    private String qcol0;
    private String qcol1;
    private String qcol2;
    private String qcol3;
    private String qcol4;
    private String qcol5;
    private String qcol6;
    private String qcol7;
    private String qcol8;
    private String qcol9;
    private String qcol10;
    private String qcol11;
    private String qcol12;
    private String qcol13;


}
