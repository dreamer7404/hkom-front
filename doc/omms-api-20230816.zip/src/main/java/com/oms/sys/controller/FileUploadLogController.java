package com.oms.sys.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.oms.cmm.global.Consts;
import com.oms.cmm.utils.Utils;
import com.oms.sys.dto.FileUploadLogReqDTO;
import com.oms.sys.dto.FileUploadLogResDTO;
import com.oms.sys.dto.LogComReqDTO;
import com.oms.sys.service.FileUploadLogService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;


/**
 * <pre>
 * Statements
 * </pre>
 * @ClassName : FileUploadLogController.java
 * @Description :
 * @author 김경훈
 * @since 2023. 6. 19.
 * @see
 */
@Tag(name = "FileUploadLogController", description = "")
@RequiredArgsConstructor
@RestController
@RequestMapping("/api")
public class FileUploadLogController {

    /**
     * 클래스 Injection
     */
    private final FileUploadLogService fileUploadService;


    /**
     * 파일업로드 목록 조회
     */
    @Operation(summary = "파일업로드 목록 조회 ")
    @GetMapping("/fileUploadHistorys")
    public List<FileUploadLogResDTO> fileUploadHistorys(@ModelAttribute LogComReqDTO dto) throws Exception {
        return fileUploadService.fileUploadHistorys(dto);
    }


    /**
     * 파일업로드 Row수
     */
    @Operation(summary = "파일업로드 Row수 ")
    @GetMapping("/fileUploadHistoryTots")
    public Integer fileUploadHistoryTots(@ModelAttribute LogComReqDTO dto) throws Exception {
        return fileUploadService.fileUploadHistoryTots(dto);
    }

    /**
     * 파일다운로드 로깅
     */
    @Operation(summary = "파일다운로드 로깅")
    @PostMapping("/fileUploadHistory")
    public void insertFileUploadHistory(@RequestBody FileUploadLogReqDTO fileUploadLogReqDTO, HttpServletRequest request) throws Exception {
        String method = Utils.getMethod(request);

        fileUploadLogReqDTO.setUserId(Utils.getUserEeno(request));
        fileUploadLogReqDTO.setUserIp(Utils.getRemoteAddress(request));
        try {
            // 등록
            if(method.equals(Consts.INSERT)) {
//                fileUploadLogReqDTO.setUseType("06");
//                fileUploadLogReqDTO.set
                fileUploadService.insertFileUploadHistory(fileUploadLogReqDTO);
            }
        }catch(Exception e) {

        }
    }



}
