package com.oms.sys.service.impl;

import java.util.List;

import org.springframework.stereotype.Service;

import com.oms.sys.dao.BatchDAO;
import com.oms.sys.dao.LogDAO;
import com.oms.sys.dto.BatchLogResDTO;
import com.oms.sys.dto.BatchReqDTO;
import com.oms.sys.dto.BatchResDTO;
import com.oms.sys.dto.LogUseReqDTO;
import com.oms.sys.dto.LogUseResDTO;
import com.oms.sys.dto.SchedLogDTO;
import com.oms.sys.model.LogUse;
import com.oms.sys.service.BatchService;
import com.oms.sys.service.LogService;

import lombok.RequiredArgsConstructor;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @author 안경수
 * @since 2023. 5. 19.
 * @see
 */

@RequiredArgsConstructor
@Service("batchService")
public class BatchServiceImpl implements BatchService {

    private final BatchDAO batchDao;

    @Override
    public List<BatchResDTO> selectBatchInfos() {
        // TODO Auto-generated method stub
        return batchDao.selectBatchInfos() ;
    }

    /*
     * @see com.oms.sys.service.BatchService#selectBatchLogs(com.oms.sys.dto.BatchReqDTO)
     */
    @Override
    public List<BatchLogResDTO> selectBatchLogs(BatchReqDTO dto) {
        return batchDao.selectBatchLogs(dto) ;
    }

    /*
     * @see com.oms.sys.service.BatchService#selectBatchLogsTot(com.oms.sys.dto.BatchReqDTO)
     */
    @Override
    public Integer selectBatchLogsTot(BatchReqDTO dto) {
        // TODO Auto-generated method stub
        return batchDao.selectBatchLogsTot(dto) ;
    }


    /*
     * @see com.oms.sys.service.BatchService#runApsProcedureHmc(com.oms.sys.dto.BatchReqDTO)
     */
    @Override
    public void runApsProcedureHmc(BatchReqDTO dto) {
        // TODO Auto-generated method stub
         batchDao.runApsProcedureHmc(dto) ;
    }

    /*
     * @see com.oms.sys.service.BatchService#runApsProcedureKmc(com.oms.sys.dto.BatchReqDTO)
     */
    @Override
    public void runApsProcedureKmc(BatchReqDTO dto) {
        // TODO Auto-generated method stub
         batchDao.runApsProcedureKmc(dto) ;
    }

    /*
     * @see com.oms.sys.service.BatchService#runErpProcedureHmc(com.oms.sys.dto.BatchReqDTO)
     */
    @Override
    public void runErpProcedureHmc(BatchReqDTO dto) {
        // TODO Auto-generated method stub
         batchDao.runErpProcedureHmc(dto) ;
    }

    /*
     * @see com.oms.sys.service.BatchService#runErpProcedureKmc(com.oms.sys.dto.BatchReqDTO)
     */
    @Override
    public void runErpProcedureKmc(BatchReqDTO dto) {
        // TODO Auto-generated method stub
         batchDao.runErpProcedureKmc(dto) ;
    }
}
