package com.oms.sys.service;

import java.util.List;
import com.oms.sys.dto.LogComReqDTO;
import com.oms.sys.dto.SchedulerLogResDTO;


/**
 * <pre>
 * Statements
 * </pre>
 * @ClassName : SchedulerLogService.java
 * @Description :
 * @author 김경훈
 * @since 2023. 6. 19.
 * @see
 */
public interface SchedulerLogService {

    List<SchedulerLogResDTO> schedulerHistorys(LogComReqDTO dto);
    Integer schedulerHistoryTots(LogComReqDTO dto);


}
