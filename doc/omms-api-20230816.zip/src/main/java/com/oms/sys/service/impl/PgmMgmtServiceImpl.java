package com.oms.sys.service.impl;

import java.util.List;

import able.cloud.core.service.HService;

import org.springframework.stereotype.Service;

import com.oms.common.dto.CommReqDTO;
import com.oms.sys.dao.PgmMgmtDAO;
import com.oms.sys.dto.AuthAffrMgmtReqDTO;
import com.oms.sys.dto.AuthAffrMgmtResDTO;
import com.oms.sys.dto.PgmMgmtReqDTO;
import com.oms.sys.dto.PgmMgmtResDTO;
import com.oms.sys.dto.UseYnReqDTO;
import com.oms.sys.model.AuthAffrMgmt;
import com.oms.sys.service.PgmMgmtService;

import lombok.RequiredArgsConstructor;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @author 안경수
 * @since 2023. 2. 24.
 * @see
 */

@RequiredArgsConstructor
@Service("pgmMgmtService")
public class PgmMgmtServiceImpl extends HService implements PgmMgmtService {

    private final PgmMgmtDAO pgmMgmtDAO;

    @Override
    public List<PgmMgmtResDTO> selectPgmMgmtList(CommReqDTO commReqDTO) throws Exception {
        return pgmMgmtDAO.selectPgmMgmtList(commReqDTO);
    }



    @Override
    public int insertPgmMgmt(PgmMgmtReqDTO dto) {
        return pgmMgmtDAO.insertPgmMgmt(dto);
    }

    @Override
    public int updatePgmMgmt(PgmMgmtReqDTO dto) {
        return pgmMgmtDAO.updatePgmMgmt(dto);
    }

    @Override
    public int deletePgmMgmt(PgmMgmtReqDTO dto) {
        return pgmMgmtDAO.deletePgmMgmt(dto);
    }

    @Override
    public List<PgmMgmtResDTO> selectGrpUsrList() {
        return pgmMgmtDAO.selectGrpUsrList();
    }

    @Override
    public int deletePgmGrpAuth(PgmMgmtReqDTO dto) {
        return pgmMgmtDAO.deletePgmGrpAuth();
    }

    @Override
    public int insertPgmGrpAuth(PgmMgmtReqDTO dto) {
        return pgmMgmtDAO.insertPgmGrpAuth();
    }

    @Override
    public List<PgmMgmtResDTO> selectPgmMgmtListAll(PgmMgmtReqDTO dto) throws Exception {
        // TODO Auto-generated method stub
        return pgmMgmtDAO.selectPgmMgmtListAll(dto);
    }

    @Override
    public int updatePgmMgmtUseYn(UseYnReqDTO useYnReqDTO){
        return pgmMgmtDAO.updatePgmMgmtUseYn(useYnReqDTO);
    }

    @Override
    public List<AuthAffrMgmtResDTO> selectAuthAffrMgmtList(AuthAffrMgmtReqDTO authAffrMgmtReqDTO) {
        return pgmMgmtDAO.selectAuthAffrMgmtList(authAffrMgmtReqDTO);
    }
    @Override
    public List<AuthAffrMgmtResDTO> selectAuthAffrMgmtListByGrp(AuthAffrMgmtReqDTO authAffrMgmtReqDTO) {
        return pgmMgmtDAO.selectAuthAffrMgmtListByGrp(authAffrMgmtReqDTO);
    }

    @Override
    public List<AuthAffrMgmtResDTO> selectAuthAffrMgmt(AuthAffrMgmtReqDTO authAffrMgmtReqDTO) {
        return pgmMgmtDAO.selectAuthAffrMgmt(authAffrMgmtReqDTO);
    }

    @Override
    public int deleteAuthAffrMgmt(AuthAffrMgmt authAffrMgmt) {
        return pgmMgmtDAO.deleteAuthAffrMgmt(authAffrMgmt);
    }

    @Override
    public int insertAuthAffrMgmt(List<AuthAffrMgmt> list) {
        return pgmMgmtDAO.insertAuthAffrMgmt(list);
    }

    @Override
    public List<PgmMgmtResDTO> selectPgmMgmtGrpList() {
        return pgmMgmtDAO.selectPgmMgmtGrpList();
    }



    /*
     * @see com.oms.sys.service.PgmMgmtService#insertPgmtMgmtGrp(com.oms.sys.dto.PgmMgmtReqDTO)
     */
    @Override
    public int insertPgmtMgmtGrp(PgmMgmtReqDTO dto) {
        // TODO Auto-generated method stub
        return pgmMgmtDAO.insertPgmtMgmtGrp(dto);
    }



    /*
     * @see com.oms.sys.service.PgmMgmtService#updatePgmtMgmtGrp(com.oms.sys.dto.PgmMgmtReqDTO)
     */
    @Override
    public int updatePgmtMgmtGrp(PgmMgmtReqDTO dto) {
        // TODO Auto-generated method stub
        return pgmMgmtDAO.updatePgmtMgmtGrp(dto);
    }



    /*
     * @see com.oms.sys.service.PgmMgmtService#selectAuthAffrMgmtMainList(com.oms.sys.dto.AuthAffrMgmtReqDTO)
     */
    @Override
    public List<AuthAffrMgmtResDTO> selectAuthAffrMgmtMainList(AuthAffrMgmtReqDTO authAffrMgmtReqDTO) {
        // TODO Auto-generated method stub
        return  pgmMgmtDAO.selectAuthAffrMgmtMainList(authAffrMgmtReqDTO);
    }



    /*
     * @see com.oms.sys.service.PgmMgmtService#selectPgmMgmtListAll(com.oms.sys.dto.PgmMgmtReqDTO)
     */





}
