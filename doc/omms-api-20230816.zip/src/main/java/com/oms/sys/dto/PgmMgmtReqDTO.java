package com.oms.sys.dto;

import java.sql.Timestamp;
import java.util.List;

import org.apache.ibatis.type.Alias;

import com.oms.common.dto.CommReqDTO;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;


/**
 * <pre>
 * Statements
 * </pre>
 * @ClassName : PgmMgmtReqDTO.java
 * @Description :
 * @author 김경훈 => 안경수 변경
 * @since 2023. 4. 6.
 * @see
 */
@Alias("pgmMgmtReqDTO")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class PgmMgmtReqDTO { //  extends CommReqDTO{
//    private String nactType;
//    private String nactNm;
//    private String nmenuCd;
//    private String nactId;
//    private String actSn;
//
//    List<PgmMgmtReqDTO> gridList;

    private String menuId;
    private String pgmId;
    private Integer pgmIdSn;
    private String pgmNm;
    private String pgmPathAdr;
    private String inpScnCd;
    private String useYn;
    private String grpNm;
    private String userEeno;

}
