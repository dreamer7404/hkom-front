package com.oms.sys.service;

import java.util.List;

import com.oms.sys.dto.LogComReqDTO;
import com.oms.sys.dto.LogLgiReqDTO;
import com.oms.sys.dto.LogLgiResDTO;

/**
 * <pre>
 * Statements
 * </pre>
 * @ClassName : LogLgiService.java
 * @Description :
 * @author 김경훈
 * @since 2023. 6. 16.
 * @see
 */
public interface LogLgiService {


    List<LogLgiResDTO> selectLogLgiHistorys(LogComReqDTO dto) ;

    /**
     * Statements
     *
     * @param dto
     * @return
     */
    Integer selectLogLgiHistoryTots(LogComReqDTO dto);

    int insertLogLgiHistory(LogLgiReqDTO dto);
    int updateLogLgiHistory(LogLgiReqDTO dto);



}
