package com.oms.sys.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import able.cloud.core.web.HController;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseCookie;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.oms.cmm.config.HttpMessageConverterConfig;
import com.oms.cmm.global.Consts;
import com.oms.cmm.security.JwtTokenProvider;
import com.oms.cmm.utils.AES128;
import com.oms.cmm.utils.Utils;
import com.oms.sys.dto.ApiAuthByGrpResDTO;
import com.oms.sys.dto.AuthReqDTO;
import com.oms.sys.dto.AuthResDTO;
import com.oms.sys.dto.LogLgiReqDTO;
import com.oms.sys.dto.UsrMgmtResDTO;
import com.oms.sys.dto.UsrTokenReqDTO;
import com.oms.sys.service.ApiMgmtService;
import com.oms.sys.service.LogLgiService;
import com.oms.sys.service.UsrMgmtService;
import com.oms.sys.service.UsrTokenService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @author 안경수
 * @since 2023. 1. 19.
 * @see
 */
@Slf4j
@Tag(name = "AuthController", description = "")
@RequiredArgsConstructor
@RestController
@RequestMapping("/api")
public class AuthController extends HController {

    private static Logger logger = LoggerFactory.getLogger(AuthController.class);

    private final JwtTokenProvider jwtTokenProvider;
    private final HttpServletRequest request;
    private final UsrMgmtService usrMgmtService;
    private final UsrTokenService usrTokenService;
    private final ApiMgmtService apiMgmtService;
    private final LogLgiService logLgiService;



    /*
     * 로그인
     *
     * - 6개월 비번변경 필수 - 꼭해야 넘어감. ( 변경안하고 팝업창 닫으면 로그인화면으로),
     * - 비번찾기통해서 임시비번 발급 - 임시비번들어오면 필수로 변경 -
     */
    @Operation(summary = "로그인")
    @PostMapping("/login")
    public ResponseEntity<Map> login(@RequestBody AuthReqDTO authReqDTO, HttpServletResponse response)  {

        logger.info("@@@@@-/login-111" );
        Map<String, Object> resultMap = new HashMap<>();
        String method = Utils.getMethod(request);
        String ip = Utils.getRemoteAddress(request);

        try {

            if(method.equals(Consts.UPDATE)) { //
                logger.info("@@@@@-/login-222" );
                // get from db
                UsrMgmtResDTO usrMgmtResDTO = usrMgmtService.selectUsrMgmt(authReqDTO.getUserEeno());
                if(usrMgmtResDTO == null) {
                    resultMap.put("result", -1); // 오류 - 사용자테이블에 없음
                    return ResponseEntity.ok().body(resultMap);
                }
                logger.info("@@@@@-/login-333" );

                // sysadm이 아닌데(sysadm은 회사코드와 상관없이 통과), 회사코드가 틀리면.
                if( !usrMgmtResDTO.getGrpCd().equals(Consts.CODE_SYSADM) &&
                    !usrMgmtResDTO.getBlnsCoCd().equals(authReqDTO.getBlnsCoCd())) {

                    resultMap.put("result", -7);  // 오류 - 회사코드 틀림
                    return ResponseEntity.ok().body(resultMap);
                }

                // password
                String savedPw = AES128.SHA256(authReqDTO.getUserPw());
                if(!usrMgmtResDTO.getUserPw().equals(savedPw)) { //비번틀림

                    // 비번 연속오류횟수 증가
                    int pwErrCnt = usrMgmtResDTO.getPwErrOft()+1;
                    if(usrMgmtResDTO.getPwErrOft()+1 >= 5) {
                        // 오류횟수 = 5회, 잠김일시 = now()
                        usrMgmtService.updateUserPwLock(authReqDTO.getUserEeno());
                        resultMap.put("result", -2);
                        return ResponseEntity.ok().body(resultMap);
                    }

                    // 오류횟수 증가
                    usrMgmtService.updateUserPwErrOft(new AuthReqDTO(authReqDTO.getUserEeno(), pwErrCnt));

                    resultMap.put("result", -3); // 오류 - 비번틀림
                    resultMap.put("pwErrCnt", pwErrCnt);
                    return ResponseEntity.ok().body(resultMap);
                }

                // 삭제여부
                if(usrMgmtResDTO.getDelYn() != null && usrMgmtResDTO.getDelYn().equals("Y")) {
                    // 로그인실패 로그 저장
                    logLgiService.insertLogLgiHistory(new LogLgiReqDTO(
                            authReqDTO.getUserEeno(),
                            "N", // sucsYn
                            ip,
                            "N", // idExistYn
                            "")); // => sessId

                    resultMap.put("result", -6); // 오류 - 삭제된 아이디
                    return ResponseEntity.ok().body(resultMap);
                }

                // 사용여부
                if(!usrMgmtResDTO.getUseYn().equals("Y")) {
                    // 로그인실패 로그 저장
                    logLgiService.insertLogLgiHistory(new LogLgiReqDTO(
                            authReqDTO.getUserEeno(),
                            "N", // sucsYn
                            ip,
                            "N", // idExistYn
                            "")); // => sessId

                    resultMap.put("result", -4); // 오류 - 사용안함
                    return ResponseEntity.ok().body(resultMap);
                }

                // 잠김지난시간 1시간 안지났나?
                if(usrMgmtResDTO.getDiffPwLock() > 0 && usrMgmtResDTO.getDiffPwLock() < Consts.PW_LOCK_MINUTE) {

                    // 로그인실패 로그 저장
                    logLgiService.insertLogLgiHistory(new LogLgiReqDTO(
                            authReqDTO.getUserEeno(),
                            "N", // sucsYn
                            ip,
                            "Y", // idExistYn
                            "")); // => sessId

                    resultMap.put("result", -5); // 오류 - 잠김시간 안지남
                    return ResponseEntity.ok().body(resultMap);
                }


                //--------------------------- 로그인 성공 -----------------------------------------------

                // 로그인 성공  - 오류횟수 초기화, FIN_LGI_DTM =now(),
                usrMgmtService.updateUserLoginOk(new AuthReqDTO(authReqDTO.getUserEeno()));


                // accessToken 생성
                String accessToken = jwtTokenProvider.createToken(authReqDTO.getUserEeno(),
                                                        usrMgmtResDTO.getBlnsCoCd(),
                                                        usrMgmtResDTO.getGrpCd(),
                                                        Consts.ACCESS_TOKEN_VALID_TIME);

                // refreshToken 생성
                String refreshToken = jwtTokenProvider.createToken(authReqDTO.getUserEeno(),
                                                        usrMgmtResDTO.getBlnsCoCd(),
                                                        usrMgmtResDTO.getGrpCd(),
                                                        Consts.REFRESH_TOKEN_VALID_TIME);

                String browserId = UUID.randomUUID().toString();

                int pwChangeYn = usrMgmtService.selectLastLogin(authReqDTO.getUserEeno());
                // insert on duplicate update
                int result = usrTokenService.insertUsrToken(new UsrTokenReqDTO(
                            authReqDTO.getUserEeno(),
                            ip,
                            browserId,
                            refreshToken,
                            Consts.REFRESH_TOKEN_VALID_TIME));


                if(result > 0) {
                    // 로그인성공 log저장
                    logLgiService.insertLogLgiHistory(new LogLgiReqDTO(
                            authReqDTO.getUserEeno(),
                            "Y", // sucsYn
                            ip,
                            "Y", // idExistYn
                            browserId)); // => sessId



                    // 성공
                    resultMap.put("result", 1);

                    // api리스트
                    List<ApiAuthByGrpResDTO> apiList = apiMgmtService.selectApiMgmtListByAuthGrp(usrMgmtResDTO.getGrpCd());


                    resultMap.put("data", new AuthResDTO(
                                accessToken,
                                browserId,
                                usrMgmtResDTO.getUserEeno(),
                                usrMgmtResDTO.getBlnsCoCd(),
                                usrMgmtResDTO.getUserDcd(),
                                usrMgmtResDTO.getGrpCd(),
                                usrMgmtResDTO.getUserOsetLgi(),
                                pwChangeYn>0? "Y":"N", //Y면 팝업이 나와야함
                                apiList));  // 권한그룹api 리스트

                    // 쿠키 ( refresh token)
                    ResponseCookie responseCookie = ResponseCookie.from("rt",refreshToken)
                            .httpOnly(true)
        //                     .secure(true)
                            .path("/") // 필수
        //                    .maxAge(60)
        //                    .domain("oms.hmc.co.kr")
                            .build();

                    String resCookie =responseCookie.toString();
                    HttpHeaders headers = new HttpHeaders();
                    headers.add(HttpHeaders.SET_COOKIE, resCookie);

                    return ResponseEntity.ok()
    //                        .header(HttpHeaders.SET_COOKIE, resCookie)
                            .headers(headers)
                            .body(resultMap);
                }else {
                    resultMap.put("result", -9); // 오류 - DB오류
                    return ResponseEntity.ok().body(resultMap);
                }

            }
        }catch(Exception e) {
            logger.info(e.getMessage());
        }

        return null;

    }

    @Operation(summary = "로그아웃")
    @PostMapping("/logout")
    public void logout(@RequestBody Map<String, String> reqMap, HttpServletResponse response) throws Exception {
        String method = Utils.getMethod(request);
        if(method.equals(Consts.UPDATE)) { //
            // lgoType => L:로그아웃버튼, X:창닫기, S:사용시간, P: PRG권한, R: RT없음, T: 토큰오류
            // 로그아웃 저장
            String lgoType = reqMap.get("lgoType").toString();
            String browserId = request.getHeader(Consts.X_AUTH_BROWSER);
            logLgiService.updateLogLgiHistory(new LogLgiReqDTO(browserId, lgoType));
        }
    }

    @Operation(summary = "토큰변경 - 현대/기아 변경으로, 어드민만해당")
    @PostMapping("/changeToken")
    public Map<String, Object> changeToken(@RequestBody AuthReqDTO authReqDTO) throws Exception {

        String userEeno = Utils.getUserEeno(request);
        String method = Utils.getMethod(request);

        if(method.equals(Consts.UPDATE)) {
            Map<String, Object> resultMap = new HashMap<>();

            // 회사코드 변경
            authReqDTO.setBlnsCoCd(authReqDTO.getBlnsCoCd());
            authReqDTO.setUserEeno(userEeno);
            int result = usrMgmtService.updateUserBlnsCoCd(authReqDTO);


            // token 생성
            if(result == 1) {
                String token = jwtTokenProvider.createToken(userEeno,
                            authReqDTO.getBlnsCoCd(), // 회사코드
                            Consts.CODE_SYSADM,  // 업무및부서
                            Consts.ACCESS_TOKEN_VALID_TIME);
                resultMap.put("token", token);
                resultMap.put("coCd", authReqDTO.getBlnsCoCd());
                return resultMap;
            }
        }
        return null;

    }





}
