package com.oms.sys.service.impl;

import java.util.List;

import org.springframework.stereotype.Service;

import com.oms.sys.dao.BatchDAO;
import com.oms.sys.dao.EmailDAO;
import com.oms.sys.dao.LogDAO;
import com.oms.sys.dto.BatchLogResDTO;
import com.oms.sys.dto.BatchReqDTO;
import com.oms.sys.dto.BatchResDTO;
import com.oms.sys.dto.EmailReqDTO;
import com.oms.sys.dto.EmailLogResDTO;
import com.oms.sys.dto.EmailRcvrResDTO;
import com.oms.sys.dto.LogUseReqDTO;
import com.oms.sys.dto.LogUseResDTO;
import com.oms.sys.dto.SchedLogDTO;
import com.oms.sys.model.LogUse;
import com.oms.sys.service.BatchService;
import com.oms.sys.service.EmailService;
import com.oms.sys.service.LogService;

import lombok.RequiredArgsConstructor;

/**
 * <pre>
 * Statements
 * </pre>
 * @ClassName : EmailServiceImpl.java
 * @Description :
 * @author 김경훈
 * @since 2023. 6. 15.
 * @see
 */
@RequiredArgsConstructor
@Service("emailService")
public class EmailServiceImpl implements EmailService {

    private final EmailDAO emailDao;

    @Override
    public List<EmailLogResDTO> selectEmailLogs(EmailReqDTO dto) {
        return emailDao.selectEmailLogs(dto);
    }

    @Override
    public List<EmailRcvrResDTO> selectEmlRcvrMgmts(EmailReqDTO dto) {

        return emailDao.selectEmlRcvrMgmts(dto);
    }

    /*
     * @see com.oms.sys.service.EmailService#insEmlRcvrMgmt(com.oms.sys.dto.EmailReqDTO)
     */
    @Override
    public int insEmlRcvrMgmt(EmailReqDTO dto) {
        // TODO Auto-generated method stub
        return emailDao.insEmlRcvrMgmt(dto);
    }

    /*
     * @see com.oms.sys.service.EmailService#selectEmlDupChk(com.oms.sys.dto.EmailReqDTO)
     */
    @Override
    public String selectEmlDupChk(EmailReqDTO dto) {
        // TODO Auto-generated method stub
        return emailDao.selectEmlDupChk(dto);
    }

    /*
     * @see com.oms.sys.service.EmailService#delEmlRcvrMgmt(com.oms.sys.dto.EmailReqDTO)
     */
    @Override
    public int delEmlRcvrMgmt(EmailReqDTO dto) {
        // TODO Auto-generated method stub
        return emailDao.delEmlRcvrMgmt(dto);
    }

    /*
     * @see com.oms.sys.service.EmailService#emlRcvrUsrList(com.oms.sys.dto.EmailReqDTO)
     */
    @Override
    public List<EmailRcvrResDTO> emlRcvrUsrList(EmailReqDTO dto) {
        // TODO Auto-generated method stub
        return emailDao.emlRcvrUsrList(dto);
    }

    /*
     * @see com.oms.sys.service.EmailService#selectEmailLog(com.oms.sys.dto.EmailReqDTO)
     */
    @Override
    public EmailLogResDTO selectEmailLog(EmailReqDTO dto) {
        // TODO Auto-generated method stub
        return emailDao.selectEmailLog(dto);
    }


}
