package com.oms.sys.dao;

import java.util.List;

import com.oms.common.dto.CommReqDTO;
import com.oms.sys.dto.AuthAffrMgmtReqDTO;
import com.oms.sys.dto.AuthAffrMgmtResDTO;
import com.oms.sys.dto.PgmMgmtReqDTO;
import com.oms.sys.dto.PgmMgmtResDTO;
import com.oms.sys.dto.UseYnReqDTO;
import com.oms.sys.model.AuthAffrMgmt;

/**
 * <pre>
 * PgmMgmt DAO 인터페이스
 * </pre>
 *
 * @Class Name  : PgmMgmtDAO.java
 * @Description : 메뉴정보/메뉴별 권한정보
 * @author 안경수
 * @since 2023.3.06
 * @see
*/
public interface PgmMgmtDAO {

    List<PgmMgmtResDTO> selectPgmMgmtListAll(PgmMgmtReqDTO dto);
    List<PgmMgmtResDTO> selectPgmMgmtList(CommReqDTO commReqDTO);
    List<PgmMgmtResDTO> selectPgmMgmtGrpList();

    int insertPgmMgmt(PgmMgmtReqDTO dto);
    int updatePgmMgmt(PgmMgmtReqDTO dto);
    int deletePgmMgmt(PgmMgmtReqDTO dto);
    List<PgmMgmtResDTO> selectGrpUsrList();
    int insertPgmGrpAuth();
    int deletePgmGrpAuth();
    int updatePgmMgmtUseYn(UseYnReqDTO useYnReqDTO);

    // 메뉴별 권한정보
    List<AuthAffrMgmtResDTO> selectAuthAffrMgmtList(AuthAffrMgmtReqDTO authAffrMgmtReqDTO);
    List<AuthAffrMgmtResDTO> selectAuthAffrMgmtListByGrp(AuthAffrMgmtReqDTO authAffrMgmtReqDTO);
    List<AuthAffrMgmtResDTO> selectAuthAffrMgmt(AuthAffrMgmtReqDTO authAffrMgmtReqDTO);
    int deleteAuthAffrMgmt(AuthAffrMgmt authAffrMgmt);
    int insertAuthAffrMgmt(List<AuthAffrMgmt> list);
    /**
     * Statements
     *
     * @param dto
     * @return
     */
    int insertPgmtMgmtGrp(PgmMgmtReqDTO dto);
    /**
     * Statements
     *
     * @param dto
     * @return
     */
    int updatePgmtMgmtGrp(PgmMgmtReqDTO dto);
    /**
     * Statements
     *
     * @param authAffrMgmtReqDTO
     * @return
     */
    List<AuthAffrMgmtResDTO> selectAuthAffrMgmtMainList(AuthAffrMgmtReqDTO authAffrMgmtReqDTO);
}
