package com.oms.sys.service.impl;

import java.util.List;

import org.springframework.stereotype.Service;

import com.oms.sys.dao.LogLgiDAO;
import com.oms.sys.dto.LogComReqDTO;
import com.oms.sys.dto.LogLgiReqDTO;
import com.oms.sys.dto.LogLgiResDTO;
import com.oms.sys.service.LogLgiService;

import lombok.RequiredArgsConstructor;



/**
 * <pre>
 * Statements
 * </pre>
 * @ClassName : LogLgiServiceImpl.java
 * @Description :
 * @author 김경훈
 * @since 2023. 6. 16.
 * @see
 */
@RequiredArgsConstructor
@Service("logLgiService")
public class LogLgiServiceImpl implements LogLgiService {

    private final LogLgiDAO logLgiDAO;

    @Override
    public List<LogLgiResDTO> selectLogLgiHistorys(LogComReqDTO dto) {
        return logLgiDAO.selectLogLgiHistorys(dto);
    }

    @Override
    public Integer selectLogLgiHistoryTots(LogComReqDTO dto) {
        return logLgiDAO.selectLogLgiHistoryTots(dto);
    }

    @Override
    public int insertLogLgiHistory(LogLgiReqDTO dto) {
        return logLgiDAO.insertLogLgiHistory(dto);
    }

    @Override
    public int updateLogLgiHistory(LogLgiReqDTO dto) {
        return logLgiDAO.updateLogLgiHistory(dto);
    }




}
