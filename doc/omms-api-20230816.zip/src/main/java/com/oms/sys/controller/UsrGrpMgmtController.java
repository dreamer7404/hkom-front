package com.oms.sys.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import able.cloud.core.web.HController;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.oms.cmm.global.Consts;
import com.oms.cmm.utils.Utils;
import com.oms.sys.dto.UseYnReqDTO;
import com.oms.sys.dto.UsrGrpMgmtReqDTO;
import com.oms.sys.dto.UsrGrpMgmtResDTO;
import com.oms.sys.service.UsrGrpMgmtService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;


/**
 * <pre>
 * UsrMgmt Controller
 * </pre>
 *
 * @ClassName   : UsrMgmtController.java
 * @Description : 클래스 설명을 기술합니다.
 * @author 안경수
 * @since 2023.1.19
 * @see
 */
@Slf4j
@Tag(name = "UsrGrpMgmtController", description = "")
@RequiredArgsConstructor
@RestController
@RequestMapping("/api")
public class UsrGrpMgmtController extends HController {

    private final HttpServletRequest request;

	private final UsrGrpMgmtService usrGrpMgmtService;


	@Operation(summary = "사용자 그룹 정보 조회")
	@GetMapping(value = "/usrGrpMgmts")
	public List<UsrGrpMgmtResDTO> selectUsrGrpMgmtById() throws Exception {
	    List<UsrGrpMgmtResDTO> list = usrGrpMgmtService.selectUsrGrpMgmtList();
	    return list;
	}

	/**
     * 사용자그룹 정보 등록, 수정
     */
    @Operation(summary = "사용자그룹 정보 등록,수정", description = "")
    @PostMapping(value = "/usrGrpMgmt")
    public Integer insertUsrMgmt(@RequestBody UsrGrpMgmtReqDTO usrGrpMgmtReqDTO) {
        int result = 0;
        String pprrEeno = Utils.getUserEeno(request); // 등록자
        String method = Utils.getMethod(request);   // 메소드
        try {
            // 등록
            if(method.equals(Consts.INSERT)) {

                // grpCd 체크
                UsrGrpMgmtReqDTO reqDTO1 = new UsrGrpMgmtReqDTO();
                reqDTO1.setGrpCd(usrGrpMgmtReqDTO.getGrpCd());
                UsrGrpMgmtResDTO resDTO1 = usrGrpMgmtService.selectUsrGrpMgmt(reqDTO1);
                if(resDTO1 != null) {
                    return -1; // grpCd 중복!!
                }

                // 정렬순서
                UsrGrpMgmtReqDTO reqDTO2 = new UsrGrpMgmtReqDTO();
                reqDTO2.setSortSn(usrGrpMgmtReqDTO.getSortSn());
                UsrGrpMgmtResDTO resDTO2 = usrGrpMgmtService.selectUsrGrpMgmt(reqDTO2);
                if(resDTO2 != null) {
                    return -2; // 이미사용중
                }

                // 그룹이름
                UsrGrpMgmtReqDTO reqDTO3 = new UsrGrpMgmtReqDTO();
                reqDTO3.setGrpNm(usrGrpMgmtReqDTO.getGrpNm());
                UsrGrpMgmtResDTO resDTO3 = usrGrpMgmtService.selectUsrGrpMgmt(reqDTO3);
                if(resDTO3 != null) {
                    return -3; // 이미사용중
                }

                usrGrpMgmtReqDTO.setPprrEeno(pprrEeno);
                result = usrGrpMgmtService.insertUsrGrpMgmt(usrGrpMgmtReqDTO);

            }
            // 수정
            else if(method.equals(Consts.UPDATE)) {

                // grpCd 체크
                UsrGrpMgmtReqDTO reqDTO1 = new UsrGrpMgmtReqDTO();
                reqDTO1.setGrpCd(usrGrpMgmtReqDTO.getGrpCd());
                UsrGrpMgmtResDTO resDTO1 = usrGrpMgmtService.selectUsrGrpMgmt(reqDTO1);
                if(resDTO1 == null) {
                    return -1; // NO grpCd~
                }

                // 정렬순서
                if(!resDTO1.getSortSn().equals(usrGrpMgmtReqDTO.getSortSn())) {
                    // 다른그룹코드에서 이미사용중이면...
                    UsrGrpMgmtReqDTO reqDTO2 = new UsrGrpMgmtReqDTO();
                    reqDTO2.setSortSn(usrGrpMgmtReqDTO.getSortSn());
                    UsrGrpMgmtResDTO resDTO2 = usrGrpMgmtService.selectUsrGrpMgmt(reqDTO2);
                    if(resDTO2 != null) {
                        return -2; // 이미사용중
                    }
                }




                usrGrpMgmtReqDTO.setPprrEeno(pprrEeno);
                result = usrGrpMgmtService.updateUsrGrpMgmt(usrGrpMgmtReqDTO);
            }else {
                return -3; // no method
            }

        }catch(Exception e) {
            e.printStackTrace();
        }

        return result;
    }








}