package com.oms.sys.controller;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.oms.cmm.utils.Utils;
import com.oms.sys.dto.BatchLogResDTO;
import com.oms.sys.dto.BatchReqDTO;
import com.oms.sys.dto.BatchResDTO;
import com.oms.sys.service.BatchService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;



/**
 * <pre>
 * Statements
 * </pre>
 * @ClassName : BatchController.java
 * @Description :
 * @author 김경훈
 * @since 2023. 7. 6.
 * @see
 */
@Tag(name = "BatchController", description = "")
@RequiredArgsConstructor
@RestController
@RequestMapping("/api")
public class BatchController {

    /**
     * 클래스 Injection
     */
    private final BatchService batchService;
    private final HttpServletRequest request;

    /**
     * Batch 목록을 조회
     */
    @Operation(summary = "Batch 목록을 조회 ")
    @GetMapping("/batchInfos")
    public List<BatchResDTO> batchInfos() throws Exception {
        List<BatchResDTO> list = batchService.selectBatchInfos();

        return list;
    }





    /**
     * Batch이력 총합 조회
     */
    @Operation(summary = "Batch이력 총합 조회 ")
    @GetMapping("/batchLogs")
    public List<BatchLogResDTO> batchLogs(@ModelAttribute BatchReqDTO dto) throws Exception {
        List<BatchLogResDTO> list = batchService.selectBatchLogs(dto);

        return list;
    }

    /**
     * Batch이력 총합 조회
     */
    @Operation(summary = "Batch이력 총합 조회 ")
    @GetMapping("/batchLogsTot")
    public Integer batchLogsTot(@ModelAttribute BatchReqDTO dto) throws Exception {


        return  batchService.selectBatchLogsTot(dto);
    }

    /**
     * Batch실행
     */
    @Operation(summary = "Batch실행")
    @PostMapping("/batchSave")
    public Integer runProcedure(@RequestBody BatchReqDTO dto) throws Exception {
        int result = 0;
        try {


        dto.setDlExpdCoCd(Utils.getDlExpdCoCd(request));
        LocalTime present = LocalTime.now();

         // 특정 시간 구하기
         // static LocalTime of(int hour, int minute, int second, int nanoOfSecond)
         LocalTime gbnTime = LocalTime.of(15, 00, 00, 000000000);
         boolean gbn = present.isBefore(gbnTime);


         System.out.println(present);
         System.out.println(gbnTime);
         System.out.println(gbn);


         //APS
         if("1".equals(dto.getBtchSn())) {
             if("01".equals(dto.getDlExpdCoCd())) {
                 dto.setBtchGbn("APS_HMC");
                  batchService.runApsProcedureHmc(dto);
             }else {
                 dto.setBtchGbn("APS_KMC");
                 batchService.runApsProcedureKmc(dto);
             }

         }

         //ERP
         if("2".equals(dto.getBtchSn())) {
             if("01".equals(dto.getDlExpdCoCd())) {
                 if(gbn==false) {
                     dto.setBtchGbn("01");
                 } else {
                     dto.setBtchGbn("02");
                 }
                  batchService.runErpProcedureHmc(dto);
             }else {
                 if(gbn==false) {
                     dto.setBtchGbn("01");
                 }
                 else  {
                     dto.setBtchGbn("02");
                 }
                     batchService.runErpProcedureKmc(dto);
             }
         }

        }catch (Exception e) {
            return -1;
        }

//        result = batchService.runApsProcedure(dto);
        return  1;
    }


}
