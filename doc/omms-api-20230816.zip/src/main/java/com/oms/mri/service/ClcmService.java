package com.oms.mri.service;

import java.util.HashMap;
import java.util.List;

import com.oms.mri.dto.ClcmInfoPopReqDTO;
import com.oms.mri.dto.ClcmInfoResDTO;
import com.oms.mri.dto.ClcmInfosReqDTO;
import com.oms.mri.dto.ClcmInfosResDTO;

/**
 * <pre>
 * ClcmService
 * </pre>
 * @ClassName : ClcmService.java
 * @Description : 제작준비 > 법규및변경관리 서비스
 * @author 김정웅
 * @since 2023. 5. 22.
 * @see
 */

public interface ClcmService {
    //법규 및 변경관리 조회
    List<ClcmInfosResDTO> selectClcmInfoList(ClcmInfosReqDTO reqDto) throws Exception;

    //법규 및 변경관리 등록
    Integer insertClcmInfoPop(ClcmInfoPopReqDTO reqDto) throws Exception;
    //법규 및 변경관리 수정
    Integer updateClcmInfoPop(ClcmInfoPopReqDTO reqDto) throws Exception;
    //법규 및 변경관리 삭제
    Integer deleteClcmInfoPop(List<ClcmInfoPopReqDTO> reqDto, String userEeno, String dlExpdCoCd) throws Exception;

    //법규 및 변경관리 상세
    ClcmInfoResDTO selectClcmInfo(ClcmInfosReqDTO reqDto) throws Exception;

    //법규 및 변경관리 수정 차종 별 언어 조회
    List<HashMap<String, String>> selectClcmLangCdList(String qltyVehlCd) throws Exception;

    //법규 및 변경관리 상세 송부인 조회
    List<HashMap<String, String>> selectmriClcmInfoRcvrList(ClcmInfosReqDTO reqDto) throws Exception;
}
