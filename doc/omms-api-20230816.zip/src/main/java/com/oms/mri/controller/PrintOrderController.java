package com.oms.mri.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import able.cloud.core.web.HController;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.oms.cmm.global.Consts;
import com.oms.cmm.utils.Utils;
import com.oms.common.dto.AttcFileReqDTO;
import com.oms.common.service.AttcFileService;
import com.oms.mri.dto.ClcmInfosResDTO;
import com.oms.mri.dto.PrintOrderComDTO;
import com.oms.mri.dto.PrintOrderInfoReqDTO;
import com.oms.mri.dto.PrintOrderInfosResDTO;
import com.oms.mri.dto.PrintOrderPageInfosResDTO;
import com.oms.mri.dto.PrintOrderPageReqDTO;
import com.oms.mri.dto.PrintOrderPrntPbcnNoResDTO;
import com.oms.mri.dto.PrintOrderReqInfoResDTO;
import com.oms.mri.service.PrintOrderService;
import com.oms.sys.dto.FileUploadLogReqDTO;
import com.oms.sys.service.FileUploadLogService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;


/**
 * <pre>
 * PrintOrderController
 * </pre>
 *
 * @ClassName   : PrintOrderController.java
 * @Description : 제작준비 > O/M발주 컨트롤러
 * @author 김정웅
 * @since 2023.5.11
 * @see
 */
@Tag(name = "PrintOrderController", description = "")
//@CrossOrigin(origins="*")
@RequiredArgsConstructor
@RestController
@RequestMapping("/api")
public class PrintOrderController extends HController {

    /**
     * 클래스 Injection
     */
    private final HttpServletRequest request;
    private final PrintOrderService printOrderService;
    private final AttcFileService attcFileService;
    private final FileUploadLogService fileUploadLogService;

    /**
     * 제작준비 > O/M 발주
     */
    @Operation(summary = "O/M 발주 목록")
    @Parameter(in = ParameterIn.HEADER, name="_method")
    @PostMapping("/printOrderInfos")
    public List<PrintOrderInfosResDTO> selectPrintOrderList(@RequestBody PrintOrderComDTO reqDto) throws Exception {
        //사용자 ID, 회사코드 할당
        reqDto.setUserEeno(Utils.getUserEeno(request));
        reqDto.setDlExpdCoCd(Utils.getDlExpdCoCd(request));

        reqDto.setSDate(reqDto.getSsDate());
        reqDto.setEDate(reqDto.getEeDate());
        reqDto.setBDate(reqDto.getBbDate());
        reqDto.setIWayCd(reqDto.getIiWayCd());

        List<PrintOrderInfosResDTO> result = new ArrayList<PrintOrderInfosResDTO>();
        result = printOrderService.selectPrintOrderList(reqDto);

        return result;
    }

    /**
     * 제작준비 > O/M 발주 > 개정정보
     */
    @Operation(summary = "O/M발주 개정정보")
    @GetMapping("/printOrderClcmInfos")
    public List<ClcmInfosResDTO> selectPrintOrderClcmInfos(@ModelAttribute PrintOrderComDTO reqDto) throws Exception {
        //사용자 ID, 회사코드 할당
        reqDto.setUserEeno(Utils.getUserEeno(request));
        reqDto.setDlExpdCoCd(Utils.getDlExpdCoCd(request));

        List<ClcmInfosResDTO> result = new ArrayList<ClcmInfosResDTO>();
        result = printOrderService.selectPrintOrderClcmInfos(reqDto);

        return result;
    }

    /**
     * 제작준비 > O/M 발주 > 발간번호코드 조회
     */
    @Operation(summary = "O/M발주 발간번호코드정보")
    @GetMapping("/printOrderPrntPbcnNoInfos")
    public List<PrintOrderPrntPbcnNoResDTO> selectPrintOrderPrntPbcnNoInfos(@ModelAttribute PrintOrderComDTO reqDto) throws Exception {
        //사용자 ID, 회사코드 할당
        reqDto.setUserEeno(Utils.getUserEeno(request));
        reqDto.setDlExpdCoCd(Utils.getDlExpdCoCd(request));

        List<PrintOrderPrntPbcnNoResDTO> result = new ArrayList<PrintOrderPrntPbcnNoResDTO>();
        result = printOrderService.selectPrintOrderPrntPbcnNoInfos(reqDto);

        return result;
    }

    /**
     * 제작준비 > O/M 발주 > 발간번호별 세부내역
     */
    @Operation(summary = "O/M발주 발간번호별 세부내역")
    @GetMapping("/printOrderReqInfo")
    public PrintOrderReqInfoResDTO selectPrintOrderReqInfo(@ModelAttribute PrintOrderComDTO reqDto) throws Exception {
        //사용자 ID, 회사코드 할당
        reqDto.setUserEeno(Utils.getUserEeno(request));
        reqDto.setDlExpdCoCd(Utils.getDlExpdCoCd(request));

        reqDto.setSDate(reqDto.getSsDate());
        reqDto.setEDate(reqDto.getEeDate());
        reqDto.setBDate(reqDto.getBbDate());
        reqDto.setIWayCd(reqDto.getIiWayCd());

        PrintOrderReqInfoResDTO result = new PrintOrderReqInfoResDTO();
        result = printOrderService.selectPrintOrderReqInfo(reqDto);


        return result;
    }

    /**
     * 제작준비 > O/M 발주 > 발간번호별 인쇄배열표 셀렉트박스
     */
    @Operation(summary = "O/M발주 인쇄배열표 콤보박스")
    @GetMapping("/newPrntPbcnNoLrnkCdInfos")
    public List<HashMap<String, String>> selectNPrntPbcnNoLrnkCdList(@ModelAttribute PrintOrderComDTO reqDto) throws Exception {
        //사용자 ID, 회사코드 할당
        reqDto.setUserEeno(Utils.getUserEeno(request));
        reqDto.setDlExpdCoCd(Utils.getDlExpdCoCd(request));


        List<HashMap<String, String>> result = new ArrayList<HashMap<String, String>>();
        result = printOrderService.selectNPrntPbcnNoLrnkCdList(reqDto);
        return result;
    }

    /**
     * 제작준비 > O/M 발주 > 발간번호별 인쇄배열표 조회
     */
    @Operation(summary = "O/M발주 발간번호별 인쇄배열표")
    @GetMapping("/printOrderPageInfo")
    public PrintOrderPageInfosResDTO selectPrintOrderPageInfo(@ModelAttribute PrintOrderComDTO reqDto) throws Exception {
        //사용자 ID, 회사코드 할당
        reqDto.setUserEeno(Utils.getUserEeno(request));
        reqDto.setDlExpdCoCd(Utils.getDlExpdCoCd(request));

        reqDto.setSDate(reqDto.getSsDate());
        reqDto.setEDate(reqDto.getEeDate());
        reqDto.setBDate(reqDto.getBbDate());
        reqDto.setIWayCd(reqDto.getIiWayCd());

        PrintOrderPageInfosResDTO result = new PrintOrderPageInfosResDTO();
        result = printOrderService.selectPrintOrderPageInfo(reqDto);


        return result;
    }

    /**
     * 제작준비 > O/M 발주 > 발간번호별 인쇄배열표 부가정보
     */
    @Operation(summary = "O/M발주 발간번호별 인쇄배열표 부가정보")
    @GetMapping("/printOrderPageInfoDtl")
    public HashMap<String, String> selectPrintOrderPageInfoDtl(@ModelAttribute PrintOrderComDTO reqDto) throws Exception {
        //사용자 ID, 회사코드 할당
        reqDto.setUserEeno(Utils.getUserEeno(request));
        reqDto.setDlExpdCoCd(Utils.getDlExpdCoCd(request));

        reqDto.setSDate(reqDto.getSsDate());
        reqDto.setEDate(reqDto.getEeDate());
        reqDto.setBDate(reqDto.getBbDate());
        reqDto.setIWayCd(reqDto.getIiWayCd());

        HashMap<String, String> result = printOrderService.selectPrintOrderPageInfoDtl(reqDto);


        return result;
    }

    /**
     * 제작준비 > O/M 발주 > 발간번호별 인쇄배열표 수정
     */
    @Operation(summary = "발간번호별 인쇄배열표 수정", description = "")
    @Parameter(in = ParameterIn.HEADER, name="_method")
    @PostMapping(value = "/printOrderPageInfo")
    public Integer insertPrintOrderPageInfo(@RequestBody PrintOrderPageReqDTO reqDto) throws Exception {
        String method = Utils.getMethod(request);
        String userEeno = Utils.getUserEeno(request);
        String dlExpdCoCd = Utils.getDlExpdCoCd(request);
        reqDto.setUserEeno(userEeno);
        reqDto.setDlExpdCoCd(dlExpdCoCd);

        int result = 0;

        if(method.equals(Consts.UPDATE)) {
            result = printOrderService.insertPrintOrderPageInfo(reqDto);
        }

        return result;
    }

    /**
     * 제작준비 > O/M 발주 > 등록
     */
    @Operation(summary = "O/M 발주 등록", description = "")
    @Parameter(in = ParameterIn.HEADER, name="_method")
    @PostMapping(value = "/printOrderInfo")
    public Integer insertPrintOrderInfo(@RequestBody PrintOrderInfoReqDTO reqDto) throws Exception {
        String method = Utils.getMethod(request);
        String userEeno = Utils.getUserEeno(request);
        String dlExpdCoCd = Utils.getDlExpdCoCd(request);
        String ip = Utils.getRemoteAddress(request);
        reqDto.setUserEeno(userEeno);
        reqDto.setDlExpdCoCd(dlExpdCoCd);

        int result = 0;

        if(method.equals(Consts.INSERT)) {
            result = printOrderService.insertPrintOrderInfo(reqDto);
        } else if (method.equals(Consts.UPDATE)) {
            List<PrintOrderInfoReqDTO> reqDtos = new ArrayList<PrintOrderInfoReqDTO>();
            reqDtos.add(reqDto);
            result = printOrderService.deletePrintOrderInfo(reqDtos, userEeno, dlExpdCoCd);
            if(result > 0) {
                result = printOrderService.insertPrintOrderInfo(reqDto);
            }
        }
        if(method.equals(Consts.INSERT) || method.equals(Consts.UPDATE) && result > 0) {
            //------------------------첨부파일 표지 --------------------------------------------------------
            // tb_attc_mgmt 기존파일 삭제
            if(reqDto.getAttcSnDeletedCover() != null && !reqDto.getAttcSnDeletedCover().isEmpty()) {
                attcFileService.deleteAttcFile(reqDto.getAttcSnDeletedCover());
            }

            // 새로운 첨부파일 나머지정보 저장
            if(reqDto.getAttcSnCover() != null && !reqDto.getAttcSnCover().isEmpty() ) {

                List<AttcFileReqDTO> attcFileListCover = new ArrayList<>();

                for(int i=0; i<reqDto.getAttcSnCover().size(); i++) {
                    long attcSn = Long.parseLong(reqDto.getAttcSnCover().get(i));

                    attcFileListCover.add(new AttcFileReqDTO(
                            attcSn,
                            "O",                                        // 내지/표지(attcGbn)
                            String.valueOf(reqDto.getNewPrntPbcnNo()), //  PK string =>gbnSn
                            0L,                                    //  PK long
                            reqDto.getExtensionCover().get(i),
                            reqDto.getOriginalNameCover().get(i),
                            Integer.valueOf(reqDto.getSizeCover().get(i)),
                            reqDto.getUserEeno()
                            ));

                    // 로그저장
                    fileUploadLogService.insertFileUploadHistory(new FileUploadLogReqDTO(
                            "07", // 06: 다운로드, 07:업로드
                            reqDto.getUserEeno(),
                            ip,
                            "O",
                            attcSn,
                            "/printOrderInfo"
                            ));
                }
                attcFileService.updateAttcFile(attcFileListCover);  // 업데이트
            }

            //------------------------첨부파일 내지 --------------------------------------------------------
            // tb_attc_mgmt 기존파일 삭제
            if(reqDto.getAttcSnDeletedInner() != null && !reqDto.getAttcSnDeletedInner().isEmpty()) {
                attcFileService.deleteAttcFile(reqDto.getAttcSnDeletedInner());
            }

            // 새로운 첨부파일 나머지정보 저장
            if(reqDto.getAttcSnInner() != null && !reqDto.getAttcSnInner().isEmpty() ) {

                List<AttcFileReqDTO> attcFileListInner = new ArrayList<>();

                for(int i=0; i<reqDto.getAttcSnInner().size(); i++) {
                    long attcSn = Long.parseLong(reqDto.getAttcSnInner().get(i));

                    attcFileListInner.add(new AttcFileReqDTO(
                            attcSn,
                            "I",                                        // 내지/표지(attcGbn)
                            String.valueOf(reqDto.getNewPrntPbcnNo()), //  PK string =>gbnSn
                            0L,                                    //  PK long
                            reqDto.getExtensionInner().get(i),
                            reqDto.getOriginalNameInner().get(i),
                            Integer.valueOf(reqDto.getSizeInner().get(i)),
                            reqDto.getUserEeno()
                            ));

                    // 로그저장
                    fileUploadLogService.insertFileUploadHistory(new FileUploadLogReqDTO(
                            "07", // 06: 다운로드, 07:업로드
                            reqDto.getUserEeno(),
                            ip,
                            "I",
                            attcSn,
                            "/printOrderInfo"
                            ));
                }
                attcFileService.updateAttcFile(attcFileListInner);  // 업데이트
            }
        }


        return result;
    }

    /**
     * 제작준비 > O/M 발주 > 발주취소 또는 삭제
     */
    @Operation(summary = "O/M 발주 삭제", description = "")
    @Parameter(in = ParameterIn.HEADER, name="_method")
    @PostMapping(value = "/printOrderInfoDelete")
    public Integer deletePrintOrderInfo(@RequestBody List<PrintOrderInfoReqDTO> reqDto) throws Exception {
        String method = Utils.getMethod(request);
        String userEeno = Utils.getUserEeno(request);
        String dlExpdCoCd = Utils.getDlExpdCoCd(request);

        int result = 0;
        if(reqDto.size() < 1) {
            return 0;
        }
        if (method.equals(Consts.DELETE)) {
            result = printOrderService.deletePrintOrderInfo(reqDto, userEeno, dlExpdCoCd);
        }

        return result;
    }

    /**
     * 제작준비 > O/M 발주 > 발간번호 중복체크
     */
    @Operation(summary = "O/M발주 발간번호 중복체크", description = "")
    @GetMapping(value = "/printOrderPrntPbcnNoDupChk")
    public Integer selectPrntPbcnNoDupChk(PrintOrderInfoReqDTO reqDto) throws Exception {
        String userEeno = Utils.getUserEeno(request);
        String dlExpdCoCd = Utils.getDlExpdCoCd(request);
        reqDto.setUserEeno(userEeno);
        reqDto.setDlExpdCoCd(dlExpdCoCd);

        int result = 0;
        result = printOrderService.selectPrntPbcnNoDupChk(reqDto);

        return result;
    }




}