import React, {useEffect, useMemo, useRef, useState} from 'react';
import { AgGridReact } from 'ag-grid-react';
import { CONSTANTS } from '../../../../utils/constants';

const GridAuthGroupList = ({filterValue, rowData, queryResult, limit, activePage, onCellClicked }) => {

  const gridRef = useRef();




  const columnDefs = [
        {
            headerName: '그룹명',
            field: 'grpNm',
            maxWidth:'250',
            cellStyle: () => ({textDecoration: 'underline', cursor: 'pointer', color:'#2589f5'})
        },
        {
          headerName: '권한',
          field: 'pgmNms',
          wrapText: true,
          cellStyle: () => ({textAlign:'left'})
        },
  ]

  const defaultColDef = useMemo(() => {
      return {
          initialWidth: 90,
          sortable: true,
          resizable:true,
      };
  }, []);

  const onFirstDataRendered = (params) => {
      params.api.sizeColumnsToFit();
  };


  useEffect(()=>{
    if(queryResult.status === 'loading' && gridRef && gridRef.current && gridRef.current.api){
        gridRef.current.api.showLoadingOverlay();
    }
  },[queryResult]);

  useEffect(()=> {
    if(gridRef && gridRef.current && gridRef.current.api){
      gridRef.current.api.setQuickFilter(filterValue);
    }
  },[filterValue]);

  useEffect(()=> {
    if(gridRef && gridRef.current && gridRef.current.api){
      gridRef.current.api.paginationGoToPage(activePage-1);
    }
  },[activePage]);

  const gridOptions = {
    domLayout: 'autoHeight',
  };

  return(
      <div className="ag-theme-alpine" style={{transition:'all ease .3s'}}>
        <AgGridReact
            ref={gridRef} 
            rowData={rowData} 
            columnDefs={columnDefs}
            defaultColDef={defaultColDef}

            // paging
            pagination={true}
            paginationPageSize={limit} //
            suppressPaginationPanel={true} 
            // onPaginationChanged={onPaginationChanged}
            
            rowSelection={'multiple'}
            suppressRowClickSelection= {true} 
            
            onCellClicked={onCellClicked}
          

            //grid auto height 
            gridOptions={gridOptions}

            // overlay
            overlayLoadingTemplate={CONSTANTS.gridLoading}
            overlayNoRowsTemplate={CONSTANTS.gridNoRows}

            onFirstDataRendered={onFirstDataRendered}
            suppressSizeToFit={true}    
            onGridSizeChanged={onFirstDataRendered}    

            rowHeight={80}
            >
        </AgGridReact>
    </div>
  )


};
export default GridAuthGroupList;