import React from 'react';
import { Form, SelectPicker } from 'rsuite';

//--------------  서버데이터용 필수 -------------------------------
import { useQuery} from 'react-query';
import { getData } from '../../utils/async';
import { API, CONSTANTS } from '../../utils/constants';
import useStore from '../../utils/store';
//--------------// 서버데이터용 필수 -------------------------------


const DlvtState = () => {

    const {keyword, 
        setDlvtState,  // sub코드 setter
    } = useStore(); 

    const onChangeDlvtState = val => {
        setDlvtState(val);
    };


    // subCd API가져오기
    const dlvtStateParams = {
        mainCd: '0017'
    };
    const dlvtStateCombo = useQuery([API.subCdCombo, dlvtStateParams], () => getData(API.subCdCombo, dlvtStateParams), {
            select: data => [{label: CONSTANTS.labelAll, value: CONSTANTS.valueAll}].concat(data.map((item) => ({ label: item.dlExpdPrvsNm, value: item.dlExpdPrvsCd })))
    });

    return (
        <>
        <Form.ControlLabel column="sm" >배송여부</Form.ControlLabel>
            <SelectPicker size="sm"
                value={keyword.dlvtState} 
                data={dlvtStateCombo && dlvtStateCombo.data ? dlvtStateCombo.data : []} 
                onChange={onChangeDlvtState}
                placeholder={CONSTANTS.labelAll}
                cleanable={false}
                searchable={false}
                block={true}
            />
        </>
    )
}
export default DlvtState;