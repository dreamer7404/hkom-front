import React, { useMemo } from 'react';
import styled from 'styled-components';

//width: 150px;
const StyledTooltip = styled.div`
    height: 30px;
    border: 1px solid cornflowerblue;
    background-color: #fff;
    text-align: center;
    padding-top: 5px;
    overflow: hidden;
`;

const CustomTooltip = (props) => {
    const data = useMemo(() => props.api.getDisplayedRowAtIndex(props.rowIndex).data ,[]);
    const len = data[props.colDef.field].length * 20;
    const label = data[props.colDef.field];

    return (
        <StyledTooltip style={{width: len+'px'}}>{label}</StyledTooltip>
    )
};
export default CustomTooltip;
