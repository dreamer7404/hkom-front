package com.oms.common.dao;

import com.oms.common.dto.AttcFileReqDTO;


/**
 * <pre>
 * Statements
 * </pre>
 * @ClassName : MailDAO.java
 * @Description :
 * @author 안경수
 * @since 2023. 5. 26.
 * @see
 */
public interface AttcFileDAO {

    int insertAttcFile(AttcFileReqDTO attcFileReqDTO);

}
