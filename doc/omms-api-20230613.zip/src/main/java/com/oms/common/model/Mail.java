package com.oms.common.model;

import org.apache.ibatis.type.Alias;

import lombok.Data;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @author 안경수
 * @since 2023. 6. 9.
 * @see
 */

@Data
@Alias("mail")
public class Mail {
    private String emlId; // 수신자 ID
    private String emlAdr; // 수신자 메일주소
}
