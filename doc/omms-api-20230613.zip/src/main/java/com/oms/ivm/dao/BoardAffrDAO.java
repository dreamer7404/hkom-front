package com.oms.ivm.dao;

import java.util.List;

import com.oms.common.dto.VehlMdyLangReqDTO;
import com.oms.ivm.dto.BoardAffrRcvUsersReqDTO;
import com.oms.ivm.dto.BoardAffrRcvUsersSaveDTO;
import com.oms.ivm.dto.BoardAffrReqDTO;

/**
 * <pre>
 * BoardAffrDAO 인터페이스
 * </pre>
 *
 * @Class Name  : BoardAffrDAO.java
 * @Description : 재고관리 > 게시판
 * @author 안경수
 * @since 2023.6.1
 * @see
*/
public interface BoardAffrDAO {
    int insertBoardAffrMgmt(BoardAffrReqDTO boardAffrReqDTO);
    int insertBoardAffrVehl(List<VehlMdyLangReqDTO> list);
    int insertBoardAffrRcvUsers(BoardAffrRcvUsersSaveDTO boardAffrRcvUsersSaveDTO);
}
