package com.oms.sys.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import able.cloud.core.web.HController;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.oms.cmm.global.Consts;
import com.oms.cmm.utils.Utils;
import com.oms.sys.dto.CodeMgmtReqDTO;
import com.oms.sys.dto.CodeMgmtResDTO;
import com.oms.sys.service.CodeMgmtService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;


/**
 * <pre>
 * CodeMgmt Controller
 * </pre>
 *
 * @ClassName   : CodeMgmtController.java
 * @Description :
 * @author 안경수
 * @since 2023.1.19
 * @see
 */
@Tag(name = "CodeMgmtController", description = "")
@RequiredArgsConstructor
@RestController
@RequestMapping("/api")
public class CodeMgmtController extends HController {

    /**
     * 클래스 Injection
     */
	private final CodeMgmtService codeMgmtService;
	private final HttpServletRequest request;


	/**
     * 코드 목록을 조회
     */
	@Operation(summary = "코드 목록을 조회")
    @GetMapping("/codeMgmts")
    public List<CodeMgmtResDTO> selectCodeMgmtList(@ModelAttribute CodeMgmtReqDTO codeMgmtReqDTO) throws Exception {
	    return codeMgmtService.selectCodeMgmtList(codeMgmtReqDTO);
    }

	/**
     * 그룹 콤보박스 조회
     */
    @Operation(summary = "그룹 콤보박스 조회")
    @GetMapping("/grpCodeCombo")
    public List<HashMap<String,Object>>grpCodeCombo() throws Exception {
        return codeMgmtService.selectGrpCodeCombo();
    }


    /**
     * 그룹 콤보박스 조회
     */
    @Operation(summary = "그룹코드 추가 시 추가할 코드")
    @GetMapping("/nextGrpCode")
    public HashMap<String,Object> nextGrpCode() throws Exception {
        return codeMgmtService.selectNextGrpCode();
    }
    /**
     * 코드정보 등록, 수정, 삭제
     */
    @Operation(summary = "그룹코드정보 등록,수정,삭제", description = "")
    @PostMapping(value = "/codeGrpMgmt")
    public Integer insertCodeGrpMgmt(@RequestBody CodeMgmtReqDTO codeMgmtReqDTO) throws Exception {
        int result = 0;

        String method = Utils.getMethod(request);

            codeMgmtReqDTO.setPprrEeno(Utils.getUserEeno(request)); //등록자
            if(method.equals(Consts.INSERT)) {

                String codeGrpChk = codeMgmtService.getCodeGrpChk(codeMgmtReqDTO);//중복체크
                if("Y".equals(codeGrpChk)) { //Y면 중복데이터 있음
                    result = 999;
                }
                else {//N일경우 진행
                    result =codeMgmtService.insertCodeGrpMgmt(codeMgmtReqDTO);
                }


        }else if(method.equals(Consts.UPDATE)) {
            result = codeMgmtService.updateCodeGrpMgmt(codeMgmtReqDTO); //그룹 코드 수정
            result = codeMgmtService.updateCodeMgmt(codeMgmtReqDTO); //코드 수정
            return result;
        }else if(method.equals(Consts.DELETE)) {

//            List<CodeMgmtReqDTO> deleteList = codeMgmtReqDTO.getDeleteList();
            result = codeMgmtService.deleteCodeMgmt(codeMgmtReqDTO);
            result = codeMgmtService.deleteCodeGrpMgmt(codeMgmtReqDTO);

        }
            return result;
    }





	/**
     * 코드정보 등록, 수정, 삭제
     */
    @Operation(summary = "코드정보 등록,수정,삭제", description = "")
    @PostMapping(value = "/codeMgmt")
    public Integer insertUsrMgmt(@RequestBody CodeMgmtReqDTO codeMgmtReqDTO) throws Exception {

        String method = Utils.getMethod(request);
        codeMgmtReqDTO.setPprrEeno(Utils.getUserEeno(request)); //등록자
        if(method.equals(Consts.INSERT)) {
          return codeMgmtService.insertCodeMgmt(codeMgmtReqDTO);
        }else if(method.equals(Consts.UPDATE)) {
            return codeMgmtService.updateCodeMgmt(codeMgmtReqDTO);
        }else if(method.equals(Consts.DELETE)) {
            return codeMgmtService.deleteCodeMgmt(codeMgmtReqDTO);
        }
        return 0;
    }



}