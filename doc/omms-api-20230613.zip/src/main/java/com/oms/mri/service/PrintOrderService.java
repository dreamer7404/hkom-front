package com.oms.mri.service;

import java.util.HashMap;
import java.util.List;

import com.oms.mri.dto.ClcmInfosResDTO;
import com.oms.mri.dto.PrintOrderComDTO;
import com.oms.mri.dto.PrintOrderInfosResDTO;
import com.oms.mri.dto.PrintOrderPageInfosResDTO;
import com.oms.mri.dto.PrintOrderPrntPbcnNoResDTO;
import com.oms.mri.dto.PrintOrderReqInfoResDTO;

/**
 * <pre>
 * PrintOrderService
 * </pre>
 * @ClassName : PrintOrderService.java
 * @Description : 제작준비 > O/M발주 서비스
 * @author 김정웅
 * @since 2023. 5. 11.
 * @see
 */

public interface PrintOrderService {

    List<PrintOrderInfosResDTO> selectPrintOrderList(PrintOrderComDTO reqDto);

    List<ClcmInfosResDTO> selectPrintOrderClcmInfos(PrintOrderComDTO reqDto) ;

    List<PrintOrderPrntPbcnNoResDTO> selectPrintOrderPrntPbcnNoInfos(PrintOrderComDTO reqDto);

    PrintOrderReqInfoResDTO selectPrintOrderReqInfo(PrintOrderComDTO reqDto);

    List<HashMap<String, String>> selectNPrntPbcnNoLrnkCdList(PrintOrderComDTO reqDto);
    PrintOrderPageInfosResDTO selectPrintOrderPageInfo(PrintOrderComDTO reqDto);
}
