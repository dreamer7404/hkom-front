package com.oms.mri.dto;

import org.apache.ibatis.type.Alias;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * <pre>
 * ClcmInfosResDTO
 * </pre>
 *
 * @author 김정웅
 * @since 2023. 5. 11.
 * @see
 */
@Alias("clcmInfosResDTO")
@Data
@AllArgsConstructor
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown =true)
public class ClcmInfosResDTO {

    private String dlExpdAltrNo;
    private String qltyVehlCd;
    private String qltyVehlNm;
    private String langCd;
    private String newPrntPbcnNo;
    private String altrYmd;
    private String rcpmShapCd;      //수신형태 코드
    private String rcpmShapNm;      //수신형태 명
    private String dsppNm;          //발신처
    private String chgrEeno;        //등록자
    private String chgrNm;          //등록자
    private String crgrNm;          //담당자
    private String n1Afp2Adr;
    private String n1Afp2Adr1;
    private String altrTitl;        //제목
    private String altrSbc;         //내용
    private String attcYn;          //첨부파일 여부

//    private List<HashMap<String, String>> headerLangCds;   //그리드 헤더용 언어코드

}
