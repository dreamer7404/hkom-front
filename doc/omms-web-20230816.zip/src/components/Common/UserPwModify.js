import React, { useState } from 'react';
import { Modal, Button, Table } from 'react-bootstrap';
import { Form, InputGroup, Input, Schema, Notification, useToaster } from 'rsuite';

//--------------  서버데이터용 필수 -------------------------------
import { useQuery, useQueryClient, useMutation } from 'react-query';
import { getData, postData } from '../../utils/async';
import { API, CONSTANTS } from '../../utils/constants';
import useStore from '../../utils/store';
import CustomModal from '../Common/CustomModal';
import { confirmAlert } from 'react-confirm-alert'; // Import
import ConfirmAlert from '../Common/ConfirmAlert';
//--------------// 서버데이터용 필수 -------------------------------

const { StringType } = Schema.Types;

const model = Schema.Model({
    userPw: StringType().isRequired('기존 비밀번호를 입력해주세요.'),
    // .pattern(/^(?=.*[A-Za-z])(?=.*\d)(?=.*[$@$!%*#?&])[A-Za-z\d$@$!%*#?&]{7,}$/, 
    //     '최소 7자리이며, 숫자,문자,특수문자는 최소1개이상 입력해주세요')
    // # % = ; ~ - & $ ' " |
    // .rangeLength(7, 20, '7-20자로 입력해주세요'), // 기존 비밀번호 입력 시에는 체크X
    userPwNew: StringType().isRequired('변경 비밀번호를 입력해주세요.')
        .pattern(/^(?=.*[A-Za-z])(?=.*\d)(?=.*[@!*?^()])[A-Za-z\d@!?^*()]{8,}$/,
            '최소 8자리이며 숫자,문자,특수문자는 최소1개이상 입력해주세요')
        .rangeLength(8, 20, '8-20자로 입력해주세요'),
    userPwClon: StringType().isRequired('변경 비밀번호를 재입력해주세요.')
})

const UserPwModify = ({ show, data, onHide }) => {

    const {userOsetLgi,loginUrl,pwChangeYn} = useStore();
    // Form 정의
    const formRef = React.useRef();
    const [formError, setFormError] = React.useState({});
    const [formValue, setFormValue] = React.useState({
        userEeno: '',//data.userEeno,
        userPw: '',
        userPwNew: '',
        userPwClon: '',
    });

    
    // 사용자 수정하기
    const usrmgmtMutate = useMutation((params => postData(API.changeUserPw, params, CONSTANTS.update)), {
        onSuccess: res => {
            if (res > 0) {
                confirmAlert({
                    closeOnClickOutside: false,
                    customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}   title={"알림"} 
                    msg={"비밀번호 변경이 완료되었습니다. <br>변경하신 비밀번호로 다시 로그인 해 주시기 바랍니다"} pageMove={onOk} />
                });
                

            } else if (res === -1) {
            
                confirmAlert({
                    closeOnClickOutside: false,
                    customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}   title={"알림"} 
                    msg={"수정이 실패했습니다. 관리자에게 문의해주세요."}   />
                });
            } else if (res === -2) {
                 confirmAlert({
                    closeOnClickOutside: false,
                    customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}   title={"알림"} 
                    msg={"기존비밀번호가 틀립니다. 정확히 입력해주세요."}   />
                });
            } else if (res === -3) {
                confirmAlert({
                   closeOnClickOutside: false,
                   customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}   title={"알림"} 
                   msg={"이미 등록된 비밀번호입니다 새로운 비밀번호를 입력해주세요."}   />
               })
            }else {
                confirmAlert({
                    closeOnClickOutside: false,
                    customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}   title={"알림"} 
                    msg={"수정을 실패했습니다."}   />
                });
            }
            
        }
    });

    const handleSubmit = () => {
        // validation 체크
        if (!formRef.current.check()) {
            return;
        }
       
        console.log(formValue)
        if (formValue.userPwNew !== formValue.userPwClon) {
            confirmAlert({
                closeOnClickOutside: false,
                customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}   title={"알림"} 
                msg={"변경비밀번호 확인내용이 틀립니다."}   />
            });
        } else {
            //     // 사용자 수정 실행
            usrmgmtMutate.mutate({
                userPw: formValue.userPw,
                userPwNew: formValue.userPwNew
            });
        }

        const str = formValue.userPwNew;
        const arrNum = str.match(/[0-9]/g);
        const arrEng = str.match(/[a-z]/gi);
        const arrSpecial = str.match(/[\{\}\[\]\/?.,;:|\)*~`!^\-_+<>@\#$%&\\\=\(\'\"]/g);
        const isSerial = (/([A-Za-z0-9`~!@#\$%\^&\*\(\)\{\}\[\]\-_=\+\\|;:'"<>,\./\?])\1{2,}/g).test(str);

        // console.log('userPw: ', formValue.userPw)
        // console.log('userPwNew: ', str)

        // console.log('contain: ', str.includes(formValue.userPw))
        // console.log('arrNum: ', arrNum.length)
        // console.log('arrEng: ', arrEng.length)
        // console.log('arrSpecial: ', arrSpecial.length)
        // console.log('isSerial: ', isSerial)


    };

    const handleCancle = () => {

        
        if(userOsetLgi==='0'||pwChangeYn==='Y'){
          
            confirmAlert({
                closeOnClickOutside: false,
                customUI: ({onClose}) => <ConfirmAlert onClose={onClose}  msg={"비밀번호 변경 취소 시 로그아웃 됩니다. 로그아웃 하시겠습니까?"} 
                onOk={onOk} />
            });
         
        }else{
            onHide();
        }
    }
    const onOk=()=>{
        // const url = process.env.REACT_APP_LOCALHOST + (loginUrl ? loginUrl : '/errorPath');
        //window.location.origin.indexOf('localhost') > 0 ? 'http://localhost:8088/api/' : window.location.origin + '/api/';
        const url =  window.location.origin.indexOf('localhost') > 0 ? 'http://localhost:3000/login'
            : window.location.origin + (loginUrl ? loginUrl : '/errorPath');
        window.location.href = url;
     
    }

    const fnOnChange=(e)=>{


        console.log("e",e);
 /** 2.Step 연속된 문자 및 숫자 3자리 이상 입력불가체크 **/
 
    var req_exp_same = /(.)\1\1\1\1/;
        if(req_exp_same.test(e)) {
            confirmAlert({
                closeOnClickOutside: false,
                customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}   title={"알림"} 
                msg={"동일한 문자 및 숫자 5자리 이상 입력할 수 없습니다."}   />
            });
            
            let newPw = e.slice(0, -1); //끝 str삭제
            console.log(newPw);
            setFormValue(p => ({...p, userPwNew: newPw}));
            
        }
        return false;
        
    }
    return (
        <>
            <Form
                ref={formRef}
                // checkTrigger="none"
                onChange={setFormValue}
                onCheck={setFormError}
                formValue={formValue}
                model={model}>
                <Modal show={show} onHide={handleCancle} backdrop="static" keyboard={false} centered size="lg" className="modal-custom">
                    <Modal.Header closeButton>
                        <Modal.Title>비밀번호 변경</Modal.Title>
                    </Modal.Header>
                    <Modal.Body>

                        {/* 비밀번호 유효기간 만료 로그인시 팝업 
                            <div className="password-find">
                                <p>비밀번호를 변경해주세요</p>
                                <p>비밀번호를 변경하신지 6개월(180일)이 경과하였습니다. <br/> 안전한 사용을 위하여, 기존 비밀번호를 변경해주세요. <br/> 비밀번호 미 변경시 로그인이 불가합니다.</p>
                            </div>  */}

                        {/* 임시비밀번호 로그인시 팝업
                            <div className="password-find">
                                <p>비밀번호를 변경해주세요</p>
                                <p>임시 비밀번호 입니다. <br/> 안전한 사용을 위하여, 비밀번호를 변경해주세요. <br/> 비밀번호 미 변경시 로그인이 불가합니다.</p>
                            </div>  */}

                        <Table className="tbl-hor" bordered>
                            <tbody>
                                <tr>
                                    <th>기존 비밀번호</th>
                                    <td>
                                        <Form.Control name="userPw" size="sm" type="password" placeholder="기존 비밀번호를 입력해주세요" />
                                    </td>
                                </tr>
                                <tr>
                                    <th>변경 비밀번호</th>
                                    <td>
                                        <InputGroup>
                                            <Form.Control name="userPwNew" size="sm" style={{ height: '24px' }} type="password" placeholder="변경 비밀번호를 입력해주세요"  onChange={fnOnChange} />
                                            {/* <InputGroup.Addon   style={{display : showSecure==true? "flex": "none"}}></InputGroup.Addon> */}
                                           
                                        </InputGroup>
                                    </td>
                                </tr>
                                <tr>
                                    <th>변경 비밀번호 확인</th>
                                    <td>
                                        <Form.Control name="userPwClon" size="sm" type="password" placeholder="변경 비밀번호를 재입력해주세요" />
                                    </td>
                                </tr>
                            </tbody>
                        </Table>
                        <div className="password-info">
                            <p>[비밀번호 변경규칙]</p>
                            <ul>
                                <li>비밀번호는 최소 8자 이상으로 설정하세요.</li>
                                <li>비밀번호 첫 자리는 반드시 영문 알파벳 대문자로 시작되어야 합니다.</li>
                                <li>비밀번호에는 특수문자가 1개 이상 포함되어야 합니다. <span>사용 불가: # % = ; ~ - & $ ' " |   </span></li>
                                <li>비밀번호에는 영문 알파벳 소,대문자 각 1개 이상 포함되어야 합니다.</li>
                                <li>비밀번호에는 숫자가 1개 이상 포함되어야 합니다. <span>변경예시) Hmc0120!  Apple123?  Kia007!@</span></li>
                                
                                
                            </ul>
                        </div>
                    </Modal.Body>
                    <Modal.Footer>
                        <Button variant="light" size="md" onClick={handleCancle}>취소</Button>
                        <Button variant="primary" size="md" onClick={handleSubmit}>저장</Button>
                    </Modal.Footer>
                </Modal>
            </Form>
        </>
    );

};
export default UserPwModify;