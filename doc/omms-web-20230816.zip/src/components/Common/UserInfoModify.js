import React from 'react';
import {Modal, Button, Table} from 'react-bootstrap';
import {Form, Schema, Notification, useToaster} from 'rsuite';
import CustomModal from '../Common/CustomModal';

//--------------  서버데이터용 필수 -------------------------------
import { useQuery, useQueryClient, useMutation} from 'react-query';
import { getData, postData } from '../../utils/async';
import { API, CONSTANTS } from    '../../utils/constants';
//--------------// 서버데이터용 필수 -------------------------------

const { StringType} = Schema.Types;
const model = Schema.Model({
    userNm: StringType().isRequired('이름을 입력해주세요.')
                            .pattern(/^[가-힣a-zA-Z0-9]+$/, '특수문자는 _ . 만 입력가능합니다')
                            .rangeLength(2, 30, '2-30자로 입력해주세요'),
    userEmlAdr: StringType().isRequired('이메일을 입력해주세요.')
                            .isEmail('이메일 형식에 맞게 입력해주세요.')
                            .maxLength(90, '이메일주소가 너무 깁니다.'),
})

const UserInfoModify = ({show, data, onHide}) => {

    const toaster = useToaster();

    // Form 정의
    const formRef = React.useRef();
    const [formError, setFormError] = React.useState({});
    const [formValue, setFormValue] = React.useState({
        userEeno: data.userEeno,   
        userNm: data.userNm,   
        userEmlAdr: data.userEmlAdr.replace('&#64;', '@'),  
    });

     // 사용자 수정하기
     const usrmgmtMutate = useMutation((params => postData(API.usrmgmt, params, CONSTANTS.update)),{
        onSuccess: res => {
            console.log(res)
            if(res > 0){
                toaster.push(<Notification type='success' header='성공' closable >
                     수정이 완료되었습니다.
                    </Notification>);

                onHide(true); // // 창닫기 & refetch
            }else{
                toaster.push(<Notification type='error' header='실패' closable >
                    수정이 실패했습니다.<br /> 관리자에게 문의해주세요.
                    </Notification>);
                onHide(false); // 창닫기
            }
           
        }
    });

     // 저장버튼 클릭
     const handleSubmit = () => {
        // validation 체크
        if (!formRef.current.check()) {
            return;
        }
        // 사용자 수정 실행
        usrmgmtMutate.mutate(formValue);
    };
    
    return (
        <>
             <Form
                ref={formRef}
                checkTrigger="change"
                onChange={setFormValue}
                onCheck={setFormError}
                formValue={formValue}
                model={model}>
                    <CustomModal open={show} 
                            title={'사용자 정보 수정'}
                            size='md'
                            // handleOk={handleSubmit}
                            handleCancel={onHide} 
                        >
                  
                                <Table className="tbl-hor" bordered>
                                <tbody>
                                    <tr>
                                        <th>아이디</th>
                                        <td>{data.userEeno}</td>
                                    </tr>
                                    <tr>
                                        <th>이름</th>
                                        <td>
                                            <Form.Control name="userNm" size="sm" type="text"  />
                                        </td>
                                    </tr>
                                    <tr>
                                        <th>이메일</th>
                                        <td>
                                            <Form.Control name="userEmlAdr" size="sm" type="text" />
                                        </td>
                                    </tr>
                                    <tr>
                                        <th>회사명</th>
                                        <td>{data.coNm}</td>
                                    </tr>
                                </tbody>
                                </Table>
                        <div className='modal-footer'>
                            <Button variant="light" size="md" onClick={onHide}>취소</Button>
                            <Button variant="primary" size="md" onClick={handleSubmit} >저장</Button>
                        </div> 
                        
                    </CustomModal>
            </Form>
        </>
    );

};
export default UserInfoModify;