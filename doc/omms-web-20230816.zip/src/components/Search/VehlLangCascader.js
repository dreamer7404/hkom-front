/* eslint-disable react-hooks/exhaustive-deps */
import React, {useState, useEffect, useRef} from 'react';
import {Row, Col} from 'react-bootstrap';
import {Form, Button, Schema, Panel, Message, toaster, FlexboxGrid, MultiCascader} from 'rsuite';

//--------------  서버데이터용 필수 -------------------------------
import { useQuery} from 'react-query';
import { getData } from '../../utils/async';
import { API, CONSTANTS } from '../../utils/constants';
import useStore from '../../utils/store';
import { escapeCharChange} from '../../utils/commUtils';
//--------------// 서버데이터용 필수 -------------------------------

//'setSelectedLangCdByVehl'는 부모 컴포넌트에 값을 세팅합니다.
const VehlLangCascader = ({setSelectedLangCdByVehl, formErrorStatus, firstRender}) => {

    const langCdByVehl = useQuery([API.langByVehlCombo,''], () => getData(API.langByVehlCombo,''), {
      select: data => data.map((item) => (item&&{ label: escapeCharChange(item.label), value: item.value
            , children: item.children && item.children.map(item2 => 
                ({ label: escapeCharChange(item2.label), value: item2.value})
            )
        })).sort((a, b) => a && a.label && b && b.label && a.label.localeCompare(b.label))
    });

    const [langCdByVehlCombo, setLangCdByVehlCombo] = useState([]);
    const [unCheckableLangCdByVehlCombo, setUnCheckableLangCdByVehlCombo] = useState([]);
    useEffect(() => {
        if(langCdByVehl.isSuccess){
            setLangCdByVehlCombo(langCdByVehl.data)
            setUnCheckableLangCdByVehlCombo(
                langCdByVehl.data.map(item => {
                    if(!item.children){
                        return item.value
                    }
                })
            )
        }
    }, [langCdByVehl.status])

    const [onCheckedValue, setOnCheckedValue] = useState([])
    useEffect(() => {
        setSelectedLangCdByVehl(onCheckedValue)
    }, [onCheckedValue])

    const [localCheckedValue, setLocalCheckedValue] = useState([])
    const onCheck = (a,b,c) =>{
        
        // console.log('a==', a)
        // console.log('b==',b)
        // console.log('c==',c)
        // if(c){
        //     setLocalCheckedValue(prev => [...prev ,b.value])
        // } else {
        //     setLocalCheckedValue(prev => {return prev.filter(item => {
        //         return item !== b.value
        //     })})
        // }
        //언어 클릭시
        if(b.parent !== null){
            const qltyVehlCd = b.parent.value
            const qltyVehlNm = b.parent.label
            const langCd = b.value.substring(b.value.lastIndexOf('___') + 3)
            const langCdNm = b.label
            if(c){
                setLocalCheckedValue(prev => [...prev ,b.value])
                setOnCheckedValue(prevState => [...prevState, { ['qltyVehlCd']: qltyVehlCd, ['qltyVehlNm']: qltyVehlNm, ['langCd']: langCd, ['langCdNm']: langCdNm }])
            } else {
                setOnCheckedValue((prevArr) => prevArr.filter(item => {
                    if(JSON.stringify(item)!== JSON.stringify({ ['qltyVehlCd']: qltyVehlCd, ['qltyVehlNm']: qltyVehlNm, ['langCd']: langCd, ['langCdNm']: langCdNm })){
                        return item
                    }
                }))
                setLocalCheckedValue(prev => {return prev.filter(item => {
                    return item !== b.value
                })})
            }
            
        } else {
            //차종클릭시 - 하위 언어가 없는 경우
            if(b.children === null || b.children === undefined){
                alert('적용가능한 언어가 없습니다.')
            } 
            //차종클릭시 - 하위 언어가 있는 경우
            else {
                
                b.children.map(item => {
                    const qltyVehlCd = b.value
                    const qltyVehlNm = b.label
                    const langCd = item.value.substring(item.value.lastIndexOf('___') + 3)
                    const langCdNm = item.label
                    if(c){
                        setLocalCheckedValue(prev => [...prev ,item.value])
                        setOnCheckedValue(prevState => [...prevState, { ['qltyVehlCd']: qltyVehlCd, ['qltyVehlNm']: qltyVehlNm, ['langCd']: langCd, ['langCdNm']: langCdNm }])
                    } else {
                        setOnCheckedValue((prevArr) => prevArr.filter(item => {
                            if(JSON.stringify(item)!== JSON.stringify({ ['qltyVehlCd']: qltyVehlCd, ['qltyVehlNm']: qltyVehlNm, ['langCd']: langCd, ['langCdNm']: langCdNm })){
                                return item
                            }
                        }))
                        setLocalCheckedValue(prevs => {return prevs.filter(prev => {
                            return prev !== item.value
                        })})
                    }
                })
                
            }
        }
    }

    const onClean = e =>{
        setOnCheckedValue([])
    }

    const headers = ['차종', '언어'];

    // const onSearch = (e,b) => {
    //     console.log(e.toUpperCase())
    //     if(e.length === 0){
    //         setLangCdByVehlCombo(langCdByVehl.data.map((item) => (item&&{ label: escapeCharChange(item.label), value: item.value
    //             , children: item.children && item.children.map(item2 => 
    //                 ({ label: escapeCharChange(item2.label), value: item2.value})
    //             ) 
    //         })).sort((a, b) => a && a.label && b && b.label && a.label.localeCompare(b.label)))
    //         return false
    //     }
    //     let searchedData = langCdByVehl.data.filter(item => {
    //         return (item.label.indexOf(e.toUpperCase(), 0) > 0 || item.value.indexOf(e.toUpperCase(), 0) > 0) && typeof item.children !== 'undefined'
    //         // {
    //         //     console.log(item.children != 'undefined')
    //         //     return item
    //         // }
    //     })
    //     console.log(searchedData)
    //     setLangCdByVehlCombo(searchedData)
    //     setUnCheckableLangCdByVehlCombo(
    //         langCdByVehl.data.map(item => {
    //             if(!item.children){
    //                 return item.value
    //             }
    //         })
    //     )
    // }
    
    const inputRef = useRef();
    const selectRef = useRef();
    const [searchKeyword, setSearchKeyword] = useState('')
    useEffect(() => {
        if(langCdByVehl && langCdByVehl.isSuccess){
            let e = searchKeyword
            let searchedData = langCdByVehl.data.filter(item => {
                return (item.label.toUpperCase().indexOf(e, 0) > -1 || item.value.toUpperCase().indexOf(e, 0) > -1)
            })
            setLangCdByVehlCombo(searchedData)
            setUnCheckableLangCdByVehlCombo(
                langCdByVehl.data.map(item => {
                    if(!item.children){
                        return item.value
                    }
                })
                )
            if (inputRef.current) {
                console.log(inputRef);
            }
        }
    }, [searchKeyword])

    const onSearch2 = (event, layer) => {
        let e = event.target.value.toUpperCase()
        setSearchKeyword(e)
    }
    const onClose = () => {
        setSearchKeyword('')
    }

    return (
        <>
            {/* {JSON.stringify(localCheckedValue)} */}
            <MultiCascader 
                ref={selectRef}
                className="multi-cascader"
                size="sm"
                menuWidth={250}
                style={{fontSize:'12px', width:'100%', maxWidth:'1200px'}}
                placeholder="차종 및 언어를 선택해주세요"
                // data={options}
                data={langCdByVehlCombo}
                onCheck={onCheck}
                value={localCheckedValue}
                onClean={onClean}
                onClose={onClose}
                // onSearch={(e) => onSearch(e)}
                searchable={false}
                error={formErrorStatus}
                name="langCdByVehlList"
                uncheckableItemValues={unCheckableLangCdByVehlCombo}
                renderMenu={(children, menu, parentNode, layer) => {
                    return (
                
                        <div>
                                    {layer === 0 &&
                                    <div role="" className="rs-picker-search-bar">
                                        <input key="searchKeyword" ref={inputRef} autoFocus className="rs-picker-search-bar-input" placeholder="검색" value={searchKeyword} onChange={(e, layer) => onSearch2(e, layer)} />
                                        <svg width="1em" height="1em" viewBox="0 0 14 14" fill="currentColor" aria-hidden="true" className="rs-picker-search-bar-search-icon rs-icon" aria-label="search" data-category="legacy">
                                            <path d="M9.293 10.707a.999.999 0 111.414-1.414l3 3a.999.999 0 11-1.414 1.414l-3-3z"></path>
                                            <path d="M6 10a4 4 0 100-8 4 4 0 000 8zm0 2A6 6 0 116 0a6 6 0 010 12z"></path>
                                        </svg>
                                    </div>
                                        // <input key="searchKeyword" ref={inputRef} value={searchKeyword} autoFocus onChange={(e, layer) => onSearch2(e, layer)} />
                                    }
                          <div
                              style={{
                              background: '#f8f8f8',
                              padding: '4px 10px',
                              color: ' #000',
                              textAlign: 'center',
                              fontSize:'12px',
                              fontWeight:600
                              }}
                          >
                              {headers[layer]}
                          </div>
                          {menu}
                        </div>
                    );
                }} 
              >
                
                </MultiCascader>
                {firstRender && formErrorStatus &&
                    <Form.ErrorMessage show={firstRender} >
                        {formErrorStatus && '차종및 언어를 선택해주세요'}
                    </Form.ErrorMessage>
                }
        </>
    );

};
export default VehlLangCascader;