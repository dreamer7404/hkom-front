/* eslint-disable react-hooks/exhaustive-deps */
import React, {useState} from 'react';
import {Row, Col} from 'react-bootstrap';
import { SelectPicker, Form } from 'rsuite';

//--------------  서버데이터용 필수 -------------------------------
import { useQuery} from 'react-query';
import { getData } from '../../utils/async';
import { API, CONSTANTS } from '../../utils/constants';
import useStore from '../../utils/store';
//--------------// 서버데이터용 필수 -------------------------------


const CoDept = () => {
    
    const {
        coCd,
        deptCd,
        setCoCd, // 회사코드 setter
        setDeptCd,
        setTheme
    } = useStore(); 


    const onChangeCo = val => {
        setCoCd(val);

        // 현재<=>기아 변경시 header 스타일 변경위해서...
        if(val !== 'ALL' ){
            setTheme(val === '01' ? 'hd' : 'kia') 
            window.location.reload(); 
        }
    };
    const onChangeDept = val => {
        setDeptCd(val);
    };


    // 그룹구분
    const paramsCo = {
        dlExpdGCd: '0001'
    };
    const coCombo = useQuery([API.codeCombo, paramsCo], () => getData(API.codeCombo, paramsCo), {
            select: data => [{label: CONSTANTS.labelAll, value: CONSTANTS.valueAll}].concat(data.filter(item => item.value !== '09'))
    });


    return (
        <>
            <Form.ControlLabel column="sm" >구분</Form.ControlLabel>
            <Row className="select-wrap">
                <Col> 
                    <SelectPicker size="sm" style={{width: '100%'}}
                        value={coCd} 
                        data={coCombo && coCombo.data ? coCombo.data : []} 
                        onChange={onChangeCo}
                        placeholder={CONSTANTS.labelAll}
                        cleanable={false}
                        searchable={false}
                        block={true}
                    />
                </Col>
            </Row>
            
        </>
    );

};
export default CoDept;