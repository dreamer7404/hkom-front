import React, {useState, useEffect} from 'react';
import { Row, Col } from 'react-bootstrap';
import { Form ,SelectPicker } from 'rsuite';
import { escapeCharChange} from '../../utils/commUtils';

//--------------  서버데이터용 필수 -------------------------------
import { useQuery} from 'react-query';
import { getData  } from '../../utils/async';
import { API, CONSTANTS } from '../../utils/constants';
import useStore from '../../utils/store';
//--------------// 서버데이터용 필수 -------------------------------

const LangForPop = ({onChangeLangParam, vehlParams, preLangParam}) => {

    const {keyword } = useStore(); 

    //최초 파라미터 세팅은 store에서 가져오는게 나을듯..
    const [dlExpdRegnCd, setDlExpdRegnCd] = useState(keyword.dlExpdRegnCd);
    const [langCd, setLangCd] = useState(keyword.langCd);

    //부모 컴포넌트에 던져줄 파라미터들..
    const paramForPop = {
        dlExpdRegnCd : dlExpdRegnCd,
        langCd : langCd
    }

    //부모 컴포넌트에 던져주기..
    useEffect(() => {
        //아래 함수는 부모 컴포넌트에서 만들어서 가져와야함..
        onChangeLangParam(paramForPop)
    }, [dlExpdRegnCd, langCd])

    const onChangeRegionCombo = val => {
        setDlExpdRegnCd(val);
    };
    const onChangeLangCombo = val => {
        setLangCd(val);
    }
    const onSelectLangCombo = (a,b,c) => {
        if(a === 'ALL'){
            // onChangeRegionCombo('ALL')
        } else {
            onChangeRegionCombo(b.dlExpdRegnCd);
        }
    }
    

    //다른 페이지에서 파라미터를 가져올 경우 시작 (ex. O/M발주상세 -> O/M발주등록 페이지)
    useEffect(() => {
        if(preLangParam && Object.keys(preLangParam).length > 0){
            setDlExpdRegnCd(preLangParam.dlExpdRegnCd)
            setLangCd(preLangParam.langCd)
        }
    }, [preLangParam])
    //다른 페이지에서 파라미터를 가져올 경우 끝 (ex. O/M발주상세 -> O/M발주등록 페이지)


    // regionCombo API가져오기
    const regionParams = {
        bDate: keyword.bDate && keyword.bDate.replace(/-/gi, ''), 
        dlExpdPdiCd: vehlParams.dlExpdPdiCd, 
        qltyVehlCd: vehlParams.qltyVehlCd, 
        mdlMdyCd: vehlParams.mdlMdyCd
    };
    const regionCombo = useQuery([API.regionCombo, regionParams], () => getData(API.regionCombo, regionParams), {
            select: data => [{label: CONSTANTS.labelAll, value: CONSTANTS.valueAll}].concat(data.map((item) => ({ label: item.dlExpdRegnNm, value: item.dlExpdRegnCd })))
    }); 

    // langCombo API가져오기
    const langParams = {
        bDate: keyword.bDate && keyword.bDate.replace(/-/gi, ''),
        // dlExpdPdiCd: vehlParams.dlExpdPdiCd, 
        // qltyVehlCd: vehlParams.qltyVehlCd, 
        // mdlMdyCd: vehlParams.mdlMdyCd,
        dlExpdPdiCd: vehlParams.dlExpdPdiCd?vehlParams.dlExpdPdiCd:'ALL', 
        qltyVehlCd: vehlParams.qltyVehlCd?vehlParams.qltyVehlCd:'ALL', 
        mdlMdyCd: vehlParams.mdlMdyCd?vehlParams.mdlMdyCd:'ALL', 
        dlExpdRegnCd: dlExpdRegnCd
    };
    const langCombo = useQuery([API.langCombo, langParams], () => getData(API.langCombo, langParams), {
        select: data => [{label: CONSTANTS.labelAll, value: CONSTANTS.valueAll}].concat(data.map((item) => ({ label: escapeCharChange(item.langCdNm), value: item.langCd, dlExpdRegnCd: item.dlExpdRegnCd })))
    }); 

    return (
        <>
            <Form.ControlLabel column="sm" >언어</Form.ControlLabel>
            <Row className="select-wrap">
                <Col sm={3}>
                    <SelectPicker size="sm"
                        value={dlExpdRegnCd} 
                        data={regionCombo && regionCombo.data ? regionCombo.data : []} 
                        onChange={onChangeRegionCombo}
                        placeholder={CONSTANTS.labelAll}
                        cleanable={false}
                        searchable={false}
                        block={true}
                    />
                </Col>
                <Col sm={9}>
                    <SelectPicker size="sm"
                        value={langCd} 
                        data={langCombo && langCombo.data ? langCombo.data : []}  
                        onChange={onChangeLangCombo}
                        onSelect={onSelectLangCombo}
                        placeholder={CONSTANTS.labelAll}
                        cleanable={false}
                        searchable={true}
                        block={true}
                    />
                </Col>
            </Row>
        </>
    );

};
export default LangForPop;