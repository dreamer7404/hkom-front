import React ,{useState} from 'react';
import { postData } from '../../../../utils/async';
import {Button, Table} from 'react-bootstrap';
import { Form, Schema} from 'rsuite';
import { useMutation} from 'react-query';
import { confirmAlert } from 'react-confirm-alert'; // Import
import ConfirmAlert from '../../../Common/ConfirmAlert';
import { API, CONSTANTS } from '../../../../utils/constants';
import { utcToLocalDate,escapeCharChange,checkUploadFileType,getApiUrl} from '../../../../utils/commUtils';
import { useEffect } from 'react';
import CustomModal from '../../../Common/CustomModal';
import { DEXT5Upload } from 'dext5upload-react';
 



const { StringType } = Schema.Types;
const model = Schema.Model({
    saleUnp: StringType().isRequired('평균단가를 입력해주세요'),
    
});
const PrintCost = ({data, files, show, onHide}) => {
    const formRef = React.useRef();
    
    const [formError, setFormError] = React.useState({});
    const [formValue, setFormValue] = React.useState({
        newPrntPbcnNo : data.newPrntPbcnNo, //차종코드
        rqQty : Math.floor(data.rqQty).toString(),
        saleUnp: Math.floor(data.saleUnp).toString(),
        prntParrBgt :Math.floor(data.prntParrBgt).toString(),
    });  
  //저장
    const saveData = () => {

       if(formValue.saleUnp=='0'||formValue.saleUnp==null){

        confirmAlert({
            closeOnClickOutside: false,
            customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}  msg={"평균 단가를 입력해 주세요"} />
        });
       }
       else{
        confirmAlert({
            closeOnClickOutside: false,
            customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}  msg={"입력하신 내용으로 저장하시겠습니까?"} onOk={onOk} />
        });
       }
        
    }


    const onOk = () => {
        DEXT5UPLOAD.Transfer();
        // bgtUpdate.mutate(formValue);
    }


    //차종코드 저장
    const bgtUpdate = useMutation((params => postData(API.savePrntBgt, params, CONSTANTS.update)),{
        onSuccess: res => {
            console.log("res : ",res);
            if(res>0){
                confirmAlert({
                    closeOnClickOutside: false,
                    customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}  title={"알림"} msg={"저장이 완료되었습니다."}  />
                })
                
                onHide(true); 
            }else{
                confirmAlert({
                    closeOnClickOutside: false,
                    customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}  title={"알림"} msg={"저장이 실패되었습니다."}  />
                })
            }
        }
    });

    //소요예산 자동계산
    const onChangeEvent = val => {
        setFormValue(p=>({...p,
            prntParrBgt : val * data.rqQty
        }))
    }

    // 파일업로드 완료후 데이타저장
    const [fileInfo, setFileInfo] = useState(null);
    useEffect(()=> {
        if(fileInfo){

            const param = formValue;
            
            param.attcYn = DEXT5UPLOAD.GetTotalFileCount() > 0 ? 'Y' : 'N'; // 파일첨부 여부

            // 추가된 파일들
            if(fileInfo.newFile){
                // newFile
                param.attcSn = fileInfo.newFile.uploadPath; // tb_attc_mgmt의 attcSn
                param.size = fileInfo.newFile.size;
                param.extension = fileInfo.newFile.extension;
                param.originalName = fileInfo.newFile.originalName;
            }

            // 삭제된 파일들
            const deletedList = DEXT5UPLOAD.GetDeleteListForJson("dext5upload1");
            if(deletedList){
                param.attcSnDeleted = deletedList.customValue;
            }

            // 저장
            bgtUpdate.mutate(param);
        }
    },[fileInfo]);

    // 파일업로드후 리턴값
    const onTransferComplete = e => {
        const fileList = DEXT5UPLOAD.GetAllFileListForJson("dext5upload1");
        setFileInfo(fileList || {})
    }

    // 파일추가 전 처리할 내용
    const onBeforeAddItem = e => {
        if(!checkUploadFileType(e.eventInfo.paramObj)){
            confirmAlert({
                closeOnClickOutside: false,
                customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}  title={"알림"} msg={"업로드 할 수 없는 파일형식 입니다."}  />
            });
            return false;
        }
        return true;
    }
    // 기존업로드된 파일리스트 (수정화면에서 사용)
    const onCreationComplete = e => {
        // DEXT5UPLOAD.AddHttpHeaderEx('x-auth-token', 'token', "dext5upload1");
        if(files){
            for(let i=0; i<files.length; i++){
                DEXT5UPLOAD.AddUploadedFile(''+(i+1), escapeCharChange(files[i].fileNm), '', files[i].fileSize, files[i].attcSn, 'dext5upload1');
            }
        }
    }
     // 파일업로드 시작시 사용자 데이타추가
     const onTransferStart = e => {
        DEXT5UPLOAD.AddFormData("gubun", "P", "dext5upload1"); //P:견적서첨부
    }

    const mutateDownload = useMutation((params => postData(API.fileUploadHistory, params, CONSTANTS.insert)));
    const [attcSnList, setAttcSnList] = useState();

    const onFinishDownloaded = e => {
        console.log('e', e)
        // mutateDownload.mudate({
        //     useType: '06',
        //     filGbn: 'P',
        //     attcSn: attcSnList,
        //     pgmId: API.printState,
        // });
    };
    const onSelectItem = (e1, e2) => {
        console.log('e1', e1)
        console.log('e2', e2)
        // setAttcSnList(e1) //..............here.

    }



    return (
        <>
             <Form ref={formRef}
                checkTrigger="change"
                onChange={setFormValue}
                onCheck={setFormError}
                formValue={formValue}
                model={model}>
                  
                  {/* <CustomModal open={show} 
                        title={'인쇄비 입력'}
                        size='md'
                        // handleOk={handleSubmit}
                        handleCancel={onHide} >
                         */}

                <CustomModal open={show} 
                        title={'인쇄비 입력'}
                        size='lg'
                        handleCancel={onHide} 
                        >
                            <Table className="tbl-hor" bordered>
                                <colgroup>
                                    <col style={{width:'30%'}}></col>
                                    <col style={{width:''}}></col>
                                </colgroup>
                                <tbody>
                                    <tr>
                                        <th>인쇄부수</th>
                                        <td>{data.rqQty}</td>
                                    </tr>
                                    <tr>
                                        <th className="essen">평균단가</th>
                                        <td>
                                            <Form.Control size="sm" type="text" placeholder="평균단가"  name='saleUnp'  onChange={onChangeEvent} />
                                        </td>
                                    </tr>
                                    <tr>
                                        <th>소요예산</th>
                                        <td>
                                            <Form.Control size="sm" type="text" readOnly placeholder="0" name = 'prntParrBgt' />
                                        </td>
                                    </tr>
                                    <tr>
                                        <th>견적서</th>
                                        <td>
                                        <DEXT5Upload
                                                onCreationComplete={onCreationComplete}
                                                onTransferStart={onTransferStart}
                                                onTransferComplete={onTransferComplete}
                                                onBeforeAddItem={onBeforeAddItem}
                                                onFinishDownloaded={onFinishDownloaded}
                                                onSelectItem={onSelectItem}
                                                debug={false}
                                                id="dext5upload1"
                                                mode='edit' 
                                                runtimes='html5'
                                                componentUrl="/dext5upload/js/dext5upload.js"
                                                config={{MaxTotalFileSize:'100MB', MaxOneFileSize:'30MB', DevelopLangage:'NONE',Width:'100%',
                                                    ButtonBarEdit: "add,remove,download",
                                                    HandlerUrl:  getApiUrl() + 'dext5upload', 
                                                    DownloadHandlerUrl: getApiUrl() + 'dext5upload',
                                                }}
                                                
                                            />
                                        </td>
                                    </tr>
                                </tbody>
                            </Table>

                        <div className='modal-footer'>
                            <Button variant="light" size="md" onClick={onHide}>취소</Button>
                            <Button variant="primary" size="md" onClick={() => saveData()}>저장</Button>
                        </div>
                </CustomModal>
            </Form>
        </>
    );

};
export default PrintCost;