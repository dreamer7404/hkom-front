import React from 'react';
import { postData } from '../../../../utils/async';
import {Button, Table} from 'react-bootstrap';
import { Form, Schema } from 'rsuite';
import { useMutation} from 'react-query';
import { confirmAlert } from 'react-confirm-alert'; // Import
import ConfirmAlert from '../../../Common/ConfirmAlert';
import { API, CONSTANTS } from '../../../../utils/constants';

import CustomModal from '../../../Common/CustomModal';
const { StringType } = Schema.Types;

const PrintCostInputNo = ({data, show, onHide}) => {
    const formRef = React.useRef();
    
    const [formError, setFormError] = React.useState({});
    const [formValue, setFormValue] = React.useState({
        newPrntPbcnNo : data.newPrntPbcnNo, //신규발간번호
        prtlImtrSbc3 : data.prtlImtrSbc3
        
    });
    const saveData = () => {
        console.log('formValue',formValue);
        if(formValue.prtlImtrSbc3==""||formValue.prtlImtrSbc3==null){
            confirmAlert({
                closeOnClickOutside: false,
                customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}  msg={"인쇄비 품의 번호를 입력해주세요"}/>
            });
        }
        else{
            confirmAlert({
                closeOnClickOutside: false,
                customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}  msg={"입력하신 내용으로 저장하시겠습니까?"} onOk={onOk} />
            });
        }
        
    }


    const onOk = () => {
     
            savePrintCostInputNo.mutate(formValue);
        
    }

    const savePrintCostInputNo = useMutation((params => 
        
        postData(API.savePrintCostInputNo, params, CONSTANTS.update)),{
            
        onSuccess: res => {
            
            if(res>0){
                confirmAlert({
                    closeOnClickOutside: false,
                    customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}   title={"알림"} 
                    msg={" 저장이 완료되었습니다."}   />
                 });    
                onHide(true); // 창닫기 & refetch
            }else{
                
                 confirmAlert({
                    closeOnClickOutside: false,
                    customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}   title={"알림"} 
                    msg={" 에러가 발생했습니다.<br />관리자에게 문의해주세요."}  />
                 });   
            }
        }
    });

     //인쇄비 품의번호
const onChangeEvent = val => {

    setFormValue(p=>({...p,
        prtlImtrSbc3 : val 
    }))
}
    return (
        <>
              <Form ref={formRef}
                checkTrigger="change"
                onChange={setFormValue}
                onCheck={setFormError}
                formValue={formValue}
                >
               
                               
                <CustomModal open={show} 
                        title={'인쇄비 품의번호 입력'}
                        size='md'
                        // handleOk={handleSubmit}
                        handleCancel={onHide} >
                        
                            <Table className="tbl-hor" bordered>
                                <colgroup>
                                    <col style={{width:'35%'}}></col>
                                    <col style={{width:''}}></col>
                                </colgroup>
                                <tbody>
                                    <tr>
                                        <th className="essen">인쇄비 품의번호</th>
                                        <td>
                                            <Form.Control name = 'prtlImtrSbc3'size="sm" type="text" placeholder="인쇄비 품의번호"onChange={onChangeEvent}  />
                                        </td>
                                    </tr>
                                </tbody>
                            </Table>
                        
                            <div className='modal-footer'>
                            <Button variant="light" size="md" onClick={onHide}>취소</Button>
                            <Button variant="primary" size="md"onClick={() => saveData()}>저장</Button>
                        </div>
                </CustomModal>
            </Form>
        </>
    );

};
export default PrintCostInputNo;