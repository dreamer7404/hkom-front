import React, { useEffect, useMemo, useRef } from 'react';
import { Form } from 'rsuite';
import { AgGridReact } from 'ag-grid-react';
import { CONSTANTS } from '../../../../utils/constants';
import { formatNumber, escapeCharChangeForGrid } from '../../../../utils/commUtils';

const GridPrintOrderAdd = ({ filterValue, queryResult, limit, activePage, onCellClicked }) => {

  const gridRef = useRef();
  // 수량 천단위 콤마 찍기 시작
  const currencyFormatter = (params) => {
    return formatNumber(params.value);
  };
  
  //aggrid 재고상태
  const statusComonent = (props) => {

    if (props.value === "OK") {
      return (
        <div className="status-title status-1">
          {props.value}
        </div>
      )
    } else if (props.value === "준비") {
      return (
        <div className="status-title status-2">
          {props.value}
        </div>
      )
    } else if (props.value === "발주필요") {
      return (
        <div className="status-title status-3">
          {props.value}
        </div>
      )
    } else {
      return (
        <div className="status-title status-4" style={{ cursor: 'pointer' }}>
          {props.value}
        </div>
      )
    }

  }

  const columnDefs = [
    {
      headerName: '월평균\n수출오더',
      field: 'mth3AvgCurrOrdQty',
      spanHeaderHeight: true,
      valueFormatter: currencyFormatter
    },
    {
      headerName: '수출오더\n(당월)',
      field: 'currOrdQty',
      spanHeaderHeight: true,
      valueFormatter: currencyFormatter
    },
    {
      headerName: '월평균 생산량',
      field: 'mth3TrwiQty',
      spanHeaderHeight: true,

    },
    {
      headerName: '생산계획\n(2주)',
      field: 'wek2PlanQty',
      spanHeaderHeight: true,
      // cellStyle: () => ({textDecoration: 'underline', cursor: 'pointer', color:'#2589f5'}),
      valueFormatter: currencyFormatter
    },
    {
      headerName: '단기계획\n(3일)',
      field: 'day3PlanQty',
      spanHeaderHeight: true,
      // cellStyle: () => ({textDecoration: 'underline', cursor: 'pointer', color:'#2589f5'}),
      valueFormatter: currencyFormatter
    },
    {
      headerName: '당월투입\n(누적)',
      field: 'currMthTrwiQty',
      spanHeaderHeight: true,
      // cellStyle: () => ({textDecoration: 'underline', cursor: 'pointer', color:'#2589f5'}),
      valueFormatter: currencyFormatter
    },
    {
      headerName: '전일투입\n(D-1)',
      field: 'prev1DayTrwiQty',
      spanHeaderHeight: true,
      valueFormatter: currencyFormatter
    },
    {
      headerName: '재고현황',
      children: [
        {
          headerName: '세원',
          children: [
            {
              headerName: '인쇄중', field: 'prntQty', cellRenderer: "LinkComponent",
              // cellStyle: () => ({textDecoration: 'underline', cursor: 'pointer', color:'#2589f5'}) 
            },
            {
              headerName: '보유재고', field: 'sewhaIvQty', cellRenderer: "LinkComponent",
              //  cellStyle: () => ({textDecoration: 'underline', cursor: 'pointer', color:'#2589f5'})
            },
          ],
        },
        {
          headerName: 'PDI/용산', field: 'pdiIvQty', spanHeaderHeight: true, cellRenderer: "LinkComponent",
          //  cellStyle: () => ({textDecoration: 'underline', cursor: 'pointer', color:'#2589f5'})
        },
        { headerName: '합계', field: 'ivSum', spanHeaderHeight: true },
      ],
    },
    {
      headerName: '예상재고\n(2주)',
      field: 'wek2AftrIvQty',
      spanHeaderHeight: true,
      valueFormatter: currencyFormatter
    },
    {
      headerName: '재고상태',
      field: 'prntStateNm',
      spanHeaderHeight: true,
      cellRenderer: statusComonent
    }
  ];

  const defaultColDef = useMemo(() => {
    return {
      initialWidth: 90,
      sortable: true,
      resizable: true,
      minWidth: 70
    };
  }, []);

  const onFirstDataRendered = (params) => {
    params.api.sizeColumnsToFit();
  };

  useEffect(() => {
    if (queryResult.status === 'loading' && gridRef && gridRef.current && gridRef.current.api) {
      gridRef.current.api.showLoadingOverlay();
    }
  }, [queryResult]);

  useEffect(() => {
    if (gridRef && gridRef.current && gridRef.current.api) {
      gridRef.current.api.setQuickFilter(filterValue);
    }
  }, [filterValue]);

  useEffect(() => {
    if (gridRef && gridRef.current && gridRef.current.api) {
      gridRef.current.api.paginationGoToPage(activePage - 1);
    }
  }, [activePage]);


  return (
    <Form>
      <div className="ag-theme-alpine" style={{ height: 160.5, transition: 'all ease .3s' }}>
        <AgGridReact
          ref={gridRef}
          rowData={queryResult.data}
          columnDefs={columnDefs}
          defaultColDef={defaultColDef}

          // paging
          pagination={true}
          paginationPageSize={limit} //
          suppressPaginationPanel={true}
          // onPaginationChanged={onPaginationChanged}

          //  filter
          cacheQuickFilter={true}

          // overlay
          overlayLoadingTemplate={CONSTANTS.gridLoading}
          overlayNoRowsTemplate={'<div style="padding-top:90px;"><span style="padding: 10px; border: 1px solid #ccc;">금일 기준 데이터가 없습니다.</span></div>'}

          frameworkComponents={{
            statusComonent,
            escapeCharChangeForGrid
          }}

          // click column
          onCellClicked={onCellClicked} //

          onFirstDataRendered={onFirstDataRendered}
          suppressSizeToFit={true}
          onGridSizeChanged={onFirstDataRendered}
        >
        </AgGridReact>

      </div>
    </Form>
  )


};
export default GridPrintOrderAdd;