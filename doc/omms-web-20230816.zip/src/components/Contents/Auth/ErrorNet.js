// react
import React from 'react';
import {Button, Card } from "react-bootstrap";
import {Form} from 'rsuite';
import RemindOutlineIcon from '@rsuite/icons/RemindOutline';
import { useNavigate } from 'react-router-dom';
import useStore from '../../../utils/store';
const ErrorPage = () => {
    const navigate = useNavigate();
    const {loginUrl } = useStore();
    const goLogin = () => {
        navigate(loginUrl ? loginUrl : '/login')
    }
    return (
        <>
           <div className="error-wrap">
                <Form>
                    <Card className="shadow">
                        <Card.Body>
                            <RemindOutlineIcon />
                            <h4>
                                <p className="error-type">Error Connection</p>
                                서버에서 응답이 없습니다.
                            </h4>
                            <div className="button-wrap">
                                <Button variant="secondary" onClick={goLogin}>로그인</Button>
                            </div>
                        </Card.Body>
                    </Card>
                </Form>
           </div>
        </>
    )
};
export default ErrorPage;