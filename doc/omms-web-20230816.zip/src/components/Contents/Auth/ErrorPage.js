/* eslint-disable react-hooks/exhaustive-deps */
// react
import React, { useEffect } from 'react';
import {Button, Card } from "react-bootstrap";
import {Form} from 'rsuite';
import RemindOutlineIcon from '@rsuite/icons/RemindOutline';
import { Link, useNavigate } from 'react-router-dom';
import useStore from '../../../utils/store';

const ErrorPage = () => {

    const navigate = useNavigate();

    const { svrErrCd, svrErrMsg, loginUrl } = useStore();
    const goLogin = () => {
        navigate(loginUrl ? loginUrl : '/login')
    }

    return (
        <>
           <div className="error-wrap">
                <Form>
                    <Card className="shadow">
                        <Card.Body>
                            <RemindOutlineIcon />
                            <h4>
                                <p className="error-type">권한오류</p>
                                {/* {Number(svrErrCd) === 2 && <span>다른브라우저에서 정보를 요청했습니다.(<span style={{color: 'gray'}}>{svrErrMsg}</span>)</span>} */}
                                {Number(svrErrCd) === 2 && <span>다른브라우저에서 정보를 요청했습니다.</span>}
                                {Number(svrErrCd) === 3 && <span>장시간 사용하지 않아 연결이 종료되었습니다.</span>}
                                {Number(svrErrCd) === 4 && <span>토큰정보가 유효하지 않습니다.</span>}
                                {/* {Number(svrErrCd) === 5 && '토큰정보가 없거나 만료되었습니다.'} */}
                                {Number(svrErrCd) === 6 && <span>사용권한이 없는 요청으로 연결이 종료되었습니다.(<span style={{color: 'gray'}}>{svrErrMsg}</span>)</span>}
                            </h4>
                            <div className="button-wrap">
                                <Button variant="secondary" onClick={goLogin}>로그인</Button>
                            </div>
                        </Card.Body>
                    </Card>
                </Form>
           </div>
        </>
    )
};
export default ErrorPage;