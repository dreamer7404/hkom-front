/* eslint-disable react-hooks/exhaustive-deps */
/* eslint-disable jsx-a11y/alt-text */
// react
import React, { useEffect, useState } from 'react';
import { Button, Card } from "react-bootstrap";
import { Schema, Form } from 'rsuite';
import { useNavigate, Link } from 'react-router-dom';
import useStore, { useStoreAuth } from '../../../utils/store';
import { getCoNmByPath } from '../../../utils/commUtils';

//--------------  서버데이터용 필수 -------------------------------
import { useMutation } from 'react-query';
import { postAuth } from '../../../utils/async';
import { API, CONSTANTS } from '../../../utils/constants';
import FindPw from './Popup/FindPw';
//--------------// 서버데이터용 필수 -------------------------------
import { confirmAlert } from 'react-confirm-alert';
import ConfirmAlert from '../../Common/ConfirmAlert';

import moment from 'moment';


if (getCoNmByPath() === 'hd') import(`../../../styles/theme_hd.css`);
else import(`../../../styles/theme_kia.css`);


const { StringType } = Schema.Types;
const model = Schema.Model({
    userEeno: StringType().isRequired('아이디를 입력해주세요.'),
    // .pattern(/^[a-zA-Z0-9]*$/, '영문자,숫자로 입력해주세요')
    // .rangeLength(7, 20, '7-20자로 입력해주세요'),
    userPw: StringType().isRequired('비밀번호를 입력해주세요.')
    // .pattern(/^(?=.*[A-Za-z])(?=.*\d)(?=.*[$@$!%*#?&])[A-Za-z\d$@$!%*#?&]{7,}$/, 
    //     '최소 7자리이며, 숫자,문자,특수문자는 최소1개이상 입력해주세요')
    // .rangeLength(7, 20, '7-20자로 입력해주세요'),
});

const Login = () => {

    const [isPartner, setIsPartner] = useState(false);
    const [logo, setLogo] = useState('');
    const { resetUser, setBDate, setSMonth, setSDate, setEDate, setEMonth, setDlExpdPdiCd, setQltyVehlCd, setMdlMdyCd, setDlExpdRegnCd, setLangCd} = useStore();
    const navigate = useNavigate();

    // Form 정의
    const formRef = React.useRef();
    const [formError, setFormError] = React.useState({});
    const [formValue, setFormValue] = React.useState({
        userEeno: '',
        userPw: '',
        blnsCoCd: '',
    });

    useEffect(() => {
        // store 삭제
        // localStorage.removeItem('omms');

        // 파트너인가?
        // console.log('partner', window.location.pathname.indexOf('/partner'))
        const part = window.location.pathname.indexOf('/partner') > -1 ? true : false;
        setIsPartner(part);

        // URL 회사코드 가져오기
        const coNm = getCoNmByPath();

        // 로고
        setLogo(coNm);

        // 회사코드 store저장
        setFormValue(p => ({ ...p, blnsCoCd: coNm === 'hd' ? '01' : '02' }))

        // clear store  
        resetUser({
            token: '',
            browserId: '',
            grpCd: '',
            coCd: '',
            theme: '',
            userDcd: '',
            userOsetLgi: '',
            pwChangeYn: '',
        });


        
    }, [])


    // login
    const usrmgmtMutate = useMutation((params => postAuth(API.login, params, CONSTANTS.update)), {
        onSuccess: rv => {
            if (rv.result === 1) {
                // 사용자정보 세팅
                resetUser({
                    token: rv.data.token,
                    browserId: rv.data.browserId,
                    grpCd: rv.data.grpCd,
                    coCd: rv.data.blnsCoCd, // 회사코드 => sysadm 일경우, hd/kia둘다 되므로, 현재 로그인한 url로 정한다.
                    theme: rv.data.blnsCoCd === '01' ? 'hd' : 'kia',
                    deptCd: rv.data.userDcd,
                    loginUrl: window.location.pathname,
                    userOsetLgi: rv.data.userOsetLgi,
                    pwChangeYn : rv.data.pwChangeYn,
                    api: rv.data.apiList
                });
                // 날짜초기화
                const today = moment(new Date()).format("YYYY-MM-DD")
                setBDate(today); // 오늘기준
                setSDate(moment(new Date()).startOf('month').format("YYYY-MM-DD"));
                setEDate(today); // 오늘기준
                setSMonth(moment(new Date()).subtract(13, 'months').format('YYYY-MM-DD')); // 시작월(종료월 -13개월)
                setEMonth(today);
                setDlExpdPdiCd('ALL')
                setQltyVehlCd('ALL')
                // setMdlMdyCd(moment(new Date()).format("YY"))
                setMdlMdyCd('ALL') //현업 요청에 의한 변경 (20230802 - 안우석 매니저/글로벌서비스기술정보팀 (티켓번호:HKOMMS-149))
                setDlExpdRegnCd('ALL')
                setLangCd('ALL')

                navigate('/totalStock');
            } else {
                let message = '';
                if (Number(rv.result) === -1 || Number(rv.result) === -3 || Number(rv.result) === -2) message = '입력하신 아이디 또는 비밀번호가 일치하지 않습니다.\n확인 후 재입력 해주세요.';
                // else if(rv.result === -2) message = '비밀번호 5회오류가 발생했습니다.\n1시간동안 사용할수 없습니다';
                else if(Number(rv.result) === -7) {
                    let coName = '';
                    let coName2 = '';
                    let coLink2 = '';

                    if(getCoNmByPath() === 'hd'){
                        coName = '현대자동차';
                        coName2 = '기아자동차';
                        coLink2 =  isPartner ? process.env.REACT_APP_KIA_URL + '/partner' : process.env.REACT_APP_KIA_URL;
                       
                    }else{
                        coName = '기아자동차';
                        coName2 = '현대자동차';
                        coLink2 = isPartner ? process.env.REACT_APP_HMC_URL + '/partner' : process.env.REACT_APP_HMC_URL;
                    }
                    message = coName + ' 로그인 화면입니다.<br />' + coName2 + ' 사용자는 다음의 URL로 접속하시기 바랍니다.<br /><a href="' +  coLink2 + '">'+ coLink2 + '</a>';
                }
                else if (Number(rv.result) === -4) message = '입력하신 아이디는 사용중지중입니다.<br />관리자에게 문의해주세요.';
                else if (Number(rv.result) === -5) message = '입력하신 아이디는 1시간동안 사용중지 상태입니다';
                else message = '로그인 오류입니다.(' + rv.result + ')';

                confirmAlert({
                    closeOnClickOutside: false,
                    customUI: ({ onClose }) => <ConfirmAlert onClose={onClose} title={"알림"} msg={message} />
                });
            }
        }
    });
    const onKeyUp = e => {
        return e.keyCode === 13 ? (handleSubmit()) : null
    }
    const handleSubmit = () => {
        if (!formRef.current.check()) {
            return;
        }
        if (!formValue.blnsCoCd) {
            confirmAlert({
                closeOnClickOutside: false,
                customUI: ({ onClose }) => <ConfirmAlert onClose={onClose} title={"알림"} msg={'접속경로가 잘못되었습니다.'} />
            });
            return;
        }

        usrmgmtMutate.mutate(formValue);
    }

    // 비번찾기 띄우기
    const [show, setShow] = React.useState(false);
    const onClose = () => {
        setShow(false);
    }

    if (!logo) return;

    return (
        <>
            <div className="login-wrap">
                <Form
                    ref={formRef}
                    checkTrigger="none"
                    onChange={setFormValue}
                    onCheck={setFormError}
                    formValue={formValue}
                    model={model}>

                    <h4>Owner's Mannual <span>Management System</span></h4>
                    <Card className="shadow">
                        <Card.Body>
                            <div className="">

                                <div className="login-top">
                                    {!isPartner && <img className="comLogo" src={"../images/" + logo + "_logo_color.png"}></img>}
                                    {isPartner && <p style={{ textAlign: 'center', fontSize: '14px', marginBottom: '0', fontWeight: '600' }}>협력업체</p>}
                                </div>
                                <div className="login-body">
                                    <Form.Group className="mb-3" controlId="formBasicEmail">
                                        <Form.ControlLabel>아이디</Form.ControlLabel>
                                        <Form.Control type="text" placeholder="User ID" name="userEeno" />
                                    </Form.Group>

                                    <Form.Group className="mb-1" controlId="formBasicPassword">
                                        <Form.ControlLabel>비밀번호</Form.ControlLabel>
                                        <Form.Control type="password" placeholder="Password" name="userPw" onKeyUp={onKeyUp} />
                                    </Form.Group>
                                    <Form.Group className="mb-3" controlId="formBasicCheckbox">
                                        <p className="small">
                                            <Link className="text-secondary" onClick={() => setShow(true)}> 비밀번호찾기</Link>
                                        </p>
                                    </Form.Group>
                                    <div className={"login-footer-" + logo}>
                                        <Button variant="primary" size="lg" onClick={handleSubmit}>로그인</Button>
                                    </div>
                                </div>
                            </div>
                        </Card.Body>
                    </Card>

                </Form>
            </div>
            <FindPw show={show} onClose={onClose} />
        </>
    )
};
export default Login;