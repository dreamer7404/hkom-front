import React,{useState, useEffect} from 'react';
import {Tab,Tabs} from 'react-bootstrap';
import { isApi } from '../../../../utils/commUtils';
import { API } from '../../../../utils/constants';
import VehlLangList from './VehlLangList';
import LangMast from './LangMast';

const LangCodeContainer = () => {

    const [leftWidth, setLeftWidth] = useState('150px')
   
    useEffect(() => {
        const getTitle = document.getElementById('section-title-width');
        const titleWidth = getTitle.clientWidth + 40;
        setLeftWidth(titleWidth)
    }, []);

    return (
        <>
            <Tabs  defaultActiveKey="tab1" style={{left: leftWidth}} >
                {isApi(API.langMgmts, 'GET') &&<Tab eventKey="tab1" title={"차종별 언어관리"}>
                    <VehlLangList />
                </Tab>}
                {isApi(API.langMsts, 'GET') &&<Tab eventKey="tab2" title="언어마스터">
                    <LangMast />
                </Tab>}
            </Tabs>
        </>
    );

};
export default LangCodeContainer;