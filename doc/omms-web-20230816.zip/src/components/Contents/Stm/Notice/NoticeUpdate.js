// react
import React, {useState, useMemo, useEffect,useRef} from 'react';
import { AgGridReact } from 'ag-grid-react';
import {Button, Table} from 'react-bootstrap';
import {Form, SelectPicker, InputGroup, DatePicker, Schema} from 'rsuite';
import { CONSTANTS,API } from '../../../../utils/constants';
import { useQuery,useMutation} from 'react-query';
import { getData, postData } from '../../../../utils/async';
import { utcToLocalDate } from '../../../../utils/commUtils'; //'../../../utils/commUtils';
import useStore from '../../../../utils/store';
import { useNavigate  } from 'react-router-dom';
import { useLocation } from 'react-router';
import { confirmAlert } from 'react-confirm-alert'; // Import
import ConfirmAlert from '../../../Common/ConfirmAlert';
import qs from 'qs';
import { changeCharToEscape, escapeCharChange, checkUploadFileType, getApiUrl, unescapeHtml} from '../../../../utils/commUtils';
import moment from 'moment';


import { DEXT5Editor } from 'dext5editor-react';
import { DEXT5Upload } from 'dext5upload-react';

const { StringType} = Schema.Types;
const model = Schema.Model({
    // qltyVehlCd: StringType().isRequired('차종코드를 선택해 주세요.'),
    affrScnCd: StringType().isRequired('업무구분을 선택해주세요.'),
    blcTitlNm: StringType().isRequired('게시물 제목을 입력해주세요.'),
    // blcSbc: StringType().isRequired('게시물 내용을 입력해주세요.'),
    
});
const NoticeUpdate = () => {
    const gridRef = useRef();
    const navigate = useNavigate();
    const location = useLocation();
    const [query, setQuery] = useState(
        qs.parse(location.state, { ignoreQueryPrefix: true }),
    )
    const {keyword} = useStore(); 
    const [bulYn, setbulYn] = useState('N');
    const [affrScnCd,setAffrScnCd] = useState('');
    const [bulDate , setBulDate] = useState({
        sDate : '',
        eDate : ''
    })
    const formRef = useRef();
    const [formError, setFormError] = useState({});
    const [formValue, setFormValue] = useState({
        bulYn : 'N',                 //게시여부
        affrScnCd : '',             //업무구분
        blcTitlNm : '',             // 게시물제목
        // blcSbc:'',                  // 게시내용
        bulStrtYmd : new Date(),     // 게시시작일자
        bulFnhYmd : new Date(),      // 게시종료일자
        usrList  :[],
        blcSn : query.blcSn
    }); 

    const [files, setFiles] = useState([])

    const queryResult = useQuery([API.boardMgmt, query], () => getData(API.boardMgmt, query));

    useEffect(()=>{

        if(queryResult.isSuccess && queryResult.data){
            let dataInfo = queryResult.data.boardInfo
            console.log("dataInfo",dataInfo)
            setFormValue(p => ({...p, 
                bulYn : dataInfo.bulYn,                 //게시여부
                affrScnCd : dataInfo.affrScnCd,             //업무구분
                blcTitlNm : dataInfo.blcTitlNm,             // 게시물제목
                // blcSbc  :   dataInfo.blcSbc,                  // 게시내용
                bulStrtYmd : dataInfo.bulStrtYmd,     // 게시시작일자
                bulFnhYmd : dataInfo.bulFnhYmd,      // 게시종료일자
                usrList  :  [],
                blcSn : dataInfo.blcSn
            }));
            setBulDate({
                sDate : dataInfo.bulStrtYmd,
                eDate : dataInfo.bulFnhYmd
            })

             // 내용
             setTimeout(() => DEXT5.setBodyValue(unescapeHtml(dataInfo.blcSbc), 'editor1'), 500);

            // 파일
            setFiles(queryResult.data.files);
        }

    },[queryResult.status])


    const onOk = () => {
        // if(DEXT5UPLOAD.GetTotalFileCount() > 0){
            DEXT5UPLOAD.Transfer();
        // }else{
        //     const updateParam = formValue;
        //     updateParam.blcSbc = DEXT5.getBodyValue();
        //     updateParam.attcYn = 'N';
        //     noticeSave.mutate(updateParam);
        // }
    }

    const handleSubmit = () => {

    
        // if (!formRef.current.check()) { //validation chk
        //     return;
        // }

        // const textValue = DEXT5.getBodyTextValue();
        // if(textValue.length === 0){
        //     confirmAlert({
        //         closeOnClickOutside: false,
        //         customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}  title={"알림"} msg={"내용을 입력해주세요."}  />
        //     })
        //     return;
        // }

        confirmAlert({
            closeOnClickOutside: false,
            customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}   title={"알림"} msg={"입력하신 내용으로 저장하시겠습니까?"} onOk={onOk}  />
        });
        
    };
    const noticeSave = useMutation((params => postData(API.boardMgmt, params, CONSTANTS.update)),{
        onSuccess: res => {
           if(res>0){
                confirmAlert({
                    closeOnClickOutside: false,
                    customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}   title={"알림"}
                    msg={"저장이 완료되었습니다."}   />
                   
                });
                queryResult.remove();
           
           }else{
                confirmAlert({
                    closeOnClickOutside: false,
                    customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}   title={"알림"}
                    msg={"에러가 발생했습니다 관리자에게 문의해주세요."}   />
                    
                });
           }
           navigate('/notice',{ state: '' });   
        }
    });


    const columnDefs = [
        {
          checkboxSelection: true,
          headerCheckboxSelection: true,
          width:35,
          maxWidth:35,
          minWidth:35,
          sortable:false
        },
        {
          headerName: '회사명',
          field: 'coNm',
        },
        {
          headerName: '부서명',
          field: 'deptNm',
        },
        {
          headerName: '아이디',
          field: 'userEeno',
        },
        {
          headerName: '이름',
          field: 'userNm',
        },
    ]


    const defaultColDef = useMemo(() => {
        return {
            initialWidth: 90,
            sortable: true,
            minWidth:70
        };
    }, []);

 //changeEvent
 const bulYnChangeEvent = (e)=>{
    setbulYn(e)
}

const scnCdChangeEvent = (e)=>{
    setAffrScnCd(e);
}

    const onChangeDateStart = (val) => {
        setBulDate(p=>({...p,sDate : utcToLocalDate(val)}))
        setFormValue(p=>({...p,bulStrtYmd : utcToLocalDate(val)}))
    }

    const onChangeDateEnd = (val) => {
        setBulDate(p=>({...p,sEate : utcToLocalDate(val)}))
        setFormValue(p=>({...p,bulFnhYmd : utcToLocalDate(val)}))
    }
    const onFirstDataRendered = (params) => {
        params.api.sizeColumnsToFit();
        const selectedRows = gridRef.current.api.getSelectedRows();
        gridRef.current.api.forEachNode((node) =>
             node.setSelected(!!node.data && node.data.chkYn === 'Y')
        );
        setFormValue(p => ({...p, usrList: selectedRows}));
    };

    const onSelectionChanged = ()=>{
        const selectedRows = gridRef.current.api.getSelectedRows();
        setFormValue(p => ({...p, usrList: selectedRows}));
    }

    const listButton = () => {
        navigate('/notice',{ state: '' }); 
    }

    // 파일업로드 완료후 데이타저장
    const [fileInfo, setFileInfo] = useState(null);
    useEffect(()=> {
        if(fileInfo){
            if (!formRef.current.check()) { //validation chk
                return;
            }

            const textValue = DEXT5.getBodyTextValue();
            if(textValue.length === 0){
                confirmAlert({
                    closeOnClickOutside: false,
                    customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}  title={"알림"} msg={"내용을 입력해주세요."}  />
                })
                return;
            }

            const updateParam = formValue;
            updateParam.attcYn = DEXT5UPLOAD.GetTotalFileCount() > 0 ? 'Y' : 'N'
            updateParam.blcSbc = DEXT5.getBodyValue();

            // 추가된 파일들
            if(fileInfo.newFile){
                // newFile
                updateParam.attcSn = fileInfo.newFile.uploadPath; // tb_attc_mgmt의 attcSn
                updateParam.size = fileInfo.newFile.size;
                updateParam.extension = fileInfo.newFile.extension;
                updateParam.originalName = fileInfo.newFile.originalName;

            }

            // 삭제된 파일들
            const deletedList = DEXT5UPLOAD.GetDeleteListForJson("dext5upload1");
            if(deletedList){
                updateParam.attcSnDeleted = deletedList.customValue;
            }
            
            // console.log('fileInfo', fileInfo);
            // console.log('formValue', formValue);
            // const updateParam = formValue;
            // updateParam.attcYn = 'Y';
            // updateParam.blcSbc = DEXT5.getBodyValue();
            // updateParam.attcSn = fileInfo.newFile.uploadPath;           // tb_attc_mgmt의 attcSn
            // updateParam.size = fileInfo.newFile.size;                   // 파일 크기
            // updateParam.extension = fileInfo.newFile.extension;         // 파일 확장자
            // updateParam.originalName = fileInfo.newFile.originalName;   // 파일 이름
            // updateParam.attcSnOld  = fileInfo.webFile.customValue; // 기존파일 attc_sn 배열
            noticeSave.mutate(updateParam);


        }
    },[fileInfo]);

    // DEXT5UPLOAD component 로드 지연
    const [showLoad, setShowLoad ] = useState(false)
    useEffect(() => {
        setTimeout(() => setShowLoad(true), 500);
    },[]);

    // 기존업로드된 파일리스트 (수정화면에서 사용)
    const onCreationComplete = e => {
        if(files){
            for(let i=0; i<files.length; i++){
                DEXT5UPLOAD.AddUploadedFile(''+(i+1), escapeCharChange(files[i].fileNm), '', files[i].fileSize, files[i].attcSn, 'dext5upload1');
            }
        }
    }
     // 파일업로드후 리턴값
     const onTransferComplete = e => {
        const fileList = DEXT5UPLOAD.GetAllFileListForJson("dext5upload1");
        setFileInfo(fileList || {})
    }

    // 파일추가 전 처리할 내용
    const onBeforeAddItem = e => {
        if(!checkUploadFileType(e.eventInfo.paramObj)){
            confirmAlert({
                closeOnClickOutside: false,
                customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}  title={"알림"} msg={"업로드 할 수 없는 파일형식 입니다."}  />
            });
            return false;
        }
        return true;
    }
    // 파일업로드 시작시 사용자 데이타추가
    const onTransferStart = e => {
        DEXT5UPLOAD.AddFormData("gubun", "B", "dext5upload1");
    }

    
    useEffect(()=>{
        console.log("formValue",formValue);
    },[formValue])

    return (
        <>
            <div className="write-wrap">
            <Form
                ref={formRef}
                checkTrigger="change"
                onChange={setFormValue}
                onCheck={setFormError}
                formValue={formValue}
                model={model}>
                    <Table className="tbl-hor" bordered>
                        <colgroup>
                            <col style={{width:'15%'}}></col>
                            <col style={{width:'35%'}}></col>
                            <col style={{width:'15%'}}></col>
                            <col style={{width:'35%'}}></col>
                        </colgroup>
                        <tbody>
                            <tr>
                            <th className="">게시여부</th>
                                    <td>
                                        <Form.Control  name="bulYn" size="sm" style={{zIndex: 0}} 
                                            // value={bulYn}
                                            accepter={SelectPicker} 
                                            searchable={false}
                                            cleanable={false}
                                            data={[
                                                {label: '게시', value: 'Y'},
                                                {label: '미게시', value: 'N'},
                                            ]} 
                                            onChange={bulYnChangeEvent}
                                            
                                        ></Form.Control>
                                    </td>
                                <th>게시기간</th>
                                <td>
                                <InputGroup>
                                        <DatePicker oneTap block size="sm" style={{width: '100%'}} 
                                            value={bulDate && bulDate.sDate ? new Date(bulDate.sDate)  : new Date()}
                                            ranges={[
                                                {
                                                label: '오늘',
                                                value: new Date()
                                                }
                                            ]}
                                            format="yyyy-MM-dd"
                                            onChange={onChangeDateStart} 
                                            cleanable={false}
                                        />
                                        <InputGroup.Addon>~</InputGroup.Addon>
                                        <DatePicker oneTap block size="sm" style={{width: '100%'}} 
                                            value={bulDate && bulDate.eDate ? new Date(bulDate.eDate)  : new Date()}
                                            ranges={[
                                                {
                                                label: '오늘',
                                                value: new Date()
                                                }
                                            ]}
                                            format="yyyy-MM-dd"
                                            onChange={onChangeDateEnd} 
                                            cleanable={false}
                                        />
                                    </InputGroup>
                                </td>
                            </tr>
                            <tr>
                            <th className="essen">업무구분</th>
                                <td colSpan="3">
                                    <Form.Control  name="affrScnCd" size="sm" style={{zIndex: 0}} 
                                        // value={affrScnCd}
                                        accepter={SelectPicker} 
                                        data={[
                                            {label: '선택', value: ''},
                                            {label: '재고관리', value: '01'},
                                            {label: '제작준비', value: '02'},
                                            {label: '발간현황', value: '03'},
                                        ]}  searchable={false} cleanable={false} 
                                        onChange={scnCdChangeEvent}
                                    ></Form.Control>
                                                                           
                                </td>
                            </tr>
                            <tr>
                                <th className="essen">게시대상</th>
                                <td colSpan="3">
                                    <div className="ag-theme-alpine" style={{height: 250, transition:'all ease .3s'}}>
                                        <AgGridReact
                                            ref = {gridRef}
                                            rowData={queryResult.data && queryResult.data.rcvrChkList}
                                            columnDefs={columnDefs}
                                            defaultColDef={defaultColDef}
                                            rowSelection={'multiple'}
                                            suppressRowClickSelection= {true} 
                                            onFirstDataRendered={onFirstDataRendered}
                                            suppressSizeToFit={true}    
                                            onGridSizeChanged={onFirstDataRendered}    
                                            onSelectionChanged={onSelectionChanged}
                                            >
                                        </AgGridReact>
                                    </div>
                                </td>
                            </tr>
                            <tr>
                                <th className="essen">제목</th>
                                <td colSpan="3">
                                    <Form.Control size="sm" type="text" name='blcTitlNm' placeholder="제목을 입력해주세요" />
                                </td>
                            </tr>
                            <tr>
                                <th className="essen">내용</th>
                                <td colSpan="3">
                                    {/* <Form.Control size="sm" type="text" name='blcSbc' placeholder="내용을 입력해주세요" /> */}
                                    <DEXT5Editor
                                        debug={true}
                                        id="editor1"
                                        componentUrl="/dext5editor/js/dext5editor.js"
                                        config={{ DevelopLangage:'NONE', Width:'100%' }}
                                    />
                                </td>
                            </tr>
                            <tr>
                                <th>첨부파일</th>
                                <td colSpan="3">
                                {showLoad && <DEXT5Upload
                                        onCreationComplete={onCreationComplete}
                                        onTransferStart={onTransferStart}
                                        onTransferComplete={onTransferComplete}
                                        onBeforeAddItem={onBeforeAddItem}
                                        debug={false}
                                        id="dext5upload1"
                                        mode='edit' 
                                        runtimes='html5'
                                        componentUrl="/dext5upload/js/dext5upload.js"
                                        config={{MaxTotalFileSize:'100MB', MaxOneFileSize:'30MB', DevelopLangage:'NONE',Width:'100%',
                                            ButtonBarEdit: "add,remove,remove_all",
                                            HandlerUrl:  getApiUrl() + 'dext5upload', 
                                            DownloadHandlerUrl: getApiUrl() + 'dext5upload',
                                        }}
                                        
                                    />}
                                </td>
                            </tr>
                        </tbody>
                    </Table>
                </Form>
                <div className="btn-wrap">
                    <div className="right-align">
                        <Button variant="light" onClick={listButton}>취소</Button>{' '}
                        <Button className="" variant="primary" size="md" onClick={handleSubmit}>저장</Button>
                    </div>
                </div>
            </div>
        </>
    )
};
export default NoticeUpdate;