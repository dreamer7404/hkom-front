import React, {useEffect, useMemo, useRef, useState} from 'react';
import { AgGridReact } from 'ag-grid-react';
import { CONSTANTS } from '../../../../utils/constants';
import { escapeCharChange ,escapeCharChangeForGrid} from '../../../../utils/commUtils';
const GridVehlCodeList = ({gridRef, coCd, gridHeight, filterValue, queryResult, limit, activePage, onCellClicked}) => {

  
  

//columnDefs-> useState 변환후 상태관리, 하위 데이터 children을 따로 빼서 데이터 매핑
  const [columnDefs, setColumnDefs] = useState( [
    {
      checkboxSelection: true,
      headerCheckboxSelection: true,
      spanHeaderHeight: true,
      width:35,
      maxWidth:35,
      minWidth:35,
      pinned:'left'
    },
    {
      headerName: '차종',
      children: [
        { headerName:'차종코드', field: 'qltyVehlCd', minWidth:'70',pinned:'left'},
        { headerName:'차종명', field: 'qltyVehlNm', minWidth:'130',pinned:'left', cellStyle: () => ({textDecoration: 'underline', cursor: 'pointer', color:'#2589f5'}), cellRenderer: data => escapeCharChangeForGrid(data) },
        { headerName:'연식', field: 'mdlMdyCd', minWidth:'50',pinned:'left'},
      ],
    },
    {
      headerName: '구분',
      children: [
        { headerName:'승상', field: 'pacScnGbn', minWidth:'60', pinned:'left'},
        { headerName:'PDI', field: 'pdiNm', minWidth:'60', pinned:'left',cellRenderer: data => escapeCharChangeForGrid(data) },
      ],
    },
    {
      headerName: '연계차종코드',
      children: [
        { headerName:'APS', field: 'dytmPlnCd', minWidth:'60', pinned:'left'},
        { headerName:'생산', field: 'prdnMstCd', minWidth:'60', pinned:'left' },
        { headerName:'BOM', field: 'bomVehlCd', minWidth:'60', pinned:'left' },
        { headerName:'판매', field: 'saleVehlCd', minWidth:'60', pinned:'left' },
        { headerName:'용산', field: 'yongVehlCd', minWidth:'60', pinned:'left' },
      ],
    },
    {
      headerName: '사용\n여부',
      spanHeaderHeight: true,
      field: 'useYn',
      minWidth:'60',
      pinned:'left',
      cellRenderer: "statusComonent"
    },
    {
      headerName: '담당자 정보',
      children: [
        {headerName:coCd =='01'? 'HMC':'KMC', field: 'hmc', minWidth:'80'},
        { headerName:'외주제작사', field: 'kyung', minWidth:'80' },
        { headerName:'세원', field: 'sehwa', minWidth:'80' },
        { headerName:'PDI', field: 'pdi', minWidth:'80'},
        { headerName:'용산', field: 'yong', minWidth:'80'},
      ],
    },
    
]);    // 페이지번호
   

  const defaultColDef = useMemo(() => {
      return {
          initialWidth: 90,
          sortable: true,
          resizable:true,
      };
  }, []);

  //사용여부
  const statusComonent = (props) => {
    if(props.value === "Y"){
      return(
          <div style={{color:'#2589f5'}}>
          {props.value}
          </div>
      )
    }else if(props.value === "N"){
      return(
          <div style={{color:'#dc3545'}}>
          {props.value}
          </div>
      )
    }
  }

  const onFirstDataRendered = (params) => {
      params.api.sizeColumnsToFit();
  };
  


  useEffect(()=>{
    if(queryResult.isSuccess && queryResult.data!=undefined) {
      const item = queryResult.data.regnList;
      const arr = item.map(p=>({headerName:p.dlExpdPrvsNm,
                                field : p.dlExpdPrvsCd? "regn"+p.dlExpdPrvsCd:null,
                                minWidth:'90'}));

      setColumnDefs(columnDefs.filter(item => item.headerName !== '연식관계정보').concat({
        headerName: '연식관계정보',
        children: arr,
      }))
     
    }

    
  },[queryResult.status]);



  useEffect(()=>{
    if(queryResult.status === 'loading' && gridRef && gridRef.current && gridRef.current.api){
        gridRef.current.api.showLoadingOverlay();
    }
    
  },[queryResult]);

  useEffect(()=> {
    if(gridRef && gridRef.current && gridRef.current.api){
      gridRef.current.api.setQuickFilter(filterValue);
    }
  },[filterValue]);

  useEffect(()=> {
    if(gridRef && gridRef.current && gridRef.current.api){
      gridRef.current.api.paginationGoToPage(activePage-1);
    }
  },[activePage]);


  return(

    
      <div className="ag-theme-alpine" style={{height: gridHeight, transition:'all ease .3s'}}>
    
        <AgGridReact
            ref={gridRef} 
            rowData={queryResult.isSuccess &&queryResult.data && queryResult.data.vehlList} 
            columnDefs={columnDefs}
            defaultColDef={defaultColDef}

            // paging
            pagination={true}
            paginationPageSize={limit} //
            suppressPaginationPanel={true} 
            // onPaginationChanged={onPaginationChanged}

            //  filter
            cacheQuickFilter={true}

            onCellClicked={onCellClicked}

            frameworkComponents={{
                statusComonent
            }}

            // overlay
            overlayLoadingTemplate={CONSTANTS.gridLoading}
            overlayNoRowsTemplate={CONSTANTS.gridNoRows}

            onFirstDataRendered={onFirstDataRendered}
            suppressSizeToFit={true}    
            onGridSizeChanged={onFirstDataRendered}    
            >
        </AgGridReact>
    </div>
  )


};
export default GridVehlCodeList;