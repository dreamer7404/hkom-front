/* eslint-disable react-hooks/exhaustive-deps */
import React, {useEffect,useState, useMemo, useRef} from 'react';
import { AgGridReact } from 'ag-grid-react';
import { CONSTANTS } from '../../../../utils/constants';
import { escapeCharChangeForGrid, formatNumber } from '../../../../utils/commUtils';

const GridVehlMdyList = ({gridHeight, filterValue, queryResult, limit, activePage, onCellClicked}) => {

  
  const gridRef = useRef();

  const [columnDefs, setColumnDefs] = useState([]);

  const [data, setData] = useState(null);

  useEffect(()=>{
    console.log("111111111",queryResult.data);
    if(queryResult.data) {

      console.log('queryResult.data',queryResult.data)
      console.log('queryResult.data.mdyList',queryResult.data.mdyList)

      let list = queryResult.data.mdyList;
      //---------- 컬럼 합치기 위한 데이타조사 ----------------------
      for(let i=0; i<list.length; i++){
          const item = list[i];
          const keys = Object.keys(item).filter(m => m.substring(0, 3) === 'col').sort().reverse();

          let span = '';
          let tmpVal = item[keys[0]];
          let cnt = 1;
          for(let k=1; k<keys.length; k++){
            const val = item[keys[k]];
            if(val !== tmpVal) {
              span += keys[k-1] + '-' + cnt + ',';
              cnt = 1;
              tmpVal = val;
            }else{
              cnt++;
            }
          }
          span += keys[keys.length-1] + '-' + cnt;
          list[i]['spanInfo'] = span;
      }
      //----------// 컬럼 합치기 위한 데이타조사 ----------------------
      setData(list);

      
      const item = queryResult.data.dateList;
      let uniqueValues = [];
      const colors = ['#ffe6cc', '#ccffe6', '#cce6ff'];

      const arr = item.map((p, idx)=> p.value && ({
          minWidth:'60',
          headerName: p.value.substring(2, 4)+'.'+p.value.substring(5, 7)+'월', // 년도-월
          field: p.value ? p.key : null,
          cellStyle: (params) => {
            
            // console.log('cellStyle',params.data.spanInfo)
            let backgroundColor = '#fff';
            let border = ''
            if(params.data.spanInfo){
              const arr1 = params.data.spanInfo.split(',');
              for(let i=0; i<arr1.length; i++){
                const arr2 = arr1[i].split('-');
                if(params.column.colId === arr2[0]){
                  if(i%3 === 0) backgroundColor = '#ffe6cc';
                  else if(i%3 === 1) backgroundColor = '#ccffe6';
                  else if(i%3 === 2) backgroundColor = '#cce6ff';

                  border = '1px solid #F2F2F2'
                  break;
                }
              }
            }
            return border ? {textDecoration: 'underline', cursor: 'pointer', color:'#2589f5', backgroundColor: backgroundColor, border: border}
            : {textDecoration: 'underline', cursor: 'pointer', color:'#2589f5', backgroundColor: backgroundColor};
          },
          cellRenderer: params => params.value && params.value + 'My',
          colSpan: params => {
            // 컬럼 합치기 
            //  ex) col01-5,col21-3...
            if(params.data.spanInfo){
              const arr1 = params.data.spanInfo.split(','); 
              for(let i=0; i<arr1.length; i++){
                const arr2 = arr1[i].split('-'); 
                if(params.column.colId === arr2[0]){
                  return  Number(arr2[1]);
                }
              }
              return 1;
            }
            else return 1;
          }
      }) );

      

      setColumnDefs([
       
        {
          headerName: '차종',
          children: [
            { headerName:'차종코드', field: 'qltyVehlCd', minWidth:'70',pinned:'left'},
            { headerName:'차종명', field: 'qltyVehlNm', minWidth:'130',pinned:'left',
              cellRenderer: data => escapeCharChangeForGrid(data)
            },
          ],
        },
        {
          headerName: '지역',
          spanHeaderHeight: true,
          minWidth:'70',
          field: 'dlExpdPrvsNm',
          pinned:'left'
        },
        {
          headerName: '월팩',
          children: arr,
        }
        ,{
          headerName: '종료미지정',
          children: [
            { 
              headerName:'9999', field: 'col25', minWidth:'120',
              cellStyle: (params) => {
                if(!params.value) return {backgroundColor: 'white'};
                else{
                  const index = uniqueValues.length-1;
                  return params.value === uniqueValues[index] ? {backgroundColor: colors[index]} : {};
                }
              },
              cellRenderer: params => params.value && params.value + 'My'
            }
          ]
        },
        // {
        //   headerName: 'aaaa',
        //   minWidth:'200',
        //   field: "spanInfo",
        //   hide: false,
        // },
       
      ]);
  
    }
  },[queryResult.status, queryResult.data]);


    
  const defaultColDef = useMemo(() => {
      return {
          initialWidth: 90,
          sortable: true,
          resizable:true,
      };
  }, []);

  const columnFunction =(params) =>{
    const yearMonth1 = params.data.col1;
    const yearMonth2 = params.data.col2;
        
      return yearMonth1 === yearMonth2 ? 2 : 1
  }


  const onFirstDataRendered = (params) => {
      params.api.sizeColumnsToFit();
  };

  useEffect(()=>{
    
    if(queryResult.status === 'loading' && gridRef && gridRef.current && gridRef.current.api){
        gridRef.current.api.showLoadingOverlay();
    }
    
  },[queryResult]);
  
  useEffect(()=> {
    if(gridRef && gridRef.current && gridRef.current.api){
      gridRef.current.api.setQuickFilter(filterValue);
    }
  },[filterValue]);

  useEffect(()=> {
    if(gridRef && gridRef.current && gridRef.current.api){
      gridRef.current.api.paginationGoToPage(activePage-1);
    }
  },[activePage]);


  return(
      <div className="ag-theme-alpine" style={{height: gridHeight, transition:'all ease .3s'}}>
        <AgGridReact
            ref={gridRef} 
            rowData={data && data} 
            columnDefs={columnDefs}
            defaultColDef={defaultColDef}
            // paging
            pagination={true}
            paginationPageSize={limit} //
            suppressPaginationPanel={true} 
            // onPaginationChanged={onPaginationChanged}

            //  filter
            cacheQuickFilter={true}

            onCellClicked={onCellClicked}

            // overlay
            overlayLoadingTemplate={CONSTANTS.gridLoading}
            overlayNoRowsTemplate={CONSTANTS.gridNoRows}

            onFirstDataRendered={onFirstDataRendered}
            suppressSizeToFit={true}    
            onGridSizeChanged={onFirstDataRendered}    
            >
        </AgGridReact>
    </div>
  )


};
export default GridVehlMdyList;