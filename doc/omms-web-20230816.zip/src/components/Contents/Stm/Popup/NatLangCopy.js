import React,{useState,useEffect} from 'react';
import {Row, Col, Button, Modal, Table} from 'react-bootstrap';
import {Form, SelectPicker } from 'rsuite';
import { API, CONSTANTS } from '../../../../utils/constants';
import useStore from '../../../../utils/store';
import { useQuery} from 'react-query';
import { getData } from '../../../../utils/async';
import { escapeCharChange, formatNumber } from '../../../../utils/commUtils';
import CustomModal from '../../../Common/CustomModal';
import { confirmAlert } from 'react-confirm-alert'; // Import
import ConfirmAlert from '../../../Common/ConfirmAlert';
const NatLangCopy = ({show, onHide, natlCopyEvent}) => {
    const [natlCd, setNatlCd] = useState(); //  차종코드
    const [mdlMdyCd, setMdlMdyCd] = useState();     // 차량Mdy코드

    const onChangeNatlCombo = val => {
        
        setNatlCd(val);
        };
        const onChangeNatlMdyCombo = value => {
            
            setMdlMdyCd(value);
            searchData();
        
        };

        const searchData = () =>{
            queryResult.refetch();
            
        }
   
   
    const natlCombo = useQuery([API.natlMsts, {}], () => getData(API.natlMsts, {}), {
        select: data => []
            .concat(data.map((item) => ({ label: escapeCharChange(item.natNm), value: item.dlExpdNatCd })))
    }); 
    
    const mdlMdyParams={
        // qltyVehlCd : keyword.qltyVehlCd.replace('ALL','')
        dlExpdNatCd: natlCd
    }
    const natlMdyCombo = useQuery([API.natlMdyCombo,mdlMdyParams], () => getData(API.natlMdyCombo,mdlMdyParams), {
        select: data => data.map(item => ({ label: escapeCharChange(item.totNm), value: item.mdlMdyCd})) 
    });

    const natlCopyParams = {
        dlExpdNatCd : natlCd,
        mdlMdyCd : mdlMdyCd
    }
    const queryResult =  useQuery([API.natlCopys, natlCopyParams], () => getData(API.natlCopys, natlCopyParams));
   


    useEffect(()=>{
        if(queryResult.isSuccess && mdlMdyCd && natlCd ){
            
            natlCopyEvent(queryResult.data.copyNatlList)
        }

    },queryResult.status)
    const handleSubmit = ()=> {

        if(!natlCd){
            confirmAlert({
                closeOnClickOutside: false,
                customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}  title={"알림"} msg={"대상국가를 선택해주세요."}  />
            });
        }else{
            onHide();
        }
    }

    return (
        <>
            <Form>
           
                <CustomModal open={show} 
                        title={'국가언어복사'}
                        size='md'
                        // handleOk={onHide}
                        handleCancel={onHide} 
                >
                            <Table className="tbl-hor" bordered>
                                <tbody>
                                    <tr>
                                        <th className="essen">대상국가</th>
                                        <td>
                                            <Row className="select-wrap">
                                                <Col sm={8}>
                                                <SelectPicker size="sm" 
                                                        // value={keyword.qltyVehlCd} 
                                                        placeholder="선택"
                                                        value={natlCd} 
                                                        data={natlCombo && natlCombo.data ? natlCombo.data : []}  
                                                        onChange={onChangeNatlCombo}
                                                        searchable={false} 
                                                        cleanable={false} 

                                                    />
                                                </Col>
                                                <Col sm={4}>
                                                <SelectPicker size="sm" 
                                                        // value={keyword.valCd}
                                                        placeholder="선택"
                                                        value={mdlMdyCd}
                                                        searchable={false}
                                                        onChange={onChangeNatlMdyCombo}
                                                        data={natlMdyCombo && natlMdyCombo.data ? natlMdyCombo.data : []}  
                                                        cleanable={false} 

                                                    />
                                                </Col>
                                            </Row>
                                        </td>
                                    </tr>
                                </tbody>
                            </Table>


                            <div className='modal-footer'>
                                <Button variant="light" size="md" onClick={onHide}>취소</Button>
                                <Button variant="primary" size="md" onClick={handleSubmit} >저장</Button>
                            </div>
                        </CustomModal>
            </Form>
        </>
    );

};
export default NatLangCopy;