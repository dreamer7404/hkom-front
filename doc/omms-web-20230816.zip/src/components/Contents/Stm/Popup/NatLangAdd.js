import React, {useState, useMemo, useEffect, useRef} from 'react';
import {Button, Modal, Table} from 'react-bootstrap';
import SearchIcon from '@rsuite/icons/Search';
import PageNextIcon from '@rsuite/icons/PageNext';
import PagePreviousIcon from '@rsuite/icons/PagePrevious';
import { InputGroup, Form, SelectPicker, Schema, TagGroup,Tag } from 'rsuite';
import { AgGridReact } from 'ag-grid-react';
import { getData,postData } from '../../../../utils/async';
import { useQuery,useMutation} from 'react-query';
import NatLangCopy from './NatLangCopy';
import NatCodeSearch from './NatCodeSearch';
import { API,CONSTANTS} from '../../../../utils/constants';
import { confirmAlert } from 'react-confirm-alert'; // Import
import ConfirmAlert from '../../../Common/ConfirmAlert';
import CustomModal from '../../../Common/CustomModal';
const { StringType} = Schema.Types;

const model = Schema.Model({
    dlExpdNatCd: StringType().isRequired('국가코드를 선택해주세요'),
    mdlMdyCd : StringType().isRequired('연식을 입력해주세요'),
                            
    
    
});
const NatLangAdd = ({show, onHide}) => {

    const vehlGrid = useRef();
    const langGrid = useRef();
    
    const [addNatCodeParam, setNatCodeParam] = React.useState({
        dlExpdNatCd: '',             // 차종코드
        natNm: '',             // 차종
        dlExpdRegnCd: '',               // 회사코드
        regnNm:'',
        
    });  
    const formRef = React.useRef();
    const [formError, setFormError] = React.useState({});
    const [formValue, setFormValue] = React.useState({
        dlExpdNatCd : '',
        natNm : '',
        dlExpdRegnCd: '',
        regnNm : '',
        mdlMdyCd : '',
        blkLstCd : '',
        vehlList : [],
    }); 
 // 차종코드 리스트
 const vehlCd = useQuery([API.natlVehlList,{}], () => getData(API.natlVehlList, {}), {
    select: data => { 
        return data.map(item => ({
            qltyVehlCd: item.qltyVehlCd, 
            qltyVehlNm : item.qltyVehlNm,
            langs: [], // langCd
        })); 
    },
});
const [filteredLangList, setFilteredLangList] = useState();

 // 언어코드 리스트
 const langCd = useQuery([API.langMsts,{}], () => getData(API.langMsts, {}), {
    select: data => { 
        return data.map(item => ({
            dlExpdRegnCd: item.dlExpdRegnCd, 
            langCd: item.langCd, 
            langCdNm: item.langCdNm, 
            regnNm: item.regnNm
        })); 
    },
});

   // 국가그리드 태그
   const tagRender =(e)=>{
    const list = e.data.langs;
    return <>
        {list.length > 0 && 
            <TagGroup style={{textAlign: 'left'}}>
                {list.map((m, i) => (
                    <Tag key={i} closable onClose={() => removeTag(e.data.qltyVehlCd, m)}>{m}</Tag>
                ))}
            </TagGroup>
        }
    </>
    }

    // 국가그리드 태그삭제
    const removeTag = (qltyVehlCd, langCd) => {
        setVehlList(vehlList.map(m => m.qltyVehlCd === qltyVehlCd
            // ? {...m, langs: m.langs.filter(f => f.langCd !== langCd)} : m));
            ? {...m, langs: m.langs.filter(item => item !== langCd)} : m));
    };

    useEffect(()=>{ //국가코드 선택 팝업 선택 시 매핑
        setFormValue(p=>({...p,
            
            dlExpdNatCd : addNatCodeParam.dlExpdNatCd,
            natNm : addNatCodeParam.natNm,
            dlExpdRegnCd: addNatCodeParam.dlExpdRegnCd,
            regnNm : addNatCodeParam.regnNm
        }))
    },[addNatCodeParam]) 


    useEffect(()=>{
        if(vehlCd.data && langCd.data){
            // 국가코드목록에 언어코드목록 넣기

            setVehlList(vehlCd.data);
            
            // 언어코드목록
            setLangList(langCd.data);
            setFilteredLangList(langCd.data);  // 언어코드목록 필터링(VIEW용)
        }
    },[vehlCd.status, langCd.status]);

    const defaultColDef = useMemo(() => {
        return {
            initialWidth: 90,
            resizable:true,
        };
    }, []);
   

    const columnDefs = [
        {
            checkboxSelection: true,
            headerCheckboxSelection: true,
            spanHeaderHeight: true,
            width:35,
            maxWidth:35,
            minWidth:35
        },
        {
            headerName: '차종코드',
            field: 'qltyVehlCd',
            spanHeaderHeight: true,
            maxWidth:'100',
            minWidth:70,
            sortable:true,
            filter: 'agTextColumnFilter',
            floatingFilter: true,
            suppressMenu: true,
            filterParams: {
                filterOptions: ['contains'],
            }
        },
        {
            headerName: '언어',
            field: 'lang',
            minWidth:130,
            spanHeaderHeight: true,
            cellRenderer: tagRender,
               
        },      
    ]

    const columnDefs2 = [
        {
            checkboxSelection: true,
            headerCheckboxSelection: true,
            spanHeaderHeight: true,
            width:35,
            maxWidth:35,
            minWidth:35
        },
        {
            headerName: '언어코드',
            field: 'langCd',
            spanHeaderHeight: true,
            maxWidth:80,
            minWidth:70,
            sortable:true
        },  
        {
            headerName: '언어명',
            field: 'langCdNm',
            minWidth:130,
            spanHeaderHeight: true,
        },
        {
            headerName: '지역',
            field: 'regnNm',
            maxWidth:100,
            minWidth:70,
            spanHeaderHeight: true,
        },    
    ]

    const onFirstDataRendered = (params) => {
        params.api.sizeColumnsToFit();
    };
 

    const [vehlList, setVehlList] = useState();
    const [langList, setLangList] = useState();
    const langAddEvnt = () => {
        const vehlRows = vehlGrid.current.api.getSelectedRows();
        const langRows = langGrid.current.api.getSelectedRows();
        
        if(langRows.length === 0 ){
            confirmAlert({
                closeOnClickOutside: false,
                customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}  title={"알림"} msg={"언어를 선택해주세요"}  />
            });
        }else if(vehlRows.length === 0){
            confirmAlert({
                closeOnClickOutside: false,
                customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}  title={"알림"} msg={"차종을 선택해주세요"}  />
            });
        }else{
            // const langs = langRows.map(item => ({langCd: item.langCd, langCdNm: item.langCdNm}));
            const langs = langRows.map(item => item.langCd);
            setVehlList(vehlList.map(m => vehlRows.find(f => f.qltyVehlCd === m.qltyVehlCd) ? {...m, langs: langs} : m));
        }
    
    }

    const natlCopyEvent = (copyData) => {//언어복사
        if(copyData && vehlCd.data && langCd.data){

            const vehlLangList = copyData;
            // 차종코드목록에 언어코드목록 넣기
            for(let i=0; i<vehlCd.data.length; i++){
                for(let k=0; k<vehlLangList.length; k++){
                    if(vehlCd.data[i].qltyVehlCd === vehlLangList[k].qltyVehlCd){
                        vehlCd.data[i].langs = vehlLangList[k].langCd.split(',')
                    }
                }
            }
            setVehlList(vehlCd.data);
            
            // 언어코드목록
            setLangList(langCd.data);
            setFilteredLangList(langCd.data); 
        }
    }

    
    // 저장버튼 클릭
    const handleSubmit = () => {
        if (!formRef.current.check()) { //validation chk
            return;
        }

        
        formValue.vehlList = vehlList.filter(f => f.langs.length > 0);

        confirmAlert({
            closeOnClickOutside: false,
            customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}   title={"알림"} 
            msg={"입력된 내용으로 저장하시겠습니까?"}  
            onOk={onOk}
            />
        });
       
    };

  //국가코드 저장
  const natlVehlSave = useMutation((params => postData(API.natlLangMgmt, params, CONSTANTS.insert)),{
    onSuccess: res => {
        
        if(res>0){ //데이터 정상처리
        
            confirmAlert({
                closeOnClickOutside: false,
                customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}   title={"알림"} 
                msg={"저장이 완료되었습니다."}   />
            });
        }else{
               
            confirmAlert({
                closeOnClickOutside: false,
                customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}   title={"알림"} 
                msg={"저장에 실패하였습니다 관리자에게 문의해주세요."}   />
            });
        
        }
         onHide(); // 창닫기 & refetch
    }
    });

    const onOk = () => {
        
        natlVehlSave.mutate(formValue);
    }


  
    const [natLangCopyPop, setNatLangCopyPop] = useState(false);
    const [natCodeSearchPop, setNatCodeSearchPop] = useState(false);
 // 국가그리드 선택이벤트 => 언어그리드 필터링
 const onSelectionChanged  = e => {
    // 국가그리드 선택된
    const vehlRows = vehlGrid.current.api.getSelectedRows();

    // console.log('onSelectionChanged - natlRows.length: ', natlRows.length)
    if(vehlRows.length > 0){
        // const langCdArray =  natlRows.map(m => m.langs.map(m2 => m2.langCd));
        const langCdArray =  vehlRows.map(m => m.langs.map(m2 => m2));

        // 중복 언어코드 찾기
        let dupLangCd = [];
        if(langCdArray.length > 0){
            // 배열합치기
            const arr = langCdArray.reduce((acc, cur) => acc.concat(cur));
            // 배열중복횟수
            const result = arr.reduce((accu,curr)=> {
                accu.set(curr, (accu.get(curr)||0) +1) ;
                return accu;
            },new Map());
            // 배열 중복회수가 선택된 국가그리드수와 같은가?
            for (let [key, value] of result.entries()) {
                if(value === vehlRows.length)
                    dupLangCd.push(key)
            }
        }

        //  언어그리드 필터링
        if(dupLangCd.length > 0){ // 중복언어코드가 있으면.
            // const filtered = langList.filter(item => !dupLangCd.includes(item.langCd));
            const filtered = langList.filter(item => !dupLangCd.includes(item.langCd));
            setFilteredLangList(filtered)
        }else{
            setFilteredLangList(langList)
        }
    }else{
        setFilteredLangList(langList)
    }

};

useEffect(() => {
    // 언어그리드 필터링
    if(vehlGrid && vehlGrid.current && vehlGrid.current.api && vehlGrid.current.api.getRenderedNodes().length > 0){
        onSelectionChanged();
    }
},[vehlList])
    return (
        <>
           <Form
                ref={formRef}
                checkTrigger="change"
                onChange={setFormValue}
                onCheck={setFormError}
                formValue={formValue}
                model={model}>
                
                        <CustomModal open={show} 
                            title={'국가별 언어등록'}
                            size='xl'
                            // handleOk={handleSubmit}
                            handleCancel={onHide} 
                        >
                            <div className="grid-wrap">
                                    <Table className="tbl-hor" bordered>
                                        <colgroup>
                                            <col style={{width:'15%'}}></col>
                                            <col style={{width:'35%'}}></col>
                                            <col style={{width:'15%'}}></col>
                                            <col style={{width:'35%'}}></col>
                                        </colgroup>
                                        <tbody>
                                            <tr>
                                                <th className="essen">국가코드</th>
                                                <td>
                                                <InputGroup inside >
                                                <Form.Control name="dlExpdNatCd" style={{fontSize:'12px',height:'24px'}} value={addNatCodeParam && addNatCodeParam.dlExpdNatCd}/>  
                                                    <InputGroup.Button style={{height:'24px'}} onClick={() => setNatCodeSearchPop(true)}>
                                                    <SearchIcon />
                                                    </InputGroup.Button>
                                                </InputGroup>
                                           
                                                </td>
                                                <th className="">국가명</th>
                                                <td>
                                                    <Form.Control size="sm" type="text" name = "natNm" value={addNatCodeParam && addNatCodeParam.natNm} readOnly />
                                                </td>
                                            </tr>
                                            <tr>
                                                <th className="">지역</th>
                                                <td>
                                                    <Form.Control size="sm" type="text" name="regnNm" placeholder="" readOnly />
                                                </td>
                                                <th className="essen">연식</th>
                                                <td>
                                                    <Form.Control size="sm" type="text" name='mdlMdyCd' placeholder=""  />
                                                </td>
                                            </tr>
                                            <tr>
                                                <th className="">제외 대리점 코드</th>
                                                <td colSpan="3">
                                                    <Form.Control size="sm" type="text" name="dytmPlnNatCd" placeholder=""  />
                                                </td>
                                            </tr>
                                            <tr>
                                                <th>적용 차종 및 언어</th>
                                                <td colSpan="3">
                                                     <div className="grid-btn-wrap" style={{marginBottom:'5px'}}>
                                                        <div className="right-align">
                                                            <Button variant="outline-secondary" size="sm" onClick={() => setNatLangCopyPop(true)}>국가언어 복사</Button>{' '}
                                                        </div>
                                                    </div>
                                                    <div className="grid-double">
                                                        <div className="ag-theme-alpine" style={{height:300, width:'60%'}}>
                                                            <AgGridReact
                                                                ref = {vehlGrid}
                                                                rowData={vehlList}
                                                                columnDefs={columnDefs}
                                                                defaultColDef={defaultColDef}
                                                                rowSelection={'multiple'}
                                                                suppressRowClickSelection= {true} 
                                                                onFirstDataRendered={onFirstDataRendered}
                                                                suppressSizeToFit={true}    
                                                                onGridSizeChanged={onFirstDataRendered}     
                                                                onSelectionChanged ={onSelectionChanged }
                                                                >
                                                            </AgGridReact>
                                                        </div>
                                                        <div className="grid-move-btn" style={{marginLeft:"5px"}}>
                                                            <Button className="lang-add-btn" variant="outline-secondary" size="sm" onClick={() => langAddEvnt()}> <PagePreviousIcon/> </Button>{' '}
                                                            {/* <Button className="lang-dlt-btn" variant="outline-secondary" size="sm" > </Button> */}
                                                        </div>
                                                        <div className="ag-theme-alpine" style={{height:300, width:'40%',marginLeft:"5px"}}>
                                                            <AgGridReact
                                                                ref={langGrid}
                                                                rowData={filteredLangList}
                                                                columnDefs={columnDefs2}
                                                                defaultColDef={defaultColDef}
                                                                rowSelection={'multiple'}
                                                                suppressRowClickSelection= {true} 
                                                                onFirstDataRendered={onFirstDataRendered}
                                                                suppressSizeToFit={true}    
                                                                onGridSizeChanged={onFirstDataRendered}     
                                                                >
                                                            </AgGridReact>
                                                        </div>
                                                    </div>
                                                    
                                                </td>
                                            </tr>
                                        </tbody>
                                    </Table>
                                </div>

                                <div className='modal-footer'>
                                <Button variant="light" size="md" onClick={onHide}>취소</Button>
                                <Button variant="primary" size="md" onClick={handleSubmit} >저장</Button>
                            </div>
                       </CustomModal>
            </Form>


            {natCodeSearchPop && <NatCodeSearch addCodeParam = {setNatCodeParam}show={natCodeSearchPop} onHide={() => setNatCodeSearchPop(false)}  />} {/* 국가코드선택 */}
            {natLangCopyPop && <NatLangCopy show={natLangCopyPop} onHide={() => setNatLangCopyPop(false)}  natlCopyEvent={natlCopyEvent}/>}  {/* 국가언어복사 */}
        </>
    );

};
export default NatLangAdd;