import React, {useState, useRef} from 'react';
import {Button, Modal, Table, Row, Col} from 'react-bootstrap';
import {Form, SelectPicker,Schema} from 'rsuite';
import { API, CONSTANTS } from '../../../../utils/constants';
import { useQuery, useMutation, useQueryClient } from 'react-query';
import { getData,postData } from '../../../../utils/async';
import { escapeCharChange} from '../../../../utils/commUtils';
import { confirmAlert } from 'react-confirm-alert'; // Import
import ConfirmAlert from '../../../Common/ConfirmAlert';
import CustomModal from '../../../Common/CustomModal';
const { StringType} = Schema.Types;
const model = Schema.Model({
    // qltyVehlCd: StringType().isRequired('차종코드를 선택해 주세요.'),
    langCd: StringType().isRequired('언어코드를 입력해주세요.').rangeLength(0, 2, '0-2자로 입력해주세요'),
    langCdNm: StringType().isRequired('언어명을 입력해주세요.'),
    dlExpdRegnCd: StringType().isRequired('지역을 선택해주세요.'),
    useYn: StringType().isRequired('사용유무를 선택해 주세요.')
});
const LangCodeAdd = ({show, onHide}) => {
    const containerRef = useRef();
    const queryClient = useQueryClient(); 
    const formRef = useRef();
    const [formError, setFormError] = useState({});
    const [formValue, setFormValue] = useState({
        langCd : '',
        langCdNm : '',
        dlExpdRegnCd : '',
        useYn:'',                   // 사용유무
    }); 
    const handleSubmit = () => {
        if (!formRef.current.check()) { //validation chk
            return;
        }
        
        
        confirmAlert({
            closeOnClickOutside: false,
            customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}   title={"알림"}
            msg={"입력하신 내용으로 저장하시겠습니까?"} 
            
            onOk={onOk}  />
            
        });
        
        
    }; 
    const langMstsSave = useMutation((params => postData(API.langMst, params, CONSTANTS.insert)),{
        onSuccess: res => {
            if(res===999){
                confirmAlert({
                    closeOnClickOutside: false,
                    customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}   title={"알림"}
                    msg={"중복된 언어코드가 있습니다."}   />
                    
                })
               }
         
           else   if(res>0){
            confirmAlert({
                closeOnClickOutside: false,
                customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}   title={"알림"}
                msg={"저장이 완료되었습니다."}   />
                        
                });
                    
            }
           else{
            confirmAlert({
                closeOnClickOutside: false,
                customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}   title={"알림"}
                msg={"에러가 발생했습니다 관리자에게 문의해주세요."}   />
                
            });
           }
           onHide();
           queryClient.invalidateQueries(); //모든 쿼리 캐시 초기화
        }
        
    });


    const onOk = () => {
       
        langMstsSave.mutate(formValue);
    }

    const paramsCo = {dlExpdGCd: CONSTANTS.grpCdRegn};
    const regnCombo = useQuery([API.codeCombo,paramsCo], () => getData(API.codeCombo,paramsCo)) 
    return (
        <>
               <Form
                ref={formRef}
                checkTrigger="change"
                onChange={setFormValue}
                onCheck={setFormError}
                formValue={formValue}
                model={model}>
                <CustomModal open={show} 
                        title={'언어코드 등록'}
                        size='lg'
                        // handleOk={handleSubmit}
                        handleCancel={onHide} 
                        
                        >
                            <Table className="tbl-hor" bordered>
                                <colgroup>
                                    <col style={{width:'30%'}}></col>
                                    <col style={{width:''}}></col>
                                </colgroup>
                                <tbody>
                                    <tr>
                                        <th className="essen">언어코드</th>
                                        <td>
                                            <Form.Control name = "langCd" size="sm" type="text"/> 
                                        </td>
                                    </tr>
                                    <tr>
                                        <th className="essen">언어명</th>
                                        <td>
                                            <Form.Control name = "langCdNm" size="sm" type="text"/> 
                                        </td>
                                    </tr>
                                    <tr>
                                        <th className="essen">지역</th>
                                        <td>
                                        {regnCombo.isSuccess &&
                                                    <Form.Control container={()=> containerRef.current}  name="dlExpdRegnCd" size="sm" style={{zIndex: 0}} 
                                                        
                                                        placeholder={'선택'}
                                                        defaultValue={''}
                                                        accepter={SelectPicker} 
                                                        searchable={false}
                                                        cleanable={false}
                                                        data={regnCombo.isFetched && regnCombo.data}
                                                        
                                                    ></Form.Control>
                                                }
                                        </td>
                                    </tr>
                                    <tr>
                                        <th className="">사용여부</th>
                                        <td>
                                        <Form.Control name="useYn" size="sm"   
                                                    container={()=> containerRef.current}
                                                    placeholder={'선택'}
                                                    defaultValue={''}
                                                    accepter={SelectPicker} 
                                                    searchable={false}
                                                    cleanable={false}
                                                    data={[
                                                        {label: '사용', value: 'Y'},
                                                        {label: '미사용', value: 'N'},
                                                    ]}
                                            ></Form.Control>
                                        </td>
                                    </tr>
                                </tbody>
                            </Table>
                            <div className='modal-footer'>
                                <Button variant="light" size="md" onClick={onHide}>취소</Button>
                                <Button variant="primary" size="md" onClick={handleSubmit} >저장</Button>
                            </div>
                </CustomModal>
            </Form>

        </>
    );

};
export default LangCodeAdd;