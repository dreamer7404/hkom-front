import React from 'react';
import {Button, Modal, Table, Row, Col} from 'react-bootstrap';
import {Form, SelectPicker, DatePicker, Schema} from 'rsuite';
import {CONSTANTS, API } from '../../../../utils/constants';
import { getData, postData } from '../../../../utils/async';
import { useQuery,useMutation,useQueryClient} from 'react-query';
import { useEffect,useState } from 'react';
import { confirmAlert } from 'react-confirm-alert'; // Import
import ConfirmAlert from '../../../Common/ConfirmAlert';
import { escapeCharChange,utcToLocalDate} from '../../../../utils/commUtils';
import CustomModal from '../../../Common/CustomModal';

const { StringType} = Schema.Types;

const model = Schema.Model({
    // langCdNm: StringType().isRequired('언어명을 입력해주세요.'),
});
const PrintPageUpdate = ({show, onHide,data}) => {
    const containerRef = React.useRef();
    const formRef = React.useRef();
    
    const [rgstDte, setRgstDte] = React.useState({});
    const [pageArr, setPageArr] = React.useState([]);
    const [formError, setFormError] = React.useState({});
    const [formValue, setFormValue] = React.useState({
        qltyVehlCd : '',
        mdlMdyCd : '',
        dlExpdRegnCd: '',
        langCd : '',
        newPrntPbcnNo : '',
        lrnkCd : '',
        rgstYmd : '',
        pageArr  :[],
    }); 
    const queryClient = useQueryClient();
    

    const param = {
        newPrntPbcnNo : data.newPrntPbcnNo,
        lrnkCd : data.lrnkCd
    }
    const queryResult = useQuery([API.prntPageMgmt, param], () => getData(API.prntPageMgmt, param),{
        staleTime: 0,
    });
    

    const addHtml = () => {
        setPageArr(pageArr.concat(1))
    };

    const delHtml = () => {
        const test = [...pageArr];
        test.pop();
        
        setPageArr(test)
    };
    const onChangeDate = val =>{
        setRgstDte(val ? utcToLocalDate(val) : utcToLocalDate(new Date()));
    }
    const onChangeEvent=(value,idx)=>{
        setPageArr(pageArr.map((item, index) => ({...item, endPgSn: index === idx ? value : item.endPgSn})));
    }

    useEffect(()=>{
        if(queryResult.isSuccess){
    

            const dataInfo = queryResult.data;
            console.log("dataINfo",dataInfo);
            const date = dataInfo.detailInfo.rgstYmd
            
            const rgstYmd = date.substring(0,4)+'-'+date.substring(4,6)+'-'+date.substring(6,8);
            setRgstDte(rgstYmd)
            setFormValue({
                newPrntPbcnNo : dataInfo.detailInfo.newPrntPbcnNo,               // 사용여부
                qltyVehlCd : escapeCharChange(dataInfo.detailInfo.qltyVehlCd),             // A코드
                qltyVehlNm : escapeCharChange(dataInfo.detailInfo.qltyVehlNm),             // A코드
                dlExpdRegnCd : dataInfo.dlExpdRegnCd, // 지역코드
                langCd : escapeCharChange(dataInfo.detailInfo.langCd),
                langNm : escapeCharChange(dataInfo.detailInfo.langNm),
                lrnkCd : dataInfo.detailInfo.lrnkCd,
                mdlMdyCd : dataInfo.detailInfo.mdlMdyCd,
                rgstYmd : rgstYmd,
                a01 : dataInfo.detailInfo.a01,
                a02 : dataInfo.detailInfo.a02,
                a03 : dataInfo.detailInfo.a03,
                
                // pageArr : [{endPgSn : dataInfo.detailPageInfo.END_PG_SN}]


            })
            
            for(var i=0; i< dataInfo.detailPageInfo.length; i++){
                
                pageArr[i]={endPgSn : dataInfo.detailPageInfo[i].END_PG_SN}
            }

            let arr = [];
            for(var i=0; i< dataInfo.detailPageInfo.length; i++){
                
                // pageArr[i]={endPgSn : dataInfo.detailPageInfo[i].END_PG_SN}
                arr = arr.concat({endPgSn : dataInfo.detailPageInfo[i].END_PG_SN});
            }
            setPageArr(arr);
            
            
        }
    },[queryResult.status])

    const handleSubmit = () => {
        if (!formRef.current.check()) { //validation chk
            return;
        }
        
        confirmAlert({
            closeOnClickOutside: false,
            customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}   title={"알림"}
            msg={"입력하신 내용으로 저장하시겠습니까?"} 
            
            onOk={onOk}  />
            
        });
        
    };
    const prntPageSave = useMutation((params => postData(API.prntPageMgmt, params, CONSTANTS.update)),{
        onSuccess: res => {
           if(res>0){
                confirmAlert({
                    closeOnClickOutside: false,
                    customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}   title={"알림"}
                    msg={"저장이 완료되었습니다."}   />
                    
                });
           
           }else{
                confirmAlert({
                    closeOnClickOutside: false,
                    customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}   title={"알림"}
                    msg={"에러가 발생했습니다 관리자에게 문의해주세요."}   />
                    
                });
           }
           refresh();
        }
    });

    const refresh=()=>{
        queryClient.invalidateQueries([API.prntPageMgmt]); //모든 쿼리 캐시 초기화 
        onHide();
    }
   
    const onOk = () => {
        formValue.pageArr = pageArr;
        prntPageSave.mutate(formValue);
    }

    return (
        <>
            <Form
                ref={formRef}
                checkTrigger="change"
                onChange={setFormValue}
                onCheck={setFormError}
                formValue={formValue}
                model={model}>
                     <CustomModal open={show} 
                        title={'인쇄페이지 상세/수정'}
                        size='lg'
                        // handleOk={handleSubmit}
                        handleCancel={refresh} 
                        
                        
                        >
             
                            <Table className="tbl-hor" bordered>
                                <colgroup>
                                    <col style={{width:'15%'}}></col>
                                    <col style={{width:'35%'}}></col>
                                    <col style={{width:'15%'}}></col>
                                    <col style={{width:'35%'}}></col>
                                </colgroup>
                                <tbody>
                                    <tr>
                                        <th>차종</th>
                                        <td> {formValue && formValue.qltyVehlNm}</td>
                                            
                                        <th>언어</th>
                                        <td>
                                            {formValue && formValue.langNm}
                                        </td>
                                    </tr>
                                    <tr>
                                        <th>발간번호</th>
                                        <td>{formValue && formValue.newPrntPbcnNo}</td>
                                        <th>등록일</th>
                                        <td>
                                            <DatePicker oneTap block size="sm"
                                                cleanable = {false}
                                                searchable = "true"
                                                
                                                // value = {rgstDte ? new Date(rgstDte)  : new Date()}
                                                value={new Date()}
                                                onChange = {onChangeDate} 
                                                ranges={[
                                                    {
                                                    label: '오늘',
                                                    value: new Date()
                                                    }
                                                ]}
                                              />
                                        </td>
                                    </tr>
                                    <tr>
                                        <th className="essen">마지막페이지 구분</th>
                                        <td colSpan="3">
                                            <div className="grid-btn-wrap" style={{marginBottom:'5px'}}>
                                                <div className="right-align">
                                                    {/*--------- 버튼 -----------*/}
                                                    <Button variant="outline-secondary" size="sm" onClick={addHtml}>추가</Button>{' '}
                                                    <Button variant="outline-secondary" size="sm" onClick={delHtml}>삭제</Button>{' '}
                                                </div>
                                            </div>
                                            <div className="print-page-set">
                                                    <Row className="select-wrap">
                                                        <Col sm={1}>서문1</Col>
                                                        <Col sm={2}><Form.Control size="sm" name="a01" type="text"defaultValue='0'/></Col>
                                                        <Col sm={1}>서문2</Col>
                                                        <Col sm={2}><Form.Control size="sm" name="a02" type="text"defaultValue='0'/></Col>
                                                        <Col sm={1}>서문3</Col>
                                                        <Col sm={2}><Form.Control size="sm" name="a03" type="text"defaultValue='0'/></Col>
                                                        {pageArr.length>0 &&  pageArr.map((dataB,idx)=>
                                                        <>
                                                            <Col sm={1} key={idx+1}>{idx+1}장</Col>
                                                            <Col sm={2}><Form.Control size="sm" name={"endPgSn"+idx} type="text"  key={idx} defaultValue='0'onChange={(e)=>onChangeEvent(e,idx)} value={dataB.endPgSn}/></Col></>
                                                        )}
                                                         
                                                    </Row>
                                                    
                                            </div>
                                        </td>
                                    </tr>
                                </tbody>
                            </Table>


                            <div className='modal-footer'>
                                <Button variant="light" size="md" onClick={refresh}>취소</Button>
                                <Button variant="primary" size="md" onClick={handleSubmit} >저장</Button>
                            </div>
                            </CustomModal>
            </Form>

        </>
    );

};
export default PrintPageUpdate;