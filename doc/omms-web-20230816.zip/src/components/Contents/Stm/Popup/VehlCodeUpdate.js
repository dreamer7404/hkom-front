/* eslint-disable react-hooks/exhaustive-deps */
import React, {useState, useMemo,useEffect, useRef} from 'react';
import {Row, Col, Button, Modal, Table} from 'react-bootstrap';
import SearchIcon from '@rsuite/icons/Search';
import PageNextIcon from '@rsuite/icons/PageNext';
import PagePreviousIcon from '@rsuite/icons/PagePrevious';
import {  InputGroup, Form, SelectPicker, Schema, TagGroup,Tag } from 'rsuite';
import { AgGridReact } from 'ag-grid-react';
import { API,CONSTANTS} from '../../../../utils/constants';
import LangCopy from './LangCopy';
import VehlPerson from './VehlPerson';
import { getData,postData } from '../../../../utils/async';
import { escapeCharChange,escapeCharChangeForGrid} from '../../../../utils/commUtils';
import { useQuery, useMutation, useQueryClient } from 'react-query';
import { isApi } from '../../../../utils/commUtils';
import { confirmAlert } from 'react-confirm-alert'; // Import
import ConfirmAlert from '../../../Common/ConfirmAlert';
import CustomModal from '../../../Common/CustomModal';
import useStore from '../../../../utils/store';

const { StringType} = Schema.Types;

const model = Schema.Model({
    qltyVehlNm: StringType().isRequired('차종명을 입력해주세요.')
                            .pattern(/^[가-힣a-zA-Z0-9_().,/]+$/, '특수문자는 _().,/ 만 입력가능합니다')
                            .rangeLength(2, 30, '2-30자로 입력해주세요'),
    mdlMdyCd: StringType().isRequired('차종코드 및 연식을 입력해주세요.'),
    dlExpdPacScnCd: StringType().isRequired('승상구분을 선택해주세요.'),
    dlExpdPdiCd: StringType().isRequired('PDI구분을 선택해주세요.'),
    useYn: StringType().isRequired('사용유무를 선택해 주세요.')
});
const VehlCodeUpdate = ({show, data, onHide,onChange}) => {

    const natlGrid = useRef();
    const langGrid = useRef();
    const {setVehlInfo,coCd,keyword,setQltyVehlCd,setDlExpdPdiCd} = useStore();  // 조회키워드 가져오기
    const [submitButton, setSubmitButton] = useState(false);
    const defaultColDef = useMemo(() => {
        return {
            initialWidth: 90,
            resizable:true,
        };
    }, []);
    const queryClient = useQueryClient();

    //상세조회 파라미터 
    const param = { 
        qltyVehlCd: data.qltyVehlCd,    //차종
        mdlMdyCd: data.mdlMdyCd         //연식
    };
    const queryResult = useQuery([API.vehlMgmt,param], () => getData(API.vehlMgmt, param)); //상세 쿼리 조회
  
    //승상코드구분 콤보박스
    const pacScnParam = {dlExpdGCd: CONSTANTS.grpCdPacScn};
    const dlExpdPacScnCombo = useQuery([API.codeCombo,pacScnParam], () => getData(API.codeCombo,pacScnParam)) 
    //PDI구분 콤보박스
    const pdiCombo = useQuery([API.pdiCombo], () => getData(API.pdiCombo), {
        select: data => data.map((item) => ({ label: escapeCharChange(item.dlExpdPrvsNm), value: item.dlExpdPdiCd }))
    }); 

    const dlExpdPrvsCombo = useQuery([API.dlExpdPrvsCombo], () => getData(API.dlExpdPrvsCombo), {
        select: data => data.map((item) => ({ label: item.dlExpdPrvsNm, value: item.dlExpdPrvsCd }))
    }); 
     // 지역데이터 가져오기
    const paramsCo = {dlExpdGCd: CONSTANTS.grpCdRegn};
    const regnList = useQuery([API.codeCombo,paramsCo], () => getData(API.codeCombo,paramsCo)) 


    // 국가코드 리스트
    const natlCd = useQuery([API.natlMsts,{}], () => getData(API.natlMsts, {}), {
        enabled: !!queryResult.data,
        select: data => {
            return data.map(item => ({
                dlExpdNatCd: item.dlExpdNatCd, 
                dlExpdRegnCd: item.dlExpdRegnCd, 
                natNm: item.natNm,
                
                langs: [], // langCd
            }));
        } ,
    });

    // 언어코드 리스트
    const langCd = useQuery([API.langMsts,{}], () => getData(API.langMsts, {}), {
        enabled: !!natlCd.data,
        select: data => { 
            return data.map(item => ({
                dlExpdRegnCd: item.dlExpdRegnCd, 
                langCd: item.langCd, 
                langCdNm: item.langCdNm, 
                regnNm: item.regnNm
            })); 
        },
    });

    const [natlList, setNatlList] = useState();
    const [langList, setLangList] = useState();
    const [filteredLangList, setFilteredLangList] = useState();

    useEffect(()=>{
        if(queryResult.isSuccess && natlCd.data && langCd.data){

            const natlLangList = queryResult.data.natlLangList;
            // 국가코드목록에 언어코드목록 넣기
            for(let i=0; i<natlCd.data.length; i++){
                for(let k=0; k<natlLangList.length; k++){
                    if(natlCd.data[i].dlExpdNatCd === natlLangList[k].DL_EXPD_NAT_CD){
                        natlCd.data[i].langs = natlLangList[k].LANG_CD.split(',')
                    }
                }
            }
            setNatlList(natlCd.data);
            
            // 언어코드목록
            setLangList(langCd.data);
            setFilteredLangList(langCd.data);  // 언어코드목록 필터링(VIEW용)
        }
    },[natlCd.status, langCd.status, queryResult.status]);


    // [<<] 언어코드 이동 
    const langAddEvnt = () => {
        const langRows = langGrid.current.api.getSelectedRows();
        const natlRows = natlGrid.current.api.getSelectedRows();

        if(langRows.length === 0 ){
            confirmAlert({
                closeOnClickOutside: false,
                customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}  title={"알림"} msg={"언어를 선택해주세요"}  />
            });
        }else if(natlRows.length === 0){
            confirmAlert({
                closeOnClickOutside: false,
                customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}  title={"알림"} msg={"국가를 선택해주세요"}  />
            });
        }else{
            // const langs = langRows.map(item => ({langCd: item.langCd, langCdNm: item.langCdNm}));
            let langs = langRows.map(item => item.langCd);
            // console.log("langs",langs);
            // console.log('natlRows',natlRows)
            // langs=["AS","AR"]

            setNatlList(natlList.map(m => natlRows.find(f => f.dlExpdNatCd === m.dlExpdNatCd) ? {...m, langs: langs} : m));
        }
    
    }

    // [>>] 지역코드 이동 - 언어코드 삭제후, 언어그리드 필터링
    const natlAddEvnt = () => {

        // 선택된 국가그리드 언어코드 삭제
        const natlRows = natlGrid.current.api.getSelectedRows();
        setNatlList(natlList.map(m => natlRows.find(f => f.dlExpdNatCd === m.dlExpdNatCd) ? {...m, langs: []} : m));
    }
    useEffect(() => {
        // 언어그리드 필터링
        if(natlGrid && natlGrid.current && natlGrid.current.api && natlGrid.current.api.getRenderedNodes().length > 0){
            onSelectionChanged();
        }
    },[natlList])



    //차종코드 저장
    const vehlMgmtMutate = useMutation((params => postData(API.vehlMgmt, params, CONSTANTS.update)),{
        onSuccess: res => {
            if(res.resultCode === 200){ //데이터 정상처리
                if(res.mdyChk==='Y'){
                    confirmAlert({
                        closeOnClickOutside: false,
                        customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}   title={"알림"} 
                        msg={"저장이 완료되었습니다."}   />
                    });
                }
                else if(res.mdyChk==='P'){
                    
                   
                    confirmAlert({
                        closeOnClickOutside: false,
                        customUI: ({onClose}) => <ConfirmAlert onClose={onClose}  msg={"저장이 완료되었습니다.<br />등록된 차종의 연식관리가 필요합니다.<br />연식관리로 이동하시려면 확인 버튼을 눌러주세요."} 
                        
                        onOk={onOk} />
                    });
                }
                queryClient.invalidateQueries(); //모든 쿼리 캐시 초기화 
                onHide(); // 창닫기 & refetch
            }else{ //에러 발생
                confirmAlert({
                    closeOnClickOutside: false,
                    customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}  title={"알림"} 
                    msg={" 에러가 발생했습니다.<br />관리자에게 문의해주세요."}  />
                });
            }
            setSubmitButton(false);
        }
    });

       //params = 연식쪽 조회조건 매핑시키기
       const onOk = () => {
        //코드에 따른 페이지 이동
            console.log("vehlMgmtMutate.variables.qltyVehlCd ",formValue.qltyVehlCd )
            console.log("vehlMgmtMutate.variables.dlExpdPdiCd",formValue.qltyVehlCd )
            setQltyVehlCd(formValue && formValue.qltyVehlCd );
            setDlExpdPdiCd(formValue && formValue.dlExpdPdiCd);
        setSubmitButton(true);
        onChange()
        
    }
    // Form 정의
    const containerRef = React.useRef();
    const formRef = React.useRef();
    const [formError, setFormError] = React.useState({});
    const [saveRegnList, setSaveRegnList] = React.useState([]);
    const [formValue, setFormValue] = React.useState({
        qltyVehlCd: '',             // 차종코드
        mdlMdyCd: '',
        qltyVehlNm: '',             // 차종
        blnsCoCd: '',               // 회사코드
        dlExpdPacScnCd: '',         // 승상구분
        dlExpdPdiCd: '',            // PDI코드
        useYn:'',                   // 사용유무
        dytmPlnCd:'',               // APS
        prdnMstCd:'',               // 생산
        bomVehlCd:'',               // BOM
        saleVehlCd:'',              // 판매
        yongVehlCd: '',

        regn01:'',
        regn02:'',
        regn03:'',
        regn04:'',
        regn05:'',
        regn06:'',
        regn07:'',
        regn08:'',
        // 담당자정보
        usrArray01:'',              // HMC,KMC
        usrArray03:'',              // 외주제작사
        usrArray04:'',              // 인쇄업체
        usrArray06:'',              // PDI
        usrArray05:'',              // 용산

        chrgList: [],
        regnDlpvList : []           // 연식관계정보 (지역) - 저장용 regnCd, MdlRelCd
    });   

    


    useEffect(() => {
        if(queryResult.isSuccess && queryResult.data){
            const vehlInfo  = queryResult.data.vehlMgmtInfo;
            const data  = queryResult.data;

            console.log("data",data);
            const obj = {
                qltyVehlCd: vehlInfo.qltyVehlCd || '',            // 차종코드
                mdlMdyCd : vehlInfo.mdlMdyCd || '',               // 연식
                qltyVehlNm: escapeCharChange(vehlInfo.qltyVehlNm) || '',            // 차종
                blnsCoCd: vehlInfo.blnsCoCd || '',                // 회사코드
                dlExpdPacScnCd: vehlInfo.dlExpdPacScnCd || '',    // 승상구분
                dlExpdPdiCd: vehlInfo.dlExpdPdiCd || '',          // PDI코드
                useYn:vehlInfo.useYn || '',                       // 사용유무
                dytmPlnCd:vehlInfo.dytmPlnCd || '',               //APS
                prdnMstCd:vehlInfo.prdnMstCd || '',               //생산
                bomVehlCd:vehlInfo.bomVehlCd || '',               //BOM
                saleVehlCd:vehlInfo.saleVehlCd || '',              //판매
                yongVehlCd:vehlInfo.yongVehlCd || '',              //용산
                regn01 : vehlInfo.regn01 || '',                  //regn01
                regn02 : vehlInfo.regn02 || '',                  //regn02
                regn03 : vehlInfo.regn03 || '',                  //regn03
                regn04 : vehlInfo.regn04 || '',                  //regn04
                regn05 : vehlInfo.regn05 || '',                  //regn05
                regn06 : vehlInfo.regn06 || '',                  //regn06
                regn07 : vehlInfo.regn07 || '',                  //regn07
                regn08 : vehlInfo.regn08 || '',                  //regn08

                // 담당자정보
                usrArray01: data.usrList01.map(d => d.userNm).join(','),              //hmc담당자
                usrArray03: data.usrList03.map(d => d.userNm).join(','),              //외주제작사
                usrArray04: data.usrList04.map(d => d.userNm).join(','),              //인쇄업체(세원)
                usrArray05: data.usrList05.map(d => d.userNm).join(','),               //PDI
                usrArray06: data.usrList06.map(d => d.userNm).join(','),               //PDI
                

                regnDlpvList: data.regnDlpvList,    // 연식관계정보 (지역) - 저장용
            }
             setFormValue(obj);

             setUsrList01(data.usrList01)//hmc,kmc
             setUsrList03(data.usrList03)//외주제작사
             setUsrList04(data.usrList04)//pdi
             setUsrList05(data.usrList05)//인쇄
             setUsrList06(data.usrList06)//용산
             
        }
    },[queryResult.status]);

    const [langCopyPop, setLangCopyPop] = useState(false);
    const [vehlPersonPop, setVehlPersonPop] = useState(false);
    const [usrList01, setUsrList01] = useState([]); //담당자01
    const [usrList03, setUsrList03] = useState([]); //담당자02
    const [usrList04, setUsrList04] = useState([]); //담당자03
    const [usrList05, setUsrList05] = useState([]); //담당자04
    const [usrList06, setUsrList06] = useState([]); //담당자04
    
    const [chrgList, setChrgList] = useState({}); //팝업에 보내줄 파라미터 저장 변수

    const [compGbn, setCompGbn] = useState({blnsCoCd:""});

    const usrEvent= (param) =>{
        setVehlPersonPop(true)
        
        setCompGbn({grpCd:param}) // '01', '03'. '04'. '06'
        
        if(param === '101' ) setChrgList(usrList01.map(d => d.userEeno));
        else if(param === '103' ) setChrgList(usrList03.map(d => d.userEeno));
        else if(param === '104' ) setChrgList(usrList04.map(d => d.userEeno));
        else if(param === '105' ) setChrgList(usrList05.map(d => d.userEeno));
        else if(param === '106' ) setChrgList(usrList06.map(d => d.userEeno));
        
    }


    const onChangeUsrList = (grpCd, arr) => {
        
        if(grpCd === "101"){ // HMC
            setFormValue(p => ({...p, usrArray01: arr.map(item => item.userNm).join(',')}));
            setUsrList01(arr);
        }else if(grpCd === "103"){ //외주제작사
            setFormValue(p => ({...p, usrArray03: arr.map(item => item.userNm).join(',')}));
            setUsrList03(arr);
        }else if(grpCd === "104"){ //
            setFormValue(p => ({...p, usrArray04: arr.map(item => item.userNm).join(',')}));
            setUsrList04(arr);
        }else if(grpCd === "105"){
            setFormValue(p => ({...p, usrArray05: arr.map(item => item.userNm).join(',')}));
            setUsrList05(arr);
        }else if(grpCd === "106"){
            setFormValue(p => ({...p, usrArray06: arr.map(item => item.userNm).join(',')}));
            setUsrList06(arr);
        }
        
        
    }


    const langCopyEvent = (copyData) => {//언어복사
        if(copyData && natlCd.data && langCd.data){

            const natlLangList = copyData;
            // 국가코드목록에 언어코드목록 넣기
            for(let i=0; i<natlCd.data.length; i++){
                for(let k=0; k<natlLangList.length; k++){
                    if(natlCd.data[i].dlExpdNatCd === natlLangList[k].DL_EXPD_NAT_CD){
                        natlCd.data[i].langs = natlLangList[k].LANG_CD.split(',')
                    }
                }
            }
            setNatlList(natlCd.data);
            
            // 언어코드목록
            setLangList(langCd.data);
            setFilteredLangList(langCd.data); 
        }
    }

    useEffect(()=>{
        if(queryResult.isSuccess && natlCd.data && langCd.data){

            const natlLangList = queryResult.data.natlLangList;

            // 국가코드목록에 언어코드목록 넣기
            for(let i=0; i<natlCd.data.length; i++){
                for(let k=0; k<natlLangList.length; k++){
                    if(natlCd.data[i].dlExpdNatCd === natlLangList[k].DL_EXPD_NAT_CD){
                        natlCd.data[i].langs = natlLangList[k].LANG_CD.split(',')
                    }
                }
            }
            setNatlList(natlCd.data);
            
            // 언어코드목록
            setLangList(langCd.data);
            setFilteredLangList(langCd.data);  // 언어코드목록 필터링(VIEW용)
        }
    },[natlCd.status, langCd.status, queryResult.status]);

    // 국가그리드 태그삭제
    const removeTag = (dlExpdNatCd, langCd) => {
        setNatlList(natlList.map(m => m.dlExpdNatCd === dlExpdNatCd
            // ? {...m, langs: m.langs.filter(f => f.langCd !== langCd)} : m));
            ? {...m, langs: m.langs.filter(item => item !== langCd)} : m));
    };

    // 국가그리드 태그
    const tagRender =(e)=>{
        const list = e.data.langs;
        return <>
            {list.length > 0 && 
                <TagGroup style={{textAlign: 'left'}}>
                    {list.map((m, i) => (
                        <Tag key={i} closable onClose={() => removeTag(e.data.dlExpdNatCd, m)}>{m}</Tag>
                    ))}
                </TagGroup>
            }
        </>
    }

    // 국가그리드 선택이벤트 => 언어그리드 필터링
    const onSelectionChanged  = e => {
        // 국가그리드 선택된
        const natlRows = natlGrid.current.api.getSelectedRows();

        
        if(natlRows.length > 0){
            // const langCdArray =  natlRows.map(m => m.langs.map(m2 => m2.langCd));
            const langCdArray =  natlRows.map(m => m.langs.map(m2 => m2));

            // 중복 언어코드 찾기
            let dupLangCd = [];
            if(langCdArray.length > 0){
                // 배열합치기
                const arr = langCdArray.reduce((acc, cur) => acc.concat(cur));
                // 배열중복횟수
                const result = arr.reduce((accu,curr)=> {
                    accu.set(curr, (accu.get(curr)||0) +1) ;
                    return accu;
                },new Map());
                // 배열 중복회수가 선택된 국가그리드수와 같은가?
                for (let [key, value] of result.entries()) {
                    if(value === natlRows.length)
                        dupLangCd.push(key)
                }
            }

            //  언어그리드 필터링
            if(dupLangCd.length > 0){ // 중복언어코드가 있으면.
                // const filtered = langList.filter(item => !dupLangCd.includes(item.langCd));
                const filtered = langList.filter(item => !dupLangCd.includes(item.langCd));
                setFilteredLangList(filtered)
            }else{
                setFilteredLangList(langList)
            }
        }else{
            setFilteredLangList(langList)
        }

    };

 
    const changeEvent = (regn,e) => {

        const arr = formValue.regnDlpvList.filter(item => item.regnCd !== regn).concat({regnCd: regn, mdlRelCd : e});
        setFormValue(p => ({...p, regnDlpvList: arr}));

    };
 

   
    const columnDefs = [ //그리드 커럼
        {
            checkboxSelection: true,
            headerCheckboxSelection: true,
            spanHeaderHeight: true,
            width:35,
            maxWidth:35,
            minWidth:35,
        },
        {
            headerName: '국가코드',
            field: 'dlExpdNatCd',
            spanHeaderHeight: true,
            maxWidth:100,
            minWidth:70,
            sortable:true,
            filter: 'agTextColumnFilter',
            floatingFilter: true,
            suppressMenu: true,
            filterParams: {
                filterOptions: ['contains'],
            },
           
        },
        {
            headerName: '국가명',
            field: 'natNm',
            maxWidth:130,
            minWidth:130,
            spanHeaderHeight: true,
            filter: 'agTextColumnFilter',
            floatingFilter: true,
            suppressMenu: true,
            filterParams: {
                filterOptions: ['contains'],
            },
            cellRenderer: escapeCharChangeForGrid,
        },
        {
            headerName: '언어',
            field: 'langNms',
            spanHeaderHeight: true,
            minWidth:70,
            cellRenderer: tagRender,
            wrapText: true,
            autoHeight: true,
            align: 'left'
        },    
    ]
   

    const columnDefs2 = [ //언어 그리드
        {
            checkboxSelection: true,
            headerCheckboxSelection: true,
            spanHeaderHeight: true,
            width:35,
            maxWidth:35,
            minWidth:35
        },
        {
            headerName: '언어코드',
            field: 'langCd',
            spanHeaderHeight: true,
            maxWidth:80,
            minWidth:70,
            sortable:true
        },  
        {
            headerName: '언어명',
            field: 'langCdNm',
            minWidth:130,
            spanHeaderHeight: true,
        },
        {
            headerName: '지역',
            field: 'regnNm',
            maxWidth:100,
            minWidth:70,
            spanHeaderHeight: true,
        },    
    ]

    const onFirstDataRendered = (params) => {
        params.api.sizeColumnsToFit();
    };

    
     // 저장버튼 클릭
     const handleSubmit = () => {
        if (!formRef.current.check()) { //validation chk
            return;
        }
        if(usrList01.length === 0 && usrList03.length === 0 && usrList04.length === 0 && usrList06.length === 0){
            confirmAlert({
                closeOnClickOutside: false,
                customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}  title={"알림"} msg={"담당자 정보를 입력해주세요."}  />
            });
            
        }else{
            formValue.usrList01 =  usrList01.map(m => m.userEeno);
            formValue.usrList03 =  usrList03.map(m => m.userEeno);
            formValue.usrList04 =  usrList04.map(m => m.userEeno);
            formValue.usrList05 =  usrList05.map(m => m.userEeno);
            formValue.usrList06 =  usrList06.map(m => m.userEeno);
            formValue.natlList = natlList.filter(f => f.langs.length > 0);
            confirmAlert({
                closeOnClickOutside: false,
                customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}   title={"알림"} 
                msg={"입력된 내용으로 저장하시겠습니까?"}  
                onOk={onSubmitOk}
                />
            });
            
        }
    };
    const onSubmitOk = ()=>{
        
        vehlMgmtMutate.mutate(formValue);
    }

   
    return (
        <div style={{position: 'relative'}}>
            <Form
                ref={formRef}
                checkTrigger="change"
                onChange={setFormValue}
                onCheck={setFormError}
                formValue={formValue}
                model={model}>

                <CustomModal open={show} 
                        title={'차종코드 상세/수정'}
                        size='xl'
                        // handleOk={handleSubmit}
                        handleCancel={onHide} >
                            <div className="grid-wrap">
                                    <div className="grid-btn-wrap">
                                        <div className="left-align">
                                            <div className="sub-title">
                                                <ul>
                                                    <li>기본정보</li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                    <Table className="tbl-hor" bordered>
                                        <colgroup>
                                            <col style={{width:'15%'}}></col>
                                            <col style={{width:'35%'}}></col>
                                            <col style={{width:'15%'}}></col>
                                            <col style={{width:'35%'}}></col>
                                        </colgroup>
                                        <tbody>
                                            <tr>
                                                <th>차종코드</th>
                                                <td>
                                                    <Row className="select-wrap">
                                                        <Col sm={9}>
                                                            <Form.Control name = "qltyVehlCd" size="sm" type="text"  maxLength={4} readOnly/>
                                                        </Col>
                                                        <Col sm={3}>
                                                            <Form.Control name = "mdlMdyCd" size="sm" type="text" readOnly/>
                                                        </Col>
                                                    </Row>
                                                </td>
                                                <th className="essen">차종명</th>
                                                <td><Form.Control name = "qltyVehlNm" size="sm" type="text" placeholder="차종명" /></td>
                                            </tr>
                                            <tr>
                                                <th className="essen">승상구분</th>
                                                <td>
                                                {dlExpdPacScnCombo.isSuccess&&
                                                    <Form.Control container={()=> containerRef.current}  name="dlExpdPacScnCd" size="sm" style={{zIndex: 0}} 
                                                        placeholder={'선택'}
                                                        defaultValue={''}
                                                        accepter={SelectPicker} 
                                                        searchable={false}
                                                        cleanable={false}
                                                        data={dlExpdPacScnCombo.isFetched && dlExpdPacScnCombo.data}
                                                    ></Form.Control>
                                                }
                                                </td>
                                                
                                                <th className="essen" >PDI구분</th>
                                                <td>
                                                    {pdiCombo.isSuccess&&
                                                    <Form.Control name="dlExpdPdiCd" container={()=> containerRef.current}  size="sm" style={{zIndex: 0}} 
                                                        placeholder={'선택'}
                                                        defaultValue={''}
                                                        accepter={SelectPicker} 
                                                        searchable={false}
                                                        cleanable={false}
                                                        data={pdiCombo.isFetched && pdiCombo.data}
                                                    ></Form.Control>
                                                    }
                                                </td>
                                            </tr>
                                            <tr>
                                                <th className="essen">사용여부</th>
                                                <td>
                                                <Form.Control name="useYn" size="sm"   
                                                    container={()=> containerRef.current}
                                                    placeholder={'선택'}
                                                    defaultValue={''}
                                                    accepter={SelectPicker} 
                                                    searchable={false}
                                                    cleanable={false}
                                                    data={[
                                                        {label: '사용', value: 'Y'},
                                                        {label: '미사용', value: 'N'},
                                                    ]}
                                            ></Form.Control>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </Table>

                                    <div className="grid-btn-wrap mt-4">
                                        <div className="left-align">
                                            <div className="sub-title">
                                                <ul>
                                                    <li>연계차종코드</li>
                                                </ul>
                                            </div>
                                        </div>
                                        <div className="right-align">
                                        </div>
                                    </div>
                                    <Table className="tbl-ver" bordered>
                                        <colgroup>
                                            <col style={{width:'20%'}}></col>
                                            <col style={{width:'20%'}}></col>
                                            <col style={{width:'20%'}}></col>
                                            <col style={{width:'20%'}}></col>
                                            <col style={{width:'20%'}}></col>
                                        </colgroup>
                                        <thead>
                                            <tr>
                                                <th>APS</th>
                                                <th>생산</th>
                                                <th>BOM</th>
                                                <th>판매</th>
                                                <th>용산</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                <td><Form.Control name="dytmPlnCd" size="sm" type="text" placeholder="" /></td>
                                                <td><Form.Control name="prdnMstCd" size="sm" type="text" placeholder="" /></td>
                                                <td><Form.Control name="bomVehlCd" size="sm" type="text" placeholder=""/></td>
                                                <td><Form.Control name="saleVehlCd" size="sm" type="text" placeholder=""/></td>
                                                <td><Form.Control name="yongVehlCd" size="sm" type="text" placeholder=""/></td>
                                            </tr>
                                        </tbody>
                                    </Table>


                                    <div className="grid-btn-wrap mt-4">
                                        <div className="left-align">
                                            <div className="sub-title">
                                                <ul>
                                                    <li>연식관계 정보</li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                    <Table className="tbl-ver" bordered>
                                        <colgroup>
                                            <col style={{width:'100px'}}></col>
                                            <col style={{width:''}}></col>
                                            <col style={{width:'100px'}}></col>
                                            <col style={{width:''}}></col>
                                        </colgroup>
                                        <thead>
                                            <tr>
                                                {regnList.data && regnList.data.map((item, index)=>(<th key={index} >{item.label}</th>)) }
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr>
                                            {regnList.data && regnList.data.map((item,index) =>(<td  key={index}>
                                                {dlExpdPrvsCombo.data && 
                                                    <Form.Control name={"regn"+item.value} key={index} container={()=> containerRef.current}  size="sm" style={{zIndex: 0}} 
                                                        placeholder={'선택'}
                                                        defaultValue={''}
                                                        accepter={SelectPicker} 
                                                        searchable={false}
                                                        cleanable={false}
                                                        data={dlExpdPrvsCombo.isFetched && dlExpdPrvsCombo.data}
                                                        onChange={(e) => changeEvent(item.value,e)}
                                                    ></Form.Control>
                                                }
                                            </td>))
                                            }
                                            </tr>
                                        </tbody>
                                    </Table>
                                    <div className="grid-btn-wrap mt-4">
                                        <div className="left-align">
                                            <div className="sub-title">
                                                <ul>
                                                    <li>
                                                        {/* {usrList01 && usrList01.userEeno} */}
                                                        담당자 정보</li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                    <Table className="tbl-ver" bordered>
                                        <colgroup>
                                            <col style={{width:'20%'}}></col>
                                            <col style={{width:'20%'}}></col>
                                            <col style={{width:'20%'}}></col>
                                            <col style={{width:'20%'}}></col>
                                            <col style={{width:'20%'}}></col>
                                        </colgroup>
                                        <thead>
                                            <tr>
                                                <th>{coCd =='01'? 'HMC':'KMC'}</th>
                                                <th>외주제작사</th>
                                                <th>PDI</th>
                                                <th>인쇄업체</th>
                                                <th>용산</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                <td>
                                                    <InputGroup inside >
                                                        <Form.Control name="usrArray01" style={{fontSize:'12px',height:'24px'}} />
                                                        <InputGroup.Button  style={{height:'24px'}} onClick={() => usrEvent("101")}>
                                                        <SearchIcon />
                                                        </InputGroup.Button>
                                                    </InputGroup>
                                                </td>
                                                <td>
                                                    <InputGroup inside >
                                                        <Form.Control name="usrArray03" style={{fontSize:'12px',height:'24px'}} />
                                                        <InputGroup.Button style={{height:'24px'}} onClick={() => usrEvent("103")}>
                                                        <SearchIcon />
                                                        </InputGroup.Button>
                                                    </InputGroup>
                                                </td>
                                                <td>
                                                    <InputGroup inside >
                                                        <Form.Control name="usrArray04" style={{fontSize:'12px',height:'24px'}} />
                                                        <InputGroup.Button style={{height:'24px'}} onClick={() => usrEvent("104")}>
                                                        <SearchIcon />
                                                        </InputGroup.Button>
                                                    </InputGroup>
                                                </td>
                                                <td>
                                                    <InputGroup inside >
                                                        <Form.Control name="usrArray05" style={{fontSize:'12px',height:'24px'}} />
                                                        <InputGroup.Button style={{height:'24px'}} onClick={() => usrEvent("105")}>
                                                        <SearchIcon />
                                                        </InputGroup.Button>
                                                    </InputGroup>
                                                </td>
                                                <td>
                                                    <InputGroup inside >
                                                        <Form.Control name="usrArray06" style={{fontSize:'12px',height:'24px'}} />
                                                        <InputGroup.Button style={{height:'24px'}} onClick={() => usrEvent("106")}>
                                                        <SearchIcon />
                                                        </InputGroup.Button>
                                                    </InputGroup>
                                                </td>
                                              
                                            </tr>
                                        </tbody>
                                    </Table>
                                    <div className="grid-btn-wrap mt-4">
                                        <div className="left-align">
                                            <div className="sub-title">
                                                <ul>
                                                    <li>적용 국가 및 언어</li>
                                                </ul>
                                            </div>
                                        </div>
                                        <div className="right-align">
                                            <Button variant="outline-secondary" size="sm" onClick={() => setLangCopyPop(true)}>언어복사</Button>{' '}
                                        </div>
                                    </div>
                                    <Table className="tbl-hor" bordered>
                                        <colgroup>
                                            <col style={{width:'120px'}}></col>
                                            <col style={{width:''}}></col>
                                            <col style={{width:''}}></col>
                                            <col style={{width:''}}></col>
                                        </colgroup>
                                        <tbody>
                                            <tr>
                                                <th>적용 국가 및 언어</th>
                                                <td colSpan="3">
                                                    <div className="grid-double">
                                                        <div className="ag-theme-alpine" style={{height:300, width:'60%'}}>
                                                            <AgGridReact
                                                                ref={natlGrid} 
                                                                rowData={natlList}
                                                                columnDefs={columnDefs}
                                                                defaultColDef={defaultColDef}
                                                                rowSelection={'multiple'}
                                                                suppressRowClickSelection= {true} 
                                                                onFirstDataRendered={onFirstDataRendered}
                                                                suppressSizeToFit={true}    
                                                                onGridSizeChanged={onFirstDataRendered}     

                                                                onSelectionChanged ={onSelectionChanged }
                                                                >
                                                            </AgGridReact>
                                                        </div>
                                                        <div className="grid-move-btn" style={{marginLeft:"5px"}}>
                                                            <Button className="lang-add-btn" variant="outline-secondary" size="sm" onClick={langAddEvnt}> <PagePreviousIcon/> </Button>
                                                            {/* <Button className="lang-dlt-btn" variant="outline-secondary" size="sm" onClick={natlAddEvnt}> <PageNextIcon/></Button> */}
                                                        </div>
                                                        <div className="ag-theme-alpine" style={{height:300, width:'40%' ,marginLeft:"5px"}}>
                                                            <AgGridReact
                                                                ref={langGrid} 
                                                                rowData={filteredLangList}
                                                                columnDefs={columnDefs2}
                                                                defaultColDef={defaultColDef}
                                                                rowSelection={'multiple'}
                                                                suppressRowClickSelection= {true} 
                                                                onFirstDataRendered={onFirstDataRendered}
                                                                suppressSizeToFit={true}    
                                                                onGridSizeChanged={onFirstDataRendered}     
                                                                >
                                                            </AgGridReact>
                                                        </div>
                                                    </div>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </Table>
                                </div> 
                        <div className='modal-footer'>
                            <Button variant="light" size="md" onClick={onHide}>취소</Button>
                            {isApi(API.vehlMgmt, 'POST') &&<Button variant="primary" size="md" disabled={submitButton}  onClick={handleSubmit} >저장</Button>}
                        </div>
                </CustomModal>
            </Form>

            {langCopyPop && <LangCopy show={langCopyPop} onHide={() => setLangCopyPop(false)}  langCopyEvent={langCopyEvent}/>}
            {vehlPersonPop && <VehlPerson show={vehlPersonPop} onHide={() => setVehlPersonPop(false) } chrgList={chrgList} onChangeUsrList={onChangeUsrList} param={compGbn}/>}
            </div>
    );

};
export default VehlCodeUpdate;