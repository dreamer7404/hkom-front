import React, {useState, useMemo, useRef,useEffect, useCallback} from 'react';
import {Button, Modal, Table} from 'react-bootstrap';
import { AgGridReact } from 'ag-grid-react';
import { API} from '../../../../utils/constants';
import { getData } from '../../../../utils/async';
import { useQuery} from 'react-query';
import { GridApi } from 'ag-grid-community';
import { escapeCharChangeForGrid } from '../../../../utils/commUtils';
import CustomModal from '../../../Common/CustomModal';
import { confirmAlert } from 'react-confirm-alert'; // Import
import ConfirmAlert from '../../../Common/ConfirmAlert';
import { select } from 'async';
const VehlPersonSearch = ({show, onHide, param,chrgList, onChangeUsrList}) => {
    const usrGrid = useRef();
    const defaultColDef = useMemo(() => {
        return {
            initialWidth: 90,
            resizable:true,
            sortable:true,
            minWidth:70
        };
    }, []);

    //처음 팝업 들어왔을때는 빈값, 기존에 선택한 값이 있을 경우 chkYn을 'Y'로 바꿈
    //모달창 그리드 조회
    const usrData = useQuery([API.userMgmtPop,param], () => getData(API.userMgmtPop, param),{
        
        // select: data => data.map(item => ({...item, chkYn: chrgList && chrgList.find(f => f === item.userEeno) ? 'Y' : 'N'}))
    })
        
    const columnDefs = [
        {
            checkboxSelection: true,
            headerCheckboxSelection: true,
            spanHeaderHeight: true,
            width:35,
            maxWidth:35,
            minWidth:35
        },
        {
            headerName: '회사구분',
            field: 'coNm',
            spanHeaderHeight: true,
        },
        {
            headerName: '부서명',
            field: 'deptNm',
            spanHeaderHeight: true,
            cellRenderer: data => escapeCharChangeForGrid(data)
        },
        {
            headerName: '아이디',
            field: 'userEeno',
            spanHeaderHeight: true,
        },
        {
            headerName: '이름',
            field: 'userNm',
            spanHeaderHeight: true,
        }   
    ]

    


    const saveEvent = () =>{
        let selectedRows = usrGrid.current.api.getSelectedRows();
        
        // if(selectedRows.length<1){
        //     confirmAlert({
        //         closeOnClickOutside: false,
        //         customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}  title={"알림"} msg={"담당자를 선택해주세요."}  />
        //     });
        // }else{
            onChangeUsrList(selectedRows);
            onHide();
        // }
        
    }


    const onFirstDataRendered = (params) => {
        params.api.sizeColumnsToFit();

        let grid = usrGrid.current.api;
        grid.forEachNode((node) =>
            // console.log(node.data.userEeno)
            node.setSelected(!!node.data && node.data.chkYn === 'Y' )
        )
    };

    return (
        <>
        <CustomModal open={show} 
                    title={'담당자 검색'}
                    size='md'
                    // handleOk={handleSubmit}
                    handleCancel={onHide} 
        >
         
                          <div className="ag-theme-alpine" style={{height:300}}>
                                <AgGridReact
                                    ref={usrGrid} 
                                    rowData={usrData && usrData.data}
                                    columnDefs={columnDefs}
                                    defaultColDef={defaultColDef}
                                    rowSelection={'multiple'}
                                    suppressRowClickSelection= {true} 
                                    onFirstDataRendered={onFirstDataRendered}
                                    suppressSizeToFit={true}    
                                    onGridSizeChanged={onFirstDataRendered}     
                                ></AgGridReact>
                            </div>
                    
                 
                    <div className='modal-footer'>
                            <Button variant="light" size="md" onClick={onHide}>취소</Button>
                            <Button variant="primary" size="md" onClick={()=>saveEvent()}>저장</Button>
                        </div> 
            </CustomModal>
        </>
    );

};
export default VehlPersonSearch;