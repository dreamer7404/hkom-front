/* eslint-disable react-hooks/exhaustive-deps */
/* eslint-disable no-undef */
import React, {useState, useMemo,useEffect, useRef} from 'react';
import {Row, Col, Button, Modal, Table} from 'react-bootstrap';
import SearchIcon from '@rsuite/icons/Search';
import PageNextIcon from '@rsuite/icons/PageNext';
import PagePreviousIcon from '@rsuite/icons/PagePrevious';
import { InputGroup, Form, SelectPicker, Schema, TagGroup,Tag } from 'rsuite';
import { AgGridReact } from 'ag-grid-react';
import { API,CONSTANTS} from '../../../../utils/constants';
import LangCopy from './LangCopy';
import VehlPerson from './VehlPerson';
import { getData,postData } from '../../../../utils/async';
import { useQuery, useMutation, useQueryClient } from 'react-query';

import { confirmAlert } from 'react-confirm-alert'; // Import
import ConfirmAlert from '../../../Common/ConfirmAlert';

import { escapeCharChange, escapeCharChangeForGrid } from '../../../../utils/commUtils';
import CustomModal from '../../../Common/CustomModal';
import useStore from '../../../../utils/store';
const { StringType} = Schema.Types;

const model = Schema.Model({
    qltyVehlCd: StringType().isRequired('차종코드 및 연식을 입력해주세요.')
                            .pattern(/^[A-Z0-9]*$/, '영문(대),숫자로 입력해주세요'),
    qltyVehlNm: StringType().isRequired('차종명을 입력해주세요.')
                            .pattern(/^[가-힣a-zA-Z0-9()]+$/, '특수문자는 _(). 만 입력가능합니다')      
                            .rangeLength(2, 30, '2-30자로 입력해주세요'),
    mdlMdyCd: StringType().isRequired('차종코드 및 연식을 입력해주세요.'),
    dlExpdPacScnCd: StringType().isRequired('승상구분을 선택해주세요.'),
    dlExpdPdiCd: StringType().isRequired('PDI구분을 선택해주세요.'),
    useYn: StringType().isRequired('사용유무를 선택해 주세요.')
});
const VehlCodeAdd = ({show, onHide, onChange }) => {
    const queryClient = useQueryClient();
    const natlGrid = useRef();
    const langGrid = useRef();
    const {setVehlInfo,coCd,setQltyVehlCd,setDlExpdPdiCd} = useStore();  // 조회키워드 가져오기
    const [submitButton, setSubmitButton] = useState(false);
    const defaultColDef = useMemo(() => {
        return {
            initialWidth: 90,
            resizable:true,
        };
    }, []);
    
    
     //승상코드구분 콤보박스
    const pacScnParam = {dlExpdGCd: CONSTANTS.grpCdPacScn};
    const dlExpdPacScnCombo = useQuery([API.codeCombo,pacScnParam], () => getData(API.codeCombo,pacScnParam)) 
    //PDI구분 콤보박스
    const pdiCombo = useQuery([API.pdiCombo], () => getData(API.pdiCombo), {
        select: data => data.map((item) => ({ label: escapeCharChange(item.dlExpdPrvsNm), value: item.dlExpdPdiCd }))
    }); 
    

    const dlExpdPrvsCombo = useQuery([API.dlExpdPrvsCombo], () => getData(API.dlExpdPrvsCombo), {
        select: data => data.map((item) => ({ label: item.dlExpdPrvsNm, value: item.dlExpdPrvsCd }))
    }); 
     // 지역데이터 가져오기
    const paramsCo = {dlExpdGCd: CONSTANTS.grpCdRegn};
    const regnList = useQuery([API.codeCombo,paramsCo], () => getData(API.codeCombo,paramsCo)) 

    // 국가코드 리스트
    const natlCd = useQuery([API.natlMsts,{}], () => getData(API.natlMsts, {}), {
        select: data => {
            return data.map(item => ({
                dlExpdNatCd: item.dlExpdNatCd, 
                dlExpdRegnCd: item.dlExpdRegnCd, 
                natNm: item.natNm,
                
                langs: [], // langCd
            }));
        } ,
    });

    // 언어코드 리스트
    const langCd = useQuery([API.langMsts,{}], () => getData(API.langMsts, {}), {
        select: data => { 
            return data.map(item => ({
                dlExpdRegnCd: item.dlExpdRegnCd, 
                langCd: item.langCd, 
                langCdNm: item.langCdNm, 
                regnNm: item.regnNm
            })); 
        },
    });

    const [natlList, setNatlList] = useState();
    const [langList, setLangList] = useState();
    
    const [filteredLangList, setFilteredLangList] = useState();

    useEffect(()=>{
        if(natlCd.data && langCd.data){
            // 국가코드목록에 언어코드목록 넣기
            setNatlList(natlCd.data);
            
            // 언어코드목록
            setLangList(langCd.data);
            setFilteredLangList(langCd.data);  // 언어코드목록 필터링(VIEW용)
        }
    },[natlCd.status, langCd.status]);

    const langCopyEvent = (copyData) => {//언어복사
        if(copyData && natlCd.data && langCd.data){

            const natlLangList = copyData;
            // 국가코드목록에 언어코드목록 넣기
            for(let i=0; i<natlCd.data.length; i++){
                for(let k=0; k<natlLangList.length; k++){
                    if(natlCd.data[i].dlExpdNatCd === natlLangList[k].DL_EXPD_NAT_CD){
                        natlCd.data[i].langs = natlLangList[k].LANG_CD.split(',')
                    }
                }
            }
            setNatlList(natlCd.data);
            
            // 언어코드목록
            setLangList(langCd.data);
            setFilteredLangList(langCd.data); 
        }
    }
    // [<<] 언어코드 이동 
    const langAddEvnt = () => {
        const langRows = langGrid.current.api.getSelectedRows();
        const natlRows = natlGrid.current.api.getSelectedRows();

        if(langRows.length === 0 ){
            confirmAlert({
                closeOnClickOutside: false,
                customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}  title={"알림"} msg={"언어를 선택해주세요"}  />
            });
        }else if(natlRows.length === 0){
            confirmAlert({
                closeOnClickOutside: false,
                customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}  title={"알림"} msg={"국가를 선택해주세요"}  />
            });
        }else{
            // const langs = langRows.map(item => ({langCd: item.langCd, langCdNm: item.langCdNm}));
            const langs = langRows.map(item => item.langCd);
            setNatlList(natlList.map(m => natlRows.find(f => f.dlExpdNatCd === m.dlExpdNatCd) ? {...m, langs: langs} : m));
        }
    
    }

    // [>>] 지역코드 이동 - 언어코드 삭제후, 언어그리드 필터링
    const natlAddEvnt = () => {

        // 선택된 국가그리드 언어코드 삭제
        const natlRows = natlGrid.current.api.getSelectedRows();
        setNatlList(natlList.map(m => natlRows.find(f => f.dlExpdNatCd === m.dlExpdNatCd) ? {...m, langs: []} : m));
    }
    useEffect(() => {
        // 언어그리드 필터링
        if(natlGrid && natlGrid.current && natlGrid.current.api && natlGrid.current.api.getRenderedNodes().length > 0){
            onSelectionChanged();
        }
    },[natlList])


    //차종코드 저장
    const vehlMgmtMutate = useMutation((params => postData(API.vehlMgmt, params, CONSTANTS.insert)),{
        onSuccess: res => {
            if(res.resultCode === 200){ //데이터 정상처리
                if(res.mdyChk==='Y'){
                    confirmAlert({
                        closeOnClickOutside: false,
                        customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}   title={"알림"} 
                        msg={"저장이 완료되었습니다."}   />
                    });
                }
                else if(res.mdyChk==='P'){
                    confirmAlert({
                        closeOnClickOutside: false,
                        customUI: ({onClose}) => <ConfirmAlert onClose={onClose}  msg={"저장이 완료되었습니다.<br />등록된 차종의 연식관리가 필요합니다.<br />연식관리로 이동하시려면 확인 버튼을 눌러주세요."} 
                        onOk={onOk} />
                    });
                }
             
                onHide(); // 창닫기 & refetch
                queryClient.invalidateQueries(); //모든 쿼리 캐시 초기화 
            }else if(res.resultCode === 300){
                confirmAlert({
                    closeOnClickOutside: false,
                    customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}  title={"알림"} 
                    msg={"차종코드가 이미 사용중 입니다."}  />
                });
            }else{ //에러 발생
                confirmAlert({
                    closeOnClickOutside: false,
                    customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}  title={"알림"} 
                    msg={" 에러가 발생했습니다.<br />관리자에게 문의해주세요."}  />
                });
            }
            setSubmitButton(false);
        }
    });

    

    
    // Form 정의
    const containerRef = React.useRef();
    const formRef = React.useRef();
    const [formError, setFormError] = React.useState({});
    const [saveRegnList, setSaveRegnList] = React.useState([]);
    const [formValue, setFormValue] = React.useState({
        qltyVehlCd: '',             // 차종코드
        qltyVehlNm: '',             // 차종
        blnsCoCd: '',               // 회사코드
        mdlMdyCd:'',
        dlExpdPacScnCd: '',      // 승상구분
        dlExpdPdiCd: '',            // PDI코드
        useYn:'',                   // 사용유무
        dytmPlnCd:'',               //APS
        prdnMstCd:'',               //생산
        bomVehlCd:'',               //BOM
        saleVehlCd:'',              //판매
        yongVehlCd:'',
        usrArray01:'',              //HMC,KMC
        usrArray03:'',              //외주제작사
        usrArray04:'',              //pdi
        usrArray05:'',              //인쇄
        usrArray06:'',              //용산
        
        chrgList: [],
        regnDlpvList : []           // 연식관계정보 (지역)
        
    });  
    
    const [langCopyPop, setLangCopyPop] = useState(false);
    const [vehlPersonPop, setVehlPersonPop] = useState(false);
    const [usrList01, setUsrList01] = useState([]); //담당자01
    const [usrList03, setUsrList03] = useState([]); //담당자02
    const [usrList04, setUsrList04] = useState([]); //담당자03
    const [usrList05, setUsrList05] = useState([]); //담당자04
    const [usrList06, setUsrList06] = useState([]); //담당자04
    const [chrgList, setChrgList] = useState({}); //팝업에 보내줄 파라미터 저장 변수

    const [compGbn, setCompGbn] = useState({grpCd:""});

    const usrEvent= (param) =>{
        setVehlPersonPop(true)
        setCompGbn({grpCd:param}) // '01', '03'. '04'. '06'
        
        if(param === '101' ) setChrgList(usrList01.map(d => d.userEeno));
        else if(param === '103' ) setChrgList(usrList03.map(d => d.userEeno));
        else if(param === '104' ) setChrgList(usrList04.map(d => d.userEeno));
        else if(param === '105' ) setChrgList(usrList05.map(d => d.userEeno));
        else if(param === '106' ) setChrgList(usrList06.map(d => d.userEeno));
    }

    const onChangeUsrList = (grpCd, arr) => {
        
        if(grpCd === "101"){ // HMC
            setFormValue(p => ({...p, usrArray01: arr.map(item => item.userNm).join(',')}));
            setUsrList01(arr);
        }else if(grpCd === "103"){ //인쇄업체
            setFormValue(p => ({...p, usrArray03: arr.map(item => item.userNm).join(',')}));
            setUsrList03(arr);
        }else if(grpCd === "104"){
            setFormValue(p => ({...p, usrArray04: arr.map(item => item.userNm).join(',')}));
            setUsrList04(arr);
        }else if(grpCd === "105"){
            setFormValue(p => ({...p, usrArray05: arr.map(item => item.userNm).join(',')}));
            setUsrList05(arr);
        }else if(grpCd === "106"){
            setFormValue(p => ({...p, usrArray06: arr.map(item => item.userNm).join(',')}));
            setUsrList06(arr);
        }
    }


    //params = 연식쪽 조회조건 매핑시키기
    const onOk = () => {
        setQltyVehlCd(formValue && formValue.qltyVehlCd );
        setDlExpdPdiCd(formValue && formValue.dlExpdPdiCd);
        //코드에 따른 페이지 이동
        onChange()
    }

    // 국가그리드 태그삭제
    const removeTag = (dlExpdNatCd, langCd) => {
        setNatlList(natlList.map(m => m.dlExpdNatCd === dlExpdNatCd
            // ? {...m, langs: m.langs.filter(f => f.langCd !== langCd)} : m));
            ? {...m, langs: m.langs.filter(item => item !== langCd)} : m));
    };

    // 국가그리드 태그
    const tagRender =(e)=>{
        const list = e.data.langs;
        return <>
            {list.length > 0 && 
                <TagGroup style={{textAlign: 'left'}}>
                    {list.map((m, i) => (
                        <Tag key={i} closable onClose={() => removeTag(e.data.dlExpdNatCd, m)}>{m}</Tag>
                    ))}
                </TagGroup>
            }
        </>
    }

    // 국가그리드 선택이벤트 => 언어그리드 필터링
    const onSelectionChanged  = e => {
        // 국가그리드 선택된
        const natlRows = natlGrid.current.api.getSelectedRows();

        
        if(natlRows.length > 0){
            // const langCdArray =  natlRows.map(m => m.langs.map(m2 => m2.langCd));
            const langCdArray =  natlRows.map(m => m.langs.map(m2 => m2));

            // 중복 언어코드 찾기
            let dupLangCd = [];
            if(langCdArray.length > 0){
                // 배열합치기
                const arr = langCdArray.reduce((acc, cur) => acc.concat(cur));
                // 배열중복횟수
                const result = arr.reduce((accu,curr)=> {
                    accu.set(curr, (accu.get(curr)||0) +1) ;
                    return accu;
                },new Map());
                // 배열 중복회수가 선택된 국가그리드수와 같은가?
                for (let [key, value] of result.entries()) {
                    if(value === natlRows.length)
                        dupLangCd.push(key)
                }
            }

            //  언어그리드 필터링
            if(dupLangCd.length > 0){ // 중복언어코드가 있으면.
                // const filtered = langList.filter(item => !dupLangCd.includes(item.langCd));
                const filtered = langList.filter(item => !dupLangCd.includes(item.langCd));
                setFilteredLangList(filtered)
            }else{
                setFilteredLangList(langList)
            }
        }else{
            setFilteredLangList(langList)
        }

    };


    const [saveArrayList, setSaveArrayList] = useState([]);
    const changeEvent = (regn,e) => {
        setSaveArrayList(saveArrayList
            .filter(item => item.regnCd !== regn)
            .concat({
                regnCd: regn,
                mdlRelCd : e
            })
        );
        
        setSaveRegnList(p=>({...p,regnCd:regn, mdlRelCd:e}))

    };
    useEffect(() => {
        setFormValue(p=>({...p,
            regnDlpvList:saveArrayList
        }) )

    },[saveArrayList])
   
   

    const columnDefs = [
        {
            checkboxSelection: true,
            headerCheckboxSelection: true,
            spanHeaderHeight: true,
            width:35,
            maxWidth:35,
            minWidth:35
        },
        {
            headerName: '국가코드',
            field: 'dlExpdNatCd',
            spanHeaderHeight: true,
            maxWidth:100,
            minWidth:70,
            sortable:true,
            filter: 'agTextColumnFilter',
            floatingFilter: true,
            suppressMenu: true,
            filterParams: {
                filterOptions: ['contains'],
            }
        },
        {
            headerName: '국가명',
            field: 'natNm',
            maxWidth:130,
            minWidth:130,
            spanHeaderHeight: true,
            filter: 'agTextColumnFilter',
            floatingFilter: true,
            suppressMenu: true,
            filterParams: {
                filterOptions: ['contains'],
            },
            cellRenderer: escapeCharChangeForGrid,
        },
        {
            headerName: '언어',
            field: 'lang',
            minWidth:70,
            spanHeaderHeight: true,
            cellRenderer: tagRender,
               
        },    
    ]
   

    const columnDefs2 = [
        {
            checkboxSelection: true,
            headerCheckboxSelection: true,
            spanHeaderHeight: true,
            width:35,
            maxWidth:35,
            minWidth:35
        },
        {
            headerName: '언어코드',
            field: 'langCd',
            spanHeaderHeight: true,
            maxWidth:80,
            minWidth:70,
            sortable:true
        },  
        {
            headerName: '언어명',
            field: 'langCdNm',
            spanHeaderHeight: true,
            minWidth:130
        },
        {
            headerName: '지역',
            field: 'regnNm',
            maxWidth:100,
            minWidth:70,
            spanHeaderHeight: true,
        },    
    ]

    const onFirstDataRendered = (params) => {
        params.api.sizeColumnsToFit();
    };

    
    
    
    // 저장버튼 클릭
    const handleSubmit = () => {
        if (!formRef.current.check()) { //validation chk
            return;
        }
        if(usrList01.length === 0 && usrList03.length === 0 && usrList04.length === 0 && usrList06.length === 0){
            confirmAlert({
                closeOnClickOutside: false,
                customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}  title={"알림"} msg={"담당자 정보를 입력해주세요."}  />
            });
            
        }else{
            formValue.usrList01 =  usrList01.map(m => m.userEeno);
            formValue.usrList03 =  usrList03.map(m => m.userEeno);
            formValue.usrList04 =  usrList04.map(m => m.userEeno);
            formValue.usrList05 =  usrList05.map(m => m.userEeno);
            formValue.usrList06 =  usrList06.map(m => m.userEeno);
            formValue.natlList = natlList.filter(f => f.langs.length > 0);
            confirmAlert({
                closeOnClickOutside: false,
                customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}   title={"알림"} 
                msg={"입력된 내용으로 저장하시겠습니까?"}  
                onOk={onSubmitOk}
                />
            });
            
            
        }
    };


    const onSubmitOk = ()=>{
        setSubmitButton(true);
        vehlMgmtMutate.mutate(formValue);
    }

    


    return (
        <div style={{position: 'relative'}}>
            <Form
                ref={formRef}
                checkTrigger="change"
                onChange={setFormValue}
                onCheck={setFormError}
                formValue={formValue}
                model={model}>
                
                <CustomModal open={show} 
                        title={'차종코드 등록'}
                        size='xl'
                        // handleOk={handleSubmit}
                        handleCancel={onHide} >
                        
                  
                           <div className="grid-wrap">
                                    <div className="grid-btn-wrap">
                                        <div className="left-align">
                                            <div className="sub-title">
                                                <ul>
                                                    <li>기본정보</li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                     <Table className="tbl-hor" bordered>
                                        <colgroup>
                                            <col style={{width:'15%'}}></col>
                                            <col style={{width:'35%'}}></col>
                                            <col style={{width:'15%'}}></col>
                                            <col style={{width:'35%'}}></col>
                                        </colgroup>
                                        <tbody>
                                            <tr>
                                                <th className="essen">차종코드</th>
                                                <td>
                                                    <Row className="select-wrap">
                                                        <Col sm={9}>
                                                            <Form.Control name = "qltyVehlCd" size="sm" type="text" placeholder="차종코드" maxLength={4} />
                                                        </Col>
                                                        <Col sm={3}>
                                                            <Form.Control name = "mdlMdyCd" size="sm" type="text" placeholder="연식" />
                                                        </Col>
                                                    </Row>
                                                </td>
                                                <th className="essen">차종명</th>
                                                <td><Form.Control name = "qltyVehlNm" size="sm" type="text" placeholder="차종명" /></td>
                                            </tr>
                                            <tr>
                                                <th className="essen">승상구분</th>
                                                <td>
                                                {dlExpdPacScnCombo.isSuccess &&
                                                    <Form.Control container={()=> containerRef.current}  name="dlExpdPacScnCd" size="sm" style={{zIndex: 0}} 
                                                        placeholder={'선택'}
                                                        defaultValue={''}
                                                        accepter={SelectPicker} 
                                                        searchable={false}
                                                        cleanable={false}
                                                        data={dlExpdPacScnCombo.isFetched && dlExpdPacScnCombo.data}
                                                    ></Form.Control>
                                                }
                                                </td>
                                                
                                                <th className="essen" >PDI구분</th>
                                                <td>
                                                    {pdiCombo.isSuccess&&
                                                    <Form.Control name="dlExpdPdiCd" container={()=> containerRef.current}  size="sm" style={{zIndex: 0}} 
                                                        placeholder={'선택'}
                                                        defaultValue={''}
                                                        accepter={SelectPicker} 
                                                        searchable={false}
                                                        cleanable={false}
                                                        data={pdiCombo.isFetched && pdiCombo.data}
                                                    ></Form.Control>
                                                    }
                                                </td>
                                            </tr>
                                            <tr>
                                                <th className="essen">사용여부</th>
                                                <td>
                                                <Form.Control name="useYn" size="sm"   
                                                    container={()=> containerRef.current}
                                                    placeholder={'선택'}
                                                    defaultValue={''}
                                                    accepter={SelectPicker} 
                                                    searchable={false}
                                                    cleanable={false}
                                                    data={[
                                                        {label: '사용', value: 'Y'},
                                                        {label: '미사용', value: 'N'},
                                                    ]}
                                            ></Form.Control>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </Table>


                                    <div className="grid-btn-wrap mt-4">
                                        <div className="left-align">
                                            <div className="sub-title">
                                                <ul>
                                                    <li>연계차종코드</li>
                                                </ul>
                                            </div>
                                        </div>
                                        <div className="right-align">
                                        </div>
                                    </div>
                                    <Table className="tbl-ver" bordered>
                                        <colgroup>
                                            <col style={{width:'20%'}}></col>
                                            <col style={{width:'20%'}}></col>
                                            <col style={{width:'20%'}}></col>
                                            <col style={{width:'20%'}}></col>
                                            <col style={{width:'20%'}}></col>
                                        </colgroup>
                                        <thead>
                                            <tr>
                                                <th>APS</th>
                                                <th>생산</th>
                                                <th>BOM</th>
                                                <th>판매</th>
                                                <th>용산</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                <td><Form.Control name="dytmPlnCd" size="sm" type="text" placeholder="" /></td>
                                                <td><Form.Control name="prdnMstCd" size="sm" type="text" placeholder="" /></td>
                                                <td><Form.Control name="bomVehlCd" size="sm" type="text" placeholder=""/></td>
                                                <td><Form.Control name="saleVehlCd" size="sm" type="text" placeholder=""/></td>
                                                <td><Form.Control name="yongVehlCd" size="sm" type="text" placeholder=""/></td>
                                            </tr>
                                        </tbody>
                                    </Table>


                                    <div className="grid-btn-wrap mt-4">
                                        <div className="left-align">
                                            <div className="sub-title">
                                                <ul>
                                                    <li>연식관계 정보</li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                    <Table className="tbl-ver" bordered>
                                        <colgroup>
                                            <col style={{width:'100px'}}></col>
                                            <col style={{width:''}}></col>
                                            <col style={{width:'100px'}}></col>
                                            <col style={{width:''}}></col>
                                        </colgroup>
                                        <thead>
                                            <tr>
                                                {regnList.data&& regnList.data.map((item, index)=>(<th key={index} >{item.label}</th>)) }
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr>
                                            {regnList.data && regnList.data.map((item,index) =>(<td  key={index}>
                                                   {dlExpdPrvsCombo.data && <Form.Control name={"regn"+item.value} key={index} container={()=> containerRef.current}  size="sm" style={{zIndex: 0}} 
                                                        placeholder={'선택'}
                                                        defaultValue={''}
                                                        accepter={SelectPicker} 
                                                        searchable={false}
                                                        cleanable={false}
                                                        data={dlExpdPrvsCombo.isFetched && dlExpdPrvsCombo.data}
                                                        onChange={(e) => changeEvent(item.value,e)}

                                                    ></Form.Control>
                                                    }
                                                </td>))
                                            }
                                            </tr>
                                        </tbody>
                                    </Table>
                                    <div className="grid-btn-wrap mt-4">
                                        <div className="left-align">
                                            <div className="sub-title">
                                                <ul>
                                                    <li>담당자 정보</li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                    <Table className="tbl-ver" bordered>
                                        <colgroup>
                                            <col style={{width:'20%'}}></col>
                                            <col style={{width:'20%'}}></col>
                                            <col style={{width:'20%'}}></col>
                                            <col style={{width:'20%'}}></col>
                                            <col style={{width:'20%'}}></col>
                                        </colgroup>
                                        <thead>
                                            <tr>
                                                <th>{coCd =='01'? 'HMC':'KMC'}</th>
                                                <th>외주제작사</th>
                                                <th>PDI</th>
                                                <th>인쇄업체</th>
                                                <th>용산</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                <td>
                                                    <InputGroup inside >
                                                        <Form.Control name="usrArray01" style={{fontSize:'12px',height:'24px'}} />
                                                        <InputGroup.Button style={{height:'24px'}} onClick={() => usrEvent("101")}>
                                                        <SearchIcon />
                                                        </InputGroup.Button>
                                                    </InputGroup>
                                                </td>
                                                <td>
                                                    <InputGroup inside >
                                                        <Form.Control name="usrArray03" style={{fontSize:'12px',height:'24px'}} />
                                                        <InputGroup.Button style={{height:'24px'}} onClick={() => usrEvent("103")}>
                                                        <SearchIcon />
                                                        </InputGroup.Button>
                                                    </InputGroup>
                                                </td>
                                                 <td>
                                                    <InputGroup inside >
                                                        <Form.Control name="usrArray04" style={{fontSize:'12px',height:'24px'}} />
                                                        <InputGroup.Button style={{height:'24px'}} onClick={() => usrEvent("104")}>
                                                        <SearchIcon />
                                                        </InputGroup.Button>
                                                    </InputGroup>
                                                </td>
                                                <td>
                                                    <InputGroup inside >
                                                        <Form.Control name="usrArray05" style={{fontSize:'12px',height:'24px'}} />
                                                        <InputGroup.Button style={{height:'24px'}} onClick={() => usrEvent("105")}>
                                                        <SearchIcon />
                                                        </InputGroup.Button>
                                                    </InputGroup>
                                                </td>
                                                <td>
                                                    <InputGroup inside >
                                                        <Form.Control name="usrArray06" style={{fontSize:'12px',height:'24px'}} />
                                                        <InputGroup.Button style={{height:'24px'}} onClick={() => usrEvent("106")}>
                                                        <SearchIcon />
                                                        </InputGroup.Button>
                                                    </InputGroup>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </Table>
                                    <div className="grid-btn-wrap mt-4">
                                        <div className="left-align">
                                            <div className="sub-title">
                                                <ul>
                                                    <li>적용 국가 및 언어</li>
                                                </ul>
                                            </div>
                                        </div>
                                        <div className="right-align">
                                            <Button variant="outline-secondary" size="sm" onClick={() => setLangCopyPop(true)}>언어복사</Button>{' '}
                                        </div>
                                    </div>
                                    <Table className="tbl-hor" bordered>
                                        <colgroup>
                                            <col style={{width:'120px'}}></col>
                                            <col style={{width:''}}></col>
                                            <col style={{width:''}}></col>
                                            <col style={{width:''}}></col>
                                        </colgroup>
                                        <tbody>
                                            <tr>
                                                <th>적용 국가 및 언어</th>
                                                <td colSpan="3">
                                                    <div className="grid-double">
                                                        <div className="ag-theme-alpine" style={{height:300, width:'60%'}}>
                                                            <AgGridReact
                                                                ref={natlGrid} 
                                                                rowData={natlList}
                                                                columnDefs={columnDefs}
                                                                defaultColDef={defaultColDef}
                                                                rowSelection={'multiple'}
                                                                suppressRowClickSelection= {true} 
                                                                onFirstDataRendered={onFirstDataRendered}
                                                                suppressSizeToFit={true}    
                                                                onGridSizeChanged={onFirstDataRendered}   
                                                                
                                                                onSelectionChanged ={onSelectionChanged }
                                                                >
                                                            </AgGridReact>
                                                        </div>
                                                        <div className="grid-move-btn" style={{marginLeft:"5px"}}>
                                                            <Button className="lang-add-btn" variant="outline-secondary" size="sm" onClick={() => langAddEvnt()}> <PagePreviousIcon/> </Button>
                                                        </div>
                                                        <div className="ag-theme-alpine" style={{height:300, width:'40%',marginLeft:"5px"}}>
                                                            <AgGridReact
                                                                ref={langGrid} 
                                                                rowData={filteredLangList}
                                                                columnDefs={columnDefs2}
                                                                defaultColDef={defaultColDef}
                                                                rowSelection={'multiple'}
                                                                suppressRowClickSelection= {true} 
                                                                onFirstDataRendered={onFirstDataRendered}
                                                                suppressSizeToFit={true}    
                                                                onGridSizeChanged={onFirstDataRendered}     
                                                                >
                                                            </AgGridReact>
                                                        </div>
                                                    </div>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </Table>
                                </div> 
                       <div className='modal-footer'>
                            <Button variant="light" size="md" onClick={onHide}>취소</Button>
                            <Button variant="primary" size="md" disabled={submitButton} onClick={handleSubmit} >저장</Button>
                        </div>
                </CustomModal>
            </Form>

            {langCopyPop && <LangCopy show={langCopyPop} onHide={() => setLangCopyPop(false)}  langCopyEvent={langCopyEvent}/>}
            {vehlPersonPop && <VehlPerson show={vehlPersonPop} onHide={() => setVehlPersonPop(false) } 
                param={compGbn}
                chrgList={chrgList} 
                // setUsrList01={setUsrList01} 
                // setUsrList03={setUsrList03} 
                // setUsrList04={setUsrList04}
                // setUsrList06={setUsrList06} 
                onChangeUsrList={onChangeUsrList}
                />}
            </div>
    );

};
export default VehlCodeAdd;