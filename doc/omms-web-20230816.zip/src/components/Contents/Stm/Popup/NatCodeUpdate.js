import React from 'react';
import {Button, Modal, Table} from 'react-bootstrap';
import {  Form, SelectPicker, Schema } from 'rsuite';
import {CONSTANTS, API } from '../../../../utils/constants';
import { getData, postData } from '../../../../utils/async';
import { useQuery,useMutation} from 'react-query';
import { useEffect } from 'react';
import { confirmAlert } from 'react-confirm-alert'; // Import
import ConfirmAlert from '../../../Common/ConfirmAlert';
import CustomModal from '../../../Common/CustomModal';
import { isApi } from '../../../../utils/commUtils';
import { escapeCharChange } from '../../../../utils/commUtils';
const { StringType} = Schema.Types;

const model = Schema.Model({
    natNm: StringType().isRequired('국가명을 입력해주세요.'),
    dlExpdRegnCd: StringType().isRequired('지역을 선택해주세요.'),
});
const NatCodeUpdate = ({auth ,show, onHide,data}) => {
    const containerRef = React.useRef();
    const formRef = React.useRef();
    const [formError, setFormError] = React.useState({});
    const [formValue, setFormValue] = React.useState({
        dlExpdNatCd : '',
        natNm : '',
        dlExpdRegnCd: ''
    }); 


    const paramsCo = {dlExpdGCd: CONSTANTS.grpCdRegn};
    const regnCombo = useQuery([API.codeCombo,paramsCo], () => getData(API.codeCombo,paramsCo)) 

    const param = {
        dlExpdNatCd : data.dlExpdNatCd
    }
    const queryResult = useQuery([API.natlMst, param], () => getData(API.natlMst, param),{
        staleTime: 0,
        
    });
    useEffect(()=>{
        if(queryResult.isSuccess){
    
            const dataInfo = queryResult.data;
            console.log("dataInfo",dataInfo);
    
            setFormValue({
                dlExpdNatCd : escapeCharChange(dataInfo.dlExpdNatCd),               // 사용여부
                natNm : escapeCharChange(dataInfo.natNm),             // A코드
                dlExpdRegnCd : dataInfo.dlExpdRegnCd // 지역코드
            })
        }
    },[queryResult.status])


    const handleSubmit = () => {
        if (!formRef.current.check()) { //validation chk
            return;
        }
        confirmAlert({
            closeOnClickOutside: false,
            customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}   title={"알림"}
            msg={"입력하신 내용으로 저장하시겠습니까?"} 
            onOk={onOk}  />
        });
    };
    const handleSubmitDel = () => {
        confirmAlert({
            closeOnClickOutside: false,
            customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}   title={"알림"}
            msg={"삭제하시겠습니까?"} 
            onOk={onDelete}  />
        });
    };
    const onOk = () => {
       
        natlSave.mutate(formValue);
    }
    const onDelete = () => {
       
        natlDelete.mutate(formValue);
    }
    const natlSave = useMutation((params => postData(API.natlMst, params, CONSTANTS.update)),{
        onSuccess: res => {
           if(res>0){
                confirmAlert({
                    closeOnClickOutside: false,
                    customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}   title={"알림"}
                    msg={"저장이 완료되었습니다."}   />
                    
                });
           }
           else{
            confirmAlert({
                closeOnClickOutside: false,
                customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}   title={"알림"}
                msg={"에러가 발생했습니다 관리자에게 문의해주세요."}   />
                
            });
           }
           onHide();
        }
    });
    const natlDelete = useMutation((params => postData(API.natlMst, params, CONSTANTS.delete)),{
        onSuccess: res => {
           if(res>0){
                confirmAlert({
                    closeOnClickOutside: false,
                    customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}   title={"알림"}
                    msg={"삭제가 완료되었습니다."}   />
                    
                });
           }
           else{
            confirmAlert({
                closeOnClickOutside: false,
                customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}   title={"알림"}
                msg={"에러가 발생했습니다 관리자에게 문의해주세요."}   />
                
            });
           }
           onHide();
        }
    });
    return (
        <>
                <Form
                ref={formRef}
                checkTrigger="change"
                onChange={setFormValue}
                onCheck={setFormError}
                formValue={formValue}
                model={model}>
                <CustomModal open={show} 
                        title={'국가코드 상세/수정'}
                        size='md'
                        // handleOk={handleSubmit}
                        handleCancel={onHide} >
                        
                            <Table className="tbl-hor" bordered>
                                <colgroup>
                                    <col style={{width:'30%'}}></col>
                                    <col style={{width:''}}></col>
                                </colgroup>
                                <tbody>
                                    <tr>
                                        <th className="">국가코드</th>
                                        <td>{queryResult.data && escapeCharChange(queryResult.data.dlExpdNatCd)}</td>
                                    </tr>
                                    <tr>
                                        <th className="essen">국가명</th>
                                        <td>
                                        <Form.Control name = "natNm" size="sm" type="text"/> 
                                        </td>
                                    </tr>
                                    <tr>
                                        <th className="essen">지역</th>
                                        <td>
                                        {regnCombo.isSuccess &&
                                                    <Form.Control container={()=> containerRef.current}  name="dlExpdRegnCd" size="sm" style={{zIndex: 0}} 
                                                        placeholder={'선택'}
                                                        defaultValue={''}
                                                        accepter={SelectPicker} 
                                                        searchable={false}
                                                        cleanable={false}
                                                        data={regnCombo.isFetched && regnCombo.data}
                                                        
                                                    ></Form.Control>
                                                }
                                        </td>
                                    </tr>
                                </tbody>
                            </Table>
                        

                        <div className='modal-footer'>
                            <Button variant="light" size="md" onClick={onHide}>취소</Button>
                            {auth && auth==='100' &&isApi(API.natlMst, 'POST') && <Button variant="outline-danger" size="md" onClick={handleSubmitDel}>삭제</Button>}
                            {isApi(API.natlMst, 'POST') &&<Button variant="primary" size="md" onClick={handleSubmit} >저장</Button>}
                        </div>
                </CustomModal>
            </Form>

        </>
    );

};
export default NatCodeUpdate;