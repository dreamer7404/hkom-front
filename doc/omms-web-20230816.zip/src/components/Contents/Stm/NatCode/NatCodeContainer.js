import React,{useState, useEffect} from 'react';
import {Tab,Tabs} from 'react-bootstrap';
import { isApi } from '../../../../utils/commUtils';
import { API } from '../../../../utils/constants';
import NatlLangList from './NatlLangList';
import NatMast from './NatMast';

const LangCodeContainer = () => {

    const [leftWidth, setLeftWidth] = useState('150px')
   
    useEffect(() => {
        const getTitle = document.getElementById('section-title-width');
        const titleWidth = getTitle.clientWidth + 40;
        setLeftWidth(titleWidth)
    }, []);

    return (
        <>
            <Tabs  defaultActiveKey="tab1" style={{left: leftWidth}} >
                {isApi(API.natlLangMgmts, 'GET') && <Tab eventKey="tab1" title={"국가별 언어관리"}>
                    <NatlLangList />
                </Tab>}
                {isApi(API.natlMsts, 'GET') &&<Tab eventKey="tab2" title="국가마스터">
                    <NatMast />
                </Tab>}
            </Tabs>
        </>
    );

};
export default LangCodeContainer;