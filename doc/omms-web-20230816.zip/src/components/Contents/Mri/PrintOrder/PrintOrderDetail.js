// react
import React, {useState, useEffect, useCallback} from 'react';
import {Button, Table} from 'react-bootstrap';
import AttachmentIcon from '@rsuite/icons/Attachment';
import {Notification, toaster} from 'rsuite';
//--------------  서버데이터용 필수 -------------------------------
import { useQuery, useMutation} from 'react-query';
import { getData, postData } from '../../../../utils/async';
import { API,CONSTANTS } from '../../../../utils/constants';
import useStore from '../../../../utils/store';
//--------------// 서버데이터용 필수 -------------------------------
import GridPrintOrderAdd from '../_Grid/GridPrintOrderAdd';
import PrintArrayTable from '../Popup/PrintArrayTable';
import qs from 'qs';
import { useLocation } from 'react-router';
import { Link,useNavigate} from 'react-router-dom';
import { escapeCharChange, formatNumber, utcToLocalDate } from '../../../../utils/commUtils';
import { confirmAlert } from 'react-confirm-alert'; // Import
import ConfirmAlert from '../../../Common/ConfirmAlert';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faFileExcel,faPrint } from '@fortawesome/free-solid-svg-icons'
import {Button as ButtonBoot} from 'react-bootstrap';
import { isApi } from '../../../../utils/commUtils';

//엑셀다운로드 테스트 김정웅
import * as ExcelJS from 'exceljs'
import { excelDownloadTable } from '../../../../utils/excelForPrintOrderDetail';

const PrintOrderDetail = () => {

    //------------------- 필수 공통 ------------------------------
    const [open, setOpen] = useState(true); // 조건창 열기/닫기
    const {keyword } = useStore();  // 조회키워드 가져오기

    const [activePage, setActivePage] = useState(1);    // 페이지번호
    const [limit, setLimit] = useState(50);             // 페이지행수
    const [filterValue, setFilterValue] = useState(''); // 필터값

    const onChangePage = val => {
        setActivePage(val);
    };
    const onChangeLimit = val => {
        setLimit(val);
    };
    useEffect(()=>{
        onChangePage(1); // 페이지번호 리셋
    },[keyword]);

    // 필터
    const onFilterTextBoxChanged = useCallback((e) => {
        setFilterValue(e.target.value);
    }, []);

    // 검색창 열기/닫기 > 페이지네이션 여부에 따라 +-20px
    const gridExpand = () =>{
        setOpen(!open);
    }
    //-------------------// 필수 공통 ------------------------------

    const location = useLocation();
    const [query, setQuery] = useState(
        qs.parse(location.state, { ignoreQueryPrefix: true }),
    )
    
    // 발간실적 기준정보 조회
    const queryTotResult = useQuery([API.ivmTotIvInfos, query], () => getData(API.ivmTotIvInfos, query));

    // 상세 조회 (세부내역, 인쇄비용, 개정내용)
    const [data, setData] = useState();
    const [reversionList, setReversionList] = useState();
    const queryResult = useQuery([API.printState, query], () => getData(API.printState, query));
    useEffect(()=>{
        if(queryResult.isSuccess){
            setData(queryResult.data.prntApvlInfoList)
            setReversionList(queryResult.data.reviceInfoList);
            // setQuery(p=>({...p,
            //     dlvgParrYmd : queryResult.data.prntApvlInfoList.dlvgParrYmd,//납품예정일(납품예정일 변경)
            //     rqQty : queryResult.data.prntApvlInfoList.rqQty, //인쇄부수 (인쇄비용 할당값)
            //     saleUnp : queryResult.data.prntApvlInfoList.saleUnp, 
            //     prntParrBgt : queryResult.data.prntApvlInfoList.prntParrBgt ,
            //     prtlImtrSbc3 : queryResult.data.prntApvlInfoList.prtlImtrSbc3,
            //     prntParrYmd :  queryResult.data.prntApvlInfoList.prntParrYmd,

            // }) )
        }
    },[queryResult.status])

    const navigate = useNavigate();
    const listButton = () => {
        navigate('/printOrder');
    }

    const boardInfoEvent = (blcSn) =>{
        navigate('../../../board/detail',{ state: blcSn }); 
    }
    const addButton = () => {
        let qltyVehlNm = escapeCharChange(data.qltyVehlNm)
        qltyVehlNm = qltyVehlNm.substring(qltyVehlNm.lastIndexOf(')')+1,qltyVehlNm.lastIndexOf('-'))

        let langCdNm = escapeCharChange(data.langCdNm)
        langCdNm = langCdNm.substring(langCdNm.lastIndexOf(')')+1,langCdNm.length)
        // alert(langCdNm)

        let param = {...query, qltyVehlNm:qltyVehlNm, langCdNm: langCdNm, oldPrntPbcnNo: data.oldPrntPbcnNo}
        navigate('/printOrder/add',{ state: param}); 
    }

    const [printArrayTablePop, setPrintArrayTablePop] = useState(false);

    //임시저장 삭제 or 발주완료건 취소
    const deleteResult = useMutation((params => postData(API.printOrderInfoDelete, params, CONSTANTS.delete)),{
        onSuccess: res => {
		    if(res == 1){
                toaster.push(
                    <Notification type='success' header='요청성공' closable >
                        
                        {query && query.trtmRstCd && query.trtmRstCd === '02'
                            ? '발주취소가 완료되었습니다.'
                            : '삭제가 완료되었습니다.'
                        }
                    </Notification>
                );
                setTimeout(() => listButton(), 500)
            } else {
                toaster.push(
                    <Notification type='error' header='요청실패' closable >
                        {query && query.trtmRstCd && query.trtmRstCd === '02'
                            ? '발주취소를 실패했습니다.'
                            : '삭제를 실패했습니다.'
                        }
                    </Notification>
                );
            }
        }
    });

    const deleteButton = state => {
        let param = [query];
        let msg = '';
        if(state === '02'){
            if(Number(data.dlvgParrYmd.replace(/-/g, '')) < Number(utcToLocalDate(new Date()).replace(/-/g, ''))){
                confirmAlert({
                    closeOnClickOutside: false,
                    customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}  title={"알림"} msg={'납품일이 지난 항목은 취소가 불가합니다.'}  />
                })
                return false
            }
            msg = '발주취소 하시겠습니까?'
        } else {
            msg = '삭제 하시겠습니까?'
        }
        const onOk = () => {
            setTimeout(deleteResult.mutate(param), 500)
        }
        confirmAlert({
            closeOnClickOutside: false,
            customUI: ({ onClose }) => <ConfirmAlert 
                                            onClose={onClose} 
                                            title={"알림"}
                                            msg={msg} 
                                            onOk={onOk}  
                                        />
        })
    }
    const prntPageOpen =() =>{ 

        if(queryResult.data.prntPageYn==='Y'){
            setPrintArrayTablePop(true)
        }
        else{
            confirmAlert({
                closeOnClickOutside: false,
                customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}  title={"알림"} msg={'저장된 인쇄페이지가 없습니다.'}  />
            })
        }
    }
    //법규및 변경관리 상세 페이지 이동
    const handleDetail =(param)=>{
        const data ={
            dlExpdAltrNo : param
        }
        navigate('../../../clcm/detail',{ state: data }); 

    }

    //O/M발주 상세 엑셀다운로드 시작
    const excelDownload = () => {
        excelDownloadTable(data)
    }
    //O/M발주 상세 엑셀다운로드 끝

    return (
        <>
            <div className="grid-wrap">
                
                <div className="grid-btn-wrap">
                    <div className="left-align">
                        <div className="sub-title">
                            <ul>
                                <li>발간실적 기준정보</li>
                            </ul>
                        </div>
                    </div>
                    <div className="right-align">
                        <Button variant="outline-dark btn-print" size="sm"onClick={() => window.print()}><FontAwesomeIcon icon={faPrint}/>{CONSTANTS.print}</Button>{' '}
                    </div>
                </div>
                {/*--------- Grid -----------*/}
                {queryTotResult && 
                    <GridPrintOrderAdd 
                    filterValue={filterValue}
                    queryResult={queryTotResult}
                    limit={limit}
                    activePage={activePage}
                    />
                }

                <div className="grid-btn-wrap mt-4">
                    <div className="left-align">
                        <div className="sub-title">
                            <ul>
                                <li>세부내역</li>
                            </ul>
                        </div>
                    </div>
                    <div className="right-align">
                        <Button variant="outline-success btn-excel" size="sm" onClick={() => excelDownload(true)}>
                            <FontAwesomeIcon icon={faFileExcel}/>
                            {CONSTANTS.excelDownload}
                        </Button>{' '}
                        <Button variant="outline-secondary" size="sm" onClick={() => prntPageOpen()}>인쇄배열표</Button>{' '}
                    </div>
                </div>
                
                <Table className="tbl-hor" bordered>
                    <colgroup>
                        <col style={{width:'15%'}}></col>
                        <col style={{width:'15%'}}></col>
                        <col style={{width:''}}></col>
                        <col style={{width:'15%'}}></col>
                        <col style={{width:'15%'}}></col>
                        <col style={{width:'%'}}></col>
                    </colgroup>
                    <tbody>
                        <tr>
                            <th colSpan="2">차종</th>
                            <td>
                                {data && escapeCharChange( data.qltyVehlNm)}
                            </td>
                            <th colSpan="2">언어</th>
                            <td>{data &&escapeCharChange( data.langCdNm)}</td>
                        </tr>
                        <tr>
                            <th colSpan="2">인쇄부수</th>
                            <td>{data && formatNumber(data.rqQty)}</td>
                            <th rowSpan="4">인쇄페이지</th>
                            <th>총 페이지</th>
                            <td>{data && data.pgNl}</td>
                        </tr>
                        <tr>
                            <th rowSpan="2">납품</th>
                            <th rowSpan="2">납품일</th>
                            <td rowSpan="2">{data && data.dlvgParrYmd}</td>
                            <th>표지</th>
                            <td>{data && data.prntWayCd2=='04' || data &&data.prntWayCd2=='05' || data &&data.prntWayCd2=='06' || data &&data.prntWayCd2=='07'?  "0" : "4"}</td>
                        </tr>
                        <tr>
                            
                            <th>설명서</th>
                            <td>{data && data.expdNl}</td>
                        </tr>
                        <tr>
                            <th rowSpan="2">발간번호</th>
                            <th>신규번호</th>
                            <td>{data && escapeCharChange(data.newPrntPbcnNo)}</td>
                            <th>보증서/엽서</th>
                            <td>{data && data.grnDocNl}</td>
                        </tr>
                        <tr>
                            <th>기존번호</th>
                            <td>{data && escapeCharChange(data.oldPrntPbcnNo)}</td>
                            <th rowSpan="2">옵셋(내지)</th>
                            <th>기존필름이용</th>
                            <td>{data && data.prntWayCd2=='01' || data &&data.prntWayCd2=='02' || data &&data.prntWayCd2=='08'? 
                             (data && data.eofu1Nl==null? 0:data.eofu1Nl) : "0"}</td>
                        </tr>
                        <tr>
                            <th colSpan="2">발행방법</th>
                            <td>{data && data.iwayNm}</td>
                            <th>신규필름제작(교정포함)</th>
                            <td>{data && data.prntWayCd2=='01' || data &&data.prntWayCd2=='02' || data &&data.prntWayCd2=='08'?data && data.nrFlmMkoNl:'0' }</td>
                        </tr>
                        <tr>
                            <th colSpan="2">제본</th>
                            <td>{data && data.prntWayCd2=='04' || data &&data.prntWayCd2=='05' || data &&data.prntWayCd2=='06' || data &&data.prntWayCd2=='07'?  "" : "무선제본"}</td>
                            <th>디지털(내지)</th>
                            <th>디지털 인쇄</th>
                            <td>{data && data.prntWayCd2=='01' || data &&data.prntWayCd2=='02' || data &&data.prntWayCd2=='08'?'0':data &&data.nrFlmMkoNl }</td>
                        </tr>
                        <tr>
                            <th colSpan="2">규격</th>
                            <td>{data && escapeCharChange(data.pgMgnSbc)}</td>
                            
                            <th colSpan="2">외주편집페이지</th>
                            <td>{data && data.oordEditPgNl}</td>
                        </tr>
                        <tr>
                            <th rowSpan="2">지질</th>
                            <th>표지</th>
                            <td>{data && data.prntWayCd2=='04' || data &&data.prntWayCd2=='05' || data &&data.prntWayCd2=='06' || data &&data.prntWayCd2=='07'?   "" : "250아트"}</td>
                            <th colSpan="2">외주편집업체</th>
                            <td>{data && data.oordEditCoCd=="01"? "TLA"
                                :data && data.oordEditCoCd=="02"? "AST"
                                :data && data.oordEditCoCd=="03"? "FEEL"
                                :data && data.oordEditCoCd=="04"? "TEXTREE":"없음"}</td>
                        </tr>
                        <tr>
                            <th>내지</th>
                            <td>{data && data.deipq1Sbc=='01'? "80화인코드지":"70모조지"}</td>
                            <th colSpan="2">커버수량</th>
                            <td>{data && data.depc1Yn=='Y'? data&& data.depc1Qty:'0'}</td>
                        </tr>
                        <tr>
                            <th rowSpan="2">인쇄</th>
                            <th>표지</th>
                            <td>{data && data.prntWayCd2=='04' || data &&data.prntWayCd2=='05' || data &&data.prntWayCd2=='06' || data &&data.prntWayCd2=='07'?   "" : "옵셋"}</td>
                            <th colSpan="2">비고</th>
                            <td>{data && data.rem}</td>
                        </tr>
                        <tr>
                            <th>내지</th>
                            <td>{data && data.prntWayCd2=="01"||data && data.prntWayCd2=="02"||data && data.prntWayCd2=="08"? "옵셋"
                                :data && data.prntWayCd2=="03"? "디지털"
                                :data && data.prntWayCd2=="04"||data && data.prntWayCd2=="05"? "스티커"
                                :data && data.prntWayCd2=="06"||data && data.prntWayCd2=="07"? "리플렛":""}</td>
                            <th colSpan="2">표지코팅</th>
                            <td>무광코팅</td>
                        </tr>
                        <tr>
                            <th rowSpan="2">인쇄도수</th>
                            <th>표지</th>
                            <td>{data && data.prntWayCd!=''?
                                
                            data && data.prntWayCd2=='04' || data &&data.prntWayCd2=='05' || data &&data.prntWayCd2=='06' || data &&data.prntWayCd2=='07'?   "" 
                            : data && data.prntWayCd=="01"?"없음"
                            : data && data.prntWayCd=="02"?"1"
                            : data && data.prntWayCd=="03"?"2"
                            : data && data.prntWayCd=="04"?"3"
                            : data && data.prntWayCd=="05"?"4"
                            : data && data.prntWayCd=="06"?"5":""
                            :data&& data.cPrntCvrSbc}</td>
                            <th colSpan="2">게시판 관리번호</th>
                            <td>
                            {data && data.blcSn && <ButtonBoot style={{padding:0}} variant="link" onClick={() => boardInfoEvent(data.blcSn)}>{data.blcSn} </ButtonBoot>}
                            </td>
                        </tr>
                        <tr>
                            <th>내지</th>
                            <td>{data && data.prntWayCd2=="01"||data && data.prntWayCd2=="03"||data && data.prntWayCd2=="04"||data && data.prntWayCd2=="06"? "1"
                                :data && data.prntWayCd2=="02"||data && data.prntWayCd2=="05"||data && data.prntWayCd2=="07"? "2"
                                :data && data.prntWayCd2=="08"?"4":data && data.cPrntInsdPgSbc}</td>
                            <th colSpan="2"></th>
                            <td></td>
                        </tr>
                        <tr>
                            <th colSpan="2">메모</th>
                            <td colSpan="4">{data && escapeCharChange(escapeCharChange(data.prtlImtrSbc))}</td>
                        </tr>
                        <tr>
                            <th colSpan="2">발주자</th>
                            <td>{
                                data && data.crgrNm 
                                    ? data.crgrNm 
                                    : data && data.crgrEeno 
                                        ? data.crgrEeno 
                                        : ''
                                }
                            </td>
                            <th colSpan="2">발주일</th>
                            <td>{data && data.ordnRqstYmd}</td>
                        </tr>
                        <tr>
                            <th colSpan="2">발주상태</th>
                            <td colSpan="4">{query && query.trtmRst }</td>
                        </tr>
                    </tbody>
                </Table>

                <div className="grid-btn-wrap mt-4">
                    <div className="left-align">
                        <div className="sub-title">
                            <ul>
                                <li>개정내용</li>
                            </ul>
                        </div>
                    </div>
                </div>
                <Table className="tbl-ver" bordered>
                    <colgroup>
                        <col style={{width:'10%'}}></col>
                        <col style={{width:''}}></col>
                        <col style={{width:'10%'}}></col>
                    </colgroup>
                    <thead>
                        <tr>
                            <th>등록번호</th>
                            <th>개정내용</th>
                            <th>첨부</th>
                        </tr>
                    </thead>
                    <tbody>
                        {reversionList && reversionList.length > 0
                        ? reversionList.map((item,index)=>(
                        <tr key = {index}>
                            <td>{item.dlExpdAltrNo}</td>
                            <td><ButtonBoot variant="link" onClick={()=>handleDetail(item.dlExpdAltrNo)}> {item.altrTitl}   </ButtonBoot></td>
                            <td></td>
                        </tr>
                        ))
                        :
                        <tr>
                            <td colSpan={3}>적용된 개정내용이 없습니다.</td>
                        </tr>
                    }
                    </tbody>
                </Table>

                
                <div className="btn-wrap">
                    <div className="left-align">
                        <Button variant="light" onClick={() => listButton()}>목록</Button>{' '}
                    </div>
                {query.trtmRstCd === '02' 
                ? //발주완료인 경우
                    <div className="right-align">
                        {data && data.dlvgParrYmd && Number(data.dlvgParrYmd.replace(/-/g, '')) >= Number(utcToLocalDate(new Date()).replace(/-/g, '')) && isApi(API.printOrderInfoDelete, 'POST') &&
                        <Button variant="outline-danger" onClick={() => deleteButton('02')}>발주취소</Button> //납품일이 오늘을 안지난 경우만 삭제 가능
                        }
                        {isApi(API.printOrderInfo, 'POST') &&
                        <>
                        {' '}<Button variant="primary" onClick={() => addButton()}>O/M발주</Button>{' '}
                        </>
                        }
                    </div>
                : //발주상태가 발주취소or임시저장인 경우 아래의 버튼으로 변경
                    <div className="right-align">
                        {isApi(API.printOrderInfoDelete, 'POST') &&
                        <>
                        <Button variant="outline-danger" onClick={() => deleteButton(query && query.trtmRstCd ? query.trtmRstCd : '')}>삭제</Button>{' '}
                        </>
                        }
                        {isApi(API.printOrderInfo, 'POST') &&
                        <>
                        <Button variant="primary" onClick={() => addButton()}>O/M발주</Button>{' '}
                        </>
                        }
                    </div>
                }
                </div>

            </div>

            {query &&
            <PrintArrayTable show={printArrayTablePop} onHide={() => setPrintArrayTablePop(false)} param={query} readOnly={true}  />
            }
        </>
    )
};
export default PrintOrderDetail;