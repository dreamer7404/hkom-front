// react
import React, {useState, useEffect, useCallback, useRef} from 'react';
import {Col, Button, Collapse,Row, Spinner } from 'react-bootstrap';
import {Form, Input, SelectPicker,InputGroup,DatePicker} from 'rsuite';
import SearchIcon from '@rsuite/icons/Search';
import { utcToLocalDate ,encrypt, decrypt} from '../../../../utils/commUtils'; //'../../../utils/commUtils';
import moment from 'moment';
import axios from 'axios';

//--------------  서버데이터용 필수 -------------------------------
import { useQuery,useMutation} from 'react-query';
import { API, CONSTANTS } from '../../../../utils/constants';   
import useStore from '../../../../utils/store';
import { getData, getExcel } from '../../../../utils/async';
//--------------// 서버데이터용 필수 -------------------------------

import GridShipInfo from '../_Grid/GridShipInfo';
import Paging from '../../../Common/Paging';
import { CustomInputGroup } from '../../../Common/CustomInputGroup';

import {ArrowDownLine, ArrowUpLine} from '@rsuite/icons';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faFileExcel,faPrint } from '@fortawesome/free-solid-svg-icons'
import { excelDownload as excelDownloadAggrid } from '../../../../utils/excelForAggrid';

import { confirmAlert } from 'react-confirm-alert'; 
import ConfirmAlert from  '../../../Common/ConfirmAlert';


const ShipInfoList = () => {
    
    //------------------- 필수 공통 ------------------------------
    const [open, setOpen] = useState(true); // 조건창 열기/닫기
    const {coCd } = useStore();  // 조회키워드 가져오기
    const [vin , setVin] = useState();
    const [activePage, setActivePage] = useState(1);    // 페이지번호
    const [limit, setLimit] = useState(50);             // 페이지행수
    const [filterValue, setFilterValue] = useState(''); // 필터값
    const [excelStatus, setExcelStatus] = useState(false);
    const gridRef = useRef();

    const [startDate, setStartDate] = useState(utcToLocalDate(new Date().setDate(1))); //현재월의 1일
    const [endDate, setEndDate] = useState(utcToLocalDate(new Date()));//현재일자
    const [params, setParams] = useState({
        orderType: '',
        orderBy: '',
        vin : '',
        pageNo: activePage,
        pageSize: limit,
        offset: 0,
        sDate : startDate,
        eDate : endDate
    });
    const onChangePage = val => {
        setActivePage(val);
        setParams(state => ({...state, pageNo: val, offset: (val-1)*limit}));
    };
    const onChangeVin = val =>{
        setVin(val);
        setParams(state => ({...state, vin: val}));
    }
    const onChangeLimit = val => {
        setLimit(val);
        setParams(state => ({...state, pageSize: val}));
        onChangePage(1); // 페이지번호 리셋
    };

    



    // 필터
    const onFilterTextBoxChanged = useCallback((e) => {
        setFilterValue(e.target.value);
    }, []);
    const onChangeDateStart = val => {
        setStartDate(utcToLocalDate(val));
    }
    useEffect(()=>{
        setParams(state => ({...state, sDate: startDate, eDate: endDate}));
    },[startDate, endDate])
    
    const onChangeDateEnd = val => {
        setEndDate(utcToLocalDate(val));
    }
 
    // 검색창 열기/닫기 > 페이지네이션 여부에 따라 +-20px
    const [gridHeight, setGridHeight] = useState(575);
    const gridExpand = () =>{
        setOpen(!open);
        if(open){
            setTimeout(() => setGridHeight(650), 250);
        }else{
            setGridHeight(575)
        }
    }
    //-------------------// 필수 공통 ------------------------------


    //  requestState 조회
    const queryResult = useQuery([API.shipInfos,params], () => getData(API.shipInfos,params));
    const queryResultTot = useQuery([API.shipInfoTots,params], () => getData(API.shipInfoTots,params));


    const onCellClicked = (e) => {

    }
    

    // 조회버튼
    const onSearch = () => {
        if(coCd === '02'){ // 기아조회
            queryResult.remove();
            queryResultTot.remove();

            queryResult.refetch(); // 수동쿼리실행
            queryResultTot.refetch();

        }else{ // 현대 팝업윈도우
            // 로컬IP조회
            if(vinHd){
                const url = process.env.REACT_APP_HMC_URL + "/api/vehlGis?vin=" + vinHd;
                const popUpWin = window.open(url, "width=900, height=800, top=0, left=0, status=no, scrollbars=yes");
                popUpWin.focus();
            }else{
                confirmAlert({
                    closeOnClickOutside: false,
                    customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}  title={"알림"} msg={'V.I.N을 입력해주세요.'}  />
                });
            }
           
        }
    };


    useEffect(() => {
        if(excelStatus) {
            setTimeout(() =>setExcelStatus(excelDownloadAggrid(gridRef, '선적현황', 2)), 1000)
        }
    }, [excelStatus])

    //--------------------------------- 엑셀 ----------------------------------------------------

    const [loading, setLoading] = useState(false);

    const excelDownload = () => {
        setLoading(true);

        getExcel(API.shipExcelDown,{sDate: startDate, eDate: endDate}).then(res => {
            const fileName = '기아선적현황_' + moment(new Date()).format('YYYYMMDDHHmmsss')+ '.xls';
            const url = window.URL.createObjectURL(
                new Blob([res.data], { type: res.headers["content-type"] })
            );
            const link = document.createElement("a");
            link.href = url;
            link.setAttribute("download", fileName);
            document.body.appendChild(link);
            link.click();

            setLoading(false);
        })
    } 


    const shipExcelDown = () => {

        if(Number(queryResultTot.data) === 0){
            confirmAlert({
                closeOnClickOutside: false,
                customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}  title={"알림"} msg={'해당기간의 데이타가 없습니다.'}  />
            });
            return;
        }

        if(Number(queryResultTot.data) > 2000){
            confirmAlert({
                closeOnClickOutside: false,
                customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}  title={"알림"} msg={'최대 2000라인까지 가능합니다.'} onOk={excelDownload} />
            });
        }else{
            excelDownload();
        }
    }



    // ----------------------------현대 --------------------------------------------------------
    const [vinHd , setVinHd] = useState();

    // vin검색
    const onChangeVinHd = val =>{
        setVinHd(val);
    }

     


    return (
        <>
            <div className="search-area">
                <Collapse in={open}>
                    <div className="form" id="example-collapse-text">
                        <div className="search-group">
                            {coCd === '01' && 
                                <div className="row">
                                
                                    <Col sm={3} className=""> 
                                        <Form.ControlLabel column="sm">V.I.N</Form.ControlLabel>
                                        <Input type="text" size="sm" onChange={onChangeVinHd}/>
                                    </Col>

                                </div>}

                            {coCd === '02' && 
                                <div className="row">
                                
                                    <Col sm={3} className=""> 
                                        <Form.ControlLabel column="sm">V.I.N</Form.ControlLabel>
                                        <Input type="text" size="sm" onChange={onChangeVin}/>
                                    </Col>
                                    <Col sm={3} className=""> 
                                    <Form.ControlLabel column="sm">기간</Form.ControlLabel>
                                        <Row className="select-wrap">
                                            <Col>
                                                <InputGroup>
                                                    <DatePicker oneTap block size="sm" style={{width: '100%'}} 
                                                        value={startDate ? new Date(startDate)  : new Date()}
                                                        ranges={[
                                                            {
                                                            label: '오늘',
                                                            value: new Date()
                                                            }
                                                        ]}
                                                        format="yyyy-MM-dd"
                                                        onChange={onChangeDateStart} 
                                                        cleanable={false}
                                                    />
                                                    <InputGroup.Addon>~</InputGroup.Addon>
                                                    <DatePicker oneTap  block size="sm" style={{width: '100%'}} 
                                                        value={endDate ? new Date(endDate)  : new Date()}
                                                        ranges={[
                                                            {
                                                            label: '오늘',
                                                            value: new Date()
                                                            }
                                                        ]}
                                                        format="yyyy-MM-dd"
                                                        onChange={onChangeDateEnd} 
                                                        cleanable={false}
                                                    />
                                                </InputGroup>
                                            </Col>
                                        </Row>
                                        </Col>
                                    
                                </div>
                                }
                            <div className="search-btn-wrap">
                                <Button className="btn-search" variant="outline-primary" size="sm" onClick={onSearch}><SearchIcon />조회</Button>
                            </div>
                        </div>
                    </div>
                    
                </Collapse>

                
                <Button size="sm" variant="outline-dark" className="search-control" aria-controls="example-collapse-text" 
                    aria-expanded={open} onClick={gridExpand}>
                    {/* <span className={open === true ? "search-area-close" : "search-area-open"}>{open === true ? CONSTANTS.closeSearch : CONSTANTS.openSearch}</span> */}
                    {open ? <span className="search-area-close"><ArrowUpLine style={{marginRight: '5px', fontSize: '2em'}} />{CONSTANTS.closeSearch}</span> :
                    <span className="search-area-open"><ArrowDownLine style={{marginRight: '5px', fontSize: '2em'}} />{CONSTANTS.openSearch}</span>}
                </Button>

            </div>
            {coCd === '02' && 
            <div className="grid-wrap">
                <div className="grid-btn-wrap">
                    <div className="left-align">
                        {/*--------- 필터 -----------*/}
                        {/* <CustomInputGroup size="sm"   onInput={onFilterTextBoxChanged} /> */}
                    </div>
                    <div className="right-align">
                        {/*--------- 버튼 -----------*/}
                        <Button variant="outline-success btn-excel" size="sm" disabled={loading} onClick={shipExcelDown}>
                            {loading && <Spinner
                                as="span"
                                animation="border"
                                size="sm"
                                role="status"
                                aria-hidden="true"
                                className='me-1'
                                />}
                            {!loading && <FontAwesomeIcon icon={faFileExcel}/>}
                            {CONSTANTS.excelDownload}
                           
                        </Button>{' '}
                        <Button variant="outline-dark btn-print" size="sm"onClick={() => window.print()}><FontAwesomeIcon icon={faPrint}/>{CONSTANTS.print}</Button>{' '}
                    </div>
                </div>
                {/*--------- Grid -----------*/}
                <GridShipInfo 
                    gridRef = {gridRef}
                    gridHeight={gridHeight}
                    // filterValue={filterValue}
                    queryResult={queryResult}
                    // limit={limit}
                    // activePage={activePage}
                    onCellClicked={onCellClicked}
                    />

                {/*--------- 페이징 -----------*/}
                <Paging 
                    total={queryResultTot &&  queryResultTot.data}
                    limit={limit}
                    activePage={activePage}
                    onChangePage={onChangePage}
                    onChangeLimit={onChangeLimit}
                />
            </div>}
        </>
    )
};
export default ShipInfoList;