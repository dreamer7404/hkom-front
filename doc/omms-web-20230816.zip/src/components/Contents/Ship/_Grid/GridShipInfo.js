import React, {useEffect, useMemo, useRef} from 'react';
import { AgGridReact } from 'ag-grid-react';
import { CONSTANTS } from '../../../../utils/constants';
import { escapeCharChange } from '../../../../utils/commUtils';
const GridShipInfo = ({gridRef, gridHeight, filterValue, queryResult, limit, activePage, onCellClicked}) => {

  
  const columnDefs = [
        {
            headerName: 'V.I.N',
            field: 'vin',
            // cellStyle: () => ({textDecoration: 'underline', cursor: 'pointer', color:'#2589f5'}),
            minWidth:'120'
        },
        {
            headerName: 'Description',
            field: 'description',
            cellRenderer: param => escapeCharChange(param.value)
        },
        {
          headerName: 'Model Year',
          field: 'opt',
          minWidth:'20'
        },
        {
          headerName: 'Port',
          field: 'portNm',
        },
        {
          headerName: 'Current Status',
          field: 'statNm',
        },  
        {
          headerName: 'Shipping Distributor',
          field: 'shipDistNm',
          minWidth:'120',
          cellRenderer: param => escapeCharChange(param.value)
        },  
        {
          headerName: 'Sales Distributor',
          field: 'saleDistNm',
          cellRenderer: param => escapeCharChange(param.value)
        },  
        {
          headerName: 'Sign Off',
          field: 'prodYmd',
        },  
        {
          headerName: 'Motor Pool',
          field: 'mpoolYmd',
        },  
        {
          headerName: 'Ship Out',
          field: 'shipYmd',
        },  
        {
          headerName: 'Port Arrival(ETA)',
          field: 'portArrvYmd',
        },
        {
          headerName: 'Compound In',
          field: 'compInYmd',
        },
        {
          headerName: 'Wholesale',
          field: 'wholSaleYmd',
        },
        {
          headerName: 'Retail',
          field: 'rtYmd',
        }
    ]

    const defaultColDef = useMemo(() => {
        return {
            initialWidth: 90,
            sortable: true,
            resizable:true,
            minWidth:70
        };
    }, []);

  const onFirstDataRendered = (params) => {
      params.api.sizeColumnsToFit();
  };

  useEffect(()=>{
    if(queryResult.status === 'loading' && gridRef && gridRef.current && gridRef.current.api){
        gridRef.current.api.showLoadingOverlay();
    }
  },[queryResult]);

  useEffect(()=> {
    if(gridRef && gridRef.current && gridRef.current.api){
      gridRef.current.api.setQuickFilter(filterValue);
    }
  },[filterValue]);

  useEffect(()=> {
    if(gridRef && gridRef.current && gridRef.current.api){
      gridRef.current.api.paginationGoToPage(activePage-1);
    }
  },[activePage]);


  return(
      <div className="ag-theme-alpine" style={{height: gridHeight, transition:'all ease .3s'}}>
        <AgGridReact
            ref={gridRef} 
            rowData={queryResult && queryResult.data} 
            columnDefs={columnDefs}
            defaultColDef={defaultColDef}

            // paging
            pagination={true}
            paginationPageSize={limit} //
            suppressPaginationPanel={true} 
            // onPaginationChanged={onPaginationChanged}

            //  filter
            cacheQuickFilter={true}

             // click column
              onCellClicked={onCellClicked} //

            // overlay
            overlayLoadingTemplate={CONSTANTS.gridLoading}
            overlayNoRowsTemplate={CONSTANTS.gridNoRows}

            onFirstDataRendered={onFirstDataRendered}
            suppressSizeToFit={true}    
            onGridSizeChanged={onFirstDataRendered}    
            >
        </AgGridReact>
    </div>
  )


};
export default GridShipInfo;