import React from 'react';
import {Tab,Tabs} from 'react-bootstrap';

import SewonIvmTot from './SewonIvmTot';
import SewonIvmPrint from './SewonIvmPrint';
import OutState from './OutState';
import RequestState from './RequestState';
import CarStock from '../TotalStock/CarStock';
import ProductPlan from '../TotalStock/ProductPlan';
import { isApi } from '../../../../utils/commUtils';
import { API } from '../../../../utils/constants';

const SewonIvmContainer = () => {

    const [leftWidth, setLeftWidth] = React.useState('150px')
    // const element = React.useRef(null);
   
    React.useEffect(() => {
        const getTitle = document.getElementById('section-title-width');
        const titleWidth = getTitle.clientWidth + 40;
        setLeftWidth(titleWidth)
    }, []);

    const [activeTab, setActiveTab] = React.useState('tab1');

    return (
        <>
            <Tabs  defaultActiveKey={activeTab} onSelect={tab => setActiveTab(tab)} style={{left: leftWidth}} >
                {isApi(API.ivmSewonIvmInfos, 'GET') &&
                <Tab eventKey="tab1" title="세원재고관리 현황">
                    {activeTab === 'tab1' && <SewonIvmTot />}
                </Tab>
                }
                {isApi(API.ivmSewonPrintInfos, 'GET') &&
                <Tab eventKey="tab2" title="인쇄현황">
                    {activeTab === 'tab2' && <SewonIvmPrint />}
                </Tab>
                }
                {isApi(API.ivmSewonWhotInfos2, 'GET') &&
                <Tab eventKey="tab3" title="출고현황">
                    {activeTab === 'tab3' && <OutState />}
                </Tab>
                }
                {isApi(API.ivmNatlProdPlanInfos, 'GET') &&
                <Tab eventKey="tab5" title="국가별 생산계획">
                    {activeTab === 'tab5' && <ProductPlan />}
                </Tab>
                }
                {isApi(API.ivmVehlIvInfos, 'GET') &&
                <Tab eventKey="tab6" title="차종별 재고분석">
                    {activeTab === 'tab6' && <CarStock />}
                </Tab>
                }
                {isApi(API.ivmOrderRequestInfos, 'GET') &&
                <Tab eventKey="tab4" title="요청현황">
                    {activeTab === 'tab4' && <RequestState />}
                </Tab>
                }
            </Tabs>
        </>
    );

};
export default SewonIvmContainer;