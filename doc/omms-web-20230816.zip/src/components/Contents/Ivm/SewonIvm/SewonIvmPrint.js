import React, {useState, useEffect, useCallback, useRef} from 'react';
import {Button, Collapse} from 'react-bootstrap';
import {Grid, Row, Col ,Form, Input, Notification, toaster, Radio, RadioGroup, Checkbox} from 'rsuite';
import SearchIcon from '@rsuite/icons/Search';
import { confirmAlert } from 'react-confirm-alert'; 
import ConfirmAlert from   '../../../Common/ConfirmAlert';  

//--------------  서버데이터용 필수 -------------------------------
import { useQuery, useMutation, useQueryClient, } from 'react-query';
import { getData, postData } from '../../../../utils/async';
import { API , CONSTANTS } from '../../../../utils/constants';
import useStore from '../../../../utils/store';
import VehlType from '../../../Search/VehlType';
import Lang from '../../../Search/Lang';
import SeDate from '../../../Search/SeDate';
//--------------// 서버데이터용 필수 -------------------------------

import GridSewonIvmPrint from '../_Grid/GridSewonIvmPrint';
import Paging from '../../../Common/Paging';
import { CustomInputGroup } from '../../../Common/CustomInputGroup';
//아이콘
import {ArrowDownLine, ArrowUpLine, FileDownload} from '@rsuite/icons';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faFileExcel,faPrint } from '@fortawesome/free-solid-svg-icons'
import { isApi } from '../../../../utils/commUtils';

const SewonIvmPrint = () => {
    
    //------------------- 필수 공통 ------------------------------
    const [open, setOpen] = useState(true); // 조건창 열기/닫기
    const {keyword } = useStore();  // 조회키워드 가져오기

    const [activePage, setActivePage] = useState(1);    // 페이지번호
    const [limit, setLimit] = useState(50);             // 페이지행수
    const [filterValue, setFilterValue] = useState(''); // 필터값

    const onChangePage = val => {
        setActivePage(val);
    };
    const onChangeLimit = val => {
        setLimit(val);
    };
    useEffect(()=>{
        onChangePage(1); // 페이지번호 리셋
    },[keyword]);

    // 필터
    const onFilterTextBoxChanged = useCallback((e) => {
        setFilterValue(e.target.value);
    }, []);

    // 검색창 열기/닫기 > 페이지네이션 여부에 따라 +-20px
    const [gridHeight, setGridHeight] = useState(575);
    const gridExpand = () =>{
        setOpen(!open);
        if(open){
            setTimeout(() => setGridHeight(650), 250);
        }else{
            setGridHeight(575)
        }
    }
    const queryClient = useQueryClient();
    //-------------------// 필수 공통 ------------------------------

    const [allCheck, setAllCheck] = useState(false);
    const onChangeAllCheck = (a,b,c) => {
        setAllCheck(b)
    }
    //  세원재고 조회
    const [paramIvmTotal, setParamIvmTotal] = useState({})
    useEffect(() => {
        queryResult.remove()
        setParamIvmTotal({
            sDate: keyword.sDate,
            eDate: keyword.eDate,
            dlExpdPdiCd: keyword.dlExpdPdiCd,
            qltyVehlCd: keyword.qltyVehlCd,
            mdlMdyCd: keyword.mdlMdyCd,
            dlExpdRegnCd: keyword.dlExpdRegnCd,
            langCd: keyword.langCd,
            newPrntPbcnNo : 'ALL',
            allCheck:allCheck
        })
    },[keyword])    
    const queryResult = useQuery([API.ivmSewonPrintInfos, paramIvmTotal], () => getData(API.ivmSewonPrintInfos, paramIvmTotal));

    const onChangeNewPrntPbcnNo = e => {
        paramIvmTotal.newPrntPbcnNo =  e
    }

    // 조회버튼
    const onSearch = () => {
        setTimeout(queryResult.refetch(), 500)
        // queryResult.refetch(); // 수동쿼리실행
        setCheckedRowsForOutReqInput([])
        setCheckedNodesForOutReqInput([])
    };

    const gridRef = useRef();

    //데이터 등록(post)
    const submitResult = useMutation([API.ivmSewonPrintInfos, checkedRowsForOutReqInput], () => postData(API.ivmSewonPrintInfos, checkedRowsForOutReqInput, CONSTANTS.update),{
		onSuccess: res => {
		    if(res > 0){
                queryClient.invalidateQueries([API.ivmSewonIvmInfos]);
                queryClient.invalidateQueries([API.ivmTotIvInfos]);
                queryClient.invalidateQueries([API.ivmPdiIvInfos]);
                queryClient.invalidateQueries([API.ivmSewonPrintInfos]);
                queryClient.invalidateQueries([API.ivmSewonWhotInfos2]);
                
                
		        toaster.push(
                    <Notification type='success' header='요청성공' closable >완료부수가 저장되었습니다.</Notification>
                    );
                // onSearch()
		    }else{
		        toaster.push(
                    <Notification type='error' header='요청실패' closable >완료부수 저장을 실패했습니다.</Notification>
                );
		    }
		}
	});

    // 그리드 내에서 체크된 rows by Woong
    const [checkedRowsForOutReqInput, setCheckedRowsForOutReqInput] = useState([]);    
    const [checkedNodesForOutReqInput, setCheckedNodesForOutReqInput] = useState([]);    
    const saveButtonFirst = () =>{
        gridRef.current.api.redrawRows()
        setTimeout(saveButton, 150)
    }
    const saveButton = () => {
        // gridRef.current.api.redrawRows()
        if(checkedRowsForOutReqInput.length == 0){
            confirmAlert({
                closeOnClickOutside: false,
                customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}  title={"알림"} msg={"대상을 선택해주세요."}  />
            })
            return false
        }
        
        let scrollCheck = false;

        for(let i = 0; i < checkedNodesForOutReqInput.length; i ++){
            if(typeof checkedNodesForOutReqInput[i].data.inputQty == 'undefined' || checkedNodesForOutReqInput[i].data.inputQty === '0' || checkedNodesForOutReqInput[i].data.inputQty === '' || checkedNodesForOutReqInput[i].data.inputQty === 0 || checkedNodesForOutReqInput[i].data.inputQty === null) {
                if(scrollCheck !== true) {
                    gridRef.current.api.ensureIndexVisible(checkedNodesForOutReqInput[i].rowIndex)
                    confirmAlert({
                        closeOnClickOutside: false,
                        customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}  title={"알림"} msg={'완료부수를 입력하세요.'}  />
                    })
                }
                gridRef.current.api.flashCells({ rowNodes: [checkedNodesForOutReqInput[i]], columns: ['inputQty'], fadeDelay: 400000, flashDelay:10 });        
                scrollCheck = true
                break
            }
        }

        if(scrollCheck) {
            return false
        } else {
            const onOk = () => {
                submitResult.mutate(checkedRowsForOutReqInput)
            }
            confirmAlert({
                closeOnClickOutside: false,
                customUI: ({ onClose }) => <ConfirmAlert 
                                                onClose={onClose} 
                                                title={"알림"}
                                                msg={"입력하신 내용으로 인쇄완료하시겠습니까?"} 
                                                onOk={onOk}  
                                            />
            })
        }
    }

    //데이터 삭제(post)
    const deleteResult = useMutation([API.ivmSewonPrintInfos, checkedRowsForOutReqInput], () => postData(API.ivmSewonPrintInfos, checkedRowsForOutReqInput, CONSTANTS.delete),{
		onSuccess: res => {
		    if(res > 0){
                queryClient.invalidateQueries([API.ivmSewonIvmInfos]);
                queryClient.invalidateQueries([API.ivmTotIvInfos]);
                queryClient.invalidateQueries([API.ivmPdiIvInfos]);
                queryClient.invalidateQueries([API.ivmSewonPrintInfos]);
                queryClient.invalidateQueries([API.ivmSewonWhotInfos2]);
		        toaster.push(
                    <Notification type='success' header='요청성공' closable >인쇄취소를 성공하였습니다.</Notification>
                );
		    }else{
		        toaster.push(
                    <Notification type='error' header='요청실패' closable >인쇄취소를 실패했습니다.</Notification>
                );
		    }
		}
	});

    const deleteButton = () => {
        // gridRef.current.api.redrawRows()
        if(checkedRowsForOutReqInput.length == 0){
            confirmAlert({
                closeOnClickOutside: false,
                customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}  title={"알림"} msg={"대상을 선택해주세요."}  />
            })
            return false
        }
        
        let scrollCheck = false;

        if(scrollCheck) {
            return false
        } else {
            const onOk = () => {
                deleteResult.mutate(checkedRowsForOutReqInput)
            }
            confirmAlert({
                closeOnClickOutside: false,
                customUI: ({ onClose }) => <ConfirmAlert 
                                                onClose={onClose} 
                                                title={"알림"}
                                                msg={"선택하신 내용들을 인쇄취소 하시겠습니까?"} 
                                                onOk={onOk}  
                                            />
            })
        }
    }

    return (
        <>
            <div className="search-area">
                <Collapse in={open}>
                    <div className="form" id="example-collapse-text">
                        <div className="search-group">
                            <div className="row">
                                <Grid fluid>
                                    <Row className="show-grid">
                                        <Col sm={5} className=""> 
                                            <SeDate />
                                        </Col>
                                        <Col sm={8} className="" >
                                            <VehlType  />
                                        </Col>
                                        <Col sm={6} className="" >
                                            <Lang />
                                        </Col>
                                        <Col sm={3}>
                                            <Form.ControlLabel column="sm" >발간번호</Form.ControlLabel>
                                            <Input type="text" size="sm" onChange={onChangeNewPrntPbcnNo}/>
                                        </Col>
                                        <Col sm={2}>
                                            <Form.ControlLabel column="sm" >완료포함</Form.ControlLabel>
                                            {/* (value: any, checked: boolean, event: SyntheticInputEvent) */}
                                            <Checkbox size="sm"  onChange={(a,b,c) => onChangeAllCheck(a,b,c)}/>
                                        </Col>
                                    </Row>
                                </Grid>
                            </div>
                            <div className="search-btn-wrap">
                                <Button className="btn-search" variant="outline-primary" size="sm" onClick={onSearch}><SearchIcon />조회</Button>
                            </div>
                        </div>
                    </div>
                </Collapse>
                <Button size="sm" variant="outline-dark" className="search-control" aria-controls="example-collapse-text" 
                    aria-expanded={open} onClick={gridExpand}>
                    {open 
                        ? 
                        <span className="search-area-close">
                            <ArrowUpLine style={{marginRight: '5px', fontSize: '2em'}} />
                            {CONSTANTS.closeSearch}
                        </span> 
                        :
                        <span className="search-area-open">
                            <ArrowDownLine style={{marginRight: '5px', fontSize: '2em'}} />
                            {CONSTANTS.openSearch}
                        </span>
                    }
                </Button>
            </div>
            
            <div className="grid-wrap">
                <div className="grid-btn-wrap">
                    <div className="left-align">
                        {/*--------- 필터 -----------*/}
                        <CustomInputGroup size="sm"   onInput={onFilterTextBoxChanged} />
                    </div>
                    <div className="right-align">
                        {
                        isApi(API.ivmSewonPrintInfos, 'POST') &&
                        <>
                        <Button variant="outline-danger" size="sm" onClick={() => deleteButton()}>인쇄 취소</Button>{' '}
                        <Button variant="outline-secondary" size="sm" onClick={() => saveButtonFirst()}>인쇄 완료</Button>{' '}
                        </>
                        }
                    </div>
                </div>
                {/*--------- Grid -----------*/}
                <GridSewonIvmPrint 
                    gridHeight={gridHeight}
                    filterValue={filterValue}
                    queryResult={queryResult}
                    limit={limit}
                    activePage={activePage}
                    setCheckedRowsForOutReqInput={setCheckedRowsForOutReqInput}
                    setCheckedNodesForOutReqInput={setCheckedNodesForOutReqInput}
                    gridRef={gridRef}
                    />

                {/*--------- 페이징 -----------*/}
                <Paging 
                    total={queryResult && queryResult.data && queryResult.data.length}
                    limit={limit}
                    activePage={activePage}
                    onChangePage={onChangePage}
                    onChangeLimit={onChangeLimit}
                />
            </div>
        </>
    )
};
export default SewonIvmPrint;