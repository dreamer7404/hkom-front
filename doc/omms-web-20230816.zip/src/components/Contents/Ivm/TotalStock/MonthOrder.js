// react
import React, {useState, useEffect, useRef} from 'react';
import {Col, Button, Collapse} from 'react-bootstrap';
import {SelectPicker } from 'rsuite';
import SearchIcon from '@rsuite/icons/Search';
// rsuite

//--------------  서버데이터용 필수 -------------------------------
import { useQuery} from 'react-query';
import { getData } from '../../../../utils/async';
import { API, CONSTANTS } from '../../../../utils/constants';
import useStore from '../../../../utils/store';
import SeMonth from '../../../Search/SeMonth';
//--------------// 서버데이터용 필수 -------------------------------

import VehlType from '../../../Search/VehlType';
import Lang from '../../../Search/Lang';
import Total from '../../../Common/Total';
import GridMonthOrder from '../_Grid/GridMonthOrder';
//아이콘
import {ArrowDownLine, ArrowUpLine, FileDownload} from '@rsuite/icons';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faFileExcel,faPrint } from '@fortawesome/free-solid-svg-icons'

//파라미터 : gridRef, fileName(엑셀파일명), lastRowIndex(row 최대 길이)
import { excelDownload as excelDownloadAggrid } from '../../../../utils/excelForAggrid';

import { confirmAlert } from 'react-confirm-alert'; // Import
import ConfirmAlert from '../../../Common/ConfirmAlert';

const MonthOrder = () => {
    
    //------------------- 필수 공통 ------------------------------
    const [open, setOpen] = useState(true); // 조건창 열기/닫기
    const {keyword } = useStore();  // 조회키워드 가져오기

    const [activePage, setActivePage] = useState(1);    // 페이지번호
    const [limit, setLimit] = useState(50);             // 페이지행수
    // eslint-disable-next-line
    const [filterValue, setFilterValue] = useState(''); // 필터값

    const onChangePage = val => {
        setActivePage(val);
    };
    const onChangeLimit = val => {
        setLimit(val);
    };

    // 검색창 열기/닫기 > 페이지네이션 여부에 따라 +-20px
    const [gridHeight, setGridHeight] = useState(575);
    const gridExpand = () =>{
        setOpen(!open);
        if(open){
            setTimeout(() => setGridHeight(650), 250);
        }else{
            setGridHeight(575)
        }
    }
    //-------------------// 필수 공통 ------------------------------

    //  requestState 조회
    const [param, setParam] = useState({
        'mode': 'monPrd',
        // 'sDate': keyword.sMonth,
        // 'eDate': keyword.eMonth
        'sMonth': keyword.sMonth,
        'eMonth': keyword.eMonth,        
        'dlExpdPdiCd': keyword.dlExpdPdiCd,           // PDI code
        'qltyVehlCd': keyword.qltyVehlCd,             // 차종 code
        'dlExpdRegnCd': keyword.dlExpdRegnCd,         // 지역코드
        'langCd': keyword.langCd,                     // 언어코드
        'mdlMdyCd':keyword.mdlMdyCd,                // 차량 Mdy code
    });
    //  const queryResult = useQuery(["monthOrder", param], () => {return rowData});
    const queryResult = useQuery([API.ivmMonthOrdPrdInfos, param], () => getData(API.ivmMonthOrdPrdInfos, param),{
        staleTime:0,
        // enabled:false
        enabled: param.qltyVehlCd==='ALL'?false:true

    });

    const gridRef = useRef();
    const [excelStatus, setExcelStatus] = useState(false);
    useEffect(() => {
        if(excelStatus) {
            setExcelStatus(excelDownloadAggrid(gridRef, '월간 오더/생산 정보', 2, 'TOTAL'))
        }
    }, [excelStatus])

    // 조회버튼
    const onSearch = () => {
        if(param.qltyVehlCd !== 'ALL'){
            queryResult.refetch(); // 수동쿼리실행
        } else {
            confirmAlert({
                closeOnClickOutside: false,
                customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}  title={"알림"} msg={"차종을 선택해주세요."}  />
            })
        }
    };

     // 월간정보 선택
     const [selectMonthly, setSelectMonthly] = useState("monPrd");
     const onChangeMonthly = e => {
       setSelectMonthly(e)
     };
    
    useEffect(()=>{
        setParam({
            'mode': selectMonthly,
            'sMonth': keyword.sMonth,
            'eMonth': keyword.eMonth,
            'qltyVehlCd': keyword.qltyVehlCd,
            'dlExpdRegnCd': keyword.dlExpdRegnCd,         // 지역코드
            'langCd': keyword.langCd,                     // 언어코드
            'mdlMdyCd':keyword.mdlMdyCd,
        });
        onChangePage(1); // 페이지번호 리셋
    },[keyword, selectMonthly]);

    const selectData = [
        {name:'월간 생산정보', code:'monPrd'},
        {name:'월간 오더정보', code:'monOrd'},
        {name:'월간 오더대비 생산정보', code:'monOrdPrd'},
    ].map(
        item => ({ label: item.name, value: item.code })
    ); 

    return (
        <>
           <div className="search-area">
                <Collapse in={open}>
                    <div className="form" id="example-collapse-text">
                        <div className="search-group">
                            <div className="row">
                                <Col sm={3} className=""> 
                                    <SeMonth />
                                </Col>
                                <Col sm={5} className="" >
                                    <VehlType />
                                </Col>
                                <Col sm={4} className="" >
                                    <Lang />
                                </Col>
                            </div>
                            <div className="search-btn-wrap">
                                <Button className="btn-search" variant="outline-primary" size="sm" onClick={onSearch}><SearchIcon />조회</Button>
                            </div>
                        </div>
                    </div>
                </Collapse>
                <Button size="sm" variant="outline-dark" className="search-control" aria-controls="example-collapse-text" 
                    aria-expanded={open} onClick={gridExpand}>
                    {open 
                        ? 
                        <span className="search-area-close">
                            <ArrowUpLine style={{marginRight: '5px', fontSize: '2em'}} />
                            {CONSTANTS.closeSearch}
                        </span> 
                        :
                        <span className="search-area-open">
                            <ArrowDownLine style={{marginRight: '5px', fontSize: '2em'}} />
                            {CONSTANTS.openSearch}
                        </span>
                    }
                </Button>
            </div>
           
            <div className="grid-wrap">
              <div className="grid-btn-wrap">
                    <div className="left-align">
                        <SelectPicker size="sm" style={{width:'200px'}} searchable={false} cleanable={false} value={selectMonthly} onChange={onChangeMonthly} data={selectData}/>
                    </div>
                    <div className="right-align">
                        <Button variant="outline-success btn-excel" size="sm" disabled={excelStatus} onClick={() => setExcelStatus(true)}>
                                <FontAwesomeIcon icon={faFileExcel}/>
                                {CONSTANTS.excelDownload}
                            </Button>{' '}
                        <Button variant="outline-dark btn-print" size="sm"onClick={() => window.print()}><FontAwesomeIcon icon={faPrint}/>{CONSTANTS.print}</Button>{' '}
                    </div>
                </div>
                {/*--------- Grid -----------*/}
                <GridMonthOrder 
                  mode={param.mode}
                  gridHeight={gridHeight}
                  filterValue={filterValue}
                  queryResult={queryResult}
                  limit={limit}
                  activePage={activePage}
                   // 합계데이터
                  qltyVehlCd={param.qltyVehlCd}
                  gridRef = {gridRef}
                />

              {/*--------- 페이징 -----------*/}
              <Total 
                total={queryResult && queryResult.data && queryResult.data.length && (param.mode==='monOrdPrd'?(queryResult.data.length-3)/2:queryResult.data.length-2)}
                limit={limit}
                activePage={activePage}
                onChangePage={onChangePage}
                onChangeLimit={onChangeLimit}
                />
            </div>
        </>
    );

};
export default MonthOrder;