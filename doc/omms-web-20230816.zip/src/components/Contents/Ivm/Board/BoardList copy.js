// react
import React, {useState, useEffect, useCallback} from 'react';
import {Row, Col, Button, Collapse} from 'react-bootstrap';
import {Form, Input, SelectPicker, InputNumber} from 'rsuite';
import SearchIcon from '@rsuite/icons/Search';
import { useNavigate, Link  } from 'react-router-dom';
//--------------  서버데이터용 필수 -------------------------------
import { useQuery, useQueryClient, useMutation} from 'react-query';
import { getData, postData } from '../../../../utils/async';
import { API, CONSTANTS } from '../../../../utils/constants';
import useStore from '../../../../utils/store';
//--------------// 서버데이터용 필수 -------------------------------

import GridBoardList from '../_Grid/GridBoardList';
import Paging from '../../../Common/Paging';
import { CustomInputGroup } from '../../../Common/CustomInputGroup';
import FileControl from  '../../../Common/FileControl';
import { isApi ,escapeCharChange} from '../../../../utils/commUtils';

import VehlType from '../../../Search/VehlType';
import Lang from '../../../Search/Lang';


// icon
import {ArrowDownLine, ArrowUpLine, FileDownload} from '@rsuite/icons';


const BoardList = () => {


    //------------------- 필수 공통 ------------------------------
    const [open, setOpen] = useState(true); // 조건창 열기/닫기
    const {keyword } = useStore();  // 조회키워드 가져오기
    const [activePage, setActivePage] = useState(1);    // 페이지번호
    const [limit, setLimit] = useState(50);             // 페이지행수
    const [filterValue, setFilterValue] = useState(''); // 필터값
    const navigate = useNavigate();
    const onChangePage = val => {
        setActivePage(val);
    };
    const onChangeLimit = val => {
        setLimit(val);
    };
    useEffect(()=>{
        onChangePage(1); // 페이지번호 리셋
    },[keyword]);

    // 필터
    const onFilterTextBoxChanged = useCallback((e) => {
        setFilterValue(e.target.value);
    }, []);


    // 검색창 열기/닫기 > 페이지네이션 여부에 따라 +-20px
    const [gridHeight, setGridHeight] = useState(575);
    const gridExpand = () =>{
        setOpen(!open);
        if(open){
            setTimeout(() => setGridHeight(650), 250);
        }else{
            setGridHeight(575)
        }
    }
    //-------------------// 필수 공통 ------------------------------
    const [gubun, setBugun] = useState('');
    const [searchWord, setSearchWord] = useState('');
    const [param, setParam] = useState({
        blcScnCd:'',    // 분류
        qltyVehlCd:'',  // 차종
        mdlMdyCd:'',    //연식
        regnCd: '', //지역
        langCd:'',

        blcTitlNm:'', //제목
        pprrEeno:'', // 등록인
        blcSn:'', // 관리번호

    })

    useEffect(()=>{
        queryResult.remove()
        console.log('param=>', param)
    },[param]);

    const onChangeBlcScnCd = e => setParam(state => ({...state, blcScnCd: e === 'ALL' ? '' : e }));
    const onChangeQltyVehlCd = e => setParam(state => ({...state, qltyVehlCd: e === 'ALL' ? '' : e }));
    const onChangeMdyCombo = e => setParam(state => ({...state, mdlMdyCd: e === 'ALL' ? '' : e }));
    const onChangeRegionCombo = e => setParam(state => ({...state, regnCd: e === 'ALL' ? '' : e }));
    const onChangeLangCombo = e => setParam(state => ({...state, langCd: e === 'ALL' ? '' : e })); 

    const onChangeGubunCombo = e => setBugun(e); 
    const onChangeSearchWord = e => setSearchWord(e);
    
     // 게시판 목록
    const queryResult = useQuery([API.boardAffrMgmts,param], () => getData(API.boardAffrMgmts,param), {
        // select: data => { 
        //     if(data.length === 1) return data;

        //     data[data.length-1].flag = 1; // 맨끝=1
        //     let cnt = 1;

        //     // for(let i=data.length-2; i>=0; i--){ // 뒤에서 두번쩨부터 시작
        //     //     if(data[i].blcSn === data[i+1].blcSn){ // 현재것==아래것
        //     //         data[i+1].flag = 1; // 아래것=1
        //     //         data[i].flag = ++cnt; // 현재것 ++
        //     //     }else{ // 같지않으면
        //     //         cnt = 1; 
        //     //         data[i].flag = 1; // 현재것 =1
        //     //     }
        //     //     if(i % limit === 0) data[i].tmp = 999;
        //     //     else data[i].tmp = i;
        //     // }

        //     for(let i=data.length-2; i>=0; i--){ // 뒤에서 두번쩨부터 시작
        //         if(data[i].blcSn === data[i+1].blcSn){ // 현재것==아래것
        //             if(i % limit === (limit-1)){ // 페이지 마지막일때
        //                 data[i+1].flag = cnt; // 아래것=cnt
        //                 data[i].flag = 1;   // 현재것 =1
        //                 cnt = 1; // cnt=1
        //             }else{
        //                 data[i+1].flag = 1; // 아래것=1
        //                 data[i].flag = ++cnt; // 현재것 ++
        //             }
        //         }else{ // 같지않으면
        //             cnt = 1; 
        //             data[i].flag = 1; // 현재것 =1
        //         }
        //     }

        //     return data;
        // }
        
   });

   useEffect(() => {
        if(queryResult.data){
            console.log('queryResult',queryResult.data)
        }

   },[queryResult.status])

    //----------------  첨부파일 가져오기 -------------------------------------------------------
    const [openFileDownload, setOpenFileDownload] = useState(false);
    const [fileList, setFileList] = useState(null);
    const [paramFile, setParamFile] = useState(null);
    const queryFile = useQuery([API.fileDownload, paramFile], () => getData(API.fileDownload, paramFile),{
        enabled: false
    });

    useEffect(() => {
        if(fileList){
            setOpenFileDownload(true);
        }
    },[fileList])

    useEffect(() => {
        if(queryFile.isFetched){
            setFileList(queryFile.data);
        }
    },[queryFile.status]);

    useEffect(() => {
        if(paramFile){
            queryFile.refetch();
        }
    },[paramFile])
    //----------------//  첨부파일 가져오기 -------------------------------------------------------

    // 셀 클릭
    const onCellClicked = e => {
        if(e.column.colId === 'blcTitlNm'){ // 상세
            navigate('/board/detail',{ state: e.data.blcSn }); 
        }else if(e.column.colId === 'attcYn' && e.data.attcYn === 'Y'){ // 첨부파일클릭
            queryFile.remove();
            setParamFile({gbnSn: e.data.blcSn ,attcGbn : "B"});
        }
    };


    const addButton = () => {
        navigate('/board/add'); 
    }

     // 조회버튼
     const onSearch = () => {
        if(gubun === 'blcTitlNm') setParam(state => ({...state, blcTitlNm: searchWord, pprrEeno: '', blcSn:''})); 
        else if(gubun === 'pprrEeno') setParam(state => ({...state, blcTitlNm: '', pprrEeno: searchWord, blcSn:''})); 
        else if(gubun === 'blcSn') setParam(state => ({...state, blcTitlNm: '', pprrEeno: '', blcSn:searchWord})); 
    };

    const onKeyUp = e => {
        // console.log('e',e)
        if(e.keyCode === 13) onSearch();
    }

    //---------------- filter -------------------------------------------------------------------------

    // 분류
    const paramBlcScnCd = { dlExpdGCd: '0039'}; // 게시판구분 (불용재고, 교체투입, 분리투입, 기타)
    const blcScnCdCombo = useQuery([API.codeCombo, paramBlcScnCd], () => getData(API.codeCombo, paramBlcScnCd),{
        select: data => [{label: CONSTANTS.labelAll, value: CONSTANTS.valueAll}].concat(data)
    });
    
    // 모든차종
    const vehlCombo = useQuery([API.vehlComboAll], () => getData(API.vehlComboAll), {
            select: data => [{label: CONSTANTS.labelAll, value: CONSTANTS.valueAll}].concat(data.map((item) => ({ label: item.value + '('+ escapeCharChange(item.label)+')', value: item.value})))
    }); 
    useEffect(()=>{
        console.log('vehlCombo.data',vehlCombo.data)
    },[vehlCombo.data])

    // 모든연식
    const mdyCombo = useQuery([API.mdyComboAll, {}], () => getData(API.mdyComboAll,{}), {
        select: data => [{label: CONSTANTS.labelAll, value: CONSTANTS.valueAll}].concat(data) //.map((item) => ({ label: item.label, value: item.value})))
    }); 

    // 모든지역
    const params = {
        dlExpdGCd: '0008' // 지역그룹코드
    };
    const regionCombo = useQuery([API.codeCombo, params], () => getData(API.codeCombo, params));

    // 모든언어
    const langCombo = useQuery([API.langCombo], () => getData(API.langCombo), {
        select: data => [{label: CONSTANTS.labelAll, value: CONSTANTS.valueAll}].concat(data.map((item) => ({ label: escapeCharChange(item.langCdNm), value: item.langCd, dlExpdRegnCd: item.dlExpdRegnCd })))
    }); 
    
    return (
        <>

            {/*--------- 조회조건 -----------*/}
            <div className="search-area">
                <Collapse in={open}>
                    <div className="form" id="example-collapse-text">
                        <div className="search-group">
                            <div className="row">
                                <Col sm={1}>
                                    <Form.ControlLabel column="sm">분류</Form.ControlLabel>
                                    {/* <Input type='number' size="sm" value={blcSn || ''} onChange={e => setBlcSn(e)}/> */}
                                    <SelectPicker size="sm"
                                        value={param.blcScnCd} 
                                        data={blcScnCdCombo.data ? blcScnCdCombo.data : []}  
                                        onChange={onChangeBlcScnCd}
                                        placeholder={CONSTANTS.labelAll}
                                        cleanable={false}
                                        searchable={false}
                                        block={true}
                                    />
                                </Col>
                                <Col sm={2} >
                                    <Form.ControlLabel column="sm">차종</Form.ControlLabel>
                                    <SelectPicker size="sm"
                                        value={param.qltyVehlCd} 
                                        data={vehlCombo.data ? vehlCombo.data : []}  
                                        onChange={onChangeQltyVehlCd}
                                        // onSelect={onSelectVehlCombo}
                                        placeholder={CONSTANTS.labelAll}
                                        cleanable={false}
                                        searchable={true}
                                        block={true}
                                    />
                                </Col>
                                <Col sm={1}> 
                                    <Form.ControlLabel column="sm">연식</Form.ControlLabel>
                                    <SelectPicker size="sm" style={{width: '100%'}}
                                        value={param.mdlMdyCd} 
                                        data={mdyCombo && mdyCombo.data ? mdyCombo.data : []} 
                                        onChange={onChangeMdyCombo}
                                        placeholder={CONSTANTS.labelAll}
                                        cleanable={false}
                                        searchable={false}
                                        block={true}
                                    />
                                </Col>
                                <Col md={2}>
                                    <Form.ControlLabel column="sm">지역</Form.ControlLabel>
                                    <SelectPicker size="sm"
                                        value={param.dlExpdRegnCd} 
                                        data={regionCombo && regionCombo.data ? regionCombo.data : []} 
                                        onChange={onChangeRegionCombo}
                                        placeholder={CONSTANTS.labelAll}
                                        cleanable={false}
                                        searchable={false}
                                        block={true}
                                    />
                                </Col>
                                <Col md={2} >
                                    <Form.ControlLabel column="sm">언어</Form.ControlLabel>
                                    <SelectPicker size="sm"
                                        value={param.langCd} 
                                        data={langCombo && langCombo.data ? langCombo.data : []}  
                                        onChange={onChangeLangCombo}
                                        // onSelect={onSelectLangCombo}
                                        placeholder={CONSTANTS.labelAll}
                                        cleanable={false}
                                        searchable={true}
                                        block={true}
                                    />
                                </Col>
                                <Col sm={4}  >
                                    <Form.ControlLabel column="sm">검색어</Form.ControlLabel>
                                    <Row className="select-wrap">
                                        <Col sm={3}> 
                                            <SelectPicker size="sm" data={[
                                                    {label: '제목', value: 'blcTitlNm'},
                                                    {label: '등록자', value: 'pprrEeno'},
                                                    {label: '관리번호', value: 'blcSn'},
                                                ]} 
                                                onChange={onChangeGubunCombo}
                                                placeholder='선택' searchable={false} cleanable={false} />
                                        </Col>
                                        <Col sm={7}> 
                                            <Input size="sm" value={searchWord || ''} onChange={onChangeSearchWord} onKeyUp={onKeyUp}/>
                                        </Col>
                                    </Row>
                                </Col>
                               
                            </div>
                            <div className="search-btn-wrap">
                                <Button className="btn-search" variant="outline-primary" size="sm" onClick={onSearch}><SearchIcon />조회</Button>
                            </div>
                        </div>
                        
                    </div>
                </Collapse>
                <Button size="sm" variant="outline-dark" className="search-control" aria-controls="example-collapse-text" 
                    aria-expanded={open} onClick={gridExpand}>
                    {/* <span className={open === true ? "search-area-close" : "search-area-open"}>{open === true ? CONSTANTS.closeSearch : CONSTANTS.openSearch}</span> */}
                    {open 
                        ? 
                        <span className="search-area-close">
                            <ArrowUpLine style={{marginRight: '5px', fontSize: '2em'}} />
                            {CONSTANTS.closeSearch}
                        </span> 
                        :
                        <span className="search-area-open">
                            <ArrowDownLine style={{marginRight: '5px', fontSize: '2em'}} />
                            {CONSTANTS.openSearch}
                        </span>
                    }
                </Button>
            </div>

            <div className="grid-wrap">
                <div className="grid-btn-wrap">
                    <div className="left-align">
                        
                    </div>
                    <div className="right-align">
                        <Button variant="outline-secondary" size="sm" onClick={addButton} className='me-2'>게시글 등록</Button>
                    </div>
                </div>
               {/*--------- Grid -----------*/}
                <GridBoardList 
                    queryResult={queryResult}
                    limit={limit}
                    activePage={activePage}
                    onCellClicked={onCellClicked}
                    />

                {/*--------- 페이징 -----------*/}
                <Paging 
                    total={queryResult && queryResult.data && queryResult.data.length}
                    limit={limit}
                    activePage={activePage}
                    onChangePage={onChangePage}
                    onChangeLimit={onChangeLimit}
                />
            </div>

           
            {openFileDownload && fileList && fileList.length > 0 &&
                <FileControl 
                        mode='view' 
                        gubun='A' 
                        onHide={()=>setOpenFileDownload(false) } 
                        fileList={fileList}
                    />}
        </>
    )
};
export default BoardList;