/* eslint-disable react-hooks/exhaustive-deps */
import React ,{useState, useRef, useEffect, useMemo, useCallback} from 'react';
import {Button,Modal, Row, Col, Table} from 'react-bootstrap';
import {Schema, Form, SelectPicker, CustomProvider, DatePicker, Radio, RadioGroup, Checkbox, MultiCascader, Input, InputGroup} from 'rsuite';
import { AgGridReact } from 'ag-grid-react';

import { useNavigate } from 'react-router-dom';
import { useLocation } from "react-router";

//--------------  서버데이터용 필수 -------------------------------
import { useQuery, useQueryClient, useMutation} from 'react-query';
import { getData, postData } from '../../../../utils/async';
import { API, CONSTANTS } from '../../../../utils/constants';
import useStore from '../../../../utils/store';
//--------------// 서버데이터용 필수 -------------------------------
import { confirmAlert } from 'react-confirm-alert'; 
import ConfirmAlert from   '../../../Common/ConfirmAlert';  
import { changeCharToEscape, escapeCharChange,escapeCharChangeForGrid, checkUploadFileType, convertYmd, unescapeHtml, getApiUrl} from '../../../../utils/commUtils';
import moment from 'moment';

import { DEXT5Editor } from 'dext5editor-react';
import { DEXT5Upload } from 'dext5upload-react';

import ko from 'rsuite/locales/ko_KR';
import SearchIcon from '@rsuite/icons/Search';

const { StringType, MixedType} = Schema.Types;
const model = Schema.Model({
    blcScnCd: StringType().isRequired('분류를 선택해주세요.'),
    befmyTrwiYn: StringType().isRequired('전MY투입가능여부를 선택해주세요.'),
    bbYn: StringType().isRequired('책등 유무를 선택해주세요.'),
    dtrwiYn: StringType().isRequired('분리투입여부를 선택해주세요.'),
    altrTrwiYn: StringType().isRequired('교체투입여부를 선택해주세요.'),
    blcTitlNm: StringType().isRequired('제목을 입력해주세요.'),
});


const Field = React.forwardRef((props, ref) => {
    const { name, message, label, accepter, error, ...rest } = props;
    return (
      <Form.Group controlId={`${name}-10`} ref={ref} className={error ? 'has-error' : ''}>
        <Form.ControlLabel>{label} </Form.ControlLabel>
        <Form.Control name={name} accepter={accepter} errorMessage={error} {...rest} />
        <Form.HelpText>{message}</Form.HelpText>
      </Form.Group>
    );
  });




const BoardUpdate = () => {

    const navigate = useNavigate();
    const { state } = useLocation();
    const [showUpload, setShowUpload ] = useState(false);
    const queryClient = useQueryClient();

    // Form 정의 (for validation..)
    const formRef = React.useRef();
    const [formError, setFormError] = React.useState({});
    const [formValue, setFormValue] = React.useState({
         blcScnCd: '',   // 게시물 구분코드(분리투입, 교체투입...)
         regnNm:'',     // 등록인
         befmyTrwiYn: '', // 전MY투입가능여부
         bbYn: '', // 책등여부
         bbVal: '', // 책등값
         dtrwiRqYmd: null,       //분리투입요청일
         dtrwiYn: '',           // 분리투입여부
         dtrwiMidcsnYn: false,    // 분리투입미확정여부
         altrTrwiYn: '',       // 교체투입여부
         nmtrwiRqYmd: null,      // 신규매뉴얼투입요청일
         nmtrwiMidcsnYn: false,   // 신규매뉴얼투입미확정여부
         blcTitlNm: '',  //게시물제목명
         // blcSbc: '',  //게시물내용 
         
         // attcYn: '',  //첨부여부
         // replyYn: '',  //댓글여부
         // delYn: '',  //삭제여부
         // emlCd: '', //이메일 코드(리턴값)
 
         // langCdByVehl: [], //차종및 언어
         // rcvUsers: [], // 수신인
    });

    const [files, setFiles] = useState(null)

    //----------------  게시판 정보 가져오기 ----------------------------------
    const queryParam = {blcSn: state};
    const queryResult = useQuery([API.boardAffrMgmt, queryParam], () => getData(API.boardAffrMgmt, queryParam));
 
    useEffect(()=> {
 
        if(queryResult.isFetched){
            // console.log('queryResult', queryResult.data);

            const detail = queryResult.data.detail;
            setFormValue(p => ({...p, 
                blcScnCd: detail.blcScnCd,          // 게시물 구분코드(분리투입, 교체투입...)
                regnNm: detail.regnNm,              // 등록인 이름
                befmyTrwiYn: detail.befmyTrwiYn,    // 전MY투입가능여부
                dtrwiYn: detail.dtrwiYn,            // 분리투입여부
                altrTrwiYn: detail.altrTrwiYn,      // 교체투입여부
                bbYn: detail.bbYn,                  // 책등여부
                bbVal: detail.bbVal,                // 책등값
                dtrwiRqYmd: new Date(convertYmd(detail.dtrwiRqYmd)),        //분리투입요청일
                dtrwiMidcsnYn: detail.dtrwiMidcsnYn === 'Y' ? true : false, // 분리투입미확정여부
                nmtrwiRqYmd: new Date(convertYmd(detail.nmtrwiRqYmd)),      // 신규매뉴얼투입요청일
                nmtrwiMidcsnYn: detail.nmtrwiMidcsnYn === 'Y' ? true : false, // 신규매뉴얼투입미확정여부
                blcTitlNm: detail.blcTitlNm,                                // 제목
            }))
            // 내용
            setTimeout(() => DEXT5.setBodyValue(unescapeHtml(queryResult.data.detail.blcSbc), 'editor1'), 500);

            // 파일
            setFiles(queryResult.data.files);
            setTimeout(()=> setShowUpload(true), 100);
            
            // 차종언어
            setSelectedLangCdByVehl(queryResult.data.vehls)
        }
    },[queryResult.status])
 
    useEffect(()=> {
         if(!state) navigate('/board')
    },[state]);

    //----------------//  게시판 정보가져와 초기입력 ----------------------------------


    const gridRef = useRef();
    const gridVehlRef = useRef();
    const {coCd} = useStore();

    const [gubun, setGubun] = useState([]);

    // 게시판구분
    const params = {
        dlExpdGCd: '0039' // 게시판 구분 (불용재고, 교체투입, 분리투입, 기타)
    };
    const gubunCombo = useQuery([API.codeCombo, params], () => getData(API.codeCombo, params));
    useEffect(() => {
        if(gubunCombo.isFetched){
            setGubun(gubunCombo.data)
        }
    },[gubunCombo.data])


    // 기존업로드된 파일리스트 (수정화면에서 사용)
    const onCreationComplete = e => {
        if(files){
            for(let i=0; i<files.length; i++){
                DEXT5UPLOAD.AddUploadedFile(''+(i+1), escapeCharChange(files[i].fileNm), '', files[i].fileSize, files[i].attcSn, 'dext5upload1');
            }
        }
    }

    //--------------------//  게시판 정보가져와 초기입력 ------------------------------------------

    
    
    //------------------------------- 차종 및 언어 - Cascader -------------------------------------
    const [openCascader, setOpenCascader] = useState(false);
    const toggle = () => setOpenCascader(!openCascader)
    const headers = ['차종', '연식', '언어'];
    const [vehlLang, setVehlLang] = useState([]); // value (선택된데이타)
    const [vehlLangData, setVehlLangData] = useState([]); // data (가져온 리스트)

    // 차종및언어목록 임시저장
    const [vehlLangDataTemp, setVehlLangDataTemp] = useState([]);
    const [searchWord, setSearchWord] = useState('');

    const onSearch = (val) => {
        setSearchWord(val)
    }
    const onClickSearch = (e) => {
        
    }
    
    useEffect(() => {
        setVehlLangData(vehlLangDataTemp
            .filter(p => p.label.indexOf(searchWord) > -1));
    },[searchWord])

    //차종 및 언어 그리드
    const [selectedLangCdByVehl, setSelectedLangCdByVehl] = useState([]);
    const columnDefs = [
        {
            headerName: '차종',
            field: 'qltyVehlNm',
            cellRenderer: function(params) {
                return params.data.qltyVehlCd + ' (' + escapeCharChange(params.value) + ')';
            }
        },
        {
            headerName: '연식',
            field: 'mdlMdyCd',
        },
        {
            headerName: '언어',
            field: 'langCdNm',
        },
    ];

  
    

    // 차종쿼리
    const [paramVehl, setParamVehl] = useState();
    const vehlCombo = useQuery([API.vehlsByUserCombo, paramVehl], () => getData(API.vehlsByUserCombo, paramVehl),{
        enabled: false,
        // select: data => data.map(item => ({
        //     level: 0, 
        //     label: item.qltyVehlCd + ' (' + escapeCharChange(item.qltyVehlNm) + ')', 
        //     value: item.qltyVehlCd, 
        //     children: item.children ? item.children.map(item2 => ({
        //         level: 1, 
        //         label: item2.qltyVehlNm, 
        //         value: item2.qltyVehlCd, 
        //         children: item2.children ? item2.children.map(item3 => ({
        //             level: 2, 
        //             label: escapeCharChange(item3.langCdNm), 
        //             value: item3.langCd, 
        //             children: null
        //         })) : []  
        //     })) : [] 
        // }))
        select: data => data.map(item => ({...item, label: item.value + ' (' + escapeCharChange(item.label) + ')' }))
    }); 

    // useEffect(() => {
    //     if(paramVehl){
    //         // console.log('#### 2', paramVehl)
    //         vehlCombo.refetch();
    //     }
    // },[paramVehl])

    useEffect(() => {
        if(paramVehl){
            vehlCombo.refetch();
        }
    },[paramVehl])

    useEffect(() => {
        if(selectedLangCdByVehl){
            setParamVehl({arr: selectedLangCdByVehl.map(item => item.qltyVehlCd + '_' + item.mdlMdyCd).join(',')})
        }
    },[selectedLangCdByVehl])


    // 그리드용 차종,연식,언어 리스트
    const param = {codes: vehlLang.join(',')}
    const queryGrid = useQuery([API.vehlMdyLangGrid, param], () => getData(API.vehlMdyLangGrid, param),{
        enabled:  false,
    }); 
   

    useEffect(() => {
        if(vehlCombo.isFetched){
            // console.log('vehlCombo.data',vehlCombo.data)
            
            // multiCascator 리스트 세팅
            setVehlLangData(vehlCombo.data) // cascader용
            setVehlLangDataTemp(vehlCombo.data) // temp용

            // multiCascator 기존값 입력
            setVehlLang(selectedLangCdByVehl.map(item => item.qltyVehlCd + '_' + item.mdlMdyCd))
        }
    },[vehlCombo.status])

   
    // 닫기버튼
    const onCloseVehlLang = e => {
        setOpenCascader(false);
        queryGrid.refetch();
    }

    // "clear"버튼 그리드데이타 삭제
    const onCleanVehlLang = e => {
        setSelectedLangCdByVehl([]);
    }

    // 그리드용 차종,연식,언어 리스트
    useEffect(() => {
        if(queryGrid.isFetched){
            setSelectedLangCdByVehl(queryGrid.data)        
        }
    },[queryGrid.data]);
      
    // 자식 가져오기
    // 차종코드_연식_언어코드
    const getChildren = (e) => {
       
        return new Promise(resolve => {  
            console.log('getChildren', e)
            if(e.level === 0){ // 연식쿼리
                const qltyVehlCd = e.value;
                getData(API.mdysByVehlCdCombo, {qltyVehlCd: qltyVehlCd}).then(items => {
                    const children = items.map(item => ({level: 1, label: qltyVehlCd + '_' + item + '연식', value: qltyVehlCd+'_'+item, children:[] })) // => 차종코드_연식
                    resolve(children);
                })
            }else if(e.level === 1){ // 언어쿼리
                const qltyVehlCd = e.value.split('_')[0];
                const mdlMdyCd = e.value.split('_')[1];
                getData(API.langsByVehlCdMdyCombo, {qltyVehlCd: qltyVehlCd, mdlMdyCd: mdlMdyCd}).then(items => {
                    const children = items.map(item => ({label: item.langCdNm, value: e.value+'_'+item.langCd , children: null })) // => 차종코드_연식_언어코드
                    resolve(children);
                })
            }
        });
    }

    

   
    //-------------------------------// 차종 및 언어 - Cascader ---------------------


    //----------------------- 수신인 ---------------------------------------------

    const columnDefs2 = [
        {
          checkboxSelection: true,
          headerCheckboxSelection: true,
          width:45,
          maxWidth:45,
          minWidth:45
        },
        {
          headerName: '소속',
          field: 'coDeptNm',
          cellRenderer: data => escapeCharChangeForGrid(data)
        },
        {
          headerName: '이름',
          field: 'userNm',
          cellRenderer: data => escapeCharChangeForGrid(data)
        },
    ]

    const defaultColDef = useMemo(() => {
        return {
            initialWidth: 90,
            sortable: true,
        };
    }, []);

    const onFirstDataRendered = (params) => {
        params.api.sizeColumnsToFit();
    };

    const onFirstDataRenderedUsrData = (params) => {
        params.api.sizeColumnsToFit();

         // usrData checked
         gridRef.current.api.forEachNode((node) =>
            node.setSelected(!!node.data && node.data.checked)
        );
    };

    const paramsUsr = {
        blnsCoCd: coCd
    }
    const usrData = useQuery([API.userMgmtPop,paramsUsr], () => getData(API.userMgmtPop, paramsUsr), {
        enabled: queryResult.isFetched,
        select: data => data.map(item => ({...item, coDeptNm: item.coNm+'('+item.deptNm+')', 
                                                    checked: queryResult.data.users.find(f => f.userEeno === item.userEeno) ? true : false })),
    })
    //수신인 그리드 내에서 클릭된 RowData by Woong
    const [checkedRowData, setCheckedRowData] = useState();
    const onSelectionChanged = useCallback(() => {
        const selectedRows = gridRef.current.api.getSelectedRows();
        setCheckedRowData(selectedRows)
    }, []);
    //-----------------------// 수신인 ---------------------------------------------


    // 파일업로드 완료후 데이타저장
    const [fileInfo, setFileInfo] = useState(null);
    useEffect(()=> {
        if(fileInfo){

            const param = {
                blcSn: state, //게시물번호
                blcScnCd: formValue.blcScnCd,   // 게시물 구분코드
                befmyTrwiYn: formValue.befmyTrwiYn, // 전MY투입가능여부
                bbYn: formValue.bbYn, // 책등여부
                bbVal: formValue.bbVal, // 책등값
                dtrwiRqYmd: moment(formValue.dtrwiRqYmd).format('YYYYMMDD'),       //분리투입요청일
                dtrwiYn: formValue.dtrwiYn,           // 분리투입여부
                dtrwiMidcsnYn: formValue.dtrwiMidcsnYn ? 'Y': 'N',    // 분리투입미확정여부
                altrTrwiYn: formValue.altrTrwiYn,       // 교체투입여부
                nmtrwiRqYmd: moment(formValue.nmtrwiRqYmd).format('YYYYMMDD'),      // 신규매뉴얼투입요청일
                nmtrwiMidcsnYn: formValue.nmtrwiMidcsnYn ? 'Y': 'N',   // 신규매뉴얼투입미확정여부
                blcTitlNm: formValue.blcTitlNm,  //게시물제목명
    
                langCdByVehl: selectedLangCdByVehl.map(item => ({qltyVehlCd: item.qltyVehlCd, mdlMdyCd: item.mdlMdyCd, langCd: item.langCd})) || [], // 차종및 언어
                rcvUsers: gridRef.current.api.getSelectedRows().map(item => item.userEeno),               // 수신인
                blcSbc: DEXT5.getBodyValue(),       //  내용
                attcYn: DEXT5UPLOAD.GetTotalFileCount() > 0 ? 'Y' : 'N', // 파일첨부 여부
            }
            // console.log('param', param);

            // 추가된 파일들
            if(fileInfo.newFile){
                // newFile
                param.attcSn = fileInfo.newFile.uploadPath; // tb_attc_mgmt의 attcSn
                param.size = fileInfo.newFile.size;
                param.extension = fileInfo.newFile.extension;
                param.originalName = fileInfo.newFile.originalName;
            }

            // 삭제된 파일들
            const deletedList = DEXT5UPLOAD.GetDeleteListForJson("dext5upload1");
            if(deletedList){
                param.attcSnDeleted = deletedList.customValue;
            }

            // console.log('updateParam', param);
            updateMutate.mutate(param);
        }
    },[fileInfo]);

    // 파일업로드후 - 리턴값(uploadPath)는 여기서만 받음.
    const onTransferComplete = e => {
        const fileList = DEXT5UPLOAD.GetAllFileListForJson("dext5upload1");
        setFileInfo(fileList || {})
    }

    // 파일추가 전 처리할 내용
    const onBeforeAddItem = e => {
        if(!checkUploadFileType(e.eventInfo.paramObj)){
            confirmAlert({
                closeOnClickOutside: false,
                customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}  title={"알림"} msg={"업로드 할 수 없는 파일형식 입니다."}  />
            });
            return false;
        }
        return true;
    }
    // 파일업로드 시작시 사용자 데이타추가
    const onTransferStart = e => {
        DEXT5UPLOAD.AddFormData("gubun", "A", "dext5upload1");
    }

   

    // 등록
    const updateMutate = useMutation((params => postData(API.boardAffrMgmt, params, CONSTANTS.update)),{
        onSuccess: res => {
            console.log('res', res);
            if(res > 0){
                queryClient.invalidateQueries([API.boardAffrMgmt]);
                queryClient.invalidateQueries([API.boardAffrMgmts]);

                confirmAlert({
                    closeOnClickOutside: false,
                    customUI: ({ onClose }) => <ConfirmAlert  title={"알림"} msg={"저장되었습니다."} onClose={onClose} pageMove={() => navigate('/board')}   />
                });

            }else{
                confirmAlert({
                    closeOnClickOutside: false,
                    customUI: ({ onClose }) => <ConfirmAlert onClose={onClose} title={"알림"} msg={"저장실패했습니다"}   />
                });
            }
        }
    });


    // 저장버튼
    const saveButton = () => {
        if (!formRef.current.check()) {
            return;
        }

        // 적용차종및 언어
        if(selectedLangCdByVehl.length === 0){
            confirmAlert({
                closeOnClickOutside: false,
                customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}  title={"알림"} msg={"차종 및 언어를 선택해주세요."}  />
            })
            return;
        }
        
        // 수신인
        const rcvUsers = gridRef.current.api.getSelectedRows().map(item => item.userEeno);
        
        if(rcvUsers.length === 0){
            confirmAlert({
                closeOnClickOutside: false,
                customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}  title={"알림"} msg={"수신인을 선택해주세요."}  />
            })
            return;
        }

        //책등색상
        if(formValue.bbYn === 'Y' && formValue.bbVal === ''){
            setFormError(formError => ({...formError, bbVal: true}));
            return;
        }

        // 내용
        const textValue = DEXT5.getBodyTextValue();
        if(DEXT5.getBodyTextValue().length === 0){
            confirmAlert({
                closeOnClickOutside: false,
                customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}  title={"알림"} msg={"내용을 입력해주세요."}  />
            })
            return;
        }
        DEXT5UPLOAD.Transfer();
    }

    return (
        <>
            <div className="write-wrap">
                <Form
                    ref={formRef}
                    checkTrigger="change"
                    onChange={setFormValue}
                    onCheck={setFormError}
                    formValue={formValue}
                    model={model}
                    >
                    <Table className="tbl-hor" bordered>
                        <colgroup>
                            <col style={{width:'15%'}}></col>
                            <col style={{width:'35%'}}></col>
                            <col style={{width:'15%'}}></col>
                            <col style={{width:'35%'}}></col>
                        </colgroup>
                        <tbody>
                            <tr>
                                <th>관리번호</th>
                                <td colSpan={"3"}>{state}</td>
                            </tr>
                            <tr>
                                <th>분류</th>
                                <td>
                                    <Form.Control 
                                        name="blcScnCd" 
                                        size="sm" 
                                        placeholder={'선택'}
                                        accepter={SelectPicker} 
                                        searchable={false}
                                        cleanable={false}
                                        data={gubun}
                                    ></Form.Control>

                                </td>
                                <th>등록자</th>
                                <td>{formValue.regnNm}</td>
                            </tr>
                            <tr>
                                <th>차종 및 언어</th>
                                <td colSpan="3">
                                {vehlCombo.isFetched && <MultiCascader 
                                        open={openCascader}
                                        menuHeight={450}
                                        menuWidth={250}
                                        size="sm"
                                        block
                                        className="multi-cascader"
                                        data={vehlLangData}
                                        value={vehlLang}
                                        onChange={setVehlLang}
                                        onClick={toggle}
                                        onClean={onCleanVehlLang}
                                        searchable={false}
                                        getChildren={getChildren}
                                        renderMenu={(children, menu, parentNode, layer) => (
                                            <div>
                                                <div >
                                                {layer === 0 && 
                                                    <InputGroup inside style={{width: '230px', marginTop: '10px'}}> 
                                                    <Input autoFocus onChange={onSearch} value={searchWord} style={{width: '100%'}} /> 
                                                        <InputGroup.Button>
                                                            <SearchIcon onClick={onClickSearch} />
                                                        </InputGroup.Button>
                                                    </InputGroup> }
                                                    {layer !== 0 && <div style={{height: '46px'}}>&nbsp;</div>}
                                                </div>
                                                <div className='multi-cascader-header'>
                                                    {headers[layer]}
                                                </div>
                                            
                                                {menu}
                                            </div>
                                        )}
                                        renderExtraFooter={() => (
                                            <div className='multi-cascader-footer'>
                                                {/* <Button variant="secondary" onClick={toggle}>취소</Button>{' '} */}
                                                <Button variant="primary" onClick={onCloseVehlLang}>확인</Button>
                                            </div>
                                        )}
                                        />}
                                </td>
                            </tr>
                            <tr>
                                <th>적용 차종 및 언어</th>
                                <td>
                                    <div className="ag-theme-alpine" style={{height: 130, transition:'all ease .3s'}}>
                                        <AgGridReact
                                            ref={gridVehlRef}
                                            initialWidth={90}
                                            sortable={true}
                                            // defaultColDef={defaultColDef}
                                            columnDefs={columnDefs}
                                            rowData={selectedLangCdByVehl}
                                            // rowData={vehls}
                                            onFirstDataRendered={onFirstDataRendered}
                                            suppressSizeToFit={true}    
                                            onGridSizeChanged={onFirstDataRendered}    
                                            overlayNoRowsTemplate={'적용차종 및 언어를 선택하세요.'}
                                            > 
                                        </AgGridReact> 
                                    </div>
                                </td>
                                <th>수신인</th>
                                <td>
                                    <div className="ag-theme-alpine" style={{height: 130, transition:'all ease .3s'}}>
                                        {usrData && usrData.isSuccess &&
                                            <AgGridReact
                                            ref={gridRef}
                                            initialWidth={90}
                                            sortable={true}
                                            // defaultColDef={defaultColDef}
                                            rowData={usrData && usrData.isSuccess &&usrData.data}
                                            columnDefs={columnDefs2}
                                            rowSelection={'multiple'}
                                            suppressRowClickSelection= {true} 
                                            onFirstDataRendered={onFirstDataRenderedUsrData}
                                            suppressSizeToFit={true}    
                                            onGridSizeChanged={onFirstDataRendered}
                                            // checkedRowDatas by Woong
                                            onSelectionChanged={onSelectionChanged}
                                            >
                                            </AgGridReact>
                                        }
                                    </div>
                                </td>
                            </tr>
                            <tr>
                                <th>전 MY 투입가능</th>
                                <td>
                                    <Form.Control inline name="befmyTrwiYn" accepter={RadioGroup} className='ms-3' >
                                        <Radio value="Y">Y</Radio>
                                        <Radio value="N">N</Radio>
                                    </Form.Control> 
                                </td>
                                <th>책등 유무</th>
                                <td>
                                    <div className="form-group">
                                         <Form.Control inline name="bbYn" accepter={RadioGroup} defaultValue={'N'} className='ms-3' >
                                            <Radio value="Y">Y</Radio>
                                            <Radio value="N">N</Radio>
                                        </Form.Control>
                                        <Form.Control disabled={formValue.bbYn==='N'} name="bbVal" className="inline-block ml-10" size="sm" style={{width:'130px'}} type="text" placeholder="색상을 입력해주세요" />
                                        <Form.ErrorMessage show={formValue.bbYn==='Y' && formValue.bbVal === ''} style={{marginLeft: '150px'}} >색상을 입력해주세요.</Form.ErrorMessage>
                                    </div>
                                </td>
                            </tr>
                            <tr >
                                <th>분리투입 여부</th>
                                <td>
                                    <Form.Control inline name="dtrwiYn" accepter={RadioGroup} className='ms-3' >
                                        <Radio value="Y">Y</Radio>
                                        <Radio value="N">N</Radio>
                                    </Form.Control>
                                </td>
                                <th>분리투입 요청일</th>
                                <td >
                                    <Form.Group>
                                        <Form.Control name="dtrwiRqYmd" disabled={formValue.dtrwiYn==='N' || formValue.dtrwiMidcsnYn===true} oneTap size="sm" cleanable={false} accepter={DatePicker} style={{width:'150px', marginRight: '10px'}} />
                                        <Form.Control name="dtrwiMidcsnYn" disabled={formValue.dtrwiYn==='N'} accepter={Checkbox} checked={formValue.dtrwiMidcsnYn} value={!formValue.dtrwiMidcsnYn}>미확정</Form.Control>
                                    </Form.Group>
                                </td>
                            </tr>
                            <tr>
                                <th>교체투입 여부(이전매뉴얼 폐기)</th>
                                <td>
                                    <Form.Control inline name="altrTrwiYn" accepter={RadioGroup} className='ms-3' >
                                        <Radio value="Y">Y</Radio>
                                        <Radio value="N">N</Radio>
                                    </Form.Control>
                                </td>
                                <th>신규매뉴얼 투입 요청일</th>
                                <td>
                                     <Form.Group>
                                        <Form.Control name="nmtrwiRqYmd" disabled={formValue.altrTrwiYn==='N' || formValue.nmtrwiMidcsnYn===true}   oneTap size="sm" cleanable={false} accepter={DatePicker}  style={{width:'150px', marginRight: '10px'}} />
                                        <Form.Control name="nmtrwiMidcsnYn" disabled={formValue.altrTrwiYn==='N'}  accepter={Checkbox} checked={formValue.nmtrwiMidcsnYn} value={!formValue.nmtrwiMidcsnYn}>미확정</Form.Control>
                                    </Form.Group>
                                </td>
                            </tr>
                            <tr>
                                <th>제목</th>
                                <td colSpan="3">
                                    <Form.Control name="blcTitlNm" size="sm" type="text" placeholder="제목을 입력해주세요" />
                                </td>
                            </tr>
                            <tr>
                                <th>내용</th>
                                <td colSpan="3">
                                   <DEXT5Editor
                                        debug={true}
                                        id="editor1"
                                        componentUrl="/dext5editor/js/dext5editor.js"
                                        config={{ DevelopLangage:'NONE', Width:'100%' }}
                                        // initData="<p>Hello <strong>DEXT5 Editor</strong> world!</p>"
                                    />
                                   
                                </td>
                            </tr>
                            <tr>
                                <th>첨부파일</th>
                                <td colSpan="3">
                                   { showUpload && <DEXT5Upload
                                        onCreationComplete={onCreationComplete}
                                        onTransferStart={onTransferStart}
                                        onTransferComplete={onTransferComplete}
                                        onBeforeAddItem={onBeforeAddItem}
                                        debug={false}
                                        id="dext5upload1"
                                        mode='edit' 
                                        runtimes='html5'
                                        componentUrl="/dext5upload/js/dext5upload.js"
                                        config={{MaxTotalFileSize:'100MB', MaxOneFileSize:'30MB', DevelopLangage:'NONE', Width:'100%',
                                            ButtonBarEdit: "add,remove,remove_all",
                                            HandlerUrl:  getApiUrl() + 'dext5upload', 
                                            DownloadHandlerUrl: getApiUrl() + 'dext5upload',
                                        }}
                                        
                                    />}
                                </td>
                            </tr>
                        </tbody>
                    </Table>
                </Form>
        
                <div className="btn-wrap">
                    <div className="right-align">
                        <Button variant="light" onClick={()=>navigate('/board/detail', {state: state})}>취소</Button>{' '}
                        <Button className="" variant="primary" size="md" onClick={saveButton}>저장</Button>
                    </div>
                </div>
            </div>
        </>
    )
};
export default BoardUpdate;