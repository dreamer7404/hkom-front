import React, { useState, useMemo, useRef, useEffect } from 'react';
import {Button, Modal} from 'react-bootstrap';
import { AgGridReact } from 'ag-grid-react';
import { CONSTANTS } from '../../../../utils/constants';
// //--------------  서버데이터용 필수 -------------------------------
import { useQuery } from 'react-query';
import { getData } from '../../../../utils/async';
import { API } from '../../../../utils/constants';
import { formatNumber, escapeCharChangeForGrid } from '../../../../utils/commUtils';
// //--------------// 서버데이터용 필수 -------------------------------
//아이콘
import {ArrowDownLine, ArrowUpLine, FileDownload} from '@rsuite/icons';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faFileExcel,faPrint } from '@fortawesome/free-solid-svg-icons'
//모달
import CustomModal from '../../../Common/CustomModal';
import { excelDownload as excelDownloadAggrid } from '../../../../utils/excelForAggrid';

const SewonIvmHave = ({show, onHide, clickedRowData}) => {

    // 수량 천단위 콤마 찍기 끝
    const currencyFormatter = (params) => {
        return formatNumber(params.value);
    }; 
    const gridRef = useRef();

    const queryResult = useQuery([API.ivmSewonIvs, clickedRowData], () => getData(API.ivmSewonIvs, clickedRowData), {
        //화면 열렸을때 무조건 실행 방지를 위한 옵션.
        enabled: false,
    });

    useEffect(() => {
        if(show){
            queryResult.refetch();
        }
    }, [clickedRowData]);

    
    const onFirstDataRendered = (params) => {
        params.api.sizeColumnsToFit();
    };

    const defaultColDef = useMemo(() => {
        return {
            sortable: true,
            minWidth:100,
            resizable:false,
            flex:1,
        };
    }, []);

    const columnDefs = [
        {
            headerName: '발간번호',
            field: 'newPrntPbcnNo',
            colSpan: (params) => {
                const newPrntPbcnNo = params.data.newPrntPbcnNo;
                if (newPrntPbcnNo === 'TOTAL') {
                    // have all Russia age columns width 2
                    return 4;
                } else {
                    // all other rows should be just normal
                    return 1;
                }
            }
        },
        {
            headerName: '발주일',
            field: 'prntParrYmd',
        },
        {
            headerName: '납품일',
            field: 'dlvgParrYmd',
        },
        {
            headerName: '기납품수량',
            field: 'prevDlvgQty',
            valueFormatter: currencyFormatter
        }, 
        {
            headerName: '재고수량',
            field: 'ivQty',
            valueFormatter: currencyFormatter
        }, 
        {
            headerName: '타연식 제공내역',
            field: 'ivText',
            cellRenderer:escapeCharChangeForGrid,
            minWidth: 150
        }, 
    ]

    const [total, setTotal] = useState({});
    const [queryResultRealDatas, setQueryResultRealDatas] = useState([]);

    useEffect(()=>{
        if(queryResult.isSuccess){
            setTotal(
                queryResult.isSuccess && queryResult.data.filter(item => {
                    return item.newPrntPbcnNo === 'TOTAL'
                })[0]
            )
            setQueryResultRealDatas (
                queryResult.isSuccess && queryResult.data.filter(item => {
                    return item.newPrntPbcnNo !== 'TOTAL'
                })
            )
        }    
    },[queryResult.data]);

    const pinnedBottomRowData = [total];

    //엑셀다운로드
    const [excelStatus, setExcelStatus] = useState(false);
    useEffect(() => {
        if(excelStatus) {
            setExcelStatus(excelDownloadAggrid(gridRef, '세원재고(보유재고)', 1, 'TOTAL'))
        }
    }, [excelStatus])

    return (
        <>
            <CustomModal open={show} 
                title={'세원재고(보유재고)'}
                size='lg'
                // handleOk={handleSubmit}
                handleCancel={onHide} 
            >
            {/* <Modal show={show} onHide={onHide} backdrop="static" keyboard={false} centered size="lg" className="modal-custom">
                <Modal.Header closeButton>
                    <Modal.Title>세원재고(보유재고)</Modal.Title>
                </Modal.Header>
                <Modal.Body> */}
                    <div className="grid-btn-wrap">
                        <div className="left-align">
                            <div className="sub-title">
                                <ul>
                                    {/*                                     
                                    <li>차종 <span>(AA-19)AA-CAR</span></li>
                                    <li>언어 <span>EC(영어,불어/캐나다)</span></li>
                                     */}
                                    <li>차종 <span>({clickedRowData.qltyVehlCd} - {clickedRowData.mdlMdyCd}){clickedRowData.qltyVehlNm}</span></li>
                                    <li>언어 <span>{clickedRowData.langCd}({clickedRowData.langCdNm})</span></li>
                                </ul>
                            </div>
                        </div>
                        <div className="right-align">
                            <Button variant="outline-success btn-excel" size="sm" disabled={excelStatus} onClick={() => setExcelStatus(true)}>
                                <FontAwesomeIcon icon={faFileExcel}/>
                                {CONSTANTS.excelDownload}
                            </Button>{' '}
                            <Button variant="outline-dark btn-print" size="sm"onClick={() => window.print()}><FontAwesomeIcon icon={faPrint}/>{CONSTANTS.print}</Button>{' '}
                        </div>
                    </div>
                    <div style={{ display: 'flex', flexDirection: 'column', height: 300 }} className="ag-theme-alpine" >
                        <div style={{ flex: '1 1 auto'}}>
                            <AgGridReact
                                // rowData={rowData}
                                // rowData={queryResult && queryResult.data}
                                ref={gridRef}
                                rowData={queryResult && queryResultRealDatas}                                
                                columnDefs={columnDefs}
                                defaultColDef={defaultColDef}
                                onFirstDataRendered={onFirstDataRendered}
                                suppressSizeToFit={true}
                                pinnedBottomRowData={pinnedBottomRowData}
                                // overlay
                                overlayLoadingTemplate={CONSTANTS.gridLoading}
                                overlayNoRowsTemplate={CONSTANTS.gridNoRows}
                                frameworkComponents={{
                                    escapeCharChangeForGrid
                                }}
                                >
                            </AgGridReact>
                        </div>
                    </div>
                <div className='modal-footer'>
                    <Button variant="light" size="md" onClick={onHide}>취소</Button>
                    {/* <Button variant="primary" size="md" onClick={handleSubmit} >저장</Button> */}
                </div>
            </CustomModal>
                {/* </Modal.Body>
                <Modal.Footer>
                    <Button variant="light" size="md" onClick={onHide}>취소</Button>
                </Modal.Footer>
            </Modal> */}
        </>
    )
};
export default SewonIvmHave;