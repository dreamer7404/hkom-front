import React, { useState, useEffect} from 'react';
import {Button, Modal, Table} from 'react-bootstrap';
import { CONSTANTS } from '../../../../utils/constants';
import { escapeCharChange, formatNumber} from '../../../../utils/commUtils';
// //--------------  서버데이터용 필수 -------------------------------
import { useQuery } from 'react-query';
import { getData } from '../../../../utils/async';
import { API } from '../../../../utils/constants';
// //--------------// 서버데이터용 필수 -------------------------------
//아이콘
import {ArrowDownLine, ArrowUpLine, FileDownload} from '@rsuite/icons';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faFileExcel,faPrint } from '@fortawesome/free-solid-svg-icons'
//모달
import CustomModal from '../../../Common/CustomModal';
import { excelDownloadTable } from '../../../../utils/excelForProductPlan3Days';


const ProductPlan3Days = ({show, onHide, clickedRowData}) => {

    const queryResult = useQuery([API.ivm3DayPlan, clickedRowData], () => getData(API.ivm3DayPlan, clickedRowData), {
        //화면 열렸을때 무조건 실행 방지를 위한 옵션.
        enabled: false,
    });
    useEffect(() => {
        if(show){
            queryResult.refetch();
        }
    }, [clickedRowData]);

    //엑셀다운로드
    const [excelStatus, setExcelStatus] = useState(false);
    useEffect(() => {
        if(excelStatus) {
            const colDefs = [
                {headerName:'구분', field:'col0' ,rowSpan:'2' },
                {headerName:'번호', field:'col1' ,rowSpan:'2' },
                {headerName:'공정명', field:'col2' ,rowSpan:'2' },
                {headerName:'대수', field:'col3' },
                {headerName:'From', field:'from' },
                {headerName:'To', field:'to' },
            ]
            const rowDatas = [
                {col0:'계획', col1:'0', col2:'투입계획(D+2)', col3:queryResult.data.th0PowTrwiQty, from:queryResult.data.th0PowStrtYmdhm, to:queryResult.data.th0PowFnhYmdhm },
                {col0:'의장', col1:'6', col2:'TRIM IN', col3:queryResult.data.th6PowTrwiQty, from:queryResult.data.th6PowStrtYmdhm, to:queryResult.data.th6PowFnhYmdhm },
                {col0:'의장', col1:'7', col2:'C/FINAL', col3:queryResult.data.th7PowTrwiQty, from:queryResult.data.th7PowStrtYmdhm, to:queryResult.data.th7PowFnhYmdhm },
                {col0:'의장', col1:'8', col2:'S/OFF', col3:queryResult.data.th8PowTrwiQty, from:queryResult.data.th8PowStrtYmdhm, to:queryResult.data.th8PowFnhYmdhm },
                {col0:'PDI 미통과분', col1:'PDI 미통과분', col2:'PDI 미통과분', col3:queryResult.data.powTrwiQty, from:queryResult.data.powStrtYmdhm, to:queryResult.data.powFnhYmdhm },
                {col0:'총계', col1:'총계', col2:'총계', col3:'3일 계획', from:'3일 계획', to:'0'  ,flag:2 },
                {col0:'총계', col1:'총계', col2:'총계', col3:'공정 투입', from:'공정 투입', to:queryResult.data.planTotQty+'-'+queryResult.data.th0PowTrwiQty ,flag:0 },
            ]
            
            setExcelStatus(excelDownloadTable(rowDatas, colDefs, 1, '단기계획(3일)', '총계', 2, ['col0','col1','col2']))
        }
    }, [excelStatus])
    const excelDownload = () => {
        
    }

    return (
        <>
            <CustomModal open={show} 
                title={'단기계획(3일)'}
                size='lg'
                // handleOk={handleSubmit}
                handleCancel={onHide} 
            >
            {/* <Modal show={show} onHide={onHide} backdrop="static" keyboard={false} centered size="lg" className="modal-custom">
                <Modal.Header closeButton>
                    <Modal.Title>단기계획(3일)</Modal.Title>
                </Modal.Header>
                <Modal.Body> */}
                    <div className="grid-btn-wrap">
                        <div className="left-align">
                            <div className="sub-title">
                                <ul>
                                    <li>차종 <span>({clickedRowData.qltyVehlCd} - {clickedRowData.mdlMdyCd}){clickedRowData.qltyVehlNm}</span></li>
                                    <li>언어 <span>{clickedRowData.langCd}({clickedRowData.langCdNm})</span></li>
                                </ul>
                            </div>
                        </div>
                        <div className="right-align">
                            <Button variant="outline-success btn-excel" size="sm" disabled={excelStatus} onClick={() => setExcelStatus(true)}>
                                <FontAwesomeIcon icon={faFileExcel}/>
                                {CONSTANTS.excelDownload}
                            </Button>{' '}
                            <Button variant="outline-dark btn-print" size="sm"onClick={() => window.print()}><FontAwesomeIcon icon={faPrint}/>{CONSTANTS.print}</Button>{' '}
                        </div>
                    </div>
                    <Table className="tbl-ver" bordered>
                        <thead>
                            <tr>
                                <th>구분</th>
                                <th>번호</th>
                                <th>공정명</th>
                                <th>대수</th>
                                <th>From</th>
                                <th>To</th>
                            </tr>
                        </thead>
                        {queryResult.isFetched 
                        ?
                        <tbody>
                            <tr>
                                <td>계획</td>
                                <td>0</td>
                                <td>투입계획(D+2)</td>
                                <td className="item-num">{formatNumber(queryResult.data.th0PowTrwiQty)}</td>
                                <td>{queryResult.data.th0PowStrtYmdhm}</td>
                                <td>{queryResult.data.th0PowFnhYmdhm}</td>
                            </tr>
                            <tr>
                                <td>의장</td>
                                <td>6</td>
                                <td>TRIM IN</td>
                                <td className="item-num">{formatNumber(queryResult.data.th6PowTrwiQty)}</td>
                                <td>{escapeCharChange(queryResult.data.th6PowStrtYmdhm)}</td>
                                <td>{escapeCharChange(queryResult.data.th6PowFnhYmdhm)}</td>
                            </tr>
                            <tr>
                                <td>의장</td>
                                <td>7</td>
                                <td>C/FINAL</td>
                                <td className="item-num">{formatNumber(queryResult.data.th7PowTrwiQty)}</td>
                                <td>{escapeCharChange(queryResult.data.th7PowStrtYmdhm)}</td>
                                <td>{escapeCharChange(queryResult.data.th7PowFnhYmdhm)}</td>
                            </tr>
                            <tr>
                                <td>의장</td>
                                <td>8</td>
                                <td>S/OFF</td>
                                <td className="item-num">{formatNumber(queryResult.data.th8PowTrwiQty)}</td>
                                <td>{escapeCharChange(queryResult.data.th8PowStrtYmdhm)}</td>
                                <td>{escapeCharChange(queryResult.data.th8PowFnhYmdhm)}</td>
                            </tr>
                            <tr>
                                <td colSpan="3">PDI 미통과분</td>
                                <td className="item-num">{formatNumber(queryResult.data.powTrwiQty)}</td>
                                <td>{escapeCharChange(queryResult.data.powStrtYmdhm)}</td>
                                <td>{escapeCharChange(queryResult.data.powFnhYmdhm)}</td>
                            </tr>
                            <tr>
                                <th colSpan="3" rowSpan="2">총계</th>
                                <th colSpan="2">3일 계획</th>
                                <th className="item-num">{JSON.stringify(queryResult.data.planTotQty)}</th>
                            </tr>
                            <tr>
                                <th colSpan="2">공정 투입</th>
                                <th className="item-num">{queryResult.data.planTotQty}-{queryResult.data.th0PowTrwiQty}</th>
                            </tr>
                        </tbody>
                        :
                        <tbody>
                            <tr>
                                <td colSpan="6">데이터가 없습니다.</td>
                            </tr>
                        </tbody>
                        }
                    </Table>
                    {/* <p className="tbl-info">※ <span>2023-01-31 12:00</span> 기준</p> */}
                    {queryResult.isFetched 
                     ?
                    <p className="tbl-info">※ <span>{escapeCharChange(queryResult.data.vlocalChar)}</span> 기준</p>
                    : null
                    }
                    
                <div className='modal-footer'>
                    <Button variant="light" size="md" onClick={onHide}>취소</Button>
                    {/* <Button variant="primary" size="md" onClick={handleSubmit} >저장</Button> */}
                </div>
            </CustomModal>
                {/* </Modal.Body>
                <Modal.Footer>
                    <Button variant="light" size="md" onClick={onHide}>취소</Button>
                </Modal.Footer>
            </Modal> */}
        </>
    );

};
export default ProductPlan3Days;