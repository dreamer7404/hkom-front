import React, {useState, useMemo, useEffect, useCallback, useRef} from 'react';
import { AgGridReact } from 'ag-grid-react';
import {Col, Modal, Button, Spinner} from 'react-bootstrap';
import {Form, SelectPicker, MaskedInput, Notification, toaster} from 'rsuite';
import SearchIcon from '@rsuite/icons/Search';
import { escapeCharChange, escapeCharChangeForGrid, formatNumber, utcToLocalDate } from '../../../../utils/commUtils';
import useStore from '../../../../utils/store';

// //--------------  서버데이터용 필수 -------------------------------
import { useMutation, useQuery, useQueryClient} from 'react-query';
import { postData, getData } from '../../../../utils/async';
import { API, CONSTANTS } from '../../../../utils/constants';
// //--------------// 서버데이터용 필수 -------------------------------

import { confirmAlert } from 'react-confirm-alert'; // Import
import ConfirmAlert from '../../../Common/ConfirmAlert';

// import VehlType from '../../../Search/VehlType';
import VehlTypeForPop from '../../../Search/VehlTypeForPop';
// import Lang from '../../../Search/Lang';
import LangForPop from '../../../Search/LangForPop';
//아이콘
import {ArrowDownLine, ArrowUpLine, FileDownload} from '@rsuite/icons';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faFileExcel,faPrint } from '@fortawesome/free-solid-svg-icons'
//모달
import CustomModal from '../../../Common/CustomModal';
import { excelDownload as excelDownloadAggrid } from '../../../../utils/excelForAggrid';



const IvmModify = ({show, onHide, menuGubun}) => {

    // 수량 천단위 콤마 찍기
    const currencyFormatter = (params) => {
        return formatNumber(params.value);
    };

    //  세원재고 조회
    const { keyword } = useStore();  // 조회키워드 가져오기
    
    // 차종콤보 컴포넌트 내에서 선택된 파라미터
    const [vehlParams, setVehlParams] = useState({
        dlExpdPdiCd: '',
        qltyVehlCd: '',
        mdlMdyCd: ''
    });    
    const onChangeVehlParam = e => {
        setVehlParams(e)
    };

    // 언어콤보 컴포넌트 내에서 선택된 파라미터
    const [langParams, setLangParams] = useState({
        dlExpdRegnCd : '',
        langCd : ''
    });    
    const onChangeLangParam = e => {
        setLangParams(e)
    };
    

    const [spinner, setSpinner] = useState('')
    const [param, setParam] = useState({})
    useEffect(() => {
        queryResultInPop.remove()
        setSpinner(" whirl traditional")
        setParam({
            bDate: keyword.bDate,
            dlExpdPdiCd: vehlParams.dlExpdPdiCd,
            qltyVehlCd: vehlParams.qltyVehlCd,
            mdlMdyCd: vehlParams.mdlMdyCd,
            dlExpdRegnCd: langParams.dlExpdRegnCd,
            langCd: langParams.langCd,
            menuGubun: menuGubun
        })
    },[vehlParams, langParams])
    const queryResultInPop = useQuery([API.ivmIvModInfos, param], () => getData(API.ivmIvModInfos, param), {
        staleTime:0,
        // select: data => data.map(item => ({...item, menuGubun:menuGubun})) 
    });


    // 조회버튼
    const onSearch = () => {
        queryClient.invalidateQueries([API.ivmIvModInfos]);
        setSpinner(" whirl traditional")
        //시간차두기
        setTimeout(() => {queryResultInPop.refetch()}, 100);
        // queryResultInPop.refetch(); // 수동쿼리실행
    };

    
   

    const [excelStatus, setExcelStatus] = useState(false);
    useEffect(() => {
        if(excelStatus) {
            setExcelStatus(excelDownloadAggrid(gridRef, '재고보정', 2))
        }
    }, [excelStatus])

    const queryClient = useQueryClient();
    const onHideLocal = () => {
        // gridRef.current.reset()
        queryClient.invalidateQueries([API.ivmIvModInfos]);
        setCheckedRowsForOutReqInput([])
        setCheckedNodesForOutReqInput([])
    }

    
    const [formValue, setFormValue] = useState();
    useEffect(() => {
      if(queryResultInPop.isSuccess && queryResultInPop.data)  {
        setSpinner("")
        setFormValue(queryResultInPop.data)
      }
    },[queryResultInPop.data])

    //보유재고+보정수량이 되는경우
    const addModCd = ['05', '06', '11'];

    const NumberComponent = props => {
        const option = 
            {
              mask: [/\d/, /\d/, /\d/, /\d/, /\d/, /\d/, /\d/]
            }
        
        const onChangeInput = (newValue, oldValue) => {
            if(parseInt(newValue) > parseInt(props.data.ivQty)){
                props.node.setDataValue(props.colDef.field, props.data.ivQty)
                // props.node.setDataValue('fixedIvQty', calcByModCd(props.data.ivQty, props.data.modQty))
            } else {
                props.node.setDataValue(props.colDef.field, newValue.replace(/(^0+)/, ""))
                // props.node.setDataValue('fixedIvQty', calcByModCd(newValue.replace(/(^0+)/, ""), props.data.modQty))
            }
        };

        return (
            <div className="grid-form-wrap">
                    <MaskedInput
                        value={props.value ? props.value : 0}
                        mask={option.mask}
                        guide={false}
                        showMask={false}
                        onChange={e => onChangeInput(e, props.value)}
                        maxLength={props.data.ivQty.length}
                        //당일 데이터가 아닌경우 input에 readonly 활성화..
                        // readOnly={props.data.clScnCd==='N'?true:false}
                    />
            </div>
        )
    }

    const inputComponent = (props) => {
        const onChangeInput = (newValue, oldValue) => {
            props.node.setDataValue(props.colDef.field, escapeCharChange(newValue))
        };
        
        return (
          <div className="grid-form-wrap">
            <Form.Control 
                name="name" 
                size="sm" 
                placeholder="" 
                onChange={e => onChangeInput(e, props.value)} 
                value={props!==null && props.value && escapeCharChange(props.value) || ''}
                //당일 데이터가 아닌경우 input에 readonly 활성화..
                // readOnly={props.data.clScnCd==='N'?true:false}
            />
          </div>
        );
    }


    const SelectComponent = (props) => {
        
        let selectMenuGroup = [
            {value:'02', label:'별도지급'},
            {value:'03', label:'폐기'},
            {value:'05', label:'추가입고'},
            {value:'06', label:'전시차'},
            {value:'07', label:'추가출고'},
            {value:'08', label:'반출'},
            {value:'11', label:'재고실사+'},
            {value:'12', label:'재고실사-'}
        ];
        const [selectedValue, setSelectedValue] = useState(props.value);
        const onChangeSelectDt = value => {
            setSelectedValue(value);
        };
        useEffect(() => {
            selectedValue 
            ? props.node.setDataValue('modCd',selectedValue)
            : props.node.setDataValue('modCd','07')
        })
        return (
            <div className='grid-form-wrap'>
                
                <SelectPicker
                    // disabled={isCurrentRowEditing ? true : false}
                    size="sm"
                    searchable={false}
                    cleanable={false}
                    value={selectedValue && selectedValue!==''?selectedValue:'07'}
                    onChange={onChangeSelectDt}
                    data={selectMenuGroup}
                />
            </div>
        );
    }

    const gridRef = useRef();

    const columnDefs = [
        {
            checkboxSelection: true,
            headerCheckboxSelection: true,
            spanHeaderHeight: true,
            width:35,
            maxWidth:35,
            minWidth:35,
            sortable: false
        },
        {
          headerName: '차종',
          children: [
            { headerName:'차종코드', field: 'qltyVehlCd', minWidth:70,},
            { headerName:'차종명', field: 'qltyVehlNm',minWidth:130, cellRenderer:escapeCharChangeForGrid },
            { headerName:'연식', field: 'mdlMdyCd' , minWidth:50,},
          ],
        },
        {
          headerName: '언어',
          children: [
            { headerName:'지역', field: 'dlExpdPrvsNm', minWidth:70,},
            { headerName:'언어코드', field: 'langCd',minWidth:70, },
            { headerName:'언어명', field: 'langCdNm',minWidth:130,},
          ],
        },
        {
          headerName: '발간번호',
          field: 'newPrntPbcnNo',
          spanHeaderHeight: true,
          width:110,
        },

        // {
        // headerName: 'dtlSn(지워야함)',
        // field: 'dtlSn',
        // spanHeaderHeight: true,
        // width:80,
        // },   

        {
            headerName: '보정구분',
            field: 'modCd',
            spanHeaderHeight: true,
            cellRenderer:SelectComponent,
            width:120,
            aggFunc: params => { //엑셀다운로드 할 때 해당 Cell의 데이터를 매핑하기위한 작업(해당 Cell이 셀렉트 박스인경우, label이 나오도록 하기위함..)
                if(params === '02'){
                    return '별도지급';
                } else if (params === '03') {
                    return '폐기';
                } else if (params === '05') {
                    return '추가입고';
                } else if (params === '06') {
                    return '전시차';
                } else if (params === '07') {
                    return '추가출고';
                } else if (params === '08') {
                    return '반출';
                } else if (params === '11') {
                    return '재고실사+';
                } else if (params === '12') {
                    return '재고실사-';
                }
            }
        },  
        {
          headerName: '보유재고',
          field: 'ivQty',
          spanHeaderHeight: true,
          width:100,
          valueFormatter: currencyFormatter
        },  
        {
            headerName: '보정수량',
            field: 'modQty',
            spanHeaderHeight: true,
            cellRenderer:NumberComponent,
            width:100,
        },  
        {
            headerName: '확정재고',
            field: 'fixedIvQty',
            spanHeaderHeight: true,
            width:80,
            valueFormatter: currencyFormatter,
            valueGetter: (params) => {
                return addModCd.filter(item => {
                    return item === params.data.modCd
                }).length === 0 ? (Number(params.data.ivQty)-Number(params.data.modQty)) : (Number(params.data.ivQty)+Number(params.data.modQty))
            },
        },  
        {
            headerName: '보정일',
            field: 'modYmd',
            spanHeaderHeight: true,
            width:80,
        },  
        {
            headerName: '담당자',
            field: 'crgrNm',
            spanHeaderHeight: true,
            width:80,
        },
        {
            headerName: '비고',
            field: 'prtlImtrSbc',
            spanHeaderHeight: true,
            cellRenderer:inputComponent,
            width:150
        },  
    ]
    
    const columnDefs2 = [
        {
            headerName: '일자',
            field: 'clsYmd',
            spanHeaderHeight: true,
            width:150
        },  
        {
          headerName: '차종',
          children: [
            { headerName:'차종코드', field: 'qltyVehlCd', minWidth:70,},
            { headerName:'차종명', field: 'qltyVehlNm',minWidth:130, cellRenderer:escapeCharChangeForGrid },
            { headerName:'연식', field: 'mdlMdyCd' , minWidth:50,},
          ],
        },
        {
          headerName: '언어',
          children: [
            { headerName:'지역', field: 'dlExpdPrvsNm', minWidth:70,},
            { headerName:'언어코드', field: 'langCd',minWidth:70, },
            { headerName:'언어명', field: 'langCdNm',minWidth:130,},
          ],
        },
        {
          headerName: '발간번호',
          field: 'newPrntPbcnNo',
          spanHeaderHeight: true,
          width:110,
        },

        // {
        // headerName: 'dtlSn(지워야함)',
        // field: 'dtlSn',
        // spanHeaderHeight: true,
        // width:80,
        // },   

        {
            headerName: '보정구분',
            field: 'modCd',
            spanHeaderHeight: true,
            cellRenderer:SelectComponent,
            width:120,
            aggFunc: params => { //엑셀다운로드 할 때 해당 Cell의 데이터를 매핑하기위한 작업(해당 Cell이 셀렉트 박스인경우, label이 나오도록 하기위함..)
                if(params === '02'){
                    return '별도지급';
                } else if (params === '03') {
                    return '폐기';
                } else if (params === '05') {
                    return '추가입고';
                } else if (params === '06') {
                    return '전시차';
                } else if (params === '07') {
                    return '추가출고';
                } else if (params === '08') {
                    return '반출';
                } else if (params === '11') {
                    return '재고실사+';
                } else if (params === '12') {
                    return '재고실사-';
                }
            }
        },  
        {
          headerName: '보유재고',
          field: 'ivQty',
          spanHeaderHeight: true,
          width:100,
          valueFormatter: currencyFormatter
        },  
        {
            headerName: '보정수량',
            field: 'modQty',
            spanHeaderHeight: true,
            cellRenderer:NumberComponent,
            width:100,
        },  
        {
            headerName: '확정재고',
            field: 'fixedIvQty',
            spanHeaderHeight: true,
            width:80,
            valueFormatter: currencyFormatter,
            valueGetter: (params) => {
                return addModCd.filter(item => {
                    return item === params.data.modCd
                }).length === 0 ? (Number(params.data.ivQty)-Number(params.data.modQty)) : (Number(params.data.ivQty)+Number(params.data.modQty))
            },
        },  
        {
            headerName: '보정일',
            field: 'modYmd',
            spanHeaderHeight: true,
            width:80,
        },  
        {
            headerName: '담당자',
            field: 'crgrNm',
            spanHeaderHeight: true,
            width:80,
        },
        {
            headerName: '비고',
            field: 'prtlImtrSbc',
            spanHeaderHeight: true,
            cellRenderer:inputComponent,
            width:150
        },  
    ]

    const defaultColDef = useMemo(() => {
        return {
            initialWidth: 90,
            sortable: true,
            resizable:true,
        };
    }, []);

    

    const onFirstDataRendered = (params) => {
        params.api.sizeColumnsToFit();
    };

    // 그리드 내에서 체크된 rows by Woong
    const [checkedRowsForOutReqInput, setCheckedRowsForOutReqInput] = useState([]);    
    const [checkedNodesForOutReqInput, setCheckedNodesForOutReqInput] = useState([]);    
    const onSelectionChanged = useCallback(() => {
        setCheckedRowsForOutReqInput(gridRef.current.api.getSelectedRows())
        setCheckedNodesForOutReqInput(gridRef.current.api.getSelectedNodes())
    }, []);

    

    //데이터 등록(post)
    
    const submitResult = useMutation((params => postData(API.ivmIvModInfos, params, CONSTANTS.insert)),{
        onSuccess: res => {
            setSpinner("")
		    if(res > 0){
                queryClient.invalidateQueries([API.ivmIvModInfos]);
                queryClient.invalidateQueries([API.ivmTotIvInfos]);
                queryClient.invalidateQueries([API.ivmSewonIvmInfos]);
                queryClient.invalidateQueries([API.ivmSewonWhotInfos]);
                queryClient.invalidateQueries([API.ivmSewonWhotInfos2]);
                queryClient.invalidateQueries([API.ivmSewonPrintInfos]);
                queryClient.invalidateQueries([API.ivmPdiIvInfos]);
                queryClient.invalidateQueries([API.ivmPdiWhsnInfo]);
                queryClient.invalidateQueries([API.ivmPdiWhsnStatInfos]);
		        toaster.push(
                    <Notification type='success' header='요청성공' closable >재고보정이 완료되었습니다.</Notification>
                );
                show=false;
                onHideLocal(); // 창닫기
		    }else{
		        toaster.push(
                    <Notification type='error' header='요청실패' closable >재고보정을 실패했습니다.</Notification>
                );
		    }
		}
	});


    const saveButtonFirst = (e, scrollCheck) =>{
        gridRef.current.api.redrawRows()
        setTimeout(onSubmit(e, scrollCheck), 150)
    }
    //저장 버튼 클릭시
    const onSubmit = (e, scrollCheck) => {
        
        if(checkedRowsForOutReqInput.length === 0 && !scrollCheck){
            scrollCheck = true
            confirmAlert({
                closeOnClickOutside: false,
                customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}  title={"알림"} msg={"대상을 선택해주세요."}  />
            })
            return false
        }
        
        for(let i = 0; i < checkedNodesForOutReqInput.length; i ++){

            if(checkedNodesForOutReqInput[i].data.modQty === '0' || checkedNodesForOutReqInput[i].data.modQty === '' || checkedNodesForOutReqInput[i].data.modQty === 0 || checkedNodesForOutReqInput[i].data.modQty === null) {
                if(scrollCheck !== true) {
                    gridRef.current.api.ensureIndexVisible(checkedNodesForOutReqInput[i].rowIndex)
                    confirmAlert({
                        closeOnClickOutside: false,
                        customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}  title={"알림"} msg={'보정수량을 입력하세요.'}  />
                    })
                }
                gridRef.current.api.flashCells({ rowNodes: [checkedNodesForOutReqInput[i]], columns: ['modQty'], fadeDelay: 400000, flashDelay:10 });        
                scrollCheck = true
                break
            }
        }

        if(scrollCheck) {
            return false
        } else {
            const onOk = () => {
                setSpinner(" whirl traditional")
                submitResult.mutate(checkedRowsForOutReqInput)
            }
            confirmAlert({
                closeOnClickOutside: false,
                customUI: ({ onClose }) => <ConfirmAlert 
                                                onClose={onClose} 
                                                title={"알림"}
                                                msg={"입력하신 내용으로 재고보정하시겠습니까?"} 
                                                onOk={onOk}  
                                            />
            })
        }
    };


    //데이터 삭제(post)
    const deleteResult = useMutation([API.ivmIvModInfos, checkedRowsForOutReqInput], () => postData(API.ivmIvModInfos, checkedRowsForOutReqInput, CONSTANTS.delete),{
        onSuccess: res => {
            setSpinner("")
		    if(res > 0){
		        toaster.push(
                    <Notification type='success' header='요청성공' closable >재고보정취소가 완료되었습니다.</Notification>
                );
                show=false;
                onHideLocal(); // 창닫기
		    }else{
		        toaster.push(
                    <Notification type='error' header='요청실패' closable >재고보정취소를 실패했습니다.</Notification>
                );
		    }
		}
	});
    const onDelete = (e) => {
        if(checkedRowsForOutReqInput.length === 0){
            confirmAlert({
                closeOnClickOutside: false,
                customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}  title={"알림"} msg={"대상을 선택해주세요."}  />
            })
            return false
        } else {
            const onOk = () => {
                setSpinner(" whirl traditional")
                deleteResult.mutate(checkedRowsForOutReqInput)
            }
            confirmAlert({
                closeOnClickOutside: false,
                customUI: ({ onClose }) => <ConfirmAlert 
                                                onClose={onClose} 
                                                title={"알림"}
                                                msg={"선택하신 항목을 재고보정취소하시겠습니까?"} 
                                                onOk={onOk}  
                                            />
            })
            
        }
    }

    //월별 엑셀다운로드 시작
    const gridRef2 = useRef();
    const queryResultForExcelDownloadMonthly = useQuery([API.ivmIvModMonthInfos, param], () => getData(API.ivmIvModMonthInfos, param), {
        enabled: false,
        staleTime:0,
    });

    const [excelMonthStatus, setExcelMonthStatus] = useState(false);

    useEffect(() => {
        const fetchData = async () => {
            await queryResultForExcelDownloadMonthly.refetch();
        };

        if (excelMonthStatus) {
            fetchData()
        }
    }, [excelMonthStatus]);

    useEffect(() => {
        if(excelMonthStatus && queryResultForExcelDownloadMonthly.isSuccess){
            const timer = setTimeout(() => {
                setExcelMonthStatus(excelDownloadAggrid(gridRef2, '재고보정-월별다운로드', 2));
                queryClient.invalidateQueries([API.ivmIvModMonthInfos]);
            }, 3000);

            return () => clearTimeout(timer);
        }

    }, [queryResultForExcelDownloadMonthly])

    // useEffect(() => {
    //     if (excelMonthStatus) {
    //         const timer = setTimeout(() => {
    //                 setExcelMonthStatus(excelDownloadAggrid(gridRef2, '재고보정-월별다운로드', 2));
    //         }, 3000);

    //         return () => clearTimeout(timer);
    //     }
    // }, [excelMonthStatus]);
    //월별 엑셀다운로드 끝

    return (
        <>
            <Form>
                <CustomModal open={show} 
                    title={'재고보정'}
                    size='3xl'
                    // handleOk={handleSubmit}
                    handleCancel={onHide} 
                >
                {/* <Modal show={show} onHide={onHide} backdrop="static" keyboard={false} centered size="xl" className="modal-custom size-2xl">
                    <Modal.Header closeButton>
                        <Modal.Title>재고보정</Modal.Title>
                    </Modal.Header>
                    <Modal.Body> */}
                        <div className="search-area">
                            <div className="form" id="example-collapse-text">
                                <div className="search-group">
                                    <div className="row">
                                        <Col sm={5} className="" >
                                            <VehlTypeForPop onChangeVehlParam={onChangeVehlParam} />
                                        </Col>
                                        <Col sm={4} className="" >
                                            <LangForPop onChangeLangParam={onChangeLangParam} vehlParams={vehlParams} />
                                        </Col>
                                    </div>
                                    <div className="search-btn-wrap">
                                        <Button className="btn-search" variant="ou-primary" size="sm" onClick={() => onSearch()}><SearchIcon />조회</Button>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div className="grid-btn-wrap">
                            <div className="left-align">
                                <div className="sub-title">
                                    <ul>
                                {/* <li>2023-03-21</li> */}
                                <li>{utcToLocalDate(new Date())}</li>
                            </ul>
                                </div>
                            </div>
                            <div className="right-align">
                                <Button variant="outline-secondary" size="sm" onClick={onDelete}>재고보정취소</Button>{' '}
                                <Button variant="outline-success btn-excel" size="sm" disabled={excelStatus} onClick={() => setExcelStatus(true)}>
                                    <FontAwesomeIcon icon={faFileExcel}/>
                                    {excelStatus ? '엑셀다운로드 중' :CONSTANTS.excelDownload}
                                </Button>{' '}
                                <Button variant="outline-success btn-excel" size="sm" disabled={excelMonthStatus} onClick={() => setExcelMonthStatus(true)}>
                                    <FontAwesomeIcon icon={faFileExcel}/>
                                    {excelMonthStatus ? (
                                    <>
                                        월별 엑셀다운로드
                                        <Spinner variant="success" size="sm" role="status" animation="border" />
                                    </>
                                    ) : (
                                    '월별 엑셀다운로드'
                                    )}
                                </Button>{' '}
                                <Button variant="outline-dark btn-print" size="sm"onClick={() => window.print()}><FontAwesomeIcon icon={faPrint}/>{CONSTANTS.print}</Button>{' '}
                            </div>
                        </div>
                        {queryResultInPop && 
                        <div className={"ag-theme-alpine" + spinner} style={{height:500, minWidth:300}}>
                            <AgGridReact
                                ref={gridRef} 
                                // rowData={rowData}
                                //rowData={queryResultInPop && queryResultInPop.data}
                                rowData={queryResultInPop && formValue}
                                
                                columnDefs={columnDefs}
                                defaultColDef={defaultColDef}
                                rowSelection={'multiple'}
                                suppressRowClickSelection= {true} 
                                frameworkComponents={{
                                    NumberComponent,
                                    inputComponent,
                                    SelectComponent,
                                    escapeCharChangeForGrid
                                }}
                                onFirstDataRendered={onFirstDataRendered}
                                suppressSizeToFit={true}    
                                onGridSizeChanged={onFirstDataRendered}
                                onGridColumnsChanged={onFirstDataRendered}
                                // checkedRowDatas by Woong
                                onSelectionChanged={onSelectionChanged}

                                overlayLoadingTemplate={CONSTANTS.gridLoading}
                                overlayNoRowsTemplate={CONSTANTS.gridNoRows}
                                >
                            </AgGridReact>
                        </div>
                        }
                        <div className="ag-theme-alpine" style={{height:0, minWidth:0}}>
                            <AgGridReact
                                ref={gridRef2} 
                                // rowData={rowData}
                                //rowData={queryResultInPop && queryResultInPop.data}
                                rowData={queryResultForExcelDownloadMonthly && queryResultForExcelDownloadMonthly.data}
                                
                                columnDefs={columnDefs2}
                                defaultColDef={defaultColDef}
                                rowSelection={'multiple'}
                                suppressRowClickSelection= {true} 
                                frameworkComponents={{
                                    NumberComponent,
                                    inputComponent,
                                    SelectComponent,
                                    escapeCharChangeForGrid
                                }}
                                onFirstDataRendered={onFirstDataRendered}
                                suppressSizeToFit={true}    
                                onGridSizeChanged={onFirstDataRendered}

                                // checkedRowDatas by Woong
                                onSelectionChanged={onSelectionChanged}

                                overlayLoadingTemplate={CONSTANTS.gridLoading}
                                overlayNoRowsTemplate={CONSTANTS.gridNoRows}
                                >
                            </AgGridReact>
                        </div>
                        <div className='modal-footer'>
                            <Button variant="light" size="md" onClick={onHide}>취소</Button>
                            <Button variant="primary" size="md" onClick={e => {saveButtonFirst(e, false)}}>저장</Button>
                        </div>
                </CustomModal>
                    {/* </Modal.Body>
                    <Modal.Footer>
                        <Button variant="light" size="md" onClick={onHide}>취소</Button>
                        <Button variant="primary" size="md" onClick={e => {onSubmit(e, false)}}>저장</Button>
                    </Modal.Footer>
                </Modal> */}
            </Form>
        </>
    );

};
export default IvmModify;