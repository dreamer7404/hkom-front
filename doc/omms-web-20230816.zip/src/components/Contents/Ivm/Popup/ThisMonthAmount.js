import React, { useState, useEffect} from 'react';
import {Row, Col, Button, Modal, Table} from 'react-bootstrap';
import { CONSTANTS } from '../../../../utils/constants';
import { formatNumber } from '../../../../utils/commUtils';
// //--------------  서버데이터용 필수 -------------------------------
import { useQuery } from 'react-query';
import { getData } from '../../../../utils/async';
import { API } from '../../../../utils/constants';
// //--------------// 서버데이터용 필수 -------------------------------
//아이콘
import {ArrowDownLine, ArrowUpLine, FileDownload} from '@rsuite/icons';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faFileExcel,faPrint } from '@fortawesome/free-solid-svg-icons'
//모달
import CustomModal from '../../../Common/CustomModal';
import { excelDownloadTable } from '../../../../utils/excelForAggrid';

const ThisMonthAmount = ({show, onHide, clickedRowData}) => {

    const queryResult = useQuery([API.ivmThisMonTrwis, clickedRowData], () => getData(API.ivmThisMonTrwis, clickedRowData), {
        //화면 열렸을때 무조건 실행 방지를 위한 옵션.
        enabled: false,
    });

    useEffect(() => {
        if(show){
            queryResult.refetch();
        }
    }, [clickedRowData]);

    //엑셀다운로드
    const [excelStatus, setExcelStatus] = useState(false);
    useEffect(() => {
        if(excelStatus) {
            const colDefs = [
                {headerName:'날짜', field:'wkYmd' },
                {headerName:'입고', field:'whsnQty' },
                {headerName:'투입', field:'whotQty' },
            ]
    
            const rowDatas = queryResult.data
            setExcelStatus(excelDownloadTable(rowDatas, colDefs, 1, '당월투입(누적)', 'TOTAL'))
        }
    }, [excelStatus])

    return (
        <>
            <CustomModal open={show} 
                title={'당월투입(누적)'}
                size='lg'
                // handleOk={handleSubmit}
                handleCancel={onHide} 
            >
            {/* <Modal show={show} onHide={onHide} backdrop="static" keyboard={false} centered size="lg" className="modal-custom">
                <Modal.Header closeButton>
                    <Modal.Title>당월투입(누적)</Modal.Title>
                </Modal.Header>
                <Modal.Body> */}
                    <div className="grid-btn-wrap">
                        <div className="left-align">
                            <div className="sub-title">
                                <ul>
                                    <li>차종 <span>({clickedRowData.qltyVehlCd} - {clickedRowData.mdlMdyCd}){clickedRowData.qltyVehlNm}</span></li>
                                    <li>언어 <span>{clickedRowData.langCd}({clickedRowData.langCdNm})</span></li>
                                </ul>
                            </div>
                        </div>
                        <div className="right-align">
                            <Button variant="outline-success btn-excel" size="sm" disabled={excelStatus} onClick={() => setExcelStatus(true)}>
                                <FontAwesomeIcon icon={faFileExcel}/>
                                {CONSTANTS.excelDownload}
                            </Button>{' '}
                            <Button variant="outline-dark btn-print" size="sm"onClick={() => window.print()}><FontAwesomeIcon icon={faPrint}/>{CONSTANTS.print}</Button>{' '}
                        </div>
                    </div>
                    <Row>
                        <Col xs={6}>
                        <Table className="tbl-ver" bordered>
                            <thead>
                                <tr>
                                    <th>날짜</th>
                                    <th>입고</th>
                                    <th>투입</th>
                                </tr>
                            </thead>
                            <tbody>
                            {queryResult.isFetched && queryResult.data.map((item, index) => (
                                index < 16
                                ?
                                <tr key={index}>
                                    <td>{item.wkYmd}</td>
                                    <td className="item-num">{formatNumber(item.whsnQty)}</td>
                                    <td className="item-num">{formatNumber(item.whotQty)}</td>
                                </tr>
                                :null
                            ))}
                            </tbody>
                        </Table>
                        </Col>
                        <Col xs={6}>
                        <Table className="tbl-ver" bordered>
                            <thead>
                                <tr>
                                    <th>날짜</th>
                                    <th>입고</th>
                                    <th>투입</th>
                                </tr>
                            </thead>
                            <tbody>
                            {queryResult.isFetched && queryResult.data.map((item, index) => (
                                index > 15 
                                ?
                                    item.wkYmd !== 'TOTAL'
                                    ?
                                    <tr key={index}>
                                        <td>{item.wkYmd}</td>
                                        <td className="item-num">{formatNumber(item.whsnQty)}</td>
                                        <td className="item-num">{formatNumber(item.whotQty)}</td>
                                    </tr>
                                    :
                                    <tr key={index}>
                                        <td>합계</td>
                                        <td className="item-num">{formatNumber(item.whsnQty)}</td>
                                        <td className="item-num">{formatNumber(item.whotQty)}</td>
                                    </tr>
                                :null

                            ))}
                            </tbody>
                        </Table>
                        </Col>
                    </Row>
                    <div className='modal-footer'>
                        <Button variant="light" size="md" onClick={onHide}>취소</Button>
                    </div>
            </CustomModal>
                    {/* </Modal.Body>
                <Modal.Footer>
                    <Button variant="light" size="md" onClick={onHide}>취소</Button>
                </Modal.Footer>
            </Modal> */}
        </>
    );

};
export default ThisMonthAmount;