import React, { useState, useEffect} from 'react';
import {Button, Modal, Collapse, Table, Col, Row} from 'react-bootstrap';
import { CONSTANTS } from '../../../../utils/constants';
import { formatNumber } from '../../../../utils/commUtils';
import {SelectPicker } from 'rsuite';
// //--------------  서버데이터용 필수 -------------------------------
import { useQuery } from 'react-query';
import { getData } from '../../../../utils/async';
import { API } from '../../../../utils/constants';
import useStore from '../../../../utils/store'; //plntCd // 기아만 보여야하기때문
// //--------------// 서버데이터용 필수 -------------------------------
//아이콘
import {ArrowDownLine, ArrowUpLine, FileDownload} from '@rsuite/icons';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faFileExcel,faPrint } from '@fortawesome/free-solid-svg-icons'
//모달
import CustomModal from '../../../Common/CustomModal';
import { excelDownloadTable } from '../../../../utils/excelForAggrid';


const ProductPlan2Weeks = ({show, onHide, clickedRowData}) => {
    
   
    const [open, setOpen] = useState(false);
    const [plntCd, setPlntCd] = useState(); //plntCd //조회 파라미터 담을 변수
    const { coCd } = useStore();  // plntCd // 회사코드
    const [param, setParam] = useState("");
    const plntCombo = useQuery([API.plntCombo, {qltyVehlCd : clickedRowData.qltyVehlCd}], () => getData(API.plntCombo,{qltyVehlCd : clickedRowData.qltyVehlCd}), {
        select: data => [{label: CONSTANTS.labelAll, value: CONSTANTS.valueAll}]
            .concat(data)
    }); //plntCd Combo

    
     const onChangePlntCombo = (e)=>{ //plntCd //changeEvent
        setPlntCd(e); //plntCd 자동할당
        setParam(p => ({...p, prdnPlntCd: e}));
    }



    const queryResult = useQuery([API.ivm2WeekPlan, param], () => getData(API.ivm2WeekPlan, param), {
        //화면 열렸을때 무조건 실행 방지를 위한 옵션.
        enabled: false,
    });

    useEffect(()=>{
        if(plntCd){
            queryResult.remove();
            queryResult.refetch();
        }
    },[plntCd])

    useEffect(() => {
        if(coCd==='02') {
            setPlntCd(clickedRowData.prdnPlntCd) //plntCd //처음 들어왔을 시 plntCd 셋팅
        } 
        setOpen(false)
        setParam(clickedRowData); //조회값
    }, [clickedRowData]);

    useEffect(()=>{
        console.log("param",param);
        if(show && param !=""){
            queryResult.refetch();
        }
    },[param])

    //엑셀다운로드
    const [excelStatus, setExcelStatus] = useState(false);
    useEffect(() => {
        if(excelStatus) {
            const colDefs = [
                {headerName:'구분', field:'idxNm' },
                {headerName:'생산일', field:'wkYmd' },
                {headerName:'요일', field:'dowNm' },
                {headerName:'대수', field:'prdnPlnQty' },
                {headerName:'확정여부', field:'dcsnYn' },
            ]
            
            const rowDatas = queryResult.data.slice(0, queryResult.data.length - 1); //2주생산계획은 마지막row에 요약보기 row가 있기때문에 삭제한 후 엑셀다운로드를 진행한다.
            // rowDatas.pop() 
            rowDatas[0]['idxNm'] = rowDatas[0]['wkYmd']
            rowDatas[0]['dowNm'] = rowDatas[0]['wkYmd']
            setExcelStatus(excelDownloadTable(rowDatas, colDefs, 1, '생산계획(2주)', 'TOTAL', 1 , ['idxNm','wkYmd','dowNm']))
        }
    }, [excelStatus])
  
    

    return (
        <>
            <CustomModal open={show} 
                title={'생산계획(2주)'}
                size='lg'
                // handleOk={handleSubmit}
                handleCancel={onHide} 
            >
            {/* <Modal show={show} onHide={onHide} backdrop="static" keyboard={false} centered size="lg" className="modal-custom">
                <Modal.Header closeButton>
                    <Modal.Title>생산계획(2주)</Modal.Title>
                </Modal.Header>
                <Modal.Body> */}
                    <div className="grid-btn-wrap">
                        <div className="left-align">
                            <div className="sub-title">
                                <ul>
                                    {/*                                     
                                    <li>차종 <span>(AA-19)AA-CAR</span></li>
                                    <li>언어 <span>EC(영어,불어/캐나다)</span></li>
                                     */}
                                  
                                    <li>차종 <span>({clickedRowData.qltyVehlCd} - {clickedRowData.mdlMdyCd}){clickedRowData.qltyVehlNm}</span></li>
                                    <li>언어 <span>{clickedRowData.langCd}({clickedRowData.langCdNm})</span></li>
                                    {coCd==='02'&& clickedRowData.prdnPlntCd!="N"&&<li>공정
                                        <span style={{display:"inline-block"}}>
                                            <Col sm={5}>
                                                <SelectPicker size="sm" style={{marginLeft:"10px"}}
                                                    value={plntCd? plntCd:""}
                                                    data={plntCombo && plntCombo.data ? plntCombo.data : []}   //plntCd
                                                    placeholder="전체"
                                                    onChange={onChangePlntCombo} //plntCd
                                                    searchable={false} 
                                                    cleanable={false} 
                                                />
                                            </Col>
                                        </span>
                                    </li>}
                                </ul>
                            </div>
                        </div>
                        <div className="right-align">
                            <Button variant="outline-success btn-excel" size="sm" disabled={excelStatus} onClick={() => setExcelStatus(true)}>
                                <FontAwesomeIcon icon={faFileExcel}/>
                                {CONSTANTS.excelDownload}
                            </Button>{' '}
                            <Button variant="outline-dark btn-print" size="sm"onClick={() => window.print()}><FontAwesomeIcon icon={faPrint}/>{CONSTANTS.print}</Button>{' '}
                        </div>
                    </div>
                    <Table className="tbl-ver" bordered>
                        <thead>
                            <tr>
                            <th>구분</th>
                            <th>생산일</th>
                            <th>요일</th>
                            <th>대수</th>
                            <th>확정여부</th>
                            </tr>
                        </thead>
                        <tbody>
                            {queryResult.isFetched && queryResult.data.map((item, index) => (

                                    index === 0 
                                    ?
                                    <tr key={index}>                                                        
                                        <td colSpan="3">PDI 미통과분</td>
                                        <td className="item-num">{formatNumber(item.prdnPlnQty)}</td>
                                        <td></td>
                                    </tr>
                                    :
                                        item.idxNm !== 'TOTAL'
                                        ?
                                            item.idxNm !== null
                                            ?
                                                <tr key={index}>
                                                    <td>{item.idxNm}</td>
                                                    <td>{item.wkYmd}</td>
                                                    <td>{item.dowNm}</td>
                                                    <td className="item-num">{formatNumber(item.prdnPlnQty)}</td>
                                                    <td>{item.dcsnYn}</td>
                                                </tr>
                                            : null
                                        :
                                        <tr key={index}>
                                            <th colSpan="3">{item.idxNm}</th>
                                            <th className="item-num" colSpan="2" >{formatNumber(item.prdnPlnQty)}</th>
                                        </tr>
                            ))}
                        </tbody>
                    </Table>
                    <Button size="sm" variant="outline-dark" className="search-control" onClick={() => { setOpen(!open) }} aria-controls="example-collapse-text" aria-expanded={open} >
                            {/* <span className={open === true ? "area-close" : "area-open"}>
                                {open === true ? "요약내용 닫기" : "요약내용 열기"}
                            </span> */}

                            {open 
                                ? 
                                <span className="search-area-close">
                                    <ArrowUpLine style={{marginRight: '5px', fontSize: '2em'}} />
                                    <span style={{fontSize: '11px'}}>요약내용 닫기</span>
                                </span> 
                                :
                                <span className="search-area-open">
                                    <ArrowDownLine style={{marginRight: '5px', fontSize: '2em'}} />
                                    <span style={{fontSize: '11px'}}>요약내용 열기</span>
                                </span>
                            }
                    </Button>
                    <Collapse in={open}>
                        <div id="example-collapse-text">
                        <Table className="tbl-hor" bordered>
                            <colgroup>
                            <col style={{width:'50%'}}></col>
                            <col style={{width:'50%'}}></col>
                            </colgroup>
                            {queryResult.isFetched && queryResult.data.map((item, index) => (
                                item.idxNm === null
                                ?
                                <tbody key={index}> 
                                    <tr>
                                        <th>총 오더</th>
                                        <td className="item-num">{formatNumber(item.totOrdQty)}</td>
                                    </tr>
                                    <tr>
                                        <th>기 생산</th>
                                        <td className="item-num">{formatNumber(item.prevProdQty)}</td>
                                    </tr>
                                    <tr>
                                        <th>가용 오더</th>
                                        <td className="item-num">{formatNumber(item.netOrdQty)}</td>
                                    </tr>
                                    <tr>
                                        <th>당월 오더</th>
                                        <td className="item-num">{formatNumber(item.currOrdQty)}</td>
                                    </tr>
                                    <tr>
                                        <th>당월 생산</th>
                                        <td className="item-num">{formatNumber(item.currProdQty)}</td>
                                    </tr>
                                    <tr>
                                        <th>당월 예상</th>
                                        <td className="item-num">{formatNumber(item.currPlanQty)}</td>
                                    </tr>
                                    <tr>
                                        <th>차월 이월</th>
                                        <td className="item-num">{formatNumber(item.nextOrdQty)}</td>
                                    </tr>
                                </tbody>
                                :
                                null
                            ))}
                                
                            
                        </Table>
                        <p className="tbl-info">※ 현재월 기준입니다.</p>
                        </div>
                    </Collapse>

                    <div className='modal-footer'>
                        <Button variant="light" size="md" onClick={onHide}>취소</Button>
                        {/* <Button variant="primary" size="md" onClick={handleSubmit} >저장</Button> */}
                    </div>
            </CustomModal>
                {/* </Modal.Body>
                <Modal.Footer>
                    <Button variant="light" size="md" onClick={onHide}>취소</Button>
                </Modal.Footer>
            </Modal> */}
        </>
    );

};
export default ProductPlan2Weeks;