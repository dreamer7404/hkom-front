import React, {useState, useMemo, useRef, useEffect} from 'react';
import {Modal, Button} from 'react-bootstrap';
import {Form, MaskedInput, Notification, toaster} from 'rsuite';
import { AgGridReact } from 'ag-grid-react';
import { escapeCharChange, escapeCharChangeForGrid, formatNumber, utcToLocalDate } from '../../../../utils/commUtils';

// //--------------  서버데이터용 필수 -------------------------------
import { useMutation} from 'react-query';
import { postData } from '../../../../utils/async';
import { API, CONSTANTS } from '../../../../utils/constants';
// //--------------// 서버데이터용 필수 -------------------------------

import { confirmAlert } from 'react-confirm-alert'; // Import
import ConfirmAlert from '../../../Common/ConfirmAlert';
//아이콘
import {ArrowDownLine, ArrowUpLine, FileDownload} from '@rsuite/icons';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faFileExcel,faPrint } from '@fortawesome/free-solid-svg-icons'
//모달
import CustomModal from '../../../Common/CustomModal';
import { excelDownload as excelDownloadAggrid } from '../../../../utils/excelForAggrid';

const OrderRequest = ({show, onHide, checkedRows}) => {
    const gridRef = useRef();

    const defaultColDef = useMemo(() => {
        return {
            initialWidth: 90,
            resizable:true,
            minWidth:70
        };
    }, []);

    const NumberComponent = props => {
        const option = 
            {
              mask: [/\d/, /\d/, /\d/, /\d/, /\d/, /\d/, /\d/, /\d/]
            }
        
        const onChangeInput = (newValue, oldValue) => {
                props.node.setDataValue(props.colDef.field, newValue.replace(/(^0+)/, ""))
        }; 
        props.node.setDataValue(props.colDef.field, props.value ? props.value : 0)
        
  
        return (
            <div className="grid-form-wrap">
                    <MaskedInput
                        value={props.value ? props.value : 0}
                        mask={option.mask}
                        guide={false}
                        showMask={false}
                        onChange={e => onChangeInput(e, props.value)}
                    />
            </div>
        )
    }

    const columnDefs = [
        {
          headerName: '차종',
          children: [
            { headerName:'차종코드', field: 'qltyVehlCd', minWidth:70,},
            { headerName:'차종명', field: 'qltyVehlNm',minWidth:130, cellRenderer:escapeCharChangeForGrid },
            { headerName:'연식', field: 'mdlMdyCd' , minWidth:50,},
          ],
        },
        {
          headerName: '언어',
          children: [
            { headerName:'지역', field: 'dlExpdRegnNm', minWidth:70,},
            { headerName:'언어코드', field: 'langCd',minWidth:70, },
            { headerName:'언어명', field: 'langCdNm',minWidth:130,},
          ],
        },
        {
            headerName: '수량',
            field: 'rqQty',
            spanHeaderHeight: true,
            cellRenderer:NumberComponent,
            width:100,
        }  
    ]

    

    const onHideLocal = () => {
        checkedRows.map(item => {
          return item.rqQty=''
        })        
        onHide()
      }

    const onFirstDataRendered = (params) => {
        params.api.sizeColumnsToFit();
    };

    //데이터 등록(post)
    const submitResult = useMutation((params => postData(API.ivmPdiOrderRequest, params, CONSTANTS.insert)),{
        onSuccess: res => {
          if(res > 0){
              toaster.push(
                      <Notification type='success' header='요청성공' closable >발주요청이 완료되었습니다.</Notification>
                  );
                  show=false;
                  onHideLocal(); // 창닫기
          }else{
              toaster.push(
                      <Notification type='error' header='요청실패' closable >발주요청을 실패했습니다.</Notification>
                  );
          }
        }
    });

    const saveButtonFirst = () =>{
        gridRef.current.api.redrawRows()
        setTimeout(onSubmit, 150)
    }

    //저장 버튼 클릭시
    const onSubmit = (e, scrollCheck) => {
        let checkedRowsForOutReqInput = gridRef.current.props.rowData
        // gridRef.current.api.redrawRows()
        
        for(let i = 0; i < checkedRowsForOutReqInput.length; i ++){
            const checkedNodesForOutReqInput = gridRef.current.api.getRowNode(i)
            if(checkedNodesForOutReqInput.data.rqQty === '0' || checkedNodesForOutReqInput.data.rqQty === '' || checkedNodesForOutReqInput.data.rqQty === 0 || checkedNodesForOutReqInput.data.rqQty === null || checkedNodesForOutReqInput.data.rqQty === undefined) {
                if(scrollCheck !== true) {
                    gridRef.current.api.ensureIndexVisible(checkedNodesForOutReqInput.rowIndex)
                    confirmAlert({
                        closeOnClickOutside: false,
                        customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}  title={"알림"} msg={'수량을 입력하세요.'}  />
                    })
                }
                gridRef.current.api.flashCells({ rowNodes: [checkedNodesForOutReqInput], columns: ['rqQty'], fadeDelay: 400000, flashDelay:10 });        
                scrollCheck = true
                break
            }
        }
  
        if(scrollCheck) {
            return false
        } else {
            const onOk = () => {
                submitResult.mutate(checkedRowsForOutReqInput)
            }
            confirmAlert({
                closeOnClickOutside: false,
                customUI: ({ onClose }) => <ConfirmAlert 
                                                onClose={onClose} 
                                                title={"알림"}
                                                msg={"입력하신 내용으로 발주요청하시겠습니까?"} 
                                                onOk={onOk}  
                                            />
            })
        }
    };
    //저장 버튼 클릭시 끝

    const [excelStatus, setExcelStatus] = useState(false);
    useEffect(() => {
        if(excelStatus) {
            setExcelStatus(excelDownloadAggrid(gridRef, '발주요청', 2))
        }
    }, [excelStatus])

    return (
        <>
            <Form>
                <CustomModal open={show} 
                    title={'발주요청'}
                    size='lg'
                    // handleOk={handleSubmit}
                    handleCancel={onHideLocal} 
                >
                {/* <Modal show={show} onHide={onHideLocal} backdrop="static" keyboard={false} centered size="lg" className="modal-custom">
                    <Modal.Header closeButton>
                            <Modal.Title>발주요청</Modal.Title>
                        </Modal.Header>
                        <Modal.Body> */}
                            <div className="grid-btn-wrap">
                                <div className="right-align">
                                    <Button variant="outline-success btn-excel" size="sm" disabled={excelStatus} onClick={() => setExcelStatus(true)}>
                                        <FontAwesomeIcon icon={faFileExcel}/>
                                        {CONSTANTS.excelDownload}
                                    </Button>{' '}
                                    <Button variant="outline-dark btn-print" size="sm"onClick={() => window.print()}><FontAwesomeIcon icon={faPrint}/>{CONSTANTS.print}</Button>{' '}
                                </div>
                            </div>
                            <div className="ag-theme-alpine" style={{height:300, minWidth:300}}>
                            <AgGridReact
                                ref={gridRef}
                                rowData={checkedRows}
                                columnDefs={columnDefs}
                                defaultColDef={defaultColDef}
                                frameworkComponents={{
                                    NumberComponent,
                                    escapeCharChangeForGrid
                                }}
                                onFirstDataRendered={onFirstDataRendered}
                                suppressSizeToFit={true}    
                                onGridSizeChanged={onFirstDataRendered}     
                                >
                            </AgGridReact>
                            </div>
                            <p className="tbl-info2">※ 현재 재고 부족으로 상기 매뉴얼의 긴급 발주를 요청합니다.</p>
                    <div className='modal-footer'>
                        <Button variant="light" size="md" onClick={() => onHideLocal()}>취소</Button>
                        <Button variant="primary" size="md" onClick={() => saveButtonFirst()} >저장</Button>
                    </div>
                </CustomModal>
                        {/* </Modal.Body>
                        <Modal.Footer>
                            <Button variant="light" size="md" onClick={onHideLocal}>취소</Button>
                            <Button variant="primary" size="md" onClick={onSubmit}>저장</Button>
                        </Modal.Footer>
                </Modal> */}
            </Form>
        </>
    );

};
export default OrderRequest;