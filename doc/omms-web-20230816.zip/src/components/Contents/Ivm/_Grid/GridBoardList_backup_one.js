import React, {useEffect, useMemo, useRef, useState, useCallback} from 'react';
import { AgGridReact } from 'ag-grid-react';
import { CONSTANTS } from '../../../../utils/constants';
import AttachmentIcon from '@rsuite/icons/Attachment';
import { escapeCharChangeForGrid, escapeCharChange } from '../../../../utils/commUtils';
import moment from 'moment';


const GridBoardList = ({gridHeight, selectFilter, filterValue, queryResult, limit, activePage, onCellClicked}) => {

  const gridRef = useRef();

  const [data, setData] = useState()
  useEffect(() => {
    if(queryResult.data){
      setData(queryResult.data)
    }
  },[queryResult.status])

  const [columnDefs, setColumnDefs] = useState([
        {
            headerName: '관리번호',
            field: 'blcSn',
            wrapText: true,
            autoHeight: true,
        },
        {
            headerName: '분류',
            field: 'blcScnCdNm',
          wrapText: true,
          autoHeight: true,
        },
        {
          headerName: '차종',
          children: [
            { headerName:'차종코드', field: 'qltyVehlCd',minWidth:70,
            spanHeaderHeight: true, 
            wrapText: true,
            autoHeight: true,
            cellRenderer: function(params) {
              return escapeCharChange(params.value).replace(/\@/g,'\n');
            },
            cellStyle: { 'whiteSpace': 'pre' },
            },
            { 
              headerName:'차종명', 
              field: 'qltyVehlNm',
              minWidth:130,
              wrapText: true,
              autoHeight: true,
              cellRenderer: function(params) {
                return escapeCharChange(params.value).replace(/\@/g,'\n');
              },
              cellStyle: { 'whiteSpace': 'pre' }
          },
            { 
              headerName:'연식', 
              field: 'mdlMdyCd',
              minWidth:70,
              spanHeaderHeight: true,
              wrapText: true,
              autoHeight: true,
              cellRenderer: function(params) {
                return escapeCharChange(params.value).replace(/\@/g,'\n');
              },
              cellStyle: { 'whiteSpace': 'pre' },
            }
          ],
        },
        {
          headerName: '언어',
          children: [
            { 
              headerName:'지역', 
              field: 'regnNm',
              minWidth:70,
              wrapText: true,
              autoHeight: true,
              cellRenderer: function(params) {
                return escapeCharChange(params.value).replace(/\@/g,'\n');
              },
              cellStyle: { 'whiteSpace': 'pre' }
            },
            { 
              headerName:'언어코드', 
              field: 'langCd',
              minWidth:70,
              wrapText: true,
              autoHeight: true,
              cellRenderer: function(params) {
                return escapeCharChange(params.value).replace(/\@/g,'\n');
              },
              cellStyle: { 'whiteSpace': 'pre' }
            },
            { 
              headerName:'언어명', 
              field: 'langCdNm',
              minWidth:130,
              wrapText: true,
              autoHeight: true,
              cellRenderer: function(params) {
                return escapeCharChange(params.value).replace(/\@/g,'\n');
              },
              cellStyle: { 'whiteSpace': 'pre' }
          },
          ],
        },
        {
          headerName: '제목',
          field: 'blcTitlNm',
          minWidth:'400',
          cellStyle: () => ({ textDecoration: 'underline', cursor: 'pointer', color:'#2589f5'})
        },
        {
          headerName: '첨부',
          field: 'attcYn',
          cellStyle: () => ({textDecoration: 'underline', cursor: 'pointer'}),
          cellRenderer: function(params) {
            return params.value === 'Y' ? <AttachmentIcon style={{fontSize:'14px'}} /> : '';
          }
        },
        {
          headerName: '등록자',
          field: 'pprrEeno',
        },  
        {
          headerName: '등록일',
          field: 'framDtm',
          cellRenderer: (param) => moment(param).format('YYYY-MM-DD'),
        }
    ])

    const defaultColDef = useMemo(() => {
        return {
            initialWidth: 90,
            sortable: true,
            resizable:true,
            minWidth:70
        };
    }, []);

  const onFirstDataRendered = (params) => {
      params.api.sizeColumnsToFit();
  };

  useEffect(()=>{
    if(queryResult.status === 'loading' && gridRef && gridRef.current && gridRef.current.api){
        gridRef.current.api.showLoadingOverlay();
    }
  },[queryResult]);

  // useEffect(()=> {
  //   if(gridRef && gridRef.current && gridRef.current.api){
  //     gridRef.current.api.setQuickFilter(filterValue);
  //   }
  // },[filterValue]);

  useEffect(()=> {
    if(gridRef && gridRef.current && gridRef.current.api){
      gridRef.current.api.paginationGoToPage(activePage-1);
    }
  },[activePage]);


  //------------------- filter --------------------------------------

  useEffect(() => {
    console.log('filterValue', filterValue)
    console.log('selectFilter', selectFilter)
    if(queryResult.data && selectFilter){
      if(selectFilter === 'blcSn'){
        setData(queryResult.data.filter(item => item.blcSn === Number(filterValue) ))
      }else{
        setData(queryResult.data.filter(item => item[selectFilter].indexOf(filterValue) > -1))
      }
    }
  },[filterValue])
  

  
  return(
      <div className="ag-theme-alpine" style={{height: '682px', transition:'all ease .3s'}}>
        <AgGridReact
            ref={gridRef} 
            // rowData={queryResult && queryResult.data} 
            rowData={data}
            columnDefs={columnDefs}
            defaultColDef={defaultColDef}

            // paging
            pagination={true}
            paginationPageSize={limit} //
            suppressPaginationPanel={true} 
            // onPaginationChanged={onPaginationChanged}

            // click column
            onCellClicked={onCellClicked} //

            //  filter
            // cacheQuickFilter={true}

            // external filter
            // isExternalFilterPresent={isExternalFilterPresent}
            // doesExternalFilterPass={doesExternalFilterPass}

            // overlay
            overlayNoRowsTemplate={CONSTANTS.gridNoRows}
            overlayLoadingTemplate={CONSTANTS.gridLoading}
            

            onFirstDataRendered={onFirstDataRendered}
            suppressSizeToFit={true}    
            onGridSizeChanged={onFirstDataRendered}    

            suppressRowTransform={true} // rowSpan 할때 필요!
            >
        </AgGridReact>
    </div>
  )


};
export default GridBoardList;