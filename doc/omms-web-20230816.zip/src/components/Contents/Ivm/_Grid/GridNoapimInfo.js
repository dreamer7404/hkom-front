import React, {useEffect, useMemo, useRef} from 'react';
import { AgGridReact } from 'ag-grid-react';
import { CONSTANTS } from '../../../../utils/constants';
import { formatNumber, escapeCharChangeForGrid ,numComparator} from '../../../../utils/commUtils';

const GridRequestState = ({gridHeight, filterValue, queryResult, limit, activePage, gridRef}) => {

  // 수량 천단위 콤마 찍기
  const currencyFormatter = (params) => {
    return formatNumber(params.value);
  };

  const columnDefs = [
      {
        headerName: '전송차종정보',
        children: [
          { headerName:'차종코드', field: 'etVehlCd',minWidth:50,},
          { headerName:'모델월팩', field: 'etMdlMdyCd',minWidth:50,},
          { headerName:'국가코드', field: 'etNatCd',minWidth:50, },
        ],
      },
      {
        headerName: 'OMMS차종정보',
        children: [
          { headerName:'차종코드', field: 'qltyVehlCd',minWidth:50,},
          { headerName:'연식', field: 'mdlMdyCd',minWidth:50, },
          { headerName:'국가코드', field: 'natCd',minWidth:50, },
        ],
      },
      {
        headerName: '국가명',
        field: 'natNm',
        spanHeaderHeight: true,
        minWidth:80,
        cellRenderer: escapeCharChangeForGrid
      },
      {
        headerName: '업무구분',
        field: 'affrScnNm',
        spanHeaderHeight: true,
        minWidth:120,
      },
      {
        headerName: '오류유형',
        field: 'errCase',
        spanHeaderHeight: true,
      },
      {
        headerName: '생산계획일자',
        field: 'prdnPlnYmd',
        spanHeaderHeight: true,
      },
      {
        headerName: '발생시각',
        field: 'framDtm',
        spanHeaderHeight: true,
        cellRenderer:escapeCharChangeForGrid
      }
  ]

  const defaultColDef = useMemo(() => {
      return {
          initialWidth: 90,
          sortable: true,
          resizable:true,
          minWidth:70,
      };
  }, []);

  const onFirstDataRendered = (params) => {
      params.api.sizeColumnsToFit();
  };

  useEffect(()=>{
    if(queryResult.status === 'loading' && gridRef && gridRef.current && gridRef.current.api){
        gridRef.current.api.showLoadingOverlay();
    }
  },[queryResult]);

  useEffect(()=> {
    if(gridRef && gridRef.current && gridRef.current.api){
      gridRef.current.api.setQuickFilter(filterValue);
    }
  },[filterValue]);

  useEffect(()=> {
    if(gridRef && gridRef.current && gridRef.current.api){
      gridRef.current.api.paginationGoToPage(activePage-1);
    }
  },[activePage]);


  return(
      <div className="ag-theme-alpine" style={{height: gridHeight, transition:'all ease .3s'}}>
        <AgGridReact
            ref={gridRef} 
            rowData={queryResult && queryResult.data} 
            columnDefs={columnDefs}
            defaultColDef={defaultColDef}

            // paging
            pagination={true}
            paginationPageSize={limit} //
            suppressPaginationPanel={true} 
            // onPaginationChanged={onPaginationChanged}

            //  filter
            cacheQuickFilter={true}

            // overlay
            overlayLoadingTemplate={CONSTANTS.gridLoading}
            overlayNoRowsTemplate={CONSTANTS.gridNoRows}

            frameworkComponents={escapeCharChangeForGrid}

            onFirstDataRendered={onFirstDataRendered}
            suppressSizeToFit={true}    
            onGridSizeChanged={onFirstDataRendered}
            >
        </AgGridReact>
    </div>
  )


};
export default GridRequestState;