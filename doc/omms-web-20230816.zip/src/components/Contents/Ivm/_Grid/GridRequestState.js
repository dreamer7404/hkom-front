import React, {useEffect, useMemo, useRef} from 'react';
import { AgGridReact } from 'ag-grid-react';
import { CONSTANTS } from '../../../../utils/constants';
import { formatNumber,numComparator, escapeCharChangeForGrid, escapeCharChange } from '../../../../utils/commUtils';

const GridRequestState = ({gridHeight, filterValue, queryResult, limit, activePage, gridRef}) => {

  // 수량 천단위 콤마 찍기
  const currencyFormatter = (params) => {
    return formatNumber(params.value);
  };

  const CustomTooltip = (props) => {
    return (
      <div
        className="custom-tooltip"
        style={{ backgroundColor: 'white', border:'solid 1px', padding:'10px' }}
      >
        <p style={{fontSize:'13px'}}>
          {escapeCharChange(props.data[props.field])}
        </p>
      </div>
    );
  }

  const columnDefs = [
      {
          headerName: '요청구분',
          field: 'rqGbn',
          spanHeaderHeight: true,
        },
      {
        headerName: '차종',
        children: [
          { headerName:'차종코드', field: 'qltyVehlCd',minWidth:70,},
          { headerName:'차종명', field: 'qltyVehlNm',minWidth:130,},
          { headerName:'연식', field: 'mdlMdyCd',minWidth:50, },
        ],
      },
      {
        headerName: '언어',
        children: [
          { headerName:'지역', field: 'dlExpdPrvsNm',minWidth:70,},
          { headerName:'언어코드', field: 'langCd',minWidth:70, },
          { headerName:'언어명', field: 'langCdNm',minWidth:130, },
        ],
      },
      {
        headerName: '요청수량',
        field: 'rqQty',
        spanHeaderHeight: true,
        valueFormatter: currencyFormatter
        ,comparator: numComparator
      },
      {
        headerName: '요청자',
        field: 'userNm',
        spanHeaderHeight: true,
      },
      {
        headerName: '요청일',
        field: 'ordnRqstYmd',
        spanHeaderHeight: true,
      },
      {
        headerName: '비고',
        field: 'rqRsonSbc',
        spanHeaderHeight: true,
        cellRenderer: escapeCharChangeForGrid,
        minWidth:200,
        tooltipField: 'rqRsonSbc' ,
        tooltipComponentParams: { field: 'rqRsonSbc' },
        tooltipValueGetter: CustomTooltip,
        valueGetter: (params) => {
          return params.data.rqRsonSbc ? params.data.rqRsonSbc.replace(/<[^>]*>?/g, '') : ''
        },
      }
  ]
  
  const defaultColDef = useMemo(() => {
      return {
          initialWidth: 90,
          sortable: true,
          resizable:true,
          minWidth:70,
          enableBrowserTooltips: true,
          tooltipComponent: CustomTooltip,
      };
  }, []);

  const onFirstDataRendered = (params) => {
      params.api.sizeColumnsToFit();
  };

  useEffect(()=>{
    if(queryResult.status === 'loading' && gridRef && gridRef.current && gridRef.current.api){
        gridRef.current.api.showLoadingOverlay();
    }
  },[queryResult]);

  useEffect(()=> {
    if(gridRef && gridRef.current && gridRef.current.api){
      gridRef.current.api.setQuickFilter(filterValue);
    }
  },[filterValue]);

  useEffect(()=> {
    if(gridRef && gridRef.current && gridRef.current.api){
      gridRef.current.api.paginationGoToPage(activePage-1);
    }
  },[activePage]);


  return(
      <div className="ag-theme-alpine" style={{height: gridHeight, transition:'all ease .3s'}}>
        <AgGridReact
            ref={gridRef} 
            rowData={queryResult && queryResult.data} 
            columnDefs={columnDefs}
            defaultColDef={defaultColDef}

            // paging
            pagination={true}
            paginationPageSize={limit} //
            suppressPaginationPanel={true} 
            // onPaginationChanged={onPaginationChanged}

            //  filter
            cacheQuickFilter={true}

            // overlay
            overlayLoadingTemplate={CONSTANTS.gridLoading}
            overlayNoRowsTemplate={CONSTANTS.gridNoRows}

            onFirstDataRendered={onFirstDataRendered}
            suppressSizeToFit={true}    
            onGridSizeChanged={onFirstDataRendered}    

            tooltipShowDelay={0}
            tooltipHideDelay={100000}
            >
        </AgGridReact>
    </div>
  )


};
export default GridRequestState;