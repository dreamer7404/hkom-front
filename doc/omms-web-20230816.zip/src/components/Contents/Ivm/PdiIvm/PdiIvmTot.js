// react
import React, {useState, useEffect, useCallback, useRef} from 'react';
import {Col, Collapse, Button} from 'react-bootstrap';
import {Form, SelectPicker} from 'rsuite';
import SearchIcon from '@rsuite/icons/Search';

//--------------  서버데이터용 필수 -------------------------------
import { useQuery} from 'react-query';
import { getData } from '../../../../utils/async';
import { API, CONSTANTS } from '../../../../utils/constants';
import useStore from '../../../../utils/store';
//--------------// 서버데이터용 필수 -------------------------------

import BDate from '../../../Search/BDate';
import VehlType from '../../../Search/VehlType';
import Lang from '../../../Search/Lang';
import IvmState from '../../../Search/IvmState';
import DlvtState from '../../../Search/DlvtState';
import Paging from '../../../Common/Paging';
import GridPdiIvmTot from '../_Grid/GridPdiIvmTot';
import { CustomInputGroup } from '../../../Common/CustomInputGroup';

import ProductMonitor from '../Popup/ProductMonitor';
import InputConfirm from '../Popup/InputConfirm';
import IvmModify from '../Popup/IvmModify';
import DeliveryRequest from '../Popup/DeliveryRequest';
import OrderRequest from '../Popup/OrderRequest';
import ProductPlan2Weeks from '../Popup/ProductPlan2Weeks';
import ProductPlan3Days from '../Popup/ProductPlan3Days';
import ThisMonthAmount from '../Popup/ThisMonthAmount';
import SewonIvmPrinting from '../Popup/SewonIvmPrinting';
import SewonIvmHave from '../Popup/SewonIvmHave';
import PdiGlovisIvm from '../Popup/PdiGlovisIvm';

import { confirmAlert } from 'react-confirm-alert'; // Import
import ConfirmAlert from '../../../Common/ConfirmAlert';
//아이콘
import {ArrowDownLine, ArrowUpLine, FileDownload} from '@rsuite/icons';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faFileExcel,faPrint } from '@fortawesome/free-solid-svg-icons'
import { excelDownload as excelDownloadAggrid } from '../../../../utils/excelForAggrid';
import { isApi } from '../../../../utils/commUtils';
import { useNavigate} from 'react-router-dom';

const PdiIvmTot = () => {

    //------------------- 필수 공통 ------------------------------
    const [open, setOpen] = useState(true); // 조건창 열기/닫기
    const {keyword } = useStore();  // 조회키워드 가져오기

    const [activePage, setActivePage] = useState(1);    // 페이지번호
    const [limit, setLimit] = useState(50);             // 페이지행수
    const [filterValue, setFilterValue] = useState(''); // 필터값

    const onChangePage = val => {
        setActivePage(val);
    };
    const onChangeLimit = val => {
        setLimit(val);
    };
    useEffect(()=>{
        onChangePage(1); // 페이지번호 리셋
    },[keyword]);

    // 필터
    const onFilterTextBoxChanged = useCallback((e) => {
        setFilterValue(e.target.value);
    }, []);

    // 검색창 열기/닫기 > 페이지네이션 여부에 따라 +-20px
    const [gridHeight, setGridHeight] = useState(575);
    const gridExpand = () =>{
        setOpen(!open);
        if(open){
            setTimeout(() => setGridHeight(650), 250);
        }else{
            setGridHeight(575)
        }
    }
    //-------------------// 필수 공통 ------------------------------

    //  ivmTotal 조회
    const [paramIvmTotal, setParamIvmTotal] = useState({})
    useEffect(() => {
        queryResult.remove()
        batchFinResult.remove()
        setCheckedRows([])
        setParamIvmTotal({
            bDate: keyword.bDate,
            dlExpdPdiCd: keyword.dlExpdPdiCd,
            qltyVehlCd: keyword.qltyVehlCd,
            mdlMdyCd: keyword.mdlMdyCd,
            dlExpdRegnCd: keyword.dlExpdRegnCd,
            langCd: keyword.langCd,
            subCd: keyword.subCd,
            dlvtState: keyword.dlvtState
        })
    },[keyword])
    const queryResult = useQuery([API.ivmPdiIvInfos, paramIvmTotal], () => getData(API.ivmPdiIvInfos, paramIvmTotal));

    const batchFinResult = useQuery([API.ivmFinBatchDtm, paramIvmTotal], () => getData(API.ivmFinBatchDtm, paramIvmTotal));

    // 그리드 내에서 클릭된 row by Woong
    const [clickedRowData, setClickedRowData] = useState({});

    // 그리드 내에서 체크된 rows by Woong
    const [checkedRows, setCheckedRows] = useState([]);    
    const checkRow = e => {
        setCheckedRows(e)
    };
    const gridRef = useRef();

    // 셀 클릭
    const navigate = useNavigate();
    const onCellClicked = e => {

        //그리드 내에서 클릭된 rowData 할당
        e.data.bDate = keyword.bDate;
        setClickedRowData(e.data);

        if(e.column.colId === 'wek2PlanQty'){
            setProductPlan1(true)
        }else if(e.column.colId === 'day3PlanQty'){
            setProductPlan2(true)
        }else if(e.column.colId === 'currMthTrwiQty'){
            setThisMonthAmount(true)
        }else if(e.column.colId === 'prntQty'){
            setSewonIvmPrinting(true)
        }else if(e.column.colId === 'sewonIvQty'){
            setSewonIvmHave(true)
        }else if(e.column.colId === 'pdiIvQty'){
            setPdiGlovisIvm(true)
        }else if(e.column.colId === 'prntStateNm'){
            console.log(e.data)
            let param = {
                dlExpdPdiCd : 'ALL',
                qltyVehlCd : e.data.qltyVehlCd,
                mdlMdyCd : e.data.mdlMdyCd,
                dlExpdRegnCd : e.data.dlExpdRegnCd,
                langCd : e.data.langCd, 
                gubun:'pdiIvm'
            }
            if(e.data.prntStateNm === '긴급' || e.data.prntStateNm === '발주 필요'){
                navigate('/printOrder/add',{ state: param}); 
            }
        }

    };

    const [productMonitor, setProductMonitor] = useState(false);
    const setProductMonitorPopVali = () => {
        if(checkedRows.length == 0){
            confirmAlert({
                closeOnClickOutside: false,
                customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}  title={"알림"} msg={"대상을 선택해주세요."}  />
            })
            return false
        } else if (checkedRows.length > 1){
            confirmAlert({
                closeOnClickOutside: false,
                customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}  title={"알림"} msg={"대상을 한 개만 선택해주세요."}  />
            })
            return false
        } else {
            checkedRows[0].bDate = keyword.bDate
            setProductMonitor(true)
        }
    }

    const [inputConfirm, setInputConfirm] = useState(false);
    const setInputConfirmPopVali = () => {
        if(checkedRows.length <= 0){
            confirmAlert({
                closeOnClickOutside: false,
                customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}  title={"알림"} msg={"대상을 선택해주세요."}  />
            })
            return false
        } else {
            setInputConfirm(true)
        }
    }
    
    const [ivmModify, setIvmModify] = useState(false);
    const [deliveryRequest, setDeliveryRequest] = useState(false);
    const setDeliveryRequestPopVali = () => {
        if(checkedRows.length <= 0){
            confirmAlert({
                closeOnClickOutside: false,
                customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}  title={"알림"} msg={"대상을 선택해주세요."}  />
            })
            return false
        }
        setDeliveryRequest(true)
    }
    const [orderRequest, setOrderRequest] = useState(false);
    const setOrderRequestPopVali = () => {
        if(checkedRows.length <= 0){
            confirmAlert({
                closeOnClickOutside: false,
                customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}  title={"알림"} msg={"대상을 선택해주세요."}  />
            })
            return false
        }
        setOrderRequest(true)
    }
    const [productPlan1, setProductPlan1] = useState(false);
    const [productPlan2, setProductPlan2] = useState(false);
    const [thisMonthAmount, setThisMonthAmount] = useState(false);
    const [sewonIvmPrinting, setSewonIvmPrinting] = useState(false);
    const [sewonIvmHave, setSewonIvmHave] = useState(false);
    const [pdiGlovisIvm, setPdiGlovisIvm] = useState(false);

    // 조회버튼
    const onSearch = () => {
        queryResult.refetch(); // 수동쿼리실행
    };

    const [excelStatus, setExcelStatus] = useState(false);
    useEffect(() => {
        if(excelStatus) {
            setExcelStatus(excelDownloadAggrid(gridRef, 'PDI재고관리 현황', 3))
        }
    }, [excelStatus])

    return (
        <>
            <div className="search-area">
                <Collapse in={open}>
                    <div className="form" id="example-collapse-text">
                        <div className="search-group">
                            <div className="row">
                                <Col sm={2} className=""> 
                                    <BDate />
                                </Col>
                                <Col sm={5} className="" >
                                    <VehlType  />
                                </Col>
                                <Col sm={3} className="" >
                                    <Lang />
                                </Col>
                                <Col sm={1} className="" >
                                    {/* <Form.Group>
                                        <Form.ControlLabel column="sm" >배송여부</Form.ControlLabel>
                                        <SelectPicker size="sm" data={[{ label: "test"}]} searchable={false} cleanable={false} />
                                    </Form.Group> */}
                                    <DlvtState />
                                </Col>
                                <Col sm={1} className="" >
                                    <IvmState />
                                </Col>
                            </div>
                            <div className="search-btn-wrap">
                                <Button className="btn-search" variant="outline-primary" size="sm" onClick={onSearch}><SearchIcon />조회</Button>
                            </div>
                        </div>
                    </div>
                </Collapse>
                <Button size="sm" variant="outline-dark" className="search-control" aria-controls="example-collapse-text" 
                    aria-expanded={open} onClick={gridExpand}>
                    {open 
                        ? 
                        <span className="search-area-close">
                            <ArrowUpLine style={{marginRight: '5px', fontSize: '2em'}} />
                            {CONSTANTS.closeSearch}
                        </span> 
                        :
                        <span className="search-area-open">
                            <ArrowDownLine style={{marginRight: '5px', fontSize: '2em'}} />
                            {CONSTANTS.openSearch}
                        </span>
                    }
                </Button>
            </div>
            
            <div className="grid-wrap">
                <div className="grid-btn-wrap">
                    <div className="left-align">
                        {/*--------- 필터 -----------*/}
                        <CustomInputGroup size="sm"   onInput={onFilterTextBoxChanged} />
                    </div>
                    <div className="right-align">
                        {isApi(API.ivmPdiPrndMonitorInfo, 'GET') &&
                            <>
                                <Button variant="outline-secondary" size="sm"  onClick={() => setProductMonitorPopVali()} >생산라인 모니터링</Button>{' '}
                            </>
                        }
                        {isApi(API.ivmPdiWhsnInfo, 'POST') &&
                            <>
                                <Button variant="outline-secondary" size="sm" onClick={() => setInputConfirmPopVali()}>입고확인</Button>{' '}
                            </>
                        }
                        {isApi(API.ivmIvModInfos, 'POST') &&
                            <>
                                <Button variant="outline-secondary" size="sm" onClick={() => setIvmModify(true)}>재고보정</Button>{' '}
                            </>
                        }
                        {isApi(API.ivmPdiDlvtRequest, 'POST') &&
                            <>
                                <Button variant="outline-secondary" size="sm" onClick={() => setDeliveryRequestPopVali()}>배송요청</Button>{' '}
                            </>
                        }
                        {isApi(API.ivmPdiOrderRequest, 'POST') &&
                            <>
                                <Button variant="outline-secondary" size="sm" onClick={() => setOrderRequestPopVali()}>발주요청</Button>{' '}
                            </>
                        }
                        <Button variant="outline-success btn-excel" size="sm" disabled={excelStatus} onClick={() => setExcelStatus(true)}>
                            <FontAwesomeIcon icon={faFileExcel}/>
                            {CONSTANTS.excelDownload}
                        </Button>{' '}
                        <Button variant="outline-dark btn-print" size="sm"onClick={() => window.print()}><FontAwesomeIcon icon={faPrint}/>{CONSTANTS.print}</Button>{' '}
                    </div>
                </div>
                {/*--------- Grid -----------*/}
                <GridPdiIvmTot 
                    gridHeight={gridHeight}
                    filterValue={filterValue}
                    queryResult={queryResult}
                    limit={limit}
                    activePage={activePage}
                    onCellClicked={onCellClicked}
                    checkRow={checkRow}
                    gridRef={gridRef}
                    />
                
                {/*--------- 페이징 -----------*/}
                <Paging 
                    total={queryResult && queryResult.data && queryResult.data.length}
                    limit={limit}
                    activePage={activePage}
                    onChangePage={onChangePage}
                    onChangeLimit={onChangeLimit}
                />
                <p style={{textAlign:'right'}}>{batchFinResult && batchFinResult.data}</p>

            </div>

            {productMonitor && <ProductMonitor show={productMonitor} onHide={() => setProductMonitor(false)} checkedRows={checkedRows[0]}  /> }            
            {inputConfirm && <InputConfirm show={inputConfirm} onHide={() => setInputConfirm(false)} checkedRows={checkedRows} /> }
            {ivmModify && <IvmModify show={ivmModify} onHide={() => setIvmModify(false)} menuGubun={'pdi'}  />}
            {/* {ivmModify && <IvmModify show={ivmModify} onHide={() => setIvmModify(false)} menuGubun={'sewon'}   />} */}
            
            {deliveryRequest && <DeliveryRequest show={deliveryRequest} onHide={() => setDeliveryRequest(false)} checkedRows={checkedRows} />}
            {orderRequest && <OrderRequest show={orderRequest} onHide={() => setOrderRequest(false)} checkedRows={checkedRows}  />}
            {productPlan1 && <ProductPlan2Weeks show={productPlan1} onHide={() => setProductPlan1(false)} clickedRowData={clickedRowData} />}
            {productPlan2 && <ProductPlan3Days show={productPlan2} onHide={() => setProductPlan2(false)} clickedRowData={clickedRowData} />}
            {thisMonthAmount && <ThisMonthAmount show={thisMonthAmount} onHide={() => setThisMonthAmount(false)} clickedRowData={clickedRowData} />}
            {sewonIvmPrinting && <SewonIvmPrinting show={sewonIvmPrinting} onHide={() => setSewonIvmPrinting(false)} clickedRowData={clickedRowData}  />}
            {sewonIvmHave && <SewonIvmHave show={sewonIvmHave} onHide={() => setSewonIvmHave(false)} clickedRowData={clickedRowData} />}
            {pdiGlovisIvm && <PdiGlovisIvm show={pdiGlovisIvm} onHide={() => setPdiGlovisIvm(false)} clickedRowData={clickedRowData} />}
            
        </>
    )
};
export default PdiIvmTot;