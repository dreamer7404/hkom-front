import React, {useEffect, useMemo, useRef} from 'react';
import { AgGridReact } from 'ag-grid-react';
import { CONSTANTS } from '../../../../utils/constants';
import {escapeCharChangeForGrid, escapeCharChange } from '../../../../utils/commUtils';
const GridLoginHistory = ({gridHeight, filterValue, queryResult, limit, activePage}) => {

  const gridRef = useRef();

  //L:로그아웃버튼, X:창닫기, S:사용시간, P: PRG권한, R: RT없음, T: 토큰오류
  const cellRendererLgoType = e => {
    if(e.value === 'L') return '로그아웃';
    else if(e.value === 'X') return '창닫기';
    else if(e.value === 'S') return '사용시간경과';
    else if(e.value === 'P') return '프로그램권한';
    else if(e.value === 'R') return '리프레시토큰';
    else if(e.value === 'T') return '토큰오류';
    else return e.value;
  }

  const columnDefs = [
        {
          headerName: '사용자ID',
          field: 'userId',
        },
        {
          headerName: '사용자명',
          field: 'userNm',
        },  
        {
          headerName: '로그인 일시',
          field: 'lgiDtm',
          cellRenderer:escapeCharChangeForGrid
        },  
        {
          headerName: '성공여부',
          field: 'sucsYn',
          maxWidth:'150'
        },  
        {
          headerName: '사용자IP',
          field: 'userIpAdr',
          cellRenderer:escapeCharChangeForGrid
        },  
        {
          headerName: '세션ID',
          field: 'sessId',
          cellRenderer:escapeCharChangeForGrid,
          minWidth:'150'
        },  
        {
          headerName: '로그아웃 일시',
          field: 'lgoDtm',
          cellRenderer:escapeCharChangeForGrid
        },  
        {
          headerName: '로그아웃 방법',
          field: 'lgoType',
          cellRenderer: cellRendererLgoType
        },  
  ]

  const defaultColDef = useMemo(() => {
      return {
          initialWidth: 90,
          sortable: true,
          resizable:true,
          minWidth:70
      };
  }, []);

  const onFirstDataRendered = (params) => {
      params.api.sizeColumnsToFit();
  };

  useEffect(()=>{
    if(queryResult.status === 'loading' && gridRef && gridRef.current && gridRef.current.api){
        gridRef.current.api.showLoadingOverlay();
    }
  },[queryResult]);

  useEffect(()=> {
    if(gridRef && gridRef.current && gridRef.current.api){
      gridRef.current.api.setQuickFilter(filterValue);
    }
  },[filterValue]);

  useEffect(()=> {
    if(gridRef && gridRef.current && gridRef.current.api){
      gridRef.current.api.paginationGoToPage(activePage-1);
    }
  },[activePage]);


  return(
      <div className="ag-theme-alpine" style={{height: gridHeight, transition:'all ease .3s'}}>
        <AgGridReact
            ref={gridRef} 
            rowData={queryResult && queryResult.data} 
            columnDefs={columnDefs}
            defaultColDef={defaultColDef}

            // paging
            pagination={true}
            paginationPageSize={limit} //
            suppressPaginationPanel={true} 
            // onPaginationChanged={onPaginationChanged}

            //  filter
            cacheQuickFilter={true}

            // overlay
            overlayLoadingTemplate={CONSTANTS.gridLoading}
            overlayNoRowsTemplate={CONSTANTS.gridNoRows}
            frameworkComponents={{
              
              escapeCharChangeForGrid
            }}

            onFirstDataRendered={onFirstDataRendered}
            suppressSizeToFit={true}    
            onGridSizeChanged={onFirstDataRendered}    
            >
        </AgGridReact>
    </div>
  )


};
export default GridLoginHistory;