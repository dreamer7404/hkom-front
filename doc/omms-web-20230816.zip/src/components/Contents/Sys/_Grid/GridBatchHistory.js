import React, {useEffect, useMemo, useRef} from 'react';
import { AgGridReact } from 'ag-grid-react';
import { CONSTANTS } from '../../../../utils/constants';
import { escapeCharChange } from '../../../../utils/commUtils';
const GridBatchHistory = ({gridRef, gridHeight, filterValue, queryResult, limit, activePage}) => {

  

  const columnDefs = [
        {
            headerName: 'Batch명',
            field: 'btchNm',
            maxWidth:'500',
            cellRenderer: param => escapeCharChange(param.value)
        },
        {
          headerName: '시작일시',
          spanHeaderHeight: true,
          field: 'btchFinStrtDtm',
          maxWidth:'200'
          , cellRenderer: param => escapeCharChange(param.value)
          
        },
        {
          headerName: '종료일시',
          field: 'btchFnhDtm',
          maxWidth:'200'
          , cellRenderer: param => escapeCharChange(param.value)
        },
        {
          headerName: '작업코드',
          field: 'btchWkCd',
          maxWidth:'120',
        },
        {
          headerName: '작업결과내용',
          field: 'btchWkRsltSbc'
          , cellRenderer: param => escapeCharChange(param.value)
        },    
  ]

  const defaultColDef = useMemo(() => {
      return {
          initialWidth: 90,
          sortable: true,
          resizable:true,
          minWidth:70
      };
  }, []);

  const onFirstDataRendered = (params) => {
      params.api.sizeColumnsToFit();
  };

  useEffect(()=>{
    if(queryResult.status === 'loading' && gridRef && gridRef.current && gridRef.current.api){
        gridRef.current.api.showLoadingOverlay();
    }
  },[queryResult]);

  useEffect(()=> {
    if(gridRef && gridRef.current && gridRef.current.api){
      gridRef.current.api.setQuickFilter(filterValue);
    }
  },[filterValue]);

  useEffect(()=> {
    if(gridRef && gridRef.current && gridRef.current.api){
      gridRef.current.api.paginationGoToPage(activePage-1);
    }
  },[activePage]);

  return(
      <div className="ag-theme-alpine" style={{height: gridHeight, transition:'all ease .3s'}}>
        <AgGridReact
            ref={gridRef} 
            rowData={queryResult && queryResult.data} 
            columnDefs={columnDefs}
            defaultColDef={defaultColDef}

            // paging
            pagination={true}
            paginationPageSize={limit} //
            suppressPaginationPanel={true} 
            // onPaginationChanged={onPaginationChanged}

            //  filter
            cacheQuickFilter={true}

            // overlay
            overlayLoadingTemplate={CONSTANTS.gridLoading}
            overlayNoRowsTemplate={CONSTANTS.gridNoRows}

            onFirstDataRendered={onFirstDataRendered}
            suppressSizeToFit={true}    
            onGridSizeChanged={onFirstDataRendered}    
            >
        </AgGridReact>
    </div>
  )


};
export default GridBatchHistory;