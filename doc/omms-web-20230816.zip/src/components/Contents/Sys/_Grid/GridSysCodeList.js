import React, {useEffect, useMemo, useRef} from 'react';
import { AgGridReact } from 'ag-grid-react';
import { CONSTANTS } from '../../../../utils/constants';
import { escapeCharChangeForGrid,escapeCharChange } from '../../../../utils/commUtils';
const GridSysCodeList = ({gridRef, gridHeight, filterValue, queryResult, limit, activePage, onCellClicked}) => {

  

  const columnDefs = [
        {
          checkboxSelection: true,
          headerCheckboxSelection: true,
          width:35,
          maxWidth:35,
          minWidth:35,
          sortable:false
        },
        {
            headerName: '그룹코드',
            field: 'dlExpdGCd',
            maxWidth:'150'
        },
        {
            headerName: '그룹명',
            field: 'dlExpdGNm',
            cellStyle: () => ({textDecoration: 'underline', cursor: 'pointer', color:'#2589f5'})
        },
        {
          headerName: '항목코드',
          field: 'dlExpdPrvsCd',
          maxWidth:'150'
        },
        {
          headerName: '항목명', 
          field: 'dlExpdPrvsNm',
          cellRenderer: data => escapeCharChange(escapeCharChangeForGrid(data)),
        },
        {
          headerName: '정렬순서',
          field: 'sortSn',
          maxWidth:'150'
        },
        {
          headerName: '사용여부',
          field: 'useYn',
          maxWidth:'120',
          cellRenderer: "statusComonent"
        },
        {
          headerName: '등록자',
          field: 'pprrEeno',
          maxWidth:'150'
        },    
        {
          headerName: '등록일',
          field: 'framDtm',
          maxWidth:'150'
        },    
  ]

  const defaultColDef = useMemo(() => {
      return {
          initialWidth: 90,
          sortable: true,
          resizable:true,
          minWidth:70
      };
  }, []);

  const onFirstDataRendered = (params) => {
      params.api.sizeColumnsToFit();
  };

  //사용여부
  const statusComonent = (props) => {
    if(props.value === "Y"){
      return(
          <div style={{color:'#2589f5'}}>
          {props.value}
          </div>
      )
    }else if(props.value === "N"){
      return(
          <div style={{color:'#dc3545'}}>
          {props.value}
          </div>
      )
    }
  }


  useEffect(()=>{
    if(queryResult.status === 'loading' && gridRef && gridRef.current && gridRef.current.api){
        gridRef.current.api.showLoadingOverlay();
    }
  },[queryResult]);

  useEffect(()=> {
    if(gridRef && gridRef.current && gridRef.current.api){
      gridRef.current.api.setQuickFilter(filterValue);
    }
  },[filterValue]);

  useEffect(()=> {
    if(gridRef && gridRef.current && gridRef.current.api){
      gridRef.current.api.paginationGoToPage(activePage-1);
    }
  },[activePage]);

  return(
      <div className="ag-theme-alpine" style={{height: gridHeight, transition:'all ease .3s'}}>
        <AgGridReact
            ref={gridRef} 
            rowData={queryResult && queryResult.data} 
            columnDefs={columnDefs}
            defaultColDef={defaultColDef}

            // paging
            pagination={true}
            paginationPageSize={limit} //
            suppressPaginationPanel={true} 
            // onPaginationChanged={onPaginationChanged}

            rowSelection={'multiple'}
            suppressRowClickSelection= {true} 

            //  filter
            cacheQuickFilter={true}

            onCellClicked={onCellClicked}

            frameworkComponents={{
                statusComonent
            }}

            // overlay
            overlayLoadingTemplate={CONSTANTS.gridLoading}
            overlayNoRowsTemplate={CONSTANTS.gridNoRows}

            onFirstDataRendered={onFirstDataRendered}
            suppressSizeToFit={true}    
            onGridSizeChanged={onFirstDataRendered}    
            >
        </AgGridReact>
    </div>
  )


};
export default GridSysCodeList;