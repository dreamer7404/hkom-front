// react
import React, {useState, useEffect, useCallback,useRef} from 'react';
import {Col, Button, Collapse} from 'react-bootstrap';
import {Form, SelectPicker} from 'rsuite';
import SearchIcon from '@rsuite/icons/Search';

//--------------  서버데이터용 필수 -------------------------------
import { useQuery,useMutation} from 'react-query';
import { API, CONSTANTS } from '../../../../utils/constants';
import useStore from '../../../../utils/store';
import { getData,postData } from '../../../../utils/async';
//--------------// 서버데이터용 필수 -------------------------------

import GridSysCodeList from '../_Grid/GridSysCodeList';
import Paging from '../../../Common/Paging';
import { CustomInputGroup } from '../../../Common/CustomInputGroup';

import SysCodeGroupAdd from '../Popup/SysCodeGroupAdd';
import SysCodeGroupDelete from '../Popup/SysCodeGroupDelete';
import SysCodeAdd from '../Popup/SysCodeAdd';
import SysCodeAddAll from '../Popup/SysCodeAddAll';
import SysCodeUpdate from '../Popup/SysCodeUpdate';
import { confirmAlert } from 'react-confirm-alert'; // Import
import ConfirmAlert from '../../../Common/ConfirmAlert';
import {ArrowDownLine, ArrowUpLine} from '@rsuite/icons';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faFileExcel,faPrint } from '@fortawesome/free-solid-svg-icons'
import { excelDownload as excelDownloadAggrid } from '../../../../utils/excelForAggrid';
import { isApi } from '../../../../utils/commUtils';
const SysCodeList = () => {

    //------------------- 필수 공통 ------------------------------
    const gridRef = useRef();
    const [open, setOpen] = useState(true); // 조건창 열기/닫기
    const {keyword } = useStore();  // 조회키워드 가져오기

    const [activePage, setActivePage] = useState(1);    // 페이지번호
    const [limit, setLimit] = useState(50);             // 페이지행수
    const [filterValue, setFilterValue] = useState(''); // 필터값
    const [paramData, setParamData] = useState();    // 페이지번호
    const [searChParam, setSearchParam] = useState({dlExpdGCd : "",
                                                    dlExpdPrvsCd : '',
                                                    useYn: ''});    // 페이지번호
    const [excelStatus, setExcelStatus] = useState(false);
    const onChangePage = val => {
        setActivePage(val);
    };
    const onChangeLimit = val => {
        setLimit(val);
    };
    const onChangeUseYn = val => { //사용여부 체인지이벤트
        setSearchParam(p=>({...p, useYn : val}));
    };

    const onChangeGrpCd = val =>{
        setSearchParam(p=>({...p, 
            dlExpdGCd : val,
            dlExpdPrvsCd : ''}));
        
    }
    const onChangeCd = val =>{
        setSearchParam(p=>({...p, dlExpdPrvsCd : val}));
    }

    useEffect(()=>{
        onChangePage(1); // 페이지번호 리셋
    },[keyword]);

    useEffect(() => {
        if(excelStatus) {
            setTimeout(() =>setExcelStatus(excelDownloadAggrid(gridRef, '시스템코드관리', 2)), 1000)
        }
    }, [excelStatus])

    // 필터
    const onFilterTextBoxChanged = useCallback((e) => {
        setFilterValue(e.target.value);
    }, []);

    // 검색창 열기/닫기 > 페이지네이션 여부에 따라 +-20px
    const [gridHeight, setGridHeight] = useState(575);
    const gridExpand = () =>{
        setOpen(!open);
        if(open){
            setTimeout(() => setGridHeight(650), 250);
        }else{
            setGridHeight(575)
        }
    }
    //-------------------// 필수 공통 ------------------------------

       //  requestState 조회
    
    const queryResult = useQuery([API.codeMgmts, searChParam], () => getData(API.codeMgmts, searChParam),{        staleTime: 0,
        
    });

    const grpCdCombo = useQuery([API.grpCodeCombo, {}], () => getData(API.grpCodeCombo, {}), {
        select: data => [{label: '전체', value: ''}].concat(data.map((item) => ({ label: item.dlExpdGNm, value: item.dlExpdGCd })))
    }); 

    
    const paramsCo = {dlExpdGCd: searChParam.dlExpdGCd};
    const codeCombo = useQuery([API.codeCombo,paramsCo], () => getData(API.codeCombo,paramsCo),{
        select: data => [{label: '전체', value: ''}].concat(data.map((item) => ({ label: item.label, value: item.value })))
    }) 


    // 셀 클릭
    const onCellClicked = e => {
        if(e.column.colId === 'dlExpdGNm'){
            setParamData({
                dlExpdGCd : e.data.dlExpdGCd,
                dlExpdGNm : e.data.dlExpdGNm,
                dlExpdPrvsCd : e.data.dlExpdPrvsCd,
                dlExpdPrvsNm : e.data.dlExpdPrvsNm,
                sortSn : e.data.sortSn,
                useYn : e.data.useYn
            })
            setSysCodeUpdatePop(true)
        }

    };

    const [sysCodeGroupAddPop, setSysCodeGroupAddPop] = useState(false);
    const [sysCodeGroupDeletePop, setSysCodeGroupDeletePop] = useState(false);
    const [sysCodeAddPop, setSysCodeAddPop] = useState(false);
    const [sysCodeAddAllPop, setSysCodeAddAllPop] = useState(false);
    const [sysCodeUpdatePop, setSysCodeUpdatePop] = useState(false);


    // 조회버튼
    const onSearch = () => {
        queryResult.refetch(); // 수동쿼리실행
    };




    const onHideGrpAdd = () => {
        setSysCodeGroupAddPop(false)
        setTimeout(() => queryResult.refetch(), 100);
    }
    const onHideGrpDelete = () => {
        setSysCodeGroupDeletePop(false)
        setTimeout(() => queryResult.refetch(), 100);
    }
    const onHideAddAll = () => {
        setSysCodeAddAllPop(false)
        setTimeout(() => queryResult.refetch(), 100);
    }
    const onHideAdd = () => {
        setSysCodeAddPop(false)
        setTimeout(() => queryResult.refetch(), 100);
    }
    const onHideUpdate = () => {
        setSysCodeUpdatePop(false)
        setTimeout(() => queryResult.refetch(), 100);
    }

    const handleSubmit = () => {
        let checkedItems = gridRef.current.api.getSelectedRows();
        if(checkedItems.length===0){
         confirmAlert({
             closeOnClickOutside: false,
             customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}   title={"알림"}
             msg={"최소 한 개의 데이터를 선택해주세요."} 
             
             />
             
         });
         return
        }
 
         
         confirmAlert({
             closeOnClickOutside: false,
             customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}   title={"알림"}
             msg={"선택하신 항목을 삭제하시겠습니까?"} 
             
             onOk={onDelete}  />
             
         });
         
     };
     const onDelete = () => {
         const deleteList = {
            deleteList : gridRef.current.api.getSelectedRows()
        }
        sysCodeDelete.mutate(deleteList);
     }
     const sysCodeDelete = useMutation((params => postData(API.codeMgmt, params, CONSTANTS.delete)),{
        onSuccess: res => {
           if(res>0){
                confirmAlert({
                    closeOnClickOutside: false,
                    customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}   title={"알림"}
                    msg={"삭제 완료되었습니다."}   />
                    
                });
           
           }else{
                confirmAlert({
                    closeOnClickOutside: false,
                    customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}   title={"알림"}
                    msg={"에러가 발생했습니다 관리자에게 문의해주세요."}   />
                    
                });
           }
           queryResult.refetch();
        }
    });
    return (
        <>
            <div className="search-area">
                <Collapse in={open}>
                    <div className="form" id="example-collapse-text">
                        <div className="search-group">
                            <div className="row">
                                <Col sm={3} className=""> 
                                    <Form.ControlLabel column="sm" >그룹명</Form.ControlLabel>
                                    <SelectPicker size="sm" 
                                    value={searChParam.dlExpdGCd}
                                    data={grpCdCombo && grpCdCombo.data ? grpCdCombo.data : []} 
                                    searchable={true}
                                    cleanable={false}
                                    onChange={onChangeGrpCd} />
                                </Col>
                                <Col sm={3} className=""> 
                                    <Form.ControlLabel column="sm" >항목명</Form.ControlLabel>
                                    <SelectPicker size="sm" 
                                    value={searChParam.dlExpdPrvsCd}
                                    data={codeCombo && codeCombo.data ? codeCombo.data : []} 
                                    searchable={false}
                                    cleanable={false}
                                    onChange={onChangeCd} />
                                </Col>
                                <Col sm={3} className=""> 
                                    <Form.ControlLabel column="sm" >사용여부</Form.ControlLabel>
                                    <SelectPicker size="sm" 
                                    value={searChParam.useYn}
                                    data={[ 
                                            {label: '전체', value: ''},
                                            {label: '사용', value: 'Y'},
                                            {label: '미사용', value: 'N'}
                                        ]} 
                                    searchable={false}
                                    cleanable={false}
                                    onChange={onChangeUseYn} />
                                </Col>
                            </div>

                            <div className="search-btn-wrap">
                                <Button className="btn-search" variant="outline-primary" size="sm" onClick={onSearch}><SearchIcon />조회</Button>
                            </div>
                        </div>
                    </div>
                </Collapse>
                <Button size="sm" variant="outline-dark" className="search-control" aria-controls="example-collapse-text" 
                    aria-expanded={open} onClick={gridExpand}>
                    {/* <span className={open === true ? "search-area-close" : "search-area-open"}>{open === true ? CONSTANTS.closeSearch : CONSTANTS.openSearch}</span> */}
                    {open ? <span className="search-area-close"><ArrowUpLine style={{marginRight: '5px', fontSize: '2em'}} />{CONSTANTS.closeSearch}</span> :
                    <span className="search-area-open"><ArrowDownLine style={{marginRight: '5px', fontSize: '2em'}} />{CONSTANTS.openSearch}</span>}
                </Button>
            </div>
            
            <div className="grid-wrap">
                <div className="grid-btn-wrap">
                    <div className="left-align">
                        {/*--------- 필터 -----------*/}
                        <CustomInputGroup size="sm"   onInput={onFilterTextBoxChanged} />
                    </div>
                    <div className="right-align">
                        {/*--------- 버튼 -----------*/}
                        {isApi(API.codeGrpMgmt, 'POST') &&   <Button variant="outline-secondary" size="sm" onClick={() => setSysCodeGroupAddPop(true)}>그룹코드 등록</Button>}{' '}
                        {isApi(API.codeGrpMgmt, 'POST') &&   <Button variant="outline-secondary" size="sm" onClick={() => setSysCodeGroupDeletePop(true)}>그룹코드 삭제</Button>}{' '}
                        {isApi(API.codeMgmt, 'POST') &&   <Button variant="outline-secondary" size="sm" onClick={() => setSysCodeAddPop(true)}>코드 등록</Button>}{' '}
                        {isApi(API.sysCodeExcelUpload, 'POST') &&   <Button variant="outline-secondary" size="sm" onClick={() => setSysCodeAddAllPop(true)}>코드 등록(일괄)</Button>}{' '}
                        {isApi(API.codeGrpMgmt, 'POST') &&  <Button variant="outline-secondary" size="sm" onClick={handleSubmit}>코드 삭제</Button>}{' '}
                        <Button variant="outline-success btn-excel" size="sm" disabled={excelStatus} onClick={() => setExcelStatus(true)}>
                            <FontAwesomeIcon icon={faFileExcel}/>
                            {CONSTANTS.excelDownload}
                        </Button>{' '}
                    </div>
                </div>
                {/*--------- Grid -----------*/}
                <GridSysCodeList 
                    gridRef ={gridRef}
                    gridHeight={gridHeight}
                    filterValue={filterValue}
                    queryResult={queryResult}
                    limit={limit}
                    activePage={activePage}
                    onCellClicked={onCellClicked}
                    />

                {/*--------- 페이징 -----------*/}
                <Paging 
                    total={queryResult && queryResult.data && queryResult.data.length}
                    limit={limit}
                    activePage={activePage}
                    onChangePage={onChangePage}
                    onChangeLimit={onChangeLimit}
                />
            </div>

            {sysCodeGroupAddPop && <SysCodeGroupAdd show={sysCodeGroupAddPop} onHide={onHideGrpAdd} />}
            {sysCodeGroupDeletePop && <SysCodeGroupDelete show={sysCodeGroupDeletePop} onHide={onHideGrpDelete} />}
            {sysCodeAddPop && <SysCodeAdd show={sysCodeAddPop} onHide={onHideAdd} />}
            {sysCodeAddAllPop && <SysCodeAddAll show={sysCodeAddAllPop} onHide={onHideAddAll} />}
            {sysCodeUpdatePop && <SysCodeUpdate show={sysCodeUpdatePop} onHide={onHideUpdate} paramData={paramData}/>}
        </>
    )
};
export default SysCodeList;