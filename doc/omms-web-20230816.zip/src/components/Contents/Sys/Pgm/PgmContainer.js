import React from 'react';
import {Tab,Tabs} from 'react-bootstrap';

import PgmList from './PgmList';
import PgmAuthList from './PgmAuthList';
import { isApi } from '../../../../utils/commUtils';
import { API } from '../../../../utils/constants';
const PgmContainer = () => {
    
    const [leftWidth, setLeftWidth] = React.useState('150px')
    React.useEffect(() => {
        const getTitle = document.getElementById('section-title-width');
        const titleWidth = getTitle.clientWidth + 40;
        setLeftWidth(titleWidth);
    }, []);

    const [activeTab, setActiveTab] = React.useState('tab1');

    return (
        <>
            <Tabs  defaultActiveKey="tab1" onSelect={tab => setActiveTab(tab)} style={{left: leftWidth}} >
                {isApi(API.apiMgmts, 'GET') && <Tab eventKey="tab1" title="프로그램관리">
                    {activeTab === 'tab1' && <PgmList />}
                </Tab>}
                {isApi(API.usrGrpMgmts, 'GET') && <Tab eventKey="tab2" title="프로그램 권한관리">
                   {activeTab === 'tab2' && <PgmAuthList />}
                </Tab>}
            </Tabs>
        </>
    );

};
export default PgmContainer;