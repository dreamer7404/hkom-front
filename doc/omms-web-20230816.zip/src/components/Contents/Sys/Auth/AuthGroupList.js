/* eslint-disable react-hooks/exhaustive-deps */
// react
import React, {useState, useEffect, useCallback, useRef,useMemo} from 'react';
import {Col, Button, Collapse} from 'react-bootstrap';
import {Form, SelectPicker, useToaster, Notification} from 'rsuite';
import SearchIcon from '@rsuite/icons/Search';
//--------------  서버데이터용 필수 -------------------------------
import { useQuery, useQueryClient, useMutation} from 'react-query';
import { getData, postData } from '../../../../utils/async';
import { API, CONSTANTS } from '../../../../utils/constants';
import useStore from '../../../../utils/store';
//--------------// 서버데이터용 필수 -------------------------------

import GridAuthGroupList from '../_Grid/GridAuthGroupList';
import Total from '../../../Common/Total';

import AuthGroupUpdate from '../Popup/AuthGroupUpdate';
import { forEach } from 'lodash';

const AuthGroupList = () => {

    //------------------- 필수 공통 ------------------------------
    const [open, setOpen] = useState(true); // 조건창 열기/닫기
    const {keyword } = useStore();  // 조회키워드 가져오기

    const [activePage, setActivePage] = useState(1);    // 페이지번호
    const [limit, setLimit] = useState(50);             // 페이지행수
    const [filterValue, setFilterValue] = useState(''); // 필터값

    const onChangePage = val => {
        setActivePage(val);
    };
    const onChangeLimit = val => {
        setLimit(val);
    };
    useEffect(()=>{
        onChangePage(1); // 페이지번호 리셋
    },[keyword]);

    // 필터
    const onFilterTextBoxChanged = useCallback((e) => {
        setFilterValue(e.target.value);
    }, []);

    // 검색창 열기/닫기 > 페이지네이션 여부에 따라 +-20px
    const [gridHeight, setGridHeight] = useState(575);
    const gridExpand = () =>{
        setOpen(!open);
        if(open){
            setTimeout(() => setGridHeight(650), 250);
        }else{
            setGridHeight(575)
        }
    }
    //-------------------// 필수 공통 ------------------------------

    const gridRef = useRef();

    //  requestState 조회
    const queryResult = useQuery([API.authAffrMgmtsForGrp], () => getData(API.authAffrMgmtsForGrp), {
        select: data => {
           const grpList = [...new Set(data.map(item => item.grpCd))].map(item => ({grpCd: item, grpNm: '', pgmNms:[], menuIds: []}));
  
           for(let i=0; i<data.length; i++){
               const item = data[i];
              for(let k=0; k<grpList.length; k++){
                   if(grpList[k].grpCd === item.grpCd){
                       grpList[k].grpNm = item.grpNm;
                       grpList[k].pgmNms.push(item.pgmNm);  
                       grpList[k].menuIds.push(item.pgmNm  + ',' + item.menuId + ',' + item.grpCd);                            
                   }
              }
           }
           return grpList;
        }
    });

    useEffect(() => {
        if(queryResult.isSuccess){
            setRowData(queryResult.data);
        }
     },[queryResult.data])

    const [rowData, setRowData] = useState([]);
    const [grpMenuList, setGrpMenuList] = useState('');
    const [grpCd, setGrpCd] = useState('');

    // 셀 클릭
    const onCellClicked = e => {
        if(e.column.colId === 'grpNm'){
            setAuthGroupUpdatePop(true);
            // setGrpMenuList(e.data.menuIds);
            setGrpCd(e.data.grpCd);
        }
    };

    const [authGroupUpdatePop, setAuthGroupUpdatePop] = useState(false);

    // 팝업닫기 & 리프레시
    const onHide = () => {
        setAuthGroupUpdatePop(false);
        setTimeout(()=> queryResult.refetch(), 100);
    }

    return (
        <>
            <div className="grid-wrap" style={{paddingTop:'10px', borderTop:'2px solid var(--main-color)'}}>
                {/*--------- Grid -----------*/}
                <GridAuthGroupList 
                    queryResult={queryResult} 
                    rowData={rowData} // 데이터용
                    limit={limit}
                    activePage={activePage}
                    onCellClicked={onCellClicked}
                    />

                {/*--------- 페이징 -----------*/}
                <Total 
                    total={rowData && rowData.length}
                    limit={limit}
                    activePage={activePage}
                    onChangePage={onChangePage}
                    onChangeLimit={onChangeLimit}
                />
            </div>

           {authGroupUpdatePop &&  <AuthGroupUpdate show={authGroupUpdatePop} onHide={onHide} grpCd={grpCd} />}
        </>
    )
};
export default AuthGroupList;