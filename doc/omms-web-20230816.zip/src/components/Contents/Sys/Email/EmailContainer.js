import React from 'react';
import {Tab,Tabs} from 'react-bootstrap';

import EmailHistory from './EmailHistory';
import EmailRcvList from './EmailRcvList';
import { isApi } from '../../../../utils/commUtils';
import { API } from '../../../../utils/constants';
const EmailConainer = () => {
    
    const [leftWidth, setLeftWidth] = React.useState('150px')
    React.useEffect(() => {
        const getTitle = document.getElementById('section-title-width');
        const titleWidth = getTitle.clientWidth + 40;
        setLeftWidth(titleWidth);
    }, []);

    return (
        <>
            <Tabs  defaultActiveKey="tab1" style={{left: leftWidth}} >
            {isApi(API.emailLogs, 'GET') &&  <Tab eventKey="tab1" title="이력관리">
                    <EmailHistory />
                </Tab>}
                {isApi(API.emlRcvrMgmts, 'GET') &&<Tab eventKey="tab2" title="수신자관리">
                   <EmailRcvList />
                </Tab>}
            </Tabs>
        </>
    );

};
export default EmailConainer;