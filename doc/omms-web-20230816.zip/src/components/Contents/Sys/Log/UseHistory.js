/* eslint-disable react-hooks/exhaustive-deps */
// react
import React, {useState, useEffect, useCallback, useRef} from 'react';
import {Col, Button, Collapse} from 'react-bootstrap';
import SearchIcon from '@rsuite/icons/Search';
import {Grid, Row,Form ,Input, SelectPicker} from 'rsuite';

//--------------  서버데이터용 필수 -------------------------------
import { useQuery, useQueryClient, useMutation} from 'react-query';
import { getData, postData } from '../../../../utils/async';
import { API, CONSTANTS } from '../../../../utils/constants';
import useStore from '../../../../utils/store';
//--------------// 서버데이터용 필수 -------------------------------
import SeDateLog from '../../../Search/SeDateLog';
import { confirmAlert } from 'react-confirm-alert'; 
import ConfirmAlert from   '../../../Common/ConfirmAlert';  

import GridUseHistory from '../_Grid/GridUseHistory';
import Paging from '../../../Common/Paging';
import { CustomInputGroup } from '../../../Common/CustomInputGroup';

// icon
import {ArrowDownLine, ArrowUpLine} from '@rsuite/icons';
const UseHistory = () => {

    //------------------- 필수 공통 ------------------------------
    const [open, setOpen] = useState(true); // 조건창 열기/닫기
    const {keyword } = useStore();  // 조회키워드 가져오기

    const [activePage, setActivePage] = useState(1);    // 페이지번호
    const [limit, setLimit] = useState(50);             // 페이지행수
    // const [filterValue, setFilterValue] = useState(''); // 필터값

    const onChangePage = val => {
        setActivePage(val);
        setParams(state => ({...state, pageNo: val, offset: (val-1)*limit}));
    };
    const onChangeLimit = val => {
        setLimit(val);
        setParams(state => ({...state, pageSize: val}));
        onChangePage(1); // 페이지번호 리셋
    };
    useEffect(()=>{
        setParams(state => ({...state, startDate: keyword.sDateLog, endDate: keyword.eDateLog}));
        onChangePage(1); // 페이지번호 리셋
    },[keyword]);

    // 필터
    // const onFilterTextBoxChanged = useCallback((e) => {
    //     setFilterValue(e.target.value);
    // }, []);

    // 검색창 열기/닫기 > 페이지네이션 여부에 따라 +-20px
    const [gridHeight, setGridHeight] = useState(575);
    const gridExpand = () =>{
        setOpen(!open);
        if(open){
            setTimeout(() => setGridHeight(650), 250);
        }else{
            setGridHeight(575)
        }
    }
    //-------------------// 필수 공통 ------------------------------

    const gridRef = useRef();

    // 조회조건 설정
    const [userEeno, setUserEeno] = useState('');
    const onChangeUserEeno = val => {
        setUserEeno(val);
    }

    useEffect(()=>{
        setParams(state => ({...state, userEeno: userEeno}));

    },[userEeno])
    // DB조회 파라미타
    const [params, setParams] = useState({
        userEeno:'',
        orderType: '',
        orderBy: '',
        startDate: keyword.sDateLog,
        endDate: keyword.eDateLog,
        pageNo: activePage,
        pageSize: limit,
        offset: 0,
    });

    // total count
    const queryResultTot = useQuery([API.logUsesTot, params], () => getData(API.logUsesTot, params), {staleTime: 0, cacheTime: 0, retry: 0}) ; 
    // list
    const queryResult = useQuery([API.logUses, params], () => getData(API.logUses, params), {staleTime: 0, cacheTime: 0, retry: 0});    


    useEffect(()=> {
        if(queryResult.data){
            queryResult.remove(); 
        }
    },[queryResult.data])


    // 조회버튼
    const onSearch = () => {
        setParams(state => ({...state, userEeno: userEeno}));
        setTimeout(()=> queryResult.refetch(), 100); // 수동쿼리실행
    };

    // 헤더클릭(정렬)
    const onSortChanged = e => {
        let sortModel = e.columnApi.getColumnState().filter((col) => col.sort);
        
        if(sortModel.length === 1){
            setParams(state => ({...state, 
                orderBy: sortModel[0].colId, 
                orderType: sortModel[0].sort}));
        }
    }

   

    return (
        <>
            <div className="search-area">
                <Collapse in={open}>
                    <div className="form" id="example-collapse-text">
                        <div className="search-group">
                            <div className="row">
                                <Col sm={3} > 
                                    <SeDateLog />
                                </Col>
                                <Col sm={2} >
                                    <Form.ControlLabel column="sm" >사용자ID</Form.ControlLabel>
                                    <Input size="sm" type="text" onChange={onChangeUserEeno} />
                                </Col>
                            </div>

                            <div className="search-btn-wrap">
                                <Button className="btn-search" variant="outline-primary" size="sm" onClick={onSearch}><SearchIcon />조회</Button>
                            </div>
                        </div>
                    </div>
                </Collapse>
                <Button size="sm" variant="outline-dark" className="search-control" aria-controls="example-collapse-text" 
                    aria-expanded={open} onClick={gridExpand}>
                    {/* <span className={open === true ? "search-area-close" : "search-area-open"}>{open === true ? CONSTANTS.closeSearch : CONSTANTS.openSearch}</span> */}
                    {open ? <span className="search-area-close"><ArrowUpLine style={{marginRight: '5px', fontSize: '2em'}} />{CONSTANTS.closeSearch}</span> :
                    <span className="search-area-open"><ArrowDownLine style={{marginRight: '5px', fontSize: '2em'}} />{CONSTANTS.openSearch}</span>}
                </Button>
            </div>
            
            <div className="grid-wrap">
                <div className="grid-btn-wrap">
                    {/* <div className="left-align">
                        <CustomInputGroup size="sm"   onInput={onFilterTextBoxChanged} />
                    </div> */}
                </div>
                {/*--------- Grid -----------*/}
                <GridUseHistory 
                    queryResult={queryResult}
                    gridRef={gridRef}
                    gridHeight={gridHeight}
                    onSortChanged={onSortChanged}
                    />

                {/*--------- 페이징 -----------*/}
                <Paging 
                    // total={queryResult && queryResult.data && queryResult.data.length}
                    total={queryResultTot && queryResultTot.data}
                    limit={limit}
                    activePage={activePage}
                    onChangePage={onChangePage}
                    onChangeLimit={onChangeLimit}
                />
            </div>

        </>
    )
};
export default UseHistory;