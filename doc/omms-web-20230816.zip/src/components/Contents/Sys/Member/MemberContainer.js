import React from 'react';
import {Tab,Tabs} from 'react-bootstrap';
import MemberList from './MemberList';
import MemberGroupList from './MemberGroupList';
import { isApi } from '../../../../utils/commUtils';
import { API } from '../../../../utils/constants';
const MemberContainer = () => {

    const [leftWidth, setLeftWidth] = React.useState('150px')
    React.useEffect(() => {
        const getTitle = document.getElementById('section-title-width');
        const titleWidth = getTitle.clientWidth + 40;
        setLeftWidth(titleWidth);
    }, []);



    const [activeTab, setActiveTab] = React.useState('tab1');
    
    return (
        <>  
            <Tabs  defaultActiveKey={activeTab} onSelect={tab => setActiveTab(tab)} style={{left: leftWidth}} >
                {isApi(API.usrmgmts, 'GET') &&  <Tab eventKey="tab1" title="사용자관리">
                    {activeTab === 'tab1' && <MemberList />}
                </Tab>}
                {isApi(API.usrGrpMgmts, 'GET') && <Tab eventKey="tab2" title="사용자그룹관리">
                    {activeTab === 'tab2' && <MemberGroupList />}
                </Tab>}
            </Tabs>
        </>

       
    );

};
export default MemberContainer;