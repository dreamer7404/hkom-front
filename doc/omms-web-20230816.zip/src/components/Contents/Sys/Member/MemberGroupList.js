// react
import React, {useState, useEffect} from 'react';
import {Button} from 'react-bootstrap';

//--------------  서버데이터용 필수 -------------------------------
import { useQuery, useQueryClient, useMutation} from 'react-query';
import { getData, postData } from '../../../../utils/async';
import { API, CONSTANTS } from '../../../../utils/constants';
import useStore from '../../../../utils/store';
//--------------// 서버데이터용 필수 -------------------------------

import GridMemberGroupList from '../_Grid/GridMemberGroupList';
import Total from '../../../Common/Total';

import MemberGroupAdd from '../Popup/MemberGroupAdd';
import MemberGroupUpdate from '../Popup/MemberGroupUpdate';
import { escapeCharChange } from '../../../../utils/commUtils';
import { isApi } from '../../../../utils/commUtils';
const MemberGroupList = () => {

    //------------------- 필수 공통 ------------------------------
    const {keyword } = useStore();  // 조회키워드 가져오기

    const [activePage, setActivePage] = useState(1);    // 페이지번호
    const [limit, setLimit] = useState(50);             // 페이지행수

    const onChangePage = val => {
        setActivePage(val);
    };
    const onChangeLimit = val => {
        setLimit(val);
    };
    useEffect(()=>{
        onChangePage(1); // 페이지번호 리셋
    },[keyword]);

    //-------------------// 필수 공통 ------------------------------

    //  requestState 조회
    const queryResult = useQuery([API.usrGrpMgmts], () => getData(API.usrGrpMgmts));

    const [memberData, setMemberData] = useState(false);


    // 셀 클릭
    const onCellClicked = e => {
        // console.log(e);
        // alert(e.column.colId + ',' + e.value)

        if(e.column.colId === 'grpCd'){
            setMemberGroupUpdatePop(true);
            setMemberData(e.data);
        }

    };

    const [memberGroupAddPop, setMemberGroupAddPop] = useState(false);
    const [memberGroupUpdatePop, setMemberGroupUpdatePop] = useState(false);

    const onHideMemberAdd = () => {
        setMemberGroupAddPop(false);
        queryResult.refetch();
    }

    const onHideMemberUpdate = () => {
        setMemberGroupUpdatePop(false);
        queryResult.refetch();
    }

    return (
        <>
            <div className="grid-wrap" style={{paddingTop:'10px', borderTop:'2px solid var(--main-color)'}}>
                <div className="grid-btn-wrap">
                    <div className="right-align">
                        {/*--------- 버튼 -----------*/}
                        {isApi(API.usrGrpMgmt, 'POST') &&  <Button variant="outline-secondary" size="sm" onClick={() => setMemberGroupAddPop(true)}>사용자그룹 등록</Button>}{' '}
                    </div>
                </div>
                {/*--------- Grid -----------*/}
                <GridMemberGroupList 
                    queryResult={queryResult}
                    limit={limit}
                    activePage={activePage}
                    onCellClicked={onCellClicked}
                    />

                {/*--------- 페이징 -----------*/}
                <Total 
                    total={queryResult && queryResult.data && queryResult.data.length}
                    limit={limit}
                    activePage={activePage}
                    onChangePage={onChangePage}
                    onChangeLimit={onChangeLimit}
                />
            </div>

             {memberGroupAddPop && <MemberGroupAdd show={memberGroupAddPop} onHide={onHideMemberAdd} />}
             {memberGroupUpdatePop && <MemberGroupUpdate  data={memberData}  show={memberGroupUpdatePop} onHide={onHideMemberUpdate} />}
        </>
    )
};
export default MemberGroupList;