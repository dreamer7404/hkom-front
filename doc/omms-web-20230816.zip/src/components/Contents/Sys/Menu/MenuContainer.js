import React from 'react';
import {Tab,Tabs} from 'react-bootstrap';

import MenuList from './MenuList';
import MenuGroupList from './MenuGroupList';
import { isApi } from '../../../../utils/commUtils';
import { API } from '../../../../utils/constants';
import useStore from '../../../../utils/store';

const MenuContainer = () => {

    const [leftWidth, setLeftWidth] = React.useState('150px')
    React.useEffect(() => {
        const getTitle = document.getElementById('section-title-width');
        const titleWidth = getTitle.clientWidth + 40;
        setLeftWidth(titleWidth);
    }, []);
   
    return (
        <>
            <Tabs  defaultActiveKey="tab1" style={{left: leftWidth}}  >
                {isApi(API.pgmMgmtsAll, 'GET') &&<Tab eventKey="tab1" title="메뉴관리" >
                    <MenuList />
                </Tab>}
                {isApi(API.pgmMgmtGrps, 'GET') &&<Tab eventKey="tab2" title="메뉴그룹관리">
                   <MenuGroupList />
                </Tab>}
            </Tabs>
        </>
    );

};
export default MenuContainer;