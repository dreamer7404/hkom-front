/* eslint-disable react-hooks/exhaustive-deps */
// react
import React, {useState, useEffect, useCallback, useRef,useMemo} from 'react';
import {Button, Collapse} from 'react-bootstrap';
import {Form, SelectPicker, useToaster, Notification,Placeholder, Row, Col, Message} from 'rsuite';
import SearchIcon from '@rsuite/icons/Search';
import { AgGridReact } from 'ag-grid-react';

//--------------  서버데이터용 필수 -------------------------------
import { useQuery, useQueryClient, useMutation} from 'react-query';
import { getData, postData } from '../../../../utils/async';
import { API, CONSTANTS } from '../../../../utils/constants';
import useStore from '../../../../utils/store';
//--------------// 서버데이터용 필수 -------------------------------

import GridMenuList from '../_Grid/GridMenuList';
import Paging from '../../../Common/Paging';
import { CustomInputGroup } from '../../../Common/CustomInputGroup';

import MenuAdd from '../Popup/MenuAdd';
import MenuUpdate from '../Popup/MenuUpdate';
import { confirmAlert } from 'react-confirm-alert'; // Import
import ConfirmAlert from '../../../Common/ConfirmAlert';
// icon
import {ArrowDownLine, ArrowUpLine} from '@rsuite/icons';
import { isApi } from '../../../../utils/commUtils';
const MenuList = () => {

     //------------------- 필수 공통 ------------------------------
     const [open, setOpen] = useState(true); // 조건창 열기/닫기
     const {keyword } = useStore();  // 조회키워드 가져오기
 
     const [activePage, setActivePage] = useState(1);    // 페이지번호
     const [limit, setLimit] = useState(50);             // 페이지행수
     const [filterValue, setFilterValue] = useState(''); // 필터값
 
     const onChangePage = val => {
         setActivePage(val);
     };
     const onChangeLimit = val => {
         setLimit(val);
     };
     useEffect(()=>{
         onChangePage(1); // 페이지번호 리셋
     },[keyword]);
 
     // 필터
     const onFilterTextBoxChanged = useCallback((e) => {
         setFilterValue(e.target.value);
     }, []);
 
     // 검색창 열기/닫기 > 페이지네이션 여부에 따라 +-20px
     const [gridHeight, setGridHeight] = useState(575);
     const gridExpand = () =>{
         setOpen(!open);
         if(open){
             setTimeout(() => setGridHeight(650), 250);
         }else{
             setGridHeight(575)
         }
     }
     //-------------------// 필수 공통 ------------------------------

    const gridRef = useRef();
    const toaster = useToaster();

    const [grpNm, setGrpNm] = useState('');
    

    



    //  pgmMgmts 조회
    const queryResult = useQuery([API.pgmMgmtsAll,{pgmId : grpNm}], () => getData(API.pgmMgmtsAll,{pgmId : grpNm}), {
        select: data => {
            if(data.menuList.length === 1) return data;

            data.menuList[data.menuList.length-1].flag = 1;
            let cnt = 1;
            for(let i=data.menuList.length-2; i>=0; i--){
                if(data.menuList[i].grpNm === data.menuList[i+1].grpNm){
                    data.menuList[i+1].flag = 1;
                    data.menuList[i].flag = ++cnt;
                }else{
                    cnt = 1;
                    data.menuList[i].flag = 1;
                }
            }
            return data;
        }

    });


    const [grpCombo, setGrpCombo] = useState(null);
    const [data, setData] = useState();
    const pgmGrpCombo = useQuery([API.pgmGrpCombo, {}], () => getData(API.pgmGrpCombo, {}), {
        select: data => [{label: '전체', value: ''}].concat(data.map((item) => ({ label: item.pgmNm, value: item.pgmId })))
        
    }); 

    useEffect(() => {
        if(queryResult.isSuccess){
            setGrpCombo([{label: '전체', value: ''}]
                .concat(queryResult.data.grpList.map(d=> ({label: d.pgmNm, value: d.pgmId})))
            );
        }
    },[queryResult.status]);

    const onChangeGrpCombo = val => {
        setGrpNm(val);
    };

    // 셀 클릭
    const onCellClicked = e => {
        if(e.column.colId === 'pgmNm'){
            setMenuUpdatePop(true)
            const param = {
                menuId : e.data.menuId,
                pgmId : e.data.pgmId,
                pgmNm : e.data.pgmNm,
                pgmIdSn : e.data.pgmIdSn,
                pgmPathAdr : e.data.pgmPathAdr,
                useYn : e.data.useYn,
                grpNm : e.data.grpNm
            }
            setData(param)
        }
    };

    const [menuAddPop, setMenuAddPop] = useState(false);
    const [menuUpdatePop, setMenuUpdatePop] = useState(false);


    // 조회버튼
    const onSearch = () => {
        queryResult.refetch(); // 수동쿼리실행
    };


    // 사용여부 수정
    const changeUseYnMutate = useMutation((params => postData(API.changePgmMgmtUseYn, params, CONSTANTS.update)),{
        onSuccess: res => {
           if(res > 0){
                confirmAlert({
                    closeOnClickOutside: false,
                    customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}   title={"알림"}
                    msg={"저장되었습니다."}   />
                });
                 queryResult.refetch();
            }else{
                confirmAlert({
                    closeOnClickOutside: false,
                    customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}   title={"알림"}
                    msg={"에러가 발생했습니다 관리자에게 문의해주세요."}   />
                });
            }
        }
    });

    // 사용여부
    const onUseYn = useYn => {
        const rows = gridRef.current.api.getSelectedRows();
        if(rows.length > 0){
            changeUseYnMutate.mutate({useYn: useYn, list: rows.map(item => item.menuId)});
        } else {
            confirmAlert({
                closeOnClickOutside: false,
                customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}   title={"알림"}
                msg={"최소 한 개의 데이터를 선택해주세요."}   />
            });
        }
    };
    
    const onClickAdd= ()=>{
        setMenuAddPop(false)
        queryResult.refetch();
    }
    const onClickUpdate= ()=>{
        setMenuUpdatePop(false)
        queryResult.refetch();
    }
    return (
        <>
            <div className="search-area">
                <Collapse in={open}>
                    <div className="form" id="example-collapse-text">
                        <div className="search-group">
                            <div className="row">
                            <Col sm={3} className=""> 
                                <Col sm={6}>
                                    <Form.ControlLabel column="sm" >메뉴그룹</Form.ControlLabel>
                                    
                                        {pgmGrpCombo.isFetched && 
                                            <SelectPicker  
                                            block size="sm"
                                            searchable={false} 
                                            cleanable={false} 
                                            defaultValue={''}
                                            data={pgmGrpCombo.data} 
                                            onChange={onChangeGrpCombo}
                                        />}
                                     </Col>
                                </Col>
                                
                            </div>

                            <div className="search-btn-wrap">
                                <Button className="btn-search" variant="outline-primary" size="sm" onClick={onSearch}><SearchIcon />조회</Button>
                            </div>
                           
                        </div>
                    </div>
                </Collapse>
                <Button size="sm" variant="outline-dark" className="search-control" aria-controls="example-collapse-text" 
                    aria-expanded={open} onClick={gridExpand}>
                    {/* <span className={open === true ? "search-area-close" : "search-area-open"}>{open === true ? CONSTANTS.closeSearch : CONSTANTS.openSearch}</span> */}
                    {open ? <span className="search-area-close"><ArrowUpLine style={{marginRight: '5px', fontSize: '2em'}} />{CONSTANTS.closeSearch}</span> :
                    <span className="search-area-open"><ArrowDownLine style={{marginRight: '5px', fontSize: '2em'}} />{CONSTANTS.openSearch}</span>}
                </Button>
            </div>
            
            <div className="grid-wrap">
                <div className="grid-btn-wrap">
                    <div className="left-align">
                        {/*--------- 필터 -----------*/}
                        <CustomInputGroup size="sm"   onInput={onFilterTextBoxChanged} />
                    </div>
                    <div className="right-align">
                        {/*--------- 버튼 -----------*/}
                        {isApi(API.pgmMgmt, 'POST') &&  <Button variant="outline-secondary" size="sm" onClick={() => setMenuAddPop(true)}>메뉴 등록</Button>}{' '}
                        {isApi(API.changePgmMgmtUseYn, 'POST') &&  <Button variant="outline-secondary" size="sm" onClick={() => onUseYn('Y')}>사용</Button>}{' '}
                        {isApi(API.changePgmMgmtUseYn, 'POST') &&  <Button variant="outline-secondary" size="sm" onClick={() => onUseYn('N')}>미사용</Button>}{' '}
                    </div>
                </div>

                {/*--------- Grid -----------*/}
                <GridMenuList 
                    gridRef={gridRef}
                    gridHeight={gridHeight}
                    filterValue={filterValue}
                    queryResult={queryResult}
                    limit={limit}
                    activePage={activePage}
                    onCellClicked={onCellClicked}
                    grpNm={grpNm}
                    />

                {/*--------- 페이징 -----------*/}
                <Paging 
                    total={queryResult && queryResult.data && queryResult.data.menuList.length}
                    limit={limit}
                    activePage={activePage}
                    onChangePage={onChangePage}
                    onChangeLimit={onChangeLimit}
                />
            </div>

            {menuAddPop && pgmGrpCombo&& <MenuAdd show={menuAddPop} onHide={onClickAdd} grpCombo={pgmGrpCombo}/>}
            {menuUpdatePop && pgmGrpCombo&&<MenuUpdate show={menuUpdatePop} onHide={onClickUpdate}  grpCombo={pgmGrpCombo} data={data} />}
        </>
    )
};
export default MenuList;