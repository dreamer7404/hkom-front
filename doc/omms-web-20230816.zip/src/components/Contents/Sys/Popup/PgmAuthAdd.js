import React, {useState, useEffect, useCallback, useRef, useMemo} from 'react';
import { AgGridReact } from 'ag-grid-react';
import {Col, Modal, Button} from 'react-bootstrap';
import {Form, SelectPicker} from 'rsuite';
import SearchIcon from '@rsuite/icons/Search';

import { formatNumber, escapeCharChange } from '../../../../utils/commUtils';

//--------------  서버데이터용 필수 -------------------------------
import { useQuery, useQueryClient, useMutation} from 'react-query';
import { getData, postData } from '../../../../utils/async';
import { API, CONSTANTS } from '../../../../utils/constants';
import useStore from '../../../../utils/store';
//--------------// 서버데이터용 필수 -------------------------------
import { confirmAlert } from 'react-confirm-alert'; 
import ConfirmAlert from   '../../../Common/ConfirmAlert'; 
import CustomModal from '../../../Common/CustomModal';
import { isApi } from '../../../../utils/commUtils';
const PgmAuthAdd = ({show, data, onHide}) => {

    const gridRef = useRef();
    const [filterValue, setFilterValue] = useState(''); // 필터값
    const queryClient = useQueryClient();

    const columnDefs = [
        {
          checkboxSelection: true,
          headerCheckboxSelection: true,
          width:35,
          maxWidth:35,
          minWidth:35,
          sortable:false
        },
        {
            headerName: 'pgmId',
            field: 'pgmId',
            maxWidth:'100',
            hide: true,
        },
        {
            headerName: '메뉴ID',
            field: 'menuId',
            maxWidth:'100',
            hide: true,
            getQuickFilterText: () => ''
        },
        {
            headerName: '메뉴명',
            field: 'pgmNm',
            maxWidth:'150',
            cellRenderer: param => {
              return !param.value  ? '공통' : param.value;
            },
            getQuickFilterText: () => ''
        },
        {
            headerName: 'API URL',
            field: 'apiUrl',
            cellStyle: () => ({textAlign: 'left', textDecoration: 'underline', cursor: 'pointer', color:'#2589f5'}),
            getQuickFilterText: () => ''
        },
        {
          headerName: 'API 타입',
          field: 'method',
          maxWidth:'100',
          getQuickFilterText: () => ''
        },
        {
          headerName: 'API 설명',
          spanHeaderHeight: true,
          field: 'apiNm',
          cellStyle: () => ({textAlign: 'left'}),
          cellRenderer: param => escapeCharChange(param.value),
          getQuickFilterText: () => ''
        },
        
    ]

    const defaultColDef = useMemo(() => {
        return {
            initialWidth: 90,
            sortable: true,
            resizable:true,
            minWidth:70
        };
    }, []);

    const onFirstDataRendered = (params) => {
        params.api.sizeColumnsToFit();

         // 데이타에서 authVehl === 'Y'인것은 체크
         gridRef.current.api.forEachNode((node) =>
            node.setSelected(!!node.data && node.data.grpCd !== null)
        );
    };

    // 메뉴그룹
    const pgmGrpCombo = useQuery([API.pgmGrpCombo, {}], () => getData(API.pgmGrpCombo, {}), {
        select: data => [{label: '전체', value: ''}].concat(data.map((item) => ({ label: item.pgmNm, value: item.pgmId })))
        
    }); 



    //  requestState 조회
    const params = {
        grpCd: data.grpCd
    };  
    const queryResult = useQuery([API.apiMgmtsByApiAuth,  params], () => getData(API.apiMgmtsByApiAuth,  params));


    const updateMutate = useMutation((params => postData(API.apiAuth, params, CONSTANTS.update)),{
        onSuccess: res => {
            if(res === 1){
                confirmAlert({
                    closeOnClickOutside: false,
                    customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}  title={"알림"} msg={"저장이 완료되었습니다."}  />
                })
                queryResult.remove();
                queryClient.invalidateQueries(); //모든 쿼리 캐시 초기화 
                onHide(); // 창닫기 & refetch
            }else{
                confirmAlert({
                    closeOnClickOutside: false,
                    customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}  title={"알림"} msg={"등록이 실패했습니다.<br /> 관리자에게 문의해주세요."}  />
                })
            }
        }
    }); 

    // 저장버튼 클릭
    const handleSubmit = () => {

        const selectedRows = gridRef.current.api.getSelectedRows();
      
        // API 등록 실행
        const params = {
            grpCd: data.grpCd,
            apiUrls: selectedRows.map(item => ({apiUrl: item.apiUrl, method: item.method})),
        }
        const onOk = () => {
            updateMutate.mutate(params);
        }
        confirmAlert({
            closeOnClickOutside: false,
            customUI: ({ onClose }) => <ConfirmAlert 
                                            onClose={onClose} 
                                            title={"알림"}
                                            msg={"입력하신 내용으로 저장 하시겠습니까?"} 
                                            onOk={onOk}  
                                        />
        })
    };

    const [pgmId, setPgmId] = useState(null);
    const onChangePgmGrpCombo = val => {
        setPgmId(val);
        // setFilterValue(val);
        if(gridRef && gridRef.current && gridRef.current.api){
            gridRef.current.api.setQuickFilter(val);
          }
    };



    return (
        <>
            <Form>
                <CustomModal open={show} 
                    title={'프로그램 권한등록'}
                    size='lg'
                    handleCancel={onHide} 
                    >
                        <div className="search-area">
                            <div className="form" id="example-collapse-text">
                                <div className="search-group">
                                    <div className="row">
                                        <Col sm={6} className=""> 
                                            <Form.ControlLabel column="sm" >메뉴그룹</Form.ControlLabel>
                                            <SelectPicker block size="sm" 
                                                searchable={false}
                                                cleanable={false} 
                                                data={pgmGrpCombo && pgmGrpCombo.data} 
                                                defaultValue="" 
                                                onChange={onChangePgmGrpCombo} />
                                        </Col>
                                    </div>
                                    {/* <div className="search-btn-wrap">
                                        <Button className="btn-search" variant="ou-primary" size="sm"><SearchIcon />조회</Button>
                                    </div> */}
                                </div>
                            </div>
                        </div>
                        <div className="grid-btn-wrap">
                            <div className="left-align">
                                <div className="sub-title">
                                    <ul>
                                        <li>권한그룹명: {data.grpNm}</li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div className="ag-theme-alpine" style={{height:300, minWidth:300}}>
                            <AgGridReact
                                ref={gridRef}
                                rowData={queryResult && queryResult.data}
                                columnDefs={columnDefs}
                                defaultColDef={defaultColDef}
                                rowSelection={'multiple'}
                                suppressRowClickSelection= {true} 
                                onFirstDataRendered={onFirstDataRendered}
                                suppressSizeToFit={true}    
                                onGridSizeChanged={onFirstDataRendered}  
                                
                                cacheQuickFilter={true}
                                includeHiddenColumnsInQuickFilter={true}
                                >
                            </AgGridReact>
                        </div>
                        <div className='modal-footer'>
                            <Button variant="light" size="md" onClick={onHide}>취소</Button>
                            {isApi(API.apiAuth, 'POST') &&   <Button variant="primary" size="md" onClick={handleSubmit}>저장</Button>}
                        </div>
                </CustomModal>
            </Form>
        </>
    );

};
export default PgmAuthAdd;