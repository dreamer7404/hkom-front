import React from 'react';
import { useEffect } from 'react';
import {Button, Modal, Table} from 'react-bootstrap';
import {Form} from 'rsuite';
import {CONSTANTS, API } from '../../../../utils/constants';
import { getData } from '../../../../utils/async';
import { useQuery} from 'react-query';
import CustomModal from '../../../Common/CustomModal';
import {unescapeHtml,escapeCharChange} from '../../../../utils/commUtils';
const EmailDetail = ({show, onHide,param}) => {


    const queryResult = useQuery([API.emailLog, param], () => getData(API.emailLog, param),{
        staleTime: 0,
        
    });
    useEffect(()=>{
        if(queryResult.isSuccess){
    
            const dataInfo = queryResult.data;
            console.log("dataInfo",dataInfo);
      }
    },[queryResult.status])

    return (
        <>
            <Form>
            <CustomModal open={show} 
                        title={'이력 상세'}
                        size='lg'
                        // handleOk={handleSubmit}
                        handleCancel={onHide} >
                            <Table className="tbl-hor" bordered>
                                <colgroup>
                                    <col style={{width:'30%'}}></col>
                                    <col style={{width:''}}></col>
                                </colgroup>
                                <tbody>
                                    <tr>
                                        <th className="">수신인</th>
                                        <td>
                                            {queryResult.data && queryResult.data.rcvrNm}
                                        </td>
                                    </tr>
                                    <tr>
                                        <th className="">제목</th>
                                        <td>
                                        {queryResult.data && escapeCharChange(queryResult.data.emlTitl)}
                                        </td>
                                    </tr>
                                    <tr>
                                        <th className="">내용</th>
                                        <td>
                                        {/* <div dangerouslySetInnerHTML={{__html: unescapeHtml(data.blcSbc)}} />  */}
                                        {/* <div dangerouslySetInnerHTML= {{__html:queryResult.data && unescapeHtml(queryResult.data.emlSbc)}}/> */}
                                        {/* <div style={{maxWidth:'30'}} dangerouslySetInnerHTML= {{__html:queryResult.data && unescapeHtml(escapeCharChange(queryResult.data.emlSbc))}}/> */}
                                        
                                        <div style={{maxWidth:'30'}} dangerouslySetInnerHTML= {{__html:queryResult.data && escapeCharChange(unescapeHtml(queryResult.data.emlSbc))}}/>
                                        </td>
                                    </tr>
                                </tbody>
                            </Table>
                        

                        <div className='modal-footer'>
                            <Button variant="primary" size="md" onClick={onHide} >확인</Button>
                        </div>
                </CustomModal>
            </Form>
        </>
    );

};
export default EmailDetail;