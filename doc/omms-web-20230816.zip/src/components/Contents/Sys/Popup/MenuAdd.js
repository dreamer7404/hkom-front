import React, {useEffect, useState} from 'react';
import {Button, Modal, Table} from 'react-bootstrap';
import {Form, SelectPicker, Schema } from 'rsuite';
import { confirmAlert } from 'react-confirm-alert'; // Import
import ConfirmAlert from '../../../Common/ConfirmAlert';
import CustomModal from '../../../Common/CustomModal';
import {CONSTANTS, API } from '../../../../utils/constants';
import  {postData } from '../../../../utils/async';
import {useMutation} from 'react-query';
const { StringType, NumberType} = Schema.Types;
const model = Schema.Model({

    pgmId : StringType().isRequired('메뉴그룹을 선택해주세요.'),
    pgmNm: StringType().isRequired('메뉴명을 입력해주세요.').pattern(/^[가-힣a-zA-Z]+$/, '한글, 영문만 입력사능합니다.'),
    pgmIdSn: StringType().isRequired('정렬순서를 입력해주세요.'),
    pgmPathAdr : StringType().isRequired('URL을 입력해주세요.'),
});


const MenuAdd = ({show, onHide, grpCombo}) => {
    // Form 정의
    const formRef = React.useRef();
    const [formError, setFormError] = React.useState({});
    const [formValue, setFormValue] = React.useState({
        pgmId : '',
        pgmNm : '',
        pgmIdSn : '',
        pgmPathAdr : '',
        useYn : 'Y',
    });
    
    const handleSubmit = () => {
        if (!formRef.current.check()) { //validation chk
            return;
        }
        confirmAlert({
            closeOnClickOutside: false,
            customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}   title={"알림"}
            msg={"입력하신 내용으로 저장하시겠습니까?"} 
            onOk={onOk}  />
        });
    };


    const onOk = () => {
        menuAddSave.mutate(formValue);
    }


    const menuAddSave = useMutation((params => postData(API.pgmMgmt, params, CONSTANTS.insert)),{
        onSuccess: res => {
           if(res>0){
                confirmAlert({
                    closeOnClickOutside: false,
                    customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}   title={"알림"}
                    msg={"저장이 완료되었습니다."}   />
                    
                });
           }else{
                confirmAlert({
                    closeOnClickOutside: false,
                    customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}   title={"알림"}
                    msg={"에러가 발생했습니다 관리자에게 문의해주세요."}   />
                });
           }
           onHide();
        }
    });

    return (
        <>
            <Form
              ref={formRef}
              checkTrigger="change"
              onChange={setFormValue}
              onCheck={setFormError}
              formValue={formValue}
              model={model}>
       
                    <CustomModal open={show} 
                        title={'메뉴 등록'}
                        size='md'
                        // handleOk={handleSubmit}
                        handleCancel={onHide} 
                        
                        >
                            <Table className="tbl-hor" bordered>
                                <colgroup>
                                    <col style={{width:'30%'}}></col>
                                    <col style={{width:''}}></col>
                                </colgroup>
                                <tbody>
                                    <tr>
                                        <th className="essen">메뉴그룹</th>
                                        <td>
                                            <Form.Control name="pgmId" size="sm" 
                                                placeholder="선택"
                                                accepter={SelectPicker} 
                                                searchable={false}
                                                cleanable={false}
                                                data={grpCombo && grpCombo.data.filter(d=> d.value !== '')}
                                            ></Form.Control>
                                        </td>
                                    </tr>
                                    <tr>
                                        <th className="essen">메뉴명</th>
                                        <td colSpan="3">
                                            <Form.Control size="sm" name = "pgmNm" type="text"/> 
                                        </td>
                                    </tr>
                                    <tr>
                                        <th className="essen">순번</th>
                                        <td>
                                            <Form.Control size="sm" name = "pgmIdSn" type="text"/>
                                        </td>
                                    </tr>
                                    <tr>
                                        <th className="essen">URL</th>
                                        <td colSpan="3">
                                            <Form.Control size="sm" name = "pgmPathAdr" type="text"/> 
                                        </td>
                                    </tr>
                                    <tr>
                                    <th className="">사용여부</th>
                                        <td colSpan="3">
                                            <Form.Control name="useYn" size="sm" 
                                                placeholder={'선택'}
                                                defaultValue={formValue.useYn}
                                                accepter={SelectPicker} 
                                                searchable={false}
                                                cleanable={false}
                                                data={[
                                                    {label: '사용', value: 'Y'},
                                                    {label: '미사용', value: 'N'},
                                                ]}
                                            ></Form.Control>
                                        </td>
                                    </tr>
                                </tbody>
                            </Table>
                        

                        <div className='modal-footer'>
                            <Button variant="light" size="md" onClick={onHide}>취소</Button>
                            <Button variant="primary" size="md" onClick={handleSubmit} >저장</Button>
                        </div>
                </CustomModal>
            </Form>
        </>
    );

};
export default MenuAdd;