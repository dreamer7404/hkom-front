import React, {useState, useRef,useEffect} from 'react';
import {Button, Modal, Table} from 'react-bootstrap';
import {Form,Schema, SelectPicker} from 'rsuite';
import { API, CONSTANTS } from '../../../../utils/constants';
import { useQuery, useMutation, useQueryClient } from 'react-query';
import { getData,postData } from '../../../../utils/async';
import { confirmAlert } from 'react-confirm-alert'; // Import
import ConfirmAlert from '../../../Common/ConfirmAlert';
import CustomModal from '../../../Common/CustomModal';

const {StringType,NumberType} = Schema.Types;

const model = Schema.Model({
    dlExpdGCd: StringType().isRequired('그룹명을 선택해주세요.'),
    dlExpdPrvsCd: StringType().isRequired('항목코드를 입력해주세요.')
    .maxLength(4, '최대 4자까지 입력 가능합니다.')
    .pattern(/^[a-zA-Z0-9]*$/, '알파벳과 숫자만 입력 가능합니다.'), //왠지 막아야할것 같아서.. 필요없음 빼세요.. by woong
    dlExpdPrvsNm: StringType().isRequired('항목명을 입력해주세요.'),
    sortSn: NumberType('숫자만 입력해주세요.').isRequired('정렬순서를 입력해주세요.'),
    useYn: StringType().isRequired('사용여부를 선택해주세요.')
});

const SysCodeAdd = ({show, onHide}) => {
    const formRef = useRef();
    const containerRef = React.useRef();
    const [formError, setFormError] = useState({});
    const [formValue, setFormValue] = useState({
        dlExpdGCd : '',
        dlExpdPrvsCd : '',
        dlExpdPrvsNm : '',
        sortSn : '',
        useYn : '',
    }); 
    const queryClient = useQueryClient();

    const grpCdCombo = useQuery([API.grpCodeCombo, {}], () => getData(API.grpCodeCombo, {}), {
        select: data =>data.map((item) => ({ label: item.dlExpdGNm, value: item.dlExpdGCd }))
    });

    const handleSubmit = () => {
        if (!formRef.current.check()) { //validation chk
            return;
        }
        confirmAlert({
            closeOnClickOutside: false,
            customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}   title={"알림"}
            msg={"입력하신 내용으로 저장하시겠습니까?"} 
            onOk={onOk}  />
        });
        
        
    }; 
    const codeSave = useMutation((params => postData(API.codeMgmt, params, CONSTANTS.insert)),{
        onSuccess: res => {
            if(res===999){
                confirmAlert({
                    closeOnClickOutside: false,
                    customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}   title={"알림"}
                    msg={"중복된 항목코드가 있습니다."}   />
                    
                })
                onHide();
                queryClient.invalidateQueries(); //모든 쿼리 캐시 초기화 
            } else if(res>0){
                confirmAlert({
                    closeOnClickOutside: false,
                    customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}   title={"알림"}
                    msg={"저장이 완료되었습니다."}   />
                    
                });
                onHide();
                queryClient.invalidateQueries(); //모든 쿼리 캐시 초기화 
            } else {
                confirmAlert({
                    closeOnClickOutside: false,
                    customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}   title={"알림"}
                    msg={"에러가 발생했습니다 관리자에게 문의해주세요."}   />
                    
                });
            }
        
          
         
        }
    });


    const onOk = () => {
        codeSave.mutate(formValue);
    }



    
    return (
        <>
            <Form
                ref={formRef}
                checkTrigger="change"
                onChange={setFormValue}
                onCheck={setFormError}
                formValue={formValue}
                model={model}>
                <CustomModal open={show} 
                        title={'코드 등록'}
                        size='md'
                        // handleOk={handleSubmit}
                        handleCancel={onHide} >
                            <Table className="tbl-hor" bordered>
                                <colgroup>
                                    <col style={{width:'30%'}}></col>
                                    <col style={{width:''}}></col>
                                </colgroup>
                                <tbody>
                                    <tr>
                                        <th className="essen">그룹명</th>
                                        <td>
                                        <Form.Control container={()=> containerRef.current}  name="dlExpdGCd" size="sm" style={{zIndex: 0}} 
                                                        placeholder={'선택'}
                                                        defaultValue={''}
                                                        accepter={SelectPicker} 
                                                        searchable={true}
                                                        cleanable={false}
                                                        data={grpCdCombo.isFetched && grpCdCombo.data}
                                        ></Form.Control>
                                        </td>
                                      
                                    </tr>
                                    <tr>
                                        <th className="essen">항목코드</th>
                                        <td>
                                            <Form.Control size="sm" name = 'dlExpdPrvsCd' type="text"/> 
                                        </td>
                                    </tr>
                                    <tr>
                                        <th className="essen">항목명</th>
                                        <td>
                                            <Form.Control size="sm" name = 'dlExpdPrvsNm' type="text"/>
                                        </td>
                                    </tr>
                                    <tr>
                                        <th className="essen">정렬순서</th>
                                        <td>
                                            <Form.Control size="sm" name = 'sortSn'type="text"/> 
                                        </td>
                                    </tr>
                                    <tr>
                                        <th className="">사용여부</th>
                                        <td>
                                            <Form.Control name="useYn" size="sm"   
                                                        placeholder={'선택'}
                                                        defaultValue={''}
                                                        accepter={SelectPicker} 
                                                        searchable={false}
                                                        cleanable={false}
                                                        data={[
                                                            {label: '사용', value: 'Y'},
                                                            {label: '미사용', value: 'N'},
                                                        ]}
                                            ></Form.Control>
                                        </td>
                                    </tr>
                                </tbody>
                            </Table>
                        
                        <div className='modal-footer'>
                            <Button variant="light" size="md" onClick={onHide}>취소</Button>
                            <Button variant="primary" size="md" onClick={handleSubmit} >저장</Button>
                        </div>

                </CustomModal>
            </Form>
        </>
    );

};
export default SysCodeAdd;