import React, {useState, useEffect} from 'react';
import {Button, Modal, Table} from 'react-bootstrap';
import {Form, SelectPicker,Schema} from 'rsuite';
import { escapeCharChange } from '../../../../utils/commUtils';
//--------------  서버데이터용 필수 -------------------------------
import { useQuery, useQueryClient, useMutation} from 'react-query';
import { getData, postData } from '../../../../utils/async';
import { API, CONSTANTS } from '../../../../utils/constants';
import useStore from '../../../../utils/store';
//--------------// 서버데이터용 필수 -------------------------------
import { confirmAlert } from 'react-confirm-alert'; 
import ConfirmAlert from   '../../../Common/ConfirmAlert';  
import { isApi } from '../../../../utils/commUtils';
import CustomModal from '../../../Common/CustomModal';
const { StringType} = Schema.Types;
const model = Schema.Model({
    apiUrl: StringType().isRequired('API URL을 입력해주세요.')
                            .maxLength(30, '30자로 이내로 입력해주세요'),
    apiNm: StringType().isRequired('API설명을 입력해주세요.')
                            .maxLength(30, '30자로 이내로 입력해주세요'),
    menuId: StringType().isRequired('해당되는 메뉴를 선택해주세요.'),
    method: StringType().isRequired('API타입을 선택해주세요.'),
});

const PgmUpdate = ({show, data, onHide}) => {

    const [menuData, setMenuData] = useState([]);

    const queryResult = useQuery([API.pgmMgmtsAll], () => getData(API.pgmMgmtsAll));

    useEffect(() => {
        if(queryResult.data){
            const grpList = queryResult.data.grpList;
            setMenuData(
                [{label: '공통', value: '9999', group: '공통'}].concat(
                queryResult.data.menuList
                .map(item => ({
                    label: item.pgmNm, 
                    value: item.menuId, 
                    group: grpList.find(f => f.pgmId === item.pgmId).pgmNm }))));
        }
    },[queryResult.data]);

     // Form 정의
     const formRef = React.useRef();
     const [formError, setFormError] = React.useState({});
     const [formValue, setFormValue] = React.useState({
        apiUrl: data.apiUrl,
        apiNm: escapeCharChange(data.apiNm),
        menuId: data.menuId,
        method: data.method,
     });


     const updateMutate = useMutation((params => postData(API.apiMgmt, params, CONSTANTS.update)),{
        onSuccess: res => {
            if(Number(res) === 1){
                confirmAlert({
                    closeOnClickOutside: false,
                    customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}  title={"알림"} msg={"저장이 완료되었습니다."}  />
                })
                onHide(); // 창닫기 & refetch
            }else if(Number(res) === -2){
                confirmAlert({
                    closeOnClickOutside: false,
                    customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}  title={"알림"} msg={"해당 API의 URL과 타입은 이미 등록되었습니다."}  />
                })
            }else{
                confirmAlert({
                    closeOnClickOutside: false,
                    customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}  title={"알림"} msg={"등록이 실패했습니다.<br /> 관리자에게 문의해주세요."}  />
                })
            }
        }
    }); 

     // 저장버튼 클릭
     const handleSubmit = () => {
        // validation 체크
        if (!formRef.current.check()) {
            return;
        }
        // API 등록 실행
        const onOk = () => {
            updateMutate.mutate(formValue);
        }
        confirmAlert({
            closeOnClickOutside: false,
            customUI: ({ onClose }) => <ConfirmAlert 
                                            onClose={onClose} 
                                            title={"알림"}
                                            msg={"입력하신 내용으로 수정 하시겠습니까?"} 
                                            onOk={onOk}  
                                        />
        })
    };

    return (
        <>
            <Form
            ref={formRef}
            checkTrigger="change"
            onChange={setFormValue}
            onCheck={setFormError}
            formValue={formValue}
            model={model}>
                  <CustomModal open={show} 
                    title={'프로그램(API) 상세/수정'}
                    size='md'
                    // handleOk={handleSubmit}
                    handleCancel={onHide} 
                >
             
                            <Table className="tbl-hor" bordered>
                                <colgroup>
                                    <col style={{width:'30%'}}></col>
                                    <col style={{width:''}}></col>
                                </colgroup>
                                <tbody>
                                    <tr>
                                        <th className="essen">API URL</th>
                                        <td>
                                            {data.apiUrl}
                                        </td>
                                    </tr>
                                    <tr>
                                        <th className="essen">API 설명</th>
                                        <td colSpan="3">
                                         <Form.Control name="apiNm" size="sm" type="text"/>  
                                        </td>
                                    </tr>
                                    <tr>
                                        <th className="essen">메뉴명</th>
                                        <td>
                                            <Form.Control name="menuId" size="sm" 
                                                placeholder={'선택'}
                                                accepter={SelectPicker} 
                                                searchable={false}
                                                cleanable={false}
                                                data={menuData && menuData}
                                                groupBy="group"
                                                renderMenuGroup={(label, item) => {
                                                    return (
                                                      <div>
                                                        <i className="rs-icon rs-icon-group" /> <strong>{label}</strong> - ({item.children.length}개)
                                                      </div>
                                                    );
                                                  }}
                                            ></Form.Control>
                                        </td>
                                    </tr>
                                    <tr>
                                        <th className="essen">API 타입</th>
                                        <td colSpan="3">
                                            <Form.Control name="method" size="sm" 
                                                placeholder={'선택'}
                                                accepter={SelectPicker} 
                                                searchable={false}
                                                cleanable={false}
                                                data={[
                                                    {label: 'GET', value: 'GET'},
                                                    {label: 'POST', value: 'POST'},
                                                ]}
                                                disabled={true}
                                            ></Form.Control>
                                        </td>
                                    </tr>
                                </tbody>
                            </Table>
                        
                        <div className='modal-footer'>
                            <Button variant="light" size="md" onClick={onHide}>취소</Button>
                            {isApi(API.apiMgmt, 'POST') &&  <Button variant="primary" size="md" onClick={handleSubmit} >저장</Button>}
                        </div> 
                </CustomModal>
            </Form>
        </>
    );

};
export default PgmUpdate;