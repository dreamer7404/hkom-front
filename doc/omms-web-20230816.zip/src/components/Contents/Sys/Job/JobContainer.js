import React from 'react';
import {Tab,Tabs} from 'react-bootstrap';

import BatchList from './BatchList';
import BatchHistory from './BatchHistory';
import { isApi } from '../../../../utils/commUtils';
import { API } from '../../../../utils/constants';
const JopContainer = () => {
    
    const [leftWidth, setLeftWidth] = React.useState('150px')
    React.useEffect(() => {
        const getTitle = document.getElementById('section-title-width');
        const titleWidth = getTitle.clientWidth + 40;
        setLeftWidth(titleWidth);
    }, []);

    return (
        <>
            <Tabs  defaultActiveKey="tab1" style={{left: leftWidth}} >
            {isApi(API.batchInfos, 'GET') &&   <Tab eventKey="tab1" title="BATCH정보">
                    <BatchList />
                </Tab>}
                {isApi(API.batchLogs, 'GET') &&<Tab eventKey="tab2" title="BATCH이력">
                   <BatchHistory />
                </Tab>}
            </Tabs>
        </>
    );

};
export default JopContainer;