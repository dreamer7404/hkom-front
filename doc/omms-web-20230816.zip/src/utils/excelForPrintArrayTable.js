//엑셀다운로드 테스트 김정웅
import * as ExcelJS from 'exceljs'
import { confirmAlert } from 'react-confirm-alert'; // Import
import ConfirmAlert from '../components/Common/ConfirmAlert';
import { formatNumber, escapeCharChange } from '../utils/commUtils';

const colDef = []
const rowData = [];
// 테두리 스타일 생성
const borderStyle = {
	style: 'thin',
	color: {
		argb: 'FF626262' // 테두리 색상 설정 (여기서는 검은색)
	}
};
const dataRowBorderStyle = {
	style: 'hair',
	color: {
		argb: 'A8A8A8' // 테두리 색상 설정 (여기서는 검은색)
	}
};

let pinnedBottomRowCount = 0


/**
 * @param {Array} rowData 컬럼수 대로 정리된 로우데이터
 * @param {Array} colDef 엑셀에서 사용될 헤더의 정보(agGrid의 columnDef의 양식과 같아야함)
 * @param {int} lastRowIndex 그리드 내 헤더의 로우길이
 * @param {String} fileName 파일명
 * @param {String} bottomFlag 테이블 내에서 pinnedBottomRow를 쓸경우 플래그 값(ex. 'TOTAL')
 * @param {Array} colSpan 테이블 내에서 colSpan 쓸경우 대상 컬럼의 값이 같은경우 colSpan처리한다. (ex. ['idxNm','wkYmd','dowNm'])
 * @param {Object} queryPrintOrderDetailResult2 인쇄배열표 상단에 추가되는 부가정보
 */
export const excelDownloadTable = (rowData, colDef, lastRowIndex, fileName, bottomFlag, colSpan, queryPrintOrderDetailResult2 ) => {
	// console.log(pinnedBottomRowCount)
	// console.log(colDef)
	// console.log(rowData)
	console.log(queryPrintOrderDetailResult2)

	return handleDownload(rowData, colDef, lastRowIndex, fileName, bottomFlag, colSpan, queryPrintOrderDetailResult2)
}

const cleanRowData = () => {
	rowData.splice(0)
	colDef.splice(0)
	left = 1;
	right = 0;
	bottom = 1;
	pinnedBottomRowCount=0;
}

const handleDownload = (rowData, columnDefs, lastRowIndex, fileName, bottomFlag, colSpan, queryPrintOrderDetailResult2) => {
	if(rowData.length <= 0){
		cleanRowData()
		confirmAlert({
			closeOnClickOutside: false,
			customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}  title={"알림"} msg={"조회된 데이터가 없습니다."}  />
		})
		return false
	}

	// Ag-Grid 데이터 가져오기
	const columns = processColumns(columnDefs);

	// 엑셀 파일 생성
	const workbook = new ExcelJS.Workbook();
	const worksheet = workbook.addWorksheet('Sheet 1');

	// 1:컬럼정보, 2.ExcelJS, 3.lastRowIndex
	mergeCells(columnDefs, worksheet, lastRowIndex)

	// 헤더 열 추가
	// addHeaderColumns(worksheet, columns);
	// 데이터 행 추가
	addDataRows(worksheet, columns, rowData, lastRowIndex, bottomFlag, colSpan, fileName);

	//인쇄배열표 상단에 부가정보 삽입 시작
	worksheet.getCell(1, 1).value = '인쇄배열표';
	worksheet.getCell(1, 1).font = { size: 15}; 
	worksheet.getCell(1, 1).alignment = { horizontal: 'left', vertical: 'middle',  wrapText: true };
	// top, left, bottom, right
	worksheet.mergeCells(1,1,1,28)
	console.log(queryPrintOrderDetailResult2)

	worksheet.getCell(2, 1).value = escapeCharChange(queryPrintOrderDetailResult2.data.row1);
	worksheet.getCell(2, 1).font = { size: 10}; 
	worksheet.getCell(2, 1).alignment = { horizontal: 'left', vertical: 'middle',  wrapText: true };
	worksheet.mergeCells(2,1,2,28)

	worksheet.getCell(3, 1).value = escapeCharChange(queryPrintOrderDetailResult2.data.row2);
	worksheet.getCell(3, 1).font = { size: 10}; 
	worksheet.getCell(3, 1).alignment = { horizontal: 'left', vertical: 'middle',  wrapText: true };
	worksheet.mergeCells(3,1,3,28)

	worksheet.getCell(4, 1).value = '인쇄부수: '+formatNumber(escapeCharChange(queryPrintOrderDetailResult2.data.row3));
	worksheet.getCell(4, 1).font = { size: 10}; 
	worksheet.getCell(4, 1).alignment = { horizontal: 'left', vertical: 'middle',  wrapText: true };
	worksheet.mergeCells(4,1,4,28)

	worksheet.getCell(5, 1).value = escapeCharChange(queryPrintOrderDetailResult2.data.row4).replace(/\n/g, " ");;
	worksheet.getCell(5, 1).font = { size: 10}; 
	worksheet.getCell(5, 1).alignment = { horizontal: 'left', vertical: 'middle',  wrapText: true };
	worksheet.mergeCells(5,1,5,28)
	//인쇄배열표 상단에 부가정보 삽입 끝
	
	
	//엑셀 파일 다운로드
	workbook.xlsx.writeBuffer().then((buffer) => {
		const blob = new Blob([buffer], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
		const url = URL.createObjectURL(blob);
		const link = document.createElement('a');
		link.href = url;
		link.download = fileName + '.xlsx';
		link.click();
		URL.revokeObjectURL(url);
	})
	.catch((error) => {
		console.error('엑셀 파일 생성 중 오류가 발생했습니다:', error);
	})
	.finally(() => {
		cleanRowData()
		return false
	})
};

const processColumns = (columns) => {
	const processedColumns = [];
	columns.forEach((column) => {
		if(column.headerName){ //체크박스가 아닌경우만 처리한다.
			if (column.children) {
				processedColumns.push(...processColumns(column.children));
			} else {
				processedColumns.push(column);
			}
		}
	});
	return processedColumns;
};

// const addHeaderColumns = (worksheet, columns) => {
//     columns.forEach((column, index) => {
//         // worksheet.getCell(1, index + 1).value = column.headerName;
//         worksheet.getCell(1, index + 1).value = {
//             richText: [{ text: column.headerName, font: { size: 10, bold:true } }],
//         }
//     });
// };

const addDataRows = (worksheet, columns, rowData, lastRowIndex, bottomFlag, colSpan, fileName) => {
	
	//rowSpan이 있는 컬럼 찾기 시작
	let rowSpanCol = [];
	columns.forEach(col => {
		if(col.rowSpan){
			rowSpanCol.push(col.field)
		}
	})
	//rowSpan이 있는 컬럼 찾기 끝
	
	rowData.forEach((row, rowIndex) => {
		rowIndex+=5  //인쇄배열표 상단에 정보 추가를 위한.... +5
		//row 배경색 칠해주기..
		let backGroundColor = false
		if((lastRowIndex+rowIndex) % 2 === 0){
			backGroundColor = true
		}

		//row별 flag 값 찾기 시작
		let flag = 0
		if(row.flag) {
			if(row.flag !== 1){
				flag = parseInt(row.flag, 10) //간혹 flag값이 String인 경우가 있어서 처리해준다...(ex. "3")
			}
		}

		let rowSpanCheck = false
		if ((rowIndex-5+flag) % flag === 0){
			rowSpanCheck =  true
		}
		
		// pinnedBottomRow가 있는경우 colSpan해줄 컬럼의 수를 카운트 한다.
		let pinnedBottomRowColSpan = 0;
		// pinnedBottomRow가 있고, rowSpan까지 사용할 경우 데이터를 마지막 row까지 그린 후에 merge를 진행한다.
		let pinnedBottomRowStartRowIndex = 0;
		let pinnedBottomRowEndRowIndex = 0;
		//colSpan을 사용한경우 colSpan 의 시작점을 할당.
		let colSpanStart = 0;
		let colSpanDatas = []; //해당 row의 colSpan 대상 컬럼의 값을 담아놓고 중복제거하여 제거한 값이 1인경우만 컬럼을 합친다.
		let colSpanEnd = 0;
		

		//row별 flag 값 찾기 끝
		columns.forEach((column, colIndex) => {
			if(!column.checkboxSelection) {
				let value = row[column.field];

				if(fileName === '월간투입현황' && column.cellRenderer && column.field.indexOf('col') !== -1){ //월간투입현황을 위한 작업..
					let params = {data:row}
					value = column.cellRenderer(params)
				}
				
				if(column.aggFunc){ //해당 그리드에서 사용된 colDef에 커스텀펑션이 있는경우, 해당 CellValue를 펑션을 사용하여 파싱한다.
					value = column.aggFunc(value)
				}

				if(column.valueGetter){
					let params = {data:row, colDef:column} //colDef는 '법규 및 변경관리'목록에서 'X' 그릴때 필요하기때문에 필수로 넣어준다.. 다른 화면에서 문제발생시 분기 처리 필요..
					value = column.valueGetter(params)
				}
				
				if(column.valueFormatter){
					if(column.valueFormatter.name === 'currencyFormatter' && value !== bottomFlag){
						value = formatNumber(value)
					}
				} else if (value && value.length > 0) {
					value = escapeCharChange(value)
				}

				worksheet.getCell(rowIndex + lastRowIndex +1, colIndex + 1).value = value;

				if(rowData.length+5 <= (pinnedBottomRowCount+rowIndex)){
					// worksheet.getCell(rowIndex + lastRowIndex +1, colIndex + 1).font = { size: 10, bold: true };
					// worksheet.getCell(rowIndex + lastRowIndex +1, colIndex + 1).alignment = { horizontal: 'center', vertical: 'middle',  wrapText: true };
					// worksheet.getCell(rowIndex + lastRowIndex +1, colIndex + 1).fill = {
					// 	type: 'pattern',
					// 	pattern: 'solid',
					// 	fgColor: { argb: 'f8f8f8' },
					// };
					// worksheet.getCell(rowIndex + lastRowIndex +1, colIndex + 1).border = {
					// 	top: borderStyle,
					// 	left: borderStyle,
					// 	bottom: borderStyle,
					// 	right: borderStyle
					// };
					// // pinnedBottomRow가 있는경우, bottomFlag와 colField가 같을경우 colSpan해줄 컬럼의 수 더해준다.
					// if(value === bottomFlag){
					// 	pinnedBottomRowColSpan ++
					// }
				} else {
					
						if(colSpan && colSpan.length > 0 && colSpan.includes(column.field)){ //현재 작업하는 컬럼이 colSpan 대상 컬럼인 경우 
							colSpanDatas.push(value)

							if(colSpanStart > colIndex){
								colSpanStart = (colIndex+1);
							}
						}
					
						worksheet.getCell(rowIndex + lastRowIndex +1, colIndex + 1).font = { size: 9}; 
						worksheet.getCell(rowIndex + lastRowIndex +1, colIndex + 1).alignment = { horizontal: 'center', vertical: 'middle',  wrapText: true };					
						worksheet.getCell(rowIndex + lastRowIndex +1, colIndex + 1).border = {
							top: dataRowBorderStyle,
							left: dataRowBorderStyle,
							bottom: dataRowBorderStyle,
							right: dataRowBorderStyle
						};
						if(backGroundColor){ //데이터 row의 경우 짝수행에 색칠해준다..
							worksheet.getCell(rowIndex + lastRowIndex +1, colIndex + 1).fill = {
								type: 'pattern',
								pattern: 'solid',
								fgColor: { argb: 'F9F9F9' },
							};
						}
					
				}

				if(rowSpanCol.length > 0){ //rowSpan을 해야하는 경우

					if(rowSpanCol.includes(column.field) && rowSpanCheck){
						if(pinnedBottomRowColSpan === 0){
							// top, left, bottom, right
							worksheet.mergeCells((rowIndex+1 + lastRowIndex),(colIndex+1),(rowIndex + lastRowIndex + flag),(colIndex+1 + pinnedBottomRowColSpan))
							
							pinnedBottomRowStartRowIndex = (rowIndex+1 + lastRowIndex)
							pinnedBottomRowEndRowIndex = (rowIndex + lastRowIndex + flag)
						}
					} else {
						if(pinnedBottomRowColSpan === 1 && pinnedBottomRowStartRowIndex === 0){
							pinnedBottomRowStartRowIndex = (rowIndex + lastRowIndex + flag)
						} else {
							pinnedBottomRowEndRowIndex = (rowIndex + lastRowIndex +1)
						}
					}

				} else { //rowSpan이 필요없는 경우
					if(pinnedBottomRowColSpan === 1 && pinnedBottomRowStartRowIndex === 0){
						pinnedBottomRowStartRowIndex = (rowIndex+ 1 + lastRowIndex + flag)
					} else {
						pinnedBottomRowEndRowIndex = (rowIndex+1 + lastRowIndex + flag )
					}
				}
			}
		}); // col forEach 끝

		//pinnedBottomRow 의 rowSpan과 colSpan을 처리해준다.
		if(pinnedBottomRowColSpan !== 0 && rowData.length === (rowIndex+1)){
			// top, left, bottom, right
			worksheet.mergeCells(pinnedBottomRowStartRowIndex, 1, pinnedBottomRowEndRowIndex, pinnedBottomRowColSpan)
		}



		//데이터Row에 사용된 colSpan을 처리해준다.
		const  findMaxDuplicateCount = (colSpanDatas) => {
			var duplicates = {};
			var maxDuplicateCount = 0;
		  
			colSpanDatas.forEach(item => {
				duplicates[item] = (duplicates[item] || 0) + 1;
				if (duplicates[item] > maxDuplicateCount) {
				maxDuplicateCount = duplicates[item];
				}
			});
		  
			return maxDuplicateCount;
		}
		if(colSpan && colSpan.length > 0 && colSpan.length === findMaxDuplicateCount(colSpanDatas)){
			// top, left, bottom, right
			// console.log((rowIndex + lastRowIndex +1), (colSpanStart+1), (rowIndex + lastRowIndex +1), (colSpanStart+colSpan.length))
			worksheet.mergeCells((rowIndex + lastRowIndex +1), (colSpanStart+1), (rowIndex + lastRowIndex +1), (colSpanStart+colSpan.length))
		}

	}); // row forEach 끝
};

// ExcelJS를 사용하여 셀 병합을 처리하는 함수
let left = 1;
let right = 0;
let bottom = 1;
const mergeCells = (columnDefs, worksheet, lastRowIndex, top) => {
	
	for(let i=0; i<columnDefs.length; i++){
		if(!top) top = 1

		let item = columnDefs[i]
		if(item.checkboxSelection) {
			continue;
		}
		
		if(!item.children){
			// console.log('children', item.headerName, 'left: '+left, 'right: '+left, 'top: '+top, 'bottom: '+lastRowIndex)
			makeCell(top+5, left, lastRowIndex+5, left, item.headerName, worksheet) //인쇄배열표 상단에 정보 추가를 위한.... +5임..
			left++

		} else {
			right += item.children.length
			let colChildArr = processColumns(item.children)
			makeCell(top, left, top, (colChildArr.length+left-1), item.headerName, worksheet)
			top++
			right += mergeCells(item.children+5, worksheet, lastRowIndex+5, top, left, bottom, right) //인쇄배열표 상단에 정보 추가를 위한.... +5임..
			top--
			right = 0
			
		}
		if(!top) top = 1
	}

	return right

}

const makeCell = (top, left, bottom, right, headerName, worksheet) => {
	// top, left, bottom, right
	worksheet.mergeCells(top,left,bottom,right);
	//row, col
	worksheet.getCell(top,left).value = headerName;
	worksheet.getCell(top,left).font = { size: 10, bold: true };
	worksheet.getCell(top,left).alignment = { horizontal: 'center', vertical: 'middle',  wrapText: true };
	worksheet.getCell(top,left).fill = {
		type: 'pattern',
		pattern: 'solid',
		fgColor: { argb: 'f8f8f8' },
	};
	
	worksheet.getCell(top,left).border = {
		top: borderStyle,
		left: borderStyle,
		bottom: borderStyle,
		right: borderStyle
	};
}

// 엑셀 다운로드 끝.. 나중에 공통으로 빼자.