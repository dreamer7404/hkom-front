//엑셀다운로드 테스트 김정웅
import * as ExcelJS from 'exceljs'
import { confirmAlert } from 'react-confirm-alert'; // Import
import ConfirmAlert from '../components/Common/ConfirmAlert';
import { formatNumber, escapeCharChange } from '../utils/commUtils';

export const excelDownloadTable = (data) => {
	const workbook = new ExcelJS.Workbook();
        const worksheet = workbook.addWorksheet('Sheet1');

        // 테두리 스타일 생성
        const borderStyle = {
            style: 'thin',
            color: {
                argb: 'FF626262' // 테두리 색상 설정 (여기서는 검은색)
            }
        };
        const dataRowBorderStyle = {
            style: 'hair',
            color: {
                argb: 'A8A8A8' // 테두리 색상 설정 (여기서는 검은색)
            }
        };

        worksheet.getColumn(1).width = 20;
        worksheet.getColumn(2).width = 20;
        worksheet.getColumn(3).width = 35;
        worksheet.getColumn(4).width = 20;
        worksheet.getColumn(5).width = 20;
        worksheet.getColumn(6).width = 35;
        

        /* ------------------------------ 1 Row ----------------------------------- */
        // top, left, bottom, right
        worksheet.mergeCells(1,1,1,2);
        //row, col
        worksheet.getCell(1,1).value = '차종';
        worksheet.getCell(1,1).font = { size: 10, bold: true };
        worksheet.getCell(1,1).alignment = { horizontal: 'center' };
        worksheet.getCell(1,1).fill = {type: 'pattern',pattern: 'solid',fgColor: { argb: 'f8f8f8' },};
        worksheet.getCell(1,1).border = { top: borderStyle, left: borderStyle, bottom: borderStyle, right: borderStyle};

        //row, col
        worksheet.getCell(1,3).value = data &&escapeCharChange( data.qltyVehlNm);
        worksheet.getCell(1,3).font = { size: 10 };
        worksheet.getCell(1,3).alignment = { horizontal: 'center' };
        worksheet.getCell(1,3).border = { top: dataRowBorderStyle, left: dataRowBorderStyle, bottom: dataRowBorderStyle, right: dataRowBorderStyle};

        // top, left, bottom, right
        worksheet.mergeCells(1,4,1,5);
        //row, col
        worksheet.getCell(1,5).value = '언어';
        worksheet.getCell(1,5).font = { size: 10, bold: true };
        worksheet.getCell(1,5).alignment = { horizontal: 'center' };
        worksheet.getCell(1,5).fill = {type: 'pattern',pattern: 'solid',fgColor: { argb: 'f8f8f8' },};
        worksheet.getCell(1,5).border = { top: borderStyle, left: borderStyle, bottom: borderStyle, right: borderStyle};
        
        //row, col
        worksheet.getCell(1,6).value = data &&escapeCharChange( data.langCdNm)
        worksheet.getCell(1,6).font = { size: 10 };
        worksheet.getCell(1,6).alignment = { horizontal: 'center' };
        worksheet.getCell(1,6).border = { top: dataRowBorderStyle, left: dataRowBorderStyle, bottom: dataRowBorderStyle, right: dataRowBorderStyle};
        
        /* ------------------------------ 2 Row ----------------------------------- */
        // top, left, bottom, right
        worksheet.mergeCells(2,1,2,2);
        //row, col
        worksheet.getCell(2,1).value = '인쇄부수';
        worksheet.getCell(2,1).font = { size: 10, bold: true };
        worksheet.getCell(2,1).alignment = { horizontal: 'center' };
        worksheet.getCell(2,1).fill = {type: 'pattern',pattern: 'solid',fgColor: { argb: 'f8f8f8' },};
        worksheet.getCell(2,1).border = { top: borderStyle, left: borderStyle, bottom: borderStyle, right: borderStyle};

        //row, col
        worksheet.getCell(2,3).value = data && formatNumber(data.rqQty)
        worksheet.getCell(2,3).font = { size: 10 };
        worksheet.getCell(2,3).alignment = { horizontal: 'center' };
        worksheet.getCell(2,3).border = { top: dataRowBorderStyle, left: dataRowBorderStyle, bottom: dataRowBorderStyle, right: dataRowBorderStyle};

        // top, left, bottom, right
        worksheet.mergeCells(2,4,5,4);
        //row, col
        worksheet.getCell(2,4).value = '인쇄페이지';
        worksheet.getCell(2,4).font = { size: 10, bold: true };
        worksheet.getCell(2,4).alignment = { horizontal: 'center', vertical: 'middle', wrapText: true };
        worksheet.getCell(2,4).fill = {type: 'pattern',pattern: 'solid',fgColor: { argb: 'f8f8f8' },};
        worksheet.getCell(2,4).border = { top: borderStyle, left: borderStyle, bottom: borderStyle, right: borderStyle};
        
        //row, col
        worksheet.getCell(2,5).value = '총페이지'
        worksheet.getCell(2,5).font = { size: 10, bold: true };
        worksheet.getCell(2,5).alignment = { horizontal: 'center' };
        worksheet.getCell(2,5).fill = {type: 'pattern',pattern: 'solid',fgColor: { argb: 'f8f8f8' },};
        worksheet.getCell(2,5).border = { top: borderStyle, left: borderStyle, bottom: borderStyle, right: borderStyle};
        //row, col
        worksheet.getCell(2,6).value = data && data.pgNl
        worksheet.getCell(2,6).font = { size: 10 };
        worksheet.getCell(2,6).alignment = { horizontal: 'center' };
        worksheet.getCell(2,6).border = { top: dataRowBorderStyle, left: dataRowBorderStyle, bottom: dataRowBorderStyle, right: dataRowBorderStyle};

        /* ------------------------------ 3 Row ----------------------------------- */
        // top, left, bottom, right
        worksheet.mergeCells(3,1,4,1);
        //row, col
        worksheet.getCell(3,1).value = '납품';
        worksheet.getCell(3,1).font = { size: 10, bold: true };
        worksheet.getCell(3,1).alignment = { horizontal: 'center', vertical: 'middle', wrapText: true  };
        worksheet.getCell(3,1).fill = {type: 'pattern',pattern: 'solid',fgColor: { argb: 'f8f8f8' },};
        worksheet.getCell(3,1).border = { top: borderStyle, left: borderStyle, bottom: borderStyle, right: borderStyle};

        //row, col
        worksheet.getCell(3,2).value = '납품일';
        worksheet.getCell(3,2).font = { size: 10, bold: true };
        worksheet.getCell(3,2).alignment = { horizontal: 'center', vertical: 'middle', wrapText: true  };
        worksheet.getCell(3,2).fill = {type: 'pattern',pattern: 'solid',fgColor: { argb: 'f8f8f8' },};
        worksheet.getCell(3,2).border = { top: borderStyle, left: borderStyle, bottom: borderStyle, right: borderStyle};

        //row, col
        worksheet.getCell(3,3).value = data && data.dlvgParrYmd
        worksheet.getCell(3,3).font = { size: 10 };
        worksheet.getCell(3,3).alignment = { horizontal: 'center', vertical: 'middle', wrapText: true  };
        worksheet.getCell(3,3).border = { top: dataRowBorderStyle, left: dataRowBorderStyle, bottom: dataRowBorderStyle, right: dataRowBorderStyle};

        //row, col
        worksheet.getCell(3,5).value = '표지';
        worksheet.getCell(3,5).font = { size: 10, bold: true };
        worksheet.getCell(3,5).alignment = { horizontal: 'center'};
        worksheet.getCell(3,5).fill = {type: 'pattern',pattern: 'solid',fgColor: { argb: 'f8f8f8' },};
        worksheet.getCell(3,5).border = { top: borderStyle, left: borderStyle, bottom: borderStyle, right: borderStyle};

        //row, col
        worksheet.getCell(3,6).value = data && data.prntWayCd2=='04' || data &&data.prntWayCd2=='05' || data &&data.prntWayCd2=='06' || data &&data.prntWayCd2=='07'?  "0" : "4"
        worksheet.getCell(3,6).font = { size: 10};
        worksheet.getCell(3,6).alignment = { horizontal: 'center'};
        worksheet.getCell(3,6).border = { top: dataRowBorderStyle, left: dataRowBorderStyle, bottom: dataRowBorderStyle, right: dataRowBorderStyle};

        /* ------------------------------ 4 Row ----------------------------------- */
        //row, col
        worksheet.getCell(4,2).value = '발주일';
        worksheet.getCell(4,2).font = { size: 10, bold: true };
        worksheet.getCell(4,2).alignment = { horizontal: 'center', vertical: 'middle', wrapText: true  };
        worksheet.getCell(4,2).fill = {type: 'pattern',pattern: 'solid',fgColor: { argb: 'f8f8f8' },};
        worksheet.getCell(4,2).border = { top: borderStyle, left: borderStyle, bottom: borderStyle, right: borderStyle};

        //row, col
        worksheet.getCell(4,3).value = data && data.ordnRqstYmd
        worksheet.getCell(4,3).font = { size: 10 };
        worksheet.getCell(4,3).alignment = { horizontal: 'center', vertical: 'middle', wrapText: true  };

        //row, col
        worksheet.getCell(4,5).value = '설명서';
        worksheet.getCell(4,5).font = { size: 10, bold: true };
        worksheet.getCell(4,5).alignment = { horizontal: 'center'};
        worksheet.getCell(4,5).fill = {type: 'pattern',pattern: 'solid',fgColor: { argb: 'f8f8f8' },};
        worksheet.getCell(4,5).border = { top: borderStyle, left: borderStyle, bottom: borderStyle, right: borderStyle};

        //row, col
        worksheet.getCell(4,6).value = data && data.expdNl
        worksheet.getCell(4,6).font = { size: 10};
        worksheet.getCell(4,6).alignment = { horizontal: 'center'};

        /* ------------------------------ 5 Row ----------------------------------- */
        // top, left, bottom, right
        worksheet.mergeCells(5,1,6,1);
        //row, col
        worksheet.getCell(5,1).value = '발간번호';
        worksheet.getCell(5,1).font = { size: 10, bold: true };
        worksheet.getCell(5,1).alignment = { horizontal: 'center', vertical: 'middle', wrapText: true};
        worksheet.getCell(5,1).fill = {type: 'pattern',pattern: 'solid',fgColor: { argb: 'f8f8f8' },};
        worksheet.getCell(5,1).border = { top: borderStyle, left: borderStyle, bottom: borderStyle, right: borderStyle};

        //row, col
        worksheet.getCell(5,2).value = '신규번호';
        worksheet.getCell(5,2).font = { size: 10, bold: true };
        worksheet.getCell(5,2).alignment = { horizontal: 'center'};
        worksheet.getCell(5,2).fill = {type: 'pattern',pattern: 'solid',fgColor: { argb: 'f8f8f8' },};
        worksheet.getCell(5,2).border = { top: borderStyle, left: borderStyle, bottom: borderStyle, right: borderStyle};
        //row, col
        worksheet.getCell(5,3).value = data && escapeCharChange(data.newPrntPbcnNo);
        worksheet.getCell(5,3).font = { size: 10};
        worksheet.getCell(5,3).alignment = { horizontal: 'center'};
        worksheet.getCell(5,3).border = { top: dataRowBorderStyle, left: dataRowBorderStyle, bottom: dataRowBorderStyle, right: dataRowBorderStyle};

        //row, col
        worksheet.getCell(5,5).value = '보증서/엽서';
        worksheet.getCell(5,5).font = { size: 10, bold: true };
        worksheet.getCell(5,5).alignment = { horizontal: 'center'};
        worksheet.getCell(5,5).fill = {type: 'pattern',pattern: 'solid',fgColor: { argb: 'f8f8f8' },};
        worksheet.getCell(5,5).border = { top: borderStyle, left: borderStyle, bottom: borderStyle, right: borderStyle};

        //row, col
        worksheet.getCell(5,6).value = data && data.grnDocNl;
        worksheet.getCell(5,6).font = { size: 10};
        worksheet.getCell(5,6).alignment = { horizontal: 'center'};

        /* ------------------------------ 6 Row ----------------------------------- */
        //row, col
        worksheet.getCell(6,2).value = '기존번호';
        worksheet.getCell(6,2).font = { size: 10, bold: true };
        worksheet.getCell(6,2).alignment = { horizontal: 'center'};
        worksheet.getCell(6,2).fill = {type: 'pattern',pattern: 'solid',fgColor: { argb: 'f8f8f8' },};
        worksheet.getCell(6,2).border = { top: borderStyle, left: borderStyle, bottom: borderStyle, right: borderStyle};

        //row, col
        worksheet.getCell(6,3).value = data && escapeCharChange(data.oldPrntPbcnNo);
        worksheet.getCell(6,3).font = { size: 10 };
        worksheet.getCell(6,3).alignment = { horizontal: 'center'};
        worksheet.getCell(6,3).border = { top: dataRowBorderStyle, left: dataRowBorderStyle, bottom: dataRowBorderStyle, right: dataRowBorderStyle};

        // top, left, bottom, right
        worksheet.mergeCells(6,4,7,4);
        //row, col
        worksheet.getCell(6,4).value = '옵셋(내지)';
        worksheet.getCell(6,4).font = { size: 10, bold: true };
        worksheet.getCell(6,4).alignment = { horizontal: 'center', vertical: 'middle', wrapText: true};
        worksheet.getCell(6,4).fill = {type: 'pattern',pattern: 'solid',fgColor: { argb: 'f8f8f8' },};
        worksheet.getCell(6,4).border = { top: borderStyle, left: borderStyle, bottom: borderStyle, right: borderStyle};
        //row, col
        worksheet.getCell(6,5).value = '기존필름이용';
        worksheet.getCell(6,5).font = { size: 10, bold: true  };
        worksheet.getCell(6,5).alignment = { horizontal: 'center'};
        worksheet.getCell(6,5).fill = {type: 'pattern',pattern: 'solid',fgColor: { argb: 'f8f8f8' },};
        worksheet.getCell(6,5).border = { top: borderStyle, left: borderStyle, bottom: borderStyle, right: borderStyle};
        //row, col
        worksheet.getCell(6,6).value = data && data.prntWayCd2=='01' || data &&data.prntWayCd2=='02' || data &&data.prntWayCd2=='08'? (data && data.eofu1Nl==null? 0:data.eofu1Nl) : "0";
        worksheet.getCell(6,6).font = { size: 10};
        worksheet.getCell(6,6).alignment = { horizontal: 'center'};
        worksheet.getCell(6,6).border = { top: dataRowBorderStyle, left: dataRowBorderStyle, bottom: dataRowBorderStyle, right: dataRowBorderStyle};

        /* ------------------------------ 7 Row ----------------------------------- */
        // top, left, bottom, right
        worksheet.mergeCells(7,1,7,2);
        //row, col
        worksheet.getCell(7,2).value = '발행방법';
        worksheet.getCell(7,2).font = { size: 10, bold: true };
        worksheet.getCell(7,2).alignment = { horizontal: 'center'};
        worksheet.getCell(7,2).fill = {type: 'pattern',pattern: 'solid',fgColor: { argb: 'f8f8f8' },};
        worksheet.getCell(7,2).border = { top: borderStyle, left: borderStyle, bottom: borderStyle, right: borderStyle};
        //row, col
        worksheet.getCell(7,3).value = data && data.iwayNm;
        worksheet.getCell(7,3).font = { size: 10 };
        worksheet.getCell(7,3).alignment = { horizontal: 'center'};
        worksheet.getCell(7,3).border = { top: dataRowBorderStyle, left: dataRowBorderStyle, bottom: dataRowBorderStyle, right: dataRowBorderStyle};
        //row, col
        worksheet.getCell(7,5).value = '신규필름제작(교정포함)';
        worksheet.getCell(7,5).font = { size: 10, bold: true  };
        worksheet.getCell(7,5).alignment = { horizontal: 'center'};
        worksheet.getCell(7,5).fill = {type: 'pattern',pattern: 'solid',fgColor: { argb: 'f8f8f8' },};
        worksheet.getCell(7,5).border = { top: borderStyle, left: borderStyle, bottom: borderStyle, right: borderStyle};
        //row, col
        worksheet.getCell(7,6).value = data && data.prntWayCd2=='01' || data &&data.prntWayCd2=='02' || data &&data.prntWayCd2=='08'?data && data.nrFlmMkoNl:'0' ;
        worksheet.getCell(7,6).font = { size: 10};
        worksheet.getCell(7,6).alignment = { horizontal: 'center'};
        worksheet.getCell(7,6).border = { top: dataRowBorderStyle, left: dataRowBorderStyle, bottom: dataRowBorderStyle, right: dataRowBorderStyle};

        /* ------------------------------ 8 Row ----------------------------------- */
        // top, left, bottom, right
        worksheet.mergeCells(8,1,8,2);
        //row, col
        worksheet.getCell(8,1).value = '제본';
        worksheet.getCell(8,1).font = { size: 10, bold: true };
        worksheet.getCell(8,1).alignment = { horizontal: 'center'};
        worksheet.getCell(8,1).fill = {type: 'pattern',pattern: 'solid',fgColor: { argb: 'f8f8f8' },};
        worksheet.getCell(8,1).border = { top: borderStyle, left: borderStyle, bottom: borderStyle, right: borderStyle};
        //row, col
        worksheet.getCell(8,3).value = data && data.prntWayCd2=='04' || data &&data.prntWayCd2=='05' || data &&data.prntWayCd2=='06' || data &&data.prntWayCd2=='07'?  "" : "무선제본";
        worksheet.getCell(8,3).font = { size: 10};
        worksheet.getCell(8,3).alignment = { horizontal: 'center'};
        worksheet.getCell(8,3).border = { top: dataRowBorderStyle, left: dataRowBorderStyle, bottom: dataRowBorderStyle, right: dataRowBorderStyle};
        //row, col
        worksheet.getCell(8,4).value = '디지털(내지)';
        worksheet.getCell(8,4).font = { size: 10, bold: true };
        worksheet.getCell(8,4).alignment = { horizontal: 'center'};
        worksheet.getCell(8,4).fill = {type: 'pattern',pattern: 'solid',fgColor: { argb: 'f8f8f8' },};
        worksheet.getCell(8,4).border = { top: borderStyle, left: borderStyle, bottom: borderStyle, right: borderStyle};
        //row, col
        worksheet.getCell(8,5).value = '디지털 인쇄';
        worksheet.getCell(8,5).font = { size: 10, bold: true };
        worksheet.getCell(8,5).alignment = { horizontal: 'center'};
        worksheet.getCell(8,5).fill = {type: 'pattern',pattern: 'solid',fgColor: { argb: 'f8f8f8' },};
        worksheet.getCell(8,5).border = { top: borderStyle, left: borderStyle, bottom: borderStyle, right: borderStyle};
        //row, col
        worksheet.getCell(8,6).value = data && data.prntWayCd2=='01' || data &&data.prntWayCd2=='02' || data &&data.prntWayCd2=='08'?'0':data &&data.nrFlmMkoNl;
        worksheet.getCell(8,6).font = { size: 10 };
        worksheet.getCell(8,6).alignment = { horizontal: 'center'};
        worksheet.getCell(8,6).border = { top: dataRowBorderStyle, left: dataRowBorderStyle, bottom: dataRowBorderStyle, right: dataRowBorderStyle};

        /* ------------------------------ 9 Row ----------------------------------- */
        // top, left, bottom, right
        worksheet.mergeCells(9,1,9,2);
        //row, col
        worksheet.getCell(9,1).value = '규격';
        worksheet.getCell(9,1).font = { size: 10, bold: true };
        worksheet.getCell(9,1).alignment = { horizontal: 'center'};
        worksheet.getCell(9,1).fill = {type: 'pattern',pattern: 'solid',fgColor: { argb: 'f8f8f8' },};
        worksheet.getCell(9,1).border = { top: borderStyle, left: borderStyle, bottom: borderStyle, right: borderStyle};
        //row, col
        worksheet.getCell(9,3).value = data && escapeCharChange(data.pgMgnSbc);
        worksheet.getCell(9,3).font = { size: 10};
        worksheet.getCell(9,3).alignment = { horizontal: 'center'};
        worksheet.getCell(9,3).border = { top: dataRowBorderStyle, left: dataRowBorderStyle, bottom: dataRowBorderStyle, right: dataRowBorderStyle};
        // top, left, bottom, right
        worksheet.mergeCells(9,4,9,5);
        //row, col
        worksheet.getCell(9,4).value = '외주편집페이지';
        worksheet.getCell(9,4).font = { size: 10, bold: true };
        worksheet.getCell(9,4).alignment = { horizontal: 'center'};
        worksheet.getCell(9,4).fill = {type: 'pattern',pattern: 'solid',fgColor: { argb: 'f8f8f8' },};
        worksheet.getCell(9,4).border = { top: borderStyle, left: borderStyle, bottom: borderStyle, right: borderStyle};
        //row, col
        worksheet.getCell(9,6).value = data && data.oordEditPgNl;
        worksheet.getCell(9,6).font = { size: 10};
        worksheet.getCell(9,6).alignment = { horizontal: 'center'};
        worksheet.getCell(9,6).border = { top: dataRowBorderStyle, left: dataRowBorderStyle, bottom: dataRowBorderStyle, right: dataRowBorderStyle};
        
        /* ------------------------------ 10 Row ----------------------------------- */
        // top, left, bottom, right
        worksheet.mergeCells(10,1,11,1);
        //row, col
        worksheet.getCell(10,1).value = '지질';
        worksheet.getCell(10,1).font = { size: 10, bold: true };
        worksheet.getCell(10,1).alignment = { horizontal: 'center', vertical: 'middle', wrapText: true};
        worksheet.getCell(10,1).fill = {type: 'pattern',pattern: 'solid',fgColor: { argb: 'f8f8f8' },};
        worksheet.getCell(10,1).border = { top: borderStyle, left: borderStyle, bottom: borderStyle, right: borderStyle};
        //row, col
        worksheet.getCell(10,2).value = '표지';
        worksheet.getCell(10,2).font = { size: 10, bold: true };
        worksheet.getCell(10,2).alignment = { horizontal: 'center'};
        worksheet.getCell(10,2).fill = {type: 'pattern',pattern: 'solid',fgColor: { argb: 'f8f8f8' },};
        worksheet.getCell(10,2).border = { top: borderStyle, left: borderStyle, bottom: borderStyle, right: borderStyle};
        //row, col
        worksheet.getCell(10,3).value = data && data.prntWayCd2=='04' || data &&data.prntWayCd2=='05' || data &&data.prntWayCd2=='06' || data &&data.prntWayCd2=='07'?   '' : '250아트'
        worksheet.getCell(10,3).font = { size: 10 };
        worksheet.getCell(10,3).alignment = { horizontal: 'center'};
        worksheet.getCell(10,3).border = { top: dataRowBorderStyle, left: dataRowBorderStyle, bottom: dataRowBorderStyle, right: dataRowBorderStyle};
        // top, left, bottom, right
        worksheet.mergeCells(10,4,10,5);
        //row, col
        worksheet.getCell(10,4).value = '외주편집업체';
        worksheet.getCell(10,4).font = { size: 10, bold: true };
        worksheet.getCell(10,4).alignment = { horizontal: 'center'};
        worksheet.getCell(10,4).fill = {type: 'pattern',pattern: 'solid',fgColor: { argb: 'f8f8f8' },};
        worksheet.getCell(10,4).border = { top: borderStyle, left: borderStyle, bottom: borderStyle, right: borderStyle};
        //row, col
        worksheet.getCell(10,6).value = data && data.oordEditCoCd=='01'? 'TLA'
        :data && data.oordEditCoCd=='02'? 'AST'
        :data && data.oordEditCoCd=='03'? 'FEEL'
        :data && data.oordEditCoCd=='04'? 'TEXTREE':'없음';
        worksheet.getCell(10,6).font = { size: 10 };
        worksheet.getCell(10,6).alignment = { horizontal: 'center'};
        worksheet.getCell(10,6).border = { top: dataRowBorderStyle, left: dataRowBorderStyle, bottom: dataRowBorderStyle, right: dataRowBorderStyle};

        /* ------------------------------ 11 Row ----------------------------------- */
        //row, col
        worksheet.getCell(11,2).value = '내지';
        worksheet.getCell(11,2).font = { size: 10, bold: true };
        worksheet.getCell(11,2).alignment = { horizontal: 'center'};
        worksheet.getCell(11,2).fill = {type: 'pattern',pattern: 'solid',fgColor: { argb: 'f8f8f8' },};
        worksheet.getCell(11,2).border = { top: borderStyle, left: borderStyle, bottom: borderStyle, right: borderStyle};
        //row, col
        worksheet.getCell(11,3).value = data && data.deipq1Sbc=='01'? '80화인코드지':'70모조지';
        worksheet.getCell(11,3).font = { size: 10 };
        worksheet.getCell(11,3).alignment = { horizontal: 'center'};
        worksheet.getCell(11,3).border = { top: dataRowBorderStyle, left: dataRowBorderStyle, bottom: dataRowBorderStyle, right: dataRowBorderStyle};
        // top, left, bottom, right
        worksheet.mergeCells(11,4,11,5);
        //row, col
        worksheet.getCell(11,4).value = '커버수량';
        worksheet.getCell(11,4).font = { size: 10, bold: true };
        worksheet.getCell(11,4).alignment = { horizontal: 'center'};
        worksheet.getCell(11,4).fill = {type: 'pattern',pattern: 'solid',fgColor: { argb: 'f8f8f8' },};
        worksheet.getCell(11,4).border = { top: borderStyle, left: borderStyle, bottom: borderStyle, right: borderStyle};
        //row, col
        worksheet.getCell(11,6).value = data && data.depc1Yn=='Y'? data&& data.depc1Qty:'0';
        worksheet.getCell(11,6).font = { size: 10 };
        worksheet.getCell(11,6).alignment = { horizontal: 'center'};
        worksheet.getCell(11,6).border = { top: dataRowBorderStyle, left: dataRowBorderStyle, bottom: dataRowBorderStyle, right: dataRowBorderStyle};

        /* ------------------------------ 12 Row ----------------------------------- */
        // top, left, bottom, right
        worksheet.mergeCells(12,1,13,1);
        //row, col
        worksheet.getCell(12,1).value = '인쇄';
        worksheet.getCell(12,1).font = { size: 10, bold: true };
        worksheet.getCell(12,1).alignment = { horizontal: 'center', vertical: 'middle', wrapText: true};
        worksheet.getCell(12,1).fill = {type: 'pattern',pattern: 'solid',fgColor: { argb: 'f8f8f8' },};
        worksheet.getCell(12,1).border = { top: borderStyle, left: borderStyle, bottom: borderStyle, right: borderStyle};
        //row, col
        worksheet.getCell(12,2).value = '표지';
        worksheet.getCell(12,2).font = { size: 10, bold: true };
        worksheet.getCell(12,2).alignment = { horizontal: 'center'};
        worksheet.getCell(12,2).fill = {type: 'pattern',pattern: 'solid',fgColor: { argb: 'f8f8f8' },};
        worksheet.getCell(12,2).border = { top: borderStyle, left: borderStyle, bottom: borderStyle, right: borderStyle};
        //row, col
        worksheet.getCell(12,3).value = data && data.prntWayCd2=='04' || data &&data.prntWayCd2=='05' || data &&data.prntWayCd2=='06' || data &&data.prntWayCd2=='07'? '' : '옵셋'
        worksheet.getCell(12,3).font = { size: 10 };
        worksheet.getCell(12,3).alignment = { horizontal: 'center'};
        worksheet.getCell(12,3).border = { top: dataRowBorderStyle, left: dataRowBorderStyle, bottom: dataRowBorderStyle, right: dataRowBorderStyle};
        // top, left, bottom, right
        worksheet.mergeCells(12,4,12,5);
        //row, col
        worksheet.getCell(12,4).value = '비고';
        worksheet.getCell(12,4).font = { size: 10, bold: true };
        worksheet.getCell(12,4).alignment = { horizontal: 'center'};
        worksheet.getCell(12,4).fill = {type: 'pattern',pattern: 'solid',fgColor: { argb: 'f8f8f8' },};
        worksheet.getCell(12,4).border = { top: borderStyle, left: borderStyle, bottom: borderStyle, right: borderStyle};
        //row, col
        worksheet.getCell(12,6).value = data && data.rem;
        worksheet.getCell(12,6).font = { size: 10 };
        worksheet.getCell(12,6).alignment = { horizontal: 'center'};
        worksheet.getCell(12,6).border = { top: dataRowBorderStyle, left: dataRowBorderStyle, bottom: dataRowBorderStyle, right: dataRowBorderStyle};

        /* ------------------------------ 13 Row ----------------------------------- */
        //row, col
        worksheet.getCell(13,2).value = '내지';
        worksheet.getCell(13,2).font = { size: 10, bold: true };
        worksheet.getCell(13,2).alignment = { horizontal: 'center'};
        worksheet.getCell(13,2).fill = {type: 'pattern',pattern: 'solid',fgColor: { argb: 'f8f8f8' },};
        worksheet.getCell(13,2).border = { top: borderStyle, left: borderStyle, bottom: borderStyle, right: borderStyle};
        //row, col
        worksheet.getCell(13,3).value = data && data.prntWayCd2=="01"||data && data.prntWayCd2=="02"||data && data.prntWayCd2=="08"? "옵셋"
        :data && data.prntWayCd2=="03"? "디지털"
        :data && data.prntWayCd2=="04"||data && data.prntWayCd2=="05"? "스티커"
        :data && data.prntWayCd2=="06"||data && data.prntWayCd2=="07"? "리플렛":"";
        worksheet.getCell(13,3).font = { size: 10 };
        worksheet.getCell(13,3).alignment = { horizontal: 'center'};
        worksheet.getCell(13,3).border = { top: dataRowBorderStyle, left: dataRowBorderStyle, bottom: dataRowBorderStyle, right: dataRowBorderStyle};
        // top, left, bottom, right
        worksheet.mergeCells(13,4,13,5);
        //row, col
        worksheet.getCell(13,4).value = '표지코팅';
        worksheet.getCell(13,4).font = { size: 10, bold: true };
        worksheet.getCell(13,4).alignment = { horizontal: 'center'};
        worksheet.getCell(13,4).fill = {type: 'pattern',pattern: 'solid',fgColor: { argb: 'f8f8f8' },};
        worksheet.getCell(13,4).border = { top: borderStyle, left: borderStyle, bottom: borderStyle, right: borderStyle};

        //row, col
        worksheet.getCell(13,6).value = '무광코팅';
        worksheet.getCell(13,6).font = { size: 10 };
        worksheet.getCell(13,6).alignment = { horizontal: 'center'};
        worksheet.getCell(13,6).border = { top: dataRowBorderStyle, left: dataRowBorderStyle, bottom: dataRowBorderStyle, right: dataRowBorderStyle};

        /* ------------------------------ 14 Row ----------------------------------- */
        // top, left, bottom, right
        worksheet.mergeCells(14,1,15,1);
        //row, col
        worksheet.getCell(14,1).value = '인쇄도수';
        worksheet.getCell(14,1).font = { size: 10, bold: true };
        worksheet.getCell(14,1).alignment = { horizontal: 'center', vertical: 'middle', wrapText: true};
        worksheet.getCell(14,1).fill = {type: 'pattern',pattern: 'solid',fgColor: { argb: 'f8f8f8' },};
        worksheet.getCell(14,1).border = { top: borderStyle, left: borderStyle, bottom: borderStyle, right: borderStyle};
        //row, col
        worksheet.getCell(14,2).value = '표지';
        worksheet.getCell(14,2).font = { size: 10, bold: true };
        worksheet.getCell(14,2).alignment = { horizontal: 'center'};
        worksheet.getCell(14,2).fill = {type: 'pattern',pattern: 'solid',fgColor: { argb: 'f8f8f8' },};
        worksheet.getCell(14,2).border = { top: borderStyle, left: borderStyle, bottom: borderStyle, right: borderStyle};
        //row, col
        worksheet.getCell(14,3).value = data && data.prntWayCd!=''?
        data && data.prntWayCd2=='04' || data &&data.prntWayCd2=='05' || data &&data.prntWayCd2=='06' || data &&data.prntWayCd2=='07'?   "" 
        : data && data.prntWayCd=="01"?"없음"
        : data && data.prntWayCd=="02"?"1"
        : data && data.prntWayCd=="03"?"2"
        : data && data.prntWayCd=="04"?"3"
        : data && data.prntWayCd=="05"?"4"
        : data && data.prntWayCd=="06"?"5":""
        :data&& data.cPrntCvrSbc;
        worksheet.getCell(14,3).font = { size: 10 };
        worksheet.getCell(14,3).alignment = { horizontal: 'center'};
        worksheet.getCell(14,3).border = { top: dataRowBorderStyle, left: dataRowBorderStyle, bottom: dataRowBorderStyle, right: dataRowBorderStyle};
        // top, left, bottom, right
        // top, left, bottom, right
        worksheet.mergeCells(14,4,15,4);
        //row, col
        worksheet.getCell(14,4).value = '메모';
        worksheet.getCell(14,4).font = { size: 10, bold: true };
        worksheet.getCell(14,4).alignment = { horizontal: 'center', vertical: 'middle', wrapText: true};
        worksheet.getCell(14,4).fill = {type: 'pattern',pattern: 'solid',fgColor: { argb: 'f8f8f8' },};
        worksheet.getCell(14,4).border = { top: borderStyle, left: borderStyle, bottom: borderStyle, right: borderStyle};
        // top, left, bottom, right
        worksheet.mergeCells(14,5,15,6);
        //row, col
        worksheet.getCell(14,5).value = data && escapeCharChange(escapeCharChange(data.prtlImtrSbc));
        worksheet.getCell(14,5).font = { size: 10 };
        worksheet.getCell(14,5).alignment = { horizontal: 'center', vertical: 'middle', wrapText: true};
        worksheet.getCell(14,5).border = { top: dataRowBorderStyle, left: dataRowBorderStyle, bottom: dataRowBorderStyle, right: dataRowBorderStyle};

        /* ------------------------------ 15 Row ----------------------------------- */
        //row, col
        worksheet.getCell(15,2).value = '내지';
        worksheet.getCell(15,2).font = { size: 10, bold: true };
        worksheet.getCell(15,2).alignment = { horizontal: 'center'};
        worksheet.getCell(15,2).fill = {type: 'pattern',pattern: 'solid',fgColor: { argb: 'f8f8f8' },};
        worksheet.getCell(15,2).border = { top: borderStyle, left: borderStyle, bottom: borderStyle, right: borderStyle};
        //row, col
        worksheet.getCell(15,3).value = data && data.prntWayCd2=="01"||data && data.prntWayCd2=="03"||data && data.prntWayCd2=="04"||data && data.prntWayCd2=="06"? "1"
        :data && data.prntWayCd2=="02"||data && data.prntWayCd2=="05"||data && data.prntWayCd2=="07"? "2"
        :data && data.prntWayCd2=="08"?"4":data && data.cPrntInsdPgSbc;
        worksheet.getCell(15,3).font = { size: 10 };
        worksheet.getCell(15,3).alignment = { horizontal: 'center'};
        worksheet.getCell(15,3).border = { top: dataRowBorderStyle, left: dataRowBorderStyle, bottom: dataRowBorderStyle, right: dataRowBorderStyle};


        // 엑셀 파일을 브라우저에 다운로드합니다.
        workbook.xlsx.writeBuffer().then((buffer) => {
            const blob = new Blob([buffer], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
            const url = URL.createObjectURL(blob);
            const link = document.createElement('a');
            link.href = url;
            link.download = 'OM발주 상세내역('+escapeCharChange(data.newPrntPbcnNo)+ ').xlsx';
            link.click();
            URL.revokeObjectURL(url);
        })
		.catch((error) => {
			console.error('엑셀 파일 생성 중 오류가 발생했습니다:', error);
		})
		.finally(() => {
			return false
		});
}