import axios from 'axios';
import useStore from './store';
import {getApiUrl} from '../utils/commUtils';

// const baseURL = 'http://localhost:8088/api/'
// const baseURL = `${process.env.REACT_APP_API_URL}`;
// const baseURL = process.env.REACT_APP_API_URL;
// const baseURL =  window.location.origin.indexOf('localhost') > 0 ? 'http://localhost:8088/api/' : window.location.origin + '/api/';
const baseURL = getApiUrl();
const axiosInstance = axios.create({
    origin: true,
    headers: {
        'Content-Type': 'application/json',
    },
    withCredentials: true,
    timeout : 1000 * 60 // 60초
});
// axiosInstance.paramsSerializer = {
//   encode: (params) => {
//     console.log('params =>', params)

//     return qs.stringify(params, { arrayFormat: 'repeat' })
//   },
// }


axiosInstance.interceptors.request.use(req => {
  req.headers["x-auth-token"] = useStore.getState().token;
  req.headers["x-auth-browser"] = useStore.getState().browserId;
  return req;
}, function(err){
  return Promise.reject(err);
});

axiosInstance.interceptors.response.use(res => {
  // console.log('res:', res)
  return res;
}, err => {
  if(err.code === 'ERR_NETWORK'){
    // window.location.pathname = '/errorNet';
    return;
  }
  const originalRequest = err.config;
  if(err.response){
    if(err.response.status === 401){
      // console.log(err.response.data);
      if(err.response.data){
          // console.log('err.response.data', err.response.data);
          if(Number(err.response.data.result) === 1){  // ok
              const newToken = err.response.data.token;
              useStore.setState(state => ({...state, token: newToken}));
              return axiosInstance(originalRequest);
          }else {
           
              if(Number(err.response.data.result) === 5){ // token expired
                window.location.pathname = useStore.getState().loginUrl ? useStore.getState().loginUrl : '/login';
              }else{
                useStore.setState(state => ({...state, 
                    svrErrCd: err.response.data.result, 
                    svrErrMsg: err.response.data.msg,
                    token: ''}));
                window.location.pathname = '/errorPage';
              }
          }
      }
    }
  }
});

export const getData = async (url, params=null) => {
  const res = await axiosInstance.get(baseURL + url, {params: params});
  return res && res.data;
}



export const getDataPure = async (url, params=null) => {
  console.log(url)
  const res = await axios.get(baseURL + url, {params: params});
  return res && res.data;
}

export const postData = async(url, params, method) => {
  console.log('[postData]' + url)
  const res =  await axiosInstance.post(baseURL + url, params, {headers: {_method: method},  withCredentials: true});
  return res && res.data;
}

export const postAuth = async(url, params, method) => {
  console.log('[postAuth]', baseURL + url)
  // axiosInstance.getUri()
  const res =  await axiosInstance.post(baseURL + url, params, {headers: {_method: method},  withCredentials: true});
  return res && res.data;
}


// 엑셀다운로드
export const getExcel = async (url, params=null) => {
  return await axiosInstance.get(baseURL + url, {params: params, responseType: 'blob'});
}