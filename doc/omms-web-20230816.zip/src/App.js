// react
import React from 'react';
import { Suspense } from 'react';
import BaseRoutes from './components/Common/BaseRoutes';

import { useMutation } from 'react-query';
import { postData } from './utils/async';
import { API, CONSTANTS } from './utils/constants';

const App = () => {

  const mutateLogout = useMutation(param => postData(API.logout, param, CONSTANTS.update))

  const handleTabClose = e => {
    mutateLogout.mutate({lgoType: 'X'}); //창닫기
    window.removeEventListener('beforeunload', handleTabClose);
  };

  React.useEffect(() => {
   

    window.addEventListener('beforeunload', handleTabClose);
    return () => {
      window.removeEventListener('beforeunload', handleTabClose);
    };
  }, []);

  return (
      <Suspense  fallback={<div>loading.....</div>}> 
        <BaseRoutes />
      </Suspense> 
  );
};
export default App;
