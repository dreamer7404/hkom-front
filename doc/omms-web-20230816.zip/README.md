
1. 캐쉬데이터 삭제. 수정 성공시, 창닫기전에 처리.
	queryResult.remove(); 

2. Form validation reset
	formRef.current.cleanErrors(); // 혹은  formRef.current.resetErrors();

	
3. api 권한체크
	import { isApi } from '../../../../utils/commUtils';

	isApi(API.boardAffrMgmts, 'GET') ==> 있으면 true, 없으면 false



4.  query 캐시 초기화 
	ex/ memberAdd.js , memberUpdate.js
	queryClient.invalidateQueries(); //모든 쿼리 캐시 초기화 
	queryClient.invalidateQueries([API.~~]); //모든 쿼리 캐시 초기화 


5. pom.xml 수정
	1. 폴더를 직접 생성한다.

	lib > com > Raonwiz.Dext5 > 1.0 > Raonwiz.Dext5-1.0.jar ( *기존 WEB-INF/Raonwoz.Dext5.jar를 복사해서 rename한다)
	lib > com > raonwiz-dext5 > 1.0 > raonwiz-dext5-1.0.jar ( *기존 WEB-INF/dext5.jar를 복사해서 rename한다) 

	2. Build Path에 추가되어있는 위 jar파일을 삭제한다.
	3. maven update한다.

5. spinner

    const [spinner, setSpinner] = useState('')
    
    
    setSpinner("whirl traditional");

    return (
        <div className={spinner} >

		</div>
	)

6. 운영서버 배포

	# 빌드할때 체크사항
		1) pom.xml 에서 <maven.test.skip>true</maven.test.skip> 로 설정 => build할때 test안함.
		2) properties파일 
			- DEXT5 path 설정변경
			- JDBC를 운영서버로 변경
		3) front의 .env파일
			- REACT_APP_HMC_URL=https://devoms.hmc.co.kr => https://oms.hmc.co.kr 
		4) front빌드후 (배포되는 최종)
			/dext5upload/config/dext5upload.config.xml 파일에서 product_key,licensekey가 운영서버로 되어있는지확인 



	- 웹서버
	WEB1: 10.5.32.85
	WEB2: 10.5.32.207
	- 와스서버
	WAS1: 10.5.200.113
	WAS2: 10.5.200.199

	1) 현대클라우드 콘솔 페이지 로그인 (https://console.cloud.hyundai-autoever.com/)
	2) 상단 콤보박스에서 - "현대/기아 오너스매뉴얼 재고.." 2개가 보이는데 아래쪽것 선택
	3) 목록에 위 4개IP보이는지확인 -> 안보이면 서비스계정 추가해달라고 안PM에게 요청.
	3) "생성" -> 본인계정접속 -> 서버목록에서 위 4개 서버선택후 확인
	4) was, web 각각 sftp로 배포.




