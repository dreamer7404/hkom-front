package com.oms.mri.dao;

import java.util.List;

import com.oms.mri.dto.PrintOrderComDTO;
import com.oms.mri.dto.PrintOrderInfosResDTO;


/**
 * <pre>
 * PrintOrderDAO
 * </pre>
 * @ClassName : PrintOrderDAO.java
 * @Description : 제작준비 > O/M발주  DAO
 * @author 김정웅
 * @since 2023. 5. 11.
 * @see
 */
public interface PrintOrderDAO {
    List<PrintOrderInfosResDTO> selectPrintOrderList(PrintOrderComDTO reqDto) ;
}
