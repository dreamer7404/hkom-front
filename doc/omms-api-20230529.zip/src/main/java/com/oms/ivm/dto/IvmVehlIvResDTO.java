package com.oms.ivm.dto;

import java.sql.Timestamp;

import org.apache.ibatis.type.Alias;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @author 김정웅
 * @since 2023. 3. 7.
 * @see
 */

@Alias("ivmVehlIvResDTO")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class IvmVehlIvResDTO {

    //공통
    private int sewhaWhsnQty;
    private int sewhaIvQty;
    private int pdiWhsnQty;
    private int pdiNormalWhot;
    private int pdiExtraWhot;
    private int pdiDisuseWhot;
    private int pdiReviceWhot;
    private int pdiIvQty;
    private int ivQty;
    private String sewhaIvText;
    private String pdiIvText;


    //언어별분석
    private String regnNm;
    private String langCd;
    private String langCdNm;
    private String sewhaWhotQty;

    //일자별분석
    private String clsYmd;
    private String sewhaPrntYn;
    private int sewhaNormalWhot;
    private int sewhaExtraWhot;
    private String expdWhsnStNm;
    private int pdiDeei1Qty;
}
