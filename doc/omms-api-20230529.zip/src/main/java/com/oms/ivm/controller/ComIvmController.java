package com.oms.ivm.controller;

import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import able.cloud.core.web.HController;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.oms.cmm.global.Consts;
import com.oms.cmm.utils.Utils;
import com.oms.ivm.dto.ComIvmReqDTO;
import com.oms.ivm.dto.Ivm2WeekPlanReqDTO;
import com.oms.ivm.dto.Ivm2WeekPlanResDTO;
import com.oms.ivm.dto.Ivm3DayPlanReqDTO;
import com.oms.ivm.dto.Ivm3DayPlanResDTO;
import com.oms.ivm.dto.IvmPdiOrYongsanIvResDTO;
import com.oms.ivm.dto.IvmSewonIvResDTO;
import com.oms.ivm.dto.IvmThisMonTrwiResDTO;
import com.oms.ivm.dto.SewonIvModReqDTO;
import com.oms.ivm.dto.SewonIvModResDTO;
import com.oms.ivm.dto.SewonWhotReqDTO;
import com.oms.ivm.service.ComIvmService;
import com.oms.ivm.service.PdiIvmService;
import com.oms.ivm.service.SewIvmService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import io.swagger.v3.oas.annotations.media.Schema;
//import io.swagger.v3.oas.annotations.parameters.RequestBody; 잊지 말자.. 스웨거의 RequestBody...
import org.springframework.web.bind.annotation.RequestBody;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;


/**
 * <pre>
 * ComIvmController
 * </pre>
 *
 * @ClassName   : ComIvmController.java
 * @Description : 재고관리 > 공통 컨트롤러 (주간계획 팝업 등..)
 * @author 김정웅
 * @since 2023.3.13
 * @see
 */
@Tag(name = "ComIvmController", description = "")
//@CrossOrigin(origins="*")
@RequiredArgsConstructor
@RestController
@RequestMapping("/api")
public class ComIvmController extends HController {

    /**
     * 클래스 Injection
     */
    private final HttpServletRequest request;
    private final ComIvmService comIvmService;
    private final SewIvmService sewIvmService;
    private final PdiIvmService pdiIvmService;

    /**
     * 재고관리 > 주간계획(2주)||생산계획(2주)
     */
    @Operation(summary = "주간계획(2주)")
    @GetMapping("/ivm2WeekPlan")
    public List<Ivm2WeekPlanResDTO> selectIvm2WeekPlanList(@ModelAttribute Ivm2WeekPlanReqDTO reqDto) throws Exception {
        //사용자 ID, 회사코드 할당
        reqDto.setUserEeno(Utils.getUserEeno(request));
        reqDto.setDlExpdCoCd(Utils.getDlExpdCoCd(request));

        List<Ivm2WeekPlanResDTO> result = new ArrayList<Ivm2WeekPlanResDTO>();
        result = comIvmService.selectIvm2WeekPlanList(reqDto);

        return result;
    }

    /**
     * 재고관리 > 단기계획(3일)
     */
    @Operation(summary = "단기계획(3일)")
    @GetMapping("/ivm3DayPlan")
    public Ivm3DayPlanResDTO selectIvm3DayPlanList(@ModelAttribute Ivm3DayPlanReqDTO reqDto) throws Exception {
        //사용자 ID, 회사코드 할당
        reqDto.setUserEeno(Utils.getUserEeno(request));
        reqDto.setDlExpdCoCd(Utils.getDlExpdCoCd(request));

        Ivm3DayPlanResDTO result = new Ivm3DayPlanResDTO();
        result = comIvmService.selectIvm3DayPrdnPlanList(reqDto);
        return result;
    }

    /**
     * 재고관리 > 당월투입(누적)
     */
    @Operation(summary = "당월투입(누적)")
    @GetMapping("/ivmThisMonTrwis")
    public List<IvmThisMonTrwiResDTO> selectIvmThisMonTrwiList(@ModelAttribute ComIvmReqDTO reqDto) throws Exception {
        //사용자 ID, 회사코드 할당
        reqDto.setUserEeno(Utils.getUserEeno(request));
        reqDto.setDlExpdCoCd(Utils.getDlExpdCoCd(request));

        List<IvmThisMonTrwiResDTO> result = new ArrayList<IvmThisMonTrwiResDTO>();
        result = comIvmService.selectIvmThisMonTrwiList(reqDto);
        return result;
    }

    /**
     * 재고관리 > 세원 보유재고
     */
    @Operation(summary = "재고현황-세원보유재고")
    @GetMapping("/ivmSewonIvs")
    public List<IvmSewonIvResDTO> selectIvmSewonIvList(@ModelAttribute ComIvmReqDTO reqDto) throws Exception {
        //사용자 ID, 회사코드 할당
        reqDto.setUserEeno(Utils.getUserEeno(request));
        reqDto.setDlExpdCoCd(Utils.getDlExpdCoCd(request));

        List<IvmSewonIvResDTO> result = new ArrayList<IvmSewonIvResDTO>();
        result = comIvmService.selectIvmSewonIvList(reqDto);
        return result;

    }

    /**
     * 재고관리 > PDI/용산 재고
     */
    @Operation(summary = "PDI/용산재고")
    @GetMapping("/ivmPdiOrYongsanIvs")
    public List<IvmPdiOrYongsanIvResDTO> selectIvmPdiOrYongsanIvList(@ModelAttribute ComIvmReqDTO reqDto) throws Exception {
        //사용자 ID, 회사코드 할당
        reqDto.setUserEeno(Utils.getUserEeno(request));
        reqDto.setDlExpdCoCd(Utils.getDlExpdCoCd(request));

        List<IvmPdiOrYongsanIvResDTO> result = new ArrayList<IvmPdiOrYongsanIvResDTO>();
        result = comIvmService.selectIvmPdiOrYongsanIvList(reqDto);
        return result;

    }

    /**
     * 재고관리 > 세원재고관리/PDI재고관리 > 재고보정팝업
     * @Description 차종 선택하여 재고보정 조회시 발간번호 별로 데이터 출력이 필요하여, 해당 팝업은 반드시 데이터 DB조회를 해야함.
     */
    @Operation(summary = "재고보정입력 팝업")
    @GetMapping("/ivmIvModInfos")
    public List<SewonIvModResDTO> selectIvModList(@ModelAttribute ComIvmReqDTO reqDto) throws Exception {
        reqDto.setUserEeno(Utils.getUserEeno(request));
        reqDto.setDlExpdCoCd(Utils.getDlExpdCoCd(request));

        List<SewonIvModResDTO> result = new ArrayList<SewonIvModResDTO>();
        if("sewon".equals(reqDto.getMenuGubun())) {
            result = sewIvmService.selectIvModList(reqDto);
        }
        else if ("pdi".equals(reqDto.getMenuGubun())) {
            result = pdiIvmService.selectIvModList(reqDto);
        }


        return result;
    }

    /**
     * 재고관리 > 세원재고관리/PDI재고관리 > 재고보정 저장, 삭제
     */
    @Operation(summary = "세원재고 재고보정 - 등록,삭제", description = "")
    @Parameter(in = ParameterIn.HEADER, name="_method")
    @PostMapping("/ivmIvModInfos")
    public Integer insertIvModList(@RequestBody List<SewonIvModReqDTO> reqDto) throws Exception {

        String method = Utils.getMethod(request);
        String userEeno = Utils.getUserEeno(request);
        String dlExpdCoCd = Utils.getDlExpdCoCd(request);
        int result = 0;

        if("sewon".equals(reqDto.get(0).getMenuGubun())) {
            if(method.equals(Consts.INSERT)) {
                result = sewIvmService.insertIvModList(reqDto, userEeno, dlExpdCoCd);
            } else if(method.equals(Consts.DELETE)) {
                result = sewIvmService.deleteIvModList(reqDto, userEeno, dlExpdCoCd);
            }
        }
        else if ("pdi".equals(reqDto.get(0).getMenuGubun())) {
            if(method.equals(Consts.INSERT)) {
                result = pdiIvmService.insertIvModList(reqDto, userEeno, dlExpdCoCd);
            } else if(method.equals(Consts.DELETE)) {
                result = pdiIvmService.deleteIvModList(reqDto, userEeno, dlExpdCoCd);
            }
        }
        else {
            return 0;
        }

        return result;
    }

}