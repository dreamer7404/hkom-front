package com.oms.stm.dao;

import java.util.List;


import com.oms.stm.dto.BoardReqDTO;
import com.oms.stm.dto.BoardResDTO;


/**
 * <pre>
 * NatlMgmt DAO 인터페이스
 * </pre>
 *
 * @Class Name  : NatlMgmtDAO.java
 * @Description :
 * @author 안경수
 * @since 2023.1.6
 * @see
*/
public interface BoardDAO {
    BoardResDTO selectNatlMgmt(BoardReqDTO boardReqDTO) throws Exception;
    List<BoardResDTO> selectNatlMgmtList(BoardReqDTO boardReqDTO) throws Exception;
    Integer insertNatlMgmt(BoardReqDTO boardReqDTO) throws Exception;
    Integer updateNatlMgmt(BoardReqDTO boardReqDTO) throws Exception;
    Integer deleteNatlMgmt(BoardReqDTO boardReqDTO) throws Exception;
    /**
     * Statements
     *
     * @param boardDTO
     * @return
     */
    List<BoardResDTO> selectBoardList(BoardReqDTO boardReqDTO) throws Exception;
    /**
     * Statements
     *
     * @param boardReqDTO
     * @return
     */
    List<BoardResDTO> selectBoardGrpList(BoardReqDTO boardReqDTO) throws Exception;
    /**
     * Statements
     *
     * @param boardReqDTO
     * @return
     */
    int selectBoardNo(BoardReqDTO boardReqDTO);
    /**
     * Statements
     *
     * @param boardReqDTO
     * @return
     * @return
     */
     void insertBoard(BoardReqDTO boardReqDTO);
     /**
      * Statements
      *
      * @param boardReqDTO
      */
     void insertRcvrMgmt(BoardReqDTO boardReqDTO);
    /**
     * Statements
     *
     * @param boardReqDTO
     */
    void deleteBoard(BoardReqDTO boardReqDTO);
    /**
     * Statements
     *
     * @param boardReqDTO
     */
    void updateBoard(BoardReqDTO boardReqDTO);

}
