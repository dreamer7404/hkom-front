package com.oms.common.scheduler;

import net.javacrumbs.shedlock.spring.annotation.EnableSchedulerLock;
import net.javacrumbs.shedlock.spring.annotation.SchedulerLock;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.util.Date;

@Component
@EnableSchedulerLock(defaultLockAtMostFor = "PT4S")
public class Job1 {
//    @Scheduled(fixedRate = 5000)
    @SchedulerLock(name="SchedulerLock",lockAtMostFor = "PT4S", lockAtLeastFor = "PT4S")
    public void SchedulerTest() {
        System.out.println("1번 스케줄러"+new Date());
    }

}
