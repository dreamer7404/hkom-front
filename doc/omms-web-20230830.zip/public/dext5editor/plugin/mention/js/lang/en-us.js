(function(){var a={};try{G_DEPlugin&&(G_DEPlugin.mention.lang=a,dext5_lang.plugins.mention=a)}catch(b){}})();
