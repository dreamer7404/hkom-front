(function(){var a={};try{G_DEPlugin&&(G_DEPlugin.autogrow.lang=a,dext5_lang.plugins.autogrow=a)}catch(b){}})();
