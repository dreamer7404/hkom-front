var G_processHtmlWorker;

function fn_processHtmlWorker(_paramObj) {
    var changeContentEditable = false;
    if (_iframeDoc) {
        if (_iframeDoc.body.contentEditable == "true") {
            _iframeDoc.body.contentEditable = "false";
            changeContentEditable = true;
        }
    }

    G_processHtmlWorker = new Worker(_paramObj.editorConfig.htmlProcessWorkerJSUrl + "?ver=" + DEXTTOP.DEXT5.ReleaseVer);

    try {
        G_processHtmlWorker.onmessage = function (e) {
            var result = "";
            if (e.data.errorMessage) {
                result = _paramObj.callFnParam[0];
            } else {
                result = e.data.htmlResult;
            }

            releaseProcessHtmlWorker();

            var backupRange = saveSelection(_paramObj.editorConfig.editor_id, true);

            if (changeContentEditable == true) {
                _iframeDoc.body.contentEditable = "true";
            }

            restoreSelection(backupRange, true);

            if (_paramObj && _paramObj.callBackFn) {
                if (_paramObj.callFn == "SetCorrectOfficeHtml") {
                    _paramObj.callBackFn(result, undefined, e.data.wordProcessorType);
                } else {
                    _paramObj.callBackFn(result);
                }
            }
        };

        G_processHtmlWorker.onerror = function (e) {

            releaseProcessHtmlWorker();

            if (changeContentEditable == true) {
                _iframeDoc.body.contentEditable = "true";
            }

            if (_paramObj && _paramObj.callBackFn) {
                _paramObj.callBackFn(_paramObj.callFnParam[0]);
            }
        };

        var editorConfig = createWorkerConfig(_paramObj.editorConfig);

        G_processHtmlWorker.postMessage({
            editorBrowser: _paramObj.editorBrowser,
            editorConfig: editorConfig,
            callFn: _paramObj.callFn,
            callFnParam: _paramObj.callFnParam
        });
    } catch (ex) {
        releaseProcessHtmlWorker();

        if (changeContentEditable == true) {
            _iframeDoc.body.contentEditable = "true";
        }

        if (_paramObj && _paramObj.callBackFn) {
            _paramObj.callBackFn(_paramObj.callFnParam[0]);
        }
    }
}

function releaseProcessHtmlWorker() {
    if (typeof (G_processHtmlWorker) != "undefined") {
        try {
            G_processHtmlWorker.terminate();
        } catch (ex) { }
    }
}

function destoryWebWorkerVar() {
    if (typeof (G_processHtmlWorker) != "undefined") {
        try {
            G_processHtmlWorker = null;
            delete G_processHtmlWorker;
        } catch (e) { }
    }
}

function createWorkerConfig(config) {
    var autoMoveInitFocusWindow = config.autoMoveInitFocus.targetWindow;
    config.autoMoveInitFocus.targetWindow = null;

    var copy = JSON.parse(JSON.stringify(config));

    config.autoMoveInitFocus.targetWindow = autoMoveInitFocusWindow;

    return copy;
}