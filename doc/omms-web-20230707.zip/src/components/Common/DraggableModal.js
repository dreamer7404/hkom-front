import ModalDialog from 'react-bootstrap/ModalDialog'
import Draggable from 'react-draggable'

const DraggableModal = ({ ...props }) => {
    return (
      <Draggable handle=".handle">
        <ModalDialog {...props} />
      </Draggable>
    );
  };
export default DraggableModal;