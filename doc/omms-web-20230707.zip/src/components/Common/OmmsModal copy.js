
import React from 'react';
import Draggable from "react-draggable";

const OmmsModal = ({show, onHide, size, title, children}) => {
    return(
        <div style={{ visibility: show ? "visible" : "hidden" }}>
            <Draggable>
                <div className='hkomms-modal'
                    style={{
                        width: size === 'lg' ? '800px' :'400px',
                        minHeight: '300px',
                    }}>
                    <div className='hkomms-modal-header'>{title}</div>
                    <div className='hkomms-modal-header-close'><p onClick={onHide} >X</p></div>
                    {children}
                 </div>
            </Draggable>
       </div> 
    )
};
export default OmmsModal;