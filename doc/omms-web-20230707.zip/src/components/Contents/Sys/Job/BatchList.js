// react
import React, {useState, useEffect, useRef} from 'react';

//--------------  서버데이터용 필수 -------------------------------
import { useQuery,useMutation} from 'react-query';
import { API, CONSTANTS } from '../../../../utils/constants';
import { getData,postData } from '../../../../utils/async';
import useStore from '../../../../utils/store';
//--------------// 서버데이터용 필수 -------------------------------

import GridBatchList from '../_Grid/GridBatchList';
import Total from '../../../Common/Total';
import { confirmAlert } from 'react-confirm-alert'; // Import
import ConfirmAlert from '../../../Common/ConfirmAlert';
const BatchList = () => {

    //------------------- 필수 공통 ------------------------------
    const {keyword } = useStore();  // 조회키워드 가져오기

    const [activePage, setActivePage] = useState(1);    // 페이지번호
    const [limit, setLimit] = useState(50);             // 페이지행수

    const onChangePage = val => {
        setActivePage(val);
    };
    const onChangeLimit = val => {
        setLimit(val);
    };
    useEffect(()=>{
        onChangePage(1); // 페이지번호 리셋
    },[keyword]);


    //-------------------// 필수 공통 ------------------------------

   
    //batch 조회
    const queryResult = useQuery([API.batchInfos, {}], () => getData(API.batchInfos, {}),{
        staleTime: 0,
    });    
   
    // //  requestState 조회
    // const queryResult = useQuery(["BatchList"], () => {return rowData});

    // 셀 클릭
    const onCellClicked = e => {
        if(e.column.colId === 'menuGroup'){
           
        }
    };


    return (
        <>
            <div className="grid-wrap" style={{paddingTop:'10px', borderTop:'2px solid var(--main-color)'}}>
                {/*--------- Grid -----------*/}
                <GridBatchList 

                    queryResult={queryResult}
                    limit={limit}
                    activePage={activePage}
                    onCellClicked={onCellClicked}
                    />

                {/*--------- 페이징 -----------*/}
                <Total 
                    total={queryResult && queryResult.data && queryResult.data.length}
                    limit={limit}
                    activePage={activePage}
                    onChangePage={onChangePage}
                    onChangeLimit={onChangeLimit}
                />
            </div>
        </>
    )
};
export default BatchList;