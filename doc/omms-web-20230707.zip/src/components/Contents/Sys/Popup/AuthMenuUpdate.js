/* eslint-disable react-hooks/exhaustive-deps */
import React, {useState, useMemo, useEffect, useRef, useCallback} from 'react';
import { AgGridReact } from 'ag-grid-react';
import {Modal, Button} from 'react-bootstrap';
import {Form, SelectPicker,Whisper, Popover, Input} from 'rsuite';

//--------------  서버데이터용 필수 -------------------------------
import { useQuery, useQueryClient, useMutation} from 'react-query';
import { getData, postData } from '../../../../utils/async';
import { API, CONSTANTS } from '../../../../utils/constants';
import useStore, {useStoreMem} from '../../../../utils/store';
//--------------// 서버데이터용 필수 -------------------------------

import { confirmAlert } from 'react-confirm-alert'; // Import
import ConfirmAlert from '../../../Common/ConfirmAlert';
const validStyle = {color: 'red', height: '30px',paddingTop: '6px'};


const AuthMenuUpdate = ({show, onHide, data}) => {

    const gridRef = useRef();
    // const {gridData, setGridData} = useStoreMem();
    const [rowData, setRowData] = useState();


     //  requestState 조회
     const params = {menuId: data.menuId};
     const queryResult = useQuery([API.authAffrMgmt, params], () => getData(API.authAffrMgmt, params), {staleTime: 0, cacheTime: 0});

     useEffect(() => {
        if(queryResult.isSuccess && queryResult.data){
            setRowData(queryResult.data);
        }
     },[queryResult.status])

    //  useEffect(() => {
    //     // grid refresh시 selection 복원
    //     if(gridRef && gridRef.current && gridRef.current.api && rowData){
    //         gridRef.current.api.forEachNode((node) =>
    //             node.setSelected(!!node.data && node.data.menuAuthCd !== null)
    //         );
    //     }
    //  },[rowData])

   

    const columnDefs = [
        {
          checkboxSelection: true,
          headerCheckboxSelection: true,
          width:35,
          maxWidth:35,
          minWidth:35,
          sortable:false
        },
        {
            headerName: '권한',
            field: 'menuAuthCd',
            maxWidth:'150',
            cellRenderer:'SelectComponent',
        },
        {
            headerName: '그룹명',
            field: 'grpNm',
        },
    ]

    const defaultColDef = useMemo(() => {
        return {
            initialWidth: 90,
            sortable: true,
            resizable:true,
            minWidth:70
        };
    }, []);

    const onFirstDataRendered = (params) => {
        params.api.sizeColumnsToFit();
        // 데이타에서 menuAuthCd 있는것은 체크
        gridRef.current.api.forEachNode((node) =>
            node.setSelected(!!node.data && node.data.menuAuthCd !== null)
        );
    };


    const InputComponent = (props) => {

        const containerRef = useRef();

        const [open, setOpen] = useState(false)
        const [txt, setTxt] = useState('')
        const onChange = val => {
            setTxt(val);
            setOpen(!open)
        }

        const onExited = e => {
            console.log(e);
        }

        return (
           
            <div className="">
                <Whisper  preventOverflow open={ open} 
                container={()=> containerRef.current}
                
                    placement="bottom" speaker={<Popover style={validStyle}>
                    {'입력해주세요'}</Popover>}>
                    <Form.Control value={txt} onChange={onChange}/>
                </Whisper>
            </div>
        )
             
    }


    const SelectComponent = (props) => {

        const onChange = val => {
            props.setValue(val)
        }

        return (
          <div className="grid-form-wrap">
                 <SelectPicker
                    size="sm"
                    searchable={false}
                    cleanable={false}
                    value={props && props.value}
                    onChange={onChange}
                    data={[
                        {label: '쓰기', value: 'U'},
                        {label: '읽기', value: 'R'},
                    ]}
                />
          </div>
        );
    }

    // 사용여부 수정
    const changeMutate = useMutation((params => postData(API.authAffrMgmt, params, CONSTANTS.update)),{
        onSuccess: res => {
            if(res > 0){
                confirmAlert({
                    closeOnClickOutside: false,
                    customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}  title={"알림"} msg={"저장했습니다."}  />
                });
                onHide();
            }else{
                confirmAlert({
                    closeOnClickOutside: false,
                    customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}  title={"오류"} msg={"저장실패했습니다."}  />
                });
            }
        }
    });

    // 저장확인
    const onOk = () => {
        const nodes = gridRef.current.api.getRenderedNodes();
        const sendNodes = nodes.map(item => ({
            menuId: data.menuId, 
            selected: item.selected,
            grpCd: item.data.grpCd, 
            menuAuthCd: item.data.menuAuthCd}));
        // 저장
        changeMutate.mutate({menuId: data.menuId, list: sendNodes});

    }

    // 저장버튼 클릭
    const handleSubmit = () => {
       
        const rows = gridRef.current.api.getSelectedRows();
        if(rows.length === 0){
            confirmAlert({
                closeOnClickOutside: false,
                customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}  title={"알림"} msg={"저장할 그룹을 선택해주세요"}  />
            });
        }else{
            // 체크 validation
            const nodes = gridRef.current.api.getRenderedNodes();
            const checkRows = nodes.filter(item => item.selected && !item.data.menuAuthCd);
            if(checkRows.length > 0){
                gridRef.current.api.flashCells({ rowNodes: checkRows, columns: ['menuAuthCd'], fadeDelay: 400000, flashDelay:10 });  
                confirmAlert({
                    closeOnClickOutside: false,
                    customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}  title={"알림"} msg={"권한을 선택해주세요"}  />
                });
            }else{

                confirmAlert({
                    closeOnClickOutside: false,
                    customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}  title={"알림"} msg={"저장하시겠습니까?"} onOk={onOk} />
                });
            }
        }
    }

   
    return (
        <>
            <Form >
                <Modal show={show} onHide={onHide} backdrop="static" keyboard={false} centered size="md" className="modal-custom">
                    <Modal.Header closeButton>
                        <Modal.Title>메뉴별 권한 상세/수정</Modal.Title>
                    </Modal.Header>
                    <Modal.Body >
                        <div className="grid-btn-wrap">
                            <div className="left-align">
                                <div className="sub-title">
                                    <ul>
                                        <li>{data.pgmNm}</li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div className="ag-theme-alpine" style={{height:300, minWidth:300}}>
                            <AgGridReact
                                ref={gridRef}
                                rowData={rowData} 
                                columnDefs={columnDefs}
                                defaultColDef={defaultColDef}
                                rowSelection={'multiple'}
                                suppressRowClickSelection= {true} 
                                frameworkComponents={{
                                    SelectComponent,
                                    // InputComponent
                                }}
                                onFirstDataRendered={onFirstDataRendered}
                                suppressSizeToFit={true}    
                                onGridSizeChanged={onFirstDataRendered}   

                                >
                            </AgGridReact>
                        </div>
                    </Modal.Body>
                    <Modal.Footer>
                        <Button variant="light" size="md" onClick={onHide}>취소</Button>
                        <Button variant="primary" size="md" onClick={handleSubmit}>저장</Button>
                    </Modal.Footer>
                </Modal>
            </Form>
        </>
    );

};
export default AuthMenuUpdate;