
import React ,{useState, useRef, useEffect} from 'react';
import {Row, Col, Table} from 'react-bootstrap';
import {InputPicker, Button, Schema, Form, Whisper, Popover, Input, Modal} from 'rsuite';
import { AgGridReact } from 'ag-grid-react';

//--------------  서버데이터용 필수 -------------------------------
import { useQuery, useMutation} from 'react-query';
import { getData, postData } from '../../../../utils/async';
import { API, CONSTANTS } from '../../../../utils/constants';
// import useStore from '../../utils/store';
//--------------// 서버데이터용 필수 -------------------------------
import { CustomInputGroup } from '../../../Common/CustomInputGroup';

const { StringType, NumberType,  ArrayType, ObjectType } = Schema.Types;
const model = Schema.Model({
    userEeno: StringType().isRequired('아이디를 입력해주세요.'),
    userNm: StringType().isRequired('이름을 입력해주세요.'),
    userEmlAdr: StringType().isRequired('이메일을 입력해주세요.')
                            .isEmail('이메일 형식에 맞게 입력해주세요.'),
    coCd: StringType().isRequired('소속회사를 선택해 주세요.'),
    deptCd: StringType().isRequired('부서를 선택해 주세요.'),
    grpCd: StringType().isRequired('그룹을 선택해 주세요.'),
    useYn: StringType().isRequired('사용유무를 선택해 주세요.'),

    // 리스트 테스트
    list: ArrayType().of(
        ObjectType().shape({
            nick: StringType().minLength(6, '6자이상 입력해주세요.').isRequired('별명을 입력해주세요.'),
            age: StringType().minLength(2, '2자이상 입력해주세요.').isRequired('나이를 입력해주세요.'),
        })
      )
});


const columnDefs = [
    {
      checkboxSelection: true,
      headerCheckboxSelection: true,
      spanHeaderHeight: true,
      width:35,
      maxWidth:35,
      minWidth:35,
      sortable:false
    },
    {
        headerName: '차종',
        field: 'qltyVehlNm',
        spanHeaderHeight: true,
        cellStyle:() => ({textAlign: 'left'}), 
        filter: true,
    },
];
const defaultColDef = {
        initialWidth: 90,
        sortable: true,
        resizable:true,
        minWidth:70
};

//-------------------------- 리스트 acceptor 컨트롤 ------------------------------------------------------------
const ListControl =  ({ value = [], onChange, fieldError }) => {

    // eslint-disable-next-line react-hooks/exhaustive-deps
    const errors = fieldError ? fieldError.array : [];
    const [list, setList] = React.useState(value); 

    const handleChangeNick = (idx, val) => {
        const arr = list.map((item, index) => (idx === index) ? {...item, nick: val} : item);
        setList(arr)
        onChange(arr);
    };
    const handleChangeAge = (idx, val) => {
        const arr = list.map((item, index) => (idx === index) ? {...item, age: val} : item);
        setList(arr)
        onChange(arr);
    };

    useEffect(()=> {
        console.log('errors', errors)
    },[errors]);

  

    return (
        <div style={{width: '400px'}} >
           
                    <Table  bordered >
                    <thead>
                        <tr>
                            <th>아이디</th>
                            <th>이름</th>
                            <th>별명</th>
                            <th>나이</th>
                        </tr>
                    </thead>
                    <tbody >
                    {list.map((item, index) => (
                        <tr key={index}>
                            <td >{item.id}</td>
                            <td>{item.name}</td>
                            <td>
                                <Whisper  preventOverflow
                                    open={(errors.length > 0 && errors[index].hasError) ? true : false}
                                    placement="bottom" 
                                    speaker={<Popover style={{color: 'red', height: '30px',paddingTop: '6px'}}>
                                        {(errors.length > 0 && errors[index].hasError) && errors[index].object.nick.errorMessage }</Popover>}
                                    >
                                    
                                    <Input value={item.nick || ''} onChange={(val)=>handleChangeNick(index, val)} style={{ width: 100 }} />

                                </Whisper>
                            </td>
                            <td>
                                <Whisper 
                                    open={(errors.length > 0 && errors[index].hasError) ? true : false}
                                    placement="bottom" 
                                    speaker={<Popover  style={{color: 'red', height: '30px',paddingTop: '6px'}}>
                                        {(errors.length > 0 && errors[index].hasError) && errors[index].object.age.errorMessage }</Popover>}
                                    >
                                    
                                    <Input  value={item.age || ''} onChange={(val)=>handleChangeAge(index, val)} style={{ width: 100 }} />
                                    {/* <div style={{color: 'red'}}>{(errors.length > 0 && errors[index].hasError) && errors[index].object.age.errorMessage }</div> */}
                                
                                </Whisper>
                            </td>
                        </tr>
                    ))}
                    </tbody>
                </Table>

            <div>errors: {errors.length}</div>  
        </div>
    )

}
//--------------------------// 리스트 acceptor 컨트롤 ------------------------------------------------------------


const MemberAddTest = ({show, onClose}) => {

    const gridRef = useRef();

    // 회사목록 가져오기
    const paramsCo = {
        dlExpdGCd: '0001'
    };
    const coCombo = useQuery([API.codeCombo, paramsCo], () => getData(API.codeCombo, paramsCo), {
            select: data => [{label: '선택', value: ''}].concat(data)
    });

    // 부서목록(용역회사) 가져오기
    const paramsDept = {
        dlExpdGCd: '0011'
    };
    const deptCombo = useQuery([API.codeCombo, paramsDept], () => getData(API.codeCombo, paramsDept), {
            select: data => [{label: '선택', value: ''}].concat(data.filter(d => (d.value === 'ALL' || d.value === '02' || d.value === '07' || d.value === '08' )))
    });

    // 그룹목록 가져오기
    const grpCombo = useQuery([API.grpCombo], () => getData(API.grpCombo), {
            select: data => [{label: '선택', value: ''}].concat(data)
    });

    // 차종권한목록 가져오기
    const userVehls = useQuery([API.userVehls], () => getData(API.userVehls));


    // Form 정의
    const formRef = React.useRef();
    const [formError, setFormError] = React.useState({});
    const [formValue, setFormValue] = React.useState({
      userEeno: '',
      userNm: '',
      userEmlAdr: '',
      blnsCoCd: '',
      userDcd: '',
      grpCd: '',
    

      usrVehls:[],

      // 리스트 테스트
      list: [
            {id: 1, name: 'aaa', email: '', age: null},
            {id: 2, name: 'bbb', email: '', age: null},
        ],
    });

    // 저장버튼 클릭
    const handleSubmit = () => {
        // validation 체크
        if (!formRef.current.check()) {
          return;
        }
        console.log(formValue)
        formValue.usrVehls = gridRef.current.api.getSelectedRows(); // grid 선택된목록 가져오기
        usrmgmtMutate.mutate(formValue);  // 사용자 등록정보
    };

    // 사용자등록하기
    const usrmgmtMutate = useMutation((params => postData(API.usrmgmt, params, CONSTANTS.insert)));

    // 사용자정보 가져오기(아이디 중복체크)
    const usrmgmt = useQuery([API.usrmgmt + '/' + formValue.userEeno], () => getData(API.usrmgmt + '/' + formValue.userEeno), {
        enabled: false, // 자동실행막기
        onSuccess: data => {
            if(data) alert('이미 사용자가 있습니다.');
            else alert('사용가능!')
        }
    });

    // 아이디 중복체크 수동 실행하기
    const onCheckId = () => {
        usrmgmt.refetch(); 
    }

   
    // grid 필터링
    const [filterValue, setFilterValue] = useState(''); 
    const onFilterTextBoxChanged =(e) => {
        setFilterValue(e.target.value);
    };
    useEffect(()=> {
        if(gridRef && gridRef.current && gridRef.current.api){
          gridRef.current.api.setQuickFilter(filterValue);
        }
    },[filterValue]);

    // grid 리사이즈
    const onFirstDataRendered = (params) => {
        params.api.sizeColumnsToFit();
    };



    //------------------------- 리스트 테스트 --------------------------------------------------------
   
    useEffect(()=> {
        console.log('show', show)
    },[show]);
    
        
    const containerRef = useRef();

    return (
        <div >
            <Modal open={show} >
            <Modal.Body onScroll={() => setFormError([])}>
            {/* <Modal.Body  ref={containerRef} > */}
                <h1>사용자 등록</h1>

                <Form
                    ref={formRef}
                    checkTrigger="change"
                    onChange={setFormValue}
                    onCheck={setFormError}
                    formValue={formValue}
                    model={model}
                    >

                        <Form.Group>
                            <Form.ControlLabel>아이디</Form.ControlLabel>
                            <Form.Control name="userEeno" size="sm" ></Form.Control>
                            <Button size="sm" onClick={onCheckId}>중복체크</Button>
                        </Form.Group>

                        <Form.Group>
                            <Form.ControlLabel>이름</Form.ControlLabel>
                            <Form.Control name="userNm" size="sm" ></Form.Control>
                        </Form.Group>

                        <Form.Group>
                            <Form.ControlLabel>이메일</Form.ControlLabel>
                            <Form.Control name="userEmlAdr" size="sm" ></Form.Control>
                        </Form.Group>

                        <Form.Group>
                            <Form.ControlLabel>소속회사</Form.ControlLabel>
                            <Form.Control name="coCd" size="sm" 
                                defaultValue={''}
                                accepter={InputPicker} 
                                data={coCombo.isFetched && coCombo.data}
                            ></Form.Control>
                        </Form.Group>
                        
                        <Form.Group>
                            <Form.ControlLabel>부서</Form.ControlLabel>
                            <Form.Control name="deptCd" size="sm" 
                                defaultValue={''}
                                accepter={InputPicker} 
                                data={deptCombo.isFetched && deptCombo.data}
                            ></Form.Control>
                        </Form.Group>

                        <Form.Group>
                            <Form.ControlLabel>그룹</Form.ControlLabel>
                            <Form.Control name="grpCd" size="sm" 
                                defaultValue={''}
                                accepter={InputPicker} 
                                data={grpCombo.isFetched && grpCombo.data}
                            ></Form.Control>
                        </Form.Group>

                        <Form.Group>
                            <Form.ControlLabel>사용유무</Form.ControlLabel>
                            <Form.Control name="useYn" size="sm" 
                                 defaultValue={''}
                                accepter={InputPicker} 
                                data={[
                                    {label: '선택', value: ''},
                                    {label: '사용', value: 'Y'},
                                    {label: '미사용', value: 'N'},
                                ]}
                            ></Form.Control>
                            
                        </Form.Group>
                       

                        <Form.Group>
                            <Form.ControlLabel>차종권한선택</Form.ControlLabel>
                            <CustomInputGroup size="sm"   onInput={onFilterTextBoxChanged} />
                            <div className="ag-theme-alpine" style={{height: '200px', transition:'all ease .3s'}}>
                                <AgGridReact
                                    ref={gridRef} //
                                    rowData={userVehls && userVehls.data} // 데이타
                                    columnDefs={columnDefs} // 정의
                                    defaultColDef={defaultColDef} // 정의

                                    //  filter
                                    cacheQuickFilter={true}

                                    // multi selection
                                    rowSelection='multiple'

                                    // overlay
                                    overlayLoadingTemplate={CONSTANTS.gridLoading}
                                    overlayNoRowsTemplate={CONSTANTS.gridNoRows}

                                    onFirstDataRendered={onFirstDataRendered}
                                    suppressSizeToFit={true}    
                                    onGridSizeChanged={onFirstDataRendered}
                                    >
                                </AgGridReact>
                            </div>
                        </Form.Group>


                    
                        <Form.Group >
                            <Form.ControlLabel>리스트 테스트</Form.ControlLabel>  

                            <Form.Control 
                                name="list" 
                                accepter={ListControl} 
                                fieldError={formError.list} 
                                />
                        </Form.Group>

                        <Row>
                            <Col>
                                <Button appearance="primary" onClick={handleSubmit}>저장</Button>
                            </Col>
                        </Row>
                </Form>
            </Modal.Body>
            <Modal.Footer>
                <Button appearance="primary" color="yellow" onClick={onClose}>닫기</Button>
            </Modal.Footer>
           </Modal>
        </div>
    );

};
export default MemberAddTest;
