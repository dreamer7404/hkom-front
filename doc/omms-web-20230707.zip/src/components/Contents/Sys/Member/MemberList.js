// react
import React, {useState, useEffect, useCallback, useRef} from 'react';
import {Col, Button, Collapse} from 'react-bootstrap';
import {Form, Input, Notification, useToaster } from 'rsuite';
import SearchIcon from '@rsuite/icons/Search';
import { useLocation } from "react-router-dom"

//--------------  서버데이터용 필수 -------------------------------
import { useQuery, useQueryClient, useMutation} from 'react-query';
import { getData, postData } from '../../../../utils/async';
import { API, CONSTANTS } from '../../../../utils/constants';
import useStore from '../../../../utils/store';
//--------------// 서버데이터용 필수 -------------------------------
import Co from '../../../Search/Co';
import Dept from '../../../Search/Dept';
import GridMemberList from '../_Grid/GridMemberList';
import Paging from '../../../Common/Paging';
import { CustomInputGroup } from '../../../Common/CustomInputGroup';

import MemberAdd from '../Popup/MemberAdd';
import MemberUpdate from '../Popup/MemberUpdate';

// icon
import {ArrowDownLine, ArrowUpLine, FileDownload} from '@rsuite/icons';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faFileExcel,faPrint } from '@fortawesome/free-solid-svg-icons'


const MemberList = () => {

    //------------------- 필수 공통 ------------------------------
    const [open, setOpen] = useState(true); // 조건창 열기/닫기
    const {keyword, coCd, deptCd } = useStore();  // 조회키워드 가져오기

    const [activePage, setActivePage] = useState(1);    // 페이지번호
    const [limit, setLimit] = useState(50);             // 페이지행수
    const [filterValue, setFilterValue] = useState(''); // 필터값
    const [userNm, setUserNm] = useState();

    const onChangePage = val => {
        setActivePage(val);
    };
    const onChangeLimit = val => {
        setLimit(val);
    };
    useEffect(()=>{
        onChangePage(1); // 페이지번호 리셋
    },[keyword]);


    const  usrChangeEvent = val =>{
        setUserNm(val);
    }

    // 필터
    const onFilterTextBoxChanged = useCallback((e) => {
        setFilterValue(e.target.value);
    }, []);

    // 검색창 열기/닫기 > 페이지네이션 여부에 따라 +-20px
    const [gridHeight, setGridHeight] = useState(575);
    const gridExpand = () =>{
        setOpen(!open);
        if(open){
            setTimeout(() => setGridHeight(650), 250);
        }else{
            setGridHeight(575)
        }
    }
    //-------------------// 필수 공통 ------------------------------
    
    const gridRef = useRef();
    const toaster = useToaster();

    //  requestState 조회
    const params = {
        blnsCoCd: coCd === 'ALL' ? null : coCd , // 서버에서 sysadm일때만 구분적용한다.
        userDcd: deptCd === 'ALL' ? null : deptCd,
        userNm : userNm
    };
    const queryResult = useQuery([API.usrmgmts, params], () => getData(API.usrmgmts, params));

    // 셀 클릭
    const onCellClicked = e => {
        if(e.column.colId === 'userEeno'){
            setData(e.data);
            setMemberUpdatePop(true);
        }
    };

    const [memberAddPop, setMemberAddPop] = useState(false);
    const [memberUpdatePop, setMemberUpdatePop] = useState(false);
    const [data, setData] = useState(null);

    // 조회버튼
    const onSearch = () => {
        queryResult.refetch(); // 수동쿼리실행
    };

    // 등록창 닫기
    const onHideMemberAdd = inserted => {
        setMemberAddPop(false);
        if(inserted){ // 등록성공시
            queryResult.refetch();
        }
    }

    // 수정창 닫기
    const onHideMemberUpdate = updated => {
        setMemberUpdatePop(false);
        if(updated){ // 수정성공시
            queryResult.refetch();
        }
    }

    // 사용여부 수정
    const changeUserUseYnrMutate = useMutation((params => postData(API.changeUserUseYn, params, CONSTANTS.update)),{
        onSuccess: res => {
            if(res > 0){
                toaster.push(<Notification type='success' header='성공' closable >
                     수정이 완료되었습니다.
                    </Notification>);
                 queryResult.refetch();
            }else{
                toaster.push(<Notification type='error' header='실패' closable >
                    수정이 실패했습니다.<br /> 관리자에게 문의해주세요.
                    </Notification>);
            }
        }
    });

    // 사용여부
    const onUseYn = useYn => {
        const rows = gridRef.current.api.getSelectedRows();
        if(rows.length > 0){
            changeUserUseYnrMutate.mutate({useYn: useYn, list: rows.map(item => item.userEeno)});
        }
    }

    const queryEmail = useQuery(["/testEmail"], () => getData("/testEmail"), {enabled: false});
    const testEmail = () => {
        queryEmail.refetch();
    }

    return (
        <>
            <div className="search-area">
                <Collapse in={open}>
                    <div className="form" id="example-collapse-text">
                        <div className="search-group">
                            <div className="row">
                                <Col sm={3} className=""> 
                                    <Co />
                                </Col>
                                <Col sm={3} className=""> 
                                    <Dept />
                                </Col>
                                <Col sm={3} className="" >
                                    <Form.ControlLabel>아이디/이름</Form.ControlLabel>
                                    <Input type="text" size="sm"  onChange={usrChangeEvent}/>
                                </Col>
                            </div>
                            <div className="search-btn-wrap">
                                <Button className="btn-search" variant="outline-primary" size="sm" onClick={onSearch}><SearchIcon />조회</Button>
                            </div>
                        </div>
                    </div>
                </Collapse>
                <Button size="sm" variant="outline-dark" className="search-control" aria-controls="example-collapse-text" 
                    aria-expanded={open} onClick={gridExpand}>
                    {/* <span className={open === true ? "search-area-close" : "search-area-open"}>{open === true ? CONSTANTS.closeSearch : CONSTANTS.openSearch}</span> */}
                    {open ? <span className="search-area-close"><ArrowUpLine style={{marginRight: '5px', fontSize: '2em'}} />{CONSTANTS.closeSearch}</span> :
                    <span className="search-area-open"><ArrowDownLine style={{marginRight: '5px', fontSize: '2em'}} />{CONSTANTS.openSearch}</span>}
                </Button>
            </div>
            <div className="grid-wrap">
                <div className="grid-btn-wrap">
                    <div className="left-align">
                        {/*--------- 필터 -----------*/}
                        <CustomInputGroup size="sm"   onInput={onFilterTextBoxChanged} />
                    </div>
                    <div className="right-align">
                        {/*--------- 버튼 -----------*/}
                        <Button variant="outline-secondary" size="sm" onClick={() => setMemberAddPop(true)}>사용자 등록</Button>{' '}
                        <Button variant="outline-secondary" size="sm" onClick={() => onUseYn('Y')}>사용</Button>{' '}
                        <Button variant="outline-secondary" size="sm" onClick={() => onUseYn('N')}>미사용</Button>{' '}
                        {/* <Button variant="outline-success" size="sm"><span className="excel-down"></span>{CONSTANTS.excelDownload}</Button>{' '} */}
                        {/* <Button variant="outline-success" size="sm"><FileDownload style={{marginRight: '5px'}} />{CONSTANTS.excelDownload}</Button>{' '} */}
                        {/* <Button variant="outline-secondary" size="sm" onClick={testEmail}>testEmail</Button>{' '} */}
                        <Button variant="outline-success btn-excel" size="sm" ><FontAwesomeIcon icon={faFileExcel}/>{CONSTANTS.excelDownload}</Button>{' '}
                    </div>
                </div>
                {/*--------- Grid -----------*/}
                <GridMemberList 
                    gridRef={gridRef}
                    gridHeight={gridHeight}
                    filterValue={filterValue}
                    queryResult={queryResult}
                    limit={limit}
                    activePage={activePage}
                    onCellClicked={onCellClicked}
                    />

                {/*--------- 페이징 -----------*/}
                <Paging 
                    total={queryResult && queryResult.data && queryResult.data.length}
                    limit={limit}
                    activePage={activePage}
                    onChangePage={onChangePage}
                    onChangeLimit={onChangeLimit}
                />
            </div>
            
            {memberAddPop && <MemberAdd show={memberAddPop} onHide={onHideMemberAdd} />}
            {memberUpdatePop && <MemberUpdate show={memberUpdatePop} data={data} onHide={onHideMemberUpdate} /> }
        </>
    )
};
export default MemberList;