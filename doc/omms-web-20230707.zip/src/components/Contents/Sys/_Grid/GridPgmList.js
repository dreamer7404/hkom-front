import React, {useEffect, useMemo, useRef} from 'react';
import { AgGridReact } from 'ag-grid-react';
import { CONSTANTS } from '../../../../utils/constants';
import { formatNumber, escapeCharChange } from '../../../../utils/commUtils';

const GridPgmList = ({gridRef, gridHeight, filterValue, queryResult, limit, activePage, onCellClicked}) => {

  const columnDefs = [
        {
          checkboxSelection: true,
          headerCheckboxSelection: true,
          width:35,
          maxWidth:35,
          minWidth:35,
          sortable:false
        },
        {
            headerName: '메뉴ID',
            field: 'menuId',
            maxWidth:'200',
        },
        {
            headerName: '메뉴명',
            field: 'pgmNm',
            maxWidth:'200',
            cellRenderer: param => {
              return !param.value  ? '공통' : param.value;
            }
        },
        {
            headerName: 'API URL',
            field: 'apiUrl',
            cellStyle: () => ({textAlign: 'left', textDecoration: 'underline', cursor: 'pointer', color:'#2589f5'})
        },
        {
          headerName: 'API 설명',
          spanHeaderHeight: true,
          field: 'apiNm',
          cellStyle: () => ({textAlign: 'left'}),
          cellRenderer: param => escapeCharChange(param.value)
        },
        {
          headerName: 'API 타입',
          field: 'method',
          maxWidth:'150'
        },
  ]

  const defaultColDef = useMemo(() => {
      return {
          initialWidth: 90,
          sortable: true,
          resizable:true,
          minWidth:70
      };
  }, []);

  const onFirstDataRendered = (params) => {
      params.api.sizeColumnsToFit();
  };

  useEffect(()=>{
    if(queryResult.status === 'loading' && gridRef && gridRef.current && gridRef.current.api){
        gridRef.current.api.showLoadingOverlay();
    }
  },[queryResult]);

  useEffect(()=> {
    if(gridRef && gridRef.current && gridRef.current.api){
      gridRef.current.api.setQuickFilter(filterValue);
    }
  },[filterValue]);

  useEffect(()=> {
    if(gridRef && gridRef.current && gridRef.current.api){
      gridRef.current.api.paginationGoToPage(activePage-1);
    }
  },[activePage]);

  return(
      <div className="ag-theme-alpine" style={{height: gridHeight, transition:'all ease .3s'}}>
        <AgGridReact
            ref={gridRef} 
            rowData={queryResult && queryResult.data} 
            columnDefs={columnDefs}
            defaultColDef={defaultColDef}

            // paging
            pagination={true}
            paginationPageSize={limit} //
            suppressPaginationPanel={true} 
            // onPaginationChanged={onPaginationChanged}

            rowSelection={'multiple'}
            suppressRowClickSelection= {true} 

            //  filter
            cacheQuickFilter={true}

            onCellClicked={onCellClicked}

            // overlay
            overlayLoadingTemplate={CONSTANTS.gridLoading}
            overlayNoRowsTemplate={CONSTANTS.gridNoRows}

            onFirstDataRendered={onFirstDataRendered}
            suppressSizeToFit={true}    
            onGridSizeChanged={onFirstDataRendered}    
            >
        </AgGridReact>
    </div>
  )


};
export default GridPgmList;