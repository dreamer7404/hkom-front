import React, {useEffect, useMemo, useRef} from 'react';
import { AgGridReact } from 'ag-grid-react';
import { CONSTANTS } from '../../../../utils/constants';
import { escapeCharChangeForGrid } from '../../../../utils/commUtils';
const GridEmailHistory = ({gridHeight, filterValue, queryResult, limit, activePage, onCellClicked}) => {

  const gridRef = useRef();

  const columnDefs = [
        {
            headerName: '메일구분',
            field: 'emlScdNm',
            maxWidth:'150'
        },
        {
            headerName: '제목',
            field: 'emlTitl',
            cellStyle: () => ({textDecoration: 'underline', cursor: 'pointer', color:'#2589f5'}),
            cellRenderer: data => escapeCharChangeForGrid(data)
        },
        {
          headerName: '수신인',
          field: 'rcvrNm',
          maxWidth:'300'
        },
        {
          headerName: '발송인',
          field: 'sndrNm',
          maxWidth:'200'
        },
        {
          headerName: '발송일시',
          field: 'fsSndDate',
          maxWidth:'200'
        },  
        {
          headerName: '상태',
          field: 'emlStCd',
          maxWidth:'150'
        },  
  ]

  const defaultColDef = useMemo(() => {
      return {
          initialWidth: 90,
          sortable: true,
          resizable:true,
          minWidth:70
      };
  }, []);

  const onFirstDataRendered = (params) => {
      params.api.sizeColumnsToFit();
  };

  useEffect(()=>{
    if(queryResult.status === 'loading' && gridRef && gridRef.current && gridRef.current.api){
        gridRef.current.api.showLoadingOverlay();
    }
  },[queryResult]);

  useEffect(()=> {
    if(gridRef && gridRef.current && gridRef.current.api){
      gridRef.current.api.setQuickFilter(filterValue);
    }
  },[filterValue]);

  useEffect(()=> {
    if(gridRef && gridRef.current && gridRef.current.api){
      gridRef.current.api.paginationGoToPage(activePage-1);
    }
  },[activePage]);


  return(
      <div className="ag-theme-alpine" style={{height: gridHeight, transition:'all ease .3s'}}>
        <AgGridReact
            ref={gridRef} 
            rowData={queryResult && queryResult.data} 
            columnDefs={columnDefs}
            defaultColDef={defaultColDef}

            // paging
            pagination={true}
            paginationPageSize={limit} //
            suppressPaginationPanel={true} 
            // onPaginationChanged={onPaginationChanged}

            //  filter
            cacheQuickFilter={true}

            onCellClicked={onCellClicked}
            frameworkComponents={{
              escapeCharChangeForGrid
            }}
            // overlay
            overlayLoadingTemplate={CONSTANTS.gridLoading}
            overlayNoRowsTemplate={CONSTANTS.gridNoRows}

            onFirstDataRendered={onFirstDataRendered}
            suppressSizeToFit={true}    
            onGridSizeChanged={onFirstDataRendered}    
            >
        </AgGridReact>
    </div>
  )


};
export default GridEmailHistory;