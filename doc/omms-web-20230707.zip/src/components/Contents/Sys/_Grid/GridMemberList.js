import React, {useEffect, useMemo, useRef} from 'react';
import { AgGridReact } from 'ag-grid-react';
import { CONSTANTS } from '../../../../utils/constants';

import CustomTooltip from '../../../Common/CustomTooltip';
import { escapeCharChangeForGrid, escapeCharChange} from '../../../../utils/commUtils';

const GridMemberList = ({gridRef, gridHeight, filterValue, queryResult, limit, activePage, onCellClicked}) => {

  const columnDefs = [
        {
          checkboxSelection: true,
          headerCheckboxSelection: true,
          width:35,
          maxWidth:35,
          minWidth:35
        },
        {
            headerName: '아이디',
            field: 'userEeno',
            cellStyle: () => ({textDecoration: 'underline', cursor: 'pointer', color:'#2589f5'})
        },
        {
            headerName: '이름',
            field: 'userNm',
        },
        {
          headerName: '구분',
          spanHeaderHeight: true,
          field: 'coNm',
          tooltipField: 'coNm', // tooltip
        },
        {
          headerName: '업무/회사',
          field: 'deptNm',
          tooltipField: 'deptNm', // tooltip
          cellRenderer: "escapeCharChangeForGrid"
        },
        {
          headerName: '그룹',
          field: 'grpNm',
        },  
        {
          headerName: '사용여부',
          field: 'useYn',
          maxWidth:'120',
          cellRenderer: "statusComonent"
        }  
  ]

  const defaultColDef = useMemo(() => {
      return {
          initialWidth: 90,
          sortable: true,
          resizable:true,
          minWidth:70,
          tooltipComponent: CustomTooltip,
      };
  }, []);

  const onFirstDataRendered = (params) => {
      params.api.sizeColumnsToFit();
  };

  //사용여부
  const statusComonent = (props) => {
    if(props.value === "Y"){
      return(
          <div style={{color:'#2589f5'}}>
          {props.value}
          </div>
      )
    }else if(props.value === "N"){
      return(
          <div style={{color:'#dc3545'}}>
          {props.value}
          </div>
      )
    }
  }


  useEffect(()=>{
    if(queryResult.status === 'loading' && gridRef && gridRef.current && gridRef.current.api){
        gridRef.current.api.showLoadingOverlay();
    }
  },[queryResult]);

  useEffect(()=> {
    if(gridRef && gridRef.current && gridRef.current.api){
      gridRef.current.api.setQuickFilter(filterValue);
    }
  },[filterValue]);

  useEffect(()=> {
    if(gridRef && gridRef.current && gridRef.current.api){
      gridRef.current.api.paginationGoToPage(activePage-1);
    }
  },[activePage]);


  return(
      <div className="ag-theme-alpine" style={{height: gridHeight, transition:'all ease .3s'}}>
        <AgGridReact
            ref={gridRef} 
            rowData={queryResult && queryResult.data} 
            columnDefs={columnDefs}
            defaultColDef={defaultColDef}

            // paging
            pagination={true}
            paginationPageSize={limit} //
            suppressPaginationPanel={true} 
            // onPaginationChanged={onPaginationChanged}

            // multi selection
            rowSelection='multiple'

            //  filter
            cacheQuickFilter={true}

            onCellClicked={onCellClicked}

            frameworkComponents={{
              statusComonent,
              escapeCharChangeForGrid
            }}


            // overlay
            overlayLoadingTemplate={CONSTANTS.gridLoading}
            overlayNoRowsTemplate={CONSTANTS.gridNoRows}

            onFirstDataRendered={onFirstDataRendered}
            suppressSizeToFit={true}    
            onGridSizeChanged={onFirstDataRendered}    

            // tooltip
            tooltipShowDelay={0}
            tooltipHideDelay={2000}
            >
        </AgGridReact>
    </div>
  )


};
export default GridMemberList;