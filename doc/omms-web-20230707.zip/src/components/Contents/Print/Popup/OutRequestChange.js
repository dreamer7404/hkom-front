import React from 'react';
import { postData } from '../../../../utils/async';
import {Button, Modal, Table} from 'react-bootstrap';
import { DatePicker, Form, Schema,Notification } from 'rsuite';
import { useQuery,useMutation} from 'react-query';
import { confirmAlert } from 'react-confirm-alert'; // Import
import ConfirmAlert from '../../../Common/ConfirmAlert';
import { API, CONSTANTS } from '../../../../utils/constants';
import { utcToLocalDate } from '../../../../utils/commUtils';
import { useEffect } from 'react';
import CustomModal from '../../../Common/CustomModal';
const { StringType } = Schema.Types;
const model = Schema.Model({
    dlvgParrYmd: StringType().isRequired('변경 납품요청일을 입력해주세요.'),
    
});

const OutRequestChange = ({data,show, onHide}) => {
    const formRef = React.useRef();
    
    console.log("data",data);
    const [newDate, setNewDate]= React.useState(utcToLocalDate(new Date()));
    const [formError, setFormError] = React.useState({});
    const [formValue, setFormValue] = React.useState({
        newPrntPbcnNo : data.newPrntPbcnNo, //차종코드
        prntParrYmd : data.prntParrYmd,
        dlvgParrYmd: newDate

    });  
  //저장
  const saveData = () => {
    confirmAlert({
        closeOnClickOutside: false,
        customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}  msg={"입력하신 내용으로 저장하시겠습니까?"} onOk={onOk} />
    });
  }
useEffect(()=>{

    console.log("1",newDate)
    setFormValue({
        newPrntPbcnNo : data.newPrntPbcnNo, //차종코드
        prntParrYmd : data.prntParrYmd,
        dlvgParrYmd: newDate
    })
    

},[newDate])

const onChangeDateEnd = val => {
  
        setNewDate(val ? utcToLocalDate(val) : utcToLocalDate(new Date()));    

    
}



const onOk = () => {
    let today = new Date();
    let dd = today.getDate();
    let mm = today.getMonth()+1;
    let yyyy = today.getFullYear();
    if(dd < 10){ dd = '0'+dd;}
    if(mm < 10){ mm = '0'+mm;}
    
    let date = yyyy+"-"+mm+"-"+dd;
    if(date > newDate){
        alert("납품예정일이 오늘보다 작을 수 없습니다.");
        return;
    }
    


    if (!formRef.current.check()) { //validation chk
        return;
    }
    
  
    outRequestChange.mutate(formValue);
}

//차종코드 저장
const outRequestChange = useMutation((params => 
        
    postData(API.outRequestChange, params, CONSTANTS.update)),{
        
    onSuccess: res => {
        
        if(res>0){
            confirmAlert({
                closeOnClickOutside: false,
                customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}   title={"알림"} 
                msg={"저장이 완료되었습니다."}   />
            });
        }else{
            confirmAlert({
                closeOnClickOutside: false,
                customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}  title={"알림"} 
                msg={" 에러가 발생했습니다.<br />관리자에게 문의해주세요."}  />
            });
        }
            onHide(true); // 창닫기 & refetch
        
    }
});



  



    
    return (
        <>
            <Form ref={formRef}
                checkTrigger="change"
                onChange={setFormValue}
                onCheck={setFormError}
                formValue={formValue}
                model={model}>
                
                <CustomModal open={show} 
                        title={'납품요청일 변경'}
                        size='md'
                        // handleOk={handleSubmit}
                        handleCancel={onHide} >
                        
                            <Table className="tbl-hor" bordered>
                                <colgroup>
                                    <col style={{width:'35%'}}></col>
                                    <col style={{width:''}}></col>
                                </colgroup>
                                <tbody>
                                    <tr>
                                        <th>납품요청일</th>
                                        <td>{data.dlvgParrYmd}</td>
                                    </tr>
                                    <tr>
                                        <th className="essen">변경 납품요청일</th>
                                        <td>
                                            <DatePicker oneTap block size="sm"
                                                name='dlvgParrYmd'
                                                value={newDate ? new Date(newDate) : new Date()}
                                                defaultValue={new Date()}  
                                                cleanable={false}
                                                searchable="true"
                                                ranges={[
                                                    {
                                                    label: '오늘',
                                                    value: new Date()
                                                    }
                                                ]}
                                                format="yyyy-MM-dd"
                                                onChange={onChangeDateEnd} 
                                            />
                                        </td>
                                    </tr>
                                </tbody>
                            </Table>
                            <div className='modal-footer'>                        
                                <Button variant="light" size="md" onClick={onHide} >취소</Button>
                                <Button variant="primary" size="md" onClick={() => saveData()}>저장</Button>
                            </div>
                </CustomModal>
            </Form>
        </>
    );

};
export default OutRequestChange;