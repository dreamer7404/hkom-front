// react
import React, {useState, useEffect, useCallback,useRef} from 'react';
import {Col, Button, Collapse} from 'react-bootstrap';
import SearchIcon from '@rsuite/icons/Search';
import { Input, InputGroup, Form } from 'rsuite';
import Total from '../../../Common/Total';
//--------------  서버데이터용 필수 -------------------------------
import { useQuery} from 'react-query';
import { API, CONSTANTS } from '../../../../utils/constants';
import useStore from '../../../../utils/store';
import VehlType from '../../../Search/VehlType';
import LangB from '../../../Search/LangB';
import { getData } from '../../../../utils/async';
//--------------// 서버데이터용 필수 -------------------------------

import GridNatLangList from '../_Grid/GridNatLangList';
import Paging from '../../../Common/Paging';
import { CustomInputGroup } from '../../../Common/CustomInputGroup';

import NatLangAdd from '../Popup/NatLangAdd';
import NatLangUpdate from '../Popup/NatLangUpdate';
import NatCodeSearch from '../Popup/NatCodeSearch';
import NatCarRegion from '../Popup/NatCarRegion';
import NatLangUpload from '../Popup/NatLangUpload';
import {ArrowDownLine, ArrowUpLine} from '@rsuite/icons';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faFileExcel,faPrint } from '@fortawesome/free-solid-svg-icons'
const NatLangList = () => {
    
    const natlGrid = useRef();
    //------------------- 필수 공통 ------------------------------
    const [open, setOpen] = useState(true); // 조건창 열기/닫기
    const {keyword } = useStore();  // 조회키워드 가져오기

    const [activePage, setActivePage] = useState(1);    // 페이지번호
    const [limit, setLimit] = useState(1000);             // 페이지행수
    const [filterValue, setFilterValue] = useState(''); // 필터값
    const [updRegnParam, setUpdRegnParam] = useState();
    const [detailParam, setDetailParam] = useState();
    const [addNatCodeParam, setNatCodeParam] = React.useState({
        dlExpdNatCd: '',             // 차종코드
        natlNm: '',             // 차종
    });  
    const onChangePage = val => {
        setActivePage(val);
    };
    const onChangeLimit = val => {
        setLimit(val);
    };
    useEffect(()=>{
        onChangePage(1); // 페이지번호 리셋
        console.log("keyword",keyword)
    },[keyword]);


    
    // 필터
    const onFilterTextBoxChanged = useCallback((e) => {
        setFilterValue(e.target.value);
    }, []);

    // 검색창 열기/닫기 > 페이지네이션 여부에 따라 +-20px
    const [gridHeight, setGridHeight] = useState(575);
    const gridExpand = () =>{
        setOpen(!open);
        if(open){
            setTimeout(() => setGridHeight(650), 250);
        }else{
            setGridHeight(575)
        }
    }
    //-------------------// 필수 공통 ------------------------------

    const param = {
        bDate: keyword.bDate,
        dlExpdPdiCd: keyword.dlExpdPdiCd,
        qltyVehlCd: keyword.qltyVehlCd==="ALL"?"":keyword.qltyVehlCd,
        mdlMdyCd: keyword.mdlMdyCd,
        dlExpdRegnCd: keyword.dlExpdRegnCd==="ALL"?"":keyword.dlExpdRegnCd,
        langCd: keyword.langCd==="ALL"?"":keyword.langCd,
        langNm: keyword.langNm==="ALL"?"":keyword.langNm,
        dlExpdNatCd : addNatCodeParam.dlExpdNatCd?  addNatCodeParam.dlExpdNatCd : '',
        natlNm :  addNatCodeParam.natlNm ?  addNatCodeParam.natlNm : '',
    }
    const queryResult = useQuery([API.natlLangMgmts, param], () => getData(API.natlLangMgmts, param),{
        staleTime: 0,
        
    });

    //  requestState 조회
    // const queryResult = useQuery(["NatLangList"], () => {return rowData});

    // 셀 클릭
    const onCellClicked = e => {
        if(e.column.colId === 'natNm'){
            console.log("e.data",e.data);
            console.log("e.value",e.value);
            setNatLangUpdatePop(true)
            setDetailParam({
                mdlMdyCd : keyword.mdlMdyCd,
                dlExpdNatCd : e.data.dlExpdNatCd,
                natNm : e.data.natNm,
                dytmPlnNatCd : e.data.dytmPlnNatCd,
                regnNm : e.data.regnNm,
                dlExpdRegnCd : e.data.dlExpdRegnCd
            })
        }else if(e.column.userProvidedColDef.flag === 'qltyVehlCd'&& e.value!= " "){
            setNatCarRegionPop(true)
            setUpdRegnParam({
                qltyVehlCd :e.column.colDef.headerName.substring(0,e.column.colDef.headerName.indexOf('-')),
                dlExpdNatCd : e.data.dlExpdNatCd,
                dlExpdRegnCd : ''
            })
        }
    };

    const [natLangAddPop, setNatLangAddPop] = useState(false);
    const [natLangUpdatePop, setNatLangUpdatePop] = useState(false);
    const [natCodeSearchPop, setNatCodeSearchPop] = useState(false);
    const [natCarRegionPop, setNatCarRegionPop] = useState(false);
    const [natLangUploadPop, setNatLangUploadPop] = useState(false);
   

    const CustomInputGroupWidthButton = () => (
        <InputGroup inside >
            <Input style={{fontSize:'12px', height:'28px'}} value={addNatCodeParam.dlExpdNatCd?addNatCodeParam.dlExpdNatCd : addNatCodeParam.natlNm}/>
            <InputGroup.Button style={{height:'28px'}} onClick={() => setNatCodeSearchPop(true)}>
            <SearchIcon />
            </InputGroup.Button>
        </InputGroup>
    );

    // 조회버튼
    const onSearch = () => {
        queryResult.remove(); 
        queryResult.refetch(); // 수동쿼리실행
    };

    const onHideUpdatePop=()=>{
        setNatLangUpdatePop(false)
        setTimeout(() => queryResult.refetch(), 100);
    }
    const onHideAddPop=()=>{
        setNatLangAddPop(false)
        setTimeout(() => queryResult.refetch(), 100);
    }
    const onHideRegionPop=()=>{
        setNatCarRegionPop(false)
        setTimeout(() => queryResult.refetch(), 100);
    }
    const onHideUploadPop=()=>{
        setNatLangUploadPop(false)
        setTimeout(() => queryResult.refetch(), 100);
    }

    return (
        <>
            <div className="search-area">
                <Collapse in={open}>
                    <div className="form" id="example-collapse-text">
                        <div className="search-group">
                            <div className="row">
                                <Col sm={4} className="" >
                                    <VehlType  />
                                </Col>
                                <Col sm={4} className="" >
                                    <LangB />
                                </Col>
                                <Col sm={2} className="" >
                                    <Form.Group>
                                        <Form.ControlLabel column="sm">국가코드/국가명</Form.ControlLabel>
                                        <CustomInputGroupWidthButton size="sm" />
                                    </Form.Group>
                                </Col>
                            </div>

                            <div className="search-btn-wrap">
                                <Button className="btn-search" variant="outline-primary" size="sm" onClick={onSearch}><SearchIcon />조회</Button>
                            </div>
                        </div>
                    </div>
                </Collapse>
                <Button size="sm" variant="outline-dark" className="search-control" aria-controls="example-collapse-text" 
                    aria-expanded={open} onClick={gridExpand}>
                    {open ? <span className="search-area-close"><ArrowUpLine style={{marginRight: '5px', fontSize: '2em'}} />{CONSTANTS.closeSearch}</span> :
                    <span className="search-area-open"><ArrowDownLine style={{marginRight: '5px', fontSize: '2em'}} />{CONSTANTS.openSearch}</span>}
                </Button>
            </div>
            
            <div className="grid-wrap">
                <div className="grid-btn-wrap">
                    <div className="left-align">
                        {/*--------- 필터 -----------*/}
                        <CustomInputGroup size="sm"   onInput={onFilterTextBoxChanged} />
                    </div>
                    <div className="right-align">
                        {/*--------- 버튼 -----------*/}
                        <Button variant="outline-secondary" size="sm" onClick={() => setNatLangAddPop(true)}>국가별 언어등록</Button>{' '}
                        <Button variant="outline-secondary" size="sm" onClick={() => setNatLangUploadPop(true)}>액셀업로드</Button>{' '}
                        <Button variant="outline-success btn-excel" size="sm" ><FontAwesomeIcon icon={faFileExcel}/>{CONSTANTS.excelDownload}</Button>{' '}
                    </div>
                </div>
                {/*--------- Grid -----------*/}
                <GridNatLangList 
                    gridRef={natlGrid}
                    gridHeight={gridHeight}
                    filterValue={filterValue}
                    queryResult={queryResult}
                    limit={limit}
                    activePage={activePage}
                    onCellClicked={onCellClicked}
                    />

                {/*--------- 페이징 -----------*/}
                <Total 
                    total={queryResult && queryResult.data && queryResult.data.natlLangList.length}
                    limit={limit}
                    activePage={activePage}
                    onChangePage={onChangePage}
                    onChangeLimit={onChangeLimit}
                />
            </div>

            {/* 팝업 */}
            {natLangAddPop &&<NatLangAdd show={natLangAddPop} onHide={onHideAddPop}  />}
            {natLangUpdatePop && <NatLangUpdate detailParam={detailParam}show={natLangUpdatePop} onHide={onHideUpdatePop}  />}
            {natCodeSearchPop && <NatCodeSearch show={natCodeSearchPop} onHide={() => setNatCodeSearchPop(false)} addCodeParam={setNatCodeParam} gbn={"search"}/>}
            {natCarRegionPop && <NatCarRegion updRegnParam={updRegnParam} show={natCarRegionPop} onHide={onHideRegionPop}  />}
            {natLangUploadPop && <NatLangUpload show={natLangUploadPop} onHide={onHideUploadPop}  />}
        </>
    )
};
export default NatLangList;