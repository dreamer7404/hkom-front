// react
import React, {useState, useEffect, useCallback, useRef } from 'react';
import {Col, Button, Collapse} from 'react-bootstrap';
import SearchIcon from '@rsuite/icons/Search';


//--------------  서버데이터용 필수 -------------------------------
import { useQuery} from 'react-query';
import { API, CONSTANTS } from '../../../../utils/constants';
import { getData } from '../../../../utils/async';
import useStore from '../../../../utils/store';
import VehlType from '../../../Search/VehlType';
import Lang from '../../../Search/Lang';
import SeDate from '../../../Search/SeDate';
//--------------// 서버데이터용 필수 -------------------------------

import GridRequestState from '../_Grid/GridRequestState';
import Paging from '../../../Common/Paging';
import { CustomInputGroup } from '../../../Common/CustomInputGroup';
//아이콘
import {ArrowDownLine, ArrowUpLine, FileDownload} from '@rsuite/icons';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faFileExcel,faPrint } from '@fortawesome/free-solid-svg-icons'
import { excelDownload as excelDownloadAggrid } from '../../../../utils/excelForAggrid';

const RequestState = () => {

    const gridRef = useRef();

    //------------------- 필수 공통 ------------------------------
    const [open, setOpen] = useState(true); // 조건창 열기/닫기
    const {keyword } = useStore();  // 조회키워드 가져오기

    const [activePage, setActivePage] = useState(1);    // 페이지번호
    const [limit, setLimit] = useState(50);             // 페이지행수
    const [filterValue, setFilterValue] = useState(''); // 필터값

    const onChangePage = val => {
        setActivePage(val);
    };
    const onChangeLimit = val => {
        setLimit(val);
    };
    useEffect(()=>{
        onChangePage(1); // 페이지번호 리셋
    },[keyword]);

    // 필터
    const onFilterTextBoxChanged = useCallback((e) => {
        setFilterValue(e.target.value);
    }, []);

    // 검색창 열기/닫기 > 페이지네이션 여부에 따라 +-20px
    const [gridHeight, setGridHeight] = useState(575);
    const gridExpand = () =>{
        setOpen(!open);
        if(open){
            setTimeout(() => setGridHeight(650), 250);
        }else{
            setGridHeight(575)
        }
    }
    //-------------------// 필수 공통 ------------------------------

    //  ivmTotal 조회
    const param = {
        sDate: keyword.sDate,
        eDate: keyword.eDate,
        dlExpdPdiCd: keyword.dlExpdPdiCd,
        qltyVehlCd: keyword.qltyVehlCd,
        mdlMdyCd: keyword.mdlMdyCd,
        dlExpdRegnCd: keyword.dlExpdRegnCd,
        langCd: keyword.langCd,
        subCd: keyword.subCd,
    }
    const queryResult = useQuery([API.ivmOrderRequestInfos, param], () => getData(API.ivmOrderRequestInfos, param));

    // 조회버튼
    const onSearch = () => {
        queryResult.refetch(); // 수동쿼리실행
    };

    const [excelStatus, setExcelStatus] = useState(false);
    useEffect(() => {
        if(excelStatus) {
            setExcelStatus(excelDownloadAggrid(gridRef, '총재고관리-요청현황', 2))
        }
    }, [excelStatus])

    return (
        <>
            <div className="search-area">
                <Collapse in={open}>
                    <div className="form" id="example-collapse-text">
                        {/* <div className="row mb-3 border noPadding"> */}
                        <div className="search-group">
                            <div className="row">
                                <Col sm={3} className=""> 
                                    <SeDate />
                                </Col>
                                <Col sm={5} className="" >
                                    <VehlType  />
                                </Col>
                                <Col sm={4} className="" >
                                    <Lang />
                                </Col>
                            </div>
                            <div className="search-btn-wrap">
                                <Button className="btn-search" variant="outline-primary" size="sm" onClick={onSearch}><SearchIcon />조회</Button>
                            </div>
                        </div>
                    </div>
                </Collapse>
                <Button size="sm" variant="outline-dark" className="search-control" aria-controls="example-collapse-text" 
                    aria-expanded={open} onClick={gridExpand}>
                    {open 
                        ? 
                        <span className="search-area-close">
                            <ArrowUpLine style={{marginRight: '5px', fontSize: '2em'}} />
                            {CONSTANTS.closeSearch}
                        </span> 
                        :
                        <span className="search-area-open">
                            <ArrowDownLine style={{marginRight: '5px', fontSize: '2em'}} />
                            {CONSTANTS.openSearch}
                        </span>
                    }
                </Button>
            </div>
            
            <div className="grid-wrap">
                <div className="grid-btn-wrap">
                    <div className="left-align">
                        {/*--------- 필터 -----------*/}
                        <CustomInputGroup size="sm"   onInput={onFilterTextBoxChanged} />
                    </div>
                    <div className="right-align">
                        {/*--------- 버튼 -----------*/}
                        <Button variant="outline-success btn-excel" size="sm" disabled={excelStatus} onClick={() => setExcelStatus(true)}>
                            <FontAwesomeIcon icon={faFileExcel}/>
                            {CONSTANTS.excelDownload}
                        </Button>{' '}
                        <Button variant="outline-dark btn-print" size="sm"onClick={() => window.print()}><FontAwesomeIcon icon={faPrint}/>{CONSTANTS.print}</Button>{' '}
                    </div>
                </div>
               
                {/*--------- Grid -----------*/}
                <GridRequestState 
                    gridHeight={gridHeight}
                    filterValue={filterValue}
                    queryResult={queryResult}
                    limit={limit}
                    activePage={activePage}
                    gridRef={gridRef}
                    />

                {/*--------- 페이징 -----------*/}
                <Paging 
                    total={queryResult && queryResult.data && queryResult.data.length}
                    limit={limit}
                    activePage={activePage}
                    onChangePage={onChangePage}
                    onChangeLimit={onChangeLimit}
                />
            </div>
        </>
    )
};
export default RequestState;