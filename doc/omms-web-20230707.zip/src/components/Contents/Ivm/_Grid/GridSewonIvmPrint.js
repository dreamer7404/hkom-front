import React, {useEffect, useMemo, useRef, useCallback} from 'react';
import {Form, MaskedInput} from 'rsuite';
import { AgGridReact } from 'ag-grid-react';
import { CONSTANTS } from '../../../../utils/constants';
import { formatNumber, escapeCharChangeForGrid } from '../../../../utils/commUtils';

const GridRequestState = ({gridHeight, filterValue, queryResult, limit, activePage, setCheckedRowsForOutReqInput, setCheckedNodesForOutReqInput, gridRef}) => {

  // const gridRef = useRef();

  // 수량 천단위 콤마 찍기 시작
  const currencyFormatter = (params) => {
    return formatNumber(params.value);
  };

  const columnDefs = [
        {
            checkboxSelection: true,
            headerCheckboxSelection: true,
            spanHeaderHeight: true,
            width:35,
            maxWidth:35,
            minWidth:35,
        },
        {
            headerName: '발간번호',
            field: 'newPrntPbcnNo',
            spanHeaderHeight: true,
            minWidth:130
          },
        {
          headerName: '차종',
          children: [
            { headerName:'차종코드', field: 'qltyVehlCd',minWidth:70},
            { headerName:'차종명', field: 'qltyVehlNm',minWidth:130 },
            { headerName:'연식', field: 'mdlMdyCd',minWidth:50 },
          ],
        },
        {
          headerName: '언어',
          children: [
            { headerName:'지역', field: 'dlExpdRegnNm',minWidth:70},
            { headerName:'언어코드', field: 'langCd',minWidth:70 },
            { headerName:'언어명', field: 'langCdNm',minWidth:130},
          ],
        },
        {
            headerName: '발주일',
            field: 'prntParrYmd',
            spanHeaderHeight: true,
          },
        {
          headerName: '납품일',
          field: 'dlvgParrYmd',
          spanHeaderHeight: true,
        },
        {
          headerName: '인쇄 총 부수',
          field: 'prntQty',
          spanHeaderHeight: true,
          valueFormatter: currencyFormatter
        },
        {
          headerName: '잔여 부수',
          field: 'leftQty',
          spanHeaderHeight: true,
          valueFormatter: currencyFormatter
        },  
        {
          headerName: '인쇄 완료부수',
          field: 'prntCmplQty',
          spanHeaderHeight: true,
          valueFormatter: currencyFormatter
        },  
        {
          headerName: '완료부수 입력',
          field: 'inputQty',
          spanHeaderHeight: true,
          cellRenderer:'NumberComponent'
        }
    ]

    const defaultColDef = useMemo(() => {
        return {
            initialWidth: 90,
            sortable: true,
            resizable:true,
            minWidth:70
        };
    }, []);

    const onFirstDataRendered = (params) => {
        params.api.sizeColumnsToFit();
    };

    const NumberComponent = props => {
      const option = 
          {
            mask: [/\d/, /\d/, /\d/, /\d/, /\d/, /\d/, /\d/, /\d/]
          }
      
      const onChangeInput = (newValue, oldValue) => {
        if(parseInt(newValue) > parseInt(props.data.leftQty)){
            props.node.setDataValue(props.colDef.field, props.data.leftQty)
        } else {
            props.node.setDataValue(props.colDef.field, newValue.replace(/(^0+)/, ""))
        }
      };
      return (
          <div className="grid-form-wrap">
                  <MaskedInput
                      style={{width:"100%", height:25, fontSize:12}}
                      value={props.value ? props.value : 0}
                      mask={option.mask}
                      guide={false}
                      showMask={false}
                      onChange={e => onChangeInput(e, props.value)}
                      maxLength={JSON.stringify(props.data.leftQty).length}
                  />
          </div>
      )
    }


  useEffect(()=>{
    if(queryResult.status === 'loading' && gridRef && gridRef.current && gridRef.current.api){
        gridRef.current.api.showLoadingOverlay();
    }
  },[queryResult]);

  useEffect(()=> {
    if(gridRef && gridRef.current && gridRef.current.api){
      gridRef.current.api.setQuickFilter(filterValue);
    }
  },[filterValue]);

  useEffect(()=> {
    if(gridRef && gridRef.current && gridRef.current.api){
      gridRef.current.api.paginationGoToPage(activePage-1);
    }
  },[activePage]);

  const onSelectionChanged = useCallback(() => {
    setCheckedRowsForOutReqInput(gridRef.current.api.getSelectedRows())
    setCheckedNodesForOutReqInput(gridRef.current.api.getSelectedNodes())
  }, []);

  return(
    <Form>
      {queryResult &&
      <div className="ag-theme-alpine" style={{height: gridHeight, transition:'all ease .3s'}}>
        <AgGridReact
            ref={gridRef} 
            rowData={queryResult && queryResult.data} 
            columnDefs={columnDefs}
            defaultColDef={defaultColDef}

            // paging
            pagination={true}
            paginationPageSize={limit} //
            suppressPaginationPanel={true} 
            // onPaginationChanged={onPaginationChanged}

            //  filter
            cacheQuickFilter={true}

            // overlay
            overlayLoadingTemplate={CONSTANTS.gridLoading}
            overlayNoRowsTemplate={CONSTANTS.gridNoRows}

            frameworkComponents={{
                NumberComponent,
                escapeCharChangeForGrid
            }}
            
            rowSelection={'multiple'}
            suppressRowClickSelection= {true} 
            
            onFirstDataRendered={onFirstDataRendered}
            suppressSizeToFit={true}    
            onGridSizeChanged={onFirstDataRendered}    
            // checkedRowDatas by Woong
            onSelectionChanged={onSelectionChanged}
            >
        </AgGridReact>
        
      </div>
      }
    </Form>
  )


};
export default GridRequestState;