import React, { useState, useMemo, useEffect, useRef} from 'react';
import {Button, Modal} from 'react-bootstrap';
import { AgGridReact } from 'ag-grid-react';
import { CONSTANTS } from '../../../../utils/constants';
import { escapeCharChangeForGrid, formatNumber } from '../../../../utils/commUtils';
// //--------------  서버데이터용 필수 -------------------------------
import { useQuery } from 'react-query';
import { getData } from '../../../../utils/async';
import { API } from '../../../../utils/constants';
// //--------------// 서버데이터용 필수 -------------------------------
//아이콘
import {ArrowDownLine, ArrowUpLine, FileDownload} from '@rsuite/icons';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faFileExcel,faPrint } from '@fortawesome/free-solid-svg-icons'
//모달
import CustomModal from '../../../Common/CustomModal';
import { excelDownload as excelDownloadAggrid } from '../../../../utils/excelForAggrid';


const PdiGlovisIvm = ({show, onHide, clickedRowData}) => {

    // 수량 천단위 콤마 찍기
    const currencyFormatter = (params) => {
        return formatNumber(params.value);
    };  
    const gridRef = useRef();

    const queryResult = useQuery([API.ivmPdiOrYongsanIvs, clickedRowData], () => getData(API.ivmPdiOrYongsanIvs, clickedRowData), {
        //화면 열렸을때 무조건 실행 방지를 위한 옵션.
        enabled: false,
    });

    useEffect(() => {
        if(show){
            queryResult.refetch();
        }
    }, [clickedRowData]);
    
    const onFirstDataRendered = (params) => {
        params.api.sizeColumnsToFit();
    };

    


    const defaultColDef = useMemo(() => {
        return {
            sortable: true,
            minWidth:100,
            resizable:false,
            flex:1,
        };
    }, []);
    
    const [total, setTotal] = useState({});
    const [queryResultRealDatas, setQueryResultRealDatas] = useState([]);
    useEffect(()=>{
        if(queryResult.isSuccess){
            setTotal(
                queryResult.isSuccess && queryResult.data.filter(item => {
                    return item.clsYmd === '합계'
                })[0]
            )
            setQueryResultRealDatas (
                queryResult.isSuccess && queryResult.data.filter(item => {
                    return item.clsYmd !== '합계'
                })
            )
        }    
    },[queryResult.data]);
    const pinnedBottomRowData = [total];

    const columnDefs = [
        {
            headerName: '구분',
            field: 'gubun',
            colSpan: (params) => {
            const clsYmd = params.data.clsYmd;
                if (clsYmd === '합계') {
                    // have all Russia age columns width 2
                    return 3;
                } else {
                    // all other rows should be just normal
                    return 1;
                }
            },
        },
        {
            headerName: '날짜',
            field: 'clsYmd',
            colSpan: (params) => {
                const clsYmd = params.data.clsYmd;
                    if (clsYmd === '합계') {
                        // have all Russia age columns width 2
                        return 3;
                    } else {
                        // all other rows should be just normal
                        return 1;
                    }
                },
        },
        {
            headerName: '상태',
            field: 'expdWhsnStNm',
        }, 
        {
            headerName: '입고',
            field: 'pdiWhsnQty',
            valueFormatter: currencyFormatter
        },
        {
            headerName: '투입',
            field: 'pdiNormalWhot',
            valueFormatter: currencyFormatter
        }, 
        {
            headerName: '별도출고',
            field: 'pdiExtraWhot',
            valueFormatter: currencyFormatter
        }, 
        {
            headerName: '폐기',
            field: 'pdiDisuseWhot',
            valueFormatter: currencyFormatter
        }, 
        {
            headerName: '보정',
            field: 'pdiReviceWhot',
            valueFormatter: currencyFormatter
        }, 
        {
            headerName: '보유재고',
            field: 'pdiIvQty',
            valueFormatter: currencyFormatter
        }, 
        {
            headerName: '보유재고 상세내역',
            field: 'pdiIvText',
            cellRenderer: "escapeCharChangeForGrid"
        }, 
    ]

    //엑셀다운로드
    const [excelStatus, setExcelStatus] = useState(false);
    useEffect(() => {
        if(excelStatus) {
            
            setExcelStatus(excelDownloadAggrid(gridRef, clickedRowData.langCd === 'KO'?'용산 재고':'PDI 재고', 1, '합계'))
        }
    }, [excelStatus])

    return (
        <>
            <CustomModal open={show} 
                title={clickedRowData.langCd === 'KO'?'용산 재고':'PDI 재고'}
                size='xl'
                handleCancel={onHide} 
            >
            {/* <Modal show={show} onHide={onHide} backdrop="static" keyboard={false} centered size="xl" className="modal-custom">
                <Modal.Header closeButton>
                    {
                        clickedRowData.langCd === 'KO'
                        ?
                        <Modal.Title>용산 재고</Modal.Title>
                        :
                        <Modal.Title>PDI 재고</Modal.Title>
                    }
                    
                </Modal.Header>
                <Modal.Body> */}
                    <div className="grid-btn-wrap">
                        <div className="left-align">
                            <div className="sub-title">
                                <ul>
                                    {/* 
                                    <li>차종 <span>(AA-19)AA-CAR</span></li>
                                    <li>언어 <span>EC(영어,불어/캐나다)</span></li>
                                     */}
                                    <li>차종 <span>({clickedRowData.qltyVehlCd} - {clickedRowData.mdlMdyCd}){clickedRowData.qltyVehlNm}</span></li>
                                    <li>언어 <span>{clickedRowData.langCd}({clickedRowData.langCdNm})</span></li>
                                </ul>
                            </div>
                        </div>
                        <div className="right-align">
                            <Button variant="outline-success btn-excel" size="sm" disabled={excelStatus} onClick={() => setExcelStatus(true)}>
                                <FontAwesomeIcon icon={faFileExcel}/>
                                {CONSTANTS.excelDownload}
                            </Button>{' '}
                            <Button variant="outline-dark btn-print" size="sm"onClick={() => window.print()}><FontAwesomeIcon icon={faPrint}/>{CONSTANTS.print}</Button>{' '}
                        </div>
                    </div>
                    <div style={{ display: 'flex', flexDirection: 'column', height: 300 }} className="ag-theme-alpine" >
                        <div style={{ flex: '1 1 auto'}}>
                            <AgGridReact
                                // rowData={rowData}
                                // rowData={queryResult && queryResult.data}
                                ref={gridRef}
                                rowData={queryResult && queryResultRealDatas}
                                columnDefs={columnDefs}
                                defaultColDef={defaultColDef}
                                onFirstDataRendered={onFirstDataRendered}
                                suppressSizeToFit={true}    
                                onGridSizeChanged={onFirstDataRendered} 
                                //escape 문자 처리  
                                frameworkComponents={{escapeCharChangeForGrid}}
                                pinnedBottomRowData={pinnedBottomRowData}
                                 // overlay
                                 overlayLoadingTemplate={CONSTANTS.gridLoading}
                                 overlayNoRowsTemplate={CONSTANTS.gridNoRows}
                                >
                            </AgGridReact>
                        </div>
                    </div>
                <div className='modal-footer'>
                    <Button variant="light" size="md" onClick={onHide}>취소</Button>
                </div>
            </CustomModal>
                {/* </Modal.Body>
                <Modal.Footer>
                    <Button variant="light" size="md" onClick={onHide}>취소</Button>
                </Modal.Footer>
            </Modal> */}
        </>
    )
};
export default PdiGlovisIvm;