const path = require('path')                                        
const HtmlWebpackPlugin = require('html-webpack-plugin')  
const Dotenv = require('dotenv-webpack');
// const webpack = require('webpack');  
// const dotenv = require("dotenv");
// dotenv.config();

module.exports = (env, options) => { 

  return {
    mode: 'production',                                
    entry: './src/index.js',                            
    output: {                                           
        path: path.join(__dirname, '/build'),            
        filename: 'index.js'
    },
    devServer: {
        port: 3000, 
        historyApiFallback: true,
        client:{
          overlay: false, //Shows a full-screen overlay in the browser when there are compiler errors or warnings.
          webSocketURL: { hostname: undefined, pathname: undefined, port: '0' },
        }
    },
    module: {                                           
      rules: [
        {
          test: /\.(js|jsx)$/,
          exclude: /node_modules/,
          use: {
            loader: 'babel-loader',
            options: {
              presets: ["@babel/preset-env", ["@babel/preset-react", {"runtime": "automatic"}]]
            }
          }
        },
        {
          test: /\.css$/,
          use:[
            'style-loader',
            { 
              loader: "css-loader", options: { url: false } 
            },
          ] 
        },
        {
          test: /\.(jpe?g|png|gif|svg)$/i,
          use: [
            {
              loader: 'url-loader',
              options: {
                limit: 8192,
                name: 'assets/images/[name].[hash:8].[ext]',
              }
            }
          ]
        },
        {
          test: /\.svg$/,
          use: ['@svgr/webpack'],
        },
        {
          test: /\.(woff|woff2|eot|ttf|otf|ico)$/i,
          use: [
            {
              loader: 'file-loader',
              options: {
                name: 'assets/fonts/[name].[hash:8].[ext]',
              },
            },
          ],
        },
              
      ]
    },
    plugins: [
        new HtmlWebpackPlugin({
            // inject: true,
            // minify: true,
            template: 'public/index.html',         
        }),
        new Dotenv(),
        // new webpack.DefinePlugin({
        //   'process.env.NODE_ENV': JSON.stringify(process.env.NODE_ENV),
        //   'process.env.DEBUG': JSON.stringify(process.env.DEBUG),
        // })
        
    ]
  }
}