import React, {useState} from 'react';
import {FlexboxGrid,  Pagination} from 'rsuite'

const Total = ({total, limit, activePage, onChangePage, onChangeLimit}) => {

    const layout = ['total'];

    return(
        <FlexboxGrid justify="start" className='mt-3' >
            <Pagination
                layout={layout}
                prev
                last
                next
                first
                size="xs"
                maxButtons={10} 
                total={total} // rows number
                limit={limit}  // rows number per page.
                activePage={activePage}
                onChangePage={onChangePage}
                onChangeLimit={onChangeLimit}
            />
        </FlexboxGrid>
    )

}
export default Total;