// react
import React, { Suspense, lazy, useEffect } from 'react';
import {  Routes, Route, useLocation  } from 'react-router-dom';
import { TransitionGroup, CSSTransition } from 'react-transition-group';

// components
import BaseLayout from '../Layout/BaseLayout';
import BasePage from '../Layout/BasePage';
import PageLoader from './PageLoader';
// import PostListContainer from '../Contents/Test/PostListContainer';
// import PostContainer from '../Contents/Test/PostContainer';
// import TestQuery from '../Contents/Test/TestQuery';

// children components
const Login = lazy(() => import('../Contents/Auth/Login'));
const ErrorPage = lazy(() => import('../Contents/Auth/ErrorPage'));
const ErrorNet = lazy(() => import('../Contents/Auth/ErrorNet'));

// 재고관리
const TotalStockContainer = lazy(() => import('../Contents/Ivm/TotalStock/TotalStockContainer'));       // 총 재고관리
const SewonIvmContainer = lazy(() => import('../Contents/Ivm/SewonIvm/SewonIvmContainer'));             // 세원재고관리
const PdiIvmContainer = lazy(() => import('../Contents/Ivm/PdiIvm/PdiIvmContainer'));                   // 세원재고관리
const YongsanIvmContainer = lazy(() => import('../Contents/Ivm/YongsanIvm/YongsanIvmContainer'));       // 용산재고관리
const BoardList = lazy(() => import('../Contents/Ivm/Board/BoardList'));                                // 게시판
const BoardDetail = lazy(() => import('../Contents/Ivm/Board/BoardDetail'));                            // 게시판 상세
const BoardAdd = lazy(() => import('../Contents/Ivm/Board/BoardAdd'));                                  // 게시판 추가
const BoardUpdate = lazy(() => import('../Contents/Ivm/Board/BoardUpdate'));                            // 게시판 수정

// 제작준비
const ClcmList = lazy(() => import('../Contents/Mri/Clcm/ClcmList'));                       // 법규및번경관리
const ClcmAdd = lazy(() => import('../Contents/Mri/Clcm/ClcmAdd'));                         // 법규및번경관리 추가
const ClcmUpdate = lazy(() => import('../Contents/Mri/Clcm/ClcmUpdate'));                   // 법규및번경관리 수정
const ClcmDetail = lazy(() => import('../Contents/Mri/Clcm/ClcmDetail'));                   // 법규및번경관리 상세
const PrintOrderList = lazy(() => import('../Contents/Mri/PrintOrder/PrintOrderList'));     // 발주
const PrintOrderAdd = lazy(() => import('../Contents/Mri/PrintOrder/PrintOrderAdd'));     // 발주
const PrintOrderDetail = lazy(() => import('../Contents/Mri/PrintOrder/PrintOrderDetail')); // 발주 상세


// 발간현황
const PrintStateList = lazy(() => import('../Contents/Print/PrintState/PrintStateList'));       // 발간현황
const PrintStateDetail = lazy(() => import('../Contents/Print/PrintState/PrintStateDetail'));   // 발간현황 상세
const MonthPutList = lazy(() => import('../Contents/Print/MonthPut/MonthPutList'));             // 월간투입현황

// 선적관리
const ShipInfo = lazy(() => import('../Contents/Ship/ShipInfo/ShipInfo'));     // 선적관리

// 운영관리
const VehlCodeContainer = lazy(() => import('../Contents/Stm/VehlCode/VehlCodeContainer'));     // 차종코드관리
const LangCodeContainer = lazy(() => import('../Contents/Stm/LangCode/LangCodeContainer'));     // 언어코드관리
const NatCodeContainer = lazy(() => import('../Contents/Stm/NatCode/NatCodeContainer'));        // 국가코드관리
const PrintPageList = lazy(() => import('../Contents/Stm/PrintPage/PrintPageList'));            // 인쇄페이지관리
const NoticeList = lazy(() => import('../Contents/Stm/Notice/NoticeList'));                     // 공지사항
const NoticeAdd = lazy(() => import('../Contents/Stm/Notice/NoticeAdd'));                       // 공지사항 추가
const NoticeDetail = lazy(() => import('../Contents/Stm/Notice/NoticeDetail'));                 // 공지사항 상세
const NoticeUpdate = lazy(() => import('../Contents/Stm/Notice/NoticeUpdate'));                 // 공지사항 수정

// 시스템관리
const MemberContainer = lazy(() => import('../Contents/Sys/Member/MemberContainer'));   // 사용자관리
const MenuContainer = lazy(() => import('../Contents/Sys/Menu/MenuContainer'));         // 메뉴관리
const PgmContainer = lazy(() => import('../Contents/Sys/Pgm/PgmContainer'));            // 프로그램관리
const AuthContainer = lazy(() => import('../Contents/Sys/Auth/AuthContainer'));         // 권한관리
const SysCodeList = lazy(() => import('../Contents/Sys/SysCode/SysCodeList'));          // 시스템코드관리
const JobContainer = lazy(() => import('../Contents/Sys/Job/JobContainer'));            // 작업관리
const EmailContainer = lazy(() => import('../Contents/Sys/Email/EmailContainer'));      // 이메일관리
const LogContainer = lazy(() => import('../Contents/Sys/Log/LogContainer'));            // 로그관리

const waitFor = Tag => props => <Tag {...props}/>;

const noLayoutPages = [
    '/hd',
    '/kia',
    '/hd/partner',
    '/kia/partner',
    '/logout',
    '/errorPage',
    '/errorNet',
];

const BaseRoutes = () => {
    const location = useLocation();

    const currentKey = location.pathname.split('/')[1] || '/';
    const timeout = { enter: 500, exit: 500 };
    const animationName = 'rag-fadeIn'

    if(noLayoutPages.indexOf(location.pathname) > -1) {
        return (
            <BasePage>
                <Suspense fallback={<PageLoader />}>
                    <Routes location={location}>
                        <Route  path="/hd" element={<Login  />}></Route>
                        <Route  path="/kia" element={<Login  />}></Route>
                        <Route  path="/hd/partner" element={<Login  />}></Route>
                        <Route  path="/kia/partner" element={<Login  />}></Route>
                        <Route  path="/errorPage" element={<ErrorPage />}></Route>
                        <Route  path="/errorNet" element={<ErrorNet />}></Route>
                        {/* <Route  path="/logout" component={waitFor(Logout)}/> */}
                    </Routes>
                </Suspense>
            </BasePage>
        );
    }else {
        return (
            <BaseLayout>
                 <TransitionGroup>
                    <CSSTransition key={currentKey} timeout={timeout} classNames={animationName} exit={false}>
                        <div>
                            <Suspense fallback={<PageLoader/>}>
                                <Routes location={location}>

                                    <Route path="/" element={<TotalStockContainer />}></Route>
                                    <Route path="/totalStock" element={<TotalStockContainer />}></Route>
                                    <Route path="/sewonIvm" element={<SewonIvmContainer />}></Route>
                                    <Route path="/pdiIvm" element={<PdiIvmContainer />}></Route>
                                    <Route path="/yongsanIvm" element={<YongsanIvmContainer />}></Route>

                                    <Route path="/board" element={<BoardList />}></Route>
                                    <Route path="/board/add" element={<BoardAdd />}></Route>
                                    <Route path="/board/detail" element={<BoardDetail />}></Route>
                                    <Route path="/board/update" element={<BoardUpdate />}></Route>
                                    
                                    <Route path="/clcm" element={<ClcmList />}></Route>
                                    <Route path="/clcm/add" element={<ClcmAdd />}></Route>
                                    <Route path="/clcm/detail" element={<ClcmDetail />}></Route>
                                    <Route path="/clcm/update" element={<ClcmUpdate />}></Route>
                                    <Route path="/printOrder" element={<PrintOrderList />}></Route>
                                    <Route path="/printOrder/add" element={<PrintOrderAdd />}></Route>
                                    <Route path="/printOrder/detail" element={<PrintOrderDetail />}></Route>

                                    <Route path="/printState" element={<PrintStateList />}></Route>
                                    <Route path="/printState/detail" element={<PrintStateDetail />}></Route>
                                    <Route path="/monthPut" element={<MonthPutList />}></Route>

                                    <Route path="/shipInfo" element={<ShipInfo />}></Route>
                                    
                                    <Route path="/vehlCode" element={<VehlCodeContainer />}></Route>
                                    <Route path="/langCode" element={<LangCodeContainer />}></Route>
                                    <Route path="/natCode" element={<NatCodeContainer />}></Route>
                                    <Route path="/printPage" element={<PrintPageList />}></Route>
                                    <Route path="/notice" element={<NoticeList />}></Route>
                                    <Route path="/notice/add" element={<NoticeAdd />}></Route>
                                    <Route path="/notice/detail" element={<NoticeDetail />}></Route>
                                    <Route path="/notice/update" element={<NoticeUpdate />}></Route>

                                    <Route path="/member" element={<MemberContainer />}></Route>
                                    <Route path="/menu" element={<MenuContainer />}></Route>
                                    <Route path="/pgm" element={<PgmContainer />}></Route>
                                    <Route path="/auth" element={<AuthContainer />}></Route>
                                    <Route path="/sysCode" element={<SysCodeList />}></Route>
                                    <Route path="/job" element={<JobContainer />}></Route>
                                    <Route path="/email" element={<EmailContainer />}></Route>
                                    <Route path="/log" element={<LogContainer />}></Route>

                                    {/* <Route path="*" component={waitFor(ErrorPage)} /> */}
                                    <Route path="*" element={<ErrorPage />}></Route>
                                </Routes>
                             </Suspense>
                        </div>
                    </CSSTransition>
                </TransitionGroup> 
            </BaseLayout>
        );
    }

};
export default BaseRoutes;