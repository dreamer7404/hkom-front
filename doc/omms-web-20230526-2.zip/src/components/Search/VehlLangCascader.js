/* eslint-disable react-hooks/exhaustive-deps */
import React, {useState, useEffect} from 'react';
import {Row, Col} from 'react-bootstrap';
import {Form, Button, Schema, Panel, Message, toaster, FlexboxGrid, MultiCascader} from 'rsuite';

//--------------  서버데이터용 필수 -------------------------------
import { useQuery} from 'react-query';
import { getData } from '../../utils/async';
import { API, CONSTANTS } from '../../utils/constants';
import useStore from '../../utils/store';
import { escapeCharChange} from '../../utils/commUtils';
//--------------// 서버데이터용 필수 -------------------------------

//'setSelectedLangCdByVehl'는 부모 컴포넌트에 값을 세팅합니다.
const VehlLangCascader = ({setSelectedLangCdByVehl, formErrorStatus, firstRender}) => {

    const langCdByVehl = useQuery([API.langByVehlCombo,''], () => getData(API.langByVehlCombo,''), {
      select: data => data.map((item) => (item&&{ label: escapeCharChange(item.label), value: item.value
          , children: item.children && item.children.map(item2 => 
              ({ label: escapeCharChange(item2.label), value: item2.value})
          ) 
      }))
    });

    const [langCdByVehlCombo, setLangCdByVehlCombo] = useState([]);
    const [unCheckableLangCdByVehlCombo, setUnCheckableLangCdByVehlCombo] = useState([]);
    useEffect(() => {
        if(langCdByVehl.isSuccess){
            setLangCdByVehlCombo(langCdByVehl.data)
            setUnCheckableLangCdByVehlCombo(
                langCdByVehl.data.map(item => {
                    if(!item.children){
                        return item.value
                    }
                })
            )
        }
    }, [langCdByVehl.status])

    const [onCheckedValue, setOnCheckedValue] = useState([])
    useEffect(() => {
        setSelectedLangCdByVehl(onCheckedValue)
    }, [onCheckedValue])

    const onCheck = (a,b,c) =>{
        // console.log(a)
        // console.log(b)
        // console.log(c)
        
        //언어 클릭시
        if(b.parent !== null){
            const qltyVehlCd = b.parent.value
            const qltyVehlNm = b.parent.label
            const langCd = b.value.substring(b.value.lastIndexOf('___') + 3)
            const langCdNm = b.label
            if(c){
                setOnCheckedValue(prevState => [...prevState, { ['qltyVehlCd']: qltyVehlCd, ['qltyVehlNm']: qltyVehlNm, ['langCd']: langCd, ['langCdNm']: langCdNm }])
            } else {
                setOnCheckedValue((prevArr) => prevArr.filter(item => {
                    if(JSON.stringify(item)!== JSON.stringify({ ['qltyVehlCd']: qltyVehlCd, ['qltyVehlNm']: qltyVehlNm, ['langCd']: langCd, ['langCdNm']: langCdNm })){
                        return item
                    }
                }))
            }
            
        } else {
            //차종클릭시 - 하위 언어가 없는 경우
            if(b.children === null || b.children === undefined){
                alert('적용가능한 언어가 없습니다.')
            } 
            //차종클릭시 - 하위 언어가 있는 경우
            else {
                b.children.map(item => {
                    const qltyVehlCd = b.value
                    const qltyVehlNm = b.label
                    const langCd = item.value.substring(item.value.lastIndexOf('___') + 3)
                    const langCdNm = item.label
                    if(c){
                        setOnCheckedValue(prevState => [...prevState, { ['qltyVehlCd']: qltyVehlCd, ['qltyVehlNm']: qltyVehlNm, ['langCd']: langCd, ['langCdNm']: langCdNm }])
                    } else {
                        setOnCheckedValue((prevArr) => prevArr.filter(item => {
                            if(JSON.stringify(item)!== JSON.stringify({ ['qltyVehlCd']: qltyVehlCd, ['qltyVehlNm']: qltyVehlNm, ['langCd']: langCd, ['langCdNm']: langCdNm })){
                                return item
                            }
                        }))
                    }
                })
                
            }
        }
    }

    const onClean = e =>{
        setOnCheckedValue([])
    }

    const headers = ['차종', '언어'];

    return (
        <>
            <MultiCascader 
                className="multi-cascader"
                size="sm"
                menuWidth={250}
                style={{fontSize:'12px', width:'100%', maxWidth:'1200px'}}
                placeholder="차종 및 언어를 선택해주세요"
                // data={options}
                data={langCdByVehlCombo}
                onCheck={onCheck}
                onClean={onClean}
                error={formErrorStatus}
                name="langCdByVehlList"
                uncheckableItemValues={unCheckableLangCdByVehlCombo}
                renderMenu={(children, menu, parentNode, layer) => {
                    return (
                        <div>
                          <div
                              style={{
                              background: '#f8f8f8',
                              padding: '4px 10px',
                              color: ' #000',
                              textAlign: 'center',
                              fontSize:'12px',
                              fontWeight:600
                              }}
                          >
                              {headers[layer]}
                          </div>
                          {menu}
                        </div>
                    );
                }} 
              />
              <Form.ErrorMessage show={firstRender && formErrorStatus} >
                {formErrorStatus}
              </Form.ErrorMessage>
        </>
    );

};
export default VehlLangCascader;