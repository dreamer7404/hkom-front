/* eslint-disable react-hooks/exhaustive-deps */
import React, {useState, useEffect}  from 'react';
import {Row, Col} from 'react-bootstrap';
import {Form, SelectPicker } from 'rsuite';
import useStore from '../../utils/store';

//--------------  서버데이터용 필수 -------------------------------
import { useQuery} from 'react-query';
import { getData } from '../../utils/async';
import { API, CONSTANTS } from '../../utils/constants';
import { escapeCharChange} from '../../utils/commUtils';
//--------------// 서버데이터용 필수 -------------------------------

const VehlTypeForPop = ({onChangeVehlParam}) => {

    const {keyword } = useStore(); 
    
    //최초 파라미터 세팅은 store에서 가져오는게 나을듯..
    const [dlExpdPdiCd, setDlExpdPdiCd] = useState(keyword.dlExpdPdiCd);
    const [qltyVehlCd, setQltyVehlCd] = useState(keyword.qltyVehlCd);
    const [mdlMdyCd, setMdlMdyCd] = useState(keyword.mdlMdyCd);

    //부모 컴포넌트에 던져줄 파라미터들..
    const paramForPop = {
        dlExpdPdiCd : dlExpdPdiCd,
        qltyVehlCd : qltyVehlCd,
        mdlMdyCd : mdlMdyCd,
    }

    //부모 컴포넌트에 던져주기..
    useEffect(() => {
        //아래 함수는 부모 컴포넌트에서 만들어서 가져와야함..
        onChangeVehlParam(paramForPop)
    }, [dlExpdPdiCd, qltyVehlCd, mdlMdyCd])

    const onChangePdiCombo = val => {
        setDlExpdPdiCd(val);
    };
    const onChangeVehlCombo = val => {
        setQltyVehlCd(val);
    };
    const onChangeMdyCombo = val => {
        setMdlMdyCd(val);
    };


    // pdiCombo API가져오기
    const pdiParams = {
        bDate: keyword.bDate && keyword.bDate.replace(/-/gi, '')
    };
    const pdiCombo = useQuery([API.pdiCombo, pdiParams], () => getData(API.pdiCombo, pdiParams), {
            select: data => [{label: CONSTANTS.labelAll, value: CONSTANTS.valueAll}].concat(data.map((item) => ({ label: escapeCharChange(item.dlExpdPrvsNm), value: item.dlExpdPdiCd })))
    }); 

    // vehlCombo API가져오기
    const vehlParams = {
        dlExpdPdiCd: dlExpdPdiCd, 
        bDate: keyword.bDate && keyword.bDate.replace(/-/gi, '')
    };
    const vehlCombo = useQuery([API.vehlCombo, vehlParams], () => getData(API.vehlCombo, vehlParams), {
            select: data => [{label: CONSTANTS.labelAll, value: CONSTANTS.valueAll}].concat(data.map((item) => ({ label: escapeCharChange(item.qltyVehlNm), value: item.qltyVehlCd })))
    }); 

    // mdlMdyCd API가져오기
    const mdyCombo = useQuery([API.mdyCombo], () => getData(API.mdyCombo), {
            select: data => [{label: CONSTANTS.labelAll, value: CONSTANTS.valueAll}].concat(data.map((item) => ({ label: item, value: item })))
    });

    return (
        <>
            <Form.ControlLabel column="sm">차종</Form.ControlLabel>
            <Row className="select-wrap">
                <Col sm={5}> 
                    <SelectPicker size="sm"
                        value={dlExpdPdiCd} 
                        data={pdiCombo && pdiCombo.data ? pdiCombo.data : []} 
                        onChange={onChangePdiCombo}
                        placeholder={CONSTANTS.labelAll}
                        cleanable={false}
                        searchable={false}
                        block={true}
                    />
                </Col>
                <Col sm={5}> 
                    <SelectPicker size="sm"
                        value={qltyVehlCd} 
                        data={vehlCombo && vehlCombo.data ? vehlCombo.data : []}  
                        onChange={onChangeVehlCombo}
                        placeholder={CONSTANTS.labelAll}
                        cleanable={false}
                        searchable={true}
                        block={true}
                    />
                </Col>
                <Col sm={2}> 
                    <SelectPicker size="sm" style={{width: '100%'}}
                        value={mdlMdyCd} 
                        data={mdyCombo && mdyCombo.data ? mdyCombo.data : []} 
                        onChange={onChangeMdyCombo}
                        placeholder={mdlMdyCd}
                        cleanable={false}
                        searchable={false}
                        block={true}
                    />
                    </Col>
            </Row>
        </>
    );

};
export default VehlTypeForPop;