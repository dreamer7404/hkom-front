/* eslint-disable react-hooks/exhaustive-deps */
import React, {useState, useMemo, useEffect, useRef} from 'react';
import { Button, Modal, Table} from 'react-bootstrap';
import { Form, SelectPicker, Schema, Notification, useToaster } from 'rsuite';
import { AgGridReact } from 'ag-grid-react';

//--------------  서버데이터용 필수 -------------------------------
import { useQuery, useQueryClient, useMutation} from 'react-query';
import { getData, postData } from '../../../../utils/async';
import { API, CONSTANTS } from '../../../../utils/constants';
//--------------// 서버데이터용 필수 -------------------------------
import { escapeCharChangeForGrid, escapeCharChange} from '../../../../utils/commUtils';

const { StringType} = Schema.Types;
const model = Schema.Model({
    userNm: StringType().isRequired('이름을 입력해주세요.')
                            .pattern(/^[가-힣a-zA-Z0-9]+$/, '특수문자는 _ . 만 입력가능합니다')
                            .rangeLength(2, 30, '2-30자로 입력해주세요'),
    userEmlAdr: StringType().isRequired('이메일을 입력해주세요.')
                            .isEmail('이메일 형식에 맞게 입력해주세요.')
                            .maxLength(90, '이메일주소가 너무 깁니다.'),
    blnsCoCd: StringType().isRequired('소속회사를 선택해 주세요.'),
    userDcd: StringType().isRequired('부서를 선택해 주세요.'),
    grpCd: StringType().isRequired('그룹을 선택해 주세요.'),
    useYn: StringType().isRequired('사용유무를 선택해 주세요.'),
});


const MemberUpdate = ({show, data, onHide}) => {

    const gridRef = useRef();
    const toaster = useToaster();
    const queryClient = useQueryClient()

    // 회사목록 가져오기
    // const paramsCo = {dlExpdGCd: CONSTANTS.grpCdCo};
    // const coCombo = useQuery([API.codeCombo, paramsCo], () => getData(API.codeCombo, paramsCo));
    const paramsCo = {
        dlExpdGCd: '0001'
    };
    const coCombo = useQuery([API.codeCombo, paramsCo], () => getData(API.codeCombo, paramsCo), {
            select: data => [{label: CONSTANTS.labelAll, value: CONSTANTS.valueAll}].concat(data.filter(item => item.value !== '09'))
    });


    // 부서목록(용역회사) 가져오기
    const paramsDept = {dlExpdGCd: CONSTANTS.grpCdDept};
    const deptCombo = useQuery([API.codeCombo, paramsDept], () => getData(API.codeCombo, paramsDept));

    // 그룹목록 가져오기
    const grpCombo = useQuery([API.grpCombo], () => getData(API.grpCombo));

    // 비밀번호 초기화
    const initUserPwMutate = useMutation(param => postData(API.initUserPw, param, CONSTANTS.update),{
        onSuccess: res => {
            if(res === 1){
                toaster.push(<Notification type='success' header='성공' closable >
                    비밀번호가 초기화되었습니다.<br />이메일로 전송된 임시비밀번호로 로그인해주세요.
                    </Notification>);
            }else{
                toaster.push(<Notification type='error' header='실패' closable >
                    비밀번호가 초기화 실패했습니다.<br /> 관리자에게 문의해주세요.
                    </Notification>);
            }
        }
    });

    // Form 정의
    const formRef = React.useRef();
    const [formError, setFormError] = React.useState({});
    const [formValue, setFormValue] = React.useState({
        userEeno: '',
        userNm: '',       // 이름
        userEmlAdr: '',   // 이메일
        blnsCoCd: '',     // 회사코드
        userDcd: '',      // 부서코드
        grpCd: '',        // 그룹코드
        useYn: '',         // 사용유무
        usrVehls:[],
    });

    // 사용자정보 & 차종권한리스트 조회
    const paramsUsrAndVehls = {
        userEeno: data.userEeno,
        // dlExpdCoCd: data.blnsCoCd
    };
    const queryResult = useQuery([API.usrAndVehls,  paramsUsrAndVehls], () => getData(API.usrAndVehls,  paramsUsrAndVehls),{staleTime: 0});

    // 사용자정보 formValue에 입력
    useEffect(() => {
        if(queryResult.isSuccess){
            const user = queryResult.data.user;
             setFormValue({
                 userEeno: data.userEeno,   // 아이디
                 userNm: user.userNm,       // 이름
                 userEmlAdr: escapeCharChange(user.userEmlAdr),   // 이메일
                 blnsCoCd: user.blnsCoCd,     // 회사코드
                 userDcd: user.userDcd,      // 부서코드
                 grpCd: user.grpCd,        // 그룹코드
                 useYn: user.useYn,         // 사용유무
                 usrVehls:[],
             });
        }
    },[queryResult.status]);

    const [grpList, setgrpList] = useState([]);
    useEffect(() => {
        if(grpCombo.isSuccess){
            setgrpList(grpCombo.data);
        }
    },[grpCombo.status])

    // 사용자 수정하기
    const usrmgmtMutate = useMutation((params => postData(API.usrmgmt, params, CONSTANTS.update)),{
        onSuccess: res => {
            if(res > 0){
                toaster.push(<Notification type='success' header='성공' closable >
                     수정이 완료되었습니다.
                    </Notification>);

                onHide(true); // // 창닫기 & refetch
            }else{
                toaster.push(<Notification type='error' header='실패' closable >
                    수정이 실패했습니다.<br /> 관리자에게 문의해주세요.
                    </Notification>);
                onHide(false); // 창닫기
            }
           
        }
    });

    // 저장버튼 클릭
    const handleSubmit = () => {
        // validation 체크
        if (!formRef.current.check()) {
            return;
        }

        // grid 선택된목록 가져오기
        formValue.usrVehls = gridRef.current.api.getSelectedRows(); 

        // 사용자 수정 실행
        usrmgmtMutate.mutate(formValue);
    };
   
    const defaultColDef = useMemo(() => {
        return {
            initialWidth: 90,
            resizable:true,
        };
    }, []);



    const columnDefs = [
        {
            field: 'authVehl',
            checkboxSelection: true,
            headerCheckboxSelection: true,
            width:45,
            maxWidth:45,
            minWidth:45
        },
        {
            headerName: '차종',
            children: [
                { 
                    headerName:'차종코드', 
                    field: 'qltyVehlCd',
                    maxWidth:100,
                    sortable:true,
                    filter: 'agTextColumnFilter',
                    floatingFilter: true,
                    suppressMenu: true,
                    filterParams: {
                        filterOptions: ['contains'],
                    }},
                { 
                    headerName:'차종명',
                    field: 'qltyVehlNm', 
                    filter: 'agTextColumnFilter',
                    sortable:true,
                    floatingFilter: true,
                    suppressMenu: true,
                    cellRenderer:"escapeCharChangeForGrid",
                    filterParams: {
                        filterOptions: ['contains'],
                    } },
                    
            ],
        },
    ]

    // Grid Init 
    const onFirstDataRendered = (params) => {
        params.api.sizeColumnsToFit();

        // 데이타에서 authVehl === 'Y'인것은 체크
        gridRef.current.api.forEachNode((node) =>
            node.setSelected(!!node.data && node.data.authVehl === 'Y')
        );
    };


    // 부서명을 회사구분에따른 필터링
    const [depts, setDepts] = useState([]);
    useEffect(() => {
        if(deptCombo.isFetched && deptCombo.data){
            if(formValue.blnsCoCd === ''){
                setDepts(deptCombo.data); 
            }else if(formValue.blnsCoCd === '01' || formValue.blnsCoCd === '02'){ // 현재/기아
                setDepts(deptCombo.data.filter(d => (d.value === '' || d.value === '01')));
            }else if(formValue.blnsCoCd === '03'){ // 외주
                setDepts(deptCombo.data.filter(d => (d.value !== '01' && d.value !== '03' &&  d.value !== '04' && d.value !== '05' && d.value !== '06' ))
                        .concat(deptCombo.data.filter(d => (d.value === '06')))); //기타 뒤에추가
                setFormValue(p => ({...p, userDcd: ''})); // 선택을 default
            }else if(formValue.blnsCoCd === '04'){ // PDI
                setDepts(deptCombo.data.filter(d => (d.value === '' || d.value === '03')));
            }else if(formValue.blnsCoCd === '05'){ // 용산
                setDepts(deptCombo.data.filter(d => (d.value === '' || d.value === '05')));
            }else if(formValue.blnsCoCd === '06'){ // 인쇄업체
                setDepts(deptCombo.data.filter(d => (d.value === '' || d.value === '04'))); // 세원
            }else if(formValue.blnsCoCd === '07'){ // 기타
                setDepts(deptCombo.data.filter(d => (d.value === '' || d.value === '06'))); // 기타
            }
            // setFormValue(p => ({...p, userDcd: ''})); // 초기에 선택
        }
    },[formValue.blnsCoCd])


    const onInitPassword = () => {
        initUserPwMutate.mutate({userEeno: data.userEeno});
    };


    return (
        <>
            <Form
                ref={formRef}
                checkTrigger="change"
                onChange={setFormValue}
                onCheck={setFormError}
                formValue={formValue}
                model={model}>
                <Modal show={show} onHide={onHide} backdrop="static" keyboard={false} centered size="lg" className="modal-custom">
                    <Modal.Header closeButton>
                        <Modal.Title>사용자 상세/수정</Modal.Title>
                    </Modal.Header>
                        <Modal.Body>
                            <Table className="tbl-hor" bordered>
                                <colgroup>
                                    <col style={{width:'15%'}}></col>
                                    <col style={{width:'35%'}}></col>
                                    <col style={{width:'15%'}}></col>
                                    <col style={{width:'35%'}}></col>
                                </colgroup>
                                <tbody>
                                    <tr>
                                        <th className="essen">아이디</th>
                                        <td>
                                            {queryResult.isSuccess && queryResult.data.user.userEeno}
                                        </td>
                                        <th className="essen">이름</th>
                                        <td>
                                            <Form.Control name="userNm" size="sm" type="text" placeholder="이름을 입력해주세요" />
                                        </td>
                                    </tr>
                                    <tr>
                                        <th className="essen">이메일</th>
                                        <td colSpan="3">
                                            <Form.Control name="userEmlAdr" size="sm" type="text" placeholder="이메일을 입력해주세요" />
                                        </td>
                                    </tr>
                                    <tr>
                                        <th className="essen">구분</th>
                                        <td>
                                            <Form.Control name="blnsCoCd" size="sm" 
                                                accepter={SelectPicker} 
                                                searchable={false}
                                                cleanable={false}
                                                data={coCombo.isFetched && coCombo.data}
                                            ></Form.Control>
                                        </td>
                                        <th className="essen">업무/회사</th>
                                        <td>
                                            <Form.Control name="userDcd" size="sm"
                                                    placeholder={'선택'}
                                                    accepter={SelectPicker} 
                                                    searchable={false}
                                                    cleanable={false}
                                                    data={depts}
                                                ></Form.Control>
                                        </td>
                                    </tr>
                                    <tr>
                                        <th className="essen">사용자그룹</th>
                                        <td>
                                            <Form.Control name="grpCd" size="sm" 
                                                accepter={SelectPicker} 
                                                searchable={false}
                                                cleanable={false}
                                                // data={grpCombo.isFetched && grpCombo.data}
                                                data={grpList}
                                            ></Form.Control>
                                        </td>
                                        <th className="essen">사용여부</th>
                                        <td>
                                            <Form.Control name="useYn" size="sm" 
                                                accepter={SelectPicker} 
                                                searchable={false}
                                                cleanable={false}
                                                data={[
                                                    {label: '사용', value: 'Y'},
                                                    {label: '미사용', value: 'N'},
                                                ]}
                                            ></Form.Control>
                                        </td>
                                    </tr>
                                    <tr>
                                        <th>권한차종</th>
                                        <td colSpan="3">
                                            <div className="ag-theme-alpine" style={{height:300}}>
                                                <AgGridReact
                                                    ref={gridRef}
                                                    rowData={queryResult.isSuccess && (queryResult.data.vehl || [])}
                                                    columnDefs={columnDefs}
                                                    defaultColDef={defaultColDef}
                                                    rowSelection={'multiple'}

                                                    suppressRowClickSelection= {true} 
                                                    onFirstDataRendered={onFirstDataRendered}
                                                    suppressSizeToFit={true}    
                                                    onGridSizeChanged={onFirstDataRendered}    

                                                    frameworkComponents={{
                                                        escapeCharChangeForGrid
                                                    }}
                                                    
                                                    // overlay
                                                    overlayLoadingTemplate={CONSTANTS.gridLoading}
                                                    overlayNoRowsTemplate={CONSTANTS.gridNoRows}

                                                    >
                                                </AgGridReact>
                                            </div>
                                        </td>
                                    </tr>
                                </tbody>
                            </Table>
                        </Modal.Body>

                        <Modal.Footer>
                            <Button variant="light" size="md" onClick={onHide}>취소</Button>
                            <Button variant="outline-secondary" size="md" onClick={onInitPassword}>비밀번호 초기화</Button>
                            <Button variant="primary" size="md" onClick={handleSubmit} >저장</Button>
                        </Modal.Footer>
                </Modal>
            </Form>
        </>
    );

};
export default MemberUpdate;