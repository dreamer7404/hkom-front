import React from 'react';
import {Row, Col} from 'react-bootstrap';
import {Form, DatePicker, InputGroup} from 'rsuite';
import { utcToLocalDate } from '../../utils/commUtils'; //'../../../utils/commUtils';

//--------------  서버데이터용 필수 -------------------------------
import useStore from '../../utils/store';
//--------------// 서버데이터용 필수 -------------------------------


const SeDate = () => {

    const {keyword, setSDate, setEDate } = useStore(); 

    const onChangeDateStart = val => {
        setSDate(utcToLocalDate(val));
    }
    const onChangeDateEnd = val => {
        setEDate(utcToLocalDate(val));
    }

    return (
        <>
            <Form.ControlLabel column="sm">기간</Form.ControlLabel>
            <Row className="select-wrap">
                <Col>
                    <InputGroup>
                        <DatePicker oneTap block size="sm" style={{width: '100%'}} 
                            value={keyword.sDate ? new Date(keyword.sDate)  : new Date()}
                            ranges={[
                                {
                                label: '오늘',
                                value: new Date()
                                }
                            ]}
                            format="yyyy-MM-dd"
                            onChange={onChangeDateStart} 
                            cleanable={false}
                        />
                        <InputGroup.Addon>~</InputGroup.Addon>
                        <DatePicker oneTap block size="sm" style={{width: '100%'}} 
                            value={keyword.eDate ? new Date(keyword.eDate)  : new Date()}
                            ranges={[
                                {
                                label: '오늘',
                                value: new Date()
                                }
                            ]}
                            format="yyyy-MM-dd"
                            onChange={onChangeDateEnd} 
                            cleanable={false}
                        />
                    </InputGroup>
                </Col>
            </Row>
        </>
    );

};
export default SeDate;