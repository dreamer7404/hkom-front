import React, {useState, useMemo} from 'react';
import { AgGridReact } from 'ag-grid-react';
import {Button, Modal, Table} from 'react-bootstrap';
import {Form} from 'rsuite';

const NatLangUpload = ({show, onHide}) => {

     const [rowData] = useState([

    ]);

    const columnDefs = [
        {
          headerName: '국가코드',
          field: 'natCd',
        },
        {
          headerName: '차종코드',
          field: 'vehlCd',
        },
        {
          headerName: '연식',
          field: 'carMdy',
        },
        {
          headerName: '언어코드',
          field: 'langCd',
          maxWidth:'80',
        },
        {
          headerName: '사용여부',
          field: 'useYn',
          maxWidth:'80',
        },
    ]

    const defaultColDef = useMemo(() => {
        return {
            initialWidth: 90,
            sortable: true,
            resizable:true,
        };
    }, []);

    const onFirstDataRendered = (params) => {
        params.api.sizeColumnsToFit();
    };

    return (
        <>
            <Form>
                <Modal show={show} onHide={onHide} backdrop="static" keyboard={false} centered size="lg" className="modal-custom">
                    <Modal.Header closeButton>
                        <Modal.Title>국가별 언어등록(액셀 업로드)</Modal.Title>
                    </Modal.Header>
                        <Modal.Body>
                            <div className="grid-btn-wrap">
                                <div className="right-align">
                                    {/*--------- 버튼 -----------*/}
                                    <Button variant="outline-secondary" size="sm">Sample</Button>{' '}
                                    <Button variant="outline-secondary" size="sm">업로드</Button>{' '}
                                </div>
                            </div>
                            <Table className="tbl-hor" bordered>
                                <colgroup>
                                    <col style={{width:'30%'}}></col>
                                    <col style={{width:''}}></col>
                                </colgroup>
                                <tbody>
                                    <tr>
                                        <th className="essen">첨부파일</th>
                                        <td>
                                            
                                        </td>
                                    </tr>
                                </tbody>
                            </Table>
                            <div className="ag-theme-alpine mt-10" style={{height:300, minWidth:300}}>
                            <AgGridReact
                                rowData={rowData}
                                columnDefs={columnDefs}
                                defaultColDef={defaultColDef}
                                rowSelection={'multiple'}
                                suppressRowClickSelection= {true} 
                                onFirstDataRendered={onFirstDataRendered}
                                suppressSizeToFit={true}    
                                onGridSizeChanged={onFirstDataRendered}     
                                >
                            </AgGridReact>
                        </div>
                        </Modal.Body>
                        <Modal.Footer>
                            <Button variant="light" size="md" onClick={onHide}>취소</Button>
                            <Button variant="primary" size="md" onClick={onHide} >저장</Button>
                        </Modal.Footer>
                </Modal>
            </Form>
        </>
    );

};
export default NatLangUpload;