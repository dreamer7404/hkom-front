import React from 'react';

const LangSelect = () => {

    return (
        <>
            <h3>언어선택</h3>
        </>
    );

};
export default LangSelect;