// react
import React, {useState, useMemo} from 'react';
import { AgGridReact } from 'ag-grid-react';
import {Button, Table} from 'react-bootstrap';
import {Form, SelectPicker, InputGroup, DatePicker} from 'rsuite';

import { utcToLocalDate } from '../../../../utils/commUtils'; //'../../../utils/commUtils';
import useStore from '../../../../utils/store';

const NoticeUpdate = () => {

    const {keyword, setSDate, setEDate } = useStore(); 

    const onChangeDateStart = val => {
        setSDate(utcToLocalDate(val));
    }
    const onChangeDateEnd = val => {
        setEDate(utcToLocalDate(val));
    }

    const [rowData] = useState([
        {co: "현대자동차", part: "자동차업체", userId: "user_01", userNm: "홍길동"},
    ]);

    const columnDefs = [
        {
          checkboxSelection: true,
          headerCheckboxSelection: true,
          width:45,
          maxWidth:45,
          minWidth:45,
        },
        {
          headerName: '회사명',
          field: 'co',
        },
        {
          headerName: '부서명',
          field: 'part',
        },
        {
          headerName: '아이디',
          field: 'userId',
        },
        {
          headerName: '이름',
          field: 'userNm',
        },
    ]

    const defaultColDef = useMemo(() => {
        return {
            initialWidth: 90,
            sortable: true,
        };
    }, []);


    const onFirstDataRendered = (params) => {
        params.api.sizeColumnsToFit();
       
        params.api.forEachNode((node) =>
         node.setSelected(!!node.data && node.data.userName !== '홍길동')
        );
    };

    const saveButton = () => {
        window.location.href="./BoardDetail"
    }

    const listButton = () => {
        window.location.href="./BoardList"
    }

    return (
        <>
            <div className="write-wrap">
                <Form>
                    <Table className="tbl-hor" bordered>
                        <colgroup>
                            <col style={{width:'15%'}}></col>
                            <col style={{width:'35%'}}></col>
                            <col style={{width:'15%'}}></col>
                            <col style={{width:'35%'}}></col>
                        </colgroup>
                        <tbody>
                            <tr>
                                <th className="">게시여부</th>
                                <td>
                                    {/* <Form.Select size="sm" xs={4}>
                                        <option value="">분류를 선택해주세요</option>
                                        <option value="">불용재고</option>
                                        <option value="">교체투입</option>
                                        <option value="">분리투입</option>
                                        <option value="">기타</option>
                                    </Form.Select>  */}
                                    <SelectPicker size="sm" data={[{ label: "게시"}]} searchable={false} cleanable={false} />
                                </td>
                                <th>게시기간</th>
                                <td>
                                    <InputGroup>
                                        <DatePicker oneTap block size="sm" style={{width: '100%'}} 
                                            value={keyword.sDate ? new Date(keyword.sDate)  : new Date()}
                                            ranges={[
                                                {
                                                label: '오늘',
                                                value: new Date()
                                                }
                                            ]}
                                            format="yyyy-MM-dd"
                                            onChange={onChangeDateStart} 
                                            cleanable={false}
                                        />
                                        <InputGroup.Addon>~</InputGroup.Addon>
                                        <DatePicker oneTap block size="sm" style={{width: '100%'}} 
                                            value={keyword.eDate ? new Date(keyword.eDate)  : new Date()}
                                            ranges={[
                                                {
                                                label: '오늘',
                                                value: new Date()
                                                }
                                            ]}
                                            format="yyyy-MM-dd"
                                            onChange={onChangeDateEnd} 
                                            cleanable={false}
                                        />
                                    </InputGroup>
                                </td>
                            </tr>
                            <tr>
                                <th className="essen">업무구분</th>
                                <td colSpan="3">
                                    <SelectPicker size="sm" data={[{ label: "재고관리"}]} searchable={false} cleanable={false} />
                                </td>
                            </tr>
                            <tr>
                                <th className="essen">게시대상</th>
                                <td colSpan="3">
                                    <div className="ag-theme-alpine" style={{height: 250, transition:'all ease .3s'}}>
                                        <AgGridReact
                                            rowData={rowData}
                                            columnDefs={columnDefs}
                                            defaultColDef={defaultColDef}
                                            rowSelection={'multiple'}
                                            suppressRowClickSelection= {true} 
                                            onFirstDataRendered={onFirstDataRendered}
                                            suppressSizeToFit={true}    
                                            onGridSizeChanged={onFirstDataRendered}    
                                            >
                                        </AgGridReact>
                                    </div>
                                </td>
                            </tr>
                            <tr>
                                <th className="essen">제목</th>
                                <td colSpan="3">
                                    <Form.Control size="sm" type="text" defaultValue="공지사항 제목입니다." />
                                </td>
                            </tr>
                            <tr>
                                <th className="essen">내용</th>
                                <td colSpan="3">
                                    <Form.Control size="sm" type="text" defaultValue="공지사항 내용입니다." />
                                </td>
                            </tr>
                            <tr>
                                <th>첨부파일</th>
                                <td colSpan="3">
                                    
                                </td>
                            </tr>
                        </tbody>
                    </Table>
                </Form>
                <div className="btn-wrap">
                    <div className="right-align">
                        <Button variant="light" onClick={listButton}>취소</Button>{' '}
                        <Button className="" variant="primary" size="md" onClick={saveButton}>저장</Button>
                    </div>
                </div>
            </div>
        </>
    )
};
export default NoticeUpdate;