import React  from 'react';

const SysCodeDelete = () => {

    return (
        <>
            <h3>시스템코드 삭제</h3>
        </>
    );

};
export default SysCodeDelete;