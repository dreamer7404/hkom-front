// react
import React, {useEffect, useState, useCallback} from 'react';

import { DEXT5Editor } from 'dext5editor-react';

import { useQuery, useMutation, useQueryClient } from 'react-query';

import { Link } from 'react-router-dom';

const Dashboard = () => {

    
    return (
        <div >
            Dashboard...
            <div>
                <Link to='/totalStock'>totalStock</Link>
            </div>
            <div>
                {/* <PostListContainer /> */}
            </div>
         

            <div>
                <Link to="/testQuery">testQuery</Link>
            </div>
            

            <DEXT5Editor
					debug={true}
					id="editor1"
					componentUrl="/dext5editor/js/dext5editor.js"
					config={{ DevelopLangage:'NONE' }}
					initData="<p>Hello <strong>DEXT5 Editor</strong> world!</p>"
				/>
           
        </div>
    )
};
export default Dashboard;