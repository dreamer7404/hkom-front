// react
import React, {useEffect} from 'react';

// react-bootstrap
import Container from 'react-bootstrap/Container';
import {  CustomProvider } from 'rsuite';
import ko from 'rsuite/locales/ko_KR'; // => rsuite/cjs/locales/ko_KR.js

// components
import Header from "./Header";
import Section from './Section';

// style
import SitePath from './SitePath';



const BaseLayout = ({children}) => {

    return (
        // <Container fluid>
        //     <Header  />
        //     <div className='mb-5'>&nbsp;</div>
        //     {/* <SitePath  /> */}
        //     <Section children={children} />
        //     <Footer />
        // </Container>

        <CustomProvider locale={ko}>
             {/* 슈퍼어드민 권한자의 경우 아래 내용 출력  /> */}
            {/* <div className="admin-top-set">
                <button className="hd-admin-button ">현대자동차</button>
                <button className="kia-admin-button active">기아자동차</button>
            </div> */}
        <div id="wrapper" className="hd">
            <Header  />
            {/* <SitePath  /> */}
            <Section children={children} />
            {/* <Footer /> */}
        </div>
        </CustomProvider>
    );
};
export default BaseLayout;