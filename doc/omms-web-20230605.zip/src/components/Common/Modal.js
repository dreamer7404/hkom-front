import React from 'react';
import ReactModal from 'react-modal-resizable-draggable';

const Modal = ({show, onHide, size, title, children}) => {
    return (
        <ReactModal 
            initWidth={size === 'lg' ? 800 : 400} 
            initHeight={"600"}
            onRequestClose={onHide} 
            isOpen={show}
            disableResize={true}>
                <div className='hkomms-modal-header'>{title}</div>
                <div className='hkomms-modal-header-close'><p onClick={onHide} >X</p></div>
                <div className='hkomms-modal-body'>{children}</div>
        </ReactModal>
    )
}

// const Footer = ({children}) => {
//     return (
//         <div className='hkomms-modal-footer'>
//             {children}
//         </div>
//     )
// }
// Modal.Footer = Footer;
export default Modal;