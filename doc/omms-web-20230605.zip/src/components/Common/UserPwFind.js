import React from 'react';
import {Modal, Button, Table} from 'react-bootstrap';
import {Form} from 'rsuite';

const UserPwFind = ({show, onHide}) => {
    
    return (
        <>
            <Form>
                <Modal show={show} onHide={onHide} backdrop="static" keyboard={false} centered size="md" className="modal-custom">
                    <Modal.Header closeButton>
                        <Modal.Title>비밀번호 찾기</Modal.Title>
                    </Modal.Header>
                    <Modal.Body>
                            <div className="password-find">
                                <p>비밀번호를 잊으셨나요?</p>
                                <p>아이디와 이름 정보를 입력해주세요. <br />관리자가 임시 비밀번호를 이메일로 보내드립니다.</p>
                            </div>
                            <Table className="tbl-hor" bordered>
                                <colgroup>
                                    <col style={{width:'30%'}}></col>
                                    <col style={{width:''}}></col>
                                </colgroup>
                                <tbody>
                                    <tr>
                                        <th className="essen">아이디</th>
                                        <td>
                                            <Form.Control size="sm" type="text"/>
                                        </td>
                                    </tr>
                                    <tr>
                                        <th className="essen">이름</th>
                                        <td>
                                            <Form.Control size="sm" type="text"/>
                                        </td>
                                    </tr>
                                </tbody>
                            </Table>
                    </Modal.Body>

                    <Modal.Footer>
                        <Button variant="light" size="md" onClick={onHide}>취소</Button>
                        <Button variant="primary" size="md" onClick={onHide}>비밀번호 찾기</Button>
                    </Modal.Footer>
                </Modal>
            </Form>
        </>
    );

};
export default UserPwFind;