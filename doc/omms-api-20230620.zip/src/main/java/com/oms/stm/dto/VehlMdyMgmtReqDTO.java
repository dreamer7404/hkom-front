package com.oms.stm.dto;

import java.util.List;

import org.apache.ibatis.type.Alias;

import com.oms.common.dto.CommReqDTO;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName : vehlMdyMgmtReqDTO.java
 * @Description : 차종연식관리 DTO
 * @author 김경훈
 * @since 2023. 4. 26.
 * @see
 */
@Alias("vehlMdyMgmtReqDTO")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class VehlMdyMgmtReqDTO extends CommReqDTO {

    private String qltyVehlCd;              //차종 코드(조회조건)
    private String dlExpdRegnCd;        //지역코드
    private String dlExpdPacScnCd;      //승상구분코드
    private String dlExpdPdiCd;           //PDI코드
    private String dlExpdCoCd;          //회사구분코드
    private String sYm;                     //시작년월
    private String eYm;                     //종료 년월
    private String newQltyVehlCd;       //차종코드(입력)

    private String mdlMdyCd;
    private int desmp1Cd;               //입력한 시작월팩
    private int defmp1Cd;               // 입력한 종료월팩
    private int prevStrtPack;           // 현재 시작월팩
    private int prevEndPack;            // 현재 종료월팩

    private int orgnDesmp1Cd;       //현재 시작월팩 update
    private int orgnDefmp1Cd;       //종료 시작월팩   update
    private String prevMdlMdyCd;    // 현재 연식


}
