package com.oms.stm.controller;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import able.cloud.core.web.HController;

import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.oms.cmm.global.Consts;
import com.oms.cmm.utils.Utils;
import com.oms.common.dto.CommReqDTO;
import com.oms.common.service.CommService;
import com.oms.stm.dto.LangMgmtReqDTO;
import com.oms.stm.dto.LangMgmtResDTO;
import com.oms.stm.dto.NatlMgmtReqDTO;
import com.oms.stm.dto.NatlMgmtResDTO;
import com.oms.stm.dto.NatlMgmtSaveDTO;
import com.oms.stm.dto.StmComReqDTO;
import com.oms.stm.dto.VehlMgmtResDTO;
import com.oms.stm.model.NatlMgmt;
import com.oms.stm.service.NatlMgmtService;
import com.oms.sys.dto.CodeMgmtReqDTO;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;


/**
 * <pre>
 * NatlMgmt Controller
 * </pre>
 *
 * @ClassName   : NatlMgmtController.java
 * @Description : 클래스 설명을 기술합니다.
 * @author 안경수
 * @since 2023.1.6
 * @see
 */
@Tag(name = "NatlMgmtController", description = "")
@RequiredArgsConstructor
@RestController
@RequestMapping("/api")
public class NatlMgmtController extends HController {

    /**
     * 클래스 Injection
     */
    private final HttpServletRequest request;
	private final NatlMgmtService natlMgmtService;
    private final CommService commService;



    @Operation(summary = "국가별 언어코드목록")
    @GetMapping("/natlLangMgmts")
     public HashMap<String, Object> natlLangMgmts(StmComReqDTO dto) throws Exception {


        HashMap<String, Object> resultMap = new HashMap<String, Object>();


        dto.setUserEeno(Utils.getUserEeno(request));
        dto.setDlExpdCoCd(Utils.getDlExpdCoCd(request));

        LocalDate dateNow = LocalDate.now(); //연식을 전체로 뒀을경우 현재 날짜기준 연식가져옴
        String myDate = dateNow.toString();
        myDate = myDate.substring(2, 4);
        dto.setMdlMdyCd(dto.getMdlMdyCd().equals("ALL") ? myDate : dto.getMdlMdyCd());

        List<NatlMgmtResDTO> LangClumList = natlMgmtService.selectNatlLangClumList(dto); //
        HashMap<String, Object> hmap = new HashMap<String,Object>();
        List<HashMap<String,Object>> qltyCodeList = new ArrayList<HashMap<String,Object>>();



        String column = "";
        for(int i=0; i< LangClumList.size(); i++) {
            HashMap<String,Object> paramMap = new HashMap<String,Object>();
                int num = i+1;
                 column = "col"+Integer.toString(num);
                hmap.put(column, LangClumList.get(i).getQltyVehlCd());

                paramMap.put("col", column);
                paramMap.put("qltyVehlCd",  LangClumList.get(i).getQltyVehlCd());
                paramMap.put("mdlMdyCd",  LangClumList.get(i).getMdlMdyCd());

                qltyCodeList.add(paramMap);

        }

        hmap.put("dlExpdCoCd", Utils.getDlExpdCoCd(request));
        hmap.put("natlCd", dto.getNatlCd());
        hmap.put("mdlMdyCd", dto.getMdlMdyCd());
        hmap.put("qltyVehlCd",  dto.getQltyVehlCd());
        hmap.put("langCd", dto.getLangCd());
        hmap.put("dlExpdRegnCd", dto.getDlExpdRegnCd());
        hmap.put("natlNm", dto.getNatlNm());



        resultMap.put("qltyCodeList",qltyCodeList);

        List<NatlMgmtResDTO> natlLangList = natlMgmtService.selectNatlLangList(hmap);
            resultMap.put("natlLangList", natlLangList);
        List<NatlMgmtResDTO> blkListCd = natlMgmtService.selectNatlBlkList(hmap);
            resultMap.put("blkListCd", blkListCd);

        return resultMap;
    }


    @Operation(summary = "국가별 언어코드상세")
    @GetMapping("/natlLangMgmt")
     public HashMap<String, Object> natlLangMgmt(StmComReqDTO dto) throws Exception {


        HashMap<String, Object> resultMap = new HashMap<String, Object>();


        dto.setUserEeno(Utils.getUserEeno(request));
        dto.setDlExpdCoCd(Utils.getDlExpdCoCd(request));

        LocalDate dateNow = LocalDate.now(); //연식을 전체로 뒀을경우 현재 날짜기준 연식가져옴
        String myDate = dateNow.toString();
        myDate = myDate.substring(2, 4);
        dto.setMdlMdyCd(dto.getMdlMdyCd().equals("ALL") ? myDate : dto.getMdlMdyCd());


        List<NatlMgmtResDTO> natlLangList = natlMgmtService.selectNatlVehlLangDetail(dto);
            resultMap.put("natlLangList", natlLangList);
            resultMap.put("mdlMdyCd", dto.getMdlMdyCd());

        return resultMap;
    }
    @Operation(summary = "국가코드 상세-> 차종리스트")
    @GetMapping("/natlVehlDtList")
     public List<NatlMgmtResDTO>natlVehlDtList(StmComReqDTO dto) throws Exception {

            dto.setUserEeno(Utils.getUserEeno(request));
            dto.setDlExpdCoCd(Utils.getDlExpdCoCd(request));

            return  natlMgmtService.selectNatlVehlDetailList(dto);//국가언어코드;
    }



    @Operation(summary = "국가별 언어코드저장 (등록, 수정 같은 로직을 사용합니다.)")
    @PostMapping("/natlLangMgmt")
    public Integer natlLangMgmt(@RequestBody NatlMgmtSaveDTO natlSaveDto) {
        int result = 0;
        String method = Utils.getMethod(request);
        String dlExpdCoCd = Utils.getDlExpdCoCd(request);
        String userEeno = Utils.getUserEeno(request);
        natlSaveDto.setUserEeno(userEeno);
        natlSaveDto.setDlExpdCoCd(dlExpdCoCd);


        if(method.equals(Consts.INSERT)||method.equals(Consts.UPDATE)) {

            String natlChk = natlMgmtService.selectNatlMgmtCount(natlSaveDto); //tb_natl_mgmt 테이블 유무 체크
            if("Y".equals(natlChk)) {
                result = natlMgmtService.insertNatlCdMgmt(natlSaveDto); //없으면 추가
            }
            result = natlMgmtService.deleteNatlLangMgmt(natlSaveDto); //하위 natlLangMgmt 조건 매핑 후 삭제 처리
            result = natlMgmtService.deleteNatlVehlMgmt(natlSaveDto); //하위 natlVehlMgmt 조건 매핑 후 삭제 처리
//      해당건 전부 삭제후 다시 저장

            for(int i=0; i< natlSaveDto.getVehlList().size() ; i++){


                natlSaveDto.getVehlList().get(i).setDlExpdCoCd(dlExpdCoCd);
                natlSaveDto.getVehlList().get(i).setUserEeno(userEeno);
                natlSaveDto.getVehlList().get(i).setDlExpdNatCd(natlSaveDto.getDlExpdNatCd());
                natlSaveDto.getVehlList().get(i).setDlExpdRegnCd(natlSaveDto.getDlExpdRegnCd());

                result =   natlMgmtService.insertNatlVehlMgmt(natlSaveDto.getVehlList().get(i));  // 국가별 차량코드 등록


                int listSize = natlSaveDto.getVehlList().get(i).getLangs().size();
                for(int j=0; j< listSize ; j++){
                    List<String> langs = natlSaveDto.getVehlList().get(i).getLangs();
                    String langCd = langs.get(j);


                    natlSaveDto.getVehlList().get(i).setLangCd(langCd); // 차량별 언어코드 등록
                    natlSaveDto.getVehlList().get(i).setDlExpdCoCd(dlExpdCoCd);
                    natlSaveDto.getVehlList().get(i).setDlExpdNatCd(natlSaveDto.getDlExpdNatCd());
                    natlSaveDto.getVehlList().get(i).setQltyVehlCd(natlSaveDto.getVehlList().get(i).getQltyVehlCd()); //해당 국가의 차종코드
                    natlSaveDto.getVehlList().get(i).setMdlMdyCd(natlSaveDto.getMdlMdyCd()); //등록할 연식값
                    natlSaveDto.getVehlList().get(i).setUserEeno(userEeno); //등록할 연식값



                    result = natlMgmtService.insertNatlLangMgmt(natlSaveDto.getVehlList().get(i)); // 차량별 언어코드 등록
                }
            }


           if(natlSaveDto.getDytmPlnNatCd()!=null) {
               result = natlMgmtService.deleteNatlBlkList(natlSaveDto); // 제외 대리점 코드 삭제 , 중복방지
               result = natlMgmtService.insertNatlBlkList(natlSaveDto); // 제외 대리점 코드 등록
           }


        } else if (method.equals(Consts.UPDATE)) {
            result = natlMgmtService.updateNatlVehlMgmt(natlSaveDto);
        }


        return result;
    }


    @Operation(summary = "국가코드 선택 팝업")
    @GetMapping("/natlMgmtPop")
     public List<NatlMgmtResDTO>natlMgmtPop(StmComReqDTO dto) throws Exception {

            dto.setUserEeno(Utils.getUserEeno(request));
            dto.setDlExpdCoCd(Utils.getDlExpdCoCd(request));

            return  natlMgmtService.selectNatlMgmtList(dto);//국가언어코드;
    }

    @Operation(summary = "국가코드 추가 -> 차종리스트")
    @GetMapping("/natlVehlList")
     public List<NatlMgmtResDTO>natlVehlList(StmComReqDTO dto) throws Exception {

            dto.setUserEeno(Utils.getUserEeno(request));
            dto.setDlExpdCoCd(Utils.getDlExpdCoCd(request));

            return  natlMgmtService.selectNatlVehlList(dto);//국가언어코드;
    }





    @Operation(summary = "국가코드 마스터 목록")
    @GetMapping("/natlMsts")
     public List<NatlMgmtResDTO>natlMsts(StmComReqDTO dto) throws Exception {

            dto.setUserEeno(Utils.getUserEeno(request));
            dto.setDlExpdCoCd(Utils.getDlExpdCoCd(request));
            return  natlMgmtService.selectNatlCdMstList(dto);//국가언어코드;
    }

    @Operation(summary = "국가코드 마스터 상세")
    @GetMapping("/natlMst")
     public NatlMgmtResDTO natlMst(@ModelAttribute StmComReqDTO dto) throws Exception {

            dto.setUserEeno(Utils.getUserEeno(request));
            dto.setDlExpdCoCd(Utils.getDlExpdCoCd(request));
            return  natlMgmtService.selectNatlCdMst(dto);//국가언어코드;
    }


    @Operation(summary = "국가코드 저장")
    @Parameter(in = ParameterIn.HEADER, name="_method", schema=@Schema(type="string"))
    @PostMapping("/natlMst")
    public Integer natlMst(@RequestBody NatlMgmtReqDTO dto) throws Exception {

        String method = Utils.getMethod(request);
        int result =0;
        dto.setUserEeno(Utils.getUserEeno(request));
        dto.setDlExpdCoCd(Utils.getDlExpdCoCd(request));
//            hmap.put("dlExpdNatCd", request.getParameter("RdlExpdNatCd"));
//            hmap.put("natNm", request.getParameter("RnatNm"));
//            hmap.put("dlExpdRegnCd", request.getParameter("RdlExpdRegnCd"));
        //화면에서 전달해줄 내용
        if(method.equals(Consts.INSERT)) {
            String validChk = natlMgmtService.natlMstValidChk(dto);

            if ("Y".equals(validChk)) {
                result = natlMgmtService.insertNatlCdMst(dto);

            } else {
                result = 999;
            }


        }  else if (method.equals(Consts.UPDATE)) {
            result =natlMgmtService.updateNatlCdMst(dto);
        }   else if (method.equals(Consts.DELETE)) {
            result =natlMgmtService.deleteNatlCdMst(dto);
        }
        return result;
    }



    @Operation(summary = "기존 국가별 연식별 조회(콤보박스)")
    @GetMapping("/natlMdyCombo")
    public  List<NatlMgmtResDTO>natlMdyCombo(@ModelAttribute NatlMgmtReqDTO dto) throws Exception {
        dto.setUserEeno(Utils.getUserEeno(request)); //토큰 사용자
        dto.setDlExpdCoCd(Utils.getDlExpdCoCd(request));

        return     natlMgmtService.selectNatlMdyCombo(dto);

    }



    @Operation(summary = "국가코드 복사 리스트")
    @GetMapping("/natlCopys")
    public  HashMap<String,Object> natlCopys(@ModelAttribute NatlMgmtReqDTO dto) throws Exception {

        HashMap<String, Object> resultMap = new HashMap();
        dto.setDlExpdCoCd(Utils.getDlExpdCoCd(request));

        List<HashMap<String,Object>> copyNatlList = natlMgmtService.selectNatlLangCpyList(dto);
        resultMap.put("copyNatlList",copyNatlList);

        return resultMap;
    }


    @Operation(summary = "차종에 해당하는 설정 지역정보")
    @GetMapping("/natlVehlRegn")
    public  HashMap<String,Object> natlVehlRegn(@ModelAttribute NatlMgmtReqDTO dto) throws Exception {

        HashMap<String, Object> resultMap = new HashMap();
        dto.setDlExpdCoCd(Utils.getDlExpdCoCd(request));

        NatlMgmtResDTO natlVehlRegn = natlMgmtService.getNatlVehlRegn(dto);
        resultMap.put("natlVehlRegn",natlVehlRegn);

        return resultMap;
    }





    @Operation(summary = "지역설정 저장")
    @PostMapping("/updRegnCd")
    public Integer updRegnCd(@RequestBody NatlMgmtReqDTO dto) throws Exception {

        String method = Utils.getMethod(request);
        int result =0;
        dto.setUserEeno(Utils.getUserEeno(request));
        dto.setDlExpdCoCd(Utils.getDlExpdCoCd(request));


        if(method.equals(Consts.UPDATE)) {
            result += natlMgmtService.updRegnCd(dto);
        }
        return result;
    }

    @Operation(summary = "엑셀 저장")
    @PostMapping("/natlExcelUpload")
    public Integer natlExcelUpload(@RequestBody NatlMgmtSaveDTO dto) throws Exception {


        int result =0;


        for(int i=0; i<dto.getExcelDataList().size(); i++) {



            dto.getExcelDataList().get(i).setDlExpdCoCd(Utils.getDlExpdCoCd(request));
            dto.getExcelDataList().get(i).setUserEeno(Utils.getUserEeno(request));


            result =natlMgmtService.deleteExcelUpload(dto.getExcelDataList().get(i)); //중복제거용
            result = natlMgmtService.insertNatlLangMgmt(dto.getExcelDataList().get(i)); //insert

        }
        return result;
    }






}