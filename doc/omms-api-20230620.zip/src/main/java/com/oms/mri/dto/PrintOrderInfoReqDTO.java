package com.oms.mri.dto;

import java.util.List;

import org.apache.ibatis.type.Alias;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * <pre>
 * PrintOrderInfoReqDTO
 * </pre>
 *
 * @author 김정웅
 * @since 2023. 6. 13.
 * @see
 */
@Alias("printOrderInfoReqDTO")
@Data
@AllArgsConstructor
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown =true)
public class PrintOrderInfoReqDTO extends PrintOrderComDTO{

    private String blcSn;
    private List<ClcmInfoResDTO> checkedRows;   //선택한 개정내용 리스트
    private String depq1Cd;
    private String dlvgParrYmd;
    private String iwayCd;
    private String oordEditCoCd;
    private String oordEditPgNl;
    private String pgMgnSbc;
    private String pgNl;
    private int prntParrQty;
    private String prntParrYmd;
    private String prntWayCd;
    private String prntWayCd2;
    private String prtlImtrSbc;         //메모
    private String state;               //임시저장, 발주 구분값 (S:임시저장, Q:O/M발주)

    private String grnDocNl;            //보증서/엽서 수량
    private String mdfyPgNl;            //수정페이지
    private String depc1Yn;             //커버 사용유무
    private String saleUnp;             //판매단가.. insert때 null로 넣고, 발간현황에서 인쇄비 입력할떄 update 됨.
    private String ordnCsetCdt;
    private String n1afp2Adr;
    private String n2afp2Adr;
    private String prtlImtrSbc2;
    private String coverAttcSn;
    private String innerAttcSn;

    private String trtmRstCd;           //발주상태 (그룹코드:0009  01:발주 전(사용X), 02:발주완료, 03:발주취소, 04:재발주(사용X), 05:저장)




}
