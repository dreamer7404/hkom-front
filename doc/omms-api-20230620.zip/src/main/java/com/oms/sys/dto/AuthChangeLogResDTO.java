package com.oms.sys.dto;

import org.apache.ibatis.type.Alias;

import com.oms.common.dto.CommReqDTO;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * <pre>
 * Statements
 * </pre>
 * @ClassName : AuthChangeResDTO.java
 * @Description :
 * @author 김경훈
 * @since 2023. 6. 19.
 * @see
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Alias("authChangeLogResDTO")

public class AuthChangeLogResDTO   extends CommReqDTO{

    private String altrCd;
    private String userId;
    private String userNm;
    private String coCd;
    private String deptNm;
    private String chgrId;
    private String chgrNm;
    private String chgrIp;
    private String aftType;
    private String befrValue;
    private String aftrValue;
    private String befAuth;
    private String aftAuth;
    private String altrDate;

}
