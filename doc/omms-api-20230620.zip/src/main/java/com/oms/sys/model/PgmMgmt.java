package com.oms.sys.model;

import java.sql.Timestamp;

import lombok.Data;

/**
 * <pre>
 * 메뉴관리
 * </pre>
 *
 * @author 안경수
 * @since 2023. 3. 8.
 * @see
 */

@Data
public class PgmMgmt {

    private String menuId;
    private String pgmId;
    private Integer pgmIdSn;
    private String pgmNm;
    private String pgmPathAdr;
    private String inpScnCd;
    private String useYn;
    private String pprrEeno;
    private Timestamp framDtm;
    private String updrEeno;
    private Timestamp mdfyDtm;
}
