package com.oms.sys.dto;

import org.apache.ibatis.type.Alias;

import com.oms.common.dto.CommReqDTO;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


/**
 * <pre>
 * Statements
 * </pre>
 * @ClassName : SchedulerLogResDTO.java
 * @Description :
 * @author 김경훈
 * @since 2023. 6. 19.
 * @see
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Alias("schedulerLogResDTO")

public class SchedulerLogResDTO   extends CommReqDTO{
    private String schedId;
    private String schedNm;
    private String startDtm;
    private String endDtm;
    private String apiUrl;
    private String getDataCnt;
    private String saveDataCnt;
    private String callRslt;
}
