package com.oms.sys.dto;

import java.sql.Timestamp;

import org.apache.ibatis.type.Alias;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;



/**
 * <pre>
 * Statements
 * </pre>
 * @ClassName : BatchResDTO.java
 * @Description :
 * @author 김경훈
 * @since 2023. 6. 14.
 * @see
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Alias("batchResDTO")
public class BatchResDTO {
    private String btchSn;
    private String btchNm;
    private String btchSbc;
    private String btchExeTm;
    private String framDtm;

}
