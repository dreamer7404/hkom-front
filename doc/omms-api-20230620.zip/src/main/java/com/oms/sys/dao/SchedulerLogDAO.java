package com.oms.sys.dao;
import java.util.List;
import com.oms.sys.dto.LogComReqDTO;
import com.oms.sys.dto.SchedulerLogResDTO;


/**
 * <pre>
 * Statements
 * </pre>
 * @ClassName : AuthChangeDAO.java
 * @Description :
 * @author 김경훈
 * @since 2023. 6. 19.
 * @see
 */
public interface SchedulerLogDAO {


    List<SchedulerLogResDTO> schedulerHistorys(LogComReqDTO dto);
    /**
     * Statements
     *
     * @param dto
     * @return
     */
    Integer schedulerHistoryTots(LogComReqDTO dto);

}
