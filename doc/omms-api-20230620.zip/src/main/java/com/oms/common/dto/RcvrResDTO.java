package com.oms.common.dto;

import java.sql.Timestamp;

import org.apache.ibatis.type.Alias;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;




/**
 * <pre>
 * Statements
 * </pre>
 * @ClassName : RcvrResDTO.java
 * @Description :
 * @author 김경훈
 * @since 2023. 6. 8.
 * @see
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown=true)
@Alias("rcvrResDTO")
public class RcvrResDTO {
    private String rcvrGbn;
    private String gbnSn;
    private String rcvrEeno;
    private String sortSn;
    private String popCkDtm;
    private String pprrEeno;
    private String userEeno;
    private Timestamp framDtm;
    private String updrEeno;
    private Timestamp mdfyDtm;

    private String chkYn;
    private String userNm;
    private String coNm;

    private String deptNm;
}
