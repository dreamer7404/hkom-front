package com.oms.common.dao;

import java.util.List;

import com.oms.common.dto.CommLangComboReqDTO;
import com.oms.common.dto.CommLangComboResDTO;

/**
 * <pre>
 * CommComboDAO 인터페이스
 * </pre>
 *
 * @Class Name  : CommComboDAO.java
 * @Description : 공통 콤보 DAO
 * @author 김정웅
 * @since 2023.3.21
 * @see
*/
public interface CommComboDAO {

    //LangCombo DAO
    List<CommLangComboResDTO> selectCommLangComboList(CommLangComboReqDTO commLangComboReqDTO) throws Exception;




}
