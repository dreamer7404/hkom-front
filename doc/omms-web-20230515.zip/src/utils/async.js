import axios from 'axios';
import useStore from './store';
import qs from 'qs'

const baseURL = 'http://localhost:8000/api/';
const axiosInstance = axios.create({
    headers: {
        'Content-Type': 'application/json',
    },
    withCredentials: true,
    timeout : 100000 // 10초
});
// axiosInstance.paramsSerializer = {
//   encode: (params) => {
//     console.log('params =>', params)

//     return qs.stringify(params, { arrayFormat: 'repeat' })
//   },
// }


axiosInstance.interceptors.request.use(req => {
  req.headers["x-auth-token"] = useStore.getState().token;
  req.headers["x-auth-browser"] = useStore.getState().browserId;
  return req;
}, function(err){
  return Promise.reject(err);
});

axiosInstance.interceptors.response.use(res => {
  // console.log('res:', res)
  return res;
}, err => {
  if(err.code === 'ERR_NETWORK'){
    // window.location.pathname = '/errorNet';
    return;
  }
  const originalRequest = err.config;
  if(err.response){
    if(err.response.status === 401){
      // console.log(err.response.data);
      if(err.response.data){
          if(parseInt(err.response.data.result) === 1){ 
              const newToken = err.response.data.token;
              useStore.setState(state => ({...state, token: newToken}));
              return axiosInstance(originalRequest);
          }else {
              window.location.pathname = useStore.getState().loginUrl ? useStore.getState().loginUrl : '/errorNet';
          }
      }
  }
  }
});

export const getData = async (url, params=null) => {
  const res = await axiosInstance.get(baseURL + url, {params: params});
  return res && res.data;
}

// export const getDataArray = async (url, params=null) => {
//   const res = await axiosInstance.get(baseURL + url, {
//     params: params,
//     paramsSerializer : (params) => {
//       return qs.stringify(params, { arrayFormat: 'repeat' })
//     }

//   });
//   return res && res.data;
// }
export const getDataPure = async (url, params=null) => {
  console.log(url)
  const res = await axios.get(baseURL + url, {params: params});
  return res && res.data;
}

export const postData = async(url, params, method) => {
  console.log('[postData]' + url)
  const res =  await axiosInstance.post(baseURL + url, params, {headers: {_method: method},  withCredentials: true});
  return res && res.data;
}

export const postAuth = async(url, params, method) => {
  axiosInstance.getUri()
  const res =  await axiosInstance.post(baseURL + url, params, {headers: {_method: method},  withCredentials: true});
  return res && res.data;
}



