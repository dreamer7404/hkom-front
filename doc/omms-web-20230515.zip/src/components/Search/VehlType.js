/* eslint-disable react-hooks/exhaustive-deps */
import React from 'react';
import {Row, Col} from 'react-bootstrap';
import {Form, SelectPicker } from 'rsuite';

//--------------  서버데이터용 필수 -------------------------------
import { useQuery} from 'react-query';
import { getData } from '../../utils/async';
import { API, CONSTANTS } from '../../utils/constants';
import useStore from '../../utils/store';
import { escapeCharChange} from '../../utils/commUtils';
//--------------// 서버데이터용 필수 -------------------------------


const VehlType = () => {

    const {keyword, 
        setDlExpdPdiCd, // PDI코드 setter
        setQltyVehlCd,  //차종코드 setter
        setMdlMdyCd,  // 차량Mdy코드 setter 
    } = useStore(); 

    const onChangePdiCombo = val => {
        setDlExpdPdiCd(val);
    };
    const onChangeVehlCombo = val => {
        setQltyVehlCd(val);
    };
    const onChangeMdyCombo = val => {
        setMdlMdyCd(val);
    };


    // pdiCombo API가져오기
    const pdiParams = {
        bDate: keyword.bDate && keyword.bDate.replace(/-/gi, '')
    };
    const pdiCombo = useQuery([API.pdiCombo, pdiParams], () => getData(API.pdiCombo, pdiParams), {
            select: data => [{label: CONSTANTS.labelAll, value: CONSTANTS.valueAll}].concat(data.map((item) => ({ label: escapeCharChange(item.dlExpdPrvsNm), value: item.dlExpdPdiCd })))
    }); 

    // vehlCombo API가져오기
    const vehlParams = {
        dlExpdPdiCd: keyword.dlExpdPdiCd, 
        bDate: keyword.bDate && keyword.bDate.replace(/-/gi, '')
    };
    const vehlCombo = useQuery([API.vehlCombo, vehlParams], () => getData(API.vehlCombo, vehlParams), {
            select: data => [{label: CONSTANTS.labelAll, value: CONSTANTS.valueAll}].concat(data.map((item) => ({ label: escapeCharChange(item.qltyVehlNm), value: item.qltyVehlCd })))
    }); 

    // mdlMdyCd API가져오기
    const mdyCombo = useQuery([API.mdyCombo], () => getData(API.mdyCombo), {
            select: data => data.map((item) => ({ label: item, value: item }))
    });

    return (
        <>
            <Form.ControlLabel column="sm">차종</Form.ControlLabel>
            <Row className="select-wrap">
                <Col sm={4}> 
                    <SelectPicker size="sm"
                        value={keyword.dlExpdPdiCd} 
                        data={pdiCombo && pdiCombo.data ? pdiCombo.data : []} 
                        onChange={onChangePdiCombo}
                        placeholder={CONSTANTS.labelAll}
                        cleanable={false}
                        searchable={false}
                        block={true}
                    />
                </Col>
                <Col sm={5}> 
                    <SelectPicker size="sm"
                        value={keyword.qltyVehlCd} 
                        data={vehlCombo && vehlCombo.data ? vehlCombo.data : []}  
                        onChange={onChangeVehlCombo}
                        placeholder={CONSTANTS.labelAll}
                        cleanable={false}
                        searchable={false}
                        block={true}
                    />
                </Col>
                <Col sm={2}> 
                    <SelectPicker size="sm" style={{width: '100%'}}
                        value={keyword.mdlMdyCd} 
                        data={mdyCombo && mdyCombo.data ? mdyCombo.data : []} 
                        onChange={onChangeMdyCombo}
                        placeholder={keyword.mdlMdyCd}
                        cleanable={false}
                        searchable={false}
                        block={true}
                    />
                    </Col>
            </Row>
        </>
    );

};
export default VehlType;