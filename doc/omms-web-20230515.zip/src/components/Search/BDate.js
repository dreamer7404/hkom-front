import React from 'react';
import { Col } from 'react-bootstrap';
import { DatePicker, Form} from 'rsuite';

import { utcToLocalDate } from '../../utils/commUtils'; //'../../../utils/commUtils';

//--------------  서버데이터용 필수 -------------------------------
import useStore from '../../utils/store';
//--------------// 서버데이터용 필수 -------------------------------


const BDate = () => {

    const {keyword, setBDate } = useStore(); 

    const onChangeBDate = val => {
        setBDate(val ? utcToLocalDate(val) : utcToLocalDate(new Date()));
    }

    return (
        <>
            <Form.ControlLabel column="sm">기준일</Form.ControlLabel>
            <DatePicker oneTap block size="sm"
            value={new Date(keyword.bDate)} 
            onChange={onChangeBDate} 
            placeholder={keyword.bDate}
            cleanable={false}
            searchable="true"
            ranges={[
                {
                label: '오늘',
                value: new Date()
                }
            ]}
            />
        </>
    );

};
export default BDate;