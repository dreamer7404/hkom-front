import React from 'react';
import { Row, Col } from 'react-bootstrap';
import { Form ,SelectPicker } from 'rsuite';
import { escapeCharChange} from '../../utils/commUtils';

//--------------  서버데이터용 필수 -------------------------------
import { useQuery} from 'react-query';
import { getData  } from '../../utils/async';
import { API, CONSTANTS } from '../../utils/constants';
import useStore from '../../utils/store';
//--------------// 서버데이터용 필수 -------------------------------

const Lang = () => {

    const {keyword, 
        setDlExpdRegnCd,  // 지역코드 setter
        setLangCd,  // 언어코드 setter
    } = useStore(); 


    const onChangeRegionCombo = val => {
        setDlExpdRegnCd(val);
    };
    const onChangeLangCombo = val => {
        setLangCd(val);
    }


    // regionCombo API가져오기
    const regionParams = {
        bDate: keyword.bDate && keyword.bDate.replace(/-/gi, ''), 
        dlExpdPdiCd: keyword.dlExpdPdiCd, 
        qltyVehlCd: keyword.qltyVehlCd, 
        mdlMdyCd: keyword.mdlMdyCd
    };
    const regionCombo = useQuery([API.regionCombo, regionParams], () => getData(API.regionCombo, regionParams), {
            select: data => [{label: CONSTANTS.labelAll, value: CONSTANTS.valueAll}].concat(data.map((item) => ({ label: item.dlExpdRegnNm, value: item.dlExpdRegnCd })))
    }); 

    // langCombo API가져오기
    const langParams = {
        bDate: keyword.bDate && keyword.bDate.replace(/-/gi, ''),
        dlExpdPdiCd: keyword.dlExpdPdiCd, 
        qltyVehlCd: keyword.qltyVehlCd, 
        mdlMdyCd: keyword.mdlMdyCd,
        dlExpdRegnCd: keyword.dlExpdRegnCd
    };
    const langCombo = useQuery([API.langCombo, langParams], () => getData(API.langCombo, langParams), {
        select: data => [{label: CONSTANTS.labelAll, value: CONSTANTS.valueAll}].concat(data.map((item) => ({ label: escapeCharChange(item.langCdNm), value: item.langCd })))
    }); 

    return (
        <>
            <Form.ControlLabel column="sm" >언어</Form.ControlLabel>
            <Row className="select-wrap">
                <Col sm={3}>
                    <SelectPicker size="sm"
                        value={keyword.dlExpdRegnCd} 
                        data={regionCombo && regionCombo.data ? regionCombo.data : []} 
                        onChange={onChangeRegionCombo}
                        placeholder={CONSTANTS.labelAll}
                        cleanable={false}
                        searchable={false}
                        block={true}
                    />
                </Col>
                <Col sm={9}>
                    <SelectPicker size="sm"
                        value={keyword.langCd} 
                        data={langCombo && langCombo.data ? langCombo.data : []}  
                        onChange={onChangeLangCombo}
                        placeholder={CONSTANTS.labelAll}
                        cleanable={false}
                        searchable={false}
                        block={true}
                    />
                </Col>
            </Row>
        </>
    );

};
export default Lang;