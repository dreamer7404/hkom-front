/* eslint-disable react-hooks/exhaustive-deps */
/* eslint-disable jsx-a11y/alt-text */
// react
import React, {useEffect, useState} from 'react';
import {Button, Card } from "react-bootstrap";
import {Schema, Form, useToaster, Notification } from 'rsuite';

import { useNavigate, Link, useLocation  } from 'react-router-dom';
import useStore, {useStoreAuth} from '../../../utils/store';

//--------------  서버데이터용 필수 -------------------------------
import { useMutation} from 'react-query';
import { postAuth } from '../../../utils/async';
import { API, CONSTANTS } from '../../../utils/constants';
import FindPw from './Popup/FindPw';
//--------------// 서버데이터용 필수 -------------------------------
import { confirmAlert } from 'react-confirm-alert'; 
import ConfirmAlert from '../../Common/ConfirmAlert';  

if(window.location.pathname.substring(0,3) === '/hd') 
    import (`../../../styles/theme_hd.css`); 
else 
    import (`../../../styles/theme_kia.css`); 

const { StringType} = Schema.Types;
const model = Schema.Model({
    userEeno: StringType().isRequired('아이디를 입력해주세요.'),
                            // .pattern(/^[a-zA-Z0-9]*$/, '영문자,숫자로 입력해주세요')
                            // .rangeLength(7, 20, '7-20자로 입력해주세요'),
    userPw: StringType().isRequired('비밀번호를 입력해주세요.')
                            // .pattern(/^(?=.*[A-Za-z])(?=.*\d)(?=.*[$@$!%*#?&])[A-Za-z\d$@$!%*#?&]{7,}$/, 
                            //     '최소 7자리이며, 숫자,문자,특수문자는 최소1개이상 입력해주세요')
                            // .rangeLength(7, 20, '7-20자로 입력해주세요'),
});

const Login = () => {

    const location = useLocation();
    const [coCd, setCoCd] = useState(location.pathname.substring(0, 3) === '/hd' ? '01' : '02');
    const [logo, setLogo] = useState(''); 

    useEffect(() => {
        if(location.pathname === '/hd'){
            setLogo('hd')
        }else if(location.pathname === '/kia'){
            setLogo('kia')
        }
    },[])

    const {resetUser, errCd, setErrCd} = useStore();

    const navigate = useNavigate();
    const toaster = useToaster();

    // Form 정의
    const formRef = React.useRef();
    const [formError, setFormError] = React.useState({});
    const [formValue, setFormValue] = React.useState({
      userEeno: '',     
      userPw: '',  
      blnsCoCd: coCd,
    });

    useEffect(()=> {
        // if(errCd === 2){
        //     confirmAlert({
        //         closeOnClickOutside: false,
        //         customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}  title={"알림"} msg={'다른곳에서 로그인헸습니다.' + errCd}  />
        //     });
        //     setErrCd(null);
        // }

        resetUser({
            token: '', 
            browserId: '', 
            grpCd: '', 
            coCd: '', 
            userDcd: '', 
        });

        // useStore.persist.clearStorage();
    },[]);

     // login
    const usrmgmtMutate = useMutation((params => postAuth(API.login, params, CONSTANTS.update)),{
        onSuccess: rv => {
            console.log('[login result]', rv);
            console.log('[window.location.pathname]', window.location.pathname);
            if(rv.result === 1){
                resetUser({
                    token: rv.data.token, 
                    browserId: rv.data.browserId, 
                    grpCd: rv.data.grpCd, 
                    coCd: rv.data.blnsCoCd, // 회사코드 => sysadm 일경우, hd/kia둘다 되므로, 현재 로그인한 url로 정한다.
                    deptCd: rv.data.userDcd, 
                    loginUrl: window.location.pathname,
                });
                navigate('/totalStock');
            }else{
                let message = '';
                if(rv.result === -1 || rv.result === -3 || rv.result === -2) message = '입력하신 아이디 또는 비밀번호가 일치하지 않습니다.\n확인 후 재입력 해주세요.';
                // else if(rv.result === -2) message = '비밀번호 5회오류가 발생했습니다.\n1시간동안 사용할수 없습니다';
                else if(rv.result === -4) message = '입력하신 아이디는 사용중지중입니다.\n관리자에게 문의해주세요.';
                else if(rv.result === -5) message = '입력하신 아이디는 1시간동안 사용중지 상태입니다';
                else message = '로그인 오류입니다.(' + rv.result + ')';

                confirmAlert({
                    closeOnClickOutside: false,
                    customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}  title={"알림"} msg={message}  />
                });
            }
        }
    });
    const onKeyPress = e => {
        return e.charCode === 13 ? ( handleSubmit()) : null
    }
    const handleSubmit =() => {
        if (!formRef.current.check()) {
            return;
        }
        usrmgmtMutate.mutate(formValue);
    }

    const [show, setShow] = React.useState(false);
    const onClose = () => {
        setShow(false);
    }

    return (
        <>
            <div className="login-wrap">

                <Form
                    ref={formRef}
                    checkTrigger="none"
                    onChange={setFormValue}
                    onCheck={setFormError}
                    formValue={formValue}
                    model={model}>

                    <h4>Owner's Mannual <span>Management System.</span></h4>
                    <Card className="shadow">
                        <Card.Body>
                            <div className="">
                                
                                <div className="login-top">
                                    {logo === 'hd' && <img className="comLogo" src="../images/hd_logo_color.png"></img>}
                                    {logo === 'kia' && <img className="comLogo" src="../images/kia_logo_color.png"></img>}
                                    {logo === '' &&  <p style={{textAlign:'center', fontSize:'14px', marginBottom:'0', fontWeight:'600'}}>협력업체</p>}
                                </div>
                                <div className="login-body">
                                    <Form.Group className="mb-3" controlId="formBasicEmail">
                                        <Form.ControlLabel>아이디</Form.ControlLabel>
                                        <Form.Control type="text" placeholder="User ID" name="userEeno" />
                                    </Form.Group>

                                    <Form.Group  className="mb-1" controlId="formBasicPassword">
                                        <Form.ControlLabel>비밀번호</Form.ControlLabel>
                                        <Form.Control type="password" placeholder="Password" name="userPw" onKeyPress={onKeyPress} />
                                    </Form.Group>
                                    <Form.Group className="mb-3" controlId="formBasicCheckbox">
                                        <p className="small">
                                            <a className="text-secondary" href="#!" onClick={()=> setShow(true)}> 비밀번호찾기</a>
                                        </p>
                                    </Form.Group>

                                    <div className="login-footer">
                                        <Button variant="primary" size="lg" onClick={handleSubmit}>로그인</Button>
                                    </div>
                                </div>
                            </div>
                        </Card.Body>
                    </Card>
                    
                </Form>
            </div>

            <FindPw show={show} onClose={onClose} />
        </>
    )
};
export default Login;