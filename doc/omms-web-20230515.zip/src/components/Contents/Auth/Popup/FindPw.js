import React, {useState, useMemo} from 'react';
import {Button, Modal, Row, Col, Table} from 'react-bootstrap';
import { Form , Schema} from 'rsuite';

//--------------  서버데이터용 필수 -------------------------------
import { useQuery, useMutation} from 'react-query';
import { getData, postData } from '../../../../utils/async';
import { API, CONSTANTS } from '../../../../utils/constants';
//--------------// 서버데이터용 필수 -------------------------------
import { confirmAlert } from 'react-confirm-alert'; 
import ConfirmAlert from  '../../../Common/ConfirmAlert'; 

const { StringType} = Schema.Types;
const model = Schema.Model({
    userEeno: StringType().isRequired('아이디를 입력해주세요.'),
                            // .pattern(/^[a-zA-Z0-9]*$/, '영문자,숫자로 입력해주세요')
                            // .rangeLength(7, 20, '7-20자로 입력해주세요'),
    userNm: StringType().isRequired('이름을 입력해주세요.')
                            // .pattern(/^(?=.*[A-Za-z])(?=.*\d)(?=.*[$@$!%*#?&])[A-Za-z\d$@$!%*#?&]{7,}$/, 
                            //     '최소 7자리이며, 숫자,문자,특수문자는 최소1개이상 입력해주세요')
                            // .rangeLength(7, 20, '7-20자로 입력해주세요'),
});

const FindPw = ({show, onClose}) => {

    // Form 정의
    const formRef = React.useRef();
    const [formError, setFormError] = React.useState({});
    const [formValue, setFormValue] = React.useState({
      userEeno: '',     // 아이디
      userNm: '',       // 이름
    });


    const submitResult = useMutation((params => postData(API.initUserPw, params, CONSTANTS.update)),{
        onSuccess: data => {
            console.log(data.result)
            if(data.result === 1){ // ok

                confirmAlert({
                    closeOnClickOutside: false,
                    customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}  title={"알림"} msg={'이메일로 임시 비밀번호를 전송했습니다.'}  />
                });
                onClose();

            }else if(data.result === 0){ // 아이디,이름 사용자 없음
                
                confirmAlert({
                    closeOnClickOutside: false,
                    customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}  title={"알림"} msg={'해당 사용자가 없습니다'}  />
                });
            }
        }
    });

    const onFind = () => {
        if (!formRef.current.check()) {
            return;
        }
        // queryResult.refetch();
        submitResult.mutate(formValue)
        
    }

    const onHide = () => {
        formRef.current.cleanErrors();
        onClose();
    }

    return (
        <Form
            ref={formRef}
            checkTrigger="change"
            onChange={setFormValue}
            onCheck={setFormError}
            formValue={formValue}
            model={model}>
                <Modal show={show} onHide={onHide} backdrop="static" backdropClassName="modal-in-backdrop" keyboard={false} centered size="md" className="modal-custom modal-in-modal">
                    <Modal.Header closeButton>
                        <Modal.Title>비밀번호 찾기</Modal.Title>
                    </Modal.Header>
                        <Modal.Body>
                            <div style={{padding: '10px'}}>
                                <div>비밀번호를 잊으셨나요?</div>
                                <div style={{paddingTop: '10px'}}>
                                    아이디와 이름정보를 입력해주세요.<br />
                                    관리자가 <strong>임시비밀번호</strong>를 <strong>이메일</strong>로 보내드립니다.
                                </div>
                            </div>
                            <Table className="tbl-hor" bordered>
                                <tbody>
                                    <tr>
                                        <th className="essen">아이디</th>
                                        <td>
                                            <Form.Control name="userEeno" size="sm" type="text" placeholder="아이디를 입력해주세요" />
                                        </td>
                                    </tr>
                                    <tr>
                                        <th className="essen">이름</th>
                                        <td>
                                            <Form.Control name="userNm" size="sm" type="text" placeholder="이름을 입력해주세요" />
                                        </td>
                                    </tr>
                                </tbody>
                            </Table>
                            <div style={{padding: '5px'}}></div>
                        </Modal.Body>
                        <Modal.Footer>
                            <Button variant="light" size="md" onClick={onHide}>취소</Button>
                            <Button variant="primary" size="md" onClick={onFind}>확인</Button>
                        </Modal.Footer>
                </Modal>
        </Form>
    );

};
export default FindPw;