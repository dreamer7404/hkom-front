import React from 'react';
import {Button, Modal, Table} from 'react-bootstrap';
import {Form, SelectPicker} from 'rsuite';

const NatCodeUpdate = ({show, onHide}) => {

    return (
        <>
            <Form>
                <Modal show={show} onHide={onHide} backdrop="static" keyboard={false} centered size="md" className="modal-custom">
                    <Modal.Header closeButton>
                        <Modal.Title>국가코드 상세/수정</Modal.Title>
                    </Modal.Header>
                        <Modal.Body>
                            <Table className="tbl-hor" bordered>
                                <colgroup>
                                    <col style={{width:'30%'}}></col>
                                    <col style={{width:''}}></col>
                                </colgroup>
                                <tbody>
                                    <tr>
                                        <th className="">국가코드</th>
                                        <td>A01</td>
                                    </tr>
                                    <tr>
                                        <th className="essen">국가명</th>
                                        <td>
                                            <Form.Control size="sm" type="text" defaultValue="AFGHANISTAN"/> 
                                        </td>
                                    </tr>
                                    <tr>
                                        <th className="essen">지역</th>
                                        <td>
                                            <SelectPicker size="sm" data={[{ label: "일반"}]} searchable={false} cleanable={false} />
                                        </td>
                                    </tr>
                                </tbody>
                            </Table>
                        </Modal.Body>

                        <Modal.Footer>
                            <Button variant="light" size="md" onClick={onHide}>취소</Button>
                            <Button variant="outline-danger" size="md" onClick={onHide}>삭제</Button>
                            <Button variant="primary" size="md" onClick={onHide} >저장</Button>
                        </Modal.Footer>
                </Modal>
            </Form>

        </>
    );

};
export default NatCodeUpdate;