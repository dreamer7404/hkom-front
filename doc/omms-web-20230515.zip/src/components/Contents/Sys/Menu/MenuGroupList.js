// react
import React, {useState, useEffect} from 'react';
import {Button} from 'react-bootstrap';

//--------------  서버데이터용 필수 -------------------------------
import { useQuery} from 'react-query';
import useStore from '../../../../utils/store';
//--------------// 서버데이터용 필수 -------------------------------

import GridMenuGroupList from '../_Grid/GridMenuGroupList';
import Total from '../../../Common/Total';

import MenuGroupAdd from '../Popup/MenuGroupAdd';
import MenuGroupUpdate from '../Popup/MenuGroupUpdate';

const MenuGroupList = () => {

    //------------------- 필수 공통 ------------------------------
    const {keyword } = useStore();  // 조회키워드 가져오기

    const [activePage, setActivePage] = useState(1);    // 페이지번호
    const [limit, setLimit] = useState(50);             // 페이지행수

    const onChangePage = val => {
        setActivePage(val);
    };
    const onChangeLimit = val => {
        setLimit(val);
    };
    useEffect(()=>{
        onChangePage(1); // 페이지번호 리셋
    },[keyword]);


    //-------------------// 필수 공통 ------------------------------

    const [rowData] = useState([
        {menuGroup: "재고관리", menuGroupCode:'01', useYn:'Y'},
        {menuGroup: "제작준비", menuGroupCode:'02', useYn:'Y'},
        {menuGroup: "발간현황", menuGroupCode:'03', useYn:'Y'},
        {menuGroup: "선적현황", menuGroupCode:'04', useYn:'N'},
        {menuGroup: "운영관리", menuGroupCode:'05', useYn:'Y'},
        {menuGroup: "시스템관리", menuGroupCode:'06', useYn:'Y'},
    ]);

    //  requestState 조회
    const queryResult = useQuery(["MenuGroupList"], () => {return rowData});

    // 셀 클릭
    const onCellClicked = e => {
        if(e.column.colId === 'menuGroup'){
            setMenuGroupUpdatePop(true)
        }
    };

    const [menuGroupAddPop, setMenuGroupAddPop] = useState(false);
    const [menuGroupUpdatePop, setMenuGroupUpdatePop] = useState(false);

    return (
        <>
            <div className="grid-wrap" style={{paddingTop:'10px', borderTop:'2px solid var(--main-color)'}}>
                <div className="grid-btn-wrap">
                    <div className="right-align">
                        {/*--------- 버튼 -----------*/}
                        <Button variant="outline-secondary" size="sm" onClick={() => setMenuGroupAddPop(true)}>메뉴그룹 등록</Button>{' '}
                        <Button variant="outline-secondary" size="sm">사용</Button>{' '}
                        <Button variant="outline-secondary" size="sm">미사용</Button>{' '}
                    </div>
                </div>
                {/*--------- Grid -----------*/}
                <GridMenuGroupList 

                    queryResult={queryResult}
                    limit={limit}
                    activePage={activePage}
                    onCellClicked={onCellClicked}
                    />

                {/*--------- 페이징 -----------*/}
                <Total 
                    total={queryResult && queryResult.data && queryResult.data.length}
                    limit={limit}
                    activePage={activePage}
                    onChangePage={onChangePage}
                    onChangeLimit={onChangeLimit}
                />
            </div>

            <MenuGroupAdd show={menuGroupAddPop} onHide={() => setMenuGroupAddPop(false)} />
            <MenuGroupUpdate show={menuGroupUpdatePop} onHide={() => setMenuGroupUpdatePop(false)} />
        </>
    )
};
export default MenuGroupList;