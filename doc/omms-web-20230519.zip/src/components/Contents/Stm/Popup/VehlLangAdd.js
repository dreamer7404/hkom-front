import React from 'react';
import {Button, Modal, Table, Row, Col} from 'react-bootstrap';
import {Form, SelectPicker} from 'rsuite';

const VehlLangAdd = ({show, onHide}) => {

    return (
        <>
            <Form>
                <Modal show={show} onHide={onHide} backdrop="static" keyboard={false} centered size="md" className="modal-custom">
                    <Modal.Header closeButton>
                        <Modal.Title>차종별 언어등록(개별)</Modal.Title>
                    </Modal.Header>
                        <Modal.Body>
                            <Table className="tbl-hor" bordered>
                                <colgroup>
                                    <col style={{width:'30%'}}></col>
                                    <col style={{width:''}}></col>
                                </colgroup>
                                <tbody>
                                    <tr>
                                        <th className="essen">차종코드</th>
                                        <td>
                                            <Row className="select-wrap">
                                                <Col sm={8}>
                                                    <SelectPicker size="sm" data={[{ label: "차종"}]} searchable={false} cleanable={false} />
                                                </Col>
                                                <Col sm={4}>
                                                    <SelectPicker block style={{width:'100%'}} size="sm" data={[{ label: "MY"}]} searchable={false} cleanable={false} />
                                                </Col>
                                            </Row>
                                        </td>
                                    </tr>
                                    <tr>
                                        <th className="essen">언어코드</th>
                                        <td>
                                            <Row className="select-wrap">
                                                <Col sm={4}>
                                                    <SelectPicker size="sm" data={[{ label: "지역"}]} searchable={false} cleanable={false} />
                                                </Col>
                                                <Col sm={8}>
                                                    <SelectPicker block style={{width:'100%'}} size="sm" data={[{ label: "언어"}]} searchable={false} cleanable={false} />
                                                </Col>
                                            </Row>
                                        </td>
                                    </tr>
                                    <tr>
                                        <th className="">A코드</th>
                                        <td>
                                            <Form.Control size="sm" type="text"/> 
                                        </td>
                                    </tr>
                                    <tr>
                                        <th className="">정렬순서</th>
                                        <td>
                                            <Form.Control size="sm" type="text"/> 
                                        </td>
                                    </tr>
                                    <tr>
                                        <th className="">사용여부</th>
                                        <td>
                                            <SelectPicker size="sm" data={[{ label: "사용"}]} searchable={false} cleanable={false} />
                                        </td>
                                    </tr>
                                </tbody>
                            </Table>
                        </Modal.Body>

                        <Modal.Footer>
                            <Button variant="light" size="md" onClick={onHide}>취소</Button>
                            <Button variant="primary" size="md" onClick={onHide} >저장</Button>
                        </Modal.Footer>
                </Modal>
            </Form>

        </>
    );

};
export default VehlLangAdd;