import React from 'react';
import {Button, Modal, Table} from 'react-bootstrap';
import {Form, SelectPicker} from 'rsuite';

const PgmAdd = ({show, onHide}) => {

    const selectData = ['총재고관리', '세원재고관리', 'PDI재고관리', '...'].map(
        item => ({ label: item, value: item })
    );

    return (
        <>
            <Form>
                <Modal show={show} onHide={onHide} backdrop="static" keyboard={false} centered size="md" className="modal-custom">
                    <Modal.Header closeButton>
                        <Modal.Title>프로그램 등록</Modal.Title>
                    </Modal.Header>
                        <Modal.Body>
                            <Table className="tbl-hor" bordered>
                                <colgroup>
                                    <col style={{width:'30%'}}></col>
                                    <col style={{width:''}}></col>
                                </colgroup>
                                <tbody>
                                    <tr>
                                        <th className="essen">프로그램아이디</th>
                                        <td>
                                            <Form.Control size="sm" type="text"/> 
                                        </td>
                                    </tr>
                                    <tr>
                                        <th className="essen">프로그램명</th>
                                        <td colSpan="3">
                                            <Form.Control size="sm" type="text"/> 
                                        </td>
                                    </tr>
                                    <tr>
                                        <th className="essen">메뉴명</th>
                                        <td>
                                            <SelectPicker size="sm" searchable={false} cleanable={false} data={selectData} placeholder="선택" />
                                        </td>
                                    </tr>
                                    <tr>
                                        <th className="essen">Type</th>
                                        <td colSpan="3">
                                            <SelectPicker size="sm" data={[{ label: "선택"}]} searchable={false} cleanable={false} placeholder="선택"/>
                                        </td>
                                    </tr>
                                </tbody>
                            </Table>
                        </Modal.Body>

                        <Modal.Footer>
                            <Button variant="light" size="md" onClick={onHide}>취소</Button>
                            <Button variant="primary" size="md" onClick={onHide} >저장</Button>
                        </Modal.Footer>
                </Modal>
            </Form>
        </>
    );

};
export default PgmAdd;