import React from 'react';
import {Tab,Tabs} from 'react-bootstrap';

import PgmList from './PgmList';
import PgmAuthList from './PgmAuthList';

const PgmContainer = () => {
    
    const [leftWidth, setLeftWidth] = React.useState('150px')
    React.useEffect(() => {
        const getTitle = document.getElementById('section-title-width');
        const titleWidth = getTitle.clientWidth + 40;
        setLeftWidth(titleWidth);
    }, []);

    return (
        <>
            <Tabs  defaultActiveKey="tab1" style={{left: leftWidth}} >
                <Tab eventKey="tab1" title="프로그램관리">
                    <PgmList />
                </Tab>
                <Tab eventKey="tab2" title="프로그램 권한관리">
                   <PgmAuthList />
                </Tab>
            </Tabs>
        </>
    );

};
export default PgmContainer;