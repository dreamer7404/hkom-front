package com.oms.ivm.service;

import java.util.List;

import com.oms.ivm.dto.ComIvmReqDTO;
import com.oms.ivm.dto.IvmRequestMonitorResDTO;
import com.oms.ivm.dto.SewonIvModReqDTO;
import com.oms.ivm.dto.SewonIvModResDTO;
import com.oms.ivm.dto.SewonIvmReqDTO;
import com.oms.ivm.dto.SewonIvmResDTO;
import com.oms.ivm.dto.SewonWhotReqDTO;
import com.oms.ivm.dto.SewonWhotResDTO;


/**
 * <pre>
 * SewIvmService
 * </pre>
 *
 * @ClassName   : SewIvmService.java
 * @Description : 재고관리 > 세원재고관리 서비스
 * @author 김정웅
 * @since 2023.3.7
 * @see
 */

public interface SewIvmService {

    //세원재고관리 현황
    public List<SewonIvmResDTO> selectSewonIvmList(SewonIvmReqDTO sewonIvmReqDTO) throws Exception;

    //출고현황입력 팝업-조회
    public List<SewonWhotResDTO> selectSewonWhotList(ComIvmReqDTO reqDto) throws Exception;
    //출고현황입력 팝업-저장(수정)
    public Integer updateSewonWhotList(List<SewonWhotReqDTO> reqDto, String userEeno) throws Exception;
    //출고현황입력 팝업-삭제
    public Integer deleteSewonWhotList(List<SewonWhotReqDTO> reqDto, String userEeno) throws Exception;

    //재고보정입력 팝업-조회
    public List<SewonIvModResDTO> selectIvModList(ComIvmReqDTO reqDto) throws Exception;
    //재고보정입력 팝업-수정
    public Integer insertIvModList(List<SewonIvModReqDTO> reqDto, String userEeno, String dlExpdCoCd) throws Exception;
    //재고보정입력 팝업-삭제
    public Integer deleteIvModList(List<SewonIvModReqDTO> reqDto, String userEeno, String dlExpdCoCd) throws Exception;

    //출고현황
    public List<SewonWhotResDTO> selectIvmSewonWhotList(ComIvmReqDTO reqDto) throws Exception;

    //요청현황
    public List<IvmRequestMonitorResDTO> selectIvmSewonReqStateList(ComIvmReqDTO reqDto) throws Exception;



}
