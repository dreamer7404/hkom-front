package com.oms.stm.dto;

import java.util.List;

import org.apache.ibatis.type.Alias;

import com.oms.common.dto.CommReqDTO;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName : VehlMdyMgmtDTO.java
 * @Description : 차종연식관리 DTO
 * @author 김경훈
 * @since 2023. 4. 26.
 * @see
 */
@Alias("vehlMdyMgmtResDTO")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class VehlMdyMgmtResDTO extends CommReqDTO {

    private String qltyVehlCd;
    private String qltyVehlNm;
    private String mdlMdyCd;
    private String dlExpdRegnCd;
    private String dlExpdPrvsNm;
    private String desmp1Cd;
    private String defmp1Cd;
    private String chk;
    private String prevMdlMdyCd;
    private String prevStrtPack;
    private String prevEndPack;

}
