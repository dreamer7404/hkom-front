package com.oms.sys.dto;

import java.sql.Timestamp;

import org.apache.ibatis.type.Alias;

import lombok.AllArgsConstructor;
import lombok.Data;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @author 안경수
 * @since 2023. 1. 31.
 * @see
 */
@Alias("usrMgmtResDTO")
@Data
//@AllArgsConstructor
public class UsrMgmtResDTO {
    private String userEeno;
    private String userPw;
    private String userNm;
    private String blnsCoCd;
    private String userDcd;
    private String userEmlAdr;
    private String useYn;
    private String pprrEeno;
    private Timestamp framDtm;
    private String updrEeno;
    private Timestamp mdfyDtm;
    private Timestamp pwAltrDtm;    // 비번변경일시
    private Timestamp finLgiDtm;    // 최종로그인
    private Timestamp pwLockDtm;    // 잠김일시
    private Integer pwErrOft;       // 비번오류횟수
    private Integer userChgPw;      // 비번변경여부 => "0","1" => 현재모두 "0"
    private String grpCd;
    private Integer userOsetLgi;    // 비번변경여부 => 현재  "0", "1", null
    private String useGbn;

    private String coNm;        // 회사명
    private String deptNm;      // 부서며
    private String grpNm;       // 그룹명
    private Integer diffPwLock; // 잠김시간 차이(분)
}
