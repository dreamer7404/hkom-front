package com.oms.sys.dto;

import org.apache.ibatis.type.Alias;

import lombok.AllArgsConstructor;
import lombok.Data;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @author Windows ≫c¿eAU
 * @since 2023. 2. 20.
 * @see
 */

@Alias("useYnReqDTO")
@Data
//@AllArgsConstructor
public class UseYnReqDTO {
    private String useYn;
    private String[] list;
}
