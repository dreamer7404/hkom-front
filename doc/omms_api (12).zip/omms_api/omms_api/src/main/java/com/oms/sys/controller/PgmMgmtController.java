package com.oms.sys.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import able.cloud.core.web.HController;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.oms.sys.dto.PgmMgmtResDTO;
import com.oms.sys.dto.UsrMgmtReqDTO;
import com.oms.sys.service.PgmMgmtService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;


/**
 * <pre>
 * PgmMgmtController
 * </pre>
 *
 * @ClassName   : PgmMgmtController.java
 * @Description :
 * @author 안경수
 * @since 2023.1.19
 * @see
 */
@Tag(name = "PgmMgmtController", description = "")
@CrossOrigin(origins="*")
//@CrossOrigin(origins="http://localhost:3000", allowCredentials = "true")
@RequiredArgsConstructor
@RestController
@RequestMapping("/api")
public class PgmMgmtController extends HController {

    /**
     * 클래스 Injection
     */
    private final PgmMgmtService pgmMgmtService;
    private final HttpServletRequest request;


    /**
     * 메뉴 목록을 조회
     */
    @Operation(summary = "메뉴 목록을 조회")
    @GetMapping(value = "/pgmMgmts")
    public List<PgmMgmtResDTO> selectPgmMgmtList(@ModelAttribute UsrMgmtReqDTO usrMgmtReqDTO) throws Exception {
        usrMgmtReqDTO.setUserEeno("H2212239");
//        usrMgmtReqDTO.setUserEeno("logan.kim");
        List<PgmMgmtResDTO> list = pgmMgmtService.selectPgmMgmtList(usrMgmtReqDTO);
        return list;
//        return null;



    }
}
