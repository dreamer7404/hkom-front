package com.oms.sys.service;

import com.oms.sys.dto.UsrSessionResDTO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @author Windows ≫c¿eAU
 * @since 2023. 2. 24.
 * @see
 */

public interface UsrSessionService {
    public UsrSessionResDTO selectUsrSession(String userEeno) throws Exception;
}
