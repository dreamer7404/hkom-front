package com.oms.stm.service.impl;

import java.util.List;

import able.cloud.core.service.HService;

import org.springframework.stereotype.Service;

import com.oms.stm.dao.NatlMgmtDAO;
import com.oms.stm.dto.NatlMgmtReqDTO;
import com.oms.stm.dto.NatlMgmtResDTO;
import com.oms.stm.service.NatlMgmtService;

import lombok.RequiredArgsConstructor;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @author 안경수
 * @since 2023. 2. 24.
 * @see
 */
@RequiredArgsConstructor
@Service("natlMgmtService")
public class NatMgmtServiceImpl extends HService implements NatlMgmtService {

    private final NatlMgmtDAO natlMgmtDAO;



    @Override
    public List<NatlMgmtResDTO> selectNatlMgmtList(NatlMgmtReqDTO natlMgmtReqDTO) throws Exception {
        return natlMgmtDAO.selectNatlMgmtList(natlMgmtReqDTO);
    }


    @Override
    public NatlMgmtResDTO selectNatlMgmt(NatlMgmtReqDTO natlMgmtReqDTO) throws Exception {
        return natlMgmtDAO.selectNatlMgmt(natlMgmtReqDTO);
    }


    @Override
    public Integer insertNatlMgmt(NatlMgmtReqDTO natlMgmtReqDTO) throws Exception {
        return natlMgmtDAO.insertNatlMgmt(natlMgmtReqDTO);
    }

    @Override
    public Integer updateNatlMgmt(NatlMgmtReqDTO natlMgmtReqDTO) throws Exception {
        return natlMgmtDAO.updateNatlMgmt(natlMgmtReqDTO);
    }

    @Override
    public Integer deleteNatlMgmt(NatlMgmtReqDTO natlMgmtReqDTO) throws Exception {
        return natlMgmtDAO.deleteNatlMgmt(natlMgmtReqDTO);
    }



}
