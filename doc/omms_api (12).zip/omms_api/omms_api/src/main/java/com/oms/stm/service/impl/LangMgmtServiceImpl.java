package com.oms.stm.service.impl;

import java.util.List;

import able.cloud.core.service.HService;

import org.springframework.stereotype.Service;

import com.oms.stm.dao.LangMgmtDAO;
import com.oms.stm.dao.NatlMgmtDAO;
import com.oms.stm.dto.LangMgmtResDTO;
import com.oms.stm.dto.NatlMgmtReqDTO;
import com.oms.stm.dto.NatlMgmtResDTO;
import com.oms.stm.dto.StmComReqDTO;
import com.oms.stm.service.LangMgmtService;
import com.oms.stm.service.NatlMgmtService;

import lombok.RequiredArgsConstructor;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @author 안경수
 * @since 2023. 2. 24.
 * @see
 */
@RequiredArgsConstructor
@Service("langMgmtService")
public class LangMgmtServiceImpl extends HService implements LangMgmtService {

    private final LangMgmtDAO langMgmtDAO;

    /*
     * @see com.oms.stm.service.LangMgmtService#selectLangList(com.oms.stm.dto.StmComReqDTO)
     */
    @Override
    public List<LangMgmtResDTO> selectLangList(StmComReqDTO dto) {

        return langMgmtDAO.selectLangList(dto);
    }







}
