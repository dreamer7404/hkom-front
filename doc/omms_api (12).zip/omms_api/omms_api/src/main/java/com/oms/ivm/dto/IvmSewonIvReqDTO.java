package com.oms.ivm.dto;

import org.apache.ibatis.type.Alias;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @author 김정웅
 * @since 2023. 3. 17.
 * @see
 */
@Alias("ivmSewonIvReqDTO")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class IvmSewonIvReqDTO {

    private String userId;
    private String vehlcd;
    private String key;
    private String sdate;
    private String language;
    private String year;
    private String region;

}
