package com.oms.sys.dto;

import org.apache.ibatis.type.Alias;

import lombok.AllArgsConstructor;
import lombok.Data;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @author Windows ≫c¿eAU
 * @since 2023. 2. 20.
 * @see
 */

@Alias("authReqDTO")
@Data
@AllArgsConstructor
public class AuthReqDTO {
    private String userEeno;     // USER_EENO(tb_usr_mgmt) : VARCHAR(20)
    private String userPw;  
    private String blnsCoCd;     // 회사소속 : VARCHAR(4)
    private String userDcd;     // 부서 : VARCHAR(8)

}
