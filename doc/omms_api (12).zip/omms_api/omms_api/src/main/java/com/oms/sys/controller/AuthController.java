package com.oms.sys.controller;

import java.util.UUID;

import javax.servlet.http.HttpServletRequest;

import able.cloud.core.web.HController;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.oms.cmm.security.JwtTokenProvider;
import com.oms.cmm.utils.AES128;
import com.oms.cmm.utils.Utils;
import com.oms.sys.dto.AuthReqDTO;
import com.oms.sys.dto.AuthResDTO;
import com.oms.sys.dto.UsrMgmtReqDTO;
import com.oms.sys.dto.UsrMgmtResDTO;
import com.oms.sys.dto.UsrSessionResDTO;
import com.oms.sys.service.UsrMgmtService;
import com.oms.sys.service.UsrSessionService;

import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @author 안경수
 * @since 2023. 1. 19.
 * @see
 */
@Tag(name = "AuthController", description = "")
@CrossOrigin(origins="*")
@RequiredArgsConstructor
@RestController
@RequestMapping("/api")
public class AuthController extends HController {
    
    private final HttpServletRequest request;
    private final JwtTokenProvider jwtTokenProvider;
    private final UsrMgmtService usrMgmtService;
    private final UsrSessionService usrSessionService;
    
    
   /*
    * 사용자등록
    */
    @PostMapping("/auth/signup")
    public Integer signup(@RequestBody UsrMgmtReqDTO usrMgmtReqDTO) throws Exception {
        
        UsrMgmtResDTO usrMgmtResDTO = usrMgmtService.selectUsrMgmt(usrMgmtReqDTO.getUserEeno()); 
        
        // 이미 사용중인 아이디가 있으면
        if(usrMgmtResDTO != null) {
            return -1;
        }
        
        // 등록
        usrMgmtService.insertUsrMgmt(usrMgmtReqDTO);
        
        
        return 1;
    }
    
    /*
     * 로그인
     */
    @PostMapping("/auth/login")
    public AuthResDTO login(@RequestBody AuthReqDTO authReqDTO) throws Exception {
        
        // get from db
        UsrMgmtResDTO usrMgmtResDTO = usrMgmtService.selectUsrMgmt(authReqDTO.getUserEeno());
        if(usrMgmtResDTO == null) {
            return new AuthResDTO(-1, null, null, null);
        }
        
        // password
        if(!usrMgmtResDTO.getUserPw().equals(AES128.SHA256(authReqDTO.getUserPw()))) {
            
            // 비번오류횟수 증가
            
            
            // 5회이상 loginLock
            
            
            return new AuthResDTO(-1, null, null, null);
        }
        
        // useYn
        if(!usrMgmtResDTO.getUseYn().equals("Y")) {
            return new AuthResDTO(-1, null, null, null);
        }
        
        // session정보 가져오기
        UsrSessionResDTO UsrSessionResDTO = usrSessionService.selectUsrSession(authReqDTO.getUserEeno());
        
        // access time이 120분 지났나?
        
        // ip가 같은가?
        
        
        
        // 비밀번호잠김일시 체크
//        if(usrMgmtResDTO.getPwLockDtm() != null && ) {
//            return -1L;
//        }
        
        String ip = Utils.getRemoteAddress(request);
        // 로그인 log저장
        
         
        // 토큰발급
        String token = jwtTokenProvider.createToken(authReqDTO.getUserEeno(), authReqDTO.getBlnsCoCd(), authReqDTO.getUserDcd());
        UUID uuid = UUID.randomUUID();
        
        return  new AuthResDTO(1, token, uuid.toString(), authReqDTO.getUserEeno());
        
    }

}
