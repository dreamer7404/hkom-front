package com.oms.stm.dto;


import org.apache.ibatis.type.Alias;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @author 안경수
 * @since 2023. 2. 9.
 * @see
 */

@Alias("boardResDTO")
@Data
@NoArgsConstructor
@AllArgsConstructor

public class BoardResDTO {


    @Schema(type = "string", example = " ")
    private String  scrnSn;                       //화면일련번호
    @Schema(type = "string", example = " ")
    private String  affrScnCd;                 //업무구분코드
    @Schema(type = "string", example = " ")
    private String  rgnEeno;                     //등록자사원번호
    private String  blcRgstYmd;               //게시물등록년월일
    private String  blcTitlNm;                  //게시물제목명
    private String  blcSbc;                        //게시물내용
    private String  attcYn;                       //첨부여부
    private String  n1afp2Adr;                  //1차첨부파일경로주소
    private String  pprrEeno;                   //작성자사원번호
    private String  framDtm;                   //작성일시
    private String  updrEeno;                  //수정자사원번호
    private String  mdfyDtm;                   //수정일시
    private String  bulStrtYmd;              //게시시작년월일
    private String  bulFnhYmd;               //게시종료년월일
    private String  bulYn;                       //게시여부

}
