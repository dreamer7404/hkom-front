package com.oms.sys.service.impl;

import java.util.List;

import able.cloud.core.service.HService;

import org.springframework.stereotype.Service;

import com.oms.sys.dao.UsrMgmtDAO;
import com.oms.sys.dto.UsrMgmtReqDTO;
import com.oms.sys.dto.UsrMgmtResDTO;
import com.oms.sys.model.UsrMgmt;
import com.oms.sys.service.UsrMgmtService;

import lombok.RequiredArgsConstructor;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @author 안경수
 * @since 2023. 2. 24.
 * @see
 */

@RequiredArgsConstructor
@Service("usrMgmtService")
public class UsrMgmtServiceImpl extends HService implements UsrMgmtService {

    private final UsrMgmtDAO usrMgmtDAO;

    @Override
    public void insertUsrMgmt(UsrMgmtReqDTO usrMgmtReqDTO) throws Exception {
        usrMgmtDAO.insertUsrMgmt(usrMgmtReqDTO);
    }

    @Override
    public void updateUsrMgmt(UsrMgmt usrMgmt) throws Exception {
        usrMgmtDAO.updateUsrMgmt(usrMgmt);
    }

    @Override
    public void deleteUsrMgmt(UsrMgmt usrMgmt) throws Exception {
        usrMgmtDAO.deleteUsrMgmt(usrMgmt);
    }

    @Override
    public UsrMgmtResDTO selectUsrMgmt(String id) throws Exception {
        return usrMgmtDAO.selectUsrMgmt(id);
    }

    @Override
    public List<UsrMgmtResDTO> selectUsrMgmtList(UsrMgmtReqDTO usrMgmtReqDTO) throws Exception {
        return usrMgmtDAO.selectUsrMgmtList(usrMgmtReqDTO);
    }

    /*
     * @see com.oms.sys.service.UsrMgmtService#deleteVehlAuth(com.oms.sys.model.UsrMgmt)
     */
    @Override
    public void deleteVehlAuth(UsrMgmtReqDTO usrMgmt) throws Exception {
        usrMgmtDAO.deleteVehlAuth(usrMgmt);

    }

    /*
     * @see com.oms.sys.service.UsrMgmtService#insertVehlAuth(com.oms.sys.model.UsrMgmt)
     */
    @Override
    public void insertVehlAuth(UsrMgmtReqDTO usrMgmt) throws Exception {
        usrMgmtDAO.insertVehlAuth(usrMgmt);

    }
}
