package com.oms.common.dto;

import java.sql.Timestamp;

import lombok.Data;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @author 안경수
 * @since 2023. 5. 17.
 * @see
 */
@Data
public class MailSndDTO {
    private Integer EmlCd; // tb_log_eml pk

    private String rcvrId; // 수신자 사번
    private String adreEml; // 수신자 이메일
    private String emlStCd; // (20) 상태
    private Timestamp sndDate; //발송일
}
