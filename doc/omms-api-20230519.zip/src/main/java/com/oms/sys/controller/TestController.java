package com.oms.sys.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.oms.cmm.security.JwtTokenProvider;
import com.oms.cmm.utils.Utils;
import com.oms.sys.dto.TestIvmTotalReqDTO;
import com.oms.sys.dto.TestIvmTotalResDTO;
import com.oms.sys.service.TestService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @author Windows ≫c¿eAU
 * @since 2023. 3. 13.
 * @see
 */
@Tag(name = "TestController", description = "")
@RequiredArgsConstructor
@RestController
@RequestMapping("/api")
public class TestController {

    private final HttpServletRequest request;
    private final TestService testService;

    @Operation(summary = "배치테스트")
    @GetMapping(value = "/testBatch")
    public String testBatch() throws Exception {
        return testService.testBatch();
    }


    @Operation(summary = "TEST 총재고관리 조회")
    @GetMapping(value = "/testIvmTotal")
    public List<TestIvmTotalResDTO> testIvmTotal(@ModelAttribute TestIvmTotalReqDTO testIvmTotalReqDTO) throws Exception {
        testIvmTotalReqDTO.setUserEeno(Utils.getUserEeno(request)); // 사원번호
        List<TestIvmTotalResDTO> list = testService.selectTotalIvmList(testIvmTotalReqDTO);
        return list;
    }

}
