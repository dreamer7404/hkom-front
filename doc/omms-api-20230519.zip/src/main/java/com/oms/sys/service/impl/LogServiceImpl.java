package com.oms.sys.service.impl;

import org.springframework.stereotype.Service;

import com.oms.sys.dao.LogDAO;
import com.oms.sys.dto.SchedLogDTO;
import com.oms.sys.service.LogService;

import lombok.RequiredArgsConstructor;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @author Windows i¿½i¿½i¿½i¿½i¿½
 * @since 2023. 5. 19.
 * @see
 */

@RequiredArgsConstructor
@Service("logService")
public class LogServiceImpl implements LogService {

    private final LogDAO logDAO;

    @Override
    public int insertSchedLog(SchedLogDTO schedLogDTO) {
        return logDAO.insertSchedLog(schedLogDTO);
    }

}
