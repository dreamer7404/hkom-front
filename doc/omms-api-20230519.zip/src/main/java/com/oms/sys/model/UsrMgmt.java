package com.oms.sys.model;

import java.sql.Timestamp;
import java.util.Collection;

import org.apache.ibatis.type.Alias;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import lombok.Data;

/**
 * <pre>
 * UsrMgmt VO
 * </pre>
 *
 * @Class Name : UsrMgmt.java
 * @Description : 클래스 설명을 기술합니다. 
 * @author 안경수
 * @since 2023.1.19
 * @see 
 */

@Data
public class UsrMgmt{

    private String userEeno;     // USER_EENO(tb_usr_mgmt) : VARCHAR(20)
    private String userPw;     // USER_PW(tb_usr_mgmt) : VARCHAR(256)
    private String userNm;     // USER_NM(tb_usr_mgmt) : VARCHAR(50)
    private String blnsCoCd;     // 회사소속 : VARCHAR(4)
    private String userDcd;     // 부서 : VARCHAR(8)
    private String userEmlAdr;     // USER_EML_ADR(tb_usr_mgmt) : VARCHAR(100)
    private String useYn;     // USE_YN(tb_usr_mgmt) : VARCHAR(1)
    private String pprrEeno;     // PPRR_EENO(tb_usr_mgmt) : VARCHAR(20)
    private Timestamp framDtm;     // FRAM_DTM(tb_usr_mgmt) : DATETIME(19)
    private String updrEeno;     // UPDR_EENO(tb_usr_mgmt) : VARCHAR(20)
    private Timestamp mdfyDtm;     // MDFY_DTM(tb_usr_mgmt) : DATETIME(19)
    private Timestamp pwAltrDtm;     // PW_ALTR_DTM(tb_usr_mgmt) : DATETIME(19)
    private Timestamp finLgiDtm;     // FIN_LGI_DTM(tb_usr_mgmt) : DATETIME(19)
    private Timestamp pwLockDtm;     // PW_LOCK_DTM(tb_usr_mgmt) : DATETIME(19)
    private Integer pwErrOft;     // PW_ERR_OFT(tb_usr_mgmt) : INTEGER(11)
    private String userChgPw;     // USER_CHG_PW(tb_usr_mgmt) : VARCHAR(1)
    private String grpCd;     // GRP_CD(tb_usr_mgmt) : VARCHAR(3)
    private String userOsetLgi;     // USER_OSET_LGI(tb_usr_mgmt) : VARCHAR(1)
    private String useGbn;     // USE_GBN(tb_usr_mgmt) : VARCHAR(1)
    
}
