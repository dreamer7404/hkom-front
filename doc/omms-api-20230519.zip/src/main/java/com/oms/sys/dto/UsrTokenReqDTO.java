package com.oms.sys.dto;

import org.apache.ibatis.type.Alias;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @author 안경수
 * @since 2023. 4. 20.
 * @see
 */


@Alias("usrTokenReqDTO")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class UsrTokenReqDTO {
    private String userEeno;
    private String ip;
    private String browserId;
    private String refreshToken;
    private Long refreshTokenValidTime;
}
