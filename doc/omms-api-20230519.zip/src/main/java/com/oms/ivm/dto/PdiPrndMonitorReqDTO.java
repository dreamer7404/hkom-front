package com.oms.ivm.dto;

import org.apache.ibatis.type.Alias;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @author 김정웅
 * @since 2023. 5. 8.
 * @see
 */
@Alias("pdiPrndMonitorReqDTO")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class PdiPrndMonitorReqDTO extends ComIvmReqDTO {
    private String vWrkYmd;
    private String vFramYmd;
    private String vLocalChar;

    private int vTddPrdnPlanQty;
    private int vTddPrdnQty3;
    private int vTddPrdnQty;

    private String dlExpdPacScnCd;
    private String dlExpdPdiCd;
}
