package com.oms.ivm.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import able.cloud.core.web.HController;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.oms.cmm.global.Consts;
import com.oms.cmm.utils.Utils;
import com.oms.ivm.dto.ComIvmReqDTO;
import com.oms.ivm.dto.IvmRequestMonitorResDTO;
import com.oms.ivm.dto.SewonIvModReqDTO;
import com.oms.ivm.dto.SewonIvModResDTO;
import com.oms.ivm.dto.SewonIvmReqDTO;
import com.oms.ivm.dto.SewonIvmResDTO;
import com.oms.ivm.dto.SewonWhotReqDTO;
import com.oms.ivm.dto.SewonWhotResDTO;
import com.oms.ivm.service.ComIvmService;
import com.oms.ivm.service.SewIvmService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;


/**
 * <pre>
 * SwnIvmController
 * </pre>
 *
 * @ClassName   : SwnIvmController.java
 * @Description : 재고관리 > 세원재고관리 컨트롤러
 * @author 김정웅
 * @since 2023.3.27
 * @see
 */
@Tag(name = "SwnIvmController", description = "")
//@CrossOrigin(origins="*")
@RequiredArgsConstructor
@RestController
@RequestMapping("/api")
public class SwnIvmController extends HController {

    /**
     * 클래스 Injection
     */
    private final HttpServletRequest request;
    private final SewIvmService sewIvmService;
    private final ComIvmService comIvmService;

    /**
     * 재고관리 > 세원재고관리 > 세원재고관리 현황
     */
    @Operation(summary = "세원재고관리 조회")
    @GetMapping("/ivmSewonIvmInfos")
    public List<SewonIvmResDTO> selectSewonIvmList(@ModelAttribute SewonIvmReqDTO reqDto) throws Exception {
        //사용자 ID, 회사코드 할당
        reqDto.setUserEeno(Utils.getUserEeno(request));
        reqDto.setDlExpdCoCd(Utils.getDlExpdCoCd(request));

        List<SewonIvmResDTO> result = sewIvmService.selectSewonIvmList(reqDto);
        return result;
    }

    /**
     * 재고관리 > 세원재고관리 > 출고현황팝업
     * @Description 차종 선택하여 출고현황 조회시 발간번호 별로 데이터 출력이 필요하여, 해당 팝업은 반드시 데이터 DB조회를 해야함.
     */
    @Operation(summary = "출고현황입력 팝업")
    @GetMapping("/ivmSewonWhotInfos")
    public List<SewonWhotResDTO> selectSewonWhotList(@ModelAttribute ComIvmReqDTO reqDto) throws Exception {
        //사용자 ID, 회사코드 할당
        reqDto.setUserEeno(Utils.getUserEeno(request));
        reqDto.setDlExpdCoCd(Utils.getDlExpdCoCd(request));

        List<SewonWhotResDTO> result = sewIvmService.selectSewonWhotList(reqDto);

        return result;
    }

    /**
     * 재고관리 > 세원재고관리 > 출고현황 저장, 삭제
     */
    @Operation(summary = "세원재고 출고현황 - 등록,삭제", description = "")
    @Parameter(in = ParameterIn.HEADER, name="_method", schema=@Schema(type="string"))
    @PostMapping(value = "/ivmSewonWhotInfos")
    public Integer insertIvmSewonWhotInfos(@RequestBody List<SewonWhotReqDTO> reqDto) throws Exception {
        String method = Utils.getMethod(request);
        String userEeno = Utils.getUserEeno(request);
        String dlExpdCoCd = Utils.getDlExpdCoCd(request);

        /**
         * @TODO 기아만 PRDN_PLNT_CD 컬럼이 있기때문에, 나중에 insert 쿼리에 추가해줘야 한다 (default:'N')
         */

        int result = 0;

        if(method.equals(Consts.UPDATE)) {
            result = sewIvmService.updateSewonWhotList(reqDto, userEeno);
        } else if(method.equals(Consts.DELETE)) {
            /**
             * @TODO delete 추가해야 함.
             */
            result = sewIvmService.deleteSewonWhotList(reqDto, userEeno);
        } else {
            return 0;
        }

        return result;
    }

      //재고보정 팝업 관련하여  ComIvmController로 이전
//    /**
//     * 재고관리 > 세원재고관리 > 재고보정팝업
//     * @Description 차종 선택하여 재고보정 조회시 발간번호 별로 데이터 출력이 필요하여, 해당 팝업은 반드시 데이터 DB조회를 해야함.
//     */
//    @Operation(summary = "재고보정입력 팝업")
//    @GetMapping("/ivmIvModInfos")
//    public List<SewonIvModResDTO> selectIvModList(@ModelAttribute ComIvmReqDTO reqDto) throws Exception {
//        reqDto.setUserEeno(Utils.getUserEeno(request));
//        reqDto.setDlExpdCoCd(Utils.getDlExpdCoCd(request));
//
//        List<SewonIvModResDTO> result = sewIvmService.selectIvModList(reqDto);
//
//        return result;
//    }
//
//    /**
//     * 재고관리 > 세원재고관리 > 재고보정 저장, 삭제
//     */
//    @Operation(summary = "세원재고 재고보정 - 등록,삭제", description = "")
//    @Parameter(in = ParameterIn.HEADER, name="_method", schema=@Schema(type="string"))
//    @PostMapping(value = "/ivmIvModInfos")
//    public Integer insertIvModList(@RequestBody List<SewonIvModReqDTO> reqDto) throws Exception {
//        String method = Utils.getMethod(request);
//        String userEeno = Utils.getUserEeno(request);
//        String dlExpdCoCd = Utils.getDlExpdCoCd(request);
//
//        int result = 0;
//
//        if(method.equals(Consts.INSERT)) {
//            result = sewIvmService.insertIvModList(reqDto, userEeno, dlExpdCoCd);
//        } else if(method.equals(Consts.DELETE)) {
//            result = sewIvmService.deleteIvModList(reqDto, userEeno, dlExpdCoCd);
//        } else {
//            return 0;
//        }
//
//        return result;
//    }

    /**
     * 재고관리 > 세원재고관리 > 출고현황
     */
    @Operation(summary = "출고현황")
    @GetMapping("/ivmSewonWhotInfos2")
    public List<SewonWhotResDTO> selectIvmSewonWhotList(@ModelAttribute ComIvmReqDTO reqDto) throws Exception {
        reqDto.setUserEeno(Utils.getUserEeno(request));
        reqDto.setDlExpdCoCd(Utils.getDlExpdCoCd(request));

        List<SewonWhotResDTO> result = sewIvmService.selectIvmSewonWhotList(reqDto);

        return result;
    }

    /**
     * 재고관리 > 세원재고관리 > 요청현황
     */
    @Operation(summary = "요창현황")
    @GetMapping("/ivmSewonRequestInfos")
    public List<IvmRequestMonitorResDTO> selectIvmSewonReqStateList(@ModelAttribute ComIvmReqDTO reqDto) throws Exception {

        reqDto.setUserEeno(Utils.getUserEeno(request));
        reqDto.setDlExpdCoCd(Utils.getDlExpdCoCd(request));

        List<IvmRequestMonitorResDTO> result = sewIvmService.selectIvmSewonReqStateList(reqDto);

        return result;
    }
}