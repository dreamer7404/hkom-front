// react
import React, {useState, useEffect, useCallback, useRef, useMemo} from 'react';
import { AgGridReact } from 'ag-grid-react';
import {Col, Modal, Button} from 'react-bootstrap';
import {Form, SelectPicker} from 'rsuite';

//--------------  서버데이터용 필수 -------------------------------
import { useQuery, useQueryClient, useMutation} from 'react-query';
import { getData, postData } from '../../../../utils/async';
import { API, CONSTANTS } from '../../../../utils/constants';
import useStore from '../../../../utils/store';
//--------------// 서버데이터용 필수 -------------------------------
import { confirmAlert } from 'react-confirm-alert'; 
import ConfirmAlert from   '../../../Common/ConfirmAlert'; 

import GridMenuGroupList from '../_Grid/GridMenuGroupList';
import Total from '../../../Common/Total';

import MenuGroupAdd from '../Popup/MenuGroupAdd';
import MenuGroupUpdate from '../Popup/MenuGroupUpdate';

const MenuGroupList = () => {

    //------------------- 필수 공통 ------------------------------
    const {keyword } = useStore();  // 조회키워드 가져오기

    const [activePage, setActivePage] = useState(1);    // 페이지번호
    const [limit, setLimit] = useState(50);             // 페이지행수

    const onChangePage = val => {
        setActivePage(val);
    };
    const onChangeLimit = val => {
        setLimit(val);
    };
    useEffect(()=>{
        onChangePage(1); // 페이지번호 리셋
    },[keyword]);


    //-------------------// 필수 공통 ------------------------------

    // 메뉴그룹
    const queryResult = useQuery([API.pgmMgmtGrps], () => getData(API.pgmMgmtGrps));

    useEffect(()=> {
        if(queryResult.data){
            console.log('queryResult.data', queryResult.data)
        }
    },[queryResult.data])
    

    // 셀 클릭
    const onCellClicked = e => {
        if(e.column.colId === 'menuGroup'){
            setMenuGroupUpdatePop(true)
        }
    };

    const [menuGroupAddPop, setMenuGroupAddPop] = useState(false);
    const [menuGroupUpdatePop, setMenuGroupUpdatePop] = useState(false);

    return (
        <>
            <div className="grid-wrap" style={{paddingTop:'10px', borderTop:'2px solid var(--main-color)'}}>
                <div className="grid-btn-wrap">
                    <div className="right-align">
                        {/*--------- 버튼 -----------*/}
                        <Button variant="outline-secondary" size="sm" onClick={() => setMenuGroupAddPop(true)}>메뉴그룹 등록</Button>{' '}
                        <Button variant="outline-secondary" size="sm">사용</Button>{' '}
                        <Button variant="outline-secondary" size="sm">미사용</Button>{' '}
                    </div>
                </div>
                {/*--------- Grid -----------*/}
                <GridMenuGroupList 

                    queryResult={queryResult}
                    limit={limit}
                    activePage={activePage}
                    onCellClicked={onCellClicked}
                    />

                {/*--------- 페이징 -----------*/}
                <Total 
                    total={queryResult && queryResult.data && queryResult.data.length}
                    limit={limit}
                    activePage={activePage}
                    onChangePage={onChangePage}
                    onChangeLimit={onChangeLimit}
                />
            </div>

            {menuGroupAddPop && <MenuGroupAdd show={menuGroupAddPop} onHide={() => setMenuGroupAddPop(false)} />}
            {menuGroupUpdatePop && <MenuGroupUpdate show={menuGroupUpdatePop} onHide={() => setMenuGroupUpdatePop(false)} />}
        </>
    )
};
export default MenuGroupList;