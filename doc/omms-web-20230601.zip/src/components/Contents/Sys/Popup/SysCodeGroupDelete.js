import React, {useState, useMemo} from 'react';
import { AgGridReact } from 'ag-grid-react';
import {Col, Modal, Button} from 'react-bootstrap';
import {Form, SelectPicker} from 'rsuite';
import SearchIcon from '@rsuite/icons/Search';

const SysCodeGroupDelete = ({show, onHide}) => {

    const [rowData] = useState([
        {groupCd: "001",groupNm:'테스트그룹1'},
        {groupCd: "001",groupNm:'테스트그룹2'},
    ]);

    const columnDefs = [
        {
          checkboxSelection: true,
          headerCheckboxSelection: true,
          width:45,
          maxWidth:45,
          minWidth:45,
          sortable:false
        },
        {
            headerName: '그룹코드',
            field: 'groupCd',
            maxWidth:'150',
        },
        {
          headerName: '그룹명',
          field: 'groupNm',
        },
    ]

    const defaultColDef = useMemo(() => {
        return {
            initialWidth: 90,
            sortable: true,
            resizable:true,
        };
    }, []);

    const onFirstDataRendered = (params) => {
        params.api.sizeColumnsToFit();
    };

    return (
        <>
            <Form>
                <Modal show={show} onHide={onHide} backdrop="static" keyboard={false} centered size="md" className="modal-custom">
                    <Modal.Header closeButton>
                        <Modal.Title>그룹코드 삭제</Modal.Title>
                    </Modal.Header>
                    <Modal.Body>
                        <div className="ag-theme-alpine" style={{height:300, minWidth:300}}>
                            <AgGridReact
                                rowData={rowData}
                                columnDefs={columnDefs}
                                defaultColDef={defaultColDef}
                                rowSelection={'multiple'}
                                suppressRowClickSelection= {true} 
                                onFirstDataRendered={onFirstDataRendered}
                                suppressSizeToFit={true}    
                                onGridSizeChanged={onFirstDataRendered}     
                                >
                            </AgGridReact>
                        </div>
                    </Modal.Body>
                    <Modal.Footer>
                        <Button variant="light" size="md" onClick={onHide}>취소</Button>
                        <Button variant="outline-danger" size="md" onClick={onHide}>삭제</Button>
                    </Modal.Footer>
                </Modal>
            </Form>
        </>
    );

};
export default SysCodeGroupDelete;