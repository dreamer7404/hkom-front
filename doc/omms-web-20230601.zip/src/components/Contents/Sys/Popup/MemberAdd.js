/* eslint-disable react-hooks/exhaustive-deps */
import React ,{useState, useRef, useEffect, useMemo} from 'react';
import {Button,Modal, Row, Col, Table} from 'react-bootstrap';
import {Schema, Form, SelectPicker} from 'rsuite';
import { AgGridReact } from 'ag-grid-react';

//--------------  서버데이터용 필수 -------------------------------
import { useQuery, useMutation} from 'react-query';
import { getData, postData } from '../../../../utils/async';
import { API, CONSTANTS } from '../../../../utils/constants';
//--------------// 서버데이터용 필수 -------------------------------
import { confirmAlert } from 'react-confirm-alert'; 
import ConfirmAlert from   '../../../Common/ConfirmAlert'; 
import { escapeCharChangeForGrid, escapeCharChange} from '../../../../utils/commUtils';

import DraggableModal from '../../../Common/DraggableModal';


const { StringType} = Schema.Types;
const model = Schema.Model({
    userEeno: StringType().isRequired('아이디를 입력해주세요.')
                            .pattern(/^[a-zA-Z0-9]*$/, '영문자,숫자로 입력해주세요')
                            .rangeLength(7, 20, '7-20자로 입력해주세요'),
    userNm: StringType().isRequired('이름을 입력해주세요.')
                            .pattern(/^[가-힣a-zA-Z0-9]+$/, '특수문자는 _ . 만 입력가능합니다')
                            .rangeLength(2, 30, '2-30자로 입력해주세요'),
    userEmlAdr: StringType().isRequired('이메일을 입력해주세요.')
                            .isEmail('이메일 형식에 맞게 입력해주세요.')
                            .maxLength(90, '이메일주소가 너무 깁니다.'),
    blnsCoCd: StringType().isRequired('소속회사를 선택해 주세요.'),
    userDcd: StringType().isRequired('부서를 선택해 주세요.'),
    grpCd: StringType().isRequired('그룹을 선택해 주세요.'),
    useYn: StringType().isRequired('사용유무를 선택해 주세요.'),

    // 리스트 테스트
    // list: ArrayType().of(
    //     ObjectType().shape({
    //         nick: StringType().minLength(6, '6자이상 입력해주세요.').isRequired('별명을 입력해주세요.'),
    //         age: StringType().minLength(2, '2자이상 입력해주세요.').isRequired('나이를 입력해주세요.'),
    //     })
    //   )
});



const MemberAdd = ({show, onHide}) => {

    const gridRef = useRef();

    const defaultColDef = useMemo(() => {
        return {
            initialWidth: 90,
            resizable:true,
        };
    }, []);

    const columnDefs = [
        {
            checkboxSelection: true,
            headerCheckboxSelection: true,
            width:45,
            maxWidth:45,
            minWidth:45
        },
        {
            headerName: '차종',
            children: [
                { 
                    headerName:'차종코드', 
                    field: 'qltyVehlCd',
                    maxWidth:100,
                    sortable:true,
                    filter: 'agTextColumnFilter',
                    floatingFilter: true,
                    suppressMenu: true,
                    filterParams: {
                        filterOptions: ['contains'],
                    }},
                { 
                    headerName:'차종명',
                    field: 'qltyVehlNm', 
                    filter: 'agTextColumnFilter',
                    sortable:true,
                    floatingFilter: true,
                    suppressMenu: true,
                    cellRenderer:"escapeCharChangeForGrid",
                    filterParams: {
                        filterOptions: ['contains'],
                    }},
            ],
        },
     
    ]

    const onFirstDataRendered = (params) => {
        params.api.sizeColumnsToFit();
    };

    // 입력데이타 초기화
    useEffect(() => {
        // formValue 초기화
        setFormValue({
                userEeno: '',
                userNm: '',
                userEmlAdr: '',
                blnsCoCd: '',
                userDcd: '',
                grpCd: '',
                useYn:'',
                usrVehls:[],
        });
        // formError 초기화
        formRef.current.resetErrors(); // or cleanErrors();
    },[show])

    // 회사목록 가져오기
    const paramsCo = {dlExpdGCd: CONSTANTS.grpCdCo};
    const coCombo = useQuery([API.codeCombo, paramsCo], () => getData(API.codeCombo, paramsCo));

    // 부서목록(용역회사) 가져오기
    const paramsDept = {dlExpdGCd: CONSTANTS.grpCdDept};
    const deptCombo = useQuery([API.codeCombo, paramsDept], () => getData(API.codeCombo, paramsDept));

    // 그룹목록 가져오기
    const grpCombo = useQuery([API.grpCombo], () => getData(API.grpCombo));

    // 차종권한목록 가져오기
    const userVehls = useQuery([API.userVehls], () => getData(API.userVehls));

    // 사용자등록하기
    const usrmgmtMutate = useMutation((params => postData(API.usrmgmt, params, CONSTANTS.insert)),{
        onSuccess: res => {
            if(res === 1){
                confirmAlert({
                    closeOnClickOutside: false,
                    customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}  title={"알림"} msg={"저장이 완료되었습니다.<br />이메일로 전송된 임시패스워드로 로그인해주세요."}  />
                });
                onHide(true); // 창닫기 & refetch
            }else{
                confirmAlert({
                    closeOnClickOutside: false,
                    customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}  title={"알림"} msg={"등록이 실패했습니다.<br /> 관리자에게 문의해주세요."}  />
                });
                onHide(false); // 창닫기
            }
           
        }
    });

    const [grpList, setgrpList] = useState([]);
    useEffect(() => {
        if(grpCombo.isSuccess){
            setgrpList(grpCombo.data);
        }
    },[grpCombo.status])


    // Form 정의
    const formRef = React.useRef();
    const [formError, setFormError] = React.useState({});
    const [formValue, setFormValue] = React.useState({
      userEeno: '',     // 아이디
      userNm: '',       // 이름
      userEmlAdr: '',   // 이메일
      blnsCoCd: '',     // 회사코드
      userDcd: '',      // 부서코드
      grpCd: '',        // 그룹코드
      useYn:'',         // 사용유무
      usrVehls:[],      // 차량코드
    });

    // 저장버튼 클릭
    const handleSubmit = () => {
        // validation 체크
        if (!formRef.current.check()) {
            return;
        }
        if(useUserEeno === null){
            confirmAlert({
                closeOnClickOutside: false,
                customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}  title={"알림"} msg={"중복확인을 해주세요."}  />
            })
            return;
        }
        //  중복체크된 사용자아이디
        formValue.userEeno = useUserEeno;

        // grid 선택된목록 가져오기
        if(formValue.usrVehls.length > 0){
            formValue.usrVehls = gridRef.current.api.getSelectedRows(); 
        }
        // 사용자 등록 실행
        usrmgmtMutate.mutate(formValue);
    };


    //  중복체크된 사용자아이디 따로저장
    const [useUserEeno, setUseUserEeno] = useState(null);

    // 사용자정보 가져오기(아이디 중복체크)
    const usrmgmt = useQuery([API.checkUserEeno + '/' + formValue.userEeno], () => getData(API.checkUserEeno + '/' + formValue.userEeno), {
        enabled: false,
        onSuccess: res => {
            if(res === 1){ // 아이디없음, 사용가능
                setUseUserEeno(formValue.userEeno);
                confirmAlert({
                    closeOnClickOutside: false,
                    customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}  title={"알림"} msg={" 사용할수 있는 아이디입니다.<br />사용자등록을 진행해 주세요."}  />
                })
            }
            else {
                setUseUserEeno(null);
                confirmAlert({
                    closeOnClickOutside: false,
                    customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}  title={"알림"} msg={"중복된 아이디가 존재합니다.<br />아이디를 다시 확인해주세요."}  />
                })
            }
        }
    });


    // 중복체크 실행
    const onClickCheckId = () => {
        // 아이디만 체크
        formRef.current.checkForField('userEeno', result => {
            if(!result.hasError){  // 입력에러가 없으면
                usrmgmt.refetch(); // 중복체크실행
            }
        });
    };


    // 부서명을 회사구분에따른 필터링
    const [depts, setDepts] = useState([]);
    useEffect(() => {
        if(deptCombo.isFetched && deptCombo.data){
            if(formValue.blnsCoCd === ''){
                setDepts(deptCombo.data); 
            }else if(formValue.blnsCoCd === '01' || formValue.blnsCoCd === '02'){ // 현재/기아
                setDepts(deptCombo.data.filter(d => (d.value === '' || d.value === '01')));
            }else if(formValue.blnsCoCd === '03'){ // 외주
                setDepts(deptCombo.data.filter(d => (d.value !== '01' && d.value !== '03' &&  d.value !== '04' && d.value !== '05' && d.value !== '06' ))
                        .concat(deptCombo.data.filter(d => (d.value === '06')))); //기타 뒤에추가
            }else if(formValue.blnsCoCd === '04'){ // PDI
                setDepts(deptCombo.data.filter(d => (d.value === '' || d.value === '03')));
            }else if(formValue.blnsCoCd === '05'){ // 용산
                setDepts(deptCombo.data.filter(d => (d.value === '' || d.value === '05')));
            }else if(formValue.blnsCoCd === '06'){ // 인쇄업체
                setDepts(deptCombo.data.filter(d => (d.value === '' || d.value === '04'))); // 세원
            }else if(formValue.blnsCoCd === '07'){ // 기타
                setDepts(deptCombo.data.filter(d => (d.value === '' || d.value === '06'))); // 기타
            }
            setFormValue(p => ({...p, userDcd: ''}));
        }
    },[formValue.blnsCoCd]);

   

    return (
        <>
            <Form
                ref={formRef}
                checkTrigger="change"
                onChange={setFormValue}
                onCheck={setFormError}
                formValue={formValue}
                model={model}>
            
                <Modal  dialogAs={DraggableModal}
                  show={show} onHide={onHide} backdrop="static" keyboard={false} centered size="lg" className="modal-custom">
                    <Modal.Header closeButton  className="handle">
                        <Modal.Title>사용자 등록</Modal.Title>
                    </Modal.Header>
                        <Modal.Body>
                            <Table className="tbl-hor" bordered>
                                <colgroup>
                                    <col style={{width:'15%'}}></col>
                                    <col style={{width:'35%'}}></col>
                                    <col style={{width:'15%'}}></col>
                                    <col style={{width:'35%'}}></col>
                                </colgroup>
                                <tbody>
                                    <tr>
                                        <th className="essen">아이디</th>
                                        <td>
                                            <Row className="select-wrap">
                                                <Col sm={9}>
                                                    <Form.Control name="userEeno" size="sm" type="text" placeholder="아이디를 입력해주세요" />
                                                </Col>
                                                <Col sm={3}>
                                                    <Button variant="secondary" size="sm" style={{width:'100%', height:'26px'}} onClick={onClickCheckId}>중복확인</Button>
                                                </Col>
                                            </Row>
                                        </td>
                                        <th className="essen">이름</th>
                                        <td>
                                            <Form.Control name="userNm" size="sm" type="text" placeholder="이름을 입력해주세요" />
                                        </td>
                                    </tr>
                                    <tr>
                                        <th className="essen">이메일</th>
                                        <td colSpan="3">
                                            <Form.Control name="userEmlAdr" size="sm" type="text" placeholder="이메일을 입력해주세요" />
                                        </td>
                                    </tr>
                                    <tr>
                                        <th className="essen">회사구분</th>
                                        <td>
                                            <Form.Control name="blnsCoCd" size="sm" 
                                               
                                                placeholder={'선택'}
                                                defaultValue={''}
                                                accepter={SelectPicker} 
                                                searchable={false}
                                                cleanable={false}
                                                data={coCombo.isFetched && coCombo.data}
                                            ></Form.Control>
                                        </td>
                                        <th className="essen">부서명</th>
                                        <td>
                                            <Form.Control name="userDcd" size="sm"
                                                placeholder={'선택'}
                                                defaultValue={''}
                                                accepter={SelectPicker} 
                                                searchable={false}
                                                cleanable={false}
                                                data={depts}
                                            ></Form.Control>
                                        </td>
                                    </tr>
                                    <tr>
                                        <th className="essen">사용자그룹</th>
                                        <td>
                                           <Form.Control name="grpCd" size="sm" 
                                                placeholder={'선택'}
                                                defaultValue={''}
                                                accepter={SelectPicker} 
                                                searchable={false}
                                                cleanable={false}
                                                // data={grpCombo.isSuccess && ( [])}
                                                data={grpList}
                                            ></Form.Control>
                                        </td>
                                        <th className="essen">사용여부</th>
                                        <td>
                                             <Form.Control name="useYn" size="sm" 
                                                placeholder={'선택'}
                                                defaultValue={''}
                                                accepter={SelectPicker} 
                                                searchable={false}
                                                cleanable={false}
                                                data={[
                                                    {label: '사용', value: 'Y'},
                                                    {label: '미사용', value: 'N'},
                                                ]}
                                            ></Form.Control>
                                        </td>
                                    </tr> 
                                    <tr>
                                        <th>
                                            <Form.ControlLabel>권한차종</Form.ControlLabel>
                                        </th>
                                        <td colSpan="3">
                                            <div className="ag-theme-alpine" style={{height:300}}>
                                                <AgGridReact
                                                    ref={gridRef}
                                                    rowData={userVehls && userVehls.data}
                                                    columnDefs={columnDefs}
                                                    defaultColDef={defaultColDef}
                                                    rowSelection={'multiple'}
                                                    suppressRowClickSelection= {true} 
                                                    onFirstDataRendered={onFirstDataRendered}
                                                    suppressSizeToFit={true}    
                                                    onGridSizeChanged={onFirstDataRendered}   
                                                    
                                                    frameworkComponents={{
                                                        escapeCharChangeForGrid
                                                    }}

                                                    >
                                                </AgGridReact>
                                            </div>
                                        </td>
                                    </tr>
                                </tbody>
                            </Table>
                        </Modal.Body>

                        <Modal.Footer>
                            <Button variant="light" size="md" onClick={onHide}>취소</Button>
                            <Button variant="primary" size="md" onClick={handleSubmit} >저장</Button>
                        </Modal.Footer>
                </Modal>
            </Form>

           
        </>
    );

};
export default MemberAdd;