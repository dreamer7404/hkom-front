import React, { useState, useMemo } from 'react';
import {Button, Modal} from 'react-bootstrap';
import { AgGridReact } from 'ag-grid-react';
import { CONSTANTS } from '../../../../utils/constants';

const SewonIvmPrinting = ({show, onHide}) => {
    
    const defaultColDef = useMemo(() => {
    return {
        sortable: true,
        minWidth:100,
        resizable:true,
    };
    }, []);

    const onFirstDataRendered = (params) => {
        params.api.sizeColumnsToFit();
    };

    // 셀 클릭
    const onCellClicked = e => {
        // console.log(e);
        // alert(e.column.colId + ',' + e.value)

        if(e.column.colId === 'printNum'){
            alert('발간현황 화면으로 이동')
        }

    };
   

    const [rowData] = useState([
        {printType:'신제작', printNum:'ABCD-20A', printStart:'2023-01-18', printEnd:'2023-01-31', printTot:'200'},
        {printType:'신제작', printNum:'ABCD-20A', printStart:'2023-01-18', printEnd:'2023-01-31', printTot:'200'},
    ]);

    const columnDefs = [

        {
        headerName: '발행구분',
        field: 'printType',
        },
        {
        headerName: '발간번호',
        field: 'printNum',
        cellStyle: () => ({textDecoration: 'underline', cursor: 'pointer', color:'#2589f5'})
        },
        {
        headerName: '발주일',
        field: 'printStart',
        },
        {
        headerName: '납품일',
        field: 'printEnd',
        },
        {
        headerName: '인쇄부수',
        field: 'printTot',
        
        }, 
    ]
    return (
        <>
            <Modal show={show} onHide={onHide} backdrop="static" keyboard={false} centered size="lg" className="modal-custom">
                <Modal.Header closeButton>
                    <Modal.Title>세원재고(인쇄중)</Modal.Title>
                </Modal.Header>
                <Modal.Body>
                    <div className="grid-btn-wrap">
                        <div className="left-align">
                            <div className="sub-title">
                                <ul>
                                    <li>차종 <span>(AA-19)AA-CAR</span></li>
                                    <li>언어 <span>EC(영어,불어/캐나다)</span></li>
                                </ul>
                            </div>
                        </div>
                        <div className="right-align">
                            <Button variant="outline-success" size="sm"><span className="excel-down"></span>{CONSTANTS.excelDownload}</Button>{' '}
                            <Button variant="outline-dark" size="sm"><span className="print"></span>{CONSTANTS.print}</Button>{' '}
                        </div>
                    </div>
                    <div className="ag-theme-alpine" style={{height:300}}>
                        <AgGridReact
                            rowData={rowData}
                            columnDefs={columnDefs}
                            defaultColDef={defaultColDef}
                            onFirstDataRendered={onFirstDataRendered}
                            suppressSizeToFit={true}    
                            onGridSizeChanged={onFirstDataRendered}   

                            onCellClicked={onCellClicked}
                            >
                        </AgGridReact>
                    </div>
                </Modal.Body>
                <Modal.Footer>
                    <Button variant="light" size="md" onClick={onHide}>취소</Button>
                </Modal.Footer>
            </Modal>
        </>
    )
};
export default SewonIvmPrinting;