import React, {useEffect, useMemo, useRef, useState} from 'react';
import { AgGridReact } from 'ag-grid-react';
import { CONSTANTS } from '../../../../utils/constants';
import { formatNumber } from '../../../../utils/commUtils';

const GridCarStock = ({mode, gridHeight, filterValue, queryResult, activePage, qltyVehlCd}) => {

  // 수량 천단위 콤마 찍기
  const currencyFormatter = (params) => {
    return formatNumber(params.value);
  };  

    const gridRef = useRef();

    const columnDefs = [
        {
          headerName: '언어',
          children: [
            { headerName:'지역', field: 'regnNm',
                colSpan: (params) => {
                const region = params.data.regnNm;
                if (region === 'TOTAL') {
                  // have all Russia age columns width 2
                  return 3;
                }else {
                  // all other rows should be just normal
                  return 1;
                }
              },
              sortable: true,
            },
            { headerName:'언어코드', field: 'langCd',sortable: true },
            { headerName:'언어명', field: 'langCdNm', sortable: true, },
          ],
        },
        {
            headerName: '세원 재고',
            children: [
              { headerName:'인쇄', field: 'sewhaWhsnQty' ,valueFormatter: currencyFormatter},
              { headerName:'배송', field: 'sewhaWhotQty' ,valueFormatter: currencyFormatter },
              { headerName:'보유재고', field: 'sewhaIvQty' ,valueFormatter: currencyFormatter },
            ],
        },
        {
            headerName: 'PDI 재고',
            children: [
              { headerName:'입고', field: 'pdiWhsnQty' ,valueFormatter: currencyFormatter},
              { headerName:'출고', field: 'pdiNormalWhot' ,valueFormatter: currencyFormatter },
              { headerName:'별도출고', field: 'pdiExtraWhot' ,valueFormatter: currencyFormatter },
              { headerName:'폐기', field: 'pdiDisuseWhot' ,valueFormatter: currencyFormatter },
              { headerName:'재고보정', field: 'pdiReviceWhot' ,valueFormatter: currencyFormatter },
              { headerName:'보유재고', field: 'pdiIvQty' ,valueFormatter: currencyFormatter },
            ],
        },
        {
            headerName: '총 재고',
            field: 'ivQty',
            spanHeaderHeight: true,
            valueFormatter: currencyFormatter
        },
        {
            headerName: '세원재고\n상세내역',
            field: 'sewhaIvText',
            spanHeaderHeight: true,
        },
        {
            headerName: 'PDI재고\n상세내역',
            field: 'pdiIvText',
            spanHeaderHeight: true,
        },
    ]

  const columnDefs2 = [
        {
            headerName: '날짜',
            field: 'clsYmd',
            spanHeaderHeight: true,
          },
        {
            headerName: '세원 재고',
            children: [
              { headerName:'인쇄', field: 'sewhaWhsnQty', valueFormatter: currencyFormatter},
              { headerName:'일반배송', field: 'sewhaNormalWhot', valueFormatter: currencyFormatter },
              { headerName:'별도배송', field: 'sewhaExtraWhot', valueFormatter: currencyFormatter },
              { headerName:'보유재고', field: 'sewhaIvQty', valueFormatter: currencyFormatter },
            ],
        },
        {
            headerName: 'PDI 재고',
            children: [
              { headerName:'입고', field: 'pdiWhsnQty', valueFormatter: currencyFormatter},
              { headerName:'상태', field: 'expdWhsnStNm'},
              { headerName:'과부족', field: 'pdiDeei1Qty', valueFormatter: currencyFormatter },
              { headerName:'출고', field: 'pdiNormalWhot', valueFormatter: currencyFormatter },
              { headerName:'별도출고', field: 'pdiExtraWhot', valueFormatter: currencyFormatter },
              { headerName:'폐기', field: 'pdiDisuseWhot', valueFormatter: currencyFormatter },
              { headerName:'재고보정', field: 'pdiReviceWhot', valueFormatter: currencyFormatter },
              { headerName:'보유재고', field: 'pdiIvQty', valueFormatter: currencyFormatter },
            ],
        },
        {
            headerName: '총 재고',
            field: 'ivQty',
            spanHeaderHeight: true,
            valueFormatter: currencyFormatter
        },
        {
            headerName: '세원재고\n상세내역',
            field: 'sewhaIvText',
            spanHeaderHeight: true,
        },
        {
            headerName: 'PDI재고\n상세내역',
            field: 'pdiIvText',
            spanHeaderHeight: true,
        },
    ]

  const [rowData2] = useState([
        {selectDate:'2023-03-01', sewon1:'11', sewon2:'12', sewon3:'13', sewon4:'14', pdi1:'15', pdi2:'12', pdi3:'12', pdi4:'12', pdi5:'12', pdi6:'12', pdi7:'12', totalIvm:'12', sewonIvmDt:'12', pdiIvmDt:'12' },
        {selectDate:'2023-03-01', sewon1:'11', sewon2:'12', sewon3:'13', sewon4:'14', pdi1:'15', pdi2:'12', pdi3:'12', pdi4:'12', pdi5:'12', pdi6:'12', pdi7:'12', totalIvm:'12', sewonIvmDt:'12', pdiIvmDt:'12' },
    ]);

  const defaultColDef = useMemo(() => {
        return {
            initialWidth: 90,
            lockPosition:true,
            tooltip:true,
            };
    }, []);

  const onFirstDataRendered = (params) => {
      params.api.sizeColumnsToFit();
  };
  const [total, setTotal] = useState({});
  const [queryResultRealDatas, setQueryResultRealDatas] = useState([]);

  useEffect(()=>{
    if(queryResult.isSuccess){
      setTotal(
        queryResult.isSuccess && queryResult.data.filter(item => {
          return item.langCd === 'TOTAL'
        })[0]
      )
      setQueryResultRealDatas (
        queryResult.isSuccess && queryResult.data.filter(item => {
          return item.langCd !== 'TOTAL'
        })
      )

    }
    // if(queryResult.status === 'loading' && gridRef && gridRef.current && gridRef.current.api){
    //     gridRef.current.api.showLoadingOverlay();
    // }
  },[queryResult.data]);

  useEffect(()=> {
    if(gridRef && gridRef.current && gridRef.current.api){
      gridRef.current.api.setQuickFilter(filterValue);
    }
  },[filterValue]);

  useEffect(()=> {
    if(gridRef && gridRef.current && gridRef.current.api){
      gridRef.current.api.paginationGoToPage(activePage-1);
    }
  },[activePage]);


  const pinnedBottomRowData = [total];


  return(
    <>
    
    {mode === 'lang' &&
      <div className="ag-theme-alpine" style={{height: gridHeight, transition:'all ease .3s'}}>
        <AgGridReact
            ref={gridRef} 
            //rowData={queryResult && queryResult.data} 
            rowData={queryResult && queryResultRealDatas} 
            
            columnDefs={columnDefs}
            defaultColDef={defaultColDef}

            //  filter
            cacheQuickFilter={true}

            // overlay
            overlayLoadingTemplate={CONSTANTS.gridLoading}
            // overlayNoRowsTemplate={CONSTANTS.gridNoRows}
            overlayNoRowsTemplate={qltyVehlCd==='ALL'?'<span style="padding: 10px; border: 1px solid #ccc;">차종을 선택하세요.</span>':CONSTANTS.gridNoRows}

            onFirstDataRendered={onFirstDataRendered}
            suppressSizeToFit={true}    
            onGridSizeChanged={onFirstDataRendered}    

            pinnedBottomRowData={pinnedBottomRowData}
            >
        </AgGridReact>
    </div>
  }

  {mode === 'day' &&
      <div className="ag-theme-alpine" style={{height: gridHeight, transition:'all ease .3s'}}>
        <AgGridReact
            ref={gridRef} 
            //rowData={queryResult && queryResult.data} 
            rowData={queryResult && queryResultRealDatas} 
            columnDefs={columnDefs2}
            defaultColDef={defaultColDef}

            //  filter
            cacheQuickFilter={true}

            // overlay
            overlayLoadingTemplate={CONSTANTS.gridLoading}
            // overlayNoRowsTemplate={CONSTANTS.gridNoRows}
            overlayNoRowsTemplate={qltyVehlCd==='ALL'?'<span style="padding: 10px; border: 1px solid #ccc;">차종을 선택하세요.</span>':CONSTANTS.gridNoRows}

            onFirstDataRendered={onFirstDataRendered}
            suppressSizeToFit={true}    
            onGridSizeChanged={onFirstDataRendered}    

            >
        </AgGridReact>
    </div>
  }

  </>
  )


};
export default GridCarStock;