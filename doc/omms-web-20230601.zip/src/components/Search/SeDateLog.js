import React from 'react';
import {Row, Col} from 'react-bootstrap';
import {Form, DatePicker, InputGroup} from 'rsuite';
import { utcToLocalDate } from '../../utils/commUtils'; //'../../../utils/commUtils';

//--------------  서버데이터용 필수 -------------------------------
import useStore from '../../utils/store';
//--------------// 서버데이터용 필수 -------------------------------


const SeDateLog = () => {

    const {keyword, setSDateLog, setEDateLog } = useStore(); 

    const onChangeDateStart = val => {
        setSDateLog(utcToLocalDate(val));
    }
    const onChangeDateEnd = val => {
        setEDateLog(utcToLocalDate(val));
    }

    return (
        <>
            <Form.ControlLabel column="sm">기간</Form.ControlLabel>
            <Row className="select-wrap">
                <Col>
                    <InputGroup>
                        <DatePicker oneTap block size="sm" style={{width: '100%'}} 
                            value={keyword.sDateLog ? new Date(keyword.sDateLog)  : new Date()}
                            ranges={[
                                {
                                label: '오늘',
                                value: new Date()
                                }
                            ]}
                            format="yyyy-MM-dd"
                            onChange={onChangeDateStart} 
                            cleanable={false}
                        />
                        <InputGroup.Addon>~</InputGroup.Addon>
                        <DatePicker oneTap block size="sm" style={{width: '100%'}} 
                            value={keyword.eDateLog ? new Date(keyword.eDateLog)  : new Date()}
                            ranges={[
                                {
                                label: '오늘',
                                value: new Date()
                                }
                            ]}
                            format="yyyy-MM-dd"
                            onChange={onChangeDateEnd} 
                            cleanable={false}
                        />
                    </InputGroup>
                </Col>
            </Row>
        </>
    );

};
export default SeDateLog;