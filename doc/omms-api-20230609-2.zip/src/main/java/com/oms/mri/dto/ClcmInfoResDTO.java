package com.oms.mri.dto;

import java.util.HashMap;
import java.util.List;

import org.apache.ibatis.type.Alias;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * <pre>
 * ClcmInfoResDTO
 * </pre>
 *
 * @author 김정웅
 * @since 2023. 5. 26.
 * @see
 */
@Alias("clcmInfoResDTO")
@Data
@AllArgsConstructor
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown =true)
public class ClcmInfoResDTO extends PrintOrderComDTO{

    private String dlExpdAltrNo;    //취급설명서변경번호
    private String altrYmd;         //변경일
    private String rcpmShapCd;      //수신형태 코드
    private String rcpmShapNm;      //수신형태 명
    private String dsppNm;          //발신처
    private String pprrEeno;        //등록자 계정
    private String pprrEenoNm;      //등록자 이름
    private String crgrNm;          //담당자 이름
    private String n1afp2Adr;       //1차첨부파일 주소
    private String n1afp2Adr1;      //2차첨부파일 주소
    private String altrTitl;        //제목
    private String altrSbc;         //내용
    private String attcYn;          //첨부파일 여부
    private String etYn;            //메일전송 여부

    private List<HashMap<String, String>> langCdByVehlList;  //선택한 차종 및 언어 + 적용 발간번호
    private List<HashMap<String, String>> senderList;        //선택한 송부인 목록

//    private List<HashMap<String, String>> headerLangCds;   //그리드 헤더용 언어코드

}
