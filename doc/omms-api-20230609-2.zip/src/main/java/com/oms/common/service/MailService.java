package com.oms.common.service;

import java.util.List;

import com.oms.common.dto.MailDTO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @author 안경수
 * @since 2023. 5. 16.
 * @see
 */

public interface MailService {
    int send(MailDTO mailDTO);
    int insertLogEml(MailDTO mailDTO);
}
