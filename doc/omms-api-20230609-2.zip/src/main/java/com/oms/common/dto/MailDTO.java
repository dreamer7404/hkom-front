package com.oms.common.dto;

import java.sql.Timestamp;
import java.util.List;

import org.apache.ibatis.type.Alias;

import com.oms.common.model.Mail;

import lombok.Data;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @author 안경수
 * @since 2023. 5. 17.
 * @see
 */
@Data
@Alias("mailDTO")
public class MailDTO {
    private Integer EmlCd; // tb_log_eml의 pk

    private String emlScdCd; // "01": 발송 ", "02": "실패"
    private List<Mail> rcvList; // 수신자 메일<rcvEeno, rcvAdr> 리스트

    private String sndrId;  // 발신자 사번
    private String emlTitl; // 제목
    private String emlSbc;  // 내용
    private Timestamp fsSndDate; //발송일

    private String AdreEml;
}
