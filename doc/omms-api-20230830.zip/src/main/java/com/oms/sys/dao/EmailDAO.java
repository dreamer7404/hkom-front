package com.oms.sys.dao;

import java.util.List;

import com.oms.sys.dto.BatchLogResDTO;
import com.oms.sys.dto.BatchReqDTO;
import com.oms.sys.dto.BatchResDTO;
import com.oms.sys.dto.EmailReqDTO;
import com.oms.sys.dto.EmailLogResDTO;
import com.oms.sys.dto.EmailRcvrResDTO;


/**
 * <pre>
 * Statements
 * </pre>
 * @ClassName : EmailDAO.java
 * @Description :
 * @author 김경훈
 * @since 2023. 6. 15.
 * @see
 */
public interface EmailDAO {

        List<EmailLogResDTO> selectEmailLogs(EmailReqDTO dto);

        List<EmailRcvrResDTO> selectEmlRcvrMgmts(EmailReqDTO dto);

        /**
         * Statements
         *
         * @param dto
         * @return
         */
        int insEmlRcvrMgmt(EmailReqDTO dto);

        /**
         * Statements
         *
         * @param dto
         * @return
         */
        String selectEmlDupChk(EmailReqDTO dto);

        /**
         * Statements
         *
         * @param dto
         * @return
         */
        int delEmlRcvrMgmt(EmailReqDTO dto);

        /**
         * Statements
         *
         * @param dto
         * @return
         */
        List<EmailRcvrResDTO> emlRcvrUsrList(EmailReqDTO dto);

        /**
         * Statements
         *
         * @param dto
         * @return
         */
        EmailLogResDTO selectEmailLog(EmailReqDTO dto);

}
