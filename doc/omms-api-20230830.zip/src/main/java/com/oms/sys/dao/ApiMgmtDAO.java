package com.oms.sys.dao;

import java.util.List;

import com.oms.sys.dto.ApiAuthByGrpResDTO;
import com.oms.sys.dto.ApiAuthReqDTO;
import com.oms.sys.dto.ApiAuthUrlReqDTO;
import com.oms.sys.dto.ApiMgmtReqDTO;
import com.oms.sys.dto.ApiMgmtResDTO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @author 안경수
 * @since 2023. 3. 13.
 * @see
 */

public interface ApiMgmtDAO {

    List<ApiMgmtResDTO> selectApiMgmtList(ApiMgmtReqDTO dto);
    int insertApiMgmt(ApiMgmtReqDTO apiMgmtReqDTO);
    int updateApiMgmt(ApiMgmtReqDTO apiMgmtReqDTO);
    int deleteApiMgmt(List<ApiAuthUrlReqDTO> list);
    ApiMgmtResDTO selectApiMgmt(ApiMgmtReqDTO apiMgmtReqDTO);
    int selectApiMgmtCheck(ApiMgmtReqDTO apiMgmtReqDTO);

    int deleteApiAuth(String grpCd);
    int insertApiAuth(ApiAuthReqDTO apiAuthReqDTO);
    List<ApiMgmtResDTO> selectApiMgmtListByApiAuth(String grpCd);
    /**
     * Statements
     *
     * @param apiMgmtReqDTO
     * @return
     */
    int deleteExcelUpload(ApiMgmtReqDTO apiMgmtReqDTO);
    String selectApiUrlMenuId(ApiMgmtReqDTO apiMgmtReqDTO);
    int selectApiUrlCheck(ApiMgmtReqDTO apiMgmtReqDTO);
    List<ApiAuthByGrpResDTO> selectApiMgmtListByAuthGrp(String grpCd);
}
