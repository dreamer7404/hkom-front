package com.oms.sys.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.oms.cmm.global.Consts;
import com.oms.cmm.utils.Utils;
import com.oms.sys.dto.ApiAuthByGrpResDTO;
import com.oms.sys.dto.ApiAuthReqDTO;
import com.oms.sys.dto.ApiMgmtReqDTO;
import com.oms.sys.dto.ApiMgmtResDTO;
import com.oms.sys.service.ApiMgmtService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @author 안경수
 * @since 2023. 5. 23.
 * @see
 */
@Tag(name = "ApiMgmtController", description = "")
@RequiredArgsConstructor
@RestController
@RequestMapping("/api")
public class ApiMgmtController {

    /**
     * 클래스 Injection
     */
    private final ApiMgmtService apiMgmtService;
    private final HttpServletRequest request;

    /**
     * API관리 목록을 조회
     */
    @Operation(summary = "API관리 목록 조회 ")
    @GetMapping("/apiMgmts")
    public List<ApiMgmtResDTO> selectApiMgmtList(@ModelAttribute ApiMgmtReqDTO dto) throws Exception {
        return apiMgmtService.selectApiMgmtList(dto);
    }


    /**
     * API mgmt 수정, 추가
     */
    @Operation(summary = "API 수정, 추가 ")
    @PostMapping("/apiMgmt")
    public int apiMgmt(@RequestBody ApiMgmtReqDTO apiMgmtReqDTO) throws Exception {
        int result = 0;
        apiMgmtReqDTO.setUserEeno(Utils.getUserEeno(request));
        String method = Utils.getMethod(request);

        try {
            // 등록
            if(method.equals(Consts.INSERT)) {
                int cnt = apiMgmtService.selectApiMgmtCheck(apiMgmtReqDTO);
                if(cnt == 1) {
                    return -2;
                }
                result = apiMgmtService.insertApiMgmt(apiMgmtReqDTO);
            }else if(method.equals(Consts.UPDATE)) {
                //업데이트에서는 중복체크 뺐음.. by woong
//                int cnt = apiMgmtService.selectApiMgmtCheck(apiMgmtReqDTO);
//                if(cnt == 1) {
//                    return -2;
//                }
                result = apiMgmtService.updateApiMgmt(apiMgmtReqDTO);
            }else  if(method.equals(Consts.DELETE)) {
                result = apiMgmtService.deleteApiMgmt(apiMgmtReqDTO.getApiUrls());
            }

        }catch(Exception e) {
            return -1;
        }
        return result;

    }


    /**
     * ApiMgmt by ApiAuth(그룹권한별 api) 조회
     */
    @Operation(summary = "API관리 목록 조회 ")
    @GetMapping("/apiMgmtsByApiAuth")
    public List<ApiMgmtResDTO> selectApiMgmtListByApiAuth(@RequestParam(value="grpCd") String grpCd) throws Exception {
        return apiMgmtService.selectApiMgmtListByApiAuth(grpCd);
    }

    /**
     * API auth 수정, 추가
     */
    @Operation(summary = "API 수정, 추가 ")
    @PostMapping("/apiAuth")
    public int apiAuth(@RequestBody ApiAuthReqDTO apiAuthReqDTO) throws Exception {
        int result = 0;
        apiAuthReqDTO.setUserEeno(Utils.getUserEeno(request));
        String method = Utils.getMethod(request);

        try {
            // 수정
            if(method.equals(Consts.UPDATE)) {
                // 삭제
                result = apiMgmtService.deleteApiAuth(apiAuthReqDTO.getGrpCd());

                // 추가
                if(apiAuthReqDTO.getApiUrls().size() > 0) {
                    result = apiMgmtService.insertApiAuth(apiAuthReqDTO);
                }

                result = 1;
            }

        }catch(Exception e) {
            return -1;
        }
        return result;
    }




    @Operation(summary = "엑셀 저장")
    @PostMapping("/apiExcelUpload")
    public Integer apiExcelUpload(@RequestBody ApiMgmtReqDTO dto) throws Exception {

        int result =0;
        for(int i=0; i<dto.getExcelDataList().size(); i++) {
            result =  apiMgmtService.deleteExcelUpload(dto.getExcelDataList().get(i)); //중복제거용
            result =  apiMgmtService.insertApiMgmt(dto.getExcelDataList().get(i)); //insert
        }
        return result;

    }


}
