package com.oms.sys.dto;

import java.sql.Timestamp;

import org.apache.ibatis.type.Alias;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;



/**
 * <pre>
 * Statements
 * </pre>
 * @ClassName : LogLgiResDTO.java
 * @Description :
 * @author 김경훈
 * @since 2023. 6. 16.
 * @see
 */
@Data
@Alias("logLgiReqDTO")
public class LogLgiReqDTO {

    private String userId;
    private String sucsYn;
    private String userIpAdr;
    private String idExistYn;
    private String sessId;
    private String lgoType;
    /**
     * Statements
     *
     * @param userId
     * @param sucsYn
     * @param userIpAdr
     * @param idExistYn
     * @param sessId
     */
    public LogLgiReqDTO(String userId, String sucsYn, String userIpAdr, String idExistYn, String sessId) {
        super();
        this.userId = userId;
        this.sucsYn = sucsYn;
        this.userIpAdr = userIpAdr;
        this.idExistYn = idExistYn;
        this.sessId = sessId;
    }
    /**
     * Statements
     *
     * @param sessId
     * @param lgoType
     */
    public LogLgiReqDTO(String sessId, String lgoType) {
        super();
        this.sessId = sessId;
        this.lgoType = lgoType;
    }




}
