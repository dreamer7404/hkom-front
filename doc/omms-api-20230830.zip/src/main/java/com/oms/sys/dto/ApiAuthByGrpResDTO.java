package com.oms.sys.dto;

import org.apache.ibatis.type.Alias;

import lombok.Data;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @author 안경수
 * @since 2023. 7. 12.
 * @see
 */
@Alias("apiAuthByGrpResDTO")
@Data
public class ApiAuthByGrpResDTO {
    private String apiUrl;
    private String method;
}
