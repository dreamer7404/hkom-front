package com.oms.sys.dao;

import java.util.List;

import com.oms.sys.dto.LogAuthChgReqDTO;
import com.oms.sys.dto.LogUseReqDTO;
import com.oms.sys.dto.LogUseResDTO;
import com.oms.sys.dto.SchedLogDTO;
import com.oms.sys.model.LogUse;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @author 안경수
 * @since 2023. 3. 13.
 * @see
 */

public interface LogDAO {
    int insertSchedLog(SchedLogDTO schedLogDTO);
    int selectYongsanIvInfoIfCnt();
    int insertLogUse(LogUse logUse);
    List<LogUseResDTO> selectLogUseList(LogUseReqDTO logUseReqDTO);
    Integer selectLogUseListTot(LogUseReqDTO logUseReqDTO);
    /**
     * Statements
     *
     * @param dto
     * @return
     */
    Integer saveLogAuthChg(LogAuthChgReqDTO dto);
}
