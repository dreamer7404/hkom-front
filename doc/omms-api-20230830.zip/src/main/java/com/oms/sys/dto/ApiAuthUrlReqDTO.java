package com.oms.sys.dto;

import java.util.List;

import org.apache.ibatis.type.Alias;

import lombok.AllArgsConstructor;
import lombok.Data;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @author 안경수
 * @since 2023. 5. 23.
 * @see
 */

@Alias("apiAuthUrlReqDTO")
@Data
public class ApiAuthUrlReqDTO {
    private String apiUrl;
    private String method;

}
