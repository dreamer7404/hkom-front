package com.oms.sys.dto;

import java.util.List;

import org.apache.ibatis.type.Alias;

import com.oms.common.dto.CommReqDTO;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;



/**
 * <pre>
 * Statements
 * </pre>
 * @ClassName : EmailReqDTO.java
 * @Description :
 * @author 김경훈
 * @since 2023. 6. 15.
 * @see
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Alias("emailReqDTO")

public class EmailReqDTO   extends CommReqDTO{


    private String rcvrNm;
    private String emlScdCd;
    private String userEeno;
    private String pprrEeno;
    private String emlCd;
    private String sndrNm;
    private String sDate;
    private String eDate;





    List<EmailReqDTO>rcvrList;

}
