package com.oms.sys.service;

import java.util.List;

import com.oms.sys.dto.FileUploadLogReqDTO;
import com.oms.sys.dto.FileUploadLogResDTO;
import com.oms.sys.dto.LogComReqDTO;

/**
 * <pre>
 * Statements
 * </pre>
 * @ClassName : FileUploadLogService.java
 * @Description :
 * @author 김경훈
 * @since 2023. 6. 19.
 * @see
 */
public interface FileUploadLogService {

    List<FileUploadLogResDTO> fileUploadHistorys(LogComReqDTO dto);
    Integer fileUploadHistoryTots(LogComReqDTO dto);
    int insertFileUploadHistory(FileUploadLogReqDTO fileUploadLogReqDTO);

}
