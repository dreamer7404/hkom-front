package com.oms.sys.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.oms.cmm.global.Consts;
import com.oms.cmm.utils.Utils;
import com.oms.print.dto.PrintStateReqDTO;
import com.oms.sys.dto.BatchLogResDTO;
import com.oms.sys.dto.BatchReqDTO;
import com.oms.sys.dto.BatchResDTO;
import com.oms.sys.dto.EmailReqDTO;
import com.oms.sys.dto.EmailLogResDTO;
import com.oms.sys.dto.EmailRcvrResDTO;
import com.oms.sys.service.BatchService;
import com.oms.sys.service.EmailService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;


/**
 * <pre>
 * Statements
 * </pre>
 * @ClassName : EmailController.java
 * @Description :
 * @author 김경훈
 * @since 2023. 6. 15.
 * @see
 */
@Tag(name = "EmailController", description = "")
@RequiredArgsConstructor
@RestController
@RequestMapping("/api")
public class EmailController {

    /**
     * 클래스 Injection
     */
    private final EmailService emailService;
    private final HttpServletRequest request;

    /**
     * Email 이력 목록을 조회
     */
    @Operation(summary = "Email 이력 목록을 조회 ")
    @GetMapping("/emailLogs")
    public List<EmailLogResDTO> emailHistorys(@ModelAttribute EmailReqDTO dto) throws Exception {
        return emailService.selectEmailLogs(dto);
    }

    @Operation(summary = "Email 이력 상세 조회 ")
    @GetMapping("/emailLog")
    public EmailLogResDTO emailHistory(@ModelAttribute EmailReqDTO dto) throws Exception {
        return emailService.selectEmailLog(dto);
    }




    /**
     * 수신자 목록을 조회
     */
    @Operation(summary = "수신자목록을 조회 ")
    @GetMapping("/emlRcvrMgmts")
    public List<EmailRcvrResDTO> emlRcvrMgmts(@ModelAttribute EmailReqDTO dto) throws Exception {
        return emailService.selectEmlRcvrMgmts(dto);
    }
    /**
     * 수신자 목록을 조회
     */
    @Operation(summary = "수신자 상세")
    @GetMapping("/emlRcvrMgmt")
    public List<EmailRcvrResDTO>emlRcvrMgmtDetail(@ModelAttribute EmailReqDTO dto) throws Exception {
        return emailService.emlRcvrUsrList(dto);
    }


    /**
     * 수신자 저장
     */
    @Operation(summary = "수신자 저장", description = "")
    @PostMapping(value = "/emlRcvrMgmt")
    public Integer emlRcvrMgmt(@RequestBody EmailReqDTO dto) throws Exception {

        String method = Utils.getMethod(request);
        dto.setPprrEeno(Utils.getUserEeno(request));
        int result = 0;
        if(method.equals(Consts.INSERT)) { // dto


            String dupChk = emailService.selectEmlDupChk(dto);

            if("Y".equals(dupChk)) {
                dto.getRcvrList().stream().forEach(item -> {
                    item.setEmlScdCd(dto.getEmlScdCd());
                    item.setPprrEeno(dto.getPprrEeno());
                });

                result = emailService.insEmlRcvrMgmt(dto);
            }
            else {
                result = -1;
            }

        } else if(method.equals(Consts.UPDATE)) {
            dto.getRcvrList().stream().forEach(item -> {
                item.setEmlScdCd(dto.getEmlScdCd());
                item.setPprrEeno(dto.getPprrEeno());
            });

            result = emailService.delEmlRcvrMgmt(dto);
            result = emailService.insEmlRcvrMgmt(dto);
      } else if (method.equals(Consts.DELETE)) {
          result = emailService.delEmlRcvrMgmt(dto);
      }

        return result;
    }

}
