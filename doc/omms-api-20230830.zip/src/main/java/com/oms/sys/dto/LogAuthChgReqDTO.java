package com.oms.sys.dto;

import org.apache.ibatis.type.Alias;

import com.oms.common.dto.CommReqDTO;

import lombok.Data;


/**
 * <pre>
 * Statements
 * </pre>
 * @ClassName : LogAuthChgReqDTO.java
 * @Description :
 * @author 김경훈
 * @since 2023. 7. 28.
 * @see
 */
@Data
@Alias("logAuthChgReqDTO")
public class LogAuthChgReqDTO extends CommReqDTO  {
   private String altrCd;               // 변경순번
   private String userId;               // 변경대상 ID
   private String chgrId;               // 변경자 ID
   private String chgrIp;               // 변경자 IP
   private String aftType;              // 변경유형(생성/변경/삭제)
   private String befrValue;            //변경이전값
   private String aftrValue;            //변경이후값
   private String befAuth;              //변경이전권한
   private String aftAuth;              //변경이후 권한
   private String altrDate;            //변경일시
}
