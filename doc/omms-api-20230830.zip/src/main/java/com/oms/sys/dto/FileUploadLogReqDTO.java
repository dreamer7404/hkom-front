package com.oms.sys.dto;

import java.util.List;

import org.apache.ibatis.type.Alias;

import com.oms.common.dto.CommReqDTO;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


/**
 * <pre>
 * Statements
 * </pre>
 * @ClassName : FileUploadLogResDTO.java
 * @Description :
 * @author 김경훈
 * @since 2023. 6. 19.
 * @see
 */
@Data
@NoArgsConstructor
@Alias("fileUploadLogReqDTO")

public class FileUploadLogReqDTO extends CommReqDTO{
    private String useType;
    private String userId;
    private String userIp;
    private String filGbn;
    private Long attcSn;
    private String pgmId;

    private List<Long> attcSnList; // 다운로드후 파일 pk 리스트 용

    /**
     * Statements
     *
     * @param useType
     * @param userId
     * @param userIp
     * @param filGbn
     * @param attcSn
     * @param pgmId
     */
    public FileUploadLogReqDTO(String useType, String userId, String userIp, String filGbn, Long attcSn, String pgmId) {
        super();
        this.useType = useType;
        this.userId = userId;
        this.userIp = userIp;
        this.filGbn = filGbn;
        this.attcSn = attcSn;
        this.pgmId = pgmId;
    }



}
