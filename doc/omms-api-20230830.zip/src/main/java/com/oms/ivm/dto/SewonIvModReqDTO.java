package com.oms.ivm.dto;

import org.apache.ibatis.type.Alias;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @author 김정웅
 * @since 2023. 3. 30.
 * @see
 */

@Alias("sewonIvModReqDTO")
@Data
@AllArgsConstructor
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown =true)
public class SewonIvModReqDTO extends ComIvmReqDTO{

    private int modQty;             //보정수량
    private String prtlImtrSbc;     //비고
    private String modCd;           //보정구분 ex)추가출고,별도지급 등..
    private String dtlSn;           //DTL_SN (TB_SEWHA_WHOT_INFO) int(12) 상세일련번호

    private int ivQty;              //보유재고
    private String oriModCd;        //수정전 보정구분 (조회시점 기준)
    private int oriModQty;          //수정전 보정수량 (조회시점 기준)
    private String oriFixedIvQty;   //수정전 보정확정 (조회시점 기준)

//    private String menuGubun;       //화면 메뉴 구분 (sewon || pdi)
    private String clScnCd;         //당일 데이터 여부(Y:당일데이터, N:일자가 다른데이터)



}
