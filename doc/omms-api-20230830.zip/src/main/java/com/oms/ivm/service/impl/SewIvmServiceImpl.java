package com.oms.ivm.service.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import able.cloud.core.service.HService;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.util.HtmlUtils;

import com.oms.cmm.utils.Utils;
import com.oms.common.dto.MailDTO;
import com.oms.common.model.Mail;
import com.oms.common.service.MailService;
import com.oms.ivm.dao.SewIvmDAO;
import com.oms.ivm.dto.ComIvmReqDTO;
import com.oms.ivm.dto.IvmRequestMonitorResDTO;
import com.oms.ivm.dto.IvmSewonPrintReqDTO;
import com.oms.ivm.dto.IvmSewonPrintResDTO;
import com.oms.ivm.dto.SewonIvModReqDTO;
import com.oms.ivm.dto.SewonIvModResDTO;
import com.oms.ivm.dto.SewonIvmReqDTO;
import com.oms.ivm.dto.SewonIvmResDTO;
import com.oms.ivm.dto.SewonWhotReqDTO;
import com.oms.ivm.dto.SewonWhotResDTO;
import com.oms.ivm.service.SewIvmService;

import lombok.RequiredArgsConstructor;

/**
 * <pre>
 * sewIvmService
 * </pre>
 *
 * @author 김정웅
 * @since 2023. 3. 7.
 * @see
 */
@RequiredArgsConstructor
@Service("sewIvmService")
public class SewIvmServiceImpl extends HService implements SewIvmService {

    private final SewIvmDAO sewIvmDAO;
    private final MailService mailService;

    @Override
    public List<SewonIvmResDTO> selectSewonIvmList(SewonIvmReqDTO sewonIvmReqDTO) throws Exception {
        String bDate = sewonIvmReqDTO.getBDate();
        HashMap<String, String> validMdlMdy4 = sewIvmDAO.selectValidMdlMdy4(bDate);

        sewonIvmReqDTO.setPFromMdlMdy(validMdlMdy4.get("P_FROM_MDL_MDY"));
        sewonIvmReqDTO.setPToMdlMdy(validMdlMdy4.get("P_TO_MDL_MDY"));

        List<SewonIvmResDTO> result = new ArrayList<SewonIvmResDTO>();

        //배송여부:전체
//        if("ALL".equals(sewonIvmReqDTO.getDlvtState())) {
            result = sewIvmDAO.selectSewonIvmListAll(sewonIvmReqDTO);
//        }
        //배송여부:배송중
//        else if ("01".equals(sewonIvmReqDTO.getDlvtState())) {
//            result = sewIvmDAO.selectSewonIvmList01(sewonIvmReqDTO);
//        }
        //배송여부:배송완료
//        else if ("02".equals(sewonIvmReqDTO.getDlvtState())) {
//            result = sewIvmDAO.selectSewonIvmList02(sewonIvmReqDTO);
//        }

        return result;
    }

    @Override
    public List<SewonWhotResDTO> selectSewonWhotList(ComIvmReqDTO reqDto) throws Exception {

        List<SewonWhotResDTO> result = new ArrayList<SewonWhotResDTO>();
        result = sewIvmDAO.selectSewonWhotList(reqDto);
        return result;
    }

    @Transactional
    @Override
    public Integer updateSewonWhotList(List<SewonWhotReqDTO> reqDto, String userEeno) throws Exception {
        Integer totalResult = 0;
        for(SewonWhotReqDTO param : reqDto) {
            param.setUserEeno(userEeno);

//            HashMap<String, String> prevWhotYmd = sewIvmDAO.getPrevWhotYmd(reqDto);
//            String vPrevWhotYmd = (String) prevWhotYmd.get("vPrevWhotYmd");
//            if(null!=vPrevWhotYmd && !vPrevWhotYmd.replace("-", "").equals(sdate.replaceAll("-",""))){
//                param.setDtlSn(null);
//            }

            int result = sewIvmDAO.updateSewonWhotList(param);
            if(result == 0) {
                result = sewIvmDAO.insertSewonWhotList(param);
            }
            totalResult += result;
        }
        return totalResult;
    }

    @Override
    public Integer deleteSewonWhotList(List<SewonWhotReqDTO> reqDto, String userEeno) throws Exception {
        Integer totalResults = 0;
        for(SewonWhotReqDTO param : reqDto) {
            totalResults += sewIvmDAO.deleteSewonWhotList(param);
        }
        return totalResults;
    }

    @Override
    public List<SewonIvModResDTO> selectIvModList(ComIvmReqDTO reqDto) throws Exception {
        List<SewonIvModResDTO> result = new ArrayList<SewonIvModResDTO>();
        result = sewIvmDAO.selectIvModList(reqDto);
        return result;
    }

    @Override
    @Transactional
    public Integer insertIvModList(List<SewonIvModReqDTO> reqDto, String userEeno, String dlExpdCoCd) throws Exception {
        Integer result = 1;
        try {
            for(SewonIvModReqDTO param : reqDto) {
                param.setUserEeno(userEeno);
                param.setDlExpdCoCd(dlExpdCoCd);

                //이전 보정을 원복할 경우를 위해 변수에 현재 사용자가 입력한 보정수량을 할당해둔다. (as-is 기준..)
                int modQty = param.getModQty();
                String modCd = param.getModCd();

                //이전 보정을 수정 할 경우 원복 Start============================
                if(!"0".equals(param.getDtlSn())){

                    //--재고 보정 추가 삭제 구분 (삭제 이므로 - 를 + , + 를 -로
                    String oriModCd = param.getOriModCd();
                    if("05".equals(oriModCd) || "06".equals(oriModCd) || "11".equals(oriModCd)){
                        param.setOriModQty(Math.abs(param.getOriModQty()))  ;
                    }else{
                        param.setOriModQty(Math.abs(param.getOriModQty()) * (-1));
                    }

                    param.setModQty(param.getOriModQty());
                    param.setModCd(param.getOriModCd());

                    //출고 삭제 (del_yn : Y)
                    sewIvmDAO.deleteIvModInfo(param);
                    //수정 재고
                    sewIvmDAO.updateIvModInfo(param);
                    //수정 재고 상세
                    sewIvmDAO.updateIvDtlModInfo(param);
                }
                //이전 보정을 수정 할 경우 원복 End============================

                param.setModCd(modCd);

                //--재고 보정 추가 삭제 구분
                if("05".equals(modCd) || "06".equals(modCd) || "11".equals(modCd)){
                    param.setModQty(Math.abs(modQty) * (-1));
                }else{
                    param.setModQty(Math.abs(modQty));
                }

                // 수정 Start : 출고 테이블 이므로 + 는 - 로 표기.......... - 는 + 로 표기.....
                    // 1. TB_SEWHA_IV_INFO, 2. TB_SEWHA_IV_INFO_DTL, 3.TB_SEWHA_IV_INFO_DTL
                    // 재고 - [07, 추가출고], [02, 별도지급], [03, 폐기], [08, 반출], 12, 재고실사(-)]
                    // 재고 + [05, 추가입고], [06, 전시차], [11, 재고실사(+)]

                // 출고 Table 입력
                sewIvmDAO.insertIvModList(param);
                // 수정 재고
                sewIvmDAO.updateIvModInfo(param);
                // 수정 재고 상세
                sewIvmDAO.updateIvDtlModInfo(param);
                // 수정 End
            }
            return result;
        } catch(RuntimeException e) {
            e.printStackTrace();
            return 0;
        } catch(Exception e) {
            e.printStackTrace();
            return 0;
        }
    }

    @Override
    public Integer deleteIvModList(List<SewonIvModReqDTO> reqDto, String userEeno, String dlExpdCoCd) throws Exception {
        Integer result = 1;
        try {
            for(SewonIvModReqDTO param : reqDto) {
                param.setUserEeno(userEeno);
                param.setDlExpdCoCd(dlExpdCoCd);

                String modCd = param.getModCd();

                if("05".equals(modCd) || "06".equals(modCd) || "11".equals(modCd)){
                    param.setModQty(Math.abs(param.getOriModQty()));
                }else{
                    param.setModQty(Math.abs(param.getOriModQty()) * (-1));
                }

                // 수정 Start : 출고 테이블 이므로 + 는 - 로 표기.......... - 는 + 로 표기.....
                // 1. TB_SEWHA_IV_INFO, 2. TB_SEWHA_IV_INFO_DTL, 3.TB_SEWHA_IV_INFO_DTL
                // 재고 - [07, 추가출고], [02, 별도지급], [03, 폐기], [08, 반출], 12, 재고실사(-)]
                // 재고 + [05, 추가입고], [06, 전시차], [11, 재고실사(+)]

                // 출고 삭제 (del_yn : Y)
                sewIvmDAO.deleteIvModInfo(param);
                // 수정 재고
                sewIvmDAO.updateIvModInfo(param);
                // 수정 재고 상세
                sewIvmDAO.updateIvDtlModInfo(param);
            }
        } catch(RuntimeException e) {
            e.printStackTrace();
            return 0;
        } catch(Exception e) {
            e.printStackTrace();
            return 0;
        }
        return result;
    }

    @Override
    public List<SewonWhotResDTO> selectIvmSewonWhotList(ComIvmReqDTO reqDto) throws Exception {
        List<SewonWhotResDTO> result = new ArrayList<SewonWhotResDTO>();
        result = sewIvmDAO.selectIvmSewonWhotList(reqDto);
        return result;
    }

    @Override
    public List<IvmRequestMonitorResDTO> selectIvmSewonReqStateList(ComIvmReqDTO reqDto) throws Exception {
        List<IvmRequestMonitorResDTO> result = new ArrayList<IvmRequestMonitorResDTO>();
        result = sewIvmDAO.selectIvmSewonReqStateList(reqDto);
        return result;
    }

    @Override
    public List<IvmSewonPrintResDTO> selectIvmSewonPrintList(ComIvmReqDTO reqDto) {
        List<IvmSewonPrintResDTO> result = new ArrayList<IvmSewonPrintResDTO>();
        result = sewIvmDAO.selectIvmSewonPrintList(reqDto);
        return result;
    }

    @Transactional
    @Override
    public Integer updateIvmSewonPrintList(List<IvmSewonPrintReqDTO> reqDto, String userEeno, String dlExpdCoCd) {
        int result = 0;
        for(IvmSewonPrintReqDTO param : reqDto) {
            param.setUserEeno(userEeno);
            param.setDlExpdCoCd(dlExpdCoCd);
            result += sewIvmDAO.updateIvmSewonPrintList(param);
            int dtlResult = sewIvmDAO.updateIvmSewonDtlPrintList(param);
        }

        return result;
    }

    @Override
    public Integer deleteIvmSewonPrintList(List<IvmSewonPrintReqDTO> reqDto, String userEeno, String dlExpdCoCd) {
        int result = 0;
        for(IvmSewonPrintReqDTO param : reqDto) {
            param.setUserEeno(userEeno);
            param.setDlExpdCoCd(dlExpdCoCd);
            result += sewIvmDAO.deleteIvmSewonPrintList(param);
            sewIvmDAO.deleteIvmSewonDtlPrintList(param);
        }

        return result;
    }

    @Override
    public List<SewonIvModResDTO> selectIvModMonthList(ComIvmReqDTO reqDto) throws Exception {
        List<SewonIvModResDTO> result = new ArrayList<SewonIvModResDTO>();
        result = sewIvmDAO.selectIvModMonthList(reqDto);
        return result;
    }

    @Override
    public Integer insertSewonOrderRequestInfos(List<ComIvmReqDTO> reqDto, String userEeno, String dlExpdCoCd) throws Exception {
        int result = 0;
        List<ComIvmReqDTO> params = new ArrayList<ComIvmReqDTO>();

        for (ComIvmReqDTO param : reqDto)  {
            param.setUserEeno(userEeno);
            param.setDlExpdCoCd(dlExpdCoCd);
            param.setMenuGubun("SWON");
            params.add(param);

            //이메일 세팅 시작
            try {
                List<String> grpCds = new ArrayList<String>();
                grpCds.add("101"); //HMC --> 어차피 해당 차종으로 보기때문에 HMC, KMC 다 넣어도 상관 없음
                grpCds.add("102"); //KMC --> 어차피 해당 차종으로 보기때문에 HMC, KMC 다 넣어도 상관 없음
                grpCds.add("103"); //외주제작사
                grpCds.add("105"); //인쇄
                //해당 차종의 수신자 조회
                MailDTO mailDTO = new MailDTO();
                mailDTO.setQltyVehlCd(param.getQltyVehlCd());
                mailDTO.setMdlMdyCd(param.getMdlMdyCd());
                mailDTO.setGrpCds(grpCds);
                List<Mail> rcvList = mailService.selectEmlAdrListByVehlAndGrpCd(mailDTO);

                if(rcvList.size() > 0) {
                    //메일용 body 세팅
                    StringBuilder preSetBody = new StringBuilder();
                    preSetBody.append(
                            "<tr>\n" +
                                    "   <td>"+param.getQltyVehlCd()+"</td>\n" +
                                    "   <td>"+param.getQltyVehlNm()+"</td>\n" +
                                    "   <td>"+param.getMdlMdyCd()+"</td>\n" +
                                    "   <td>"+param.getLangCd()+"</td>\n" +
                                    "   <td>"+param.getLangCdNm()+"</td>\n" +
                                    "   <td>"+param.getDlExpdRegnNm()+"</td>\n" +
                                    "   <td>"+param.getRqQty()+"</td>\n" +
                                    "</tr>"
                            );

                    String title = "세원";
                    String rcvrGubun = "24";

                    String content = Utils.getEmailContent("IvmPdiOrderRequest");
                    String body = HtmlUtils.htmlEscape(content.replace("{tr}",preSetBody).replace("{title}",title));
                    mailDTO.setEmlTitl("[Owner’s Manual System] "+title+" 발주요청 메일입니다.");
                    mailDTO.setEmlSbc(body);        //본문 내용
                    mailDTO.setRcvList(rcvList);    //수신자 목록
                    mailDTO.setEmlScdCd(rcvrGubun); //별도요청:17, PDI배송요청:18, PDI발주요청:19, 용산발주요청:20, 세원발주요청
                    mailService.send(mailDTO);
                }
            } catch (Exception e) {

            }


        };
        result = sewIvmDAO.insertSewonOrderRequestInfos(params);

        return result;
    }

}
