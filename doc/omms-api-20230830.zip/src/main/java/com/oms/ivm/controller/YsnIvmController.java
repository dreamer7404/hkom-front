package com.oms.ivm.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import able.cloud.core.web.HController;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.oms.cmm.utils.Utils;
import com.oms.ivm.dto.ComIvmReqDTO;
import com.oms.ivm.dto.IvmRequestMonitorResDTO;
import com.oms.ivm.dto.SewonIvmResDTO;
import com.oms.ivm.dto.YsnIvmResDTO;
import com.oms.ivm.service.ComIvmService;
import com.oms.ivm.service.YsnIvmService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;


/**
 * <pre>
 * SwnIvmController
 * </pre>
 *
 * @ClassName   : YsnIvmController.java
 * @Description : 재고관리 > 용산재고관리 컨트롤러
 * @author 김정웅
 * @since 2023.6.26
 * @see
 */
@Tag(name = "YsnIvmController", description = "")
//@CrossOrigin(origins="*")
@RequiredArgsConstructor
@RestController
@RequestMapping("/api")
public class YsnIvmController extends HController {

    /**
     * 클래스 Injection
     */
    private final HttpServletRequest request;
    private final ComIvmService comIvmService;
    private final YsnIvmService ysnIvmService;

    /**
     * 재고관리 > 용산재고관리 > 용산재고관리 현황
     */
    @Operation(summary = "용산재고관리 조회")
    @GetMapping("/ivmYongsanIvmInfos")
    public List<YsnIvmResDTO> selectYongsanIvmList(@ModelAttribute ComIvmReqDTO reqDto) throws Exception {
        //사용자 ID, 회사코드 할당
        reqDto.setUserEeno(Utils.getUserEeno(request));
        reqDto.setDlExpdCoCd(Utils.getDlExpdCoCd(request));

        List<YsnIvmResDTO> result = ysnIvmService.selectYongsanIvmList(reqDto);
        return result;
    }

    /**
     * 재고관리 > 용산재고관리 > 요청현황
     */
    @Operation(summary = "용산 요청현황")
    @GetMapping("/ivmYsnRequestInfos")
    public List<IvmRequestMonitorResDTO> selectIvmYsnReqStateList(@ModelAttribute ComIvmReqDTO reqDto) throws Exception {
        reqDto.setUserEeno(Utils.getUserEeno(request));
        reqDto.setDlExpdCoCd(Utils.getDlExpdCoCd(request));

        List<IvmRequestMonitorResDTO> result = ysnIvmService.selectIvmYsnReqStateList(reqDto);

        return result;
    }

    /**
     * 재고관리 > 용산재고관리 > 용산배치종료일시조회
     */
    @Operation(summary = "용산배치종료일시조회")
    @GetMapping("/ivmYongsanFinBatchDtm")
    public String selectYongsanIvmFinBatchDtm(@ModelAttribute ComIvmReqDTO reqDto) throws Exception {
        reqDto.setUserEeno(Utils.getUserEeno(request));
        reqDto.setDlExpdCoCd(Utils.getDlExpdCoCd(request));
        String result = "조회 정보가 없습니다.";
        result = ysnIvmService.selectYongsanIvmFinBatchDtm(reqDto);


        return result;
    }

}