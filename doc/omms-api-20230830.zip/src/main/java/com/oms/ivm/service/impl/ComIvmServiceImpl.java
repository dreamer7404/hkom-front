package com.oms.ivm.service.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import able.cloud.core.service.HService;

import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.oms.ivm.dao.ComIvmDAO;
import com.oms.ivm.dto.ComIvmReqDTO;
import com.oms.ivm.dto.Ivm2WeekPlanReqDTO;
import com.oms.ivm.dto.Ivm2WeekPlanResDTO;
import com.oms.ivm.dto.Ivm3DayPlanReqDTO;
import com.oms.ivm.dto.Ivm3DayPlanResDTO;
import com.oms.ivm.dto.IvmPdiOrYongsanIvResDTO;
import com.oms.ivm.dto.IvmSewonIvResDTO;
import com.oms.ivm.dto.IvmThisMonTrwiResDTO;
import com.oms.ivm.service.ComIvmService;

import lombok.RequiredArgsConstructor;

/**
 * <pre>
 * ComIvmServiceImpl
 * </pre>
 *
 * @author 김정웅
 * @since 2023. 3. 13.
 * @see
 */
@RequiredArgsConstructor
@Service("comIvmService")
public class ComIvmServiceImpl extends HService implements ComIvmService {

    private final ComIvmDAO comIvmDAO;

    @Override
    public List<Ivm2WeekPlanResDTO> selectIvm2WeekPlanList(Ivm2WeekPlanReqDTO ivm2WeekPlanReqDTO) throws Exception {
        HashMap<String, String> getMsgPlanProd = comIvmDAO.getMsgPlanProd(ivm2WeekPlanReqDTO);
        ivm2WeekPlanReqDTO.setVSchYmd(getMsgPlanProd.get("V_PLN_FRAM_YMD").toString());

        List<Ivm2WeekPlanResDTO> result = new ArrayList<Ivm2WeekPlanResDTO>();
        if("N".equals(ivm2WeekPlanReqDTO.getPrdnPlntCd())||"ALL".equals(ivm2WeekPlanReqDTO.getPrdnPlntCd())) {
            result.addAll(comIvmDAO.selectIvm2WeekPlanList(ivm2WeekPlanReqDTO)); //일반 aps
        }else {
            result.addAll(comIvmDAO.selectIvm2WeekPlanPlntList(ivm2WeekPlanReqDTO));  //광주 12 plnt테이블
        }

        result.addAll(comIvmDAO.selectIvm2WeekPlanListSummary(ivm2WeekPlanReqDTO));

        return result;
    }

    @Override
    public Ivm3DayPlanResDTO selectIvm3DayPrdnPlanList(Ivm3DayPlanReqDTO reqDto) throws Exception {
        Ivm3DayPlanResDTO result = new Ivm3DayPlanResDTO();

        HashMap<String,String> fuGetWrkdate = comIvmDAO.fuGetWrkdate(reqDto.getBDate());
        reqDto.setVWrkYmd(fuGetWrkdate.get("V_WRK_YMD"));

        HashMap<String,String> expdPacScnCd = comIvmDAO.selectExpdPacScnCd(reqDto.getDataSn(), reqDto.getUserEeno(), reqDto.getDlExpdCoCd());
        reqDto.setDlExpdPacScnCd(expdPacScnCd.get("DL_EXPD_PAC_SCN_CD"));
        reqDto.setDlExpdPdiCd(expdPacScnCd.get("DL_EXPD_PDI_CD"));
        reqDto.setLangCd(expdPacScnCd.get("LANG_CD"));
        ObjectMapper objectMapper = new ObjectMapper();

        ComIvmReqDTO paramDto = objectMapper.convertValue(reqDto, ComIvmReqDTO.class);
        HashMap<String, Integer> todayPrdnPlan = comIvmDAO.selectIvmTodayPrdnPlanList(paramDto);

        int vTddPrdnPlanQty = Integer.parseInt(String.valueOf(todayPrdnPlan.get("V_TDD_PRDN_PLAN_QTY")));
        int vTddPrdnQty3 = Integer.parseInt(String.valueOf(todayPrdnPlan.get("V_TDD_PRDN_QTY3")));
        int vTddPrdnQty = Integer.parseInt(String.valueOf(todayPrdnPlan.get("V_TDD_PRDN_QTY")));
        int planTotQty = vTddPrdnPlanQty + vTddPrdnQty3;


        reqDto.setVTddPrdnPlanQty(vTddPrdnPlanQty);
        reqDto.setVTddPrdnQty3(vTddPrdnQty3);
        reqDto.setVTddPrdnQty(vTddPrdnQty);

        HashMap<String,String> vFramYmd = comIvmDAO.selectVFramYmd(reqDto.getBDate(), reqDto.getDlExpdCoCd());
        reqDto.setVFramYmd(vFramYmd.get("V_FRAM_YMD"));
        reqDto.setVLocalChar(vFramYmd.get("V_LOCAL_CHAR"));

        result = comIvmDAO.selectIvm3DayPrdnPlanList(reqDto);

        if("N".equals(reqDto.getPrdnPlntCd())||"ALL".equals(reqDto.getPrdnPlntCd())) {
            result = comIvmDAO.selectIvm3DayPrdnPlanList(reqDto);
        }else {
            result = comIvmDAO.selectIvm3DayPrdnPlanPlntList(reqDto);
        }
        result.setVLocalChar(reqDto.getVLocalChar());
        result.setPlanTotQty(planTotQty);

//        for(Ivm3DayPlanResDTO result : day3PrdnPlan) {
//            result.setPPlanTotQty(pPlanTotQty);
//            result.setIvm3DayPlanReqDTO(ivm3DayPlanReqDTO);
//            results.add(result);
//        }

//        day3PrdnPlan.forEach(result -> {
//            result.setPPlanTotQty(pPlanTotQty);
//            result.setIvm3DayPlanReqDTO(reqDto);
//            results.add(result);
//        });

        return result;
    }

    @Override
    public List<IvmThisMonTrwiResDTO> selectIvmThisMonTrwiList(ComIvmReqDTO reqDto) throws Exception {
        List<IvmThisMonTrwiResDTO> result = new ArrayList<IvmThisMonTrwiResDTO>();
        result = comIvmDAO.selectIvmThisMonTrwiList(reqDto);

        return result;
    }

    @Override
    public List<IvmSewonIvResDTO> selectIvmSewonIvList(ComIvmReqDTO reqDto) throws Exception {
        List<IvmSewonIvResDTO> result = new ArrayList<IvmSewonIvResDTO>();
        result = comIvmDAO.selectIvmSewonIvList(reqDto);
        return result;
    }


    @Override
    public List<IvmPdiOrYongsanIvResDTO> selectIvmYongsanIvList(ComIvmReqDTO reqDto) throws Exception {
        List<IvmPdiOrYongsanIvResDTO> result = new ArrayList<IvmPdiOrYongsanIvResDTO>();
        result = comIvmDAO.selectIvmYongsanIvList(reqDto);
        return result;
    }


    @Override
    public List<IvmPdiOrYongsanIvResDTO> selectIvmPdiIvList(ComIvmReqDTO reqDto) throws Exception {
        List<IvmPdiOrYongsanIvResDTO> result = new ArrayList<IvmPdiOrYongsanIvResDTO>();
        result = comIvmDAO.selectIvmPdiIvList(reqDto);
        return result;
    }

    @Override
    public HashMap<String, String> getSysDate2() throws Exception {
        return comIvmDAO.getSysDate2();
    }

    @Override
    public List<HashMap<String, String>> selectivmPrndPlntCdList(ComIvmReqDTO reqDto) throws Exception {
        return comIvmDAO.selectivmPrndPlntCdList(reqDto);
    }



}
