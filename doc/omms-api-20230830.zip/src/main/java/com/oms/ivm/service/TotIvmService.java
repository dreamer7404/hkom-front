package com.oms.ivm.service;

import java.util.List;

import com.oms.ivm.dto.ComIvmReqDTO;
import com.oms.ivm.dto.IvmMonthOrdPrdReqDTO;
import com.oms.ivm.dto.IvmMonthOrdPrdResDTO;
import com.oms.ivm.dto.IvmNatlProdPlanResDTO;
import com.oms.ivm.dto.IvmNoapimResDTO;
import com.oms.ivm.dto.IvmRequestMonitorResDTO;
import com.oms.ivm.dto.IvmVehlIvResDTO;
import com.oms.ivm.dto.TotIvmReqDTO;
import com.oms.ivm.dto.TotIvmRequestReqDTO;
import com.oms.ivm.dto.TotIvmResDTO;


/**
 * <pre>
 * TotalStockService
 * </pre>
 *
 * @ClassName   : TotalStockService.java
 * @Description : 재고관리 > 총재고관리 서비스
 * @author 김정웅
 * @since 2023.3.7
 * @see
 */

public interface TotIvmService {

    public List<TotIvmResDTO> selectTotalIvmList(TotIvmReqDTO totalStockReqDTO) throws Exception;

    //별도요청 저장
    public Integer intsertSeparatelyRequest (List<TotIvmRequestReqDTO> reqDto, String userEeno) throws Exception;

    //월간 오더/생산 정보
    public List<IvmMonthOrdPrdResDTO> selectMonthOrdPrdList(IvmMonthOrdPrdReqDTO reqDto) throws Exception;

    //국가별생산계획
    public List<IvmNatlProdPlanResDTO> selectNatlProdPlanList(ComIvmReqDTO comIvmReqDTO) throws Exception;

    //차종별재고분석
    public List<IvmVehlIvResDTO> selectVehlIvList(ComIvmReqDTO reqDto) throws Exception;

    //요청현황
    public List<IvmRequestMonitorResDTO> selectOrderRequestList(ComIvmReqDTO reqDto) throws Exception;

    //미연계정보
    public List<IvmNoapimResDTO> selectNoapimList(ComIvmReqDTO reqDto) throws Exception;



}
