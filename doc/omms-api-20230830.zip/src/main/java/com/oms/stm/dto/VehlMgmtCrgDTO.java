package com.oms.stm.dto;



import java.util.List;

import org.apache.ibatis.type.Alias;

import com.oms.common.dto.CommReqDTO;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


/**
 * <pre>
 * Statements
 * </pre>
 * @ClassName : VehlMgmtCrgDTO.java
 * @Description :  차종 담당자 dto
 * @author 김경훈
 * @since 2023. 4. 25.
 * @see
 */
@Alias("vehlMgmtCrgDTO")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class VehlMgmtCrgDTO extends CommReqDTO {

    private String qltyVehlCd ;

    private String mdlMdyCd;
    private String userNm;
    private String blnsCoCd;
    private String grpCd;
    private String clScnCd;
    private String dlExpdCoCd;









}
