package com.oms.stm.controller;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import able.cloud.core.web.HController;

import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.oms.cmm.global.Consts;
import com.oms.cmm.utils.Utils;
import com.oms.common.dto.CommReqDTO;
import com.oms.common.service.CommService;
import com.oms.stm.dto.LangMgmtReqDTO;
import com.oms.stm.dto.LangMgmtResDTO;
import com.oms.stm.dto.StmComReqDTO;
import com.oms.stm.service.LangMgmtService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName : LangMgmtController.java
 * @Description :
 * @author 김경훈
 * @since 2023. 3. 23.
 * @see
 */
@Tag(name = "LanglMgmtController", description = "")
@RequiredArgsConstructor
@RestController
@RequestMapping("/api")
public class LangMgmtController extends HController {

    /**
     * 클래스 Injection
     */
    private final HttpServletRequest request;
    private final LangMgmtService langMgmtService;
    private final CommService commService;

    // mst화면에서 조회 누를때
    @Operation(summary = "언어코드조회")
    @GetMapping("/langMgmts")
    public List<LangMgmtResDTO> selectLangMgmtList(@ModelAttribute StmComReqDTO dto, HttpServletRequest request)            throws Exception {


        dto.setUserEeno(Utils.getUserEeno(request));
        dto.setDlExpdCoCd(Utils.getDlExpdCoCd(request));
        if(dto.getQltyVehlCd()==null ||dto.getQltyVehlCd()==null)
        {
            dto.setQltyVehlCd("test");
        }


        return langMgmtService.selectLangList(dto);
    }

    @Operation(summary = "언어코드상세")
    @GetMapping("/langMgmt")
    public LangMgmtResDTO LangMgmt(@RequestParam String dataSn) throws Exception {

        return langMgmtService.selectLangDetail(dataSn);
    }

    @Operation(summary = "언어코드저장")
    @PostMapping("/langMgmt")
    public Integer langMgmt(@RequestBody LangMgmtReqDTO dto) throws Exception {
        int result = 0;
        String method = Utils.getMethod(request);
        dto.setUserEeno(Utils.getUserEeno(request));
        dto.setDlExpdCoCd(Utils.getDlExpdCoCd(request));


        if (method.equals(Consts.INSERT)) {
            if (!"ONE".equals(dto.getMultiGbn())) {
                langMgmtService.deleteLangCdList(dto); // 언어코드 삭제
                result = langMgmtService.insertLangCdMgmt(dto); // 언어코드 등록
                return result;
            } else {
                String langChk = langMgmtService.getLangMgmtChk(dto);
                if ("Y".equals(langChk)) {
                    result = langMgmtService.insertLangCdOne(dto);
                }else {
                    result = -1;
                }
                return result;
            }
        } else if (method.equals(Consts.UPDATE)) {
            result = langMgmtService.updateLangCdMgmt(dto);
            return result;
        } else if (method.equals(Consts.DELETE)) {
            result = langMgmtService.deleteLangCdMgmt(dto);
            return result;
        }



        // else if (method.equals(Consts.DELETE)) {
        // String chkVal = dto.getChkVal();
        // String[] resultItem = chkVal.split(",,");//체크된 그리드 리스트 //dataSn필요
        // itemList = Arrays.asList(resultItem);
        // dto.setItemList(itemList);
        // langMgmtService.deleteLangCdMgmt(dto);
        // return result;
        // }

        return result;
    }

    // mst -> 추가 -> 차종복사 체크할 경우
    @Operation(summary = "차종코드 복사목록")
    @GetMapping("/langMgmtsCopy")
    public List<LangMgmtResDTO> selectVehlLangCopyList(StmComReqDTO dto) throws Exception {
        LangMgmtResDTO resDto = new LangMgmtResDTO();
        dto.setDlExpdCoCd(Utils.getDlExpdCoCd(request));

        return langMgmtService.selectVehlLangCpList(dto);
    }

    @Operation(summary = "언어마스터 목록")
    @GetMapping("/langMsts")
    public List<LangMgmtResDTO> selectLangMstList(StmComReqDTO dto) throws Exception {

        dto.setUserEeno(Utils.getUserEeno(request));
        dto.setDlExpdCoCd(Utils.getDlExpdCoCd(request));
        return langMgmtService.selectLangMstList(dto);// 국가언어코드;
    }
    @Operation(summary = "언어마스터 상세")
    @GetMapping("/langMst")
    public LangMgmtResDTO selectLangMstInfo(StmComReqDTO dto) throws Exception {

        dto.setUserEeno(Utils.getUserEeno(request));
        dto.setDlExpdCoCd(Utils.getDlExpdCoCd(request));
        return langMgmtService.selectLangMstInfo(dto);
    }


    @Operation(summary = "언어마스터 등록")
    @PostMapping("/langMst")
    public Integer langMst(@RequestBody LangMgmtReqDTO dto) throws Exception {

        int result = 0;
        String method = Utils.getMethod(request);
        dto.setUserEeno(Utils.getUserEeno(request));
        dto.setDlExpdCoCd(Utils.getDlExpdCoCd(request));
        String validChk = langMgmtService.LangMstValidChk(dto);
        if (method.equals(Consts.INSERT)) {
            if ("Y".equals(validChk)) {
                result =langMgmtService.insertLangMst(dto);

            } else {
                result = 999;
            }
        } else if (method.equals(Consts.UPDATE)) {
           result = langMgmtService.updateLangMst(dto);
           result = langMgmtService.updateLangMgmt(dto);
        } else if (method.equals(Consts.DELETE)) {
            result = langMgmtService.deleteLangMst(dto);
        }
        return result;
    }

}