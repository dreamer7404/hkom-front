package com.oms.stm.service;

import java.util.HashMap;
import java.util.List;

import com.oms.common.dto.CommReqDTO;
import com.oms.stm.dto.LangMgmtReqDTO;
import com.oms.stm.dto.LangMgmtResDTO;
import com.oms.stm.dto.NatlMgmtReqDTO;
import com.oms.stm.dto.NatlMgmtResDTO;
import com.oms.stm.dto.NatlMgmtSaveDTO;
import com.oms.stm.dto.StmComReqDTO;
import com.oms.stm.dto.VehlMgmtSaveDTO;


/**
 * <pre>
 * NatlMgmtService
 * </pre>
 *
 * @ClassName   : NatlMgmtService.java
 * @Description :
 * @author 안경수
 * @since 2023.1.6
 * @see
 */

public interface NatlMgmtService {


    /**
     * Statements
     *
     * @param dto
     * @return
     */
    List<NatlMgmtResDTO> selectNatlCdMstList(StmComReqDTO dto);

    /**
     * Statements
     *
     * @param dto
     * @return
     */
    int insertNatlCdMst(NatlMgmtReqDTO dto);

    /**
     * Statements
     *
     * @param dto
     */
    int updateNatlCdMst(NatlMgmtReqDTO dto);

    /**
     * Statements
     *
     * @param dto
     */
    int deleteNatlCdMst(NatlMgmtReqDTO dto);

    /**
     * Statements
     *
     * @param dto
     * @return
     */
    int updateNatlVehlMgmt(NatlMgmtSaveDTO dto);

    /**
     * Statements
     *
     * @param dto
     * @return
     */
    List<NatlMgmtResDTO> selectNatlLangClumList(StmComReqDTO dto);

    /**
     * Statements
     *
     * @param hmap
     * @return
     */
    List<HashMap<String, Object>> selectNatlLangList(HashMap<String, Object> hmap);

    /**
     * Statements
     *
     * @param hmap
     * @return
     */
    List<NatlMgmtResDTO> selectNatlBlkList(HashMap<String, Object> hmap);

    /**
     * Statements
     *
     * @param dto
     * @return
     */
    List<NatlMgmtResDTO> selectNatlMgmtList(StmComReqDTO dto);

    /**
     * Statements
     *
     * @param dto
     * @return
     */
    List<NatlMgmtResDTO> selectNatlVehlList(StmComReqDTO dto);

    /**
     * Statements
     *
     * @param dto
     * @return
     */
    String selectNatlMgmtCount(NatlMgmtSaveDTO dto);

    /**
     * Statements
     *
     * @param dto
     */
    int insertNatlCdMgmt(NatlMgmtSaveDTO dto);

    /**
     * Statements
     *
     * @param dto
     */
    int deleteNatlLangMgmt(NatlMgmtSaveDTO dto);

    /**
     * Statements
     *
     * @param dto
     */
    int deleteNatlVehlMgmt(NatlMgmtSaveDTO dto);

    /**
     * Statements
     *
     * @param natlMgmtSaveDTO
     * @return
     */
    int insertNatlVehlMgmt(NatlMgmtSaveDTO natlMgmtSaveDTO);

    /**
     * Statements
     *
     * @param natlMgmtSaveDTO
     * @return
     */
    int insertNatlLangMgmt(NatlMgmtSaveDTO natlMgmtSaveDTO);

    /**
     * Statements
     *
     * @param dto
     * @return
     */
    List<NatlMgmtResDTO> selectNatlMdyCombo(NatlMgmtReqDTO dto);

    /**
     * Statements
     *
     * @param dto
     * @return
     */
    List<HashMap<String, Object>> selectNatlLangCpyList(NatlMgmtReqDTO dto);

    /**
     * Statements
     *
     * @param dto
     * @return
     */
    NatlMgmtResDTO getNatlVehlRegn(NatlMgmtReqDTO dto);

    /**
     * Statements
     *
     * @param dto
     * @return
     */
    int updRegnCd(NatlMgmtReqDTO dto);

    /**
     * Statements
     *
     * @param natlSaveDto
     * @return
     */
    int deleteNatlBlkList(NatlMgmtSaveDTO natlSaveDto);

    /**
     * Statements
     *
     * @param natlSaveDto
     * @return
     */
    int insertNatlBlkList(NatlMgmtSaveDTO natlSaveDto);

    /**
     * Statements
     *
     * @param dto
     * @return
     */
    List<NatlMgmtResDTO> selectNatlVehlLangDetail(StmComReqDTO dto);

    /**
     * Statements
     *
     * @param dto
     * @return
     */
    String natlMstValidChk(NatlMgmtReqDTO dto);

    /**
     * Statements
     *
     * @param dto
     * @return
     */
    NatlMgmtResDTO selectNatlCdMst(StmComReqDTO dlExpdNatCd);

    /**
     * Statements
     *
     * @param natlMgmtSaveDTO
     * @return
     */
    int deleteExcelUpload(NatlMgmtSaveDTO natlMgmtSaveDTO);

    /**
     * Statements
     *
     * @param dto
     * @return
     */
    List<NatlMgmtResDTO> selectNatlVehlDetailList(StmComReqDTO dto);

}
