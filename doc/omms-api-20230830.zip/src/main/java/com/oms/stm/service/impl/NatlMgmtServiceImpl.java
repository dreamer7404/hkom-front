package com.oms.stm.service.impl;

import java.util.HashMap;
import java.util.List;

import able.cloud.core.service.HService;

import org.springframework.stereotype.Service;

import com.oms.stm.dao.NatlMgmtDAO;
import com.oms.stm.dto.LangMgmtReqDTO;
import com.oms.stm.dto.LangMgmtResDTO;
import com.oms.stm.dto.NatlMgmtReqDTO;
import com.oms.stm.dto.NatlMgmtResDTO;
import com.oms.stm.dto.NatlMgmtSaveDTO;
import com.oms.stm.dto.StmComReqDTO;
import com.oms.stm.dto.VehlMgmtSaveDTO;
import com.oms.stm.service.NatlMgmtService;

import lombok.RequiredArgsConstructor;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @author 안경수
 * @since 2023. 2. 24.
 * @see
 */
@RequiredArgsConstructor
@Service("natlMgmtService")
public class NatlMgmtServiceImpl extends HService implements NatlMgmtService {

    private final NatlMgmtDAO natlMgmtDAO;


    /*
     * @see com.oms.stm.service.LangMgmtService#selectNatlCdMstList(com.oms.stm.dto.StmComReqDTO)
     */
    @Override
    public List<NatlMgmtResDTO> selectNatlCdMstList(StmComReqDTO dto) {
        // TODO Auto-generated method stub
        return natlMgmtDAO.selectNatlCdMstList(dto);
    }

    /*
     * @see com.oms.stm.service.LangMgmtService#insertNatlCdMst(com.oms.stm.dto.LangMgmtReqDTO)
     */
    @Override
    public int insertNatlCdMst(NatlMgmtReqDTO dto) {
        // TODO Auto-generated method stub
        return natlMgmtDAO.insertNatlCdMst(dto);
    }

    /*
     * @see com.oms.stm.service.LangMgmtService#updateNatlCdMst(com.oms.stm.dto.LangMgmtReqDTO)
     */
    @Override
    public int updateNatlCdMst(NatlMgmtReqDTO dto) {
        return natlMgmtDAO.updateNatlCdMst(dto);

    }

    /*
     * @see com.oms.stm.service.LangMgmtService#deleteNatlCdMst(com.oms.stm.dto.LangMgmtReqDTO)
     */
    @Override
    public int deleteNatlCdMst(NatlMgmtReqDTO dto) {
        return natlMgmtDAO.deleteNatlCdMst(dto);
    }

    /*
     * @see com.oms.stm.service.NatlMgmtService#updateNatlVehlMgmt(com.oms.stm.dto.NatlMgmtReqDTO)
     */
    @Override
    public int updateNatlVehlMgmt(NatlMgmtSaveDTO dto) {
        // TODO Auto-generated method stub
        return natlMgmtDAO.updateNatlVehlMgmt(dto);
    }

    /*
     * @see com.oms.stm.service.NatlMgmtService#selectNatlLangClumList(com.oms.stm.dto.StmComReqDTO)
     */
    @Override
    public List<NatlMgmtResDTO> selectNatlLangClumList(StmComReqDTO dto) {
        // TODO Auto-generated method stub
        return natlMgmtDAO.selectNatlLangClumList(dto);
    }

    /*
     * @see com.oms.stm.service.NatlMgmtService#selectNatlLangList(java.util.HashMap)
     */
    @Override
    public List<HashMap<String, Object>> selectNatlLangList(HashMap<String, Object> hmap) {
        // TODO Auto-generated method stub
        return natlMgmtDAO.selectNatlLangList(hmap);
    }

    /*
     * @see com.oms.stm.service.NatlMgmtService#selectNatlBlkList(java.util.HashMap)
     */
    @Override
    public List<NatlMgmtResDTO> selectNatlBlkList(HashMap<String, Object> hmap) {
        // TODO Auto-generated method stub
        return natlMgmtDAO.selectNatlBlkList(hmap);
    }

    /*
     * @see com.oms.stm.service.NatlMgmtService#selectNatlMgmtList(com.oms.stm.dto.StmComReqDTO)
     */
    @Override
    public List<NatlMgmtResDTO> selectNatlMgmtList(StmComReqDTO dto) {
        // TODO Auto-generated method stub
        return natlMgmtDAO.selectNatlMgmtList(dto);
    }

    /*
     * @see com.oms.stm.service.NatlMgmtService#selectNatlVehlList(com.oms.stm.dto.StmComReqDTO)
     */
    @Override
    public List<NatlMgmtResDTO> selectNatlVehlList(StmComReqDTO dto) {
        return natlMgmtDAO.selectNatlVehlList(dto);
    }

    /*
     * @see com.oms.stm.service.NatlMgmtService#selectNatlMgmtCount(com.oms.stm.dto.NatlMgmtReqDTO)
     */
    @Override
    public String selectNatlMgmtCount(NatlMgmtSaveDTO dto) {
        // TODO Auto-generated method stub
        return natlMgmtDAO.selectNatlMgmtCount(dto);
    }

    /*
     * @see com.oms.stm.service.NatlMgmtService#insertNatlCdMgmt(com.oms.stm.dto.NatlMgmtReqDTO)
     */
    @Override
    public int insertNatlCdMgmt(NatlMgmtSaveDTO dto) {
        return natlMgmtDAO.insertNatlCdMgmt(dto);
    }

    /*
     * @see com.oms.stm.service.NatlMgmtService#deleteNatlLangMgmt(com.oms.stm.dto.NatlMgmtReqDTO)
     */
    @Override
    public int deleteNatlLangMgmt(NatlMgmtSaveDTO dto) {
        return natlMgmtDAO.deleteNatlLangMgmt(dto);

    }

    /*
     * @see com.oms.stm.service.NatlMgmtService#deleteNatlVehlMgmt(com.oms.stm.dto.NatlMgmtReqDTO)
     */
    @Override
    public int deleteNatlVehlMgmt(NatlMgmtSaveDTO dto) {
        return natlMgmtDAO.deleteNatlVehlMgmt(dto);
    }

    /*
     * @see com.oms.stm.service.NatlMgmtService#insertNatlVehlMgmt(com.oms.stm.dto.VehlMgmtSaveDTO)
     */
    @Override
    public int insertNatlVehlMgmt(NatlMgmtSaveDTO natlMgmtSaveDTO) {
        // TODO Auto-generated method stub
        return natlMgmtDAO.insertNatlVehlMgmt(natlMgmtSaveDTO);
    }

    /*
     * @see com.oms.stm.service.NatlMgmtService#insertNatlLangMgmt(java.lang.String)
     */
    @Override
    public int insertNatlLangMgmt(NatlMgmtSaveDTO natlMgmtSaveDTO) {
        // TODO Auto-generated method stub
        return natlMgmtDAO.insertNatlLangMgmt(natlMgmtSaveDTO);
    }

    /*
     * @see com.oms.stm.service.NatlMgmtService#selectNatlMdyCombo(com.oms.stm.dto.NatlMgmtReqDTO)
     */
    @Override
    public List<NatlMgmtResDTO> selectNatlMdyCombo(NatlMgmtReqDTO dto) {
        // TODO Auto-generated method stub
        return  natlMgmtDAO.selectNatlMdyCombo(dto);
    }

    /*
     * @see com.oms.stm.service.NatlMgmtService#selectNatlLangCpyList(com.oms.stm.dto.NatlMgmtReqDTO)
     */
    @Override
    public List<HashMap<String, Object>> selectNatlLangCpyList(NatlMgmtReqDTO dto) {
        // TODO Auto-generated method stub
        return  natlMgmtDAO.selectNatlLangCpyList(dto);
    }

    /*
     * @see com.oms.stm.service.NatlMgmtService#getNatlVehlRegn(com.oms.stm.dto.NatlMgmtReqDTO)
     */
    @Override
    public NatlMgmtResDTO getNatlVehlRegn(NatlMgmtReqDTO dto) {
        // TODO Auto-generated method stub
        return  natlMgmtDAO.getNatlVehlRegn(dto);
    }

    /*
     * @see com.oms.stm.service.NatlMgmtService#updRegnCd(com.oms.stm.dto.NatlMgmtReqDTO)
     */
    @Override
    public int updRegnCd(NatlMgmtReqDTO dto) {
        // TODO Auto-generated method stub
        return  natlMgmtDAO.updRegnCd(dto);
    }

    /*
     * @see com.oms.stm.service.NatlMgmtService#deleteNatlBlkList(com.oms.stm.dto.NatlMgmtSaveDTO)
     */
    @Override
    public int deleteNatlBlkList(NatlMgmtSaveDTO natlSaveDto) {
        // TODO Auto-generated method stub
        return  natlMgmtDAO.deleteNatlBlkList(natlSaveDto);
    }

    /*
     * @see com.oms.stm.service.NatlMgmtService#insertNatlBlkList(com.oms.stm.dto.NatlMgmtSaveDTO)
     */
    @Override
    public int insertNatlBlkList(NatlMgmtSaveDTO natlSaveDto) {
        // TODO Auto-generated method stub
        return  natlMgmtDAO.insertNatlBlkList(natlSaveDto);
    }

    /*
     * @see com.oms.stm.service.NatlMgmtService#selectNatlVehlLangDetail(com.oms.stm.dto.StmComReqDTO)
     */
    @Override
    public List<NatlMgmtResDTO> selectNatlVehlLangDetail(StmComReqDTO dto) {
        // TODO Auto-generated method stub
        return  natlMgmtDAO.selectNatlVehlLangDetail(dto);
    }

    /*
     * @see com.oms.stm.service.NatlMgmtService#natlMstValidChk(com.oms.stm.dto.NatlMgmtReqDTO)
     */
    @Override
    public String natlMstValidChk(NatlMgmtReqDTO dto) {
        // TODO Auto-generated method stub
        return  natlMgmtDAO.natlMstValidChk(dto);
    }

    /*
     * @see com.oms.stm.service.NatlMgmtService#selectNatlCdMst(com.oms.stm.dto.StmComReqDTO)
     */
    @Override
    public NatlMgmtResDTO selectNatlCdMst(StmComReqDTO dto) {
        // TODO Auto-generated method stub
        return natlMgmtDAO.selectNatlCdMst(dto);
    }

    /*
     * @see com.oms.stm.service.NatlMgmtService#deleteExcelUpload(com.oms.stm.dto.NatlMgmtSaveDTO)
     */
    @Override
    public int deleteExcelUpload(NatlMgmtSaveDTO natlMgmtSaveDTO) {
        // TODO Auto-generated method stub
        return natlMgmtDAO.deleteExcelUpload(natlMgmtSaveDTO);
    }

    /*
     * @see com.oms.stm.service.NatlMgmtService#selectNatlVehlDetailList(com.oms.stm.dto.StmComReqDTO)
     */
    @Override
    public List<NatlMgmtResDTO> selectNatlVehlDetailList(StmComReqDTO dto) {
        // TODO Auto-generated method stub
        return natlMgmtDAO.selectNatlVehlDetailList(dto);
    }

}
