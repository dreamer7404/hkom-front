package com.oms.common.service;

import java.util.List;

import com.oms.common.dto.ComboReqDTO;
import com.oms.common.dto.CommReqDTO;
import com.oms.common.dto.PdiComboResDTO;
import com.oms.common.dto.VehlComboResDTO;
import com.oms.stm.dto.BoardReqDTO;
import com.oms.stm.dto.BoardResDTO;
import com.oms.stm.dto.LangMgmtResDTO;
import com.oms.stm.dto.StmComReqDTO;
import com.oms.stm.dto.VehlMgmtResDTO;
import com.oms.sys.dto.UsrMgmtReqDTO;
import com.oms.sys.dto.UsrMgmtResDTO;



/**
 * <pre>
 * Statements
 * </pre>
 * @ClassName : CommService.java
 * @Description :
 * @author 김경훈
 * @since 2023. 3. 22.
 * @see
 */
public interface CommService {

    /**
     * Statements
     *
     * @param comDto
     * @return
     */
    List<VehlMgmtResDTO> selectCodeList(CommReqDTO comDto);



    /**
     * Statements
     *
     * @param dto
     * @return
     */
    List<UsrMgmtResDTO> userMgmtPop(UsrMgmtReqDTO dto);

    /**
     * Statements
     *
     * @param dto
     * @return
     */
    List<BoardResDTO> selectNoticeList(BoardReqDTO dto);

    /**
     * Statements
     *
     * @param dto
     * @return
     */
    String noticePopYn(BoardReqDTO dto);


}
