package com.oms.common.service;

import java.util.HashMap;
import java.util.List;

import com.oms.common.dto.MailDTO;
import com.oms.common.model.Mail;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @author 안경수
 * @since 2023. 5. 16.
 * @see
 */

public interface MailService {
    void send(MailDTO mailDTO);
    int insertLogEml(MailDTO mailDTO);
    int insertLogEmlSnd(MailDTO mailDTO);
    int updateLogEmlSnd(MailDTO mailDTO);
    List<Mail> selectEmlAdrList(List<String> list);
    //긴급인쇄리스트 조회
    List<MailDTO> selectUrgentPrintList();
    //차종별 담당자 조회(+그룹코드 구분)
    List<Mail> selectEmlAdrListByVehlAndGrpCd(MailDTO mailDTO);
}
