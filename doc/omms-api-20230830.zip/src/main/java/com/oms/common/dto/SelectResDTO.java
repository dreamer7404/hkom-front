package com.oms.common.dto;

import java.util.ArrayList;
import java.util.List;

import org.apache.ibatis.type.Alias;

import lombok.AllArgsConstructor;
import lombok.Data;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @author 안경수
 * @since 2023. 6. 5.
 * @see
 */

@AllArgsConstructor
@Data
@Alias("selectResDTO")
public class SelectResDTO {
    private Integer level;
    private String value;
    private String label;

    private List<SelectResDTO> children; // = new ArrayList<>();

}
