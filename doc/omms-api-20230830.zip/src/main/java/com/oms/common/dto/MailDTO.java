package com.oms.common.dto;

import java.sql.Timestamp;
import java.util.List;

import org.apache.ibatis.type.Alias;

import com.oms.common.model.Mail;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @author 안경수
 * @since 2023. 5. 17.
 * @see
 */
@NoArgsConstructor
@Data
@Alias("mailDTO")
public class MailDTO {
    private Integer EmlCd; // tb_log_eml의 pk

    private String emlScdCd; // 구분 (0030) 13: 비밀번호찾기, 14: 게시판, 15: 체크리스트
    private List<Mail> rcvList; // 수신자 메일<rcvEeno, rcvAdr> 리스트

    private String sndrId;  // 발신자 사번
    private String emlTitl; // 제목
    private String emlSbc;  // 내용
    private Timestamp fsSndDate; //발송일

    private String AdreEml;
    private String dataGbnVal;      //페이지 데이터키값

    private String emlStCd; // 이메일 발송상태

    private String rcvrId;  //수신자 아이디

    private String qltyVehlCd;  //차종코드
    private String mdlMdyCd;    //차종연식
    private List<String> grpCds;//그룹코드

    /**
     * Statements
     *
     * @param emlScdCd
     * @param sndrId
     * @param emlTitl
     * @param emlSbc
     */
    public MailDTO(String emlScdCd, List<Mail> rcvList, String sndrId, String emlTitl, String emlSbc, String emlStCd, String dataGbnVal) {
        super();
        this.emlScdCd = emlScdCd;
        this.rcvList = rcvList;
        this.sndrId = sndrId;
        this.emlTitl = emlTitl;
        this.emlSbc = emlSbc;
        this.emlStCd = emlStCd;
        this.dataGbnVal = dataGbnVal;
    }

    /**
     * Statements
     *
     * @param emlScdCd
     * @param sndrId
     * @param emlTitl
     * @param emlSbc
     */
    public MailDTO(String emlScdCd, List<Mail> rcvList, String sndrId, String emlTitl, String emlSbc, String emlStCd) {
        super();
        this.emlScdCd = emlScdCd;
        this.rcvList = rcvList;
        this.sndrId = sndrId;
        this.emlTitl = emlTitl;
        this.emlSbc = emlSbc;
        this.emlStCd = emlStCd;
    }



}
