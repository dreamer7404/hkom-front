package com.oms.mri.dto;

import org.apache.ibatis.type.Alias;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * <pre>
 * PrintOrderPrntPbcnNoResDTO
 * </pre>
 *
 * @author 김정웅
 * @since 2023. 6. 1.
 * @see
 */
@Alias("printOrderPrntPbcnNoResDTO")
@Data
@AllArgsConstructor
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown =true)
public class PrintOrderPrntPbcnNoResDTO {

    private String newPrntPbcnNo;
    private String oldPrntPbcnNo;
    private String qltyVehlCd;
    private String mdlMdyCd;
    private String langCd;
    private String dlExpdRdcsStCd;
    private String dlExpdRdcsStCdNm;
    private String qltyVehlNm;
    private String langCdNm;
    private String dlExpdRegnNm;



}
