package com.oms.mri.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import com.oms.mri.dto.ClcmInfoPopReqDTO;
import com.oms.mri.dto.ClcmInfoResDTO;
import com.oms.mri.dto.ClcmInfosReqDTO;
import com.oms.mri.dto.ClcmInfosResDTO;


/**
 * <pre>
 * PrintOrderDAO
 * </pre>
 * @ClassName : ClcmDAO.java
 * @Description : 제작준비 > 법규및변경관리  DAO
 * @author 김정웅
 * @since 2023. 5. 22.
 * @see
 */
public interface ClcmDAO {
    //법규 및 변경관리 목록
    List<ClcmInfosResDTO> selectClcmInfoList(ClcmInfosReqDTO reqDto) ;

    //법규 및 변경관리 등록
    String getDlExpdAltrNo(ClcmInfoPopReqDTO reqDto);
    Integer insertClcmInfo(ClcmInfoPopReqDTO reqDto);
    Integer insertClcmInfoDtl(ClcmInfoPopReqDTO reqDto);
    //법규 및 변경관리 수정
    Integer updateClcmInfo(ClcmInfoPopReqDTO reqDto);
    //법규 및 변경관리 삭제
    Integer selectClcmInfoDtlCount (String reqDto);
    Integer deleteClcmInfo(String reqDto);
    Integer deleteClcmInfoDtl(ClcmInfoPopReqDTO reqDto);

    //법규 및 변경관리 상세
    ClcmInfoResDTO selectClcmInfo(ClcmInfosReqDTO reqDto);
    List<HashMap<String, String>> selectClcmInfoDtl(ClcmInfosReqDTO reqDto);

    //법규 및 변경관리 수정 차종 별 언어 조회
    List<HashMap<String, String>> selectClcmLangCdList(String qltyVehlCd);

    //법규 및 변경관리 상세 송부인 목록 조회
    List<HashMap<String, String>> selectmriClcmInfoRcvrList(ClcmInfosReqDTO reqDto);

}
