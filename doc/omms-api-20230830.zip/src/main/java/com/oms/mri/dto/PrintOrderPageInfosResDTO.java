package com.oms.mri.dto;

import java.util.List;

import org.apache.ibatis.type.Alias;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * <pre>
 * PrintOrderPageInfosResDTO
 * </pre>
 *
 * @author 김정웅
 * @since 2023. 6. 8.
 * @see
 */
@Alias("printOrderPageInfosResDTO")
@Data
@AllArgsConstructor
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown =true)
public class PrintOrderPageInfosResDTO {

    private String dlExpdMdlMdyCd;
    private String coverAttcSn;
    private String oldPrntPbcnNo;
    private String oordEditPgNl;
    private String updrEeno;
    private String prntWayCd;
    private String prntWayCdNm;
    private String mdlMdyCd;
    private String framDtm;
    private String attcYn;
    private String ordQty;
    private String dlvgParrYmd;
    private String csetCrgrEeno;
    private String prntParrBgt;
    private String qltyVehlCd;
    private String prntParrYmd;
    private String depc1Yn;
    private String mdfyDtm;
    private String ordnRqstYmd;
    private String depq1Cd;
    private String prntWayCd2;
    private String prntWayCd2Nm;
    private String prtlImtrSbc;
    private String moAvgPrdnQty;
    private String crgrEeno;
    private String pgNl;
    private String oldPrntPbcnNo1;
    private String iWayCd;
    private String saleUnp;
    private String newPrntPbcnNo;
    private String pprrEeno;
    private String mdfyPgNl;
    private String grnDocNl;
    private String langCdNm;
    private String USER_NM;
    private String innerAttcSn;
    private String qltyVehlNm;
    private String ivQty;
    private String langCd;
    private String prntParrQty;
    private String pgMgnSbc;
    private int finalCount;
    private int modifyCount;

    private List<Object> pageList; //인쇄배열표 리스트


}
