package com.oms.mri.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Optional;

import com.oms.mri.dto.ClcmInfosResDTO;
import com.oms.mri.dto.PrintOrderComDTO;
import com.oms.mri.dto.PrintOrderInfoReqDTO;
import com.oms.mri.dto.PrintOrderInfosResDTO;
import com.oms.mri.dto.PrintOrderPageInfosResDTO;
import com.oms.mri.dto.PrintOrderPageReqDTO;
import com.oms.mri.dto.PrintOrderPrntPbcnNoResDTO;
import com.oms.mri.dto.PrintOrderReqInfoResDTO;


/**
 * <pre>
 * PrintOrderDAO
 * </pre>
 * @ClassName : PrintOrderDAO.java
 * @Description : 제작준비 > O/M발주  DAO
 * @author 김정웅
 * @since 2023. 5. 11.
 * @see
 */
public interface PrintOrderDAO {
    //O/M발주 목록
    List<PrintOrderInfosResDTO> selectPrintOrderList(PrintOrderComDTO reqDto) ;

    //O/M발주 개정정보
    List<ClcmInfosResDTO> selectPrintOrderClcmInfos(PrintOrderComDTO reqDto);

    //O/M발주 발간번호조회
    List<PrintOrderPrntPbcnNoResDTO> selectPrintOrderPrntPbcnNoInfos(PrintOrderComDTO reqDto);

    //O/M발주 발간번호 별 세부내역조회
    PrintOrderReqInfoResDTO selectPrintOrderReqInfo(PrintOrderComDTO reqDto);

    //인쇄배열표 셀렉트박스
    List<HashMap<String, String>> selectNPrntPbcnNoLrnkCdList(PrintOrderComDTO reqDto);
    //인쇄배열표 조회
    HashMap<String, String> getMdfyPageCount(PrintOrderComDTO reqDto);
    HashMap<String, String> selectMaxDeppc1Sn(PrintOrderComDTO reqDto);
    List<HashMap<String, String>> selectPageInfoList(PrintOrderComDTO reqDto);
    List<HashMap<String, String>> selectAlgnInfoList(PrintOrderComDTO reqDto);
    Optional<PrintOrderPageInfosResDTO> selectPrntApvlInfo(PrintOrderComDTO reqDto);
    HashMap<String, String> selectPrintOrderPageInfoDtl(PrintOrderComDTO reqDto);

    //인쇄배열표 세부내역 삭제
    Integer deletePrntAlgn(PrintOrderPageReqDTO reqDto);
    //인쇄배열표 세부내역 등록
    Integer insertPrntAlgn(List<HashMap<String, Object>> params);

    //O/M발주 등록
    String selectPrntPbcnNoDupChk(PrintOrderInfoReqDTO reqDto);
    String selectBlcSnExstChk(PrintOrderInfoReqDTO reqDto);
    Integer insertPrntReqInfo2(PrintOrderInfoReqDTO reqDto);
    Integer insertPrntBkgdInfo2(PrintOrderInfoReqDTO reqDto);
    Integer deleteChklistDtlInfo(PrintOrderInfoReqDTO reqDto);
    Integer updateChklistDtlInfo(HashMap<String, Object> reqDtoTmp);
    Integer spSewonWhsnInfoSave(PrintOrderInfoReqDTO reqDto);
    HashMap<String, String> selectNameByCode(PrintOrderInfoReqDTO reqDto);
    String selectTbPrntPageMgmtCheck(PrintOrderInfoReqDTO reqDto);

    //O/M발주 취소(삭제 포함)
    //발주취소
    Integer spPrntApvCancl(PrintOrderInfoReqDTO reqDto);
    HashMap<String, Object> selectCanclChk(PrintOrderInfoReqDTO reqDto);
    Integer deleteCanclChk(PrintOrderInfoReqDTO reqDto);
    //임시저장본 삭제
    Integer deletePrntReqInfo(PrintOrderInfoReqDTO reqDto);
    Integer deletePrntBkgdInfo(PrintOrderInfoReqDTO reqDto);




}
