package com.oms.print.dto;

import org.apache.ibatis.type.Alias;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName : PrintStateResDTO.java
 * @Description :
 * @author 김경훈
 * @since 2023. 5. 3.
 * @see
 */
@Alias("PrintStateResDTO")
@Data
@NoArgsConstructor
@AllArgsConstructor

public class PrintStateResDTO {

  //리스트
    private String newPrntPbcnNo;
    private String dlExpdPdiCd;
    private String qltyVehlNm;
    private String langCdNm;
    private String prntParrYmd;
    private String dlvgParrYmd;
    private String iWayCd;
    private String prntParrQty;
    private String prntParrBgt;
    private String prntParrBgt2;
    private String saleUnp;
    private String prtlImtrSbc;
    private String reviseQty;
    private String qltyVehlCd;
    private String mdlMdyCd;
    private String langCd;
    private String clScnCd;
    private String dlExpdRegnCd;
    private String prtlImtrSbc2;
    private String prtlImtrSbc3;
    private String attcYn;
    private String iWayNm;
    private String regnNm;
    private String altrTitl;
    //상세





    private String dlExpdDlvgPlCd;
    private String oldPrntPbcnNo;
    private String iWaySbc;
    private String bkbdWaySbc;
    private String pgMgnSbc;
    private String depcq1Sbc;
    private String deipq1Sbc;
    private String prntCvrSbc;
    private String prntInsdPgSbc;
    private String cPrntCvrSbc;
    private String cPrntInsdPgSbc;
    private String cvrCegSbc;
    private String pgNl;
    private String cvrNl;
    private String expdNl;
    private String grnDocNl;
    private String postCrdNl;
    private String eofu1Nl;
    private String nrFlmMkoNl;
    private String dgtlPrntNl;
    private String oordEditPgNl;
    private String oordEditCoCd;
    private String depc1Qty;
    private String rem;
    private String ivQty;
    private String ordQty;
    private String moAvgPrdnQty;
    private String rqQty;
    private String dlExpdPrvsNm;
    private String expdN1;




    private String prntWayCd;
    private String depq1Cd;

    private String mdfyPgNl;
    private String depc1Yn;

    private String ordnRqstYmd;
    private String ordnCsetCdt;
    private String n1Afp2Adr;
    private String n2Afp2Adr;
    private String crgrEeno;
    private String csetCrgrEeno;
    private String dlExpdMdlMdyCd;
    private String pprrEeno;
    private String framDtm;
    private String updrEeno;
    private String mdfyDtm;

    private String prntWayCd2;

    private String coverAttcSn;
    private String innerAttcSn;


    private String dlExpdAltrNo;
    private String altrSbc;
    private String altrSbc1;
    private String blcSn;
    private String crgrNm;
    private String depq1Nm;
    private String prntWayNm;
    private String oordEditCoNm;
}
