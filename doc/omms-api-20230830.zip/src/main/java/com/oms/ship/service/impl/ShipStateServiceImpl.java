package com.oms.ship.service.impl;


import java.util.List;

import able.cloud.core.service.HService;

import org.springframework.stereotype.Service;

import com.oms.ship.dao.ShipStateDAO;
import com.oms.ship.dto.ShipStateReqDTO;
import com.oms.ship.dto.ShipStateResDTO;
import com.oms.ship.service.ShipStateService;

import lombok.RequiredArgsConstructor;


@RequiredArgsConstructor
@Service("ShipService")
public class ShipStateServiceImpl extends HService implements ShipStateService {

    private final ShipStateDAO shipStateDAO;


    @Override
    public List<ShipStateResDTO> selectShipStateList(ShipStateReqDTO dto) {
        // TODO Auto-generated method stub
        return shipStateDAO.selectShipStateList(dto);
    }


    /*
     * @see com.oms.ship.service.ShipStateService#selectShipStateTotList(com.oms.ship.dto.ShipStateReqDTO)
     */
    @Override
    public Integer selectShipStateTotList(ShipStateReqDTO dto) {
        // TODO Auto-generated method stub
        return shipStateDAO.selectShipStateTotList(dto);
    }


}





