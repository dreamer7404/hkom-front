package com.oms.cmm.security;

import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.Base64;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import javax.crypto.spec.SecretKeySpec;
import javax.servlet.http.HttpServletRequest;
import javax.xml.bind.DatatypeConverter;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.oms.cmm.config.HttpMessageConverterConfig;
import com.oms.cmm.global.Consts;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.ExpiredJwtException;
import io.jsonwebtoken.Jws;
import io.jsonwebtoken.JwtBuilder;
import io.jsonwebtoken.JwtException;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import io.jsonwebtoken.security.Keys;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @author 안경수
 * @since 2023. 2. 13.
 * @see
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class JwtTokenProvider {

    private static Logger log = LoggerFactory.getLogger(JwtTokenProvider.class);
    private String  secretKey  = Base64.getEncoder().encodeToString(Consts.SECRET_KEY.getBytes());
    private final SignatureAlgorithm signatureAlgorithm = SignatureAlgorithm.HS256;

    private Key createKey() {
        byte[] apiKeySecretBytes = DatatypeConverter.parseBase64Binary(secretKey);
        Key signingKey = new SecretKeySpec(apiKeySecretBytes, signatureAlgorithm.getJcaName());
        return signingKey;
    }

    public String createToken(String userEeno, String blnsCoCd, String grpCd, long tokenValidTime){

        Map<String, Object> headerMap = new HashMap<>();
        headerMap.put("typ", "JWT");
        headerMap.put("alg", "HS256");

        Map<String, Object> claims = new HashMap<>();
        claims.put(Consts.CLAIM_USER_EENO, userEeno);
        claims.put(Consts.CLAIM_BLNS_CO_CD, blnsCoCd);
        claims.put(Consts.CLAIM_GRP_CD, grpCd);

        Date expireTime = new Date(System.currentTimeMillis()+ tokenValidTime);

        JwtBuilder builder = Jwts.builder()
                .setHeader(headerMap)
                .setClaims(claims)
                .setExpiration(expireTime)
                .signWith(createKey(), signatureAlgorithm);

        String result = builder.compact();
        return result;

    }
    public Boolean checkJwt(String jwt) throws Exception {
        try {
            Jwts.parserBuilder()
                    .setSigningKey(DatatypeConverter.parseBase64Binary(secretKey))
                    .build()
                    .parseClaimsJws(jwt)
                    .getBody();

        } catch (ExpiredJwtException e) {
            log.info("[EXCEPTION] ==> Token Expired!!!");
            return false;
        } catch (JwtException e) {
            log.info("[EXCEPTION] ==> Token Exception!!!");
            return false;
        }
        return true;
    }


    // 토큰의 유효성 + 만료일자 확인
    @SuppressWarnings("deprecation")
    public boolean validateToken(String jwtToken) {
        try {
            // secretKey => b21zU2VjcmV0S2V5
            Jws<Claims> claims = Jwts.parser().setSigningKey(secretKey).parseClaimsJws(jwtToken);
            return !claims.getBody().getExpiration().before(new Date());
        } catch (Exception e) {
            return false;
        }
    }

    // 토큰에서 회원 정보 추출
    @SuppressWarnings("deprecation")
    public String getUserPk(String token) {
        String user = Jwts.parser().setSigningKey(secretKey).parseClaimsJws(token).getBody().getSubject();
        return user;
    }

    // 토큰에서 추가정보 추출
    @SuppressWarnings("deprecation")
    public String getMapInfo(String token, String key) {
        return Jwts.parser().setSigningKey(secretKey).parseClaimsJws(token).getBody().get(key).toString();
    }

    // Request의 Header에서 token 값을 가져옵니다. "X-AUTH-TOKEN" : "TOKEN값'
    public String getToken(HttpServletRequest request) {
        return request.getHeader(Consts.X_AUTH_TOKEN);
    }


}
