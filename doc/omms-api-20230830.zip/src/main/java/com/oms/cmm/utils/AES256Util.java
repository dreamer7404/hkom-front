package com.oms.cmm.utils;


import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.util.Arrays;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

import org.apache.commons.codec.binary.Base64;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import lombok.extern.slf4j.Slf4j;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : AES256Cipher.java
 * @Description : AES 암호화
 * @author PARK JAEHOON
 * @since 2023. 7. 27.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2023. 7. 27.     PARK JAEHOON       최초 생성
 *  2023. 8. 01.     AHN KYUNGSOO       OMS 적용
 * </pre>
 */

@Slf4j
@Component
public class AES256Util {

    private static Logger logger = LoggerFactory.getLogger(AES256Util.class);


    public String encryptAES(String keyString, String plainText, boolean bUrlSafe) throws Exception {

        String cipherText = "";

        if (plainText == null || plainText.length() == 0) {
            return plainText;
        }

        try {
            byte[] keyBytes = keyString.getBytes("UTF-8");
            byte[] plainTextBytes = plainText.getBytes("UTF-8");

            Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
            int bsize = cipher.getBlockSize();
            IvParameterSpec ivspec = new IvParameterSpec(Arrays.copyOfRange(keyBytes, 0, bsize));

            SecretKeySpec secureKey = new SecretKeySpec(keyBytes, "AES");
            cipher.init(Cipher.ENCRYPT_MODE, secureKey, ivspec);
            byte[] encrypted = cipher.doFinal(plainTextBytes);

            if (bUrlSafe) {
                cipherText = Base64.encodeBase64URLSafeString(encrypted);
            } else {
                cipherText = new String(Base64.encodeBase64(encrypted), "UTF-8");
            }
        } catch(NoSuchAlgorithmException e) {
            logger.error("NoSuchAlgorithmException", e);
        } catch(NoSuchPaddingException e) {
            logger.error("NoSuchPaddingException", e);
        } catch(InvalidKeyException e) {
            logger.error("InvalidKeyException", e);
        } catch(InvalidAlgorithmParameterException e) {
            logger.error("InvalidAlgorithmParameterException", e);
        } catch(IllegalBlockSizeException e) {
            logger.error("IllegalBlockSizeException", e);
        } catch(BadPaddingException e) {
            logger.error("BadPaddingException", e);
        } catch(Exception e) {
            logger.error("Exception", e);
        }

        return cipherText;

    }

    public String decryptAES(String keyString, String cipherText) throws Exception {

        String plainText = "";

        if (cipherText == null || cipherText.length() == 0) {
            return cipherText;
        }

        try {
            byte[] keyBytes = keyString.getBytes("UTF-8");
            byte[] cipherTextBytes = Base64.decodeBase64(cipherText.getBytes("UTF-8"));

            Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
            int bsize = cipher.getBlockSize();
            IvParameterSpec ivspec = new IvParameterSpec(Arrays.copyOfRange(keyBytes, 0, bsize));

            SecretKeySpec secureKey = new SecretKeySpec(keyBytes, "AES");
            cipher.init(Cipher.DECRYPT_MODE, secureKey, ivspec);
            byte[] decrypted = cipher.doFinal(cipherTextBytes);

            plainText = new String(decrypted, "UTF-8");

        } catch(NoSuchAlgorithmException e) {
            logger.error("NoSuchAlgorithmException", e);
        } catch(NoSuchPaddingException e) {
            logger.error("NoSuchPaddingException", e);
        } catch(InvalidKeyException e) {
            logger.error("InvalidKeyException", e);
        } catch(InvalidAlgorithmParameterException e) {
            logger.error("InvalidAlgorithmParameterException", e);
        } catch(IllegalBlockSizeException e) {
            logger.error("IllegalBlockSizeException", e);
        } catch(BadPaddingException e) {
            logger.error("BadPaddingException", e);
        } catch(Exception e) {
            logger.error("Exception", e);
        }

        return plainText;
    }
}
