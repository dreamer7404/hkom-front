
/* eslint-disable react-hooks/exhaustive-deps */
import React ,{useState, useRef, useEffect, useMemo, useCallback} from 'react';
import {Button,Modal, Row, Col, Table} from 'react-bootstrap';
import {Schema, Form, SelectPicker, CustomProvider, DatePicker, Radio, RadioGroup, MultiCascader} from 'rsuite';
import { AgGridReact } from 'ag-grid-react';

//--------------  서버데이터용 필수 -------------------------------
import { useQuery, useQueryClient, useMutation} from 'react-query';
import { getData, postData } from '../../../../utils/async';
import { API, CONSTANTS } from '../../../../utils/constants';
import useStore from '../../../../utils/store';
//--------------// 서버데이터용 필수 -------------------------------


const BoardAddTest = () => {;

    const [value, setValue] = React.useState();

    const [data, setData] = React.useState([
        {label: 'aaa', value: '111' ,children:[] },
        {label: 'bbb', value: '222'},
    ]);

    const children =  [
        {label: 'aaa2', value: '111-2'},
        {label: 'aaa3', value: '111-3'},
    ]

    const getChildren = () => {
        return new Promise(resolve => {
            setTimeout(() => resolve(children), 1000);
        });
    }

    const headers = ['차종', '언어'];

    const getValue = () => {
        console.log('getValue', value)
    }

    return(
        <>
        
            <MultiCascader 
            style={{width: '400px'}}
            className="multi-cascader"
            onChange={setValue}
            value={value}
            data={data}
            getChildren={getChildren}
            renderMenu={(children, menu, parentNode, layer) => {
                if (parentNode && parentNode.loading) {
                    return <p style={{ padding: 10, color: '#999', textAlign: 'center' }}>Loading...</p>;
                  }
                return (
                    <div>
                      <div
                          style={{
                          background: '#f8f8f8',
                          padding: '4px 10px',
                          color: ' #000',
                          textAlign: 'center',
                          fontSize:'12px',
                          fontWeight:600
                          }}
                      >
                          {headers[layer]}
                      </div>
                      {menu}
                    </div>
                );
                return menu;
            }} 
            
            />

            <Button onClick={getValue} >get value</Button>


        </>
    )
};
export default BoardAddTest;