/* eslint-disable react-hooks/exhaustive-deps */
import React ,{useState, useRef, useEffect, useMemo, useCallback} from 'react';
import {Button,Modal, Row, Col, Table} from 'react-bootstrap';
import {Schema, Form, SelectPicker, CustomProvider, DatePicker, Radio, RadioGroup, Checkbox, MultiCascader} from 'rsuite';
import { AgGridReact } from 'ag-grid-react';

//--------------  서버데이터용 필수 -------------------------------
import { useQuery, useQueryClient, useMutation} from 'react-query';
import { getData, postData } from '../../../../utils/async';
import { API, CONSTANTS } from '../../../../utils/constants';
import useStore from '../../../../utils/store';
//--------------// 서버데이터용 필수 -------------------------------
import { confirmAlert } from 'react-confirm-alert'; 
import ConfirmAlert from   '../../../Common/ConfirmAlert';  
import { changeCharToEscape, escapeCharChange} from '../../../../utils/commUtils';
import moment from 'moment';

import VehlLangCascader from '../../../Search/VehlLangCascader'
import Dompurify from "dompurify" 

import { DEXT5Editor } from 'dext5editor-react';
import { DEXT5Upload } from 'dext5upload-react';

import ko from 'rsuite/locales/ko_KR';

const { StringType, MixedType} = Schema.Types;
const model = Schema.Model({
    blcScnCd: StringType().isRequired('분류를 선택해주세요.'),
    befmyTrwiYn: StringType().isRequired('전MY투입가능여부를 선택해주세요.'),
    bbYn: StringType().isRequired('책등 유무를 선택해주세요.'),
    dtrwiYn: StringType().isRequired('분리투입여부를 선택해주세요.'),
    altrTrwiYn: StringType().isRequired('교체투입여부를 선택해주세요.'),
    blcTitlNm: StringType().isRequired('제목을 입력해주세요.'),
});

const Field = React.forwardRef((props, ref) => {
    const { name, message, label, accepter, error, ...rest } = props;
    return (
      <Form.Group controlId={`${name}-10`} ref={ref} className={error ? 'has-error' : ''}>
        <Form.ControlLabel>{label} </Form.ControlLabel>
        <Form.Control name={name} accepter={accepter} errorMessage={error} {...rest} />
        <Form.HelpText>{message}</Form.HelpText>
      </Form.Group>
    );
  });
const BoardAdd = () => {

    const gridRef = useRef();
    const gridVehlRef = useRef();
    const {token, coCd} = useStore();

    const [gubun, setGubun] = useState([])

    // 게시판구분
    const params = {
        dlExpdGCd: '0039' // 게시판 구분 (불용재고, 교체투입, 분리투입, 기타)
    };
    const gubunCombo = useQuery([API.codeCombo, params], () => getData(API.codeCombo, params));
    useEffect(() => {
        if(gubunCombo.isFetched){
            setGubun(gubunCombo.data)
        }
    },[gubunCombo.data])

    //등록자
    const usrmgmt = useQuery([API.usrmgmt], () => getData(API.usrmgmt));

    
    
    //------------------------------- 차종 및 언어 - Cascader --------------------------------------------------------------
    const [openCascader, setOpenCascader] = useState(false);
    const toggle = () => setOpenCascader(!openCascader)
    const headers = ['차종', '연식', '언어'];
    const [vehlLang, setVehlLang] = useState([]); // value (선택된데이타)
    const [vehlLangData, setVehlLangData] = useState([]); // data (가져온 리스트)
    

    // 차종쿼리
    const vehlCombo = useQuery([API.vehlsByUserCombo, ''], () => getData(API.vehlsByUserCombo, ''),{
        select: data => data.map(item => ({level: 0, label: escapeCharChange(item.qltyVehlNm), value: item.qltyVehlCd, children:[] }))
    }); 

    // 그리드용 차종,연식,언어 리스트
    const param = {codes: vehlLang.join(',')}
    const queryGrid = useQuery([API.vehlMdyLangGrid, param], () => getData(API.vehlMdyLangGrid, param),{
        enabled:  false,
        // select: data => data.map(item => ({label: item, value: item, children:[] }))
    }); 

    useEffect(() => {
        if(vehlCombo.isFetched){
            setVehlLangData(vehlCombo.data) // cascader용
            // setLoadData(vehlCombo.data) // grid용 , getChildren할때 추가
        }
    },[vehlCombo.data])

   
    // 닫기버튼
    const onCloseVehlLang = e => {
        setOpenCascader(false);
        queryGrid.refetch();
    }

    useEffect(() => {
        if(queryGrid.isFetched){
            setSelectedLangCdByVehl(queryGrid.data)        
        }
    },[queryGrid.data]);

    // 선택한내용 저장
    const onChangeVehlLang = (val, e) => {
        setVehlLang(val);
    }

    const onCheckVehlLang = (value, item, checked, e)  => {
        // console.log('[@@@@@@@@@@@@ check] ', value, item, checked);
    }
      
    // 자식 가져오기
    // 차종코드_연식_언어코드
    const getChildren =  (e) => {
        // console.log('########### e', e)
        // setVehlLang(e.value);
        return new Promise(resolve => {  
            setTimeout(() => {
                if(e.level === 0){ // 연식쿼리
                    const qltyVehlCd = e.value;
                    getData(API.mdysByVehlCdCombo, {qltyVehlCd: qltyVehlCd}).then(items => {
                        const children = items.map(item => ({level: 1, label: item, value: qltyVehlCd+'_'+item, children:[] })) // => 차종코드_연식
                        // setLoadData(loadData.map(item => item.value === qltyVehlCd ? {...item, children: children} : item)) // 그리드용
                        resolve(children);
                    })
                }else if(e.level === 1){ // 언어쿼리
                    const qltyVehlCd = e.value.split('_')[0];
                    const mdlMdyCd = e.value.split('_')[1];
                    getData(API.langsByVehlCdMdyCombo, {qltyVehlCd: qltyVehlCd, mdlMdyCd: mdlMdyCd}).then(items => {
                        const children = items.map(item => ({label: item.langCdNm, value: e.value+'_'+item.langCd })) // => 차종코드_연식_언어코드
                        // setLoadData(loadData.map(item => item.value === qltyVehlCd  
                        //         ? ({...item, children: item.children.map(item2 => item2.value === e.value ? {...item2, children: children} : item2)}) 
                        //         : item))

                        resolve(children);
                    })
                }
               
            }, 500);
        });
    }

    //차종 및 언어 그리드
    const [selectedLangCdByVehl, setSelectedLangCdByVehl] = useState([]);
    const columnDefs = [
        {
            headerName: '차종',
            field: 'qltyVehlNm',
        },
        {
            headerName: '연식',
            field: 'mdlMdyCd',
        },
        {
            headerName: '언어',
            field: 'langCdNm',
        },
    ];
    //-------------------------------// 차종 및 언어 - Cascader ---------------------


    //----------------------- 수신인 ---------------------------------------------

    const columnDefs2 = [
        {
          checkboxSelection: true,
          headerCheckboxSelection: true,
          width:45,
          maxWidth:45,
          minWidth:45
        },
        {
          headerName: '소속',
          field: 'coDeptNm',
        },
        {
          headerName: '이름',
          field: 'userNm',
        },
    ]

    const defaultColDef = useMemo(() => {
        return {
            initialWidth: 90,
            sortable: true,
        };
    }, []);

    const onFirstDataRendered = (params) => {
        params.api.sizeColumnsToFit();
    };

    const paramsUsr = {
        blnsCoCd: coCd
    }
    const usrData = useQuery([API.userMgmtPop,paramsUsr], () => getData(API.userMgmtPop, paramsUsr), {
        select: data => data.map(item => ({...item, coDeptNm: item.coNm+'('+item.deptNm+')'}))
    })
    //수신인 그리드 내에서 클릭된 RowData by Woong
    const [checkedRowData, setCheckedRowData] = useState();
    const onSelectionChanged = useCallback(() => {
        const selectedRows = gridRef.current.api.getSelectedRows();
        setCheckedRowData(selectedRows)
    }, []);
    //-----------------------// 수신인 ---------------------------------------------


    // Form 정의 (for validation..)
    const formRef = React.useRef();
    const [formError, setFormError] = React.useState({});
    const [formValue, setFormValue] = React.useState({
        blcScnCd: '',   // 게시물 구분코드
        // rgnEeno:'',     // 등록인
        befmyTrwiYn: '', // 전MY투입가능여부
        bbYn: 'N', // 책등여부
        bbVal: '', // 책등값
        dtrwiRqYmd: new Date(),       //분리투입요청일
        dtrwiYn: '',           // 분리투입여부
        dtrwiMidcsnYn: false,    // 분리투입미확정여부
        altrTrwiYn: '',       // 교체투입여부
        nmtrwiRqYmd: new Date(),      // 신규매뉴얼투입요청일
        nmtrwiMidcsnYn: false,   // 신규매뉴얼투입미확정여부
        blcTitlNm: '',  //게시물제목명
        // blcSbc: '',  //게시물내용 
        
        // attcYn: '',  //첨부여부
        // replyYn: '',  //댓글여부
        // delYn: '',  //삭제여부
        // emlCd: '', //이메일 코드(리턴값)

        // langCdByVehl: [], //차종및 언어
        // rcvUsers: [], // 수신인

    });



    //  UPLOAD 
    const [flag, setFlag ] = useState(false)
    useEffect(() => {
        setTimeout(() => setFlag(true), 500);
    },[]);


    // 등록
    const insertMutate = useMutation((params => postData(API.boardAffrMgmt, params, CONSTANTS.insert)),{
        onSuccess: res => {

        }
    });

    const getParam = () =>{
        console.log('formValue', formValue);
        if (!formRef.current.check()) {
            return;
        }


        // 적용차종및 언어
        if(selectedLangCdByVehl.length === 0){
            setFormError(formError => ({...formError, senderListVali: true}));
            return;
        }
        // 수신인
        const rcvUsers = gridRef.current.api.getSelectedRows().map(item => item.userEeno);
        if(rcvUsers.length === 0){
            confirmAlert({
                closeOnClickOutside: false,
                customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}  title={"알림"} msg={"수신인을 선택해주세요."}  />
            })
            return;
        }

        //책등색상
        if(formValue.bbYn === 'Y' && formValue.bbVal === ''){
            // confirmAlert({
            //     closeOnClickOutside: false,
            //     customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}  title={"알림"} msg={"책등색상을 입력해주세요."}  />
            // })
            setFormError(formError => ({...formError, bbVal: true}));
            return;
        }

        // 내용
        const textValue = DEXT5.getBodyTextValue();
        if(DEXT5.getBodyTextValue().length === 0){
            confirmAlert({
                closeOnClickOutside: false,
                customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}  title={"알림"} msg={"내용을 입력해주세요."}  />
            })
            return;
        }

        const param = {
            blcScnCd: formValue.blcScnCd,   // 게시물 구분코드
            // rgnEeno:formValue.rgnEeno,     // 등록인
            befmyTrwiYn: formValue.befmyTrwiYn, // 전MY투입가능여부
            bbYn: formValue.bbYn, // 책등여부
            bbVal: formValue.bbVal, // 책등값
            dtrwiRqYmd: moment(formValue.dtrwiRqYmd).format('YYYYMMDD'),       //분리투입요청일
            dtrwiYn: formValue.dtrwiYn,           // 분리투입여부
            dtrwiMidcsnYn: formValue.dtrwiMidcsnYn ? 'Y': 'N',    // 분리투입미확정여부
            altrTrwiYn: formValue.altrTrwiYn,       // 교체투입여부
            nmtrwiRqYmd: moment(formValue.nmtrwiRqYmd).format('YYYYMMDD'),      // 신규매뉴얼투입요청일
            nmtrwiMidcsnYn: formValue.nmtrwiMidcsnYn ? 'Y': 'N',   // 신규매뉴얼투입미확정여부
            blcTitlNm: formValue.blcTitlNm,  //게시물제목명

            langCdByVehl: selectedLangCdByVehl.map(item => ({qltyVehlCd: item.qltyVehlCd, mdlMdyCd: item.mdlMdyCd, langCd: item.langCd})) || [], // 차종및 언어
            rcvUsers: rcvUsers,               // 수신인
            blcSbc: DEXT5.getBodyValue(),       //  내용
            attcYn: DEXT5UPLOAD.GetTotalFileCount() > 0 ? 'Y' : 'N', // 파일첨부 여부
        }
        console.log('param', param);
        return param;
    }

    // 저장버튼
    const saveButton = () => {
        // DEXT5UPLOAD.Transfer();
        // return;

        const param = getParam();

        //첨부파일이 없으면
        if(DEXT5UPLOAD.GetTotalFileCount() === 0){
             insertMutate.mutate(param);
        }
        else{
            // 파일업로드 실행
            DEXT5UPLOAD.Transfer();
        }

    }

    // 기존업로드된 파일리스트 (수정화면에서 사용)
    const onCreationComplete = e => {
        // DEXT5UPLOAD.AddUploadedFile( 100, "메뉴.PNG", "", "", token, 'dext5upload1' );
    }

    // 파일업로드후 리턴값
    const onTransferComplete = e => {
        // console.log(e)
        // const list = DEXT5UPLOAD.GetNewUploadListForText("dext5upload1");
        const list = DEXT5UPLOAD.GetAllFileListForJson("dext5upload1");
        console.log('list', list)

        const param = getParam();
        console.log('paramSave2', param);
        // 업로드후 DB저장
        // insertMutate.mutate(formValue);
    }



    return (
        <>
            <div className="write-wrap">
                <Form
                        ref={formRef}
                        checkTrigger="change"
                        onChange={setFormValue}
                        onCheck={setFormError}
                        formValue={formValue}
                        model={model}
                    >
                    <Table className="tbl-hor" bordered>
                        <colgroup>
                            <col style={{width:'15%'}}></col>
                            <col style={{width:'35%'}}></col>
                            <col style={{width:'15%'}}></col>
                            <col style={{width:'35%'}}></col>
                        </colgroup>
                        <tbody>
                            <tr>
                                <th>분류</th>
                                <td>
                                    <Form.Control 
                                        name="blcScnCd" 
                                        size="sm" 
                                        placeholder={'선택'}
                                        accepter={SelectPicker} 
                                        searchable={false}
                                        cleanable={false}
                                        data={gubun}
                                    ></Form.Control>

                                </td>
                                <th>등록자</th>
                                <td>{usrmgmt.isFetched && usrmgmt.data.userNm}</td>
                            </tr>
                            <tr>
                                <th>차종 및 언어</th>
                                <td colSpan="3">
                                    <MultiCascader 
                                        open={openCascader}
                                        menuHeight={450}
                                        menuWidth={250}
                                        size="sm"
                                        block
                                        style={{width: '800px'}}
                                        className="multi-cascader"

                                        data={vehlLangData}
                                        value={vehlLang}

                                        onChange={onChangeVehlLang}
                                        onCheck={onCheckVehlLang}
                                        onClick={toggle} // input box 클릭
                                        getChildren={getChildren}

                                        renderMenu={(children, menu, parentNode, layer) => (
                                                <div>
                                                    <div className='multi-cascader-header'>
                                                        {headers[layer]}
                                                    </div>
                                                    {menu}
                                                </div>
                                        )}
                                        renderExtraFooter={() => (
                                            <div className='multi-cascader-footer'>
                                                <Button variant="primary" onClick={onCloseVehlLang}>확인</Button>
                                            </div>
                                        )}
                                        />
                                </td>
                            </tr>
                            <tr>
                                <th>적용 차종 및 언어</th>
                                <td>
                                    <div className="ag-theme-alpine" style={{height: 130, transition:'all ease .3s'}}>
                                        <AgGridReact
                                            ref={gridVehlRef}
                                            initialWidth={90}
                                            sortable={true}
                                            // defaultColDef={defaultColDef}
                                            columnDefs={columnDefs}
                                            rowData={selectedLangCdByVehl}
                                            onFirstDataRendered={onFirstDataRendered}
                                            suppressSizeToFit={true}    
                                            onGridSizeChanged={onFirstDataRendered}    
                                            overlayNoRowsTemplate={'적용차종 및 언어를 선택하세요.'}
                                            > 
                                        </AgGridReact> 
                                    </div>
                                </td>
                                <th>수신인</th>
                                <td>
                                    <div className="ag-theme-alpine" style={{height: 130, transition:'all ease .3s'}}>
                                        {usrData && usrData.isSuccess &&
                                            <AgGridReact
                                            ref={gridRef}
                                            initialWidth={90}
                                            sortable={true}
                                            // defaultColDef={defaultColDef}
                                            rowData={usrData && usrData.isSuccess &&usrData.data}
                                            columnDefs={columnDefs2}
                                            rowSelection={'multiple'}
                                            suppressRowClickSelection= {true} 
                                            onFirstDataRendered={onFirstDataRendered}
                                            suppressSizeToFit={true}    
                                            onGridSizeChanged={onFirstDataRendered}
                                            // checkedRowDatas by Woong
                                            onSelectionChanged={onSelectionChanged}
                                            
                                            >
                                            </AgGridReact>
                                        }
                                    </div>
                                </td>
                            </tr>
                            <tr>
                                <th>전 MY 투입가능</th>
                                <td>
                                    <Form.Control inline name="befmyTrwiYn" accepter={RadioGroup} >
                                        <Radio value="Y">Y</Radio>
                                        <Radio value="N">N</Radio>
                                    </Form.Control> 
                                    
                                </td>
                                <th>책등 유무</th>
                                <td>
                                    <div className="form-group">
                                         <Form.Control inline name="bbYn" accepter={RadioGroup} defaultValue={'N'}>
                                            <Radio value="Y">Y</Radio>
                                            <Radio value="N">N</Radio>
                                        </Form.Control>
                                        <Form.Control disabled={formValue.bbYn==='N'} name="bbVal" className="inline-block ml-10" size="sm" style={{width:'130px'}} type="text" placeholder="색상을 입력해주세요" />
                                        <Form.ErrorMessage show={formValue.bbYn==='Y' && formValue.bbVal === ''} style={{marginLeft: '150px'}} >색상을 입력해주세요.</Form.ErrorMessage>
                                    </div>
                                </td>
                            </tr>
                            <tr >
                                <th>분리투입 여부</th>
                                <td>
                                    <Form.Control inline name="dtrwiYn" accepter={RadioGroup} >
                                        <Radio value="Y">Y</Radio>
                                        <Radio value="N">N</Radio>
                                    </Form.Control>
                                </td>
                                <th>분리투입 요청일</th>
                                <td >
                                    <Form.Group>
                                        <Form.Control name="dtrwiRqYmd" oneTap size="sm" cleanable={false} accepter={DatePicker} style={{width:'150px', marginRight: '10px'}} />
                                        <Form.Control name="dtrwiMidcsnYn" accepter={Checkbox} checked={formValue.dtrwiMidcsnYn} value={!formValue.dtrwiMidcsnYn}>미확정</Form.Control>
                                    </Form.Group>
                                </td>
                            </tr>
                            <tr>
                                <th>교체투입 여부(이전매뉴얼 폐기)</th>
                                <td>
                                    <Form.Control inline name="altrTrwiYn" accepter={RadioGroup} >
                                        <Radio value="Y">Y</Radio>
                                        <Radio value="N">N</Radio>
                                    </Form.Control>
                                </td>
                                <th>신규매뉴얼 투입 요청일</th>
                                <td>
                                     <Form.Group>
                                        <Form.Control name="nmtrwiRqYmd" oneTap size="sm" cleanable={false} accepter={DatePicker}  style={{width:'150px', marginRight: '10px'}} />
                                        <Form.Control name="nmtrwiMidcsnYn" accepter={Checkbox} checked={formValue.nmtrwiMidcsnYn} value={!formValue.nmtrwiMidcsnYn}>미확정</Form.Control>
                                    </Form.Group>
                                </td>
                            </tr>
                            <tr>
                                <th>제목</th>
                                <td colSpan="3">
                                    <Form.Control name="blcTitlNm" size="sm" type="text" placeholder="제목을 입력해주세요" />
                                </td>
                            </tr>
                            <tr>
                                <th>내용</th>
                                <td colSpan="3">
                                    <DEXT5Editor
                                        debug={true}
                                        id="editor1"
                                        componentUrl="/dext5editor/js/dext5editor.js"
                                        config={{ DevelopLangage:'NONE', Width:'100%' }}
                                        initData="<p>Hello <strong>DEXT5 Editor</strong> world!</p>"
                                    />
                                </td>
                            </tr>
                            <tr>
                                <th>첨부파일</th>
                                <td colSpan="3">
                                    {flag && <DEXT5Upload
                                        onCreationComplete={onCreationComplete}
                                        onTransferComplete={onTransferComplete}
                                        debug={true}
                                        id="dext5upload1"
                                        mode='edit' 
                                        // mode='view'  // view Mode
                                        runtimes='html5'
                                        componentUrl="/dext5upload/js/dext5upload.js"
                                        config={{MaxTotalFileSize:'100MB', MaxOneFileSize:'30MB', DevelopLangage:'NONE',
                                        ButtonBarEdit: "add,remove,remove_all,download",
                                        // ButtonBarView: 'download,download_all', // view Mode
                                        Width:'100%'}}
                                        
                                    />}
                                </td>
                            </tr>
                        </tbody>
                    </Table>
                </Form>


        
                <div className="btn-wrap">
                    <div className="right-align">
                        <Button variant="light" >취소</Button>{' '}
                        <Button className="" variant="primary" size="md" onClick={saveButton}>저장</Button>
                    </div>
                </div>
            </div>
        </>
    )
};
export default BoardAdd;