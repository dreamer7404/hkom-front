import React from 'react';
import {Tab,Tabs} from 'react-bootstrap';

import UseHistory from './UseHistory';
import LoginHistory from './LoginHistory';
import AuthChangeHistory from './AuthChangeHistory';
import FileUploadHistory from './FileUploadHistory';
import SchedulerHistory from './SchedulerHistory';

const LogContainer = () => {

    const [leftWidth, setLeftWidth] = React.useState('150px')
    React.useEffect(() => {
        const getTitle = document.getElementById('section-title-width');
        const titleWidth = getTitle.clientWidth + 40;
        setLeftWidth(titleWidth);
    }, []);

    const [activeTab, setActiveTab] = React.useState('tab1');

    return (
        <>  
            <Tabs  defaultActiveKey="tab1" onSelect={tab => setActiveTab(tab)} style={{left: leftWidth}} >
                <Tab eventKey="tab1" title="사용 이력">
                    {activeTab === 'tab1' && <UseHistory />}
                </Tab>
                <Tab eventKey="tab2" title="로그인 이력">
                    {activeTab === 'tab2' && <LoginHistory />}
                </Tab>
                <Tab eventKey="tab3" title="권한변경 이력">
                    {activeTab === 'tab3' && <AuthChangeHistory />}
                </Tab>
                <Tab eventKey="tab4" title="파일업/다운로드 이력">
                    {activeTab === 'tab4' && <FileUploadHistory />}
                </Tab>
                <Tab eventKey="tab5" title="스케쥴러 이력">
                    {activeTab === 'tab5' && <SchedulerHistory />}
                </Tab>
            </Tabs>
        </>

       
    );

};
export default LogContainer;