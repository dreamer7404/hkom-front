/* eslint-disable jsx-a11y/alt-text */
/* eslint-disable react-hooks/exhaustive-deps */
// react
import React, {useState, useEffect} from 'react';
import {  Link, useNavigate } from 'react-router-dom';
import axios from 'axios';
import { useAsync } from 'react-async';


// bootstrap
import Container from 'react-bootstrap/Container';
import Nav from 'react-bootstrap/Nav';
import Navbar from 'react-bootstrap/Navbar';
import NavDropdown from 'react-bootstrap/NavDropdown';
import {Button, CloseButton} from 'react-bootstrap';

import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { library } from '@fortawesome/fontawesome-svg-core'
import { fab } from '@fortawesome/free-brands-svg-icons'
import { faMinus, faCheckSquare , faSpinner, faHome, faChalkboardTeacher, faChevronRight} from '@fortawesome/free-solid-svg-icons'
import { faSquare } from "@fortawesome/free-regular-svg-icons";

//--------------  서버데이터용 필수 -------------------------------
import { useQuery, useMutation} from 'react-query';
import { getData, postData, getDataPure } from '../../utils/async';
import { API, CONSTANTS } from '../../utils/constants';
import useStore, {useStoreAuth} from '../../utils/store';
//--------------// 서버데이터용 필수 -------------------------------


import { Dropdown,  Notification, useToaster  } from 'rsuite';
// icon
import {Exit} from '@rsuite/icons';


import userIcon from '../../images/icon_user.jpg'

import 'rsuite/dist/rsuite.min.css'; // or 'rsuite/dist/rsuite.min.css

// 현대 기아별로 css 변경 필요
// import '../../styles/theme_hd.css';

import 'ag-grid-community/styles/ag-grid.css';
import 'ag-grid-community/styles/ag-theme-alpine.css';

import '../../styles/common.css';
import '../../styles/style.css';

import MemberUpdate from '../Contents/Sys/Popup/MemberUpdate';

import UserInfoModify from '../Common/UserInfoModify'
import UserPwModify from '../Common/UserPwModify'

//공지사항 팝업
// import Notice from '../Common/Notice'

const Header = () => {
    const navigate = useNavigate();
    const toaster = useToaster();
    
    const {setMenu, coCd, grpCd, setCoCd, setToken, loginUrl, setQltyVehlCd } = useStore(); 

    // 메뉴목록 (userEeno는 서버에서)
    const menuList = useQuery([API.pgmMgmts], ()=> getData(API.pgmMgmts), {staleTime: 0, cacheTime: 0});

    //  사용자정보
    const usrmgmt = useQuery([API.usrmgmt], () => getData(API.usrmgmt));

    // 메뉴리스트 저장
    useEffect(() => {
        if(menuList.isSuccess){
            setMenu(menuList.data);
        }
    },[menuList.data]);


    // 시용자정보팝업
    const [show, setShow] = useState(false);

    // 수정팝업
    const [userInfoModifyPop, setUserInfoModifyPop] = useState(false);

    // 비번변경팝업
    const [userPwModifyPop, setUserPwModifyPop] = useState(false);

    // 공지사항팝업
    // const [noticePop, setNoticePop] = useState(true);

    const hideUserInfoModifyPop = () => {
        usrmgmt.refetch();
        setUserInfoModifyPop(false)
    }

    const logout = () => {
        window.location.href = 'http://localhost:3000' + (loginUrl ? loginUrl : '/errorPage');
    };


    // 회사코드에따른 css적용
    useEffect(() => {
        if(!coCd){
            navigate('/errorPage')
        }
        import (`../../styles/theme_${coCd === '01' ? 'hd' : 'kia'}.css`);
    },[coCd]);

    const title = coCd === '01' ? '현대자동차' : '기아자동차';

    //-------------------------- 어드민의 현재/기아 변경에 따른 ------------------------------------------------

    // 토큰재발행(어드민)
    const mutateChangeToken = useMutation(param => postData(API.changeToken, param, CONSTANTS.update),{
        onSuccess: res => {
            if(res){
                setToken(res.token);
                setCoCd(res.coCd); //
                setQltyVehlCd('ALL'); // keword 차종코드 초기화

                window.location.reload();
            }else{
                toaster.push(<Notification type='error' header='실패' closable >회사변경에 실패헸습니다.</Notification>);
            }
        }
    });

    //회사코드변경
    const onSelectCo = coCd => {
        mutateChangeToken.mutate({blnsCoCd: coCd})
    }

   
    //--------------------------// 어드민의 현재/기아 변경에 따른 ------------------------------------------------

    return (
        <>
        <div className="top-bg"></div>
            <div className="gnb-wrap">
                <Link className="logo" to="/totalStock">
                    <img className="comLogo" src={`../../images/${coCd === '01' ? 'hd' : 'kia'}_logo_wh.png`} alt=""></img>
                    <img className="sysLogo" src="../../images/logo_common.png" alt=""></img>
                </Link>
                
                <nav className="gnb" >
                    <ul className="main-menu" >
                        {menuList.isSuccess && menuList.data.filter(item => (item.menuId !== '9999' && item.pgmIdSn===0)).map((d,i) => (
                            <li key={i}> 
                                <Link to={d.pgmPathAdr}>
                                    {d.pgmNm}
                                </Link>
                                <ul className="sub-menu">
                                {menuList.data.filter(data =>data.pgmId === d.pgmId && data.pgmIdSn!==0).map((s,j) => (
                                    <li  key={j} >
                                        <Link to={s.pgmPathAdr}>{s.pgmNm}</Link>
                                    </li>
                                ))}
                                </ul>
                            </li>
                        ))}
                    </ul>
                </nav>
                            
                <div className="user-info">
                    <ul>
                        <li className="user-type">
                           {grpCd === CONSTANTS.grpCdSysAdm &&
                                <Dropdown title={title} onSelect={onSelectCo} >
                                    <Dropdown.Item eventKey="01">현대자동차</Dropdown.Item>
                                    <Dropdown.Item eventKey="02">기아자동차</Dropdown.Item>
                                </Dropdown> 
                            }
                            {grpCd !== CONSTANTS.grpCdSysAdm &&
                                <Dropdown title={title} disabled noCaret></Dropdown> 
                            }
                        </li>
                        {usrmgmt.isSuccess && usrmgmt.data && 
                        <li className="user-name">
                            <span onClick={()=>setShow(true)}>{usrmgmt.data.userNm}</span> 님
                            <div className={(show ? "user-detail-open" : "user-detail-close") + " user-detail"}>
                                <CloseButton onClick={()=> setShow(false)} />
                            
                                <div className="detail-top">
                                    <div className="detail-img"><img className="comLogo" src={userIcon}></img></div>
                                   
                                    <div className="detail-info">
                                        <ul>
                                            <li className="detail-user-type">{usrmgmt.data.coNm}</li>
                                            <li className="detail-user-name">{usrmgmt.data.userNm}</li>
                                            <li className="detail-user-ct">{usrmgmt.data.userEeno}</li>
                                        </ul>
                                    </div>
                                    
                                </div>
                                <div className="detail-btn-group">
                                    <Button variant="outline-secondary" size="sm" onClick={() => setUserInfoModifyPop(true)}>사용자 정보 수정</Button>
                                    <Button variant="outline-secondary" size="sm" onClick={() => setUserPwModifyPop(true)}>비밀번호 변경</Button>
                                </div>    
                            </div>
                        </li>
                        }   
                        <li>
                            {/* <Link to="#" onClick={logout} className="user-logout"><span></span>Logout</Link> */}
                            <Link to="#" onClick={logout} className="user-logout"><Exit style={{marginRight: '5px', fontSize: '2em'}} />Logout</Link>
                        </li>
                    </ul>
                </div>
                        
            </div>
            {userInfoModifyPop && <UserInfoModify show={userInfoModifyPop} data={usrmgmt.data} onHide={hideUserInfoModifyPop}/>}
            {userPwModifyPop && <UserPwModify show={userPwModifyPop} data={usrmgmt.data} onHide={()=> setUserPwModifyPop(false)}/>}


            {/* 공지사항 게시 상태인 경우 공지사항 팝업
             <Notice show={noticePop} onHide={()=> setNoticePop(false)}/> 
            */}
        </>
    );
};

export default Header;