import React from 'react';
import {Modal, Button, Table} from 'react-bootstrap';
import {Form, Checkbox} from 'rsuite';

const UserPwFind = ({show, onHide}) => {
    
    return (
        <>
            <Form>
                <Modal show={show} onHide={onHide} backdrop={false} keyboard={false} size="md" className="modal-custom modal-notice" style={{left:'0'}}>
                    <Modal.Header closeButton>
                        <Modal.Title>공지사항</Modal.Title>
                    </Modal.Header>
                    <Modal.Body>
                            <Form>
                                <Table className="tbl-hor" bordered>
                                    <colgroup>
                                        <col style={{width:'20%'}}></col>
                                        <col style={{width:''}}></col>
                                    </colgroup>
                                    <tbody>
                                        <tr>
                                            <th className="">제목</th>
                                            <td colSpan="3">공지사항입니다.</td>
                                        </tr>
                                        <tr>
                                            <th className="">내용</th>
                                            <td colSpan="3">공지사항 내용입니다.</td>
                                        </tr>
                                        <tr>
                                            <th>첨부파일</th>
                                            <td colSpan="3">
                                                
                                            </td>
                                        </tr>
                                    </tbody>
                                </Table>
                            </Form>
                    </Modal.Body>

                    <Modal.Footer>
                        <Checkbox value="" className="">하루동안 공지사항 띄우지 않음</Checkbox>
                        <Button variant="primary" size="md" onClick={onHide}>확인</Button>
                    </Modal.Footer>
                </Modal>
            </Form>
            
            {/* 공지사항이 여러개인 경우 2번째 modal부터 style left값 할당 
            2개인 경우 2번째 modal에 1번 modal 넓이값 +20px
            3개인 경우 3번째 modal에 1번 modal 넓이값 + 2번 modal 넓이값 + 40px */}

            {/* <Form>
                <Modal show={show} onHide={onHide} backdrop={false} keyboard={false} size="md" className="modal-custom modal-notice" style={{left:'520px'}}>
                    <Modal.Header closeButton>
                        <Modal.Title>공지사항</Modal.Title>
                    </Modal.Header>
                    <Modal.Body>
                            <Form>
                                <Table className="tbl-hor" bordered>
                                    <colgroup>
                                        <col style={{width:'20%'}}></col>
                                        <col style={{width:''}}></col>
                                    </colgroup>
                                    <tbody>
                                        <tr>
                                            <th className="">제목</th>
                                            <td colSpan="3">공지사항입니다.</td>
                                        </tr>
                                        <tr>
                                            <th className="">내용</th>
                                            <td colSpan="3">공지사항 내용입니다.</td>
                                        </tr>
                                        <tr>
                                            <th>첨부파일</th>
                                            <td colSpan="3">
                                                
                                            </td>
                                        </tr>
                                    </tbody>
                                </Table>
                            </Form>
                    </Modal.Body>

                    <Modal.Footer>
                        <Checkbox value="" className="">하루동안 공지사항 띄우지 않음</Checkbox>
                        <Button variant="primary" size="md" onClick={onHide}>확인</Button>
                    </Modal.Footer>
                </Modal>
            </Form> */}
        </>
    );

};
export default UserPwFind;