package com.oms.ivm.dao;

import java.util.List;

import com.oms.ivm.dto.PdiIvmReqDTO;
import com.oms.ivm.dto.PdiIvmResDTO;

/**
 * <pre>
 * PdiIvmDAO 인터페이스
 * </pre>
 *
 * @Class Name  : PdiIvmDAO.java
 * @Description : 재고관리 > PDI 재고관리 DAO
 * @author 김정웅
 * @since 2023.5.4
 * @see
*/
public interface PdiIvmDAO {
    //PDI재고관리 현황 (배송여부 -> ALL:전체, 01:배송중, 02:배송완료)
    List<PdiIvmResDTO> selectPdiIvmListAll(PdiIvmReqDTO reqDto)throws Exception;
    List<PdiIvmResDTO> selectPdiIvmList01(PdiIvmReqDTO reqDto)throws Exception;
    List<PdiIvmResDTO> selectPdiIvmList02(PdiIvmReqDTO reqDto)throws Exception;


}
