package com.oms.stm.dao;

import java.util.List;

import com.oms.stm.dto.LangMgmtReqDTO;
import com.oms.stm.dto.LangMgmtResDTO;
import com.oms.stm.dto.NatlMgmtReqDTO;
import com.oms.stm.dto.NatlMgmtResDTO;
import com.oms.stm.dto.StmComReqDTO;
import com.oms.sys.dto.CodeMgmtReqDTO;

/**
 * <pre>
 * NatlMgmt DAO 인터페이스
 * </pre>
 *
 * @Class Name  : NatlMgmtDAO.java
 * @Description :
 * @author 안경수
 * @since 2023.1.6
 * @see
*/
public interface NatlMgmtDAO {
    /**
     * Statements
     *
     * @param dto
     * @return
     */
    List<NatlMgmtResDTO> selectNatlCdMstList(StmComReqDTO dto);

    /**
     * Statements
     *
     * @param dto
     * @return
     */
    int insertNatlCdMst(NatlMgmtResDTO dto);

    /**
     * Statements
     *
     * @param dto
     * @return
     */
    int updateNatlCdMst(NatlMgmtResDTO dto);

    /**
     * Statements
     *
     * @param dto
     * @return
     */
    int deleteNatlCdMst(NatlMgmtResDTO dto);

    /**
     * Statements
     *
     * @param dto
     * @return
     */
    int updateNatlVehlMgmt(NatlMgmtReqDTO dto);

}
