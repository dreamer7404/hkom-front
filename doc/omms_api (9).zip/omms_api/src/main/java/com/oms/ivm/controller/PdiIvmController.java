package com.oms.ivm.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import able.cloud.core.web.HController;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.oms.cmm.utils.Utils;
import com.oms.ivm.dto.PdiIvmReqDTO;
import com.oms.ivm.dto.PdiIvmResDTO;
import com.oms.ivm.service.PdiIvmService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;


/**
 * <pre>
 * PdiIvmController
 * </pre>
 *
 * @ClassName   : PdiIvmController.java
 * @Description : 재고관리 > PDI재고관리 컨트롤러
 * @author 김정웅
 * @since 2023.5.4
 * @see
 */
@Tag(name = "PdiIvmController", description = "")
@RequiredArgsConstructor
@RestController
@RequestMapping("/api")
public class PdiIvmController extends HController {

    /**
     * 클래스 Injection
     */
    private final HttpServletRequest request;
    private final PdiIvmService pdiIvmService;

    /**
     * 재고관리 > PDI재고관리 > PDI재고관리 현황
     */
    @Operation(summary = "총재고관리 조회")
    @GetMapping("/ivmPdiIvInfos")
    public List<PdiIvmResDTO> selectPdiIvmList(@ModelAttribute PdiIvmReqDTO reqDto) throws Exception {
        //사용자 ID, 회사코드 할당
        reqDto.setUserEeno(Utils.getUserEeno(request));
        reqDto.setDlExpdCoCd(Utils.getDlExpdCoCd(request));
        List<PdiIvmResDTO> result = pdiIvmService.selectPdiIvmList(reqDto);
        return result;
    }


}