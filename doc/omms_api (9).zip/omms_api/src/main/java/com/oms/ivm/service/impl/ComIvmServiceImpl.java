package com.oms.ivm.service.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import able.cloud.core.service.HService;

import org.springframework.stereotype.Service;

import com.oms.ivm.dao.ComIvmDAO;
import com.oms.ivm.dto.ComIvmReqDTO;
import com.oms.ivm.dto.Ivm2WeekPlanReqDTO;
import com.oms.ivm.dto.Ivm2WeekPlanResDTO;
import com.oms.ivm.dto.Ivm3DayPlanReqDTO;
import com.oms.ivm.dto.Ivm3DayPlanResDTO;
import com.oms.ivm.dto.IvmPdiOrYongsanIvResDTO;
import com.oms.ivm.dto.IvmSewonIvResDTO;
import com.oms.ivm.dto.IvmThisMonTrwiResDTO;
import com.oms.ivm.service.ComIvmService;

import lombok.RequiredArgsConstructor;

/**
 * <pre>
 * ComIvmServiceImpl
 * </pre>
 *
 * @author 김정웅
 * @since 2023. 3. 13.
 * @see
 */
@RequiredArgsConstructor
@Service("comIvmService")
public class ComIvmServiceImpl extends HService implements ComIvmService {

    private final ComIvmDAO comIvmDAO;

    @Override
    public List<Ivm2WeekPlanResDTO> selectIvm2WeekPlanList(Ivm2WeekPlanReqDTO ivm2WeekPlanReqDTO) throws Exception {
        HashMap<String, String> getMsgPlanProd = comIvmDAO.getMsgPlanProd(ivm2WeekPlanReqDTO);
        ivm2WeekPlanReqDTO.setVSchYmd(getMsgPlanProd.get("V_PLN_FRAM_YMD").toString());

        List<Ivm2WeekPlanResDTO> result = new ArrayList<Ivm2WeekPlanResDTO>();
        result.addAll(comIvmDAO.selectIvm2WeekPlanList(ivm2WeekPlanReqDTO));
        result.addAll(comIvmDAO.selectIvm2WeekPlanListSummary(ivm2WeekPlanReqDTO));

        return result;
    }

    @Override
    public Ivm3DayPlanResDTO selectIvm3DayPrdnPlanList(Ivm3DayPlanReqDTO reqDto) throws Exception {
        Ivm3DayPlanResDTO result = new Ivm3DayPlanResDTO();

        Ivm3DayPlanReqDTO fuGetWrkdate = comIvmDAO.fuGetWrkdate(reqDto.getBDate());
        reqDto.setVWrkYmd(fuGetWrkdate.getVWrkYmd());

        Ivm3DayPlanReqDTO expdPacScnCd = comIvmDAO.selectExpdPacScnCd(reqDto);
        reqDto.setDlExpdPacScnCd(expdPacScnCd.getDlExpdPacScnCd());
        reqDto.setDlExpdPdiCd(expdPacScnCd.getDlExpdPdiCd());
        reqDto.setLangCd(expdPacScnCd.getLangCd());

        Ivm3DayPlanReqDTO todayPrdnPlan = comIvmDAO.selectIvmTodayPrdnPlanList(reqDto);

//        BigDecimal vTddPrdnPlanQty = BigDecimal.valueOf(Double.valueOf(todayPrdnPlan.getVTddPrdnPlanQty()));
//        BigDecimal vTddPrdnQty3 = BigDecimal.valueOf(Double.valueOf(todayPrdnPlan.getVTddPrdnQty3()));
//        BigDecimal vTddPrdnQty = BigDecimal.valueOf(Double.valueOf(todayPrdnPlan.getVTddPrdnQty()));
//        BigDecimal pPlanTotQty = vTddPrdnPlanQty.add(vTddPrdnQty3);

        int vTddPrdnPlanQty = todayPrdnPlan.getVTddPrdnPlanQty();
        int vTddPrdnQty3 = todayPrdnPlan.getVTddPrdnQty3();
        int vTddPrdnQty = todayPrdnPlan.getVTddPrdnQty();
        int planTotQty = vTddPrdnPlanQty + vTddPrdnQty3;
        result.setPlanTotQty(planTotQty);

        reqDto.setVTddPrdnPlanQty(vTddPrdnPlanQty);
        reqDto.setVTddPrdnQty3(vTddPrdnQty3);
        reqDto.setVTddPrdnQty(vTddPrdnQty);

//
//        vTddPrdnPlanQty
//        vTddPrdnQty
//        vTddPrdnQty3

        Ivm3DayPlanReqDTO vFramYmd = comIvmDAO.selectVFramYmd(reqDto);
        reqDto.setVFramYmd(vFramYmd.getVFramYmd());
        reqDto.setVLocalChar(vFramYmd.getVLocalChar());

        result = comIvmDAO.selectIvm3DayPrdnPlanList(reqDto);
        result.setVLocalChar(reqDto.getVLocalChar());

//        for(Ivm3DayPlanResDTO result : day3PrdnPlan) {
//            result.setPPlanTotQty(pPlanTotQty);
//            result.setIvm3DayPlanReqDTO(ivm3DayPlanReqDTO);
//            results.add(result);
//        }

//        day3PrdnPlan.forEach(result -> {
//            result.setPPlanTotQty(pPlanTotQty);
//            result.setIvm3DayPlanReqDTO(reqDto);
//            results.add(result);
//        });

        return result;
    }

    @Override
    public List<IvmThisMonTrwiResDTO> selectIvmThisMonTrwiList(ComIvmReqDTO reqDto) throws Exception {
        List<IvmThisMonTrwiResDTO> result = new ArrayList<IvmThisMonTrwiResDTO>();
        result = comIvmDAO.selectIvmThisMonTrwiList(reqDto);

        return result;
    }

    @Override
    public List<IvmSewonIvResDTO> selectIvmSewonIvList(ComIvmReqDTO reqDto) throws Exception {
        List<IvmSewonIvResDTO> result = new ArrayList<IvmSewonIvResDTO>();
        result = comIvmDAO.selectIvmSewonIvList(reqDto);
        return result;
    }

    @Override
    public List<IvmPdiOrYongsanIvResDTO> selectIvmPdiOrYongsanIvList(ComIvmReqDTO reqDto) throws Exception {
        List<IvmPdiOrYongsanIvResDTO> result = new ArrayList<IvmPdiOrYongsanIvResDTO>();
        result = comIvmDAO.selectIvmPdiOrYongsanIvList(reqDto);
        return result;
    }

    /*
     * @see com.oms.ivm.service.ComIvmService#getSysDate2()
     */
    @Override
    public HashMap<String, String> getSysDate2() throws Exception {
        return comIvmDAO.getSysDate2();
    }


}
