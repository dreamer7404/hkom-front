package com.oms.print.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import able.cloud.core.web.HController;


import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.oms.cmm.utils.Utils;
import com.oms.print.dto.PrintStateReqDTO;
import com.oms.print.dto.PrintStateResDTO;
import com.oms.print.service.PrintStateService;
import com.oms.stm.dto.BoardReqDTO;
import com.oms.stm.dto.BoardResDTO;
import com.oms.stm.dto.StmComReqDTO;
import com.oms.stm.service.BoardService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;


/**
 * <pre>
 * Statements
 * </pre>
 * @ClassName : PrintStateController.java
 * @Description :
 * @author 김경훈
 * @since 2023. 5. 3.
 * @see
 */
@Tag(name = "PrintStateController", description = "")
@RequiredArgsConstructor
@RestController
@RequestMapping("/api")
public class PrintStateController extends HController {


    private final PrintStateService printStateService;
    private final HttpServletRequest request;

    @Operation(summary = "발간현황조회")
    @GetMapping("/printStates")
    public  List<PrintStateResDTO>  printStates(@ModelAttribute PrintStateReqDTO dto) throws Exception {

        String userEeno = Utils.getUserEeno(request);
        dto.setUserEeno(userEeno);

        return printStateService.selectPrintStateList(dto);
    }


    @Operation(summary = "발간현황상세")
    @GetMapping("/printState")
    public  PrintStateResDTO  printState(@ModelAttribute PrintStateReqDTO dto) throws Exception {

        return printStateService.selectPrntFpInfo(dto);

    }



}