package com.oms.ivm.dto;

import java.sql.Timestamp;

import org.apache.ibatis.type.Alias;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @author 김정웅
 * @since 2023. 3. 17.
 * @see
 */

@Alias("ivmPdiOrYongsanIvResDTO")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class IvmPdiOrYongsanIvResDTO {

    private String gubun;               //PDI, 용산 구분
    private String clsYmd;
    private String pdiWhsnQty;
    private String expdWhsnStNm;
    private String pdiNormalWhot;
    private String pdiExtraWhot;
    private String pdiDisuseWhot;
    private String pdiReviceWhot;
    private String pdiIvQty;
    private String pdiIvText;

}
