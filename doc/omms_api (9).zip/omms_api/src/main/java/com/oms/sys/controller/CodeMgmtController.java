package com.oms.sys.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import able.cloud.core.web.HController;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.oms.cmm.global.Consts;
import com.oms.cmm.utils.Utils;
import com.oms.sys.dto.CodeMgmtReqDTO;
import com.oms.sys.dto.CodeMgmtResDTO;
import com.oms.sys.service.CodeMgmtService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;


/**
 * <pre>
 * CodeMgmt Controller
 * </pre>
 *
 * @ClassName   : CodeMgmtController.java
 * @Description :
 * @author 안경수
 * @since 2023.1.19
 * @see
 */
@Tag(name = "CodeMgmtController", description = "")
@RequiredArgsConstructor
@RestController
@RequestMapping("/api")
public class CodeMgmtController extends HController {

    /**
     * 클래스 Injection
     */
	private final CodeMgmtService codeMgmtService;
	private final HttpServletRequest request;


	/**
     * 코드 목록을 조회
     */
	@Operation(summary = "코드 목록을 조회")
    @GetMapping("/codeMgmts")
    public List<CodeMgmtResDTO> selectCodeMgmtList(@ModelAttribute CodeMgmtReqDTO codeMgmtReqDTO) throws Exception {
	    return codeMgmtService.selectCodeMgmtList(codeMgmtReqDTO);
    }

	/**
     * 코드정보 등록, 수정, 삭제
     */
    @Operation(summary = "코드정보 등록,수정,삭제", description = "")
    @Parameter(in = ParameterIn.HEADER, name="_method", schema=@Schema(type="string"))
    @PostMapping(value = "/codeMgmt")
    public Integer insertUsrMgmt(@RequestBody CodeMgmtReqDTO codeMgmtReqDTO) throws Exception {
        String method = Utils.getMethod(request);
        if(method.equals(Consts.INSERT)) {
            return codeMgmtService.insertCodeMgmt(codeMgmtReqDTO);
        }else if(method.equals(Consts.UPDATE)) {
            return codeMgmtService.updateCodeMgmt(codeMgmtReqDTO);
        }else if(method.equals(Consts.DELETE)) {
            return codeMgmtService.deleteCodeMgmt(codeMgmtReqDTO);
        }
        return 0;
    }



}