package com.oms.sys.dao;

import org.springframework.context.annotation.Bean;

import com.oms.sys.dto.UsrTokenReqDTO;
import com.oms.sys.dto.UsrTokenResDTO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @author 안경수
 * @since 2023. 4. 20.
 * @see
 */
public interface UsrTokenDAO {
    UsrTokenResDTO selectUsrToken(UsrTokenReqDTO usrTokenReqDTO) throws Exception;
    Integer insertUsrToken(UsrTokenReqDTO usrTokenReqDTO) throws Exception;
    Integer updateUsrToken(UsrTokenReqDTO usrTokenReqDTO) throws Exception;
}
