package com.oms.ivm.service.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import able.cloud.core.service.HService;

import org.springframework.stereotype.Service;

import com.oms.ivm.dao.PdiIvmDAO;
import com.oms.ivm.dao.SewIvmDAO;
import com.oms.ivm.dto.PdiIvmReqDTO;
import com.oms.ivm.dto.PdiIvmResDTO;
import com.oms.ivm.dto.SewonIvmResDTO;
import com.oms.ivm.service.PdiIvmService;

import lombok.RequiredArgsConstructor;

/**
 * <pre>
 * PdiIvmServiceImpl
 * </pre>
 *
 * @author 김정웅
 * @since 2023. 5. 4.
 * @see
 */
@RequiredArgsConstructor
@Service("pdiIvmService")
public class PdiIvmServiceImpl extends HService implements PdiIvmService {

    private final PdiIvmDAO pdiIvmDAO;
    private final SewIvmDAO sewIvmDAO;

    @Override
    public List<PdiIvmResDTO> selectPdiIvmList(PdiIvmReqDTO reqDto) throws Exception {
        String bDate = reqDto.getBDate();
        HashMap<String, String> validMdlMdy4 = sewIvmDAO.selectValidMdlMdy4(bDate);

        reqDto.setPFromMdlMdy(validMdlMdy4.get("P_FROM_MDL_MDY"));
        reqDto.setPToMdlMdy(validMdlMdy4.get("P_TO_MDL_MDY"));

        List<PdiIvmResDTO> result = new ArrayList<PdiIvmResDTO>();

        //배송여부:전체
        if("ALL".equals(reqDto.getDlvtState())) {
            result = pdiIvmDAO.selectPdiIvmListAll(reqDto);
        }
        //배송여부:배송중
        else if ("01".equals(reqDto.getDlvtState())) {
            result = pdiIvmDAO.selectPdiIvmList01(reqDto);
        }
        //배송여부:배송완료
        else if ("02".equals(reqDto.getDlvtState())) {
            result = pdiIvmDAO.selectPdiIvmList02(reqDto);
        }

        return result;
    }



}
