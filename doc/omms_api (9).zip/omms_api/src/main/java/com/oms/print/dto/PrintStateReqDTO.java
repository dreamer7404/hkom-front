package com.oms.print.dto;

import org.apache.ibatis.type.Alias;

import com.oms.common.dto.RcvrReqDTO;


import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;



/**
 * <pre>
 * Statements
 * </pre>
 * @ClassName : PrintStateReqDTO.java
 * @Description :
 * @author 김경훈
 * @since 2023. 5. 3.
 * @see
 */
@Alias("printStateReqDTO")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class PrintStateReqDTO extends PrintStateComDTO {


private String sDate;
private String eDate;
}


