package com.oms.stm.dto;

import org.apache.ibatis.type.Alias;

import lombok.AllArgsConstructor;
import lombok.Data;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @author 안경수
 * @since 2023. 5. 8.
 * @see
 */
@Alias("vehlCrgrMgmtSaveDTO")
@Data
@AllArgsConstructor
public class VehlCrgrMgmtSaveDTO {
    private String qltyVehlCd;
    private String mdlMdyCd;
    private String blnsCoCd;
    private String userEeno; // 해당차종 담당자
    private String pprrEeno;

}
