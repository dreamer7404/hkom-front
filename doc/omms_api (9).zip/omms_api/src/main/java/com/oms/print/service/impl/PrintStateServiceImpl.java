package com.oms.print.service.impl;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import able.cloud.core.service.HService;

import org.springframework.stereotype.Service;

import com.oms.print.dao.PrintStateDAO;
import com.oms.print.dto.PrintStateReqDTO;
import com.oms.print.dto.PrintStateResDTO;
import com.oms.print.service.PrintStateService;
import com.oms.stm.dao.BoardDAO;
import com.oms.stm.dto.BoardReqDTO;
import com.oms.stm.dto.BoardResDTO;
import com.oms.stm.service.BoardService;

import lombok.RequiredArgsConstructor;


/**
 * <pre>
 * Statements
 * </pre>
 * @ClassName : PrintStateServiceImpl.java
 * @Description :
 * @author 김경훈
 * @since 2023. 5. 3.
 * @see
 */
@RequiredArgsConstructor
@Service("PrintStateService")
public class PrintStateServiceImpl extends HService implements PrintStateService {

    private final PrintStateDAO printStateDao;

    /*
     * @see com.oms.print.service.PrintStateService#selectPrintStateList(com.oms.print.dto.PrintStateReqDTO)
     */
    @Override
    public List<PrintStateResDTO> selectPrintStateList(PrintStateReqDTO dto) {
        // TODO Auto-generated method stub
        return printStateDao.selectPrintStateList(dto);
    }

    /*
     * @see com.oms.print.service.PrintStateService#selectPrntFpInfo(com.oms.print.dto.PrintStateReqDTO)
     */
    @Override
    public PrintStateResDTO selectPrntFpInfo(PrintStateReqDTO dto) {
        // TODO Auto-generated method stub
        return printStateDao.selectPrntFpInfo(dto);
    }

}





