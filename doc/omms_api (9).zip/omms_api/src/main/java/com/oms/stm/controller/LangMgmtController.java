package com.oms.stm.controller;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import able.cloud.core.web.HController;

import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.oms.cmm.global.Consts;
import com.oms.cmm.utils.Utils;
import com.oms.common.dto.CommReqDTO;
import com.oms.common.service.CommService;
import com.oms.stm.dto.LangMgmtReqDTO;
import com.oms.stm.dto.LangMgmtResDTO;
import com.oms.stm.dto.StmComReqDTO;
import com.oms.stm.service.LangMgmtService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;



/**
 * <pre>
 * Statements
 * </pre>
 * @ClassName : LangMgmtController.java
 * @Description :
 * @author 김경훈
 * @since 2023. 3. 23.
 * @see
 */
@Tag(name = "LanglMgmtController", description = "")
@RequiredArgsConstructor
@RestController
@RequestMapping("/api")
public class LangMgmtController extends HController {

    /**
     * 클래스 Injection
     */
    private final HttpServletRequest request;
	private final LangMgmtService langMgmtService;
	private final CommService commService;

	// mst화면에서 조회 누를때
	@Operation(summary = "언어코드조회")
	@GetMapping("/langMgmts")
	public List<LangMgmtResDTO> selectLangMgmtList(@ModelAttribute StmComReqDTO dto, HttpServletRequest request) throws Exception {


            LangMgmtResDTO resDto = new LangMgmtResDTO();
            CommReqDTO comDto = new CommReqDTO();


	        dto.setUserEeno(Utils.getUserEeno(request));

	        List<LangMgmtResDTO> langMgmtList = langMgmtService.selectLangList(dto);
	        List<LangMgmtResDTO> dlExpdRegnCdList = commService.selectDlExpdRegnCdList(dto);
            List<LangMgmtResDTO> langCdList = commService.selectLangCdList(dto);
            List<LangMgmtResDTO> vehlList = commService.selectQltyVehlCdList(dto);

	        resDto.setLangMgmtList(langMgmtList);
//	        resDto.setDlExpdRegnCdList(dlExpdRegnCdList);
//	        resDto.setLangCdList(langCdList);
//	        resDto.setVehlList(vehlList);

//	            mv.addObject("expdPdiNm", request.getParameter("expdPdiNm"));
//	            mv.addObject("qltyVehlCd", request.getParameter("qltyVehlCd"));
//	            mv.addObject("sMy", request.getParameter("sMy"));
//	            mv.addObject("dlExpdRegnCd", request.getParameter("dlExpdRegnCd"));
//	            mv.addObject("langCd", request.getParameter("langCd"));
//
//	            mv.addObject("userNm", userNm);
	        return langMgmtList;
	    }

//master화면에서 추가버튼 누를 때
	@Operation(summary = "언어코드 추가 모달")
    @GetMapping("/langMgmtsModal")
    public LangMgmtResDTO langAddModal(@ModelAttribute StmComReqDTO dto) throws Exception {
	    LangMgmtResDTO resDto = new LangMgmtResDTO();
        CommReqDTO comDto = new CommReqDTO();

        dto.setUserEeno(Utils.getUserEeno(request));
        String chkVal = request.getParameter("chkVal");

        if(!"N".equals(chkVal)){
        String[] arr = chkVal.split(",");

        dto.setDataSn(arr[0]);
        dto.setQltyVehlCd(arr[1]);
        dto.setMdlMdyCd(arr[2]);


        resDto.setQltyVehlCd(dto.getQltyVehlCd());
        resDto.setMdlMdyCd(dto.getMdlMdyCd());

//            mv.addObject("qltyVehlCd", arr[1]);
//            mv.addObject("mdlMdyCd", arr[2]);

        List<LangMgmtResDTO> vehlLangCdList = langMgmtService.selectVehlLangRegList(dto);
            resDto.setVehlLangCdList(vehlLangCdList);
        }

        List<LangMgmtResDTO> dlExpdRegnCdList = commService.selectDlExpdRegnCdList(dto);
        List<LangMgmtResDTO> vehlList = commService.selectQltyVehlCdList(dto);
        List<LangMgmtResDTO> langCdList = langMgmtService.selectLangMstList(dto);
        List<LangMgmtResDTO> totVehlList = langMgmtService.selectTotVehlCdList(dto);
            resDto.setDlExpdRegnCdList(dlExpdRegnCdList);
            resDto.setVehlList(vehlList);
            resDto.setLangCdList(langCdList);
            resDto.setTotVehlList(totVehlList);
        return resDto;
    }


//mst -> 추가 -> 차종복사 체크할 경우
	@Operation(summary = "차종코드 복사목록")
    @GetMapping("/langMgmtsCopy")
	 public LangMgmtResDTO selectVehlLangCopyList(StmComReqDTO dto) throws Exception {
	    LangMgmtResDTO resDto = new LangMgmtResDTO();
        CommReqDTO comDto = new CommReqDTO();

        dto.setUserEeno(Utils.getUserEeno(request));
	        List<LangMgmtResDTO> langCdList = langMgmtService.selectLangMstList(dto);//국가언어코드
	        resDto.setLangCdList(langCdList);
	        List<LangMgmtResDTO> vehlList = langMgmtService.selectVehlLangCpList(dto); //언어코드가 있는 차종코드 목록
	        resDto.setVehlList(vehlList);
	        return resDto;
	    }

	@Operation(summary = "언어마스터 목록")
    @GetMapping("/langMsts")
     public List<LangMgmtResDTO> selectLangMstList(StmComReqDTO dto) throws Exception {
        LangMgmtResDTO resDto = new LangMgmtResDTO();


            dto.setUserEeno(Utils.getUserEeno(request));
            List<LangMgmtResDTO> langMstList = langMgmtService.selectLangMstList(dto);//국가언어코드
            resDto.setLangMstList(langMstList);
//            List<LangMgmtResDTO> dlExpdRegnCdList = commService.selectDlExpdRegnCdList(dto); //쿼리확인필요
//            resDto.setVehlList(dlExpdRegnCdList);
            return langMstList;
        }


	@Operation(summary = "언어마스터 등록")
    @PostMapping("/langMst")
     public Integer langMst(LangMgmtReqDTO dto) throws Exception {

            int result = 0;
            String method = Utils.getMethod(request);
            dto.setUserId(Utils.getUserEeno(request));
            String validChk = langMgmtService.LangMstValidChk(dto);
            if(method.equals(Consts.INSERT)) {
                if("Y".equals(validChk)){
                    langMgmtService.insertLangMst(dto);
                    result = 1;
                }else {
                    result = 2;
                }
            }
            else if (method.equals(Consts.UPDATE)) {
                langMgmtService.updateLangMst(dto);
            }
            else if (method.equals(Consts.DELETE)) {
                langMgmtService.deleteLangMst(dto);
            }
            return result;
        }

	  @Operation(summary = "언어코드저장")
	  @Parameter(in = ParameterIn.HEADER, name="_method", schema=@Schema(type="string"))
	    @PostMapping("/langMgmt")
	    public Integer langMgmt(LangMgmtReqDTO dto) throws Exception {
	      int result =0;
	      String method = Utils.getMethod(request);
	      dto.setPprrEeno(Utils.getUserEeno(request));
	      List<String> itemList = new ArrayList<String>();
	      if(method.equals(Consts.INSERT)) {
    	      if(dto.getMultiGbn()!="one") {


    	          langMgmtService.deleteLangCdList(dto);
    	          String chkVal = dto.getChkVal();
    	          String[] resultItem = chkVal.split(",,");
    	          itemList = Arrays.asList(resultItem);
    	            dto.setItemList(itemList);
    	            langMgmtService.insertLangCdMgmt(dto);
    	            return result;
    	      }else {
    	          String langChk = langMgmtService.getLangMgmtChk(dto);
    	          if("Y".equals(langChk)) {
    	              langMgmtService.insertLangCdOne(dto);
    	          }
    	          return result;
    	      }
	      } else if (method.equals(Consts.UPDATE)) {
	          langMgmtService.updateLangCdMgmt(dto);
	          return result;
	      }else if (method.equals(Consts.DELETE)) {
	          String chkVal = dto.getChkVal();
	          String[] resultItem = chkVal.split(",,");//체크된 그리드 리스트 //dataSn필요
	          itemList = Arrays.asList(resultItem);
              dto.setItemList(itemList);
              langMgmtService.deleteLangCdMgmt(dto);
	          return result;
	      }



	      return result;
	    }





}