package com.oms.stm.service;

import java.util.List;

import com.oms.stm.dto.LangMgmtReqDTO;
import com.oms.stm.dto.LangMgmtResDTO;
import com.oms.stm.dto.StmComReqDTO;




/**
 * <pre>
 * Statements
 * </pre>
 * @ClassName : LangMgmtService.java
 * @Description :
 * @author 김경훈
 * @since 2023. 3. 23.
 * @see
 */
public interface LangMgmtService {

    /**
     * Statements
     *
     * @param dto
     * @return
     */
    List<LangMgmtResDTO> selectLangList(StmComReqDTO dto);

    /**
     * Statements
     *
     * @param dto
     * @return
     */
    List<LangMgmtResDTO> selectVehlLangRegList(StmComReqDTO dto);

    /**
     * Statements
     *
     * @param dto
     * @return
     */
    List<LangMgmtResDTO> selectLangMstList(StmComReqDTO dto);

    /**
     * Statements
     *
     * @param dto
     * @return
     */
    List<LangMgmtResDTO> selectTotVehlCdList(StmComReqDTO dto);

    /**
     * Statements
     *
     * @param dto
     * @return
     */
    List<LangMgmtResDTO> selectVehlLangCpList(StmComReqDTO dto);

    /**
     * Statements
     *
     * @param dto
     * @return
     */
    String LangMstValidChk(LangMgmtReqDTO dto);

    /**
     * Statements
     *
     * @param dto
     */
    void insertLangMst(LangMgmtReqDTO dto);

    /**
     * Statements
     *
     * @param dto
     */
    void updateLangMst(LangMgmtReqDTO dto);

    /**
     * Statements
     *
     * @param dto
     */
    void deleteLangMst(LangMgmtReqDTO dto);


    /**
     * Statements
     *
     * @param dto
     */
    void deleteLangCdList(LangMgmtReqDTO dto);

    void insertLangCdMgmt(LangMgmtReqDTO dto);

    /**
     * Statements
     *
     * @param dto
     * @return
     */
    String getLangMgmtChk(LangMgmtReqDTO dto);

    /**
     * Statements
     *
     * @param dto
     */
    void insertLangCdOne(LangMgmtReqDTO dto);

      /**
     * Statements
     *
     * @param dto
     */
    void updateLangCdMgmt(LangMgmtReqDTO dto);  /**

     * Statements
     *
     * @param dto
     */
    void deleteLangCdMgmt(LangMgmtReqDTO dto);


}
