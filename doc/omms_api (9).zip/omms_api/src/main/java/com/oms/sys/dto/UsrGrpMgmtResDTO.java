package com.oms.sys.dto;

import java.sql.Timestamp;

import org.apache.ibatis.type.Alias;

import lombok.AllArgsConstructor;
import lombok.Data;

/**
 * <pre>
 * 사용자 그룹정보
 * </pre>
 *
 * @author 안경수
 * @since 2023. 4. 18.
 * @see UsrGrpMgmtDAO UsrGrpMgmtService UsrGrpMgmtController
 */
@Alias("usrGrpMgmtResDTO")
@Data
public class UsrGrpMgmtResDTO {
    private String grpCd;
    private String grpNm;
    private Integer sortSn;
    private String useYn;
    private String rem;

    private Integer cnt;
}
