package com.oms.common.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.oms.cmm.utils.Utils;
import com.oms.common.dto.ComboReqDTO;
import com.oms.common.dto.PdiComboResDTO;
import com.oms.common.dto.VehlComboResDTO;
import com.oms.common.service.ComboService;
import com.oms.common.service.CommComboService;
import com.oms.common.service.CommService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;


/**
 * <pre>
 * Statements
 * </pre>
 * @ClassName : CommController.java
 * @Description :
 * @author 김경훈
 * @since 2023. 3. 22.
 * @see
 */
@Tag(name = "CommonController", description = "")
@CrossOrigin(origins="*")
@RequiredArgsConstructor
@RestController
@RequestMapping("/api")
public class CommController {

    private final CommService commService;






}
