package com.oms.sys.dao;

import com.oms.sys.dto.UsrMgmtReqDTO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @author Windows ≫c¿eAU
 * @since 2023. 3. 13.
 * @see
 */

public interface TestDAO {
    String testBatch() throws Exception;
}
