package com.oms.ivm.dao;

import java.util.HashMap;
import java.util.List;

import com.oms.ivm.dto.ComIvmReqDTO;
import com.oms.ivm.dto.Ivm2WeekPlanReqDTO;
import com.oms.ivm.dto.Ivm2WeekPlanResDTO;
import com.oms.ivm.dto.Ivm3DayPlanReqDTO;
import com.oms.ivm.dto.Ivm3DayPlanResDTO;
import com.oms.ivm.dto.IvmPdiOrYongsanIvResDTO;
import com.oms.ivm.dto.IvmSewonIvReqDTO;
import com.oms.ivm.dto.IvmSewonIvResDTO;
import com.oms.ivm.dto.IvmThisMonTrwiReqDTO;
import com.oms.ivm.dto.IvmThisMonTrwiResDTO;

/**
 * <pre>
 * ComIvmDAO 인터페이스
 * </pre>
 *
 * @Class Name  : ComIvmDAO.java
 * @Description : 재고관리 > 공통 DAO
 * @author 김정웅
 * @since 2023.3.13
 * @see
*/
public interface ComIvmDAO {

    //2주 생산계획
    List<Ivm2WeekPlanResDTO> selectIvm2WeekPlanList(Ivm2WeekPlanReqDTO ivm2WeekPlanReqDTO) throws Exception;
    List<Ivm2WeekPlanResDTO> selectIvm2WeekPlanListSummary(Ivm2WeekPlanReqDTO ivm2WeekPlanReqDTO) throws Exception;

    //3일 단기계획
    Ivm3DayPlanReqDTO fuGetWrkdate(String sdate) throws Exception;
    Ivm3DayPlanReqDTO selectExpdPacScnCd(String sdate) throws Exception;
    Ivm3DayPlanReqDTO selectIvmTodayPrdnPlanList(Ivm3DayPlanReqDTO ivm3DayPlanReqDTO) throws Exception;
    Ivm3DayPlanReqDTO selectVFramYmd(Ivm3DayPlanReqDTO ivm3DayPlanReqDTO) throws Exception;

    List<Ivm3DayPlanResDTO> selectIvm3DayPrdnPlanList(Ivm3DayPlanReqDTO todayPrdnPlan) throws Exception;

    //당월투입(누적)
    List<IvmThisMonTrwiResDTO> selectIvmThisMonTrwiList(IvmThisMonTrwiReqDTO ivmThisMonTrwiReqDTO);

    //세원보유재고
    List<IvmSewonIvResDTO> selectIvmSewonIvList(IvmSewonIvReqDTO ivmSewonIvReqDTO);

    //PDI/용산재고
    List<IvmPdiOrYongsanIvResDTO> selectIvmPdiOrYongsanIvList(ComIvmReqDTO comIvmReqDTO) ;

    HashMap<String,String> getSysDate2();


}
