package com.oms.ivm.dto;

import org.apache.ibatis.type.Alias;

import com.oms.common.dto.CommReqDTO;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @author 김정웅
 * @since 2023. 3. 15.
 * @see
 */
@Alias("ivm3DayPlanReqDTO")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Ivm3DayPlanReqDTO extends CommReqDTO {

    private String userId;
    private String vehlcd;
    private String key;
    private String sdate;
    private String language;
    private String year;
    private String region;

    private String vWrkYmd;

    private String vFramYmd;
    private String vLocalChar;

    private int vTddPrdnPlanQty;
    private int vTddPrdnQty3;
    private int vTddPrdnQty;

    private String vPacScnCd;
    private String vPdiCd;
    private String vLangCd;


}
