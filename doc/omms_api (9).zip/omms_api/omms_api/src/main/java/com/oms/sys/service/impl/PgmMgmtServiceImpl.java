package com.oms.sys.service.impl;

import java.util.List;

import able.cloud.core.service.HService;

import org.springframework.stereotype.Service;

import com.oms.common.dto.CommReqDTO;
import com.oms.sys.dao.PgmMgmtDAO;
import com.oms.sys.dto.PgmMgmtResDTO;
import com.oms.sys.service.PgmMgmtService;

import lombok.RequiredArgsConstructor;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @author 안경수
 * @since 2023. 2. 24.
 * @see
 */

@RequiredArgsConstructor
@Service("pgmMgmtService")
public class PgmMgmtServiceImpl extends HService implements PgmMgmtService {

    private final PgmMgmtDAO pgmMgmtDAO;

    @Override
    public List<PgmMgmtResDTO> selectPgmMgmtList(CommReqDTO commReqDTO) throws Exception {
        return pgmMgmtDAO.selectPgmMgmtList(commReqDTO);
    }


}
