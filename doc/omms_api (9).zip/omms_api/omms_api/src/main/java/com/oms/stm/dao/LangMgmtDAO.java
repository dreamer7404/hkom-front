package com.oms.stm.dao;

import java.util.List;

import com.oms.stm.dto.CodeMgmtReqDTO;
import com.oms.stm.dto.LangMgmtResDTO;
import com.oms.stm.dto.NatlMgmtReqDTO;
import com.oms.stm.dto.NatlMgmtResDTO;
import com.oms.stm.dto.StmComReqDTO;


/**
 * <pre>
 * Statements
 * </pre>
 * @ClassName : LangMgmtDAO.java
 * @Description :
 * @author 김경훈
 * @since 2023. 3. 23.
 * @see
 */
public interface LangMgmtDAO {

    /**
     * Statements
     *
     * @param dto
     * @return
     */
    List<LangMgmtResDTO> selectLangList(StmComReqDTO dto);
}
