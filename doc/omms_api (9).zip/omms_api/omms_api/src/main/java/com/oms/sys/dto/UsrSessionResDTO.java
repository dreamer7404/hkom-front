package com.oms.sys.dto;

import java.sql.Timestamp;

import org.apache.ibatis.type.Alias;

import lombok.AllArgsConstructor;
import lombok.Data;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @author Windows ≫c¿eAU
 * @since 2023. 2. 24.
 * @see
 */
@Alias("usrSessionResDTO")
@Data
@AllArgsConstructor
public class UsrSessionResDTO {
    private String userEeno;
    private String remoteIp;
    private Long accessDtm;
    private String refreshToken;
    private Timestamp mdfyDtm;
}
