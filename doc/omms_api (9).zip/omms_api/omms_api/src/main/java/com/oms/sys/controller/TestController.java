package com.oms.sys.controller;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.oms.sys.dto.TestIvmTotalReqDTO;
import com.oms.sys.service.TestService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @author Windows ≫c¿eAU
 * @since 2023. 3. 13.
 * @see
 */
@Tag(name = "TestController", description = "")
@CrossOrigin(origins="*")
@RequiredArgsConstructor
@RestController
@RequestMapping("/api")
public class TestController {

    private final TestService testService;

    @Operation(summary = "배치테스트")
    @GetMapping(value = "/testBatch")
    public String testBatch() throws Exception {
        return testService.testBatch();
    }


    @Operation(summary = "TEST 총재고관리 조회")
    @GetMapping(value = "/testIvmTotal")
    public String testIvmTotal(@ModelAttribute TestIvmTotalReqDTO testIvmTotalReqDTO) throws Exception {
        return "ok";
    }

}
