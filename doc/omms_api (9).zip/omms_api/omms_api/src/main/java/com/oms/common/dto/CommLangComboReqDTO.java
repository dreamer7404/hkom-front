package com.oms.common.dto;

import org.apache.ibatis.type.Alias;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;



/**
 * <pre>
 * Statements
 * </pre>
 * @ClassName : CommLangComboReqDTO.java
 * @Description : 언어코드 공통 호출 DTO
 * @author 김정웅
 * @since 2023. 3. 21.
 * @see
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Alias("commLangComboReqDTO")
public class CommLangComboReqDTO {
    private String userId;
    private String vehl;
    private String sdate;
    private String pdi;
    private String year;
    private String region;

//    private String menuId;
//    private String edate;
//    private String vehlCode;
//    private String language;
//    private String message;
//    private String rs;
//    private String pFromMdlMdy;
//    private String pToMdlMdy;
}
