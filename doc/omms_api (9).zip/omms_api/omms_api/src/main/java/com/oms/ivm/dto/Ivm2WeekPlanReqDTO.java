package com.oms.ivm.dto;

import org.apache.ibatis.type.Alias;

import com.oms.common.dto.CommReqDTO;

import lombok.AllArgsConstructor;
import lombok.Data;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @author 김정웅
 * @since 2023. 3. 7.
 * @see
 */
@Alias("ivm2WeekPlanReqDTO")
@Data
@AllArgsConstructor
public class Ivm2WeekPlanReqDTO extends ComIvmReqDTO {

//    private String userId;
//    private String vehlcd;
//    private String key;
//    private String sdate;
//    private String language;
//    private String year;
//    private String region;
    private String vSchYmd;
}
