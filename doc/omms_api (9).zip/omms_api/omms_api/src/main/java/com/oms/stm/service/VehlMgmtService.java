package com.oms.stm.service;

import java.util.List;


import com.oms.stm.dto.NatlMgmtReqDTO;
import com.oms.stm.dto.NatlMgmtResDTO;
import com.oms.stm.dto.StmComReqDTO;
import com.oms.stm.dto.VehlMgmtReqDTO;
import com.oms.stm.dto.VehlMgmtResDTO;



/**
 * <pre>
 * Statements
 * </pre>
 * @ClassName : VehlMgmtService.java
 * @Description :
 * @author 김경훈
 * @since 2023. 3. 13.
 * @see
 */
public interface VehlMgmtService {

    /**
     * Statements
     *
     * @param vehlReqDTO
     * @return
     */
    List<VehlMgmtResDTO> selectVehlMgmtList(StmComReqDTO dto);

    /**
     * Statements
     *
     * @param vehlReqDTO
     * @return
     */
    List<VehlMgmtResDTO> selectCpyTgVehl(StmComReqDTO dto);

    /**
     * Statements
     *
     * @param vehlReqDTO
     * @return
     */
    String selectNatlVehlChk(VehlMgmtReqDTO vehlReqDTO);

    /**
     * Statements
     *
     * @param vehlReqDTO
     */
    void insertNatlVehlMgmt(VehlMgmtReqDTO vehlReqDTO);

    /**
     * Statements
     *
     * @param vehlReqDTO
     */
    void deleteVehlLangCp(VehlMgmtReqDTO vehlReqDTO);

    /**
     * Statements
     *
     * @param vehlReqDTO
     */
    void insertVehlLangCopy(VehlMgmtReqDTO vehlReqDTO);

    /**
     * Statements
     *
     * @param vehlReqDTO
     */
    void deleteVehlNatlLang(VehlMgmtReqDTO vehlReqDTO);

    /**
     * Statements
     *
     * @param vehlReqDTO
     */
    void insertVehlNatlLangCpy(VehlMgmtReqDTO vehlReqDTO);

    /**
     * Statements
     *
     * @param vehlReqDTO
     * @return
     */
    List<VehlMgmtResDTO> selectCpyTgNatlVehl(VehlMgmtReqDTO vehlReqDTO);

    /**
     * Statements
     *
     * @param vehlReqDTO
     * @return
     */
    List<VehlMgmtResDTO> selectVehlMgmtNatlLangList(StmComReqDTO dto);

    /**
     *
     * Statements
     *
     * @param vehlReqDTO
     */
    void deleteVehlMgmtCrgr(VehlMgmtReqDTO vehlReqDTO);

    /**
     * Statements
     *
     * @param vehlReqDTO
     */
    void insertVehlMgmtCrgr(VehlMgmtReqDTO vehlReqDTO);

    /**
     * Statements
     *
     * @param vehlReqDTO
     */
    void deleteVehlMgmtRegnRelCd(VehlMgmtReqDTO vehlReqDTO);

    /**
     * Statements
     *
     * @param vehlReqDTO
     */
    void deleteVehlDlExpdMdyMgmt(VehlMgmtReqDTO vehlReqDTO);

    /**
     * Statements
     *
     * @param vehlReqDTO
     */
    void insertVehlMgmtRegnRelCd(VehlMgmtReqDTO vehlReqDTO);

    /**
     * Statements
     *
     * @param vehlReqDTO
     */
    void insertVehlDlExpdMdyMgmt(VehlMgmtReqDTO vehlReqDTO);

    /**
     * Statements
     *
     * @param vehlReqDTO
     */
    void deleteVehlMgmtAltn(VehlMgmtReqDTO vehlReqDTO);

    /**
     * Statements
     *
     * @param vehlReqDTO
     */
    void insertVehlMgmtAltn(VehlMgmtReqDTO vehlReqDTO);

    /**
     * Statements
     *
     * @param vehlReqDTO
     */
    void deleteNatlVehlLang(VehlMgmtReqDTO vehlReqDTO);

    /**
     * Statements
     *
     * @param vehlReqDTO
     */
    void insertNatlVehlLang(VehlMgmtReqDTO vehlReqDTO);

    /**
     * Statements
     *
     * @param vehlReqDTO
     */
    void updateVehlMgmtMain(VehlMgmtReqDTO vehlReqDTO);

    /**
     * Statements
     *
     * @param vo
     * @return
     */
    List<VehlMgmtReqDTO> selectDlExpdMdyPreList(VehlMgmtReqDTO vo);

    /**
     * Statements
     *
     * @param hmap
     * @return
     */
    List<VehlMgmtReqDTO> selectDlExpdMdyNextList(VehlMgmtReqDTO vo);

    /**
     * Statements
     *
     * @param hmap
     * @return
     */
    List<VehlMgmtReqDTO> selectVehlLangList(VehlMgmtReqDTO vo);

    /**
     * Statements
     *
     * @param vo
     */
    void deleteVehlLang(VehlMgmtReqDTO vo);

    /**
     * Statements
     *
     * @param vo
     */
    void insertVehlLangInfo(VehlMgmtReqDTO vo);

    /**
     * Statements
     *
     * @param vehlReqDTO
     * @return
     */
    String selectVehlMgmtCnt(VehlMgmtReqDTO vehlReqDTO);

    /**
     * Statements
     *
     * @param vehlReqDTO
     */
    void insertVehlMgmtMain(VehlMgmtReqDTO vehlReqDTO);

    /**
     * Statements
     *
     * @param vehlReqDTO
     * @return
     */
    List<VehlMgmtResDTO> selectPreVehlMdyChk(VehlMgmtReqDTO vehlReqDTO);

    /**
     * Statements
     *
     * @param reqDto
     * @return
     */
    List<VehlMgmtReqDTO> selectMdyMonth(StmComReqDTO dto);

    /**
     * Statements
     *
     * @param vehlReqDTO
     * @return
     */
    List<VehlMgmtResDTO> getVehlCombo(StmComReqDTO dto);

    /**
     * Statements
     *
     * @param vehlReqDTO
     * @return
     */
    List<VehlMgmtResDTO> getPdiCombo(StmComReqDTO vehlReqDTO);





}
