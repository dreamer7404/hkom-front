package com.oms.common.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import able.cloud.core.web.HController;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.oms.common.dto.CommLangComboReqDTO;
import com.oms.common.dto.CommLangComboResDTO;
import com.oms.common.service.CommComboService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;


/**
 * <pre>
 * ComIvmController
 * </pre>
 *
 * @ClassName   : CommComboController.java
 * @Description : 공통 콤보 컨트롤러
 * @author 김정웅
 * @since 2023.3.21
 * @see
 */
@Tag(name = "CommComboController", description = "")
@CrossOrigin(origins="*")
@RequiredArgsConstructor
@RestController
@RequestMapping("/api")
public class CommComboController extends HController {

    /**
     * 클래스 Injection
     */
    private final HttpServletRequest request;
    private final CommComboService commComboService;

    /**
     * LangCombo 컨트롤러
     */
    @Operation(summary = "언어코드 목록 조회")
    @GetMapping("/commLangCombos")
    public List<CommLangComboResDTO> selectCommLangComboList(@ModelAttribute CommLangComboReqDTO commLangComboReqDTO) throws Exception {
        List<CommLangComboResDTO> result = new ArrayList<CommLangComboResDTO>();
        result = commComboService.selectCommLangComboList(commLangComboReqDTO);
        return result;
    }

}