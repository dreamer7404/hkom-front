package com.oms.ivm.service.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import able.cloud.core.service.HService;

import org.springframework.stereotype.Service;

import com.oms.common.dao.CommComboDAO;
import com.oms.common.dto.CommLangComboReqDTO;
import com.oms.common.dto.CommLangComboResDTO;
import com.oms.ivm.dao.ComIvmDAO;
import com.oms.ivm.dao.TotIvmDAO;
import com.oms.ivm.dto.ComIvmReqDTO;
import com.oms.ivm.dto.IvmMonthOrdPrdReqDTO;
import com.oms.ivm.dto.IvmMonthOrdPrdResDTO;
import com.oms.ivm.dto.IvmNatlProdPlanResDTO;
import com.oms.ivm.dto.IvmVehlIvResDTO;
import com.oms.ivm.dto.TotIvmReqDTO;
import com.oms.ivm.dto.TotIvmRequestReqDTO;
import com.oms.ivm.dto.TotIvmResDTO;
import com.oms.ivm.model.TbWrkDateMgmt;
import com.oms.ivm.service.TotIvmService;

import lombok.RequiredArgsConstructor;

/**
 * <pre>
 * totalStockService
 * </pre>
 *
 * @author 김정웅
 * @since 2023. 3. 7.
 * @see
 */
@RequiredArgsConstructor
@Service("totIvmService")
public class TotIvmServiceImpl extends HService implements TotIvmService {

    private final TotIvmDAO totIvmDAO;
    private final ComIvmDAO comIvmDAO;
    private final CommComboDAO commComboDAO;


    @Override
    public List<TotIvmResDTO> selectTotalIvmList(TotIvmReqDTO totIvmReqDTO) throws Exception {
        List<TotIvmResDTO> result = totIvmDAO.selectTotalIvmList(totIvmReqDTO);
        return result;
    }

    @Override
    public Integer intsertTotalRequest(List<TotIvmRequestReqDTO> totIvmRequestReqDTO) throws Exception {
        int result = 0;
        for (TotIvmRequestReqDTO param : totIvmRequestReqDTO) {
            //세원 선택시 품질차종코드는 '05'로  설정
            if("sewon".equals(param.getRadioType())) {
                param.setPExpdRqScnCd("05");
            }
            //PDI/용산 선택시 언어에따라 품질차종코드를 구분해준다.
            else {
                if("KO".equals(param.getLangCd())) {
                    param.setPExpdRqScnCd("04");
                } else {
                    param.setPExpdRqScnCd("04");
                }
            }
            result = totIvmDAO.intsertTotalRequest(param);
        }

        return result;
    }

    @Override
    public List<IvmMonthOrdPrdResDTO> selectMonthOrdPrdList(IvmMonthOrdPrdReqDTO ivmMonthOrdPrdReqDTO) throws Exception {

//        CommLangComboReqDTO langReqDto = new CommLangComboReqDTO();
//        langReqDto.setUserId(ivmMonthOrdPrdReqDTO.getUserId());
//        langReqDto.setVehl(ivmMonthOrdPrdReqDTO.getVehl());
//        langReqDto.setPdi(ivmMonthOrdPrdReqDTO.getPdiNm());
//        langReqDto.setYear(ivmMonthOrdPrdReqDTO.getYear());
//        langReqDto.setSdate(ivmMonthOrdPrdReqDTO.getYear());
//        langReqDto.setRegion(ivmMonthOrdPrdReqDTO.getRegion());
//        List<CommLangComboResDTO> langCombo = commComboDAO.selectCommLangComboList(langReqDto);


        List<TbWrkDateMgmt> dlist = totIvmDAO.selectTbWrkDateMgmtList(ivmMonthOrdPrdReqDTO);
        for(int i = 0 ; i < dlist.size() ; i++ ){
            String col = "col"+i;
            String ymd = dlist.get(i).getYmd2();
            if("col0".equals(col)){  ivmMonthOrdPrdReqDTO.setCol0(ymd); };
            if("col1".equals(col)){  ivmMonthOrdPrdReqDTO.setCol1(ymd); };
            if("col2".equals(col)){  ivmMonthOrdPrdReqDTO.setCol2(ymd); };
            if("col3".equals(col)){  ivmMonthOrdPrdReqDTO.setCol3(ymd); };
            if("col4".equals(col)){  ivmMonthOrdPrdReqDTO.setCol4(ymd); };
            if("col5".equals(col)){  ivmMonthOrdPrdReqDTO.setCol5(ymd); };
            if("col6".equals(col)){  ivmMonthOrdPrdReqDTO.setCol6(ymd); };
            if("col7".equals(col)){  ivmMonthOrdPrdReqDTO.setCol7(ymd); };
            if("col8".equals(col)){  ivmMonthOrdPrdReqDTO.setCol8(ymd); };
            if("col9".equals(col)){  ivmMonthOrdPrdReqDTO.setCol9(ymd); };
            if("col10".equals(col)){ ivmMonthOrdPrdReqDTO.setCol10(ymd); };
            if("col11".equals(col)){ ivmMonthOrdPrdReqDTO.setCol11(ymd); };
            if("col12".equals(col)){ ivmMonthOrdPrdReqDTO.setCol12(ymd); };
            if("col13".equals(col)){ ivmMonthOrdPrdReqDTO.setCol13(ymd); };
        }

        List<IvmMonthOrdPrdResDTO> result = new ArrayList<IvmMonthOrdPrdResDTO>();

        String mode = ivmMonthOrdPrdReqDTO.getMode();

        HashMap<String, String> selectMsgOdrMap = new HashMap();
        selectMsgOdrMap = totIvmDAO.selectMsgOdr(ivmMonthOrdPrdReqDTO);

        ivmMonthOrdPrdReqDTO.setVFramYmd(selectMsgOdrMap.get("V_FRAM_YMD"));
        ivmMonthOrdPrdReqDTO.setFirstYm(dlist.get(0).getYmd2());
        ivmMonthOrdPrdReqDTO.setLastYm(dlist.get(dlist.size()-1).getYmd2());

        //월간 생산 정보
        if("monPrd".equals(mode)) {
            result = totIvmDAO.selectMonthPrdList(ivmMonthOrdPrdReqDTO);
        }
        //월간 오더 정보
        if("monOrd".equals(mode)) {
            result = totIvmDAO.selectMonthOrdList(ivmMonthOrdPrdReqDTO);
        }
        //월간 오더대비생산 정보
        if("monOrdPrd".equals(mode)) {
            result = totIvmDAO.selectMonthOrdPrdList(ivmMonthOrdPrdReqDTO);
        }

        return result;
    }

    @Override
    public List<IvmNatlProdPlanResDTO> selectNatlProdPlanList(ComIvmReqDTO comIvmReqDTO) throws Exception {
        List<IvmNatlProdPlanResDTO> result = new ArrayList<IvmNatlProdPlanResDTO>();
        result= totIvmDAO.selectNatlProdPlanList(comIvmReqDTO);

        return result;
    }

    @Override
    public List<IvmVehlIvResDTO> selectVehlIvList(ComIvmReqDTO reqDto) throws Exception {
        List<IvmVehlIvResDTO> result = new ArrayList<IvmVehlIvResDTO>();

        String mode = reqDto.getMode();
        //언어별분석
        if("lang".equals(mode)) {
            result= totIvmDAO.selectVehlIvByLangList(reqDto);
        }
        //일자별분석
        if("day".equals(mode)) {
            result= totIvmDAO.selectVehlIvByDayList(reqDto);
        }

        return result;
    }

}
