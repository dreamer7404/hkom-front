package com.oms.cmm.utils;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import lombok.experimental.UtilityClass;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @author 안경수
 * @since 2023. 1. 19.
 * @see
 */

@UtilityClass
public class Utils {

    public static boolean isNull(Object obj) {
        if(obj == null) return true;
        if ((obj instanceof String) && (((String)obj).trim().length() == 0)) { return true; }
        if (obj instanceof Map) { return ((Map<?, ?>) obj).isEmpty(); }
        if (obj instanceof Map) { return ((Map<?, ?>)obj).isEmpty(); }
        if (obj instanceof List) { return ((List<?>)obj).isEmpty(); }
        if (obj instanceof Object[]) { return (((Object[])obj).length == 0); }
        return false;
    }

    public static String getMethod(HttpServletRequest request) {
        String method = request.getHeader("_method");
        return method == null ? "" : method;
    }

    public static String getRemoteAddress(HttpServletRequest request) {
        String ip = request.getHeader("X-FORWARDED-FOR");
        return (ip != null) ? ip : request.getRemoteAddr();
    }

    // Token에서 사원번호 가져오기
    public static String getUserEeno(HttpServletRequest request) {
        return "H2212239";
    }

    // Token에서 회사코드 가져오기
    public static String getDlExpdCoCd(HttpServletRequest request) {
        return "01";
    }

}
