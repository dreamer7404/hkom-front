package com.oms.ivm.dto;

import org.apache.ibatis.type.Alias;

import com.oms.common.dto.CommReqDTO;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @author 김정웅
 * @since 2023. 3. 17.
 * @see
 */
@Alias("comIvmReqDTO")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class ComIvmReqDTO extends CommReqDTO {

    private String userId;      //사용자 ID
    private String vehlCd;      //차종코드
    private String key;         //
    private String sdate;       //검색조건 시작일
    private String edate;       //검색조건 종료일
    private String language;    //언어코드 ex) EU(영어/미국) 등..
    private String year;        //연식?
    private String region;      //지역코드 ex) 유럽, 북미 등..
    private String mdlMdyCd;    //연식
    private String mode;        //검색조건 화면 옵션 (언어별분석, 일자별분석 등..)
}
