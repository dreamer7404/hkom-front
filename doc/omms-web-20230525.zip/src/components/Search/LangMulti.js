import React, {useState, useRef}  from 'react';
import { Row, Col } from 'react-bootstrap';
import { Form ,SelectPicker,CheckPicker,Checkbox, Button } from 'rsuite';
import { escapeCharChange} from '../../utils/commUtils';

//--------------  서버데이터용 필수 -------------------------------
import { useQuery} from 'react-query';
import { getData  } from '../../utils/async';
import { API, CONSTANTS } from '../../utils/constants';
import useStore from '../../utils/store';
import { useEffect } from 'react';
//--------------// 서버데이터용 필수 -------------------------------

const LangMulti = () => {

    const {keyword, 
        setDlExpdRegnCd,  // 지역코드 setter
        setLangCds,  // 언어코드 setter
    } = useStore(); 


    const onChangeRegionCombo = val => {
        setDlExpdRegnCd(val);
    };


    // regionCombo API가져오기
    const regionParams = {
        bDate: keyword.bDate && keyword.bDate.replace(/-/gi, ''), 
        dlExpdPdiCd: keyword.dlExpdPdiCd, 
        qltyVehlCd: keyword.qltyVehlCd, 
        mdlMdyCd: keyword.mdlMdyCd
    };
    const regionCombo = useQuery([API.regionCombo, regionParams], () => getData(API.regionCombo, regionParams), {
            select: data => [{label: CONSTANTS.labelAll, value: CONSTANTS.valueAll}].concat(data.map((item) => ({ label: item.dlExpdRegnNm, value: item.dlExpdRegnCd })))
    }); 

    // langCombo API가져오기
    const langParams = {
        bDate: keyword.bDate && keyword.bDate.replace(/-/gi, ''),
        dlExpdPdiCd: keyword.dlExpdPdiCd, 
        qltyVehlCd: keyword.qltyVehlCd, 
        mdlMdyCd: keyword.mdlMdyCd,
        dlExpdRegnCd: keyword.dlExpdRegnCd
    };
    const langCombo = useQuery([API.langCombo, langParams], () => getData(API.langCombo, langParams), {
        select: data => data.map((item) => ({ label: escapeCharChange(item.langCdNm), value: item.langCd }))
    }); 

    const allValue = langCombo && langCombo.data ? langCombo.data.map(item => item.value) : [];
    const picker = useRef();

    
    const [value, setValue] = useState([]);
    // useEffect(() => {
    //     console.log(picker)
    //     //setLangCds(value)
    // }, [value])
    
    const handleKeyword = e => {
        setLangCds(value)
    }
    const handleChange = value => {
        setValue(value);
    };

    const handleCheckAll = (value, checked) => {
        setValue(checked ? allValue : []);
    };

    const footerStyles = {
        padding: '2px 2px',
        borderTop: '1px solid #e5e5e5'
      };
    return (
        <>
            <Form.ControlLabel column="sm" >언어</Form.ControlLabel>
            <Row className="select-wrap">
                <Col sm={3}>
                    <SelectPicker size="sm"
                        value={keyword.dlExpdRegnCd} 
                        data={regionCombo && regionCombo.data ? regionCombo.data : []} 
                        onChange={onChangeRegionCombo}
                        placeholder={CONSTANTS.labelAll}
                        cleanable={false}
                        searchable={false}
                        block={true}
                    />
                </Col>
                <Col sm={9}>
                
                    <CheckPicker
                        size="sm"
                        // data={data}
                        data={langCombo && langCombo.data ? langCombo.data : []}  
                        placeholder="전체"
                        ref={picker}
                        style={{ width: 200 }}
                        /*width 해지시 다중선택하면 길이가 늘어남.. */
                        value={value}
                        searchable={false}
                        onChange={handleChange}
                        onClose={handleKeyword}
                        cleanable={false}
                        renderExtraFooter={() => (
                        <div style={footerStyles}>
                            <Checkbox
                                indeterminate={value.length > 0 && value.length < allValue.length}
                                checked={value.length === allValue.length}
                                onChange={handleCheckAll}
                            >
                            전체 선택
                            </Checkbox>

                            {/* <Button
                            // style={footerButtonStyle}
                            appearance="primary"
                            size="sm"
                            onClick={() => {
                                setLangCds(value)
                                picker.current.close();
                            }}
                            >
                            Ok
                            </Button> */}
                        </div>
                        )}
                    />
                </Col>
            </Row>
        </>
    );

};
export default LangMulti;