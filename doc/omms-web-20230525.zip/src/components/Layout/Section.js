// react
import React, { useEffect,useState } from 'react';
import { useLocation } from 'react-router-dom';


// react-bootstrap
import useStore from '../../utils/store';
import {getMenuName, getBreadCrumbs} from '../../utils/commUtils';

const Section = ({children}) => {

    const breadCrumbs = getBreadCrumbs(useStore().menu, useLocation().pathname);

    return(
        <div  className="contentsBody" id="contents-body">
            <div className="title-wrap">
                <p className="section-title" id="section-title-width">
                    {breadCrumbs.second}
                </p>
                <ul className="bread-crumbs">
                    {breadCrumbs && <>
                        <li>{breadCrumbs.home}</li>
                        <li>{breadCrumbs.first}</li>
                        <li className="active">{breadCrumbs.second}</li>
                    </>}
                </ul>
            </div>
            <div>
                {children}
            </div>
        </div>

    );
};
export default Section;
