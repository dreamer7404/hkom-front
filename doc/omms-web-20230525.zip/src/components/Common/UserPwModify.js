import React, {useState} from 'react';
import {Modal, Button, Table} from 'react-bootstrap';
import {Form, InputGroup, Input, Schema, Notification, useToaster} from 'rsuite';

//--------------  서버데이터용 필수 -------------------------------
import { useQuery, useQueryClient, useMutation} from 'react-query';
import { getData, postData } from '../../utils/async';
import { API, CONSTANTS } from    '../../utils/constants';
//--------------// 서버데이터용 필수 -------------------------------

const { StringType} = Schema.Types;
const model = Schema.Model({
    userPw: StringType().isRequired('기존 비밀번호를 입력해주세요.')
                            .pattern(/^(?=.*[A-Za-z])(?=.*\d)(?=.*[$@$!%*#?&])[A-Za-z\d$@$!%*#?&]{7,}$/, 
                                '최소 7자리이며, 숫자,문자,특수문자는 최소1개이상 입력해주세요')
                            .rangeLength(7, 20, '7-20자로 입력해주세요'),
    userPwNew: StringType().isRequired('변경 비밀번호를 입력해주세요.')
                            .pattern(/^(?=.*[A-Za-z])(?=.*\d)(?=.*[$@$!%*#?&])[A-Za-z\d$@$!%*#?&]{7,}$/, 
                                '최소 7자리이며, 숫자,문자,특수문자는 최소1개이상 입력해주세요')
                            .rangeLength(7, 20, '7-20자로 입력해주세요'),
    userPwClon: StringType().isRequired('변경 비밀번호를 재입력해주세요.')
})

const UserPwModify = ({show, data, onHide}) => {

    const [safeClass, setSafeClass] = useState('low');
    const [safeText, setSafeText] = useState('낮음');

    const toaster = useToaster();

    // Form 정의
    const formRef = React.useRef();
    const [formError, setFormError] = React.useState({});
    const [formValue, setFormValue] = React.useState({
        userEeno: data.userEeno,   
        userPw: '',   
        userPwNew: '',    
        userPwClon: '',  
    });

    // 사용자 수정하기
    const usrmgmtMutate = useMutation((params => postData(API.changeUserPw, params, CONSTANTS.update)),{
        onSuccess: res => {
            console.log(res)
            if(res > 0){
                toaster.push(<Notification type='success' header='성공' closable >
                     수정이 완료되었습니다.
                    </Notification>);
                
            }else if(res === -1){
                toaster.push(<Notification type='error' header='실패' closable >
                    수정이 실패했습니다.<br /> 관리자에게 문의해주세요.
                    </Notification>);
                onHide(false); // 창닫기
            }else if(res === -2){
                toaster.push(<Notification type='error' header='실패' closable >
                    기존비밀번호가 틀립니다.<br /> 정확히 입력해주세요.
                    </Notification>);
            }else {
                toaster.push(<Notification type='error' header='실패' closable >
                    수정을 실패했습니다.
                    </Notification>);
            }
            onHide(); 
           
        }
    });

    const handleSubmit = () => {
        // validation 체크
        // if (!formRef.current.check()) {
        //     return;
        // }
        // console.log(formValue)
        // if(formValue.userPwNew !== formValue.userPwClon){
        //     toaster.push(<Notification type='warning' header='오류' closable >
        //     변경비밀번호 확인내용이 틀립니다.
        //     </Notification>);
        // }else{
        //     // 사용자 수정 실행
        //     usrmgmtMutate.mutate({
        //         userPw: formValue.userPw,
        //         userPwNew: formValue.userPwNew
        //     });
        // }

        const str = formValue.userPwNew;
        const arrNum = str.match(/[0-9]/g);
        const arrEng = str.match(/[a-z]/gi);
        const arrSpecial = str.match(/[\{\}\[\]\/?.,;:|\)*~`!^\-_+<>@\#$%&\\\=\(\'\"]/g);
        const isSerial = (/([A-Za-z0-9`~!@#\$%\^&\*\(\)\{\}\[\]\-_=\+\\|;:'"<>,\./\?])\1{2,}/g).test(str);

        console.log('userPw: ', formValue.userPw)
        console.log('userPwNew: ', str)

        console.log('contain: ',str.includes(formValue.userPw))
        console.log('arrNum: ', arrNum.length)
        console.log('arrEng: ', arrEng.length)
        console.log('arrSpecial: ', arrSpecial.length)
        console.log('isSerial: ', isSerial)

    };

    const count = (str) => {
        

       
    }
    
    return (
        <>
            <Form
                ref={formRef}
                checkTrigger="none"
                onChange={setFormValue}
                onCheck={setFormError}
                formValue={formValue}
                model={model}>
                <Modal show={show} onHide={onHide} backdrop="static" keyboard={false} centered size="md" className="modal-custom">
                    <Modal.Header closeButton>
                        <Modal.Title>비밀번호 변경</Modal.Title>
                    </Modal.Header>
                    <Modal.Body>
                            
                            {/* 비밀번호 유효기간 만료 로그인시 팝업 
                            <div className="password-find">
                                <p>비밀번호를 변경해주세요</p>
                                <p>비밀번호를 변경하신지 6개월(180일)이 경과하였습니다. <br/> 안전한 사용을 위하여, 기존 비밀번호를 변경해주세요. <br/> 비밀번호 미 변경시 로그인이 불가합니다.</p>
                            </div>  */}
                            
                            {/* 임시비밀번호 로그인시 팝업
                            <div className="password-find">
                                <p>비밀번호를 변경해주세요</p>
                                <p>임시 비밀번호 입니다. <br/> 안전한 사용을 위하여, 비밀번호를 변경해주세요. <br/> 비밀번호 미 변경시 로그인이 불가합니다.</p>
                            </div>  */}
                           
                            <Table className="tbl-hor" bordered>
                                <tbody>
                                    <tr>
                                        <th>기존 비밀번호</th>
                                        <td>
                                            <Form.Control name="userPw" size="sm" type="password" placeholder="기존 비밀번호를 입력해주세요" />
                                        </td>
                                    </tr>
                                    <tr>
                                        <th>변경 비밀번호</th>
                                        <td>
                                            <InputGroup>
                                                <Form.Control name="userPwNew" size="sm"  style={{height:'24px'}} type="password" placeholder="변경 비밀번호를 입력해주세요" />
                                                <InputGroup.Addon><span>안전성 <span className={safeClass}>{safeText}</span></span></InputGroup.Addon>
                                                {/* 안전성 높음 > className = " high"  - 4가지조건 만족하고, 특수문자 2개이상 or 소문자, 대문자 각 3개이상 or 숫자 2개이상, 동일문자 연속3개이하
                                                    안전성 중간 > className = " mid " - 4가지조건 만족
                                                    안전성 낮음 > className = " low " - 4가지조건 만족못할때
                                                */}
                                                {/*
                                                 
                                                */}
                                            </InputGroup>
                                        </td>
                                    </tr>
                                    <tr>
                                        <th>변경 비밀번호 확인</th>
                                        <td>
                                            <Form.Control name="userPwClon" size="sm" type="password" placeholder="변경 비밀번호를 재입력해주세요" />
                                        </td>
                                    </tr>
                                </tbody>
                            </Table>
                            <div className="password-info">
                                <p>[비밀번호 변경규칙]</p>
                                <ul>
                                    <li>비밀번호는 최소 8자 이상으로 설정하세요.</li>
                                    <li>비밀번호 첫 자리는 반드시 영문 알파벳(대문자/소문자)으로 시작되어야 합니다.</li>
                                    <li>이전 5개의 비밀번호와 동일한 비밀번호는 사용할 수 없습니다</li>
                                    <li>비밀번호는 아래의 조건 4가지를 만족하여야 합니다.
                                        <ul>
                                            <li>비밀번호에는 특수문자가 1개 이상 포함되어야 합니다. <span>사용 불가: # % = ; ~ - & $ ' " |   </span></li>
                                            <li>비밀번호에는 영문 알파벳 소,대문자 각 1개 이상 포함되어야 합니다.</li>
                                            <li>비밀번호에는 숫자가 1개 이상 포함되어야 합니다. <span>변경예시) Hmc0120!  Apple123?  Kia007!@</span></li>
                                            <li>비밀번호에는 동일문자를 연속으로 5개 이상 사용할 수 없습니다.</li>
                                        </ul>
                                    </li>
                                </ul>
                            </div>
                    </Modal.Body>
                    <Modal.Footer>
                        <Button variant="light" size="md" onClick={onHide}>취소</Button>
                        <Button variant="primary" size="md" onClick={handleSubmit}>저장</Button>
                    </Modal.Footer>
                </Modal>
            </Form>
        </>
    );

};
export default UserPwModify;