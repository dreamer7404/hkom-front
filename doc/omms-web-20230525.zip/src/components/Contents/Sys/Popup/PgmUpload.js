import React, {useState, useMemo} from 'react';
import { AgGridReact } from 'ag-grid-react';
import {Button, Modal, Table} from 'react-bootstrap';
import {Form} from 'rsuite';

const PgmUpload = ({show, onHide}) => {

     const [rowData] = useState([

    ]);

    const columnDefs = [
        {
          headerName: '프로그램아이디',
          field: 'pgmId',
        },
        {
          headerName: '프로그램명',
          field: 'PgmNm',
        },
        {
          headerName: '메뉴명',
          field: 'menuNm',
        },
        {
          headerName: 'Type',
          field: 'type',
          maxWidth:'80',
        },
    ]

    const defaultColDef = useMemo(() => {
        return {
            initialWidth: 90,
            sortable: true,
            resizable:true,
        };
    }, []);

    const onFirstDataRendered = (params) => {
        params.api.sizeColumnsToFit();
    };

    return (
        <>
            <Form>
                <Modal show={show} onHide={onHide} backdrop="static" keyboard={false} centered size="lg" className="modal-custom">
                    <Modal.Header closeButton>
                        <Modal.Title>프로그램 등록(액셀 업로드)</Modal.Title>
                    </Modal.Header>
                        <Modal.Body>
                            <div className="grid-btn-wrap">
                                <div className="right-align">
                                    {/*--------- 버튼 -----------*/}
                                    <Button variant="outline-secondary" size="sm">Sample</Button>{' '}
                                    <Button variant="outline-secondary" size="sm">업로드</Button>{' '}
                                </div>
                            </div>
                            <Table className="tbl-hor" bordered>
                                <colgroup>
                                    <col style={{width:'30%'}}></col>
                                    <col style={{width:''}}></col>
                                </colgroup>
                                <tbody>
                                    <tr>
                                        <th className="essen">첨부파일</th>
                                        <td>
                                            
                                        </td>
                                    </tr>
                                </tbody>
                            </Table>
                            <div className="ag-theme-alpine mt-10" style={{height:300, minWidth:300}}>
                            <AgGridReact
                                rowData={rowData}
                                columnDefs={columnDefs}
                                defaultColDef={defaultColDef}
                                rowSelection={'multiple'}
                                suppressRowClickSelection= {true} 
                                onFirstDataRendered={onFirstDataRendered}
                                suppressSizeToFit={true}    
                                onGridSizeChanged={onFirstDataRendered}     
                                >
                            </AgGridReact>
                        </div>
                        </Modal.Body>
                        <Modal.Footer>
                            <Button variant="light" size="md" onClick={onHide}>취소</Button>
                            <Button variant="primary" size="md" onClick={onHide} >저장</Button>
                        </Modal.Footer>
                </Modal>
            </Form>
        </>
    );

};
export default PgmUpload;