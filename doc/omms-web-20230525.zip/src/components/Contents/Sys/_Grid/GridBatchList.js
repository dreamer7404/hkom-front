import React, {useEffect, useMemo, useRef} from 'react';
import { AgGridReact } from 'ag-grid-react';
import {Button} from 'react-bootstrap';
import { CONSTANTS } from '../../../../utils/constants';

const GridBatchList = ({filterValue, queryResult, limit, activePage, onCellClicked}) => {

  const gridRef = useRef();
  const rowSpan = (params) => {
          return params.data.flag? params.data.flag: 1;
    };

  class ShowCellRenderer {
      init(params) {  
        console.log(params.value)
        const cellBlank = !params.value;
        if (cellBlank) {
            return; 
        }

        if(params.value === 'Batch 재실행'){
          this.ui = document.createElement('div');
          this.ui.innerHTML = '<div class="rowspan-title" style="line-height:' + params.data.flag * '30' + 'px;">' + '<Button class="btn btn-outline-secondary btn-sm grid-button" size="sm">' +params.value + '</Button>' + '</div>';
           
        }else{
          this.ui = document.createElement('div');
          this.ui.innerHTML = '<div class="rowspan-title" style="line-height:' + params.data.flag * '30' + 'px;">' + params.value + '</div>';
        }
    
        // this.ui = document.createElement('div');
        // this.ui.innerHTML = '<div class="rowspan-title" style="line-height:' + params.data.flag * '30' + 'px;">' + params.value + '</div>';
      
      }
  
      getGui() {
      return this.ui;
      }
  
      refresh() {
      return false;
      }
  }
  
  const columnDefs = [
        {
            headerName: 'Batch명',
            field: 'batchNm',
            maxWidth:'300',
            cellRenderer: ShowCellRenderer,
            rowSpan:rowSpan,
            cellClass: (rowSpan) => {
                return rowSpan.data.flag >= 2 ? 'show-cell' : null;
            },
        },
        {
            headerName: '실행시간',
            field: 'batchTime',
            maxWidth:'200',
        },
        {
          headerName: 'Batch설명',
          field: 'batchDt',
          cellRenderer: ShowCellRenderer,
            rowSpan:rowSpan,
            cellClass: (rowSpan) => {
                return rowSpan.data.flag >= 2 ? 'show-cell' : null;
            },
        },
        {
          headerName: '재실행',
          field: 'batchRe',
          maxWidth:'150',
          // cellRenderer: "buttonComponent",
          cellRenderer: ShowCellRenderer,
          rowSpan:rowSpan,
          cellClass: (rowSpan) => {
              return rowSpan.data.flag >= 2 ? 'show-cell' : null;
          },
        },
  ]

  

  const defaultColDef = useMemo(() => {
      return {
          initialWidth: 90,
          sortable: true,
          resizable:true,
      };
  }, []);

  const onFirstDataRendered = (params) => {
      params.api.sizeColumnsToFit();
  };

  useEffect(()=>{
    if(queryResult.status === 'loading' && gridRef && gridRef.current && gridRef.current.api){
        gridRef.current.api.showLoadingOverlay();
    }
  },[queryResult]);

  useEffect(()=> {
    if(gridRef && gridRef.current && gridRef.current.api){
      gridRef.current.api.setQuickFilter(filterValue);
    }
  },[filterValue]);

  useEffect(()=> {
    if(gridRef && gridRef.current && gridRef.current.api){
      gridRef.current.api.paginationGoToPage(activePage-1);
    }
  },[activePage]);

  const gridOptions = {
    domLayout: 'autoHeight',
  };

  return(
      <div className="ag-theme-alpine" style={{transition:'all ease .3s'}}>
        <AgGridReact
            ref={gridRef} 
            rowData={queryResult && queryResult.data} 
            columnDefs={columnDefs}
            defaultColDef={defaultColDef}

            // paging
            pagination={true}
            paginationPageSize={limit} //
            suppressPaginationPanel={true} 

            //  filter
            cacheQuickFilter={true}

            onCellClicked={onCellClicked}

            suppressRowTransform={true}

            //grid auto height 
            gridOptions={gridOptions}

            // overlay
            overlayLoadingTemplate={CONSTANTS.gridLoading}
            overlayNoRowsTemplate={CONSTANTS.gridNoRows}

            onFirstDataRendered={onFirstDataRendered}
            suppressSizeToFit={true}    
            onGridSizeChanged={onFirstDataRendered}    
            >
        </AgGridReact>
    </div>
  )


};
export default GridBatchList;