// react
import React, {useState, useMemo} from 'react';
import { AgGridReact } from 'ag-grid-react';
import {Button, Table} from 'react-bootstrap';
import {Form} from 'rsuite';


const NoticeDetail = () => {

    const [rowData] = useState([
        {co: "현대자동차", part: "자동차업체", userId: "user_01", userName: "홍길동"},
    ]);

    const columnDefs = [
        {
          headerName: '회사명',
          field: 'co',
        },
        {
          headerName: '부서명',
          field: 'part',
        },
        {
          headerName: '아이디',
          field: 'userId',
        },
        {
          headerName: '이름',
          field: 'userNm',
        },
    ]

    const defaultColDef = useMemo(() => {
        return {
            initialWidth: 90,
            sortable: true,
        };
    }, []);


    const onFirstDataRendered = (params) => {
        params.api.sizeColumnsToFit();
    };

    return (
        <>
            <div className="write-wrap">
                <Form>
                    <Table className="tbl-hor" bordered>
                        <colgroup>
                            <col style={{width:'15%'}}></col>
                            <col style={{width:'35%'}}></col>
                            <col style={{width:'15%'}}></col>
                            <col style={{width:'35%'}}></col>
                        </colgroup>
                        <tbody>
                            <tr>
                                <th className="">게시여부</th>
                                <td>게시</td>
                                <th>게시기간</th>
                                <td>2023-03-31 ~ 2023-04.30</td>
                            </tr>
                            <tr>
                                <th className="">업무구분</th>
                                <td colSpan="3">재고관리</td>
                            </tr>
                            <tr>
                                <th className="">게시대상</th>
                                <td colSpan="3">
                                    <div className="ag-theme-alpine" style={{height: 250, transition:'all ease .3s'}}>
                                        <AgGridReact
                                            rowData={rowData}
                                            columnDefs={columnDefs}
                                            defaultColDef={defaultColDef}

                                            onFirstDataRendered={onFirstDataRendered}
                                            suppressSizeToFit={true}    
                                            onGridSizeChanged={onFirstDataRendered}    
                                            >
                                        </AgGridReact>
                                    </div>
                                </td>
                            </tr>
                            <tr>
                                <th className="">제목</th>
                                <td colSpan="3">공지사항입니다.</td>
                            </tr>
                            <tr>
                                <th className="">내용</th>
                                <td colSpan="3">공지사항 내용입니다.</td>
                            </tr>
                            <tr>
                                <th>첨부파일</th>
                                <td colSpan="3">
                                    
                                </td>
                            </tr>
                        </tbody>
                    </Table>
                </Form>
                <div className="btn-wrap">
                    <div className="left-align">
                        <Button variant="light">목록</Button>{' '}
                    </div>
                    <div className="right-align">
                        <Button variant="outline-danger">삭제</Button>{' '}
                        <Button className="" variant="primary" size="md">수정</Button>
                    </div>
                </div>
            </div>
        </>
    )
};
export default NoticeDetail;