import React, {useState, useMemo} from 'react';
import { AgGridReact } from 'ag-grid-react';
import {Button, Modal, Table, Row, Col} from 'react-bootstrap';
import {Form, SelectPicker} from 'rsuite';

import VehlCopy from './VehlCopy';

const VehlLangAddAll = ({show, onHide}) => {

    const [rowData] = useState([
        {langCd: "EE", langName:"영어/유럽"},
    ]);

    const columnDefs = [
        {
          checkboxSelection: true,
          headerCheckboxSelection: true,
          width:45,
          maxWidth:45,
          minWidth:45,
          sortable:false
        },
        {
          headerName: '언어',
          children: [
            { 
                headerName:'언어코드', 
                field: 'langCd',
                filter: 'agTextColumnFilter',
                floatingFilter: true,
                suppressMenu: true,
                filterParams: {
                    filterOptions: ['contains'],
                },
                maxWidth:'150'
             },
            { 
                headerName:'언어명', 
                field: 'langName',
                filter: 'agTextColumnFilter',
                floatingFilter: true,
                suppressMenu: true,
                filterParams: {
                    filterOptions: ['contains'],
                },
            },
          ],
        },
        
    ]

    const defaultColDef = useMemo(() => {
        return {
            initialWidth: 90,
            sortable: true,
            resizable:true,
        };
    }, []);

    const onFirstDataRendered = (params) => {
        params.api.sizeColumnsToFit();
    };

    const [vehlCopyPop, setVehlCopyPop] = useState(false);

    return (
        <>
            <Form>
                <Modal show={show} onHide={onHide} backdrop="static" keyboard={false} centered size="lg" className="modal-custom">
                    <Modal.Header closeButton>
                        <Modal.Title>차종별 언어등록(일괄)</Modal.Title>
                    </Modal.Header>
                        <Modal.Body>
                            <Table className="tbl-hor" bordered>
                                <colgroup>
                                    <col style={{width:'20%'}}></col>
                                    <col style={{width:''}}></col>
                                    <col style={{width:'20%'}}></col>
                                    <col style={{width:''}}></col>
                                </colgroup>
                                <tbody>
                                    <tr>
                                        <th className="essen">차종코드</th>
                                        <td>
                                            <Row className="select-wrap">
                                                <Col sm={8}>
                                                    <SelectPicker size="sm" data={[{ label: "선택"}]} searchable={false} cleanable={false} />
                                                </Col>
                                                <Col sm={4}>
                                                    <SelectPicker block style={{width:'100%'}} size="sm" data={[{ label: "MY"}]} searchable={false} cleanable={false} />
                                                </Col>
                                            </Row>
                                        </td>
                                        <th className="">A코드</th>
                                        <td>
                                            <Form.Control size="sm" type="text"/> 
                                        </td>
                                    </tr>
                                    <tr>
                                        <th className="">정렬순서</th>
                                        <td>
                                            <Form.Control size="sm" type="text"/> 
                                        </td>
                                        <th className="">사용여부</th>
                                        <td>
                                            <SelectPicker size="sm" data={[{ label: "사용"}]} searchable={false} cleanable={false} />
                                        </td>
                                    </tr>
                                    <tr>
                                        <th className="essen">적용언어</th>
                                        <td colSpan="3">
                                            <div className="grid-btn-wrap" style={{marginBottom:'5px'}}>
                                                <div className="right-align">
                                                    <Button variant="outline-secondary" size="sm" onClick={() => setVehlCopyPop(true)}>차종복사</Button>{' '}
                                                </div>
                                            </div>
                                            <div className="ag-theme-alpine" style={{height:300, minWidth:300}}>
                                                <AgGridReact
                                                    rowData={rowData}
                                                    columnDefs={columnDefs}
                                                    defaultColDef={defaultColDef}
                                                    rowSelection={'multiple'}
                                                    suppressRowClickSelection= {true} 
                                                    onFirstDataRendered={onFirstDataRendered}
                                                    suppressSizeToFit={true}    
                                                    onGridSizeChanged={onFirstDataRendered}     
                                                    >
                                                </AgGridReact>
                                            </div>
                                        </td>
                                    </tr>
                                </tbody>
                            </Table>
                        </Modal.Body>

                        <Modal.Footer>
                            <Button variant="light" size="md" onClick={onHide}>취소</Button>
                            <Button variant="primary" size="md" onClick={onHide} >저장</Button>
                        </Modal.Footer>
                </Modal>
            </Form>

            <VehlCopy show={vehlCopyPop} onHide={() => setVehlCopyPop(false)}  />
        </>
    );

};
export default VehlLangAddAll;