// react
import React, {useState, useEffect, useCallback} from 'react';
import {Button} from 'react-bootstrap';

//--------------  서버데이터용 필수 -------------------------------
import { useQuery} from 'react-query';
import { CONSTANTS } from '../../../../utils/constants';
import useStore from '../../../../utils/store';
//--------------// 서버데이터용 필수 -------------------------------

import GridNatMast from '../_Grid/GridNatMast';
import Paging from '../../../Common/Paging';
import { CustomInputGroup } from '../../../Common/CustomInputGroup';

import NatCodeAdd from '../Popup/NatCodeAdd';
import NatCodeUpdate from '../Popup/NatCodeUpdate';

const NatMast = () => {
    
    //------------------- 필수 공통 ------------------------------
    const {keyword } = useStore();  // 조회키워드 가져오기

    const [activePage, setActivePage] = useState(1);    // 페이지번호
    const [limit, setLimit] = useState(50);             // 페이지행수
    const [filterValue, setFilterValue] = useState(''); // 필터값

    const onChangePage = val => {
        setActivePage(val);
    };
    const onChangeLimit = val => {
        setLimit(val);
    };
    useEffect(()=>{
        onChangePage(1); // 페이지번호 리셋
    },[keyword]);

    // 필터
    const onFilterTextBoxChanged = useCallback((e) => {
        setFilterValue(e.target.value);
    }, []);

    //-------------------// 필수 공통 ------------------------------

    const [rowData] = useState([
        { natCd: 'A01', natNm: 'AFGANISTAN',  region: '일반'},
        { natCd: 'A01', natNm: 'AFGANISTAN',  region: '일반'}
    ]);
    

    //  requestState 조회
    const queryResult = useQuery(["NatMast"], () => {return rowData});

    // 셀 클릭
    const onCellClicked = e => {
        if(e.column.colId === 'natNm'){
            setNatCodeUpdatePop(true)
        }
    };

    const [natCodeAddPop, setNatCodeAddPop] = useState(false);
    const [natCodeUpdatePop, setNatCodeUpdatePop] = useState(false);

    return (
        <>
            <div className="grid-wrap" style={{paddingTop: '10px', borderTop: '2px solid var(--main-color)'}}>
                <div className="grid-btn-wrap">
                    <div className="left-align">
                        {/*--------- 필터 -----------*/}
                        <CustomInputGroup size="sm"   onInput={onFilterTextBoxChanged} />
                    </div>
                    <div className="right-align">
                        {/*--------- 버튼 -----------*/}
                        <Button variant="outline-secondary" size="sm" onClick={() => setNatCodeAddPop(true)}>국가코드 등록</Button>{' '}
                        <Button variant="outline-success" size="sm"><span className="excel-down"></span>{CONSTANTS.excelDownload}</Button>{' '}
                    </div>
                </div>
                {/*--------- Grid -----------*/}
                <GridNatMast 
                    filterValue={filterValue}
                    queryResult={queryResult}
                    limit={limit}
                    activePage={activePage}
                    onCellClicked={onCellClicked}
                    />

                {/*--------- 페이징 -----------*/}
                <Paging 
                    total={queryResult && queryResult.data && queryResult.data.length}
                    limit={limit}
                    activePage={activePage}
                    onChangePage={onChangePage}
                    onChangeLimit={onChangeLimit}
                />
            </div>

            {/* 팝업 */}
            <NatCodeAdd show={natCodeAddPop} onHide={() => setNatCodeAddPop(false)}  />
            <NatCodeUpdate show={natCodeUpdatePop} onHide={() => setNatCodeUpdatePop(false)}  />
        </>
    )
};
export default NatMast;