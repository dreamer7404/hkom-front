/* eslint-disable jsx-a11y/anchor-is-valid */
/* eslint-disable react-hooks/exhaustive-deps */
import React, {useState, useEffect, useCallback} from 'react';
import {Button, Collapse, Col} from 'react-bootstrap';
import SearchIcon from '@rsuite/icons/Search';
import { confirmAlert } from 'react-confirm-alert'; // Import
import ConfirmAlert from '../../../Common/ConfirmAlert';

//--------------  서버데이터용 필수 -------------------------------
import { useQuery} from 'react-query';
import { getData } from '../../../../utils/async';
import { API, CONSTANTS } from '../../../../utils/constants';
import useStore from '../../../../utils/store';
//--------------// 서버데이터용 필수 -------------------------------

import BDate from '../../../Search/BDate';
import VehlType from '../../../Search/VehlType';
import Lang from '../../../Search/Lang';
import IvmState from '../../../Search/IvmState';
import Paging from '../../../Common/Paging';
import GridTotalStock from '../_Grid/GridTotalStock';
import { CustomInputGroup } from '../../../Common/CustomInputGroup';

import AdditionalRequest from '../Popup/AdditionalRequest';
// import AdditionalRequestTest from '../Popup/AdditionalRequestTest';
import ProductPlan2Weeks from '../Popup/ProductPlan2Weeks';
import ProductPlan3Days from '../Popup/ProductPlan3Days';
import ThisMonthAmount from '../Popup/ThisMonthAmount';
import SewonIvmPrinting from '../Popup/SewonIvmPrinting';
import SewonIvmHave from '../Popup/SewonIvmHave';
import PdiGlovisIvm from '../Popup/PdiGlovisIvm';
import MemberAddTest from  '../../Sys/Popup/MemberAddTest';

const TotalStock = () => {

    //------------------- 필수 공통 ------------------------------
    const [open, setOpen] = useState(true); // 조건창 열기/닫기
    const {keyword } = useStore();  // 조회키워드 가져오기

    const [activePage, setActivePage] = useState(1);    // 페이지번호
    const [limit, setLimit] = useState(50);             // 페이지행수
    const [filterValue, setFilterValue] = useState(''); // 필터값

    const onChangePage = val => {
        setActivePage(val);
    };
    const onChangeLimit = val => {
        setLimit(val);
    };
    useEffect(()=>{
        onChangePage(1); // 페이지번호 리셋
    },[keyword]);

    // 필터
    const onFilterTextBoxChanged = useCallback((e) => {
        setFilterValue(e.target.value);
    }, []);

    // 검색창 열기/닫기 > 페이지네이션 여부에 따라 +-20px
    const [gridHeight, setGridHeight] = useState(575);
    const gridExpand = () =>{
        setOpen(!open);
        if(open){
            setTimeout(() => setGridHeight(650), 250);
        }else{
            setGridHeight(575)
        }
    }
    //-------------------// 필수 공통 ------------------------------
    
    //  ivmTotal 조회
    const paramIvmTotal = {
            bDate: keyword.bDate,
            dlExpdPdiCd: keyword.dlExpdPdiCd,
            qltyVehlCd: keyword.qltyVehlCd,
            mdlMdyCd: keyword.mdlMdyCd,
            dlExpdRegnCd: keyword.dlExpdRegnCd,
            langCd: keyword.langCd,
            subCd: keyword.subCd,
    }
    // const queryResult = useQuery([API.testIvmTotal, paramIvmTotal], () => getData(API.testIvmTotal, paramIvmTotal));
    const queryResult = useQuery([API.ivmTotIvInfos, paramIvmTotal], () => getData(API.ivmTotIvInfos, paramIvmTotal));
    
    // 그리드 내에서 체크된 rows by Woong
    const [checkedRows, setCheckedRows] = useState([]);    
    const checkRow = e => {
        setCheckedRows(e)
    };

    // 그리드 내에서 클릭된 row by Woong
    const [clickedRowData, setClickedRowData] = useState({});

    // 셀 클릭
    const onCellClicked = e => {
      
        //그리드 내에서 클릭된 rowData 할당
        e.data.bDate = keyword.bDate;
        setClickedRowData(e.data);

        if(e.column.colId === 'wek2PlanQty'){
            setProductPlan1(true)
        }else if(e.column.colId === 'day3PlanQty'){
            setProductPlan2(true)
        }else if(e.column.colId === 'currMthTrwiQty'){
            setThisMonthAmount(true)
        }else if(e.column.colId === 'dlExpdTmpIvQty'){
            setSewonIvmPrinting(true)
        }else if(e.column.colId === 'sewhaIvQty'){
            setSewonIvmHave(true)
        }else if(e.column.colId === 'pdiIvQty'){
            setPdiGlovisIvm(true)
        }

    };

    const [orderPop, setOrderPop] = useState(false);
    const setOrderPopVali = () => {
        if(checkedRows.length <= 0){
            confirmAlert({
                closeOnClickOutside: false,
                customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}  title={"알림"} msg={"대상을 선택해주세요."}  />
            })
            return false
        }
        setOrderPop(true)
    }


    const [productPlan1, setProductPlan1] = useState(false);
    const [productPlan2, setProductPlan2] = useState(false);
    const [thisMonthAmount, setThisMonthAmount] = useState(false);
    const [sewonIvmPrinting, setSewonIvmPrinting] = useState(false);
    const [sewonIvmHave, setSewonIvmHave] = useState(false);
    const [pdiGlovisIvm, setPdiGlovisIvm] = useState(false);

    // 로딩중...
    // useEffect(()=>{
    //     if(ivmTotal.status === 'loading' && gridRef && gridRef.current && gridRef.current.api){
    //         gridRef.current.api.showLoadingOverlay();
    //     }
    // },[ivmTotal]);


    // 조회버튼
    const onSearch = () => {
        queryResult.refetch(); // 수동쿼리실행
    };

    return (
        <>
            {/*--------- 조회조건 -----------*/}
            <div className="search-area">
                <Collapse in={open}>
                    <div className="form" id="example-collapse-text">
                        <div className="search-group">
                            <div className="row">
                                <Col sm={2} className=""> 
                                    <BDate />
                                </Col>
                                <Col sm={5} className="" >
                                    <VehlType  />
                                </Col>
                                <Col sm={4} className="" >
                                    <Lang />
                                </Col>
                                <Col sm={1} className="" >
                                    <IvmState />
                                </Col>
                            </div>
                            <div className="search-btn-wrap">
                                <Button className="btn-search" variant="outline-primary" size="sm" onClick={onSearch}><SearchIcon />조회</Button>
                            </div>
                        </div>
                        
                    </div>
                </Collapse>
                <Button size="sm" variant="outline-dark" className="search-control" aria-controls="example-collapse-text" 
                    aria-expanded={open} onClick={gridExpand}>
                    <span className={open === true ? "search-area-close" : "search-area-open"}>{open === true ? CONSTANTS.closeSearch : CONSTANTS.openSearch}</span>
                </Button>
            </div>

            <div className="grid-wrap">
                        
                <div className="grid-btn-wrap">
                    <div className="left-align">
                        {/*--------- 필터 -----------*/}
                        <CustomInputGroup size="sm"   onInput={onFilterTextBoxChanged} />
                    </div>
                    <div className="right-align">
                        {/*--------- 버튼 -----------*/}
                        {/* <Button variant="outline-secondary" size="sm" onClick={() => onBtShowLoading()}>test</Button>{' '} */}
                        <Button variant="outline-secondary" size="sm" onClick={() => setOrderPopVali()}>별도요청</Button>{' '}
                        <Button variant="outline-success" size="sm"><span className="excel-down"></span>{CONSTANTS.excelDownload}</Button>{' '}
                        <Button variant="outline-dark" size="sm"><span className="print"></span>{CONSTANTS.print}</Button>{' '}
                        {/* <Button variant="outline-secondary" size="sm" onClick={() => setOrderPop2({type: true, test: ''})}>팝업테스트</Button>{' '} */}
                    </div>
                </div>

                {/*--------- Grid -----------*/}
                <GridTotalStock 
                    gridHeight={gridHeight}
                    filterValue={filterValue}
                    queryResult={queryResult}
                    limit={limit}
                    activePage={activePage}
                    onCellClicked={onCellClicked}
                    checkRow={checkRow}
                    />
                
                {/*--------- 페이징 -----------*/}
                <Paging 
                    total={queryResult && queryResult.data && queryResult.data.length}
                    limit={limit}
                    activePage={activePage}
                    onChangePage={onChangePage}
                    onChangeLimit={onChangeLimit}
                />
                
            </div>
            
            {/* 팝업 */}
            <AdditionalRequest show={orderPop} onHide={() => setOrderPop(false)} checkedRows={checkedRows} />
            {/* <AdditionalRequestTest show={orderPop} onHide={() => setOrderPop(false)} checkedRows={checkedRows} /> */}
            
            {productPlan1 && <ProductPlan2Weeks show={productPlan1} onHide={() => setProductPlan1(false)} clickedRowData={clickedRowData} />}
            {productPlan2 && <ProductPlan3Days show={productPlan2} onHide={() => setProductPlan2(false)} clickedRowData={clickedRowData} />}
            {thisMonthAmount && <ThisMonthAmount show={thisMonthAmount} onHide={() => setThisMonthAmount(false)} clickedRowData={clickedRowData} />}
            {sewonIvmPrinting && <SewonIvmPrinting show={sewonIvmPrinting} onHide={() => setSewonIvmPrinting(false)} />}
            {sewonIvmHave && <SewonIvmHave show={sewonIvmHave} onHide={() => setSewonIvmHave(false)} clickedRowData={clickedRowData} />}
            {pdiGlovisIvm && <PdiGlovisIvm show={pdiGlovisIvm} onHide={() => setPdiGlovisIvm(false)} clickedRowData={clickedRowData} />}
            {/* <MemberAddTest show={false} onHide={false} /> */}
        </>
    );

};
export default TotalStock;