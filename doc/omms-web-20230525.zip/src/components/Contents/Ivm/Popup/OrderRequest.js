import React, {useState, useMemo} from 'react';
import {Modal, Button} from 'react-bootstrap';
import {Form} from 'rsuite';
import { AgGridReact } from 'ag-grid-react';
import { CONSTANTS } from '../../../../utils/constants';

import { confirmAlert } from 'react-confirm-alert'; // Import
import 'react-confirm-alert/src/react-confirm-alert.css'; // Import css

const OrderRequest = ({show, onHide}) => {

    const defaultColDef = useMemo(() => {
        return {
            initialWidth: 90,
            resizable:true,
        };
    }, []);

    const [rowData] = useState([
        {carCd: "AD",country:'asdf', carName: "AVANTE", monthYear: '23MY', region:'유럽', langCd:'AR', langName:'영어,불어/캐나다', testDt1:'BAED-2A', testDt2:'12', testDt3:'', testDt4:'12', testDt5:'2023-03-21', testDt6:'홍길동', testDt7:'',},
        {carCd: "AD",country:'asdf', carName: "AVANTE", monthYear: '23MY', region:'유럽', langCd:'AR', langName:'영어,불어/캐나다', testDt1:'FAIM-2A', testDt2:'100', testDt3:'50', testDt4:'50', testDt5:'2023-03-21', testDt6:'홍길동', testDt7:'',},
        
    ]);

    const columnDefs = [
        {
          headerName: '차종',
          children: [
            { headerName:'차종코드', field: 'carCd', sortable:true},
            { headerName:'차종명', field: 'carName',width:'120',sortable:true },
            { headerName:'연식', field: 'monthYear',sortable:true },
          ],
        },
        {
          headerName: '언어',
          children: [
            { headerName:'지역', field: 'region',sortable:true},
            { headerName:'언어코드', field: 'langCd',sortable:true },
            { headerName:'언어명', field: 'langName', width:'120',sortable:true },
          ],
        },
        {
            headerName: '수량',
            field: 'testDt3',
            spanHeaderHeight: true,
            cellRenderer:'inputComponent',
            width:65,
        }  
    ]

    const inputComponent = (props) => {
        return (
          <div className="grid-form-wrap">
            <Form.Control size="sm" type="text" placeholder="" defaultValue={props.value} />
          </div>
        );
    }

    const onFirstDataRendered = (params) => {
        params.api.sizeColumnsToFit();
    };

    const submit = () => {
        confirmAlert({
            closeOnClickOutside: false,

            customUI: ({ onClose }) => {
                return (
                <div className=''>
                    <h1>알림</h1>
                    <p>비밀번호 변경이 완료되었습니다. <br/>변경하신 비밀번호로 다시 로그인해주시기 바랍니다.</p>
                    <div className="btn-wrap">
                        <Button variant="light" size="md" onClick={onClose}>취소</Button>
                        <Button variant="primary" size="md"
                            onClick={() => {
                                this.handleClickDelete();
                                onClose();
                            }}
                            >
                            확인
                        </Button>
                    </div>
                    
                </div>
                );
            }
        });
    };
    
    return (
        <>
            <Form>
                <Modal show={show} onHide={onHide} backdrop="static" keyboard={false} centered size="lg" className="modal-custom">
                    <Modal.Header closeButton>
                            <Modal.Title>발주요청</Modal.Title>
                        </Modal.Header>
                        <Modal.Body>
                            <div className="grid-btn-wrap">
                                <div className="right-align">
                                    <Button variant="outline-success" size="sm"><span className="excel-down"></span>{CONSTANTS.excelDownload}</Button>{' '}
                                    <Button variant="outline-dark" size="sm"><span className="print"></span>{CONSTANTS.print}</Button>{' '}
                                </div>
                            </div>
                            <div className="ag-theme-alpine" style={{height:300, minWidth:300}}>
                            <AgGridReact
                                rowData={rowData}
                                columnDefs={columnDefs}
                                defaultColDef={defaultColDef}
                                frameworkComponents={{
                                    inputComponent
                                }}
                                onFirstDataRendered={onFirstDataRendered}
                                suppressSizeToFit={true}    
                                onGridSizeChanged={onFirstDataRendered}     
                                >
                            </AgGridReact>
                            </div>
                            <p class="tbl-info2">※ 현재 재고 부족으로 상기 매뉴얼의 긴급 발주를 요청합니다.</p>
                        </Modal.Body>
                        <Modal.Footer>
                            <Button variant="light" size="md" onClick={onHide}>취소</Button>
                            <Button variant="primary" size="md" onClick={submit}>저장</Button>
                        </Modal.Footer>
                </Modal>
            </Form>
        </>
    );

};
export default OrderRequest;