export const API = {
    //--------- 공통 조회 -----------------------------
    pgmMgmts: 'pgmMgmts',           // 화면상단 메뉴리스트  
    changeToken: 'changeToken',     // 토큰변경  (어드민)   

    //--------- 조회용 콤보리스트 -----------------------
    pdiCombo: 'pdiCombo',           // PDi
    vehlCombo: 'vehlCombo',         // 차량코드
    mdyCombo: 'mdyCombo',           // MDY코드
    regionCombo: 'regionCombo',     // 지역코드
    langCombo: 'langCombo',         // 언어코드
    subCdCombo: 'subCdCombo',       // 재고상태
    codeCombo: 'codeCombo',     // 코드테이블
    grpCombo: 'grpCombo',       // 그룹정보


    //--------- 그리드 조회 -----------------------------
    // 재고관리
    // 총재고관리
    testIvmTotal: 'testIvmTotal',                       // 총재고관리 테스트
    ivmTotIvInfos: 'ivmTotIvInfos',                     // 총재고관리
    ivmSeparatelyRequest : 'ivmSeparatelyRequest',      // 별도요청 저장
    ivm2WeekPlan : 'ivm2WeekPlan',                      //2주 생산계획
    ivm3DayPlan: 'ivm3DayPlan',                         //단기계획(3일)
    ivmThisMonTrwis: 'ivmThisMonTrwis',                 //당월투입(누적)
    ivmSewonIvs: 'ivmSewonIvs',                         //재고현황-세원보유재고
    ivmPdiOrYongsanIvs: 'ivmPdiOrYongsanIvs',           //PDI/용산재고
    ivmMonthOrdPrdInfos: 'ivmMonthOrdPrdInfos',         //월간오더/생산정보
    ivmNatlProdPlanInfos: 'ivmNatlProdPlanInfos',       //국가별생산정보
    ivmVehlIvInfos: 'ivmVehlIvInfos',                   //차종별재고분석
    ivmOrderRequestInfos:'ivmOrderRequestInfos',        //요청현황
    // 세원재고관리
    ivmSewonIvmInfos: 'ivmSewonIvmInfos',               //세원재고관리
    ivmSewonWhotInfos: 'ivmSewonWhotInfos',             //출고현황입력 팝업 - 조회(get), 저장/삭제(post)
    ivmIvModInfos: 'ivmIvModInfos',                     //세원재고보정 팝업 - 조회(get), 저장/삭제(post)
    ivmSewonWhotInfos2 : 'ivmSewonWhotInfos2',          //출고현황
    ivmSewonRequestInfos:'ivmSewonRequestInfos',        //요청현황
    // PDI재고관리
    ivmPdiIvInfos: 'ivmPdiIvInfos',                     //PDI재고관리
    ivmPdiPrndMonitorInfo:'ivmPdiPrndMonitorInfo',      //생산라인모니터링
    ivmPdiWhsnInfo: 'ivmPdiWhsnInfo',                   //입고확인


    // 제작준비
    printOrderInfos: 'printOrderInfos',                 // O/M발주

    // 발간현황
    printStates: 'printStates',                     //발간현황
    printState: 'printState',                       //발간현황 상세 / 저장
    selectTotalIvm : 'selectTotalIvm',              //발간실적현황 조회
    savePrntBgt : 'savePrntBgt',                    //인쇄비용 입력
    outRequestChange : 'outRequestChange',          //납품요청일자 변경
    savePrintCostInputNo : 'savePrintCostInputNo',  //인쇄비용 품의번호 저장


    // 운영관리
    vehlMgmts: 'vehlMgmts',                 //차종조회
    langCopys: 'langCopys',                 //언어복사
    dlExpdPacScnCombo : 'dlExpdPacScnCombo',//승상구분코드
    dlExpdPrvsCombo : 'dlExpdPrvsCombo',    //수신형태코드
    userMgmtPop : 'userMgmtPop',            //담당자 팝업
    natlMsts : 'natlMsts',                  //국가코드 목록 조회
    langMsts : 'langMsts',                  //언어코드 목록 조회
    vehlMgmt : 'vehlMgmt',                  //차종관리저장//상세
    qltyVehlMdyCombo: 'qltyVehlMdyCombo',   //차종코드별 연식조회
    vehlMdyMgmts : 'vehlMdyMgmts',                  //연식리스트
    vehlMdyMgmt : 'vehlMdyMgmt',                    //연식상세, 저장

    // 시스템관리
    usrmgmts: 'usrmgmts',                   // 사용자정보 목록
    usrmgmt: 'usrmgmt',                     // 사용자정보 by userEeno
    checkUserEeno: 'checkUserEeno',         // 사용자 id 중복체크
    userVehls: 'userVehls',                 // 차종권한코드 목록
    usrAndVehls: 'usrAndVehls',             // 사용자 & 차종권한코드 목록
    initUserPw: 'initUserPw',               // 비밀번호 초기화
    changeUserPw: 'changeUserPw',           // 비번번호 변경
    changeUserUseYn: 'changeUserUseYn',     // 사용자 사용여부
    login: 'login',                         // 로그인
    usrGrpMgmts: 'usrGrpMgmts',
    usrGrpMgmt: 'usrGrpMgmt',
    pgmMgmtsAll: 'pgmMgmtsAll',            // 메뉴관리용 목록
    changePgmMgmtUseYn: 'changePgmMgmtUseYn',   // 메뉴 사용여부 변경

    authAffrMgmts: 'authAffrMgmts',         // 메뉴별 권한 목록
    authAffrMgmt: 'authAffrMgmt',         // 특정메뉴 권한그룹 목록
    comboAuthAffrMgmt: 'comboAuthAffrMgmt', // 콤보용
    authAffrMgmtsForGrp: 'authAffrMgmtsForGrp', // 그룹별 권한목록
    authAffrMgmtsByGrp: 'authAffrMgmtsByGrp', // 특정그룹 권한목록

    apiMgmts: 'apiMgmts',       //  api관리목록
    apiMgmt: 'apiMgmt',         // API 추가, 수정
    logUses: 'logUses',        // 사용로그 목록
    logUsesTot: 'logUsesTot', // 사용로그 목록개수
    
    
};

export const CONSTANTS = {
    gridLoading: '<span class="ag-overlay-loading-center">데이터 로딩중...</span>',
    gridNoRows: '<span style="padding: 10px; border: 1px solid #ccc;">데이터가 없습니다.</span>',

    labelLoading: '로딩중...',
    labelAll: '전체',
    valueAll: 'ALL',
    labelSelect: '선택',

    closeSearch: '검색창 닫기',
    openSearch: '검색창 열기',
    excelDownload: '액셀다운로드',
    print: '인쇄',
    all: '전체',

    insert: 'insert',
    update: 'update',
    delete: 'delete',

    // 그룹 코드(dlExpdGCd)
    grpCdCo: '0001',    // 회사
    grpCdRegn: '0008',  // 지역
    grpCdDept: '0011',  // 부서
    grpCdPacScn: '0004', //승상구분코드
    grpCdIway : '0024', //발행방법

    // 사용자그룹코드
    grpCdSysAdm: '100',  // 어드민

};