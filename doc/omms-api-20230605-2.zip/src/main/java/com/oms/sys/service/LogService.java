package com.oms.sys.service;

import java.util.List;

import com.oms.sys.dto.LogUseReqDTO;
import com.oms.sys.dto.LogUseResDTO;
import com.oms.sys.dto.SchedLogDTO;
import com.oms.sys.model.LogUse;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @author 안경수
 * @since 2023. 5. 19.
 * @see
 */


public interface LogService {
    int insertSchedLog(SchedLogDTO schedLogDTO);
    int insertLogUse(LogUse logUse);
    List<LogUseResDTO> selectLogUseList(LogUseReqDTO logUseReqDTO);
    Integer selectLogUseListTot(LogUseReqDTO logUseReqDTO);
}
