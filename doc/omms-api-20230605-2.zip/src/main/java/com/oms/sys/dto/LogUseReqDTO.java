package com.oms.sys.dto;

import org.apache.ibatis.type.Alias;

import com.oms.common.dto.CommReqDTO;

import lombok.Data;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @author Windows i¿½i¿½i¿½i¿½i¿½
 * @since 2023. 5. 24.
 * @see
 */

@Data
@Alias("logUseReqDTO")
public class LogUseReqDTO extends CommReqDTO  {
//    private String useEeno;
    private String apiUrl;
    private String cmd; // select, update insert delete
    private String classNm; // class Name
    private String methodNm; // method name

    // tb_api_mgmt
    private String menuId;

    // tb_pgm_mgmt
    private String pgmNm;

    //
    private String startDate;
    private String endDate;

}
