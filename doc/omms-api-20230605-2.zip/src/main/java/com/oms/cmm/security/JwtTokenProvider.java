package com.oms.cmm.security;

import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.Base64;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import javax.crypto.spec.SecretKeySpec;
import javax.servlet.http.HttpServletRequest;
import javax.xml.bind.DatatypeConverter;

import org.springframework.stereotype.Component;

import com.oms.cmm.global.Consts;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.ExpiredJwtException;
import io.jsonwebtoken.Jws;
import io.jsonwebtoken.JwtBuilder;
import io.jsonwebtoken.JwtException;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import io.jsonwebtoken.security.Keys;
import lombok.RequiredArgsConstructor;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @author 안경수
 * @since 2023. 2. 13.
 * @see
 */

@Component
@RequiredArgsConstructor
public class JwtTokenProvider {
    private String  secretKey  = Base64.getEncoder().encodeToString(Consts.SECRET_KEY.getBytes());
    private final SignatureAlgorithm signatureAlgorithm = SignatureAlgorithm.HS256;

    private Key createKey() {
        byte[] apiKeySecretBytes = DatatypeConverter.parseBase64Binary(secretKey);
        Key signingKey = new SecretKeySpec(apiKeySecretBytes, signatureAlgorithm.getJcaName());
        return signingKey;
    }

    public String createToken(String userEeno, String blnsCoCd, String grpCd, long tokenValidTime){

        Map<String, Object> headerMap = new HashMap<>();
        headerMap.put("typ", "JWT");
        headerMap.put("alg", "HS256");

        Map<String, Object> claims = new HashMap<>();
        claims.put(Consts.CLAIM_USER_EENO, userEeno);
        claims.put(Consts.CLAIM_BLNS_CO_CD, blnsCoCd);
        claims.put(Consts.CLAIM_GRP_CD, grpCd);

        Date expireTime = new Date(System.currentTimeMillis()+ tokenValidTime);

        JwtBuilder builder = Jwts.builder()
                .setHeader(headerMap)
                .setClaims(claims)
                .setExpiration(expireTime)
                .signWith(createKey(), signatureAlgorithm);

        String result = builder.compact();
        return result;

    }
    public Boolean checkJwt(String jwt) throws Exception {
        try {
            Claims claims = Jwts.parserBuilder()
                    .setSigningKey(DatatypeConverter.parseBase64Binary(secretKey))
                    .build()
                    .parseClaimsJws(jwt)
                    .getBody();

//            System.out.println(">>>>>>>>>>>> userEeno : " + claims.get(Consts.CLAIM_USER_EENO));
//            System.out.println(">>>>>>>>>>>> blnsCoCd : " + claims.get(Consts.CLAIM_BLNS_CO_CD));
//            System.out.println(">>>>>>>>>>>> grpCd : " + claims.get(Consts.CLAIM_GRP_CD));

        } catch (ExpiredJwtException e) {
            e.printStackTrace();
            return false;
        } catch (JwtException e) {
            e.printStackTrace();
            return false;
        }
        return true;
    }



//    private long tokenValidTime = 10; //60 * 60 * 1000L; // 1시간
//    private long rtValidTime = 60 * 60 * 1000L; // 1시간

//    @PostConstruct
//    protected void init() {
//        secretKey  = Base64.getEncoder().encodeToString(Consts.SECRET_KEY.getBytes());
//    }


    // JWT 토큰 생성
//    public String createToken(String username, String blnsCoCd, String grpCd, long tokenValidTime) {
//        Claims claims = Jwts.claims().setSubject(username);
//        claims.put("blnsCoCd", blnsCoCd);
//        claims.put("grpCd", grpCd);
//        Date now = new Date();
//        return Jwts.builder()
//                .setClaims(claims)
//                .setIssuedAt(now)
//                .setExpiration(new Date(now.getTime() + tokenValidTime))
//                .signWith(SignatureAlgorithm.HS256, secretKey)
//                .compact();
//    }
//    public String createRt(String username, String blnsCoCd, String grpCd) {
//        Claims claims = Jwts.claims().setSubject(username);
//        claims.put("blnsCoCd", blnsCoCd);
//        claims.put("grpCd", grpCd);
//        Date now = new Date();
//        return Jwts.builder()
//                .setClaims(claims)
//                .setIssuedAt(now)
//                .setExpiration(new Date(now.getTime() + rtValidTime))
//                .signWith(SignatureAlgorithm.HS256, secretKey)
//                .compact();
//    }

    // 토큰의 유효성 + 만료일자 확인
    public boolean validateToken(String jwtToken) {
        try {
            // secretKey => b21zU2VjcmV0S2V5
            Jws<Claims> claims = Jwts.parser().setSigningKey(secretKey).parseClaimsJws(jwtToken);
            return !claims.getBody().getExpiration().before(new Date());
        } catch (Exception e) {
            return false;
        }
    }

    // 토큰에서 회원 정보 추출
    public String getUserPk(String token) {
        String user = Jwts.parser().setSigningKey(secretKey).parseClaimsJws(token).getBody().getSubject();
        return user;
    }

    // 토큰에서 추가정보 추출
    public String getMapInfo(String token, String key) {
        return Jwts.parser().setSigningKey(secretKey).parseClaimsJws(token).getBody().get(key).toString();
    }

    // Request의 Header에서 token 값을 가져옵니다. "X-AUTH-TOKEN" : "TOKEN값'
    public String getToken(HttpServletRequest request) {
        return request.getHeader(Consts.X_AUTH_TOKEN);
    }



    //  UserEeno
//    public String getUserEeno(HttpServletRequest request) {
//        String token = request.getHeader("x-auth-token");
//        return token != null ? getUserPk(token) : null;
//    }
//
//    // 회사코드
//    public String getDlExpdCoCd(HttpServletRequest request) {
//        String token = request.getHeader("x-auth-token");
//        return token != null ? getMapInfo(token, "blnsCoCd") : null;
//    }
//
//    // 권한그룹코드
//    public String getDlExpdGCd(HttpServletRequest request) {
//        String token = request.getHeader("x-auth-token");
//        return token != null ? getMapInfo(token, "grpCd") : null;
//    }


}
