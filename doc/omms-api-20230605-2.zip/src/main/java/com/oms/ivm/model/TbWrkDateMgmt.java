package com.oms.ivm.model;

import lombok.Data;

/**
 * <pre>
 * TbWrkDateMgmt VO
 * </pre>
 *
 * @Class Name : TbWrkDateMgmt.java
 * @Description : 날짜정보관리 엔티티
 * @author 김정웅
 * @since 2023.3.21
 * @see
 */

@Data
public class TbWrkDateMgmt{

    private String wkYmd;  //WK_YMD(TB_WRK_DATE_MGMT)  char(8)
    private String dowCd;  //DOW_CD(TB_WRK_DATE_MGMT)  char(1)
    private String holiYn; //HOLI_YN(TB_WRK_DATE_MGMT) char(1)

    private String ymd;
    private String ymd2;


}
