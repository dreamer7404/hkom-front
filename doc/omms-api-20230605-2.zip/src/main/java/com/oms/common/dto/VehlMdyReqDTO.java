package com.oms.common.dto;

import org.apache.ibatis.type.Alias;

import lombok.Data;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @author 안경수
 * @since 2023. 6. 5.
 * @see
 */
@Data
@Alias("vehlMdyReqDTO")
public class VehlMdyReqDTO {
    private String vehlCd;
    private String mdyDd;
}
