package com.oms.sys.dto;

import org.apache.ibatis.type.Alias;

import lombok.Getter;
import lombok.NoArgsConstructor;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @author Windows ≫c¿eAU
 * @since 2023. 3. 8.
 * @see
 */
@Alias("pgmMgmtResDTO")
@Getter
@NoArgsConstructor
public class PgmMgmtResDTO {
    private String menuId;
    private String pgmId;
    private Integer pgmIdSn;
    private String pgmNm;
    private String pgmPathAdr;

    private String menuAuthCd;
}
