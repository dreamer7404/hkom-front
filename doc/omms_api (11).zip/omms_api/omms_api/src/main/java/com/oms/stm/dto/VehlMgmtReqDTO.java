package com.oms.stm.dto;

import java.sql.Timestamp;

import org.apache.ibatis.type.Alias;

import com.oms.common.dto.CommReqDTO;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;





/**
 * <pre>
 * Statements
 * </pre>
 * @ClassName : VehlMgmtReqDTO.java
 * @Description :
 * @author 김경훈
 * @since 2023. 3. 13.
 * @see
 */
@Alias("vehlMgmtReqDTO")
@NoArgsConstructor
@Data
@AllArgsConstructor

public class VehlMgmtReqDTO extends CommReqDTO {


    private String userId;
    @Schema(type = "string", example = " ")
    private String col1;
    @Schema(type = "string", example = " ")
    private String col2;
    @Schema(type = "string", example = " ")
    private String col3;
    @Schema(type = "string", example = " ")
    private String col4;
    @Schema(type = "string", example = " ")
    private String col5;
    @Schema(type = "string", example = " ")
    private String col6;
    @Schema(type = "string", example = " ")
    private String col7;
    @Schema(type = "string", example = " ")
    private String qltyVehlCd;
    @Schema(type = "string", example = " ")
    private String mdlMdyCd;
    @Schema(type = "string", example = " ")
    private String pdi;
    @Schema(type = "string", example = " ")
    private String c2qltyVehlCd;
    @Schema(type = "string", example = "HM-08")
    private String c2qltyVehlNm;
    @Schema(type = "string", example = " ")
    private String c1qltyVehlCd;
    @Schema(type = "string", example = " ")
    private String dlExpdRegnCd;
    @Schema(type = "string", example = " ")
    private String dlExpdNatCd;
    @Schema(type = "string", example = "12")
    private String c1mdlMdyCd;

    @Schema(type = "string", example = " ")
    private String pprrEeno;
    @Schema(type = "string", example = " ")
    private String updrEeno;

    @Schema(type = "string", example = " ")
    private String hmcchkVal;
    @Schema(type = "string", example = " ")
    private String clScnCd;
    @Schema(type = "string", example = " ")
    private String crgrEeno;
    @Schema(type = "string", example = " ")
    private String blnsCoCd;
    @Schema(type = "string", example = " ")
    private String kyungchkVal;
    @Schema(type = "string", example = " ")
    private String sehwachkVal;
    @Schema(type = "string", example = " ")
    private String pdichkVal;
    @Schema(type = "string", example = " ")
    private String regnClumSize;
    @Schema(type = "string", example = " ")
    private String dytmPlnCd;
    @Schema(type = "string", example = " ")
    private String prdnMstCd;
    @Schema(type = "string", example = " ")
    private String bomVehlCd;
    @Schema(type = "string", example = " ")
    private String saleVehlCd;
    @Schema(type = "string", example = " ")
    private String chkVal;
    @Schema(type = "string", example = " ")
    private String langCd;
    @Schema(type = "string", example = " ")
    private String prvsScnCd;
    @Schema(type = "string", example = " ")
    private String prdnVehlCd;
    @Schema(type = "string", example = " ")
    private String jbMdyRelCd;
    @Schema(type = "string", example = " ")
    private String dlExpdMdlMdyCd;
    @Schema(type = "string", example = " ")
    private String chkMdy;
    @Schema(type = "string", example = " ")
    private String nqltyVehlCd;
    @Schema(type = "string", example = " ")
    private String nMonth;
    @Schema(type = "string", example = " ")
    private String nmdlMdyCd;
    @Schema(type = "string", example = " ")
    private String oriQltyVehlCd;
    @Schema(type = "string", example = " ")
    private String oriMdlMdyCd;
    @Schema(type = "string", example = " ")
    private String vehlCdByVehlReg;
    @Schema(type = "string", example = " ")
    private String qltyVehlNm;
    @Schema(type = "string", example = " ")
    private String lastMy;
    @Schema(type = "string", example = " ")
    private String chkCpVehl;
    @Schema(type = "string", example = " ")
    private String dlExpdPacScnCd;
    @Schema(type = "string", example = " ")
    private String sYm;
    @Schema(type = "string", example = " ")
    private String eYm;
    @Schema(type = "string", example = " ")
    private String sdate;
    @Schema(type = "string", example = " ")
    private String dlExpdPdiCd;
    @Schema(type = "string", example = "Y")
    private String useYn;
}
