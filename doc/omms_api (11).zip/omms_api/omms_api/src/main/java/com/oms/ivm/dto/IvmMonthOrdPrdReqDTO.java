package com.oms.ivm.dto;

import java.sql.Timestamp;

import org.apache.ibatis.type.Alias;

import com.oms.common.dto.CommReqDTO;

import lombok.AllArgsConstructor;
import lombok.Data;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @author 김정웅
 * @since 2023. 3. 7.
 * @see
 */
@Alias("ivmMonthOrdPrdReqDTO")
@Data
@AllArgsConstructor
public class IvmMonthOrdPrdReqDTO extends CommReqDTO {

    private String chkVal;
    private String csrf;
    private String mode;
    private String page;
    private String pgmId;
    private String menuId;
    private String sdate;
    private String edate;
    private String pdiNm;
    private String vehl;
    private String year;
    private String region;
    private String language;
    private String userId;
    private String langCombo;

    private String vFramYmd;
    private String vPlnFramYmd;

    private String firstYm;
    private String lastYm;

    private String col0;
    private String col1;
    private String col2;
    private String col3;
    private String col4;
    private String col5;
    private String col6;
    private String col7;
    private String col8;
    private String col9;
    private String col10;
    private String col11;
    private String col12;
    private String col13;
}
