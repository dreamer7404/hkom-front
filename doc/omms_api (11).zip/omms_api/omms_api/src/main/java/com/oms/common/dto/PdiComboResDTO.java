package com.oms.common.dto;

import org.apache.ibatis.type.Alias;

import lombok.Data;

/**
 * <pre>
 * PDI combo용
 * </pre>
 *
 * @author 안경수
 * @since 2023. 3. 22.
 * @see
 */
@Data
@Alias("pdiComboResDTO")
public class PdiComboResDTO {
    private String dlExpdPdiCd;
    private String dlExpdPrvsNm;
}
