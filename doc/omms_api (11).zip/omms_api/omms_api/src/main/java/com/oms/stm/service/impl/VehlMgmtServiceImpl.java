package com.oms.stm.service.impl;
import java.util.List;

import able.cloud.core.service.HService;
import org.springframework.stereotype.Service;
import com.oms.stm.dao.VehlMgmtDAO;
import com.oms.stm.dto.StmComReqDTO;
import com.oms.stm.dto.VehlMgmtReqDTO;
import com.oms.stm.dto.VehlMgmtResDTO;
import com.oms.stm.service.VehlMgmtService;
import lombok.RequiredArgsConstructor;


/**
 * <pre>
 * Statements
 * </pre>
 * @ClassName : VehlMgmtServiceImpl.java
 * @Description :
 * @author 김경훈
 * @since 2023. 3. 13.
 * @see
 */
@RequiredArgsConstructor
@Service("vehlMgmtService")
public class VehlMgmtServiceImpl extends HService implements VehlMgmtService {

    private final VehlMgmtDAO vehlMgmtDAO;

    /*
     * @see com.oms.stm.service.VehlMgmtService#selectVehlMgmtList(com.oms.stm.dto.VehlMgmtReqDTO)
     */
    @Override
    public List<VehlMgmtResDTO> selectVehlMgmtList(StmComReqDTO dto) {

        return vehlMgmtDAO.selectVehlMgmtList(dto);
    }

    /*
     * @see com.oms.stm.service.VehlMgmtService#selectCpyTgVehl(com.oms.stm.dto.VehlMgmtReqDTO)
     */
    @Override
    public List<VehlMgmtResDTO> selectCpyTgVehl(StmComReqDTO dto) {
        //
        return vehlMgmtDAO.selectCpyTgVehl(dto);
    }

    /*
     * @see com.oms.stm.service.VehlMgmtService#selectNatlVehlChk(com.oms.stm.dto.VehlMgmtReqDTO)
     */
    @Override
    public String selectNatlVehlChk(VehlMgmtReqDTO vehlReqDTO) {
        // TODO Auto-generated method stub
        return vehlMgmtDAO.selectNatlVehlChk(vehlReqDTO);
    }

    /*
     * @see com.oms.stm.service.VehlMgmtService#insertNatlVehlMgmt(com.oms.stm.dto.VehlMgmtReqDTO)
     */
    @Override
    public void insertNatlVehlMgmt(VehlMgmtReqDTO vehlReqDTO) {
        vehlMgmtDAO.insertNatlVehlMgmt(vehlReqDTO);
    }

    /*
     * @see com.oms.stm.service.VehlMgmtService#deleteVehlLangCp(com.oms.stm.dto.VehlMgmtReqDTO)
     */
    @Override
    public void deleteVehlLangCp(VehlMgmtReqDTO vehlReqDTO) {
        vehlMgmtDAO.deleteVehlLangCp(vehlReqDTO);
    }

    /*
     * @see com.oms.stm.service.VehlMgmtService#insertVehlLangCopy(com.oms.stm.dto.VehlMgmtReqDTO)
     */
    @Override
    public void insertVehlLangCopy(VehlMgmtReqDTO vehlReqDTO) {
        vehlMgmtDAO.insertVehlLangCopy(vehlReqDTO);

    }

    /*
     * @see com.oms.stm.service.VehlMgmtService#deleteVehlNatlLang(com.oms.stm.dto.VehlMgmtReqDTO)
     */
    @Override
    public void deleteVehlNatlLang(VehlMgmtReqDTO vehlReqDTO) {
        vehlMgmtDAO.deleteVehlNatlLang(vehlReqDTO);

    }

    /*
     * @see com.oms.stm.service.VehlMgmtService#insertVehlNatlLangCpy(com.oms.stm.dto.VehlMgmtReqDTO)
     */
    @Override
    public void insertVehlNatlLangCpy(VehlMgmtReqDTO vehlReqDTO) {
        vehlMgmtDAO.insertVehlNatlLangCpy(vehlReqDTO);

    }

    /*
     * @see com.oms.stm.service.VehlMgmtService#selectCpyTgNatlVehl(com.oms.stm.dto.VehlMgmtReqDTO)
     */
    @Override
    public List<VehlMgmtResDTO> selectCpyTgNatlVehl(VehlMgmtReqDTO dto) {
        return vehlMgmtDAO.selectCpyTgNatlVehl(dto);
    }

    /*
     * @see com.oms.stm.service.VehlMgmtService#selectVehlMgmtNatlLangList(com.oms.stm.dto.VehlMgmtReqDTO)
     */
    @Override
    public List<VehlMgmtResDTO> selectVehlMgmtNatlLangList(StmComReqDTO dto) {
        // TODO Auto-generated method stub
        return vehlMgmtDAO.selectVehlMgmtNatlLangList(dto);
    }

    /*
     * @see com.oms.stm.service.VehlMgmtService#deleteVehlMgmtCrgr(com.oms.stm.dto.VehlMgmtReqDTO)
     */
    @Override
    public void deleteVehlMgmtCrgr(VehlMgmtReqDTO vehlReqDTO) {
        vehlMgmtDAO.deleteVehlMgmtCrgr(vehlReqDTO);
    }

    /*
     * @see com.oms.stm.service.VehlMgmtService#insertVehlMgmtCrgr(com.oms.stm.dto.VehlMgmtReqDTO)
     */
    @Override
    public void insertVehlMgmtCrgr(VehlMgmtReqDTO vehlReqDTO) {
        vehlMgmtDAO.insertVehlMgmtCrgr(vehlReqDTO);
    }

    /*
     * @see com.oms.stm.service.VehlMgmtService#deleteVehlMgmtRegnRelCd(com.oms.stm.dto.VehlMgmtReqDTO)
     */
    @Override
    public void deleteVehlMgmtRegnRelCd(VehlMgmtReqDTO vehlReqDTO) {

         vehlMgmtDAO.deleteVehlMgmtRegnRelCd(vehlReqDTO);
    }

    /*
     * @see com.oms.stm.service.VehlMgmtService#deleteVehlDlExpdMdyMgmt(com.oms.stm.dto.VehlMgmtReqDTO)
     */
    @Override
    public void deleteVehlDlExpdMdyMgmt(VehlMgmtReqDTO vehlReqDTO) {
        vehlMgmtDAO.deleteVehlDlExpdMdyMgmt(vehlReqDTO);

    }

    /*
     * @see com.oms.stm.service.VehlMgmtService#insertVehlMgmtRegnRelCd(com.oms.stm.dto.VehlMgmtReqDTO)
     */
    @Override
    public void insertVehlMgmtRegnRelCd(VehlMgmtReqDTO vehlReqDTO) {
        vehlMgmtDAO.insertVehlMgmtRegnRelCd(vehlReqDTO);

    }

    /*
     * @see com.oms.stm.service.VehlMgmtService#insertVehlDlExpdMdyMgmt(com.oms.stm.dto.VehlMgmtReqDTO)
     */
    @Override
    public void insertVehlDlExpdMdyMgmt(VehlMgmtReqDTO vehlReqDTO) {
        vehlMgmtDAO.insertVehlDlExpdMdyMgmt(vehlReqDTO);

    }

    /*
     * @see com.oms.stm.service.VehlMgmtService#deleteVehlMgmtAltn(com.oms.stm.dto.VehlMgmtReqDTO)
     */
    @Override
    public void deleteVehlMgmtAltn(VehlMgmtReqDTO vehlReqDTO) {
        vehlMgmtDAO.deleteVehlMgmtAltn(vehlReqDTO);

    }

    /*
     * @see com.oms.stm.service.VehlMgmtService#insertVehlMgmtAltn(com.oms.stm.dto.VehlMgmtReqDTO)
     */
    @Override
    public void insertVehlMgmtAltn(VehlMgmtReqDTO vehlReqDTO) {
        vehlMgmtDAO.insertVehlMgmtAltn(vehlReqDTO);

    }

    /*
     * @see com.oms.stm.service.VehlMgmtService#deleteNatlVehlLang(com.oms.stm.dto.VehlMgmtReqDTO)
     */
    @Override
    public void deleteNatlVehlLang(VehlMgmtReqDTO vehlReqDTO) {
        vehlMgmtDAO.deleteNatlVehlLang(vehlReqDTO);

    }

    /*
     * @see com.oms.stm.service.VehlMgmtService#insertNatlVehlLang(com.oms.stm.dto.VehlMgmtReqDTO)
     */
    @Override
    public void insertNatlVehlLang(VehlMgmtReqDTO vehlReqDTO) {
        vehlMgmtDAO.insertNatlVehlLang(vehlReqDTO);

    }

    /*
     * @see com.oms.stm.service.VehlMgmtService#updateVehlMgmtMain(com.oms.stm.dto.VehlMgmtReqDTO)
     */
    @Override
    public void updateVehlMgmtMain(VehlMgmtReqDTO vehlReqDTO) {
        vehlMgmtDAO.updateVehlMgmtMain(vehlReqDTO);

    }

    /*
     * @see com.oms.stm.service.VehlMgmtService#selectDlExpdMdyPreList(com.oms.stm.dto.VehlMgmtReqDTO)
     */
    @Override
    public List<VehlMgmtReqDTO> selectDlExpdMdyPreList(VehlMgmtReqDTO dto) {
        // TODO Auto-generated method stub
        return vehlMgmtDAO.selectDlExpdMdyPreList(dto);
    }

    /*
     * @see com.oms.stm.service.VehlMgmtService#selectDlExpdMdyNextList(com.oms.stm.dto.VehlMgmtReqDTO)
     */
    @Override
    public List<VehlMgmtReqDTO> selectDlExpdMdyNextList(VehlMgmtReqDTO dto) {
        // TODO Auto-generated method stub
        return vehlMgmtDAO.selectDlExpdMdyNextList(dto);
    }

    /*
     * @see com.oms.stm.service.VehlMgmtService#selectVehlLangList(com.oms.stm.dto.VehlMgmtReqDTO)
     */
    @Override
    public List<VehlMgmtReqDTO> selectVehlLangList(VehlMgmtReqDTO dto) {
        // TODO Auto-generated method stub
        return vehlMgmtDAO.selectVehlLangList(dto);
    }

    /*
     * @see com.oms.stm.service.VehlMgmtService#deleteVehlLang(com.oms.stm.dto.VehlMgmtReqDTO)
     */
    @Override
    public void deleteVehlLang(VehlMgmtReqDTO vo) {
        vehlMgmtDAO.deleteVehlLang(vo);

    }

    /*
     * @see com.oms.stm.service.VehlMgmtService#insertVehlLangInfo(com.oms.stm.dto.VehlMgmtReqDTO)
     */
    @Override
    public void insertVehlLangInfo(VehlMgmtReqDTO vo) {
        vehlMgmtDAO.insertVehlLangInfo(vo);

    }

    /*
     * @see com.oms.stm.service.VehlMgmtService#selectVehlMgmtCnt(com.oms.stm.dto.VehlMgmtReqDTO)
     */
    @Override
    public String selectVehlMgmtCnt(VehlMgmtReqDTO vehlReqDTO) {
        // TODO Auto-generated method stub
        return vehlMgmtDAO.selectVehlMgmtCnt(vehlReqDTO);
    }

    /*
     * @see com.oms.stm.service.VehlMgmtService#insertVehlMgmtMain(com.oms.stm.dto.VehlMgmtReqDTO)
     */
    @Override
    public void insertVehlMgmtMain(VehlMgmtReqDTO vehlReqDTO) {
         vehlMgmtDAO.insertVehlMgmtMain(vehlReqDTO);

    }

    /*
     * @see com.oms.stm.service.VehlMgmtService#selectPreVehlMdyChk(com.oms.stm.dto.VehlMgmtReqDTO)
     */
    @Override
    public List<VehlMgmtResDTO> selectPreVehlMdyChk(VehlMgmtReqDTO vehlReqDTO) {
        // TODO Auto-generated method stub
        return vehlMgmtDAO.selectPreVehlMdyChk(vehlReqDTO);
    }

    /*
     * @see com.oms.stm.service.VehlMgmtService#selectMdyMonth(com.oms.stm.dto.VehlMgmtReqDTO)
     */
    @Override
    public List<VehlMgmtReqDTO> selectMdyMonth(StmComReqDTO reqDto) {
        // TODO Auto-generated method stub
        return vehlMgmtDAO.selectMdyMonth(reqDto);
    }

    /*
     * @see com.oms.stm.service.VehlMgmtService#getVehlCombo(com.oms.stm.dto.VehlMgmtReqDTO)
     */
    @Override
    public List<VehlMgmtResDTO> getVehlCombo(StmComReqDTO dto) {
        // TODO Auto-generated method stub
        return vehlMgmtDAO.getVehlCombo(dto);
    }

    /*
     * @see com.oms.stm.service.VehlMgmtService#getPdiCombo(com.oms.stm.dto.VehlMgmtReqDTO)
     */
    @Override
    public List<VehlMgmtResDTO> getPdiCombo(StmComReqDTO dto) {
        // TODO Auto-generated method stub
        return vehlMgmtDAO.getPdiCombo(dto);
    }






}
