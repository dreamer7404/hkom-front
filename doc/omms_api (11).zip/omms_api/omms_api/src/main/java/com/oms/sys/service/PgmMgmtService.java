package com.oms.sys.service;

import java.util.List;

import com.oms.common.dto.CommReqDTO;
import com.oms.sys.dto.PgmMgmtResDTO;


/**
 * <pre>
 * PgmMgmtService
 * </pre>
 *
 * @ClassName   : PgmMgmtService.java
 * @Description :
 * @author 안경수
 * @since 2023.1.19
 * @see
 */


public interface PgmMgmtService {
    public List<PgmMgmtResDTO> selectPgmMgmtList(CommReqDTO commReqDTO) throws Exception;
}
