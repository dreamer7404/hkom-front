package com.oms.stm.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import able.cloud.core.web.HController;


import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


import com.oms.stm.dto.BoardReqDTO;
import com.oms.stm.dto.BoardResDTO;
import com.oms.stm.service.BoardService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;


/**
 * <pre>
 * BoardController
 * </pre>
 *
 * @ClassName   : BoardController.java
 * @Description : 클래스 설명을 기술합니다.
 * @author 김경훈
 * @since 2023.3,8
 * @see
 */
@Tag(name = "BoardController", description = "")
@CrossOrigin(origins="*")
@RequiredArgsConstructor
@RestController
@RequestMapping("/api")
public class BoardController extends HController {

    /**
     * 클래스 Injection
     */
    private final BoardService boardService;
    private final HttpServletRequest request;
	/**
     * 게시판 조회
     */
    @Operation(summary = "게시판 조회")
    @GetMapping("/boardList")
    public  List<BoardResDTO> boardList(@ModelAttribute BoardReqDTO boardReqDTO) throws Exception {

        boardReqDTO.setUserId("H2302603"); //토큰 사용자
        List<BoardResDTO> result = boardService.selectBoardList(boardReqDTO);

        boardReqDTO.setSaffrScnCd(request.getParameter("saffrScnCd"));
        boardReqDTO.setKeyword("keyword");
        boardReqDTO.setOkmsg(request.getParameter("okmsg"));


        /** LOG_USE Start =========================================================*/
//        boardReqDTO.setMenuId(request.getParameter("menuId"));
        boardReqDTO.setUseType("01"); // 사용유형(01:조회, 02:수정, 03:삭제, 04:인쇄, 05:등록, 06:DN)
        boardReqDTO.setFileNm("");
        boardReqDTO.setFileSize("");
        boardReqDTO.setActId("/stm/boardList.do");

        return result;
    }


    @Operation(summary = "게시판 추가 모달")
    @GetMapping("/selectBoardModal")
    public  List<BoardResDTO> selectBoardModal(@ModelAttribute BoardReqDTO boardReqDTO) throws Exception {

        List<BoardResDTO> list = boardService.selectBoardGrpList(boardReqDTO);  // 게시 그룹 조회


        boardReqDTO.setUserId("H2302603"); //토큰 사용자
        return  list;

    }
  /**
  * 코드정보 등록, 수정, 삭제
  */
 @Operation(summary = "공지사항 등록", description = "")
 @Parameter(in = ParameterIn.HEADER, name="_method")
 @PostMapping(value = "/insertBoard")
    public HashMap<String, Object> insertBoard(@RequestBody BoardReqDTO boardReqDTO) throws Exception {

        HashMap <String, Object> resultMap = new HashMap<String, Object>();
        boardReqDTO.setUserId("H2302603"); //토큰 사용자
        boardReqDTO.setLoginNm("김경훈");
        boardReqDTO.setRgnEeno("H2302603"); //토큰 사용자
        boardReqDTO.setUpdrEeno("H2302603"); //토큰 사용자
        boardReqDTO.setPprrEeno("H2302603"); //토큰 사용자

        try{
            boardService.insertBoard(boardReqDTO, request);
            boardReqDTO.setRcvrEeno("H2302603"); //토큰 사용자
            boardService.insertRcvrMgmt(boardReqDTO);
            String mailSend = request.getParameter("mailSend");
            String title = request.getParameter("blcTitlNm");
            String contents = request.getParameter("blcSbc");


            boardReqDTO.setTitle(title);
            boardReqDTO.setContents(contents);
            boardReqDTO.setSendemail("jayu49@hyundai.com");// 관리자 이메일로 하드코딩
            boardReqDTO.setSendEeno("H2302603".trim()); //토큰 사용자 // 보내는 사람 아이디
            boardReqDTO.setSendNm(boardReqDTO.getLoginNm()); // 보내는 사람 이름

            String subj = request.getParameter("bulSubjCdchkVal");//받는 사람 아이디
            //String subjEm = request.getParameter("userEmlAdrchkVal"); // 받는 사람 이름  &#64;
            String subjNm = request.getParameter("bulSubjCd"); // 받는 사람 이름


        }catch(Exception e) {

        }

        return null;

    }



 @Operation(summary = "공지사항 삭제", description = "")
 @Parameter(in = ParameterIn.HEADER, name="_method")
 @PostMapping(value = "/deleteBoard")
    public Integer deleteBoard(@RequestBody BoardReqDTO boardReqDTO) throws Exception {
         boardService.deleteBoard(boardReqDTO);
         return null;
     }


 @Operation(summary = "공지사항 수정", description = "")
 @Parameter(in = ParameterIn.HEADER, name="_method")
 @PostMapping(value = "/updateBoard")
     public Integer updateBoard(@RequestBody BoardReqDTO boardReqDTO) throws Exception {
         boardService.updateBoard(boardReqDTO);
         return null;
     }
}