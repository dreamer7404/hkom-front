package com.oms.sys.service.impl;

import able.cloud.core.service.HService;

import org.springframework.stereotype.Service;

import com.oms.sys.dao.UsrSessionDAO;
import com.oms.sys.dto.UsrSessionResDTO;
import com.oms.sys.service.UsrSessionService;

import lombok.RequiredArgsConstructor;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @author 안경수
 * @since 2023. 2. 24.
 * @see
 */
@RequiredArgsConstructor
@Service("usrSessionService")
public class UsrSessionServiceImpl extends HService implements UsrSessionService {

    private final UsrSessionDAO usrSessionDAO;
    
    @Override
    public UsrSessionResDTO selectUsrSession(String userEeno) throws Exception {
        return usrSessionDAO.selectUsrSession(userEeno);
    }
    

}
