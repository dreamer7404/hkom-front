package com.oms.ivm.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import able.cloud.core.web.HController;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.oms.cmm.global.Consts;
import com.oms.cmm.utils.Utils;
import com.oms.ivm.dto.ComIvmReqDTO;
import com.oms.ivm.dto.IvmMonthOrdPrdReqDTO;
import com.oms.ivm.dto.IvmMonthOrdPrdResDTO;
import com.oms.ivm.dto.IvmNatlProdPlanResDTO;
import com.oms.ivm.dto.IvmRequestMonitorResDTO;
import com.oms.ivm.dto.IvmVehlIvResDTO;
import com.oms.ivm.dto.TotIvmReqDTO;
import com.oms.ivm.dto.TotIvmRequestReqDTO;
import com.oms.ivm.dto.TotIvmResDTO;
import com.oms.ivm.service.ComIvmService;
import com.oms.ivm.service.TotIvmService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;


/**
 * <pre>
 * TotIvmController
 * </pre>
 *
 * @ClassName   : TotIvmController.java
 * @Description : 재고관리 > 총재고관리 컨트롤러
 * @author 김정웅
 * @since 2023.3.7
 * @see
 */
@Tag(name = "TotIvmController", description = "")
@CrossOrigin(origins="*")
@RequiredArgsConstructor
@RestController
@RequestMapping("/api")
public class TotIvmController extends HController {

    /**
     * 클래스 Injection
     */
    private final HttpServletRequest request;
    private final TotIvmService totIvmService;
    private final ComIvmService comIvmService;

    /**
     * 재고관리 > 총재고관리 > 총재고관리 현황
     */
    @Operation(summary = "총재고관리 조회")
    @GetMapping("/ivmTotIvInfos")
    public List<TotIvmResDTO> selectTotalIvmList(@ModelAttribute TotIvmReqDTO totIvmReqDTO) throws Exception {
        List<TotIvmResDTO> result = totIvmService.selectTotalIvmList(totIvmReqDTO);
        return result;
    }

    /**
     * 재고관리 > 총재고관리 조회 > 별도요청 저장
     */
    @Operation(summary = "별도요청 팝업 - 저장", description = "")
    @Parameter(in = ParameterIn.HEADER, name="_method", schema=@Schema(type="string"))
    @PostMapping(value = "/ivmSpcReqInsert")
    public Integer intsertTotalRequest(@RequestBody List<TotIvmRequestReqDTO> totIvmRequestReqDTO) throws Exception {
        String method = Utils.getMethod(request);
        int result = 0;

        try {
            if(method.equals(Consts.INSERT)) {
                result = totIvmService.intsertTotalRequest(totIvmRequestReqDTO);
            } else {
                return 0;
            }
        } catch (RuntimeException e) {
            return 0;
        }
        return result;
    }

    /**
     * 재고관리 > 월간 오더/생산 정보
     */
    @Operation(summary = "월간 오더/생산 정보")
    @GetMapping("/ivmMonthOrdPrdInfos")
    public List<IvmMonthOrdPrdResDTO> selectMonthOrdPrdList(@ModelAttribute IvmMonthOrdPrdReqDTO reqDto) throws Exception {
        List<IvmMonthOrdPrdResDTO> result = new ArrayList<IvmMonthOrdPrdResDTO>();
        result= totIvmService.selectMonthOrdPrdList(reqDto);

        return result;
    }

    /**
     * 재고관리 > 국가별생산계획
     */
    @Operation(summary = "국가별생산계획")
    @GetMapping("/ivmNatlProdPlanInfos")
    public List<IvmNatlProdPlanResDTO> selectNatlProdPlanList(@ModelAttribute ComIvmReqDTO reqDto) throws Exception {

        /**
         * TODO PDI, 통제소, S/OFF 추출 쿼리 추가해야함.
         *      해당내용은 인병준k -> 안유정책임 -> 현업에게 확인 요청(03/23).
         *      답변 받는대로 작업 진행
         */

        reqDto.setUserId(Utils.getUserEeno(request));

        List<IvmNatlProdPlanResDTO> result = new ArrayList<IvmNatlProdPlanResDTO>();
        result= totIvmService.selectNatlProdPlanList(reqDto);

        return result;
    }

    /**
     * 재고관리 > 차종별재고분석
     */
    @Operation(summary = "차종별재고분석")
    @GetMapping("/ivmVehlIvInfos")
    public List<IvmVehlIvResDTO> selectVehlIvList(@ModelAttribute ComIvmReqDTO reqDto) throws Exception {
        reqDto.setUserId(Utils.getUserEeno(request));
        HashMap<String, String> sysDate2 = comIvmService.getSysDate2();

        try {
            String systoday = (String) sysDate2.get("pSysdate");
            String sysweek = (String) sysDate2.get("pPrevdate");
        } catch(NullPointerException e) {
//            e.printStackTrace();
        }
        List<IvmVehlIvResDTO> result = totIvmService.selectVehlIvList(reqDto);

        return result;
    }

    /**
     * 재고관리 > 차종별재고분석
     */
    @Operation(summary = "차종별재고분석")
    @GetMapping("/ivmRequestMonitorInfos")
    public List<IvmRequestMonitorResDTO> selectRequestMonitorList(@ModelAttribute ComIvmReqDTO reqDto) throws Exception {
        reqDto.setUserId(Utils.getUserEeno(request));

        return null;
    }

}