package com.oms.ivm.dto;

import java.sql.Timestamp;

import org.apache.ibatis.type.Alias;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @author 김정웅
 * @since 2023. 3. 7.
 * @see
 */

@Alias("ivm2WeekPlanResDTO")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Ivm2WeekPlanResDTO {

    private String wkYmd;
    private String idxNm;
    private String dowNm;
    private String prdnPlnQty;
    private String dcsnYn;
    private String rownm;

    //요약보기
    private int totOrdQty;
    private int prevProdQty;
    private int netOrdQty;
    private int currOrdQty;
    private int currProdQty;
    private int currPlanQty;
    private int nextOrdQty;
}
