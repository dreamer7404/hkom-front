package com.oms.ivm.service.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import able.cloud.core.service.HService;

import org.springframework.stereotype.Service;

import com.oms.ivm.dao.ComIvmDAO;
import com.oms.ivm.dto.ComIvmReqDTO;
import com.oms.ivm.dto.Ivm2WeekPlanReqDTO;
import com.oms.ivm.dto.Ivm2WeekPlanResDTO;
import com.oms.ivm.dto.Ivm3DayPlanReqDTO;
import com.oms.ivm.dto.Ivm3DayPlanResDTO;
import com.oms.ivm.dto.IvmPdiOrYongsanIvResDTO;
import com.oms.ivm.dto.IvmSewonIvReqDTO;
import com.oms.ivm.dto.IvmSewonIvResDTO;
import com.oms.ivm.dto.IvmThisMonTrwiReqDTO;
import com.oms.ivm.dto.IvmThisMonTrwiResDTO;
import com.oms.ivm.service.ComIvmService;

import lombok.RequiredArgsConstructor;

/**
 * <pre>
 * ComIvmServiceImpl
 * </pre>
 *
 * @author 김정웅
 * @since 2023. 3. 13.
 * @see
 */
@RequiredArgsConstructor
@Service("comIvmService")
public class ComIvmServiceImpl extends HService implements ComIvmService {

    private final ComIvmDAO comIvmDAO;

    @Override
    public List<Ivm2WeekPlanResDTO> selectIvm2WeekPlanList(Ivm2WeekPlanReqDTO ivm2WeekPlanReqDTO) throws Exception {
        List<Ivm2WeekPlanResDTO> result = new ArrayList<Ivm2WeekPlanResDTO>();
        result.addAll(comIvmDAO.selectIvm2WeekPlanList(ivm2WeekPlanReqDTO));
        result.addAll(comIvmDAO.selectIvm2WeekPlanListSummary(ivm2WeekPlanReqDTO));

        return result;
    }

    @Override
    public List<Ivm3DayPlanResDTO> selectIvm3DayPrdnPlanList(Ivm3DayPlanReqDTO ivm3DayPlanReqDTO) throws Exception {
        List<Ivm3DayPlanResDTO> results = new ArrayList<Ivm3DayPlanResDTO>();

        Ivm3DayPlanReqDTO fuGetWrkdate = comIvmDAO.fuGetWrkdate(ivm3DayPlanReqDTO.getSdate());
        ivm3DayPlanReqDTO.setVWrkYmd(fuGetWrkdate.getVWrkYmd());

        Ivm3DayPlanReqDTO expdPacScnCd = comIvmDAO.fuGetWrkdate(ivm3DayPlanReqDTO.getSdate());
        ivm3DayPlanReqDTO.setVPacScnCd(expdPacScnCd.getVPacScnCd());
        ivm3DayPlanReqDTO.setVPdiCd(expdPacScnCd.getVPdiCd());
        ivm3DayPlanReqDTO.setVLangCd(expdPacScnCd.getVLangCd());

        Ivm3DayPlanReqDTO todayPrdnPlan = comIvmDAO.selectIvmTodayPrdnPlanList(ivm3DayPlanReqDTO);


//        BigDecimal vTddPrdnPlanQty = BigDecimal.valueOf(Double.valueOf(todayPrdnPlan.getVTddPrdnPlanQty()));
//        BigDecimal vTddPrdnQty3 = BigDecimal.valueOf(Double.valueOf(todayPrdnPlan.getVTddPrdnQty3()));
//        BigDecimal vTddPrdnQty = BigDecimal.valueOf(Double.valueOf(todayPrdnPlan.getVTddPrdnQty()));
//        BigDecimal pPlanTotQty = vTddPrdnPlanQty.add(vTddPrdnQty3);

        int vTddPrdnPlanQty = todayPrdnPlan.getVTddPrdnPlanQty();
        int vTddPrdnQty3 = todayPrdnPlan.getVTddPrdnQty3();
        int vTddPrdnQty = todayPrdnPlan.getVTddPrdnQty();
        int pPlanTotQty = vTddPrdnPlanQty + vTddPrdnQty3;

        ivm3DayPlanReqDTO.setVTddPrdnPlanQty(vTddPrdnPlanQty);
        ivm3DayPlanReqDTO.setVTddPrdnQty3(vTddPrdnQty3);
        ivm3DayPlanReqDTO.setVTddPrdnPlanQty(vTddPrdnQty);

        Ivm3DayPlanReqDTO vFramYmd = comIvmDAO.selectVFramYmd(ivm3DayPlanReqDTO);
        ivm3DayPlanReqDTO.setVFramYmd(vFramYmd.getVFramYmd());
        ivm3DayPlanReqDTO.setVLocalChar(vFramYmd.getVLocalChar());

        List<Ivm3DayPlanResDTO> day3PrdnPlan = comIvmDAO.selectIvm3DayPrdnPlanList(ivm3DayPlanReqDTO);
        for(Ivm3DayPlanResDTO result : day3PrdnPlan) {
            result.setPPlanTotQty(pPlanTotQty);
            result.setIvm3DayPlanReqDTO(ivm3DayPlanReqDTO);
            results.add(result);
        }

        return results;
    }

    @Override
    public List<IvmThisMonTrwiResDTO> selectIvmThisMonTrwiList(IvmThisMonTrwiReqDTO ivmThisMonTrwiReqDTO) throws Exception {
        List<IvmThisMonTrwiResDTO> result = new ArrayList<IvmThisMonTrwiResDTO>();
        result = comIvmDAO.selectIvmThisMonTrwiList(ivmThisMonTrwiReqDTO);

        return result;
    }

    @Override
    public List<IvmSewonIvResDTO> selectIvmSewonIvList(IvmSewonIvReqDTO ivmSewonIvReqDTO) throws Exception {
        List<IvmSewonIvResDTO> result = new ArrayList<IvmSewonIvResDTO>();
        result = comIvmDAO.selectIvmSewonIvList(ivmSewonIvReqDTO);
        return result;
    }

    @Override
    public List<IvmPdiOrYongsanIvResDTO> selectIvmPdiOrYongsanIvList(ComIvmReqDTO comIvmReqDTO) throws Exception {
        List<IvmPdiOrYongsanIvResDTO> result = new ArrayList<IvmPdiOrYongsanIvResDTO>();
        result = comIvmDAO.selectIvmPdiOrYongsanIvList(comIvmReqDTO);
        return result;
    }

    /*
     * @see com.oms.ivm.service.ComIvmService#getSysDate2()
     */
    @Override
    public HashMap<String, String> getSysDate2() throws Exception {
        return comIvmDAO.getSysDate2();
    }


}
