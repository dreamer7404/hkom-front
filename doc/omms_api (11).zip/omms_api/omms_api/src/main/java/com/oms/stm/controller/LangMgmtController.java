package com.oms.stm.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import able.cloud.core.web.HController;

import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.oms.common.dto.CommReqDTO;
import com.oms.common.service.CommService;
import com.oms.stm.dto.LangMgmtResDTO;
import com.oms.stm.dto.StmComReqDTO;
import com.oms.stm.service.LangMgmtService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;



/**
 * <pre>
 * Statements
 * </pre>
 * @ClassName : LangMgmtController.java
 * @Description :
 * @author 김경훈
 * @since 2023. 3. 23.
 * @see
 */
@Tag(name = "LanglMgmtController", description = "")
@CrossOrigin(origins="*")
@RequiredArgsConstructor
@RestController
@RequestMapping("/api")
public class LangMgmtController extends HController {

    /**
     * 클래스 Injection
     */
    private final HttpServletRequest request;
	private final LangMgmtService langMgmtService;
	private final CommService commService;

	@Operation(summary = "차종 조회")
	@GetMapping("/selectLangMgmtList")
	public LangMgmtResDTO selectLangMgmtList(@ModelAttribute StmComReqDTO dto, HttpServletRequest request) throws Exception {


            LangMgmtResDTO resDto = new LangMgmtResDTO();
            CommReqDTO comDto = new CommReqDTO();

            String userId = "H2302603";
	        dto.setUserId(userId);

	        List<LangMgmtResDTO> langMgmtList = langMgmtService.selectLangList(dto);
	        List<LangMgmtResDTO> dlExpdRegnCdList = commService.selectDlExpdRegnCdList(comDto);
            List<LangMgmtResDTO> langCdList = commService.selectLangCdList(comDto);
            List<LangMgmtResDTO> vehlList = commService.selectQltyVehlCdList(comDto);

	        resDto.setLangMgmtList(langMgmtList);
	        resDto.setDlExpdRegnCdList(dlExpdRegnCdList);
	        resDto.setLangCdList(langCdList);
	        resDto.setVehlList(vehlList);

//	            mv.addObject("expdPdiNm", request.getParameter("expdPdiNm"));
//	            mv.addObject("qltyVehlCd", request.getParameter("qltyVehlCd"));
//	            mv.addObject("sMy", request.getParameter("sMy"));
//	            mv.addObject("dlExpdRegnCd", request.getParameter("dlExpdRegnCd"));
//	            mv.addObject("langCd", request.getParameter("langCd"));
//
//	            mv.addObject("userNm", userNm);
	        return resDto;
	    }






}