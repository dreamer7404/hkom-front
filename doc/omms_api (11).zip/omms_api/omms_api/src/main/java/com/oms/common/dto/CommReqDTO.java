package com.oms.common.dto;

import org.apache.ibatis.type.Alias;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @author 안경수
 * @since 2023. 2. 8.
 * @see
 */

@Data
@NoArgsConstructor
@AllArgsConstructor
@Alias("commReqDTO")
public class CommReqDTO {
    @Schema(type = "string", example = " ")
    private String orderBy;

    private Integer pageNo;

    private Integer pageSize;

    @Schema(type = "string", example = " ")
    private String keyword;

    @Schema(type = "string", example = " ")
    private String userEeno;

    @Schema(type = "string", example = " ")
    private String dlExpdGCd; //selectVehlMgmtList 조회시 필요

}
