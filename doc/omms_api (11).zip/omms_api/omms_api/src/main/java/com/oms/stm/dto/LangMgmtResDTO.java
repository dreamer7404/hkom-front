package com.oms.stm.dto;

import java.sql.Timestamp;
import java.util.List;

import org.apache.ibatis.type.Alias;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName : LangMgmtResDTO.java
 * @Description :
 * @author 김경훈
 * @since 2023. 3. 23.
 * @see
 */
@Alias("langMgmtResDTO")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class LangMgmtResDTO {

    private String n1InsYn;
    private String aCode;
    private String sortSn;
    private String qltyVehlNm;
    private String qltyVehlCd;
    private String useYn;
    private String langcdnm;
    private String dlExpdRegnCd;
    private String langCd;
    private String dataSn;

    List<LangMgmtResDTO> langMgmtList;
    List<LangMgmtResDTO> dlExpdRegnCdList;
    List<LangMgmtResDTO> langCdList;
    List<LangMgmtResDTO> vehlList;

}
