package com.oms.ivm.dto;

import java.sql.Timestamp;

import org.apache.ibatis.type.Alias;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @author 김정웅
 * @since 2023. 3. 7.
 * @see
 */

@Alias("totIvmResDTO")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class TotIvmResDTO {

    private String clScnCd;
    private String dataSn;
    private String qltyVehlCd;
    private String mdlMdyCd;
    private String langCd;
    private String langSortSn;
    private String dlExpdRegnCd;
    private String qltyVehlNm;
    private String langCdNm;
    private String dlExpdRegnNm;
    private String currOrdQty;
    private String prevOrdQty;
    private String mth3TrwiQty;
    private String day3PlanQty;
    private String wek2PlanQty;
    private String currMthTrwiQty;
    private String prev1DayTrwiQty;
    private String sewhaIvQty;
    private String sewhaPrntYn;
    private String pdiIvQty;
    private String dsid14Qty;
    private String wek2AftrIvQty;
    private String prntState;
    private String prntStateNm;
    private String ivSum;
    private String nPrntPbcnNo;
    private String plntDay3QtyText;
    private String plntWek2QtyText;
    private String plntYn;
    private String prdnPlntCd;
    private String chkState;

}
