package com.oms.ivm.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import able.cloud.core.web.HController;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.oms.cmm.utils.Utils;
import com.oms.ivm.dto.ComIvmReqDTO;
import com.oms.ivm.dto.Ivm2WeekPlanReqDTO;
import com.oms.ivm.dto.Ivm2WeekPlanResDTO;
import com.oms.ivm.dto.Ivm3DayPlanReqDTO;
import com.oms.ivm.dto.Ivm3DayPlanResDTO;
import com.oms.ivm.dto.IvmPdiOrYongsanIvResDTO;
import com.oms.ivm.dto.IvmSewonIvResDTO;
import com.oms.ivm.dto.IvmThisMonTrwiResDTO;
import com.oms.ivm.service.ComIvmService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;


/**
 * <pre>
 * ComIvmController
 * </pre>
 *
 * @ClassName   : ComIvmController.java
 * @Description : 재고관리 > 공통 컨트롤러 (주간계획 팝업 등..)
 * @author 김정웅
 * @since 2023.3.13
 * @see
 */
@Tag(name = "ComIvmController", description = "")
//@CrossOrigin(origins="*")
@RequiredArgsConstructor
@RestController
@RequestMapping("/api")
public class ComIvmController extends HController {

    /**
     * 클래스 Injection
     */
    private final HttpServletRequest request;
    private final ComIvmService comIvmService;

    /**
     * 재고관리 > 주간계획(2주)||생산계획(2주)
     */
    @Operation(summary = "주간계획(2주)")
    @GetMapping("/ivm2WeekPlan")
    public List<Ivm2WeekPlanResDTO> selectIvm2WeekPlanList(@ModelAttribute Ivm2WeekPlanReqDTO reqDto) throws Exception {
        //사용자 ID, 회사코드 할당
        reqDto.setUserEeno(Utils.getUserEeno(request));
        reqDto.setDlExpdCoCd(Utils.getDlExpdCoCd(request));

        List<Ivm2WeekPlanResDTO> result = new ArrayList<Ivm2WeekPlanResDTO>();
        result = comIvmService.selectIvm2WeekPlanList(reqDto);

        return result;
    }

    /**
     * 재고관리 > 단기계획(3일)
     */
    @Operation(summary = "단기계획(3일)")
    @GetMapping("/ivm3DayPlan")
    public Ivm3DayPlanResDTO selectIvm3DayPlanList(@ModelAttribute Ivm3DayPlanReqDTO reqDto) throws Exception {
        //사용자 ID, 회사코드 할당
        reqDto.setUserEeno(Utils.getUserEeno(request));
        reqDto.setDlExpdCoCd(Utils.getDlExpdCoCd(request));

        Ivm3DayPlanResDTO result = new Ivm3DayPlanResDTO();
        result = comIvmService.selectIvm3DayPrdnPlanList(reqDto);
        return result;
    }

    /**
     * 재고관리 > 당월투입(누적)
     */
    @Operation(summary = "당월투입(누적)")
    @GetMapping("/ivmThisMonTrwis")
    public List<IvmThisMonTrwiResDTO> selectIvmThisMonTrwiList(@ModelAttribute ComIvmReqDTO reqDto) throws Exception {
        //사용자 ID, 회사코드 할당
        reqDto.setUserEeno(Utils.getUserEeno(request));
        reqDto.setDlExpdCoCd(Utils.getDlExpdCoCd(request));

        List<IvmThisMonTrwiResDTO> result = new ArrayList<IvmThisMonTrwiResDTO>();
        result = comIvmService.selectIvmThisMonTrwiList(reqDto);
        return result;
    }

    /**
     * 재고관리 > 세원 보유재고
     */
    @Operation(summary = "재고현황-세원보유재고")
    @GetMapping("/ivmSewonIvs")
    public List<IvmSewonIvResDTO> selectIvmSewonIvList(@ModelAttribute ComIvmReqDTO reqDto) throws Exception {
        //사용자 ID, 회사코드 할당
        reqDto.setUserEeno(Utils.getUserEeno(request));
        reqDto.setDlExpdCoCd(Utils.getDlExpdCoCd(request));

        List<IvmSewonIvResDTO> result = new ArrayList<IvmSewonIvResDTO>();
        result = comIvmService.selectIvmSewonIvList(reqDto);
        return result;

    }

    /**
     * 재고관리 > PDI/용산 재고
     */
    @Operation(summary = "PDI/용산재고")
    @GetMapping("/ivmPdiOrYongsanIvs")
    public List<IvmPdiOrYongsanIvResDTO> selectIvmPdiOrYongsanIvList(@ModelAttribute ComIvmReqDTO reqDto) throws Exception {
        //사용자 ID, 회사코드 할당
        reqDto.setUserEeno(Utils.getUserEeno(request));
        reqDto.setDlExpdCoCd(Utils.getDlExpdCoCd(request));

        List<IvmPdiOrYongsanIvResDTO> result = new ArrayList<IvmPdiOrYongsanIvResDTO>();
        result = comIvmService.selectIvmPdiOrYongsanIvList(reqDto);
        return result;

    }

}