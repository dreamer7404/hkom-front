package com.oms.stm.dto;

import java.util.List;

import org.apache.ibatis.type.Alias;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @author 안경수
 * @since 2023. 5. 8.
 * @see
 */
@Alias("vehlMgmtSaveDTO")
@Data
@NoArgsConstructor
public class VehlMgmtSaveDTO {
    private String dlExpdNatCd;
    private String dlExpdRegnCd;
    private String dlExpdCoCd;
    private String qltyVehlCd;
    private String pprrEeno;
    private String mdlMdyCd;
    private String langCd;
    private String natNm;
    private List<String> langs; // langCd

  
}
