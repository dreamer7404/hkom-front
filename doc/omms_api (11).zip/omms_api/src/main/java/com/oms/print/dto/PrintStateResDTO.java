package com.oms.print.dto;

import org.apache.ibatis.type.Alias;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName : PrintStateResDTO.java
 * @Description :
 * @author 김경훈
 * @since 2023. 5. 3.
 * @see
 */
@Alias("PrintStateResDTO")
@Data
@NoArgsConstructor
@AllArgsConstructor

public class PrintStateResDTO {

    private String newPrntPbcnNo;
    private String qltyVehlNm;
    private String langCdNm;
    private String prntParrYmd;
    private String dlvgParrYmd;
    private String iWayCd;
    private String prntParrQty;
    private String prntParrBgt;
    private String prntParrBgt2;
    private String saleUnp;
    private String prtlImtrSbc;
    private String reviseQty;
    private String qltyVehlCd;
    private String mdlMdyCd;
    private String langCd;
    private String clScnCd;
    private String dlExpdRegnCd;
    private String prtlImtrSbc2;
    private String prtlImtrSbc3;
    private String attcYn;
    private String iWayNm;
    private String regnNm;

}
