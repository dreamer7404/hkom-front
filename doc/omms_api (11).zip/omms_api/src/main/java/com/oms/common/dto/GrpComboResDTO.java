package com.oms.common.dto;

import java.sql.Timestamp;

import org.apache.ibatis.type.Alias;

import lombok.Data;

/**
 * <pre>
 * 그룹코드 콤보용
 * </pre>
 *
 * @author 안경수
 * @since 2023. 4. 5.
 * @see
 */
@Data
@Alias("grpComboResDTO")
public class GrpComboResDTO {
    private String grpCd;
    private String grpNm;
    private Integer sortSn;
    private String rem;
    private String useYn;
    private String pprrEeno;
    private Timestamp framDtm;
    private String updrEeno;
    private Timestamp mdfyDtm;
}
