package com.oms.ivm.dto;

import org.apache.ibatis.type.Alias;

import lombok.AllArgsConstructor;
import lombok.Data;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @author 김정웅
 * @since 2023. 3. 7.
 * @see
 */
@Alias("totIvmReqDTO")
@Data
@AllArgsConstructor
public class TotIvmReqDTO extends ComIvmReqDTO {

    private String menuId;
    private String dlExpdPdiCd;
    private String ivmState;
    private String postback;
    private String mainCd;
    private String subCd;
}
