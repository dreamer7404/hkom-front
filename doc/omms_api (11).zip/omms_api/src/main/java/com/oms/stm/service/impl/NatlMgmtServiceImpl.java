package com.oms.stm.service.impl;

import java.util.List;

import able.cloud.core.service.HService;

import org.springframework.stereotype.Service;

import com.oms.stm.dao.NatlMgmtDAO;
import com.oms.stm.dto.LangMgmtReqDTO;
import com.oms.stm.dto.LangMgmtResDTO;
import com.oms.stm.dto.NatlMgmtReqDTO;
import com.oms.stm.dto.NatlMgmtResDTO;
import com.oms.stm.dto.StmComReqDTO;
import com.oms.stm.service.NatlMgmtService;

import lombok.RequiredArgsConstructor;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @author 안경수
 * @since 2023. 2. 24.
 * @see
 */
@RequiredArgsConstructor
@Service("natlMgmtService")
public class NatlMgmtServiceImpl extends HService implements NatlMgmtService {

    private final NatlMgmtDAO natlMgmtDAO;


    /*
     * @see com.oms.stm.service.LangMgmtService#selectNatlCdMstList(com.oms.stm.dto.StmComReqDTO)
     */
    @Override
    public List<NatlMgmtResDTO> selectNatlCdMstList(StmComReqDTO dto) {
        // TODO Auto-generated method stub
        return natlMgmtDAO.selectNatlCdMstList(dto);
    }

    /*
     * @see com.oms.stm.service.LangMgmtService#insertNatlCdMst(com.oms.stm.dto.LangMgmtReqDTO)
     */
    @Override
    public int insertNatlCdMst(NatlMgmtResDTO dto) {
        // TODO Auto-generated method stub
        return natlMgmtDAO.insertNatlCdMst(dto);
    }

    /*
     * @see com.oms.stm.service.LangMgmtService#updateNatlCdMst(com.oms.stm.dto.LangMgmtReqDTO)
     */
    @Override
    public int updateNatlCdMst(NatlMgmtResDTO dto) {
        return natlMgmtDAO.updateNatlCdMst(dto);

    }

    /*
     * @see com.oms.stm.service.LangMgmtService#deleteNatlCdMst(com.oms.stm.dto.LangMgmtReqDTO)
     */
    @Override
    public int deleteNatlCdMst(NatlMgmtResDTO dto) {
        return natlMgmtDAO.deleteNatlCdMst(dto);
    }

    /*
     * @see com.oms.stm.service.NatlMgmtService#updateNatlVehlMgmt(com.oms.stm.dto.NatlMgmtReqDTO)
     */
    @Override
    public int updateNatlVehlMgmt(NatlMgmtReqDTO dto) {
        // TODO Auto-generated method stub
        return natlMgmtDAO.updateNatlVehlMgmt(dto);
    }


}
