package com.oms.ivm.service;

import java.util.List;

import com.oms.ivm.dto.ComIvmReqDTO;
import com.oms.ivm.dto.PdiIvmReqDTO;
import com.oms.ivm.dto.PdiIvmResDTO;
import com.oms.ivm.dto.PdiPrndMonitorReqDTO;
import com.oms.ivm.dto.PdiPrndMonitorResDTO;
import com.oms.ivm.dto.PdiWhsnReqDTO;
import com.oms.ivm.dto.PdiWhsnResDTO;


/**
 * <pre>
 * PdiIvmService
 * </pre>
 *
 * @ClassName   : PdiIvmService.java
 * @Description : 재고관리 > PDI재고관리 서비스
 * @author 김정웅
 * @since 2023.5.4
 * @see
 */

public interface PdiIvmService {

    //PDI 재고관리 현황
    public List<PdiIvmResDTO> selectPdiIvmList(PdiIvmReqDTO reqDto) throws Exception;

    //생산라인 모니터링 조회
    public PdiPrndMonitorResDTO selectPdiPrndMonitor(PdiPrndMonitorReqDTO reqDto) throws Exception;

    //출고현황입력 팝업-조회
    public List<PdiWhsnResDTO> selectPdiWhsnList(ComIvmReqDTO reqDto) throws Exception;

    //출고현황입력 팝업-저장(수정)
    public Integer insertPdiWhsnInfos(List<PdiWhsnReqDTO> reqDto, String userEeno) throws Exception;


//    //출고현황입력 팝업-삭제
//    public Integer deleteSewonWhotList(List<SewonWhotReqDTO> reqDto, String userEeno) throws Exception;
//
//    //재고보정입력 팝업-조회
//    public List<SewonIvModResDTO> selectIvModList(ComIvmReqDTO reqDto) throws Exception;
//    //재고보정입력 팝업-수정
//    public Integer insertIvModList(List<SewonIvModReqDTO> reqDto, String userEeno, String dlExpdCoCd) throws Exception;
//    //재고보정입력 팝업-삭제
//    public Integer deleteIvModList(List<SewonIvModReqDTO> reqDto, String userEeno, String dlExpdCoCd) throws Exception;
//
//    //출고현황
//    public List<SewonWhotResDTO> selectIvmSewonWhotList(ComIvmReqDTO reqDto) throws Exception;
//
//    //요청현황
//    public List<IvmRequestMonitorResDTO> selectIvmSewonReqStateList(ComIvmReqDTO reqDto) throws Exception;



}
