package com.oms.ivm.dao;

import java.util.HashMap;
import java.util.List;

import com.oms.ivm.dto.ComIvmReqDTO;
import com.oms.ivm.dto.Ivm2WeekPlanReqDTO;
import com.oms.ivm.dto.Ivm2WeekPlanResDTO;
import com.oms.ivm.dto.Ivm3DayPlanReqDTO;
import com.oms.ivm.dto.Ivm3DayPlanResDTO;
import com.oms.ivm.dto.IvmPdiOrYongsanIvResDTO;
import com.oms.ivm.dto.IvmSewonIvResDTO;
import com.oms.ivm.dto.IvmThisMonTrwiResDTO;

/**
 * <pre>
 * ComIvmDAO 인터페이스
 * </pre>
 *
 * @Class Name  : ComIvmDAO.java
 * @Description : 재고관리 > 공통 DAO
 * @author 김정웅
 * @since 2023.3.13
 * @see
*/
public interface ComIvmDAO {

    //2주 생산계획
    HashMap<String,String> getMsgPlanProd(Ivm2WeekPlanReqDTO reqDto) throws Exception;
    List<Ivm2WeekPlanResDTO> selectIvm2WeekPlanList(Ivm2WeekPlanReqDTO reqDto) throws Exception;
    List<Ivm2WeekPlanResDTO> selectIvm2WeekPlanListSummary(Ivm2WeekPlanReqDTO reqDto) throws Exception;

    //3일 단기계획
    HashMap<String,String> fuGetWrkdate(String bDate) throws Exception;
    HashMap<String,String> selectExpdPacScnCd(String dataSn, String userEeno) throws Exception;
    HashMap<String,Integer> selectIvmTodayPrdnPlanList(String dataSn, String bDate) throws Exception;
    HashMap<String,String> selectVFramYmd(String bDate) throws Exception;
    Ivm3DayPlanResDTO selectIvm3DayPrdnPlanList(Ivm3DayPlanReqDTO reqDto) throws Exception;

    //당월투입(누적)
    List<IvmThisMonTrwiResDTO> selectIvmThisMonTrwiList(ComIvmReqDTO reqDto);

    //세원보유재고
    List<IvmSewonIvResDTO> selectIvmSewonIvList(ComIvmReqDTO reqDto);

    //PDI/용산재고
    List<IvmPdiOrYongsanIvResDTO> selectIvmPdiOrYongsanIvList(ComIvmReqDTO reqDto) ;

    HashMap<String,String> getSysDate2();


}
