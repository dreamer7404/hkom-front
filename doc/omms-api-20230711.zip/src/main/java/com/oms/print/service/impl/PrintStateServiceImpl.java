package com.oms.print.service.impl;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import able.cloud.core.service.HService;

import org.springframework.stereotype.Service;

import com.oms.ivm.dto.TotIvmResDTO;
import com.oms.print.dao.PrintStateDAO;
import com.oms.print.dto.PrintStateComDTO;
import com.oms.print.dto.PrintStateReqDTO;
import com.oms.print.dto.PrintStateResDTO;
import com.oms.print.service.PrintStateService;
import com.oms.stm.dao.BoardDAO;
import com.oms.stm.dto.BoardReqDTO;
import com.oms.stm.dto.BoardResDTO;
import com.oms.stm.dto.PrntPageMgmtResDTO;
import com.oms.stm.service.BoardService;

import lombok.RequiredArgsConstructor;


/**
 * <pre>
 * Statements
 * </pre>
 * @ClassName : PrintStateServiceImpl.java
 * @Description :
 * @author 김경훈
 * @since 2023. 5. 3.
 * @see
 */
@RequiredArgsConstructor
@Service("PrintStateService")
public class PrintStateServiceImpl extends HService implements PrintStateService {

    private final PrintStateDAO printStateDao;

    /*
     * @see com.oms.print.service.PrintStateService#selectPrintStateList(com.oms.print.dto.PrintStateReqDTO)
     */
    @Override
    public List<PrintStateResDTO> selectPrintStateList(PrintStateReqDTO dto) {
        // TODO Auto-generated method stub
        return printStateDao.selectPrintStateList(dto);
    }

    /*
     * @see com.oms.print.service.PrintStateService#selectPrntFpInfo(com.oms.print.dto.PrintStateReqDTO)
     */
    @Override
    public PrintStateResDTO selectPrntFpInfo(PrintStateComDTO dto) {
        // TODO Auto-generated method stub
        return printStateDao.selectPrntFpInfo(dto);
    }

    /*
     * @see com.oms.print.service.PrintStateService#selectPrntApvlInfo(com.oms.print.dto.PrintStateComDTO)
     */
    @Override
    public PrintStateResDTO selectPrntApvlInfo(PrintStateComDTO dto) {
        // TODO Auto-generated method stub
        return printStateDao.selectPrntApvlInfo(dto);
    }

    /*
     * @see com.oms.print.service.PrintStateService#selectReviceInfoList(com.oms.print.dto.PrintStateComDTO)
     */
    @Override
    public List<PrintStateResDTO> selectReviceInfoList(PrintStateComDTO dto) {
        // TODO Auto-generated method stub
        return printStateDao.selectReviceInfoList(dto);
    }

    /*
     * @see com.oms.print.service.PrintStateService#selectTotalIvm(com.oms.print.dto.PrintStateComDTO)
     */
    @Override
    public List<TotIvmResDTO> selectTotalIvm(PrintStateComDTO dto) {
        // TODO Auto-generated method stub
          return printStateDao.selectTotalIvm(dto);
    }

    /*
     * @see com.oms.print.service.PrintStateService#outRequestChange(com.oms.print.dto.PrintStateReqDTO)
     */
    @Override
    public int outRequestChange(PrintStateReqDTO dto) {
        // TODO Auto-generated method stub
        return printStateDao.outRequestChange(dto);
    }

    /*
     * @see com.oms.print.service.PrintStateService#updatePrtlImtrSbc3(com.oms.print.dto.PrintStateReqDTO)
     */
    @Override
    public int updatePrtlImtrSbc3(PrintStateReqDTO dto) {
        // TODO Auto-generated method stub
        return printStateDao.updatePrtlImtrSbc3(dto);
    }

    /*
     * @see com.oms.print.service.PrintStateService#updateSaleUnp(com.oms.print.dto.PrintStateReqDTO)
     */
    @Override
    public int updateSaleUnp(PrintStateReqDTO dto) {
        // TODO Auto-generated method stub
        return printStateDao.updateSaleUnp(dto);
    }

    /*
     * @see com.oms.print.service.PrintStateService#updateSewhaIvInfoYmd(com.oms.print.dto.PrintStateReqDTO)
     */
    @Override
    public int updateSewhaIvInfoYmd(PrintStateReqDTO dto) {
        // TODO Auto-generated method stub
        return printStateDao.updateSewhaIvInfoYmd(dto);
    }

    /*
     * @see com.oms.print.service.PrintStateService#updateSewhaIvInfoDtlYmd(com.oms.print.dto.PrintStateReqDTO)
     */
    @Override
    public int updateSewhaIvInfoDtlYmd(PrintStateReqDTO dto) {
        // TODO Auto-generated method stub
        return printStateDao.updateSewhaIvInfoDtlYmd(dto);
    }

    /*
     * @see com.oms.print.service.PrintStateService#updateSewonDlvgParrYmd(com.oms.print.dto.PrintStateReqDTO)
     */
    @Override
    public int updateSewonDlvgParrYmd(PrintStateReqDTO dto) {
        // TODO Auto-generated method stub
        return printStateDao.updateSewonDlvgParrYmd(dto);
    }

    /*
     * @see com.oms.print.service.PrintStateService#selectPageInfoList(com.oms.print.dto.PrintStateComDTO)
     */
    @Override
    public List<PrntPageMgmtResDTO> selectPageInfoList(PrintStateComDTO dto) {
        // TODO Auto-generated method stub
        return printStateDao.selectPageInfoList(dto);
    }

    /*
     * @see com.oms.print.service.PrintStateService#selectMaxDeppc1Sn2(com.oms.print.dto.PrintStateComDTO)
     */
    @Override
    public int selectMaxDeppc2Sn(PrintStateComDTO dto) {
        // TODO Auto-generated method stub
        return printStateDao.selectMaxDeppc2Sn(dto);
    }

    /*
     * @see com.oms.print.service.PrintStateService#selectAlgnInfoList(com.oms.print.dto.PrintStateComDTO)
     */
    @Override
    public List<PrntPageMgmtResDTO> selectAlgnInfoList(PrintStateComDTO dto) {
        // TODO Auto-generated method stub
        return printStateDao.selectAlgnInfoList(dto);
    }

    /*
     * @see com.oms.print.service.PrintStateService#selectPrntPageYn(com.oms.print.dto.PrintStateComDTO)
     */
    @Override
    public String selectPrntPageYn(String prntNo) {
        // TODO Auto-generated method stub
        return printStateDao.selectPrntPageYn(prntNo);
    }

}





