package com.oms.print.controller;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import javax.servlet.http.HttpServletRequest;
import able.cloud.core.web.HController;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.oms.cmm.global.Consts;
import com.oms.cmm.utils.Utils;
import com.oms.ivm.dto.TotIvmResDTO;
import com.oms.print.dto.PrintStateComDTO;
import com.oms.print.dto.PrintStateReqDTO;
import com.oms.print.dto.PrintStateResDTO;
import com.oms.print.service.PrintStateService;
import com.oms.stm.dto.PrntPageMgmtReqDTO;
import com.oms.stm.dto.PrntPageMgmtResDTO;
import com.oms.stm.service.PrntPageMgmtService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;


/**
 * <pre>
 * Statements
 * </pre>
 * @ClassName : PrintStateController.java
 * @Description :
 * @author 김경훈
 * @since 2023. 5. 3.
 * @see
 */
@Tag(name = "PrintStateController", description = "")
@RequiredArgsConstructor
@RestController
@RequestMapping("/api")
public class PrintStateController extends HController {


    private final PrintStateService printStateService;
    private final PrntPageMgmtService prntPageMgmtService;
    private final HttpServletRequest request;

    @Operation(summary = "발간현황조회")
    @GetMapping("/printStates")
    public  List<PrintStateResDTO>  printStates(@ModelAttribute PrintStateReqDTO dto) throws Exception {

        String userEeno = Utils.getUserEeno(request);
        dto.setDlExpdCoCd(Utils.getDlExpdCoCd(request));
        dto.setUserEeno(userEeno);



        return printStateService.selectPrintStateList(dto);
    }


    @Operation(summary = "발간현황상세")
    @GetMapping("/printState")
    public  HashMap<String,Object>  printState(@ModelAttribute PrintStateComDTO dto) throws Exception {

        HashMap<String, Object> resultMap = new HashMap<String, Object>();
        dto.setUserEeno(Utils.getUserEeno(request));
        dto.setDlExpdCoCd(Utils.getDlExpdCoCd(request));

        PrintStateResDTO printStateInfo =  printStateService.selectPrntFpInfo(dto);


        // 현재 날짜 구하기
        LocalDate now = LocalDate.now();

        // 포맷 정의
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");

        // 포맷 적용
        String currDate = now.format(formatter);

        dto.setBDate(currDate);

        List<TotIvmResDTO> totalIvm = printStateService.selectTotalIvm(dto); //발간기준정보
        resultMap.put("totalIvm", totalIvm);
        try {
        if(printStateInfo== null) { /** 신,구발간번호로 검색된 값이 없을 때 */ //세부저장된 데이터가 없는경우


        PrntPageMgmtReqDTO prntDto = new PrntPageMgmtReqDTO();
        prntDto.setQltyVehlCd(dto.getQltyVehlCd());
        prntDto.setLangCd(dto.getLangCd());
        prntDto.setMdlMdyCd(dto.getMdlMdyCd());
        PrntPageMgmtResDTO ivOrdQty = prntPageMgmtService.selectIvOrdQty(prntDto);
        resultMap.put("ivOrdQty", ivOrdQty);

        /** 제작의뢰 내역조회 */
        PrintStateResDTO prntApvlInfo = printStateService.selectPrntApvlInfo(dto);
        resultMap.put("prntApvlInfoList", prntApvlInfo);
        String prntPageYn = printStateService.selectPrntPageYn(dto.getNewPrntPbcnNo());
        resultMap.put("prntPageYn", prntPageYn);


            if (prntApvlInfo != null) {
                dto.setNewPrntPbcnNo(prntApvlInfo.getNewPrntPbcnNo().replace("&#40;", "(").replace("&#41;", ")")); // 신인쇄발간번호);
                if(!"".equals(prntApvlInfo.getOldPrntPbcnNo()) && prntApvlInfo.getOldPrntPbcnNo()!= null) {
                    dto.setOldPrntPbcnNo(prntApvlInfo.getOldPrntPbcnNo().replace("&#40;", "(").replace("&#41;", ")")); // 구인쇄발간번호);
                }else{
                    dto.setOldPrntPbcnNo(prntApvlInfo.getOldPrntPbcnNo()); // 구인쇄발간번호);
                }

                prntApvlInfo.setPrntInsdPgSbc(prntApvlInfo.getPrntWayCd2());
                prntApvlInfo.setDlvgParrYmd(strDate((String)prntApvlInfo.getDlvgParrYmd()));
                prntApvlInfo.setNrFlmMkoNl(prntApvlInfo.getMdfyPgNl());
                prntApvlInfo.setDgtlPrntNl(prntApvlInfo.getPgNl());
                prntApvlInfo.setRqQty(prntApvlInfo.getPrntParrQty());
                prntApvlInfo.setExpdNl(prntApvlInfo.getPgNl());


                prntApvlInfo.setPgMgnSbc(prntApvlInfo.getPgMgnSbc().replace("&#42;", "*")); // 페이지크기내용

                /** 발행방법이 스티커, 리플렛일 경우 표지는 0 */
                if (prntApvlInfo.getPrntWayCd2().equals("04") || prntApvlInfo.getPrntWayCd2().equals("05")
                 || prntApvlInfo.getPrntWayCd2().equals("06") || prntApvlInfo.getPrntWayCd2().equals("07")) {

//                    resultMap.put("pgNI",Integer.parseInt(prntApvlInfo.getPgNl()));
                    prntApvlInfo.setPgNl(prntApvlInfo.getPgNl());


                } else {
                    resultMap.put("pgNI", 4 + Integer.parseInt( prntApvlInfo.getPgNl()));

                }
                resultMap.put("eofu1Nl", Integer.parseInt(prntApvlInfo.getPgNl()) - Integer.parseInt(( prntApvlInfo.getMdfyPgNl())));
            }
            List<PrintStateResDTO> reviceInfoList = printStateService.selectReviceInfoList(dto);
            resultMap.put("reviceInfoList", reviceInfoList);
//            resultMap.put("totalIvm", totalIvm);

            return resultMap;

        }  else  {
            List<PrintStateResDTO> reviceInfoList = printStateService.selectReviceInfoList(dto);
            resultMap.put("reviceInfoList", reviceInfoList);
            resultMap.put("prntApvlInfoList", printStateInfo);
//            resultMap.put("totalIvm", totalIvm);
        }


        } catch(Exception e) {
            e.printStackTrace();
        }


        return resultMap;


    }





    @Operation(summary = "인쇄배열표")
    @GetMapping("/prntAlgnPop")
    public  HashMap<String,Object>  prntAlgnPop(@ModelAttribute PrintStateComDTO dto) throws Exception {


        HashMap<String, Object> resultMap = new HashMap<String, Object>();
        List<PrntPageMgmtResDTO> pageInfoList = printStateService.selectPageInfoList(dto);
        List<PrntPageMgmtResDTO> algnInfoList = printStateService.selectAlgnInfoList(dto);


        int pageCount = pageInfoList.size();
        int algnCount = algnInfoList.size();

        String nPrntPbcnNo = dto.getNewPrntPbcnNo();
        if (pageCount == 0) {
            /** 신인쇄발간번호 조회시 값이 없을 때 */
            resultMap.put("msg", "none");
            return resultMap;
        }
        int mdfyCount1 = 0; // 수정된 페이지 수
        int deppc1Sn = 0; // 취급설명서 인쇄페이지 목차 일련번호
        int deppc2Sn = 0; // 취급설명서 인쇄페이지 목차 일련번호2
        int endPgSn = 0; // 끝페이지 일련번호
        int deppc1Sn2 = 0; // 취급설명서 인쇄페이지 목차 일련번호
        int deppc2Sn2 = 0; // 취급설명서 인쇄페이지 목차 일련번호2
        int dlExpdPrntPgSn = 0; // 취급설명서 인쇄페이지 일련번호

        int finalCount = 0; // 인쇄관리페이지에 저장된 총 페이지 수
        int sortCount = 0; // 마지막페이지 홀,짝 판별 카운트
        double n = 7; // 실제로 생성될 테이블 갯수(1~64행 생성)

        double nCount = 0; //

        String tmpText = "";
        String currentText = "";
        String currentText2 = "";
        if(pageCount >0) {
            for (int i = 0; i < pageInfoList.size(); i++) {
                nPrntPbcnNo = (String) pageInfoList.get(i).getNewPrntPbcnNo().replace("&#40;", "(").replace("&#41;", ")");
                finalCount += Integer.parseInt(String.valueOf(pageInfoList.get(i).getEndPgSn()));
                if (Integer.parseInt(String.valueOf(pageInfoList.get(i).getEndPgSn())) % 2 == 1) {
                    sortCount++;
                }
            }
            finalCount += sortCount;
        }

        if (Math.ceil(finalCount / 64.0) > n) {
            n = Math.ceil(finalCount / 64.0);
        }

        int maxDeppc1Sn = printStateService.selectMaxDeppc2Sn(dto);
        if (pageCount > 0) { // 인쇄페이지 관리에 저장된 값
            for (int i = 0; i < pageInfoList.size(); i++) {
                deppc1Sn = Integer.parseInt(String.valueOf(pageInfoList.get(i).getDeppc1Sn()));
                deppc2Sn = Integer.parseInt(String.valueOf(pageInfoList.get(i).getDeppc2sn()));
                endPgSn = Integer.parseInt(String.valueOf(pageInfoList.get(i).getEndPgSn()));
                nCount = 64 * n - finalCount;
                for (int j = 0; j < endPgSn; j++) {

                    if (deppc1Sn == maxDeppc1Sn - 1) {
                        currentText += "I" + "-" + (j + 1) + ",";
                    } else {
                        if (deppc1Sn == 0){
                            if(deppc2Sn == 1){
                                currentText += "S1" + "-" + (j + 1) + ",";
                            }else if (deppc2Sn == 2){
                                currentText += "S2" + "-" + (j + 1) + ",";
                            }else{
                                currentText += "S3" + "-" + (j + 1) + ",";
                            }
                        }else{
                            currentText += deppc1Sn + "-" + (j + 1) + ",";
                        }
                    }
                }
                if (endPgSn % 2 == 1) {
                    currentText += " " + ",";
                }
            }
            for (int k = 0; k < nCount; k++) {
                currentText += " " + ",";
            }
        }

        String arr[] = currentText.split(",");

        if (algnCount > 0) { // 인쇄배열 정보에 저장된 값
            List<String> tmpAlgnSaveList = new ArrayList<String>();
            mdfyCount1 = algnCount;
            for (int y = 0; y < algnCount; y++) {
                deppc2Sn2 = Integer.parseInt(String.valueOf(algnInfoList.get(y).getDeppc2sn()));
                deppc1Sn2 = Integer.parseInt(String.valueOf(algnInfoList.get(y).getDeppc1Sn()));
                dlExpdPrntPgSn = Integer.parseInt(String.valueOf(algnInfoList.get(y).getEndPgSn()));
                if (deppc1Sn2 == maxDeppc1Sn - 1) {
                    tmpAlgnSaveList.add("I" + "-" + dlExpdPrntPgSn);
                } else {
                    if (deppc1Sn2 == 0){
                        if(deppc2Sn2 == 1){
                            tmpAlgnSaveList.add("S1" + "-" + dlExpdPrntPgSn);
                        }else if (deppc2Sn2 == 2){
                            tmpAlgnSaveList.add("S2" + "-" + dlExpdPrntPgSn);
                        }else{
                            tmpAlgnSaveList.add("S3" + "-" + dlExpdPrntPgSn);
                        }
                    }else{
                        tmpAlgnSaveList.add(deppc1Sn2 + "-" + dlExpdPrntPgSn);
                    }
                }
            }
            for (int z = 0; z < arr.length; z++) {
                if (tmpAlgnSaveList.contains(arr[z])) {
                    currentText2 += arr[z] + ",";
                } else {
                    currentText2 += " " + ",";
                }
                /*
                 * if(tmpText.lastIndexOf(arr[z] + "&") > -1){
                 * currentText2 += arr[z] + ",";
                 * }else{
                 * currentText2 += " " + ",";
                 * }
                 */
            }
        } else {
            for (int y = 0; y < arr.length; y++) {
                currentText2 += " " + ",";
            }
        }

        resultMap.put("currentText", currentText);
        resultMap.put("currentText2", currentText2);

        return resultMap;

    }




    /**
     * 납품요청일자 변경
     */
    @Operation(summary = "납품요청일자 변경", description = "")
    @Parameter(in = ParameterIn.HEADER, name="_method")
    @PostMapping("/outRequestChange")
       public Integer outRequestChange(@RequestBody PrintStateReqDTO dto) throws Exception {
        String method = Utils.getMethod(request);
        dto.setUserEeno(Utils.getUserEeno(request));
        int result = 0;
        if(method.equals(Consts.UPDATE)) { // dto

            LocalDate currDate = LocalDate.now();
           String todayDate = currDate.toString();


           //오늘날짜와 납품예정일이 같을 경우 세원재고테이블, 세원재고상세테이블의 임시재고수량 수정
           if(todayDate.equals(dto.getDlvgParrYmd())) {
               result += printStateService.updateSewhaIvInfoYmd(dto);
               result += printStateService.updateSewhaIvInfoDtlYmd(dto);
           }
            result += printStateService.outRequestChange(dto);//제작의뢰테이블 납품일 변경
            result += printStateService.updateSewonDlvgParrYmd(dto); //세원입고테이블 납품일 변경
        }
        return result;

    }


    /**
     * 인쇄품의번호 입력
     */
    @Operation(summary = "인쇄품의번호 입력", description = "")
    @PostMapping(value = "/savePrintCostInputNo")
    public Integer savePrintCostInputNo(@RequestBody PrintStateReqDTO dto) throws Exception {

        String method = Utils.getMethod(request);
        dto.setUserEeno(Utils.getUserEeno(request));
        int result = 0;
        if(method.equals(Consts.UPDATE)) { // dto
            result=     printStateService.updatePrtlImtrSbc3(dto);
        }

        return result;
    }


    @Operation(summary = "인쇄비용 입력", description = "")
    @PostMapping("/savePrntBgt")
    public Integer savePrntBgt(@RequestBody PrintStateReqDTO dto) throws Exception {

        String method = Utils.getMethod(request);
        dto.setUserEeno(Utils.getUserEeno(request));
        int result = 0;
        // dto
         try{
            //            hmap.put("attcGbn", "P");
//            hmap.put("gbnSn", nPrntPbcnNo);
//
//            hmap.put("nPrntPbcnNo", nPrntPbcnNo);
//            hmap.put("prntParrBgt", prntParrBgt);
//            hmap.put("saleUnp", saleUnp);
//            hmap.put("rgnEeno", userId);
//            hmap.put("updrEeno", userId);

//            String filechg = request.getParameter("filechg");
//            String file2 = request.getParameter("file2");
//
//            if("Y".equals(filechg) && !file2.equals("")){
//                HMap printAttc =  printStateService.selectPrintAttcSn(hmap);
//
//                String filePath =  printAttc.get("filePath").toString();
//                File f1 = new File(filePath);
//
//                if(f1.exists()){
//                    boolean deleteFlag = f1.delete();
//
//                    if(deleteFlag){
//                        log.debug("file 삭제 성공 : ");
//                    }
//                    else{
//                        log.debug("file 삭제 실패 : ");
//                    }
//                }else{
//                    log.debug("file 없음 : ");
//                }
//            }
             if(method.equals(Consts.UPDATE)) {
                 result =printStateService.updateSaleUnp(dto);
             }

            }catch (Exception ex) {
                ex.printStackTrace();
            }

         return result;

    }


    public static String strDate(String date) {
        String yyyymmdd = date;

        if (yyyymmdd.length() == 6)
            return "20"+yyyymmdd.substring(0, 2) + "-"+yyyymmdd.substring(2, 4)  + "-"+ yyyymmdd.substring(4, 6);
        else if (yyyymmdd.length() >= 8)
            return yyyymmdd.substring(0, 4) + "-" + yyyymmdd.substring(4, 6) + "-" + yyyymmdd.substring(6, 8);
        else
            return yyyymmdd;
    }




}