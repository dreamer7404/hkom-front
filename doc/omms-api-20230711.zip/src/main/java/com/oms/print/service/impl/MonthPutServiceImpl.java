package com.oms.print.service.impl;

import java.util.ArrayList;
import java.util.List;

import able.cloud.core.service.HService;

import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.oms.ivm.dao.TotIvmDAO;
import com.oms.ivm.dto.IvmMonthOrdPrdReqDTO;
import com.oms.ivm.model.TbWrkDateMgmt;
import com.oms.print.dao.MonthPutDAO;
import com.oms.print.dto.MonthPutInfosResDTO;
import com.oms.print.dto.MonthPutReqDTO;
import com.oms.print.service.MonthPutService;

import lombok.RequiredArgsConstructor;


/**
 * <pre>
 * Statements
 * </pre>
 * @ClassName : MonthPutServiceImpl.java
 * @Description :
 * @author 김정웅
 * @since 2023. 6. 16.
 * @see
 */
@RequiredArgsConstructor
@Service("MonthPutService")
public class MonthPutServiceImpl extends HService implements MonthPutService {

    private final MonthPutDAO monthPutDao;
    private final TotIvmDAO totIvmDAO;

    @Override
    public List<MonthPutInfosResDTO> selectMonthPutList(MonthPutReqDTO reqDto) {
        ObjectMapper objectMapper = new ObjectMapper();
        IvmMonthOrdPrdReqDTO reqDtoTmp = objectMapper.convertValue(reqDto, IvmMonthOrdPrdReqDTO.class);


        List<TbWrkDateMgmt> dlist = new ArrayList<TbWrkDateMgmt>();
        try {
            dlist = totIvmDAO.selectTbWrkDateMgmtList(reqDtoTmp);
        } catch (Exception e) {
            e.printStackTrace();
        }
        for(int i = 0 ; i < dlist.size() ; i++ ){
            String col = "col"+i;
            String pcol = "pcol"+i;
            String qcol = "qcol"+i;

            String ymd = dlist.get(i).getYmd2();

            if("col0".equals(col)){  reqDto.setCol0(ymd);}
            if("col1".equals(col)){  reqDto.setCol1(ymd);}
            if("col2".equals(col)){  reqDto.setCol2(ymd);}
            if("col3".equals(col)){  reqDto.setCol3(ymd);}
            if("col4".equals(col)){  reqDto.setCol4(ymd);}
            if("col5".equals(col)){  reqDto.setCol5(ymd);}
            if("col6".equals(col)){  reqDto.setCol6(ymd);}
            if("col7".equals(col)){  reqDto.setCol7(ymd);}
            if("col8".equals(col)){  reqDto.setCol8(ymd);}
            if("col9".equals(col)){  reqDto.setCol9(ymd);}
            if("col10".equals(col)){ reqDto.setCol10(ymd);}
            if("col11".equals(col)){ reqDto.setCol11(ymd);}
            if("col12".equals(col)){ reqDto.setCol12(ymd);}
            if("col13".equals(col)){ reqDto.setCol13(ymd);}

            if("pcol0".equals(pcol)){  reqDto.setPcol0(ymd);}
            if("pcol1".equals(pcol)){  reqDto.setPcol1(ymd);}
            if("pcol2".equals(pcol)){  reqDto.setPcol2(ymd);}
            if("pcol3".equals(pcol)){  reqDto.setPcol3(ymd);}
            if("pcol4".equals(pcol)){  reqDto.setPcol4(ymd);}
            if("pcol5".equals(pcol)){  reqDto.setPcol5(ymd);}
            if("pcol6".equals(pcol)){  reqDto.setPcol6(ymd);}
            if("pcol7".equals(pcol)){  reqDto.setPcol7(ymd);}
            if("pcol8".equals(pcol)){  reqDto.setPcol8(ymd);}
            if("pcol9".equals(pcol)){  reqDto.setPcol9(ymd);}
            if("pcol10".equals(pcol)){ reqDto.setPcol10(ymd);}
            if("pcol11".equals(pcol)){ reqDto.setPcol11(ymd);}
            if("pcol12".equals(pcol)){ reqDto.setPcol12(ymd);}
            if("pcol13".equals(pcol)){ reqDto.setPcol13(ymd);}

            if("qcol0".equals(qcol)){  reqDto.setQcol0(ymd);}
            if("qcol1".equals(qcol)){  reqDto.setQcol1(ymd);}
            if("qcol2".equals(qcol)){  reqDto.setQcol2(ymd);}
            if("qcol3".equals(qcol)){  reqDto.setQcol3(ymd);}
            if("qcol4".equals(qcol)){  reqDto.setQcol4(ymd);}
            if("qcol5".equals(qcol)){  reqDto.setQcol5(ymd);}
            if("qcol6".equals(qcol)){  reqDto.setQcol6(ymd);}
            if("qcol7".equals(qcol)){  reqDto.setQcol7(ymd);}
            if("qcol8".equals(qcol)){  reqDto.setQcol8(ymd);}
            if("qcol9".equals(qcol)){  reqDto.setQcol9(ymd);}
            if("qcol10".equals(qcol)){ reqDto.setQcol10(ymd);}
            if("qcol11".equals(qcol)){ reqDto.setQcol11(ymd);}
            if("qcol12".equals(qcol)){ reqDto.setQcol12(ymd);}
            if("qcol13".equals(qcol)){ reqDto.setQcol13(ymd);}
        }

        List<MonthPutInfosResDTO> resultTmp = new ArrayList<MonthPutInfosResDTO>();
        List<MonthPutInfosResDTO> result = new ArrayList<MonthPutInfosResDTO>();

        //그리드 헤더용 날짜 시작
        MonthPutInfosResDTO tmp4 = new MonthPutInfosResDTO();
        tmp4.setQltyVehlCd("MONTH");
        for(int i = 0 ; i < dlist.size() ; i++ ){
            String col = "col"+i;

            String ymd = dlist.get(i).getYmd();
            if("ALL".equals(reqDto.getLangCd())){tmp4.setLangCd("ALL");}
            if("col0".equals(col)){  tmp4.setCol0(ymd);}
            if("col1".equals(col)){  tmp4.setCol1(ymd);}
            if("col2".equals(col)){  tmp4.setCol2(ymd);}
            if("col3".equals(col)){  tmp4.setCol3(ymd);}
            if("col4".equals(col)){  tmp4.setCol4(ymd);}
            if("col5".equals(col)){  tmp4.setCol5(ymd);}
            if("col6".equals(col)){  tmp4.setCol6(ymd);}
            if("col7".equals(col)){  tmp4.setCol7(ymd);}
            if("col8".equals(col)){  tmp4.setCol8(ymd);}
            if("col9".equals(col)){  tmp4.setCol9(ymd);}
            if("col10".equals(col)){ tmp4.setCol10(ymd);}
            if("col11".equals(col)){ tmp4.setCol11(ymd);}
            if("col12".equals(col)){ tmp4.setCol12(ymd);}
            if("col13".equals(col)){ tmp4.setCol13(ymd);}
        }
        result.add(tmp4);
        //그리드 헤더용 날짜 끝

        resultTmp = monthPutDao.selectMonthPutList(reqDto);
        for(MonthPutInfosResDTO row : resultTmp) {
            if(row.getQltyVehlCd().isEmpty()) {
                continue;
            }
            ObjectMapper objectMapper2 = new ObjectMapper();
            MonthPutInfosResDTO tmp1 = objectMapper2.convertValue(row, MonthPutInfosResDTO.class);
            tmp1.setFlag(3);
            tmp1.setGubun("투입수량");
            result.add(tmp1);

            MonthPutInfosResDTO tmp2 = objectMapper2.convertValue(row, MonthPutInfosResDTO.class);
            tmp2.setGubun("제작예산");
            result.add(tmp2);

            MonthPutInfosResDTO tmp3 = objectMapper2.convertValue(row, MonthPutInfosResDTO.class);
            tmp3.setGubun("제작수량");
            result.add(tmp3);

        }

        return result;
    }

}





