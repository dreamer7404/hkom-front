package com.oms.print.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import able.cloud.core.web.HController;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.oms.cmm.utils.Utils;
import com.oms.print.dto.MonthPutInfosResDTO;
import com.oms.print.dto.MonthPutReqDTO;
import com.oms.print.service.MonthPutService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;


/**
 * <pre>
 * Statements
 * </pre>
 * @ClassName : MonthPutController.java
 * @Description :
 * @author 김정웅
 * @since 2023. 6. 16.
 * @see
 */
@Tag(name = "MonthPutController", description = "")
@RequiredArgsConstructor
@RestController
@RequestMapping("/api")
public class MonthPutController extends HController {


    private final HttpServletRequest request;
    private final MonthPutService monthPutService;

    @Operation(summary = "월간투입현황")
    @GetMapping("/monthPutInfos")
    public  List<MonthPutInfosResDTO> selectMonthPutList(@ModelAttribute MonthPutReqDTO reqDto) throws Exception {
        //화면에서는 sMonth, eMonth로 전달받기 때문에 값을 다시 할당해줌. (쿼리 수정을 피하기위한 조치..)
        reqDto.setSDate(reqDto.getSMonth());
        reqDto.setEDate(reqDto.getEMonth());
        reqDto.setDlExpdCoCd(Utils.getDlExpdCoCd(request));

        List<MonthPutInfosResDTO> result = new ArrayList<MonthPutInfosResDTO>();
        result = monthPutService.selectMonthPutList(reqDto);
        return result;
    }
}