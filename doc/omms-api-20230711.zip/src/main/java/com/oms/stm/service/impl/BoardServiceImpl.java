package com.oms.stm.service.impl;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import able.cloud.core.service.HService;

import org.springframework.stereotype.Service;

import com.oms.common.dto.RcvrResDTO;
import com.oms.stm.dao.BoardDAO;
import com.oms.stm.dto.BoardReqDTO;
import com.oms.stm.dto.BoardResDTO;
import com.oms.stm.service.BoardService;
import com.oms.sys.dto.UsrMgmtResDTO;

import lombok.RequiredArgsConstructor;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @author 안경수
 * @since 2023. 2. 24.
 * @see
 */
@RequiredArgsConstructor
@Service("BoardService")
public class BoardServiceImpl extends HService implements BoardService {

    private final BoardDAO boardDao;

    /*
     * @see com.oms.stm.service.BoardService#selectBoardList(com.oms.stm.dto.BoardReqDTO)
     */
    @Override
    public List<BoardResDTO> selectBoardList(BoardReqDTO boardReqDTO) throws Exception{

            return boardDao.selectBoardList(boardReqDTO);
    }

    /*
     * @see com.oms.stm.service.BoardService#selectBoardGrpList(com.oms.stm.dto.BoardReqDTO)
     */
    @Override
    public List<BoardResDTO> selectBoardGrpList(BoardReqDTO boardReqDTO) throws Exception{

        return boardDao.selectBoardGrpList(boardReqDTO);
    }

 /*
 * @see com.oms.stm.service.BoardService#insertBoard(com.oms.stm.dto.BoardReqDTO, javax.servlet.http.HttpServletRequest)
 */
@Override
public Integer insertBoard(BoardReqDTO boardReqDTO) {
     return boardDao.insertBoard(boardReqDTO);
}

/*
 * @see com.oms.stm.service.BoardService#insertRcvrMgmt(com.oms.stm.dto.BoardReqDTO)
 */
@Override
public Integer insertRcvrMgmt(BoardReqDTO boardReqDTO) {
    return boardDao.insertRcvrMgmt(boardReqDTO);
}
/*
 * @see com.oms.stm.service.BoardService#deleteBoard(com.oms.stm.dto.BoardReqDTO)
 */
@Override
public Integer deleteBoard(BoardReqDTO boardReqDTO) {
    return boardDao.deleteBoard(boardReqDTO);
}

/*
 * @see com.oms.stm.service.BoardService#updateBoard(com.oms.stm.dto.BoardReqDTO)
 */
@Override
public Integer updateBoard(BoardReqDTO boardReqDTO) {
    return boardDao.updateBoard(boardReqDTO);
   }

/*
 * @see com.oms.stm.service.BoardService#selectBoardOne(com.oms.stm.dto.BoardReqDTO)
 */
@Override
public BoardResDTO selectBoardOne(BoardReqDTO boardReqDTO) {
    // TODO Auto-generated method stub
    return boardDao.selectBoardOne(boardReqDTO);
}

/*
 * @see com.oms.stm.service.BoardService#selectRcvrList(com.oms.stm.dto.BoardReqDTO)
 */
@Override
public List<UsrMgmtResDTO> selectRcvrList(BoardReqDTO boardReqDTO) {
    // TODO Auto-generated method stub
    return boardDao.selectRcvrList(boardReqDTO);
}

/*
 * @see com.oms.stm.service.BoardService#selectRcvrChkList(com.oms.stm.dto.BoardReqDTO)
 */
@Override
public List<RcvrResDTO> selectRcvrChkList(BoardReqDTO boardReqDTO) {
    // TODO Auto-generated method stub
    return  boardDao.selectRcvrChkList(boardReqDTO);
}

/*
 * @see com.oms.stm.service.BoardService#deleteBoardRecvr(com.oms.stm.dto.BoardReqDTO)
 */
@Override
public int deleteBoardRecvr(BoardReqDTO boardReqDTO) {
    // TODO Auto-generated method stub
    return  boardDao.deleteBoardRecvr(boardReqDTO);
}

/*
 * @see com.oms.stm.service.BoardService#deleteBoardMulti(com.oms.stm.dto.BoardReqDTO)
 */
@Override
public int deleteBoardMulti(BoardReqDTO boardReqDTO) {
    // TODO Auto-generated method stub
    return  boardDao.deleteBoardMulti(boardReqDTO);
}

/*
 * @see com.oms.stm.service.BoardService#deleteBoardRecvrMulti(com.oms.stm.dto.BoardReqDTO)
 */
@Override
public int deleteBoardRecvrMulti(BoardReqDTO boardReqDTO) {
    // TODO Auto-generated method stub
    return boardDao.deleteBoardRecvrMulti(boardReqDTO);
}



}





