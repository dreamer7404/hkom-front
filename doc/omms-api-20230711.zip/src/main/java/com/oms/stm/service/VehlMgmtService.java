package com.oms.stm.service;

import java.util.HashMap;
import java.util.List;

import com.oms.stm.dto.StmComReqDTO;
import com.oms.stm.dto.VehlCrgrMgmtSaveDTO;
import com.oms.stm.dto.VehlMdyMgmtReqDTO;
import com.oms.stm.dto.VehlMdyMgmtResDTO;
import com.oms.stm.dto.VehlMgmtCrgDTO;
import com.oms.stm.dto.VehlMgmtReqDTO;
import com.oms.stm.dto.VehlMgmtResDTO;
import com.oms.stm.dto.VehlMgmtSaveDTO;



/**
 * <pre>
 * Statements
 * </pre>
 * @ClassName : VehlMgmtService.java
 * @Description :
 * @author 김경훈
 * @since 2023. 3. 13.
 * @see
 */
public interface VehlMgmtService {

    /**
     * Statements
     *
     * @param vehlReqDTO
     * @return
     */
    List<VehlMgmtResDTO> selectVehlMgmtList(HashMap<String, Object> map);

    /**
     * Statements
     *
     * @param vehlReqDTO
     * @return
     */
    List<VehlMgmtResDTO> selectCpyTgVehl(StmComReqDTO dto);

    /**
     * Statements
     *
     * @param vehlReqDTO
     * @return
     */
    String selectNatlVehlChk(VehlMgmtReqDTO vehlReqDTO);

    /**
     * Statements
     *
     * @param vehlReqDTO
     */
    int insertNatlVehlMgmt(VehlMgmtSaveDTO vehlMgmtSaveDTO);

    /**
     * Statements
     *
     * @param vehlReqDTO
     */
    void deleteVehlLangCp(VehlMgmtReqDTO vehlReqDTO);

    /**
     * Statements
     *
     * @param vehlReqDTO
     */
    void insertVehlLangCopy(VehlMgmtReqDTO vehlReqDTO);

    /**
     * Statements
     *
     * @param vehlReqDTO
     */
    void deleteVehlNatlLang(VehlMgmtReqDTO vehlReqDTO);

    /**
     * Statements
     *
     * @param vehlReqDTO
     */
    void insertVehlNatlLangCpy(VehlMgmtReqDTO vehlReqDTO);

    /**
     * Statements
     *
     * @param vehlReqDTO
     * @return
     */
    List<VehlMgmtResDTO> selectCpyTgNatlVehl(VehlMgmtReqDTO vehlReqDTO);

    /**
     * Statements
     *
     * @param vehlReqDTO
     * @return
     */
    List<HashMap<String, Object>> selectVehlMgmtNatlLangList(StmComReqDTO dto);

    /**
     *
     * Statements
     *
     * @param vehlReqDTO
     */
    int deleteVehlMgmtCrgr(VehlMgmtReqDTO vehlReqDTO);

    /**
     * Statements
     *
     * @param list
     * @return
     */
    int insertVehlMgmtCrgr(List<VehlCrgrMgmtSaveDTO> list);

    /**
     * Statements
     *
     * @param vehlReqDTO
     */
    void deleteVehlMgmtRegnRelCd(VehlMgmtReqDTO vehlReqDTO);

    /**
     * Statements
     *
     * @param vehlReqDTO
     */
    void deleteVehlDlExpdMdyMgmt(VehlMgmtReqDTO vehlReqDTO);

    /**
     * Statements
     *
     * @param vehlReqDTO
     */
    void insertVehlMgmtRegnRelCd(VehlMgmtReqDTO vehlReqDTO);

    /**
     * Statements
     *
     * @param vehlReqDTO
     */
    void insertVehlDlExpdMdyMgmt(VehlMgmtReqDTO vehlReqDTO);

    /**
     * Statements
     *
     * @param vehlReqDTO
     */
    void deleteVehlMgmtAltn(VehlMgmtReqDTO vehlReqDTO);

    /**
     * Statements
     *
     * @param vehlReqDTO
     */
    void insertVehlMgmtAltn(VehlMgmtReqDTO vehlReqDTO);

    /**
     * Statements
     *
     * @param vehlReqDTO
     */
    void deleteNatlVehlLang(VehlMgmtReqDTO vehlReqDTO);

    /**
     * Statements
     *
     * @param vehlReqDTO
     */
    int insertNatlVehlLang(VehlMgmtSaveDTO vehlMgmtSaveDTO);

    /**
     * Statements
     *
     * @param vehlReqDTO
     */
    void updateVehlMgmtMain(VehlMgmtReqDTO vehlReqDTO);

    /**
     * Statements
     *
     * @param vo
     * @return
     */
    List<VehlMgmtResDTO> selectDlExpdMdyPreList(VehlMgmtReqDTO vo);

    /**
     * Statements
     *
     * @param hmap
     * @return
     */
    List<VehlMgmtResDTO> selectDlExpdMdyNextList(VehlMgmtReqDTO vo);

    /**
     * Statements
     *
     * @param hmap
     * @return
     */
    List<VehlMgmtResDTO> selectVehlLangList(VehlMgmtReqDTO vo);

    /**
     * Statements
     *
     * @param vo
     */
    void deleteVehlLang(VehlMgmtReqDTO vo);

    /**
     * Statements
     *
     * @param vo
     */
    void insertVehlLangInfo(VehlMgmtReqDTO vo);

    /**
     * Statements
     *
     * @param vehlReqDTO
     * @return
     */
    String selectVehlMgmtCnt(VehlMgmtReqDTO vehlReqDTO);

    /**
     * Statements
     *
     * @param vehlReqDTO
     */
    void insertVehlMgmtMain(VehlMgmtReqDTO vehlReqDTO);

    /**
     * Statements
     *
     * @param vehlReqDTO
     * @return
     */
    List<VehlMgmtResDTO> selectPreVehlMdyChk(VehlMgmtReqDTO vehlReqDTO);

    /**
     * Statements
     *
     * @param reqDto
     * @return
     */
    List<VehlMgmtReqDTO> selectMdyMonth(StmComReqDTO dto);

    /**
     * Statements
     *
     * @param vehlReqDTO
     * @return
     */
    List<VehlMgmtResDTO> getVehlCombo(StmComReqDTO dto);

    /**
     * Statements
     *
     * @param vehlReqDTO
     * @return
     */
    List<VehlMgmtResDTO> getPdiCombo(StmComReqDTO vehlReqDTO);

    /**
     * Statements
     *
     * @param dto
     * @return
     */
    List<VehlMgmtResDTO> selectDlExpdPacScnCdList(StmComReqDTO dto);

    /**
     * Statements
     *
     * @param vehlReqDTO
     * @return
     */
    String selectVehlMdyChk(VehlMgmtReqDTO vehlReqDTO);

    /**
     * Statements
     *
     * @param map
     * @return
     */
    VehlMgmtResDTO selectVehlMgmtInfo(HashMap<String, Object> map);

    /**
     * Statements
     *
     * @param map
     * @return
     */
    List<VehlMgmtCrgDTO> selectVehlChrgList(HashMap<String, Object> map);

    /**
     * Statements
     *
     * @param crgDto
     * @return
     */
    int insertHmcVehlAuth(VehlMgmtCrgDTO crgDto);

    /**
     * Statements
     *
     * @param map
     * @return
     */
    List<HashMap<String, Object>> selectVehlMdyList(HashMap<String, Object> map);

    /**
     * Statements
     *
     * @param dto
     * @return
     */
    VehlMdyMgmtResDTO selectMdyChk1(VehlMdyMgmtReqDTO dto);

    /**
     * Statements
     *
     * @param dto
     * @return
     */
    VehlMdyMgmtResDTO selectMdyChk2(VehlMdyMgmtReqDTO dto);

    /**
     * Statements
     *
     * @param dto
     * @return
     */
    VehlMdyMgmtResDTO selectMdyChk3(VehlMdyMgmtReqDTO dto);

    /**
     * Statements
     *
     * @param dto
     * @return
     */
    int insertVehlMdyInfo(VehlMdyMgmtReqDTO dto);

    /**
     * Statements
     *
     * @param dto
     * @return
     */
    int updateVehlMdyInfo(VehlMdyMgmtReqDTO dto);

    /**
     * Statements
     *
     * @param dto
     * @return
     */
    int updateVehlMdyEndInfo(VehlMdyMgmtReqDTO dto);

    /**
     * Statements
     *
     * @param dto
     * @return
     */
    int updateVehlPreMdyInfo(VehlMdyMgmtReqDTO dto);

    /**
     * Statements
     *
     * @param vehlReqDTO
     */
    void spRecalculateSewonIvDtl3(VehlMgmtReqDTO vehlReqDTO);

    /**
     * Statements
     *
     * @param vehlReqDTO
     */
    void spRecalculatePdiIvDtl3(VehlMgmtReqDTO vehlReqDTO);

    /**
     * Statements
     *
     * @param mdyDto
     * @return
     */
    VehlMdyMgmtResDTO selectVehlMdyMgmt(VehlMdyMgmtReqDTO mdyDto);

    /**
     * Statements
     *
     * @param dto
     * @return
     */
    VehlMdyMgmtReqDTO prvsVehlMdyInfo(VehlMdyMgmtReqDTO dto);

    /**
     * Statements
     *
     * @param dto
     * @return
     */
    VehlMdyMgmtReqDTO nextVehlMdyInfo(VehlMdyMgmtReqDTO dto);

    /**
     * Statements
     *
     * @param dto
     */
    void updateVehlNextMdyInfo(VehlMdyMgmtReqDTO dto);

    /**
     * Statements
     *
     * @param mdyDto
     * @return
     */
    String selectMaxInfoYn(VehlMdyMgmtReqDTO mdyDto);

    /**
     * Statements
     *
     * @param dto
     */
    void deleteVehlMdy(VehlMdyMgmtReqDTO dto);

    /**
     * Statements
     *
     * @param dto
     */
    void updateAftDelMdyInfo(VehlMdyMgmtReqDTO dto);






}
