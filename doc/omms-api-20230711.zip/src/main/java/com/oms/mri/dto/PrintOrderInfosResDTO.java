package com.oms.mri.dto;

import java.util.Set;

import org.apache.ibatis.type.Alias;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.oms.common.dto.CommReqDTO;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * <pre>
 * PrintOrderInfosResDTO
 * </pre>
 *
 * @author 김정웅
 * @since 2023. 5. 11.
 * @see
 */
@Alias("printOrderInfosResDTO")
@Data
@AllArgsConstructor
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown =true)
public class PrintOrderInfosResDTO {

    private String iWayCd;
    private String iiWayCdNm; //앞에 i 하나만 붙일경우 카멜케이스가 안됨.
    private String expdPacScnNm;
    private String mdlMdyNm;
    private String qltyVehlNm;
    private String expdRegnNm;
    private String expdRegnCd;
    private String langCdNm;
    private String ordnRqstYmd;
    private String dlvgParrYmd;
    private String prntParrQty;
    private String userNm;
    private String trtmRst;
    private String trtmRstCd;
    private String dlExpdPrvsCd;
    private String qltyVehlCd;
    private String mdlMdyCd;
    private String langCd;
    private String newPrntPbcnNo;
    private String oldPrntPbcnNo;
    private String clScnCd;
    private String prntWayNm;
    private String prntWayNm2;
    private String depq1Nm;
    private String dlExpdRegnCd;
    private String dlExpdRegnNm;
    private String dlExpdPdiCd;


}
