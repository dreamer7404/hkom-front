package com.oms.mri.dto;

import java.util.List;
import java.util.Set;

import org.apache.ibatis.type.Alias;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.oms.common.dto.CommReqDTO;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * <pre>
 * PrintOrderPageReqDTO
 * </pre>
 *
 * @author 김정웅
 * @since 2023. 6. 9.
 * @see
 */
@Alias("printOrderPageReqDTO")
@Data
@AllArgsConstructor
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown =true)
public class PrintOrderPageReqDTO {

    private String userEeno;
    private String dlExpdCoCd;

    private String dlExpdMdlMdyCd;
    private String coverAttcSn;
    private String oldPrntPbcnNo;
    private String oordEditPgNl;
    private String updrEeno;
    private String prntWayCd;
    private String prntWayCdNm;
    private String mdlMdyCd;
    private String framDtm;
    private String attcYn;
    private String ordQty;
    private String dlvgParrYmd;
    private String csetCrgrEeno;
    private String prntParrBgt;
    private String qltyVehlCd;
    private String prntParrYmd;
    private String depc1Yn;
    private String mdfyDtm;
    private String ordnRqstYmd;
    private String depq1Cd;
    private String prntWayCd2;
    private String prtlImtrSbc;
    private String moAvgPrdnQty;
    private String crgrEeno;
    private String pgNl;
    private String oldPrntPbcnNo1;
    private String iWayCd;
    private String saleUnp;
    private String newPrntPbcnNo;
    private String pprrEeno;
    private String mdfyPgNl;
    private String grnDocNl;
    private String langCdNm;
    private String USER_NM;
    private String innerAttcSn;
    private String qltyVehlNm;
    private String ivQty;
    private String langCd;
    private String prntParrQty;
    private String pgMgnSbc;

    private String lrnkCd;
    private int deppc1Sn;
    private int deppc2Sn;
    private String dlExpdPrntPgSn;
    private String prntInsdPgSbc;
    private String deppr1Yn;

    private List<String> checkedValues; //인쇄배열표 리스트


}
