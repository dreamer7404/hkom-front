package com.oms.ship.dao;

import java.util.List;

import com.oms.ship.dto.ShipStateReqDTO;
import com.oms.ship.dto.ShipStateResDTO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName : ShipStateDAO.java
 * @Description :
 * @author 김경훈
 * @since 2023. 7. 7.
 * @see
 */
public interface ShipStateDAO {

    /**
     * Statements
     *
     * @param dto
     * @return
     */
    List<ShipStateResDTO> selectShipStateList(ShipStateReqDTO dto);

}
