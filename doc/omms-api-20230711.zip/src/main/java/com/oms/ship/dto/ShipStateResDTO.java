package com.oms.ship.dto;

import org.apache.ibatis.type.Alias;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@Alias("shipStateResDTO")
@Data
@NoArgsConstructor
@AllArgsConstructor

public class ShipStateResDTO {
    private String vin;
    private String shipDistCd;
    private String shipDistNm;
    private String saleDistCd;
    private String saleDistNm;
    private String portCd;
    private String portNm;
    private String mdlCd;
    private String mdlNm;
    private String mdyCd;
    private String statCd;
    private String statNm;
    private String prodYmd;
    private String mpoolYmd;
    private String shipYmd;
    private String etaYmd;
    private String portArrvYmd;
    private String compInYmd;
    private String wholSaleYmd;
    private String rtYmd;
    private String crDt;
    private String exclCd;
    private String exclNm;
    private String cdgb;

}
