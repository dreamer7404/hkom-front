package com.oms.ship.controller;


import java.util.List;

import javax.servlet.http.HttpServletRequest;
import able.cloud.core.web.HController;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


import com.oms.ship.dto.ShipStateReqDTO;
import com.oms.ship.dto.ShipStateResDTO;
import com.oms.ship.service.ShipStateService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;



/**
 * <pre>
 * Statements
 * </pre>
 * @ClassName : ShipStateController.java
 * @Description :
 * @author 김경훈
 * @since 2023. 7. 7.
 * @see
 */
@Tag(name = "ShipStateController", description = "")
@RequiredArgsConstructor
@RestController
@RequestMapping("/api")
public class ShipStateController extends HController {

    /**
     * 클래스 Injection
     */
    private final ShipStateService shipStateService;
    private final HttpServletRequest request;

    @Operation(summary = "선적현황조회")
    @GetMapping("/shipInfos")
    public  List<ShipStateResDTO>  shipStates(@ModelAttribute ShipStateReqDTO dto) throws Exception {


        return shipStateService.selectShipStateList(dto);
    }


}