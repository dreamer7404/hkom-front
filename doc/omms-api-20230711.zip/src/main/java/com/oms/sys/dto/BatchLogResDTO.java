package com.oms.sys.dto;

import java.sql.Timestamp;

import org.apache.ibatis.type.Alias;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;



/**
 * <pre>
 * Statements
 * </pre>
 * @ClassName : BatchResDTO.java
 * @Description :
 * @author 김경훈
 * @since 2023. 6. 14.
 * @see
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Alias("batchLogResDTO")
public class BatchLogResDTO {

    private String logSn;
    private String btchNm;
    private String btchFinStrtDtm;
    private String btchFnhDtm;
    private String btchWkCd;
    private String btchWkRsltSbc;
    private String ahScdCd;
}
