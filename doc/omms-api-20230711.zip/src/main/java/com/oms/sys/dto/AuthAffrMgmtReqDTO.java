package com.oms.sys.dto;

import java.util.List;

import org.apache.ibatis.type.Alias;

import com.oms.sys.model.AuthAffrMgmt;

import lombok.Data;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @author 안경수
 * @since 2023. 4. 26.
 * @see
 */
@Alias("authAffrMgmtReqDTO")
@Data
public class AuthAffrMgmtReqDTO {
    private String pgmId;   // 콤보용
    private String menuId;  // 메뉴그룹별 수정
    private String grpCd;   // 권한그룹별 수정
    private List<AuthAffrMgmt> list;
}
