package com.oms.sys.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.oms.sys.dto.LogUseReqDTO;
import com.oms.sys.dto.LogUseResDTO;
import com.oms.sys.service.LogService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @author 안경수
 * @since 2023. 5. 23.
 * @see
 */
@Tag(name = "LogController", description = "")
@RequiredArgsConstructor
@RestController
@RequestMapping("/api")
public class LogController {

    /**
     * 클래스 Injection
     */
    private final LogService logService;
    private final HttpServletRequest request;

    /**
     *
     */
    @Operation(summary = "사용 목록 조회 ")
    @GetMapping("/logUses")
    public List<LogUseResDTO> selectLogUseList(@ModelAttribute LogUseReqDTO logUseReqDTO) throws Exception {
        List<LogUseResDTO> list = logService.selectLogUseList(logUseReqDTO);
        return list;
    }

    /**
     *
     */
    @Operation(summary = "사용 목록 개수 ")
    @GetMapping("/logUsesTot")
    public Integer selectLogUseListTot(@ModelAttribute LogUseReqDTO logUseReqDTO) throws Exception {
        return logService.selectLogUseListTot(logUseReqDTO);
    }








}
