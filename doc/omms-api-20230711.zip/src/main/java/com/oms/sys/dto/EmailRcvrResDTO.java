package com.oms.sys.dto;

import java.sql.Timestamp;

import org.apache.ibatis.type.Alias;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName : EmailResDTO.java
 * @Description :
 * @author 김경훈
 * @since 2023. 6. 15.
 * @see
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Alias("emailRcvrResDTO")
public class EmailRcvrResDTO {

    private String rcvrId;
    private String pprrEeno;
    private String framDtm;
    private String emlScdCd;
    private String emlScdNm;
    private String rcvrNm;
}
