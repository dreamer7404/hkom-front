package com.oms.sys.dto;

import java.sql.Timestamp;

import lombok.AllArgsConstructor;
import lombok.Data;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @author Windows ≫c¿eAU
 * @since 2023. 2. 14.
 * @see
 */
@Data
@AllArgsConstructor
public class AuthResDTO {
    private String token;
    private String browserId; // uuid
    private String userEeno;
    private String blnsCoCd;
    private String userDcd;
    private String grpCd;
    private String userOsetLgi;

}
