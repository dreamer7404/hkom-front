package com.oms.sys.dto;

import org.apache.ibatis.type.Alias;

import com.oms.common.dto.CommReqDTO;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


/**
 * <pre>
 * Statements
 * </pre>
 * @ClassName : FileUploadLogResDTO.java
 * @Description :
 * @author 김경훈
 * @since 2023. 6. 19.
 * @see
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Alias("fileUploadLogResDTO")

public class FileUploadLogResDTO   extends CommReqDTO{
    private String filCd;
    private String fileNm;
    private String filDtm;
    private String useType;
    private String userId;
    private String coNm;
    private String deptNm;
    private String userNm;
    private String userIp;
    private String filGbn;
    private String attcSn;
    private String pgmId;
    private String actId;
    private String dnlMgn;
}
