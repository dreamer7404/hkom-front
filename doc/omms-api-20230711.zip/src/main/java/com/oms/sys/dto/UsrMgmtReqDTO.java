package com.oms.sys.dto;

import java.util.List;
import org.apache.ibatis.type.Alias;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @author 안경수
 * @since 2023. 1. 31.
 * @see
 */

@Alias("usrMgmtReqDTO")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class UsrMgmtReqDTO{
    private String userEeno;
    private String userPw;
    private String userNm;
    private String blnsCoCd;
    private String userDcd;
    private String userEmlAdr;
    private String useYn;
    private String grpCd;
    private String pprrEeno;
    private String dlExpdCoCd;
    private String userOsetLgi;

    private List<AuthVehlSaveDTO> usrVehls;
}
