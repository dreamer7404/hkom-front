package com.oms.sys.dao;

import java.util.List;

import com.oms.sys.dto.TestIvmTotalReqDTO;
import com.oms.sys.dto.TestIvmTotalResDTO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @author Windows ≫c¿eAU
 * @since 2023. 3. 13.
 * @see
 */

public interface TestDAO {
    String testBatch() throws Exception;
//    List<TestIvmTotalResDTO> selectTotalIvmList(TestIvmTotalReqDTO testIvmTotalReqDTO) throws Exception;
}
