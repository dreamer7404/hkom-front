package com.oms.sys.controller;

import java.util.List;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


import com.oms.sys.dto.AuthChangeLogResDTO;
import com.oms.sys.dto.FileUploadLogResDTO;
import com.oms.sys.dto.LogComReqDTO;

import com.oms.sys.service.AuthChangeLogService;
import com.oms.sys.service.FileUploadLogService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;


/**
 * <pre>
 * Statements
 * </pre>
 * @ClassName : FileUploadLogController.java
 * @Description :
 * @author 김경훈
 * @since 2023. 6. 19.
 * @see
 */
@Tag(name = "FileUploadLogController", description = "")
@RequiredArgsConstructor
@RestController
@RequestMapping("/api")
public class FileUploadLogController {

    /**
     * 클래스 Injection
     */
    private final FileUploadLogService fileUploadService;
        /**
     * 
     */
    @Operation(summary = "파일업로드 목록 조회 ")
    @GetMapping("/fileUploadHistorys")
    public List<FileUploadLogResDTO> fileUploadHistorys(@ModelAttribute LogComReqDTO dto) throws Exception {
        return fileUploadService.fileUploadHistorys(dto);
    }


    /**
     * Batch 목록을 조회
     */
    @Operation(summary = "파일업로드 Row수 ")
    @GetMapping("/fileUploadHistoryTots")
    public Integer fileUploadHistoryTots(@ModelAttribute LogComReqDTO dto) throws Exception {
        return fileUploadService.fileUploadHistoryTots(dto);
    }



}
