package com.oms.sys.service.impl;

import java.util.List;

import org.springframework.stereotype.Service;

import com.oms.sys.dao.ApiMgmtDAO;
import com.oms.sys.dao.CodeMgmtDAO;
import com.oms.sys.dto.ApiAuthReqDTO;
import com.oms.sys.dto.ApiMgmtReqDTO;
import com.oms.sys.dto.ApiMgmtResDTO;
import com.oms.sys.service.ApiMgmtService;

import lombok.RequiredArgsConstructor;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @author 안경수
 * @since 2023. 5. 23.
 * @see
 */
@RequiredArgsConstructor
@Service("apiMgmtService")
public class ApiMgmtServiceImpl implements ApiMgmtService {

    private final ApiMgmtDAO apiMgmtDAO;


    // api mgmt

    @Override
    public List<ApiMgmtResDTO> selectApiMgmtList(ApiMgmtReqDTO dto) {
        return   apiMgmtDAO.selectApiMgmtList(dto);
    }
    @Override
    public int insertApiMgmt(ApiMgmtReqDTO apiMgmtReqDTO) {
        return apiMgmtDAO.insertApiMgmt(apiMgmtReqDTO);
    }

    @Override
    public int deleteApiMgmt(List<String> list) {
        return apiMgmtDAO.deleteApiMgmt(list);
    }

    @Override
    public ApiMgmtResDTO selectApiMgmt(String apiUrl) {
        return apiMgmtDAO.selectApiMgmt(apiUrl);
    }

    @Override
    public int updateApiMgmt(ApiMgmtReqDTO apiMgmtReqDTO) {
        return apiMgmtDAO.updateApiMgmt(apiMgmtReqDTO);
    }


    // api auth

    @Override
    public int deleteApiAuth(String grpCd) {
        return apiMgmtDAO.deleteApiAuth(grpCd);
    }

    @Override
    public int insertApiAuth(ApiAuthReqDTO apiAuthReqDTO) {
        return apiMgmtDAO.insertApiAuth(apiAuthReqDTO);
    }

    @Override
    public List<ApiMgmtResDTO> selectApiMgmtListByApiAuth(String grpCd) {
        return apiMgmtDAO.selectApiMgmtListByApiAuth(grpCd);
    }

    @Override
    public int deleteExcelUpload(ApiMgmtReqDTO apiMgmtReqDTO) {
        return apiMgmtDAO.deleteExcelUpload(apiMgmtReqDTO);
    }


    @Override
    public int selectApiUrlCheck(ApiMgmtReqDTO apiMgmtReqDTO) {
        return apiMgmtDAO.selectApiUrlCheck(apiMgmtReqDTO);
    }



}
