package com.oms.sys.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.oms.sys.dto.BatchLogResDTO;
import com.oms.sys.dto.BatchReqDTO;
import com.oms.sys.dto.BatchResDTO;
import com.oms.sys.dto.LogComReqDTO;
import com.oms.sys.dto.LogLgiResDTO;
import com.oms.sys.service.BatchService;
import com.oms.sys.service.LogLgiService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;

/**
 * <pre>
 * Statements
 * </pre>
 * @ClassName : LogLgiController.java
 * @Description :
 * @author 김경훈
 * @since 2023. 6. 16.
 * @see
 */
@Tag(name = "LogLgiController", description = "")
@RequiredArgsConstructor
@RestController
@RequestMapping("/api")
public class LogLgiController {

    /**
     * 클래스 Injection
     */
    private final LogLgiService logLgiService;
    private final HttpServletRequest request;

    /**
     *
     */
    @Operation(summary = "로그인 목록을 조회 ")
    @GetMapping("/logLgiHistorys")
    public List<LogLgiResDTO> logLgiHistorys(@ModelAttribute LogComReqDTO dto) throws Exception {
        return logLgiService.selectLogLgiHistorys(dto);
    }


    /**
     * 
     */
    @Operation(summary = "로그인 목록 Row수 ")
    @GetMapping("/logLgiHistoryTots")
    public Integer logLgiHistoryTots(@ModelAttribute LogComReqDTO dto) throws Exception {
        return logLgiService.selectLogLgiHistoryTots(dto);
    }



}
