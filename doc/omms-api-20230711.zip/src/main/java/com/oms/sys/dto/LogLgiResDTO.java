package com.oms.sys.dto;

import java.sql.Timestamp;

import org.apache.ibatis.type.Alias;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;



/**
 * <pre>
 * Statements
 * </pre>
 * @ClassName : LogLgiResDTO.java
 * @Description :
 * @author 김경훈
 * @since 2023. 6. 16.
 * @see
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Alias("logLgiResDTO")
public class LogLgiResDTO {

    private String lgiLogSn;
    private String userId;
    private String userNm;
    private String lgiDtm;
    private String sucsYn;
    private String userIpAdr;
    private String idExistYn;
    private String sessId;
    private String lgoDtm;
    private String lgoType;

}
