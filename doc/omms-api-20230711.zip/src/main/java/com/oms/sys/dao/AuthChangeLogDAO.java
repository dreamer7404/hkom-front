package com.oms.sys.dao;

import java.util.List;


import com.oms.sys.dto.AuthChangeLogResDTO;
import com.oms.sys.dto.LogComReqDTO;

/**
 * <pre>
 * Statements
 * </pre>
 * @ClassName : AuthChangeDAO.java
 * @Description :
 * @author 김경훈
 * @since 2023. 6. 19.
 * @see
 */
public interface AuthChangeLogDAO {



    List<AuthChangeLogResDTO> authChangeHistorys(LogComReqDTO dto);
    Integer authChangeHistoryTots(LogComReqDTO dto);

}
