package com.oms.sys.dto;

import java.util.List;

import org.apache.ibatis.type.Alias;

import lombok.AllArgsConstructor;
import lombok.Data;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @author 안경수
 * @since 2023. 5. 23.
 * @see
 */
@Alias("apiAuthReqDTO")
@Data
public class ApiAuthReqDTO {
    private String grpCd;
    private String userEeno;

    private List<ApiAuthUrlReqDTO> apiUrls; // apiUrl-method list
}
