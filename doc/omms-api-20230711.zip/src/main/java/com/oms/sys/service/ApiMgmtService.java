package com.oms.sys.service;

import java.util.List;

import com.oms.sys.dto.ApiAuthReqDTO;
import com.oms.sys.dto.ApiMgmtReqDTO;
import com.oms.sys.dto.ApiMgmtResDTO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @author 안경수
 * @since 2023. 5. 19.
 * @see
 */


public interface ApiMgmtService {
    // api mgmt

    int insertApiMgmt(ApiMgmtReqDTO apiMgmtReqDTO);
    int updateApiMgmt(ApiMgmtReqDTO apiMgmtReqDTO);
    int deleteApiMgmt(List<String> list);
    ApiMgmtResDTO selectApiMgmt(String apiUrl);

    // api auth
    int deleteApiAuth(String grpCd);
    int insertApiAuth(ApiAuthReqDTO apiAuthReqDTO);
    List<ApiMgmtResDTO> selectApiMgmtList(ApiMgmtReqDTO dto);
    List<ApiMgmtResDTO> selectApiMgmtListByApiAuth(String grpCd);
    int deleteExcelUpload(ApiMgmtReqDTO apiMgmtReqDTO);

    int selectApiUrlCheck(ApiMgmtReqDTO apiMgmtReqDTO);

}

