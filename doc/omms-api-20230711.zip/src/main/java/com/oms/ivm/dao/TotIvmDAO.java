package com.oms.ivm.dao;

import java.util.HashMap;
import java.util.List;

import com.oms.ivm.dto.ComIvmReqDTO;
import com.oms.ivm.dto.IvmMonthOrdPrdReqDTO;
import com.oms.ivm.dto.IvmMonthOrdPrdResDTO;
import com.oms.ivm.dto.IvmNatlProdPlanResDTO;
import com.oms.ivm.dto.IvmNoapimResDTO;
import com.oms.ivm.dto.IvmRequestMonitorResDTO;
import com.oms.ivm.dto.IvmVehlIvResDTO;
import com.oms.ivm.dto.TotIvmReqDTO;
import com.oms.ivm.dto.TotIvmRequestReqDTO;
import com.oms.ivm.dto.TotIvmResDTO;
import com.oms.ivm.model.TbWrkDateMgmt;

/**
 * <pre>
 * TotIvmDAO 인터페이스
 * </pre>
 *
 * @Class Name  : TotIvmDAO.java
 * @Description : 재고관리 > 총재고관리 DAO
 * @author 김정웅
 * @since 2023.3.7
 * @see
*/
public interface TotIvmDAO {
    List<TotIvmResDTO> selectTotalIvmList(TotIvmReqDTO totIvmDAO) throws Exception;
    //별도요청 저장
    Integer intsertSeparatelyRequest(List<TotIvmRequestReqDTO> totIvmRequestReqDTO) throws Exception;

    //날짜 정보
    List<TbWrkDateMgmt> selectTbWrkDateMgmtList(IvmMonthOrdPrdReqDTO ivmMonthOrdPrdReqDTO)throws Exception;

    HashMap<String, String> selectMsgOdr(IvmMonthOrdPrdReqDTO ivmMonthOrdPrdReqDTO)throws Exception;

    //월간 생산 정보
    List<IvmMonthOrdPrdResDTO> selectMonthPrdList(IvmMonthOrdPrdReqDTO ivmMonthOrdPrdReqDTO)throws Exception;
    //월간 오더 정보
    List<IvmMonthOrdPrdResDTO> selectMonthOrdList(IvmMonthOrdPrdReqDTO ivmMonthOrdPrdReqDTO)throws Exception;
    //월간 오더대비생산 정보
    List<IvmMonthOrdPrdResDTO> selectMonthOrdPrdList(IvmMonthOrdPrdReqDTO ivmMonthOrdPrdReqDTO)throws Exception;

    //국가별생산계획
    List<IvmNatlProdPlanResDTO> selectNatlProdPlanList(ComIvmReqDTO comIvmReqDTO) throws Exception;
    //차종별재고분석-언어별분석
    List<IvmVehlIvResDTO> selectVehlIvByLangList(ComIvmReqDTO reqDto) throws Exception;
    //차종별재고분석-언어별분석
    List<IvmVehlIvResDTO> selectVehlIvByDayList(ComIvmReqDTO reqDto) throws Exception;

    //요청현황
    List<IvmRequestMonitorResDTO> selectOrderRequestList(ComIvmReqDTO reqDto) throws Exception;

    //미연계정보
    List<IvmNoapimResDTO> selectNoapimList(ComIvmReqDTO reqDto) throws Exception;


}
