package com.oms.ivm.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import com.oms.ivm.dao.YsnIvmDAO;
import com.oms.ivm.dto.ComIvmReqDTO;
import com.oms.ivm.dto.IvmRequestMonitorResDTO;
import com.oms.ivm.dto.YsnIvmResDTO;
import com.oms.ivm.service.YsnIvmService;

import lombok.RequiredArgsConstructor;

/**
 * <pre>
 * sewIvmService
 * </pre>
 *
 * @author 김정웅
 * @since 2023. 3. 7.
 * @see
 */
@RequiredArgsConstructor
@Service("ysnIvmService")
public class YsnIvmServiceImpl implements YsnIvmService {

    private final YsnIvmDAO ysnIvmDAO;

    @Override
    public List<YsnIvmResDTO> selectYongsanIvmList(ComIvmReqDTO reqDto) {
        List<YsnIvmResDTO> result = new ArrayList<YsnIvmResDTO>();
        result = ysnIvmDAO.selectYongsanIvmList(reqDto);
        return result;
    }

    @Override
    public List<IvmRequestMonitorResDTO> selectIvmYsnReqStateList(ComIvmReqDTO reqDto) throws Exception {
        List<IvmRequestMonitorResDTO> result = new ArrayList<IvmRequestMonitorResDTO>();
        result = ysnIvmDAO.selectIvmYsnReqStateList(reqDto);
        return result;
    }

}
