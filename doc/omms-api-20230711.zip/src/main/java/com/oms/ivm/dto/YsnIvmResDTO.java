package com.oms.ivm.dto;

import org.apache.ibatis.type.Alias;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * <pre>
 * ysnIvmResDTO
 * </pre>
 *
 * @author 김정웅
 * @since 2023. 6. 26.
 * @see
 */

@Alias("ysnIvmResDTO")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class YsnIvmResDTO {

    private String yongVehlCd;
    private String qltyVehlCd;
    private String qltyVehlNm;
    private String mdlMdyCd;
    private String dlExpdRegnCd;
    private String dlExpdRegnNm;
    private String langCd;
    private String langCdNm;
    private String aplYmd;
    private String company;
    private String vehCd;
    private String mtrlCd;
    private String vehlStock;
    private String stockOnMove;
    private String stockOneAllItem;
    private String stockOneAllKit;
    private String stockOnLocal;
    private String stockSum;
    private String deliverVehlCnt;
    private String responseDays;
    private String orderAmount;
    private String restAmount;
    private String framDtm;
    private int currMthTrwiQty;

}
