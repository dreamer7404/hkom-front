package com.oms.ivm.dto;

import org.apache.ibatis.type.Alias;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @author 김정웅
 * @since 2023. 7. 10.
 * @see
 */

@Alias("ivmNoapimResDTO")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class IvmNoapimResDTO {

    private String etVehlCd;
    private String etMdlMdyCd;
    private String etNatCd;
    private String qltyVehlCd;
    private String mdlMdyCd;
    private String natCd;
    private String natNm;
    private String affrScnNm;
    private String errCase;
    private String prdnPlnYmd;
    private String framDtm;


}
