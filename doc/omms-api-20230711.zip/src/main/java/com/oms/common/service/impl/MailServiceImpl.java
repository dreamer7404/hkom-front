package com.oms.common.service.impl;

import java.util.List;

import javax.mail.Message;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import org.apache.commons.text.StringEscapeUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.scheduling.annotation.Async;
//import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

import com.oms.common.dao.MailDAO;
import com.oms.common.dto.MailDTO;
import com.oms.common.model.Mail;
import com.oms.common.service.MailService;

import lombok.RequiredArgsConstructor;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @author 안경수
 * @since 2023. 5. 16.
 * @see
 */

@RequiredArgsConstructor
@Service
public class MailServiceImpl implements MailService {

    private final JavaMailSender mailSender;
    private final MailDAO mailDao;


    @Value("${spring.mail.from}")
    private String from;
    @Value("${spring.mail.sndrId}")
    private String sndrId;

    @Async
    @Override
    public void send(MailDTO mailDTO)  {
        try {

            //  메일전송
            MimeMessage mimeMessage = mailSender.createMimeMessage();

            if(mailDTO.getRcvList() == null) {
                mailDTO.setRcvList(mailDao.selectRcvLIst(mailDTO));
            }
            // 수신자 이메일 리스트
            int size = mailDTO.getRcvList().size();

            InternetAddress[] toAddr = new InternetAddress[size];
            for(int i=0; i<size; i++) {
                toAddr[i] = new InternetAddress(mailDTO.getRcvList().get(i).getEmlAdr());
            }
            mimeMessage.setRecipients(Message.RecipientType.TO, toAddr);

            MimeMessageHelper mimeMessageHelper = new MimeMessageHelper(mimeMessage, false, "UTF-8");

            //내용 세팅
            mimeMessageHelper.setFrom(from); // 보낸이 주소
            mimeMessageHelper.setSubject(mailDTO.getEmlTitl()); // 제목
            mimeMessageHelper.setText(StringEscapeUtils.unescapeHtml4(mailDTO.getEmlSbc()), true); // 내용


            // 메일송수신자로그 저장
            mailDTO.setSndrId(sndrId);
            mailDao.insertLogEml(mailDTO);
            mailDao.insertLogEmlSnd(mailDTO);

            //메일 전송
            mailSender.send(mimeMessage);

        } catch (Exception e) {
            mailDTO.setEmlStCd("발송실패");
            updateLogEmlSnd(mailDTO);
            return;

        }
        mailDTO.setEmlStCd("발송성공");
        updateLogEmlSnd(mailDTO);

    }

    /*
     * TB_LOG_EML 저장
     */
    @Override
    public int insertLogEml(MailDTO mailDTO) {
        return mailDao.insertLogEml(mailDTO);
    }

    /*
     * TB_LOG_EML_SND 저장
     */
    @Override
    public int insertLogEmlSnd(MailDTO mailDTO) {
        return mailDao.insertLogEmlSnd(mailDTO);
    }

    @Override
    public List<Mail> selectEmlAdrList(List<String> list) {
        return mailDao.selectEmlAdrList(list);
    }

    @Override
    public int updateLogEmlSnd(MailDTO mailDTO) {
        return mailDao.updateLogEmlSnd(mailDTO);
    }



}
