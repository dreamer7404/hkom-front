package com.oms.common.dao;

import java.util.List;

import com.oms.common.dto.AttcFileReqDTO;
import com.oms.common.dto.AttcFileResDTO;


/**
 * <pre>
 * Statements
 * </pre>
 * @ClassName : MailDAO.java
 * @Description :
 * @author 안경수
 * @since 2023. 5. 26.
 * @see
 */
public interface AttcFileDAO {

    int insertAttcFile(AttcFileReqDTO attcFileReqDTO);
    int updateAttcFile(List<AttcFileReqDTO> list);
    List<AttcFileResDTO> selectAttcFileList(AttcFileReqDTO attcFileReqDTO);
    List<String> selectAttcFilePathList(List<Long> list);
    int deleteAttcFile(List<String> attcSnDeleted);

}
