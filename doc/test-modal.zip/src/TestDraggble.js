import React from 'react';
import { Row, Col, Button, Card, Input, Modal, ModalHeader, ModalBody, Form, ModalFooter  } from 'reactstrap';
import Draggable from 'react-draggable';


const TestDraggable = ({show, onHide })=> {

    return(
        <Draggable>
            <Modal isOpen={show} size="lg">
                <ModalHeader toggle={onHide}><strong>데이터 선택</strong></ModalHeader>
                <ModalBody>
                    <h1>TEst...............</h1>
                    <h1>TEst...............</h1>
                    <h1>TEst...............</h1>
                    <h1>TEst...............</h1>
                </ModalBody>

            </Modal>
        </Draggable>

    )
};

export default TestDraggable;