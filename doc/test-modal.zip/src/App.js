import React, { useState ,useRef} from 'react';
import { Button, Inpu, Form} from 'react-bootstrap';
import Modal from './components/Modal';
// import { Modal, ModalHeader, ModalBody } from "reactstrap";
import Draggable from "react-draggable";
import OmmsModal from './components/OmmsModal';





function App() {

  const [isOpen, setIsOpen] = useState(false);

  const closeModal = () => {
    setIsOpen(false);
  }

  const openModal = () => {
    setIsOpen(true);
  }

  const toggle = () => setIsOpen(!isOpen)


 

  return (
      <div className="App">
          <Button onClick={openModal}>Open modal</Button>
          {/* <Modal  isOpen={isOpen} onClose={closeModal} size='lg' title="사용자 등록">
                <h3>My Modal..</h3>
                <div className="body">
                    <p>This is the modal&apos;s body.</p>
                </div>
              <Modal.Footer>
                  <Button variant="light" size="md" onClick={closeModal}>취소</Button>
                  <Button  variant="primary"  size="md" onClick={closeModal} >저장</Button>
              </Modal.Footer>   
          </Modal> */}

        {/* <Draggable  handle=".handle">
                      <Modal show={isOpen} onHide={closeModal} backdrop="static" keyboard={false} centered size="lg" className="modal-custom">
                    
                    <Modal.Header closeButton>
                        <Modal.Title  className="handle">사용자 상세/수정</Modal.Title>
                    </Modal.Header>
                        <Modal.Body>
                          <h1>asdfasd</h1>
                        </Modal.Body>
                        
                      </Modal>  
                      </Draggable>
  */}


{/* <Draggable handle=".handle">
  <Modal size="lg" isOpen={isOpen} >
    <ModalHeader toggle={toggle} className="handle">
      Modal Title
    </ModalHeader>
    <ModalBody>
      Modal Body
    </ModalBody>
  </Modal>
</Draggable> */}

        {/* <div
              style={{
                visibility: isOpen ? "visible" : "hidden"
                // position: "absolute"
              }}
            >
<Draggable>
                      <div
              style={{
                left: 0,
                right: 0,
                top: 0,
                bottom: 0,
                margin: "auto",
                // marginRight: "auto",

                border: "1px solid #ccc",
                width: "400px",
                height: "200px",
                position: "absolute",
                align: "center",
                background: "#fff",
                cursor: "move"
              }}
            >
              <div >
                <span style={{ fontSize: "1.7em", fontWeight: "bold" }}>
                  My Model
                </span>
              </div>
              <div style={{ margin: "10px" }}>
                <div>This readme is really dragging on...</div>
                <br />
                <Form>
      <Form.Group className="mb-3" controlId="exampleForm.ControlInput1">
        <Form.Label>Email address</Form.Label>
        <Form.Control type="email" placeholder="name@example.com" />
      </Form.Group>
      <Form.Group className="mb-3" controlId="exampleForm.ControlTextarea1">
        <Form.Label>Example textarea</Form.Label>
        <Form.Control as="textarea" rows={3} />
      </Form.Group>
    </Form>
                <Button
                  label="close"
                  style={{ position: "fixed", bottom: "5px", right: "20px" }}
                  onClick={closeModal}
                />
              </div>
            </div>
                      </Draggable>
                      </div>  */}


<div>
  <input />
</div>
                    <div><h1>dddddddddddddddd</h1></div>  
                    <div><h1>dddddddddddddddd</h1></div>  
                    <div><h1>dddddddddddddddd</h1></div>  
                    <div><h1>dddddddddddddddd</h1></div>  
                    <div><h1>dddddddddddddddd</h1></div>  
                    <div><h1>dddddddddddddddd</h1></div>  
                    <div><h1>dddddddddddddddd</h1></div>  
                    <div><h1>dddddddddddddddd</h1></div>  
                    <div><h1>dddddddddddddddd</h1></div>  


               <OmmsModal   isOpen={isOpen} onClose={closeModal} size='lg' title="사용자 등록">
                  <div style={{ margin: "10px" }}>
                        <div>This readme is really dragging on...</div>
                        <Form>
                        <Form.Group className="mb-3" controlId="exampleForm.ControlInput1">
                          <Form.Label>Email address</Form.Label>
                          <Form.Control type="email" placeholder="name@example.com" />
                        </Form.Group>
                        <Form.Group className="mb-3" controlId="exampleForm.ControlTextarea1">
                          <Form.Label>Example textarea</Form.Label>
                          <Form.Control as="textarea" rows={3} />
                        </Form.Group>
                      </Form>
                    <div className='hkomms-modal-footer'>
                      <Button variant="light" size="md" onClick={closeModal}>취소</Button>
                      <Button  variant="primary"  size="md" onClick={closeModal} >저장</Button>
                      </div>
                  </div>            
              </OmmsModal> 
           </div>       
      
  )
}

export default App;
