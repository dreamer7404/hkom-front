import React, { useState ,useRef} from 'react';
import { Button, Modal, ModalHeader, ModalBody, ModalFooter } from 'reactstrap';
import Draggable from 'react-draggable';


import 'bootstrap/dist/css/bootstrap.min.css';

function App() {

  const scrollRef = useRef();

  // const [modal, setModal] = useState(false);
  // const toggle = () => setModal(!modal);
 
  // const [activeDrags, setActiveDrags] = useState(0);
  // const handleStart = () => {
  //   setActiveDrags(activeDrags+1);
  // };

  // const handleStop = () => {
  //   setActiveDrags(activeDrags-1);
  // };


  const [isDrag, setIsDrag]= useState(false);
  const [startX, setStartX]= useState(0);

  const onDragStart = e =>{
    e.preventDefault();
    setIsDrag(true);
    setStartX(e.pageX + scrollRef.current.scrollLeft);
  }

  const onDragEnd = e =>{
    setIsDrag(false);
  }

  const onDragMove = e =>{
    if(isDrag){
      scrollRef.current.scrollLeft = startX - e.pageX;
    }
  }

  return (
    <div className="App">

       {/* <Button color="danger" onClick={toggle}>Click Me</Button> */}

      {/* <Draggable>
        <Modal isOpen={modal} toggle={toggle} >
          <ModalHeader toggle={toggle}>Modal title</ModalHeader>
          <ModalBody>
            Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do
            eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad
            minim veniam, quis nostrud exercitation ullamco laboris nisi ut
            aliquip ex ea commodo consequat. Duis aute irure dolor in
            reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla
            pariatur. Excepteur sint occaecat cupidatat non proident, sunt in
            culpa qui officia deserunt mollit anim id est laborum.
          </ModalBody>
          <ModalFooter>
            <Button color="primary" onClick={toggle}>
              Do Something
            </Button>{' '}
            <Button color"secondary" onClick={toggle}>
              Cancel
            </Button>
          </ModalFooter>
        </Modal>
        </Draggable>  */}


{/* <Draggable>
      <div className="container">
        <div className="bar">bar</div>
      </div>
    </Draggable> */}

      <div
        ref={scrollRef}
        onMouseDown={onDragStart}
        onMouseUp={onDragEnd}
        onMouseMove={e => setTimeout(onDragMove(), 200)}
        role="option"
        >
          <h1>SSSSSSSSSSSSSSS</h1>

        </div>

    </div>
  );
}

export default App;
