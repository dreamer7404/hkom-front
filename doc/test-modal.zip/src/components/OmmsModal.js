
import React,{useRef} from 'react';
import Draggable from "react-draggable";
import { useOnClickOutside } from 'usehooks-ts'

const OmmsModal = ({isOpen, onClose, size, title, children}) => {

    const ref = useRef(null);
    const handleClickOutside = (e) => {
        console.log('clicked outside => ' + isOpen );
        if(isOpen){
            e.preventDefault();
        }
    }
    useOnClickOutside(ref, handleClickOutside);

       
    return(
        <div style={{ visibility: isOpen ? "visible" : "hidden" }}>
            <Draggable>
                <div ref={ref} className='hkomms-modal'
                    style={{
                        width: size === 'lg' ? '800px' :'400px',
                        minHeight: '300px',
                    }}>
                    <div className='hkomms-modal-header'>{title}</div>
                    <div className='hkomms-modal-header-close'><p onClick={onClose} >X</p></div>
                    {children}
                 </div>
            </Draggable>
       </div> 
    )
};
export default OmmsModal;