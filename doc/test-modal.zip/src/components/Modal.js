import React, {useRef} from 'react';
import ReactModal from 'react-modal-resizable-draggable';
import { useOnClickOutside } from 'usehooks-ts'


const Modal = ({isOpen, onClose, size, title, children}) => {

    const ref = useRef(null);
    const handleClickOutside = (e) => {
        console.log('clicked outside => ' + isOpen );
        if(isOpen){
            e.preventDefault();
        }
    }
    useOnClickOutside(ref, handleClickOutside);

    return (
        <div ref={ref}>
        <ReactModal 
            
            initWidth={size === 'lg' ? 800 : 400} 
            initHeight={400} 
            onRequestClose={onClose} 
            isOpen={isOpen}
            disableResize={true}
            >
                
                <div className='hkomms-modal-header'>{title}</div>
                <div className='hkomms-modal-header-close'><p onClick={onClose} >X</p></div>
                {children}
                
        </ReactModal>
        </div>
    )
}

const Footer = ({children}) => {
    return (
        <div className='hkomms-modal-footer'>
            {children}
        </div>
    )
}
Modal.Footer = Footer;
export default Modal;