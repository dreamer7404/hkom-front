package com.oms.stm.dto;

import java.util.List;

import org.apache.ibatis.type.Alias;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.oms.common.dto.RcvrReqDTO;
import com.oms.sys.dto.UsrMgmtReqDTO;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;



/**
 * <pre>
 * Statements
 * </pre>
 * @ClassName : BoardReqDTO.java
 * @Description :
 * @author 김경훈
 * @since 2023. 6. 7.
 * @see
 */
@Alias("boardReqDTO")
@Data
@JsonIgnoreProperties(ignoreUnknown=true)
@AllArgsConstructor
@NoArgsConstructor
public class BoardReqDTO extends RcvrReqDTO {
    @Schema(type = "string", example = " ")
    private String  blcSn;                       //화면일련번호
    @Schema(type = "string", example = " ")
    private String  affrScnCd;                 //업무구분코드
    @Schema(type = "string", example = " ")
    private String  rgnEeno;                     //등록자사원번호
    @Schema(type = "string", example = "테스트")
    private String  blcTitlNm;                  //게시물 제목명
    @Schema(type = "string", example = " ")
    private String  blcSbc;                  //게시물 내용
    @Schema(type = "string", example = "N")
    private String  attcYn;                  //첨부 여부
    @Schema(type = "string", example = " ")
    private String  n1afp2Adr;            //1차첨부파일경로주소
    @Schema(type = "string", example = "Y")
    private String bulYn;
    @Schema(type = "string", example = " ")
    private String bulStrtYmd;
    @Schema(type = "string", example = " ")
    private String bulFnhYmd;
    private String userEeno;
    private String sortSn;

    //조회조건
    @Schema(type = "string", example = " ")
    private String loginNm;                 //로그인중인 사용자
    @Schema(type = "string", example = " ")
    private String sDate;
    @Schema(type = "string", example = " ")
    private String eDate;


    //log 작성
    @Schema(type = "string", example = " ")
    private String fileSize;
    @Schema(type = "string", example = " ")
    private String fileNm;
    @Schema(type = "string", example = " ")
    private String useType;


    //mail
    @Schema(type = "string", example = " ")
    private String title;
    @Schema(type = "string", example = " ")
    private String contents;
    @Schema(type = "string", example = " ")
    private String sendemail;
    @Schema(type = "string", example = " ")
    private String sendEeno;
    @Schema(type = "string", example = " ")
    private String sendNm;


    List<RcvrReqDTO> usrList;
    List<BoardReqDTO> deleteList;

    //-------- 첨부파일 정보 ---------------------
    private List<String> attcSn; // 새로추가한 첨부파일 저장 tb_attc_mgmt PK
    private List<String> size;
    private List<String> extension;
    private List<String> originalName;

    private List<String> attcSnDeleted; // 기존 첨부파일 tb_attc_mgmt PK (업데이트시)

}


