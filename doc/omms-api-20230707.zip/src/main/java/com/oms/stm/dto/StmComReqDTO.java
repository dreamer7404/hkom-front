package com.oms.stm.dto;



import java.util.List;

import org.apache.ibatis.type.Alias;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.oms.common.dto.CommReqDTO;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


/**
 * <pre>
 * Statements
 * </pre>
 * @ClassName : VehlMgmtResDTO.java
 * @Description :
 * @author 김경훈
 * @since 2023. 3. 13.
 * @see
 */
@JsonIgnoreProperties(ignoreUnknown=true)
@Alias("stmComReqDTO")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class StmComReqDTO extends CommReqDTO {
    @Schema(type = "string", example = " ")
    private String qltyVehlCd ;
    @Schema(type = "string", example = " ")
    private String dlExpdRegnCd;
    @Schema(type = "string", example = " ")
    private String dlExpdPacScnCd;
    @Schema(type = "string", example = " ")
    private String sYm;
    @Schema(type = "string", example = " ")
    private String eYm;
    @Schema(type = "string", example = " ")
    private String nqltyVehlCd;
    @Schema(type = "string", example = " ")
    private String dataSn;
    @Schema(type = "string", example = " ")
    private String mdlMdyCd;
    @Schema(type = "string", example = " ")
    private String dlExpdPdiCd;
    private String blnsCoCd;
    private String langCd;
    private String dlExpeRegnCd;
    private String natlCd;
    private String natlNm;
    private String dlExpdNatCd;
    private String newPrntPbcnNo;
    private String lrnkCd;



//    List<Integer>vCnt;
    List<VehlMgmtResDTO> regnList;

}
