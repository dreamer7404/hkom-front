package com.oms.stm.dto;


import org.apache.ibatis.type.Alias;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


/**
 * <pre>
 * Statements
 * </pre>
 * @ClassName : BoardResDTO.java
 * @Description :
 * @author 김경훈
 * @since 2023. 6. 7.
 * @see
 */
@Alias("boardResDTO")
@Data
@NoArgsConstructor
@AllArgsConstructor

public class BoardResDTO {


    private String  blcSn;                       //공지사항일련번호
    private String  affrScnCd;                 //업무구분코드
    private String affrScnNm;                   //업무구분코드명
    private String  rgnEeno;                     //등록자사원번호
    private String  rgnNm;                      //등록자이름
    private String  blcRgstYmd;               //게시물등록년월일
    private String  blcTitlNm;                  //게시물제목명
    private String  blcSbc;                        //게시물내용
    private String  attcYn;                       //첨부여부
    private String  n1afp2Adr;                  //1차첨부파일경로주소
    private String  pprrEeno;                   //작성자사원번호
    private String  framDtm;                   //작성일시
    private String  updrEeno;                  //수정자사원번호
    private String  mdfyDtm;                   //수정일시
    private String  bulStrtYmd;              //게시시작년월일
    private String  bulFnhYmd;               //게시종료년월일
    private String  bulYn;                       //게시여부
    private String  bulDtm;                     // 게시기간

}
