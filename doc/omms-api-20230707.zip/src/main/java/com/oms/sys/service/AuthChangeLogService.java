package com.oms.sys.service;

import java.util.List;


import com.oms.sys.dto.AuthChangeLogResDTO;
import com.oms.sys.dto.LogComReqDTO;


/**
 * <pre>
 * Statements
 * </pre>
 * @ClassName : AuthChangeService.java
 * @Description :
 * @author 김경훈
 * @since 2023. 6. 19.
 * @see
 */
public interface AuthChangeLogService {

    List<AuthChangeLogResDTO> authChangeHistorys(LogComReqDTO dto);
    Integer authChangeHistoryTots(LogComReqDTO dto);


}
