package com.oms.sys.dto;

import java.sql.Timestamp;

import lombok.Data;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @author 안경수
 * @since 2023. 5. 19.
 * @see
 */
@Data
public class SchedLogDTO {
    private String schedId;
    private String schedNm;
    private String startDtm;
    private Timestamp endDtm;
    private String apiUrl;
    private Integer getDataCnt;
    private Integer saveDataCnt;
    private String callRslt;    // 조회응답결과

}
