package com.oms.sys.service;

import java.util.List;

import com.oms.common.dto.CommReqDTO;
import com.oms.common.model.Mail;
import com.oms.sys.dto.AuthReqDTO;
import com.oms.sys.dto.AuthVehlSaveDTO;
import com.oms.sys.dto.UseYnReqDTO;
import com.oms.sys.dto.UsrMgmtReqDTO;
import com.oms.sys.dto.UsrMgmtResDTO;
import com.oms.sys.dto.UsrVehlResDTO;
import com.oms.sys.model.UsrMgmt;


/**
 * <pre>
 * UsrMgmtService
 * </pre>
 *
 * @ClassName   : UsrMgmtService.java
 * @Description :
 * @author 안경수
 * @since 2023.1.19
 * @see
 */


public interface UsrMgmtService {
    public Integer insertUsrMgmt(UsrMgmtReqDTO usrMgmtReqDTO) throws Exception;
    public Integer updateUsrMgmt(UsrMgmtReqDTO usrMgmtReqDTO) throws Exception ;
    public Integer deleteUsrMgmt(UsrMgmtReqDTO usrMgmtReqDTO) throws Exception;
    public UsrMgmtResDTO selectUsrMgmt(String id) throws Exception;
    public List<UsrMgmtResDTO> selectUsrMgmtList(UsrMgmtReqDTO usrMgmtReqDTO) throws Exception;
    public Integer deleteVehlAuthList(AuthVehlSaveDTO authVehlSaveDTO) throws Exception;
    public Integer insertVehlAuthList(List<AuthVehlSaveDTO> list) throws Exception; //등록 or 수정하려는 차종 권한만 삭제 필요 khkim
    public List<UsrVehlResDTO> selectUserVehlList(CommReqDTO commReqDTO) throws Exception;
    public Integer deleteVehlAuthListByUserEeno(String userEeno) throws Exception;
    public Integer updateUserPw(UsrMgmtReqDTO usrMgmtReqDTO) throws Exception;
    public Integer updateUserUseYn(UseYnReqDTO useYnReqDTO ) throws Exception;
    public Integer updateUserPwLock(String userEeno) throws Exception;
    public Integer updateUserBlnsCoCd(AuthReqDTO authReqDTO)  throws Exception;
    public Integer updateUserPwErrOft(AuthReqDTO authReqDTO) throws Exception;
    Integer updateUserLoginOk(AuthReqDTO authReqDTO) throws Exception;
    public UsrMgmt selectUsrMgmt4FindPw (UsrMgmtReqDTO usrMgmtReqDTO) throws Exception;

}
