package com.oms.sys.service.impl;

import java.util.List;
import org.springframework.stereotype.Service;
import com.oms.sys.dao.SchedulerLogDAO;
import com.oms.sys.dto.LogComReqDTO;
import com.oms.sys.dto.SchedulerLogResDTO;
import com.oms.sys.service.SchedulerLogService;

import lombok.RequiredArgsConstructor;


/**
 * <pre>
 * Statements
 * </pre>
 * @ClassName : SchedulerLogServiceImpl.java
 * @Description :
 * @author 김경훈
 * @since 2023. 6. 19.
 * @see
 */
@RequiredArgsConstructor
@Service("schedulerLogService")
public class SchedulerLogServiceImpl implements SchedulerLogService {

    private final SchedulerLogDAO schedulerDao;

    /*
     * @see com.oms.sys.service.AuthChangeService#authChangeHistorys(com.oms.sys.dto.AuthChangeReqDTO)
     */
    @Override
    public List<SchedulerLogResDTO> schedulerHistorys(LogComReqDTO dto) {
        // TODO Auto-generated method stub
        return schedulerDao.schedulerHistorys(dto);
    }

    /*
     * @see com.oms.sys.service.AuthChangeService#authChangeHistoryTots(com.oms.sys.dto.AuthChangeReqDTO)
     */
    @Override
    public Integer schedulerHistoryTots(LogComReqDTO dto) {
        // TODO Auto-generated fileUploadHistoryTots stub
        return schedulerDao.schedulerHistoryTots(dto);
    }



}
