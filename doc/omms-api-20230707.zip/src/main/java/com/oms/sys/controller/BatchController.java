package com.oms.sys.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.oms.sys.dto.BatchLogResDTO;
import com.oms.sys.dto.BatchReqDTO;
import com.oms.sys.dto.BatchResDTO;
import com.oms.sys.service.BatchService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @author 안경수
 * @since 2023. 5. 23.
 * @see
 */
@Tag(name = "BatchController", description = "")
@RequiredArgsConstructor
@RestController
@RequestMapping("/api")
public class BatchController {

    /**
     * 클래스 Injection
     */
    private final BatchService batchService;
    private final HttpServletRequest request;

    /**
     * Batch 목록을 조회
     */
    @Operation(summary = "Batch 목록을 조회 ")
    @GetMapping("/batchInfos")
    public List<BatchResDTO> batchInfos() throws Exception {
        List<BatchResDTO> list = batchService.selectBatchInfos();

        return list;
    }





    /**
     * Batch 목록을 조회
     */
    @Operation(summary = "Batch이력 목록을 조회 ")
    @GetMapping("/batchLogs")
    public List<BatchLogResDTO> batchLogs(@ModelAttribute BatchReqDTO dto) throws Exception {
        List<BatchLogResDTO> list = batchService.selectBatchLogs(dto);

        return list;
    }

    /**
     * Batch 목록을 조회
     */
    @Operation(summary = "Batch이력 총합 조회 ")
    @GetMapping("/batchLogsTot")
    public Integer batchLogsTot(@ModelAttribute BatchReqDTO dto) throws Exception {


        return  batchService.selectBatchLogsTot(dto);
    }



}
