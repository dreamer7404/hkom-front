package com.oms.common.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.oms.cmm.utils.Utils;
import com.oms.common.dto.CodeComboResDTO;
import com.oms.common.dto.ComboReqDTO;
import com.oms.common.dto.CommLangComboResDTO;
import com.oms.common.dto.GrpComboResDTO;
import com.oms.common.dto.LangComboResDTO;
import com.oms.common.dto.PdiComboResDTO;
import com.oms.common.dto.RegionComboResDTO;
import com.oms.common.dto.SubCdComboResDTO;
import com.oms.common.dto.VehlComboResDTO;
import com.oms.common.dto.VehlMdyLangListReqDTO;
import com.oms.common.dto.VehlMdyLangReqDTO;
import com.oms.common.dto.VehlMdyLangResDTO;
import com.oms.common.dto.VehlMdyReqDTO;
import com.oms.common.dto.VehlMdyResDTO;
import com.oms.common.service.ComboService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;

/**
 * <pre>
 * 조회조건 목록을 가져온다
 * </pre>
 *
 * @author 안경수
 * @since 2023. 3. 22.
 * @see
 */
@Tag(name = "ComboController", description = "")
@RequiredArgsConstructor
@RestController
@RequestMapping("/api")
public class ComboController {

    /**
     * 클래스 Injection
     */
    private final HttpServletRequest request;
    private final ComboService comboService;


    /**
     * PDI combo용 조회
     */
    @Operation(summary = "PDI combo용 조회")
    @GetMapping("/pdiCombo")
    public List<PdiComboResDTO> selectPdiComboList(@ModelAttribute ComboReqDTO comboReqDTO) throws Exception {
        comboReqDTO.setUserEeno(Utils.getUserEeno(request));
        comboReqDTO.setDlExpdCoCd(Utils.getDlExpdCoCd(request)); // 회사코드
        return comboService.selectPdiComboList(comboReqDTO);
    }
    /**
     * 차량코드 combo용 조회
     */
    @Operation(summary = "차량코드 combo용 조회")
    @GetMapping("/vehlCombo")
    public List<VehlComboResDTO> selectVehlComboList(@ModelAttribute ComboReqDTO comboReqDTO) throws Exception {
        comboReqDTO.setUserEeno(Utils.getUserEeno(request)); // 사원번호
        comboReqDTO.setDlExpdCoCd(Utils.getDlExpdCoCd(request)); // 회사코드
        return comboService.selectVehlComboList(comboReqDTO);
    }

    /**
     * 차량연식 combo용 조회
     */
    @Operation(summary = "차량연식 combo용 조회")
    @GetMapping("/mdyCombo")
    public List<String> selectMdyComboList(@ModelAttribute ComboReqDTO comboReqDTO) throws Exception {
        return comboService.selectMdyComboList(comboReqDTO);
    }

    /***
     *
     * 지역코드 combo용 조회
     *
     * @param
     *  - bData        기준일(*)
     *  - userEeno     사원번호
     *  - dlExpdPdiCd  PDI코드
     *  - qltyVehlCd   차량안전코드
     *  - mdlMdyCd     차량연식
     */
    @Operation(summary = "지역코드 combo용 조회")
    @GetMapping("/regionCombo")
    public List<RegionComboResDTO> selectRegionComboList(@ModelAttribute ComboReqDTO comboReqDTO) throws Exception {
        comboReqDTO.setDlExpdCoCd(Utils.getDlExpdCoCd(request)); // 회사코드
        comboReqDTO.setUserEeno(Utils.getUserEeno(request)); // 사원번호
        List<RegionComboResDTO> list = comboService.selectRegionComboList(comboReqDTO);
        return list;
    }

    /***
    *
    * 언어코드 combo용 조회
    *
    * @param
    *  - bData        기준일(*)
    *  - userEeno     사원번호
    *  - dlExpdPdiCd  PDI코드
    *  - qltyVehlCd   차량안전코드
    *  - mdlMdyCd     차량연식
    *  - dlExpdRegnCd  지역코드
    */
   @Operation(summary = "언어코드 combo용 조회")
   @GetMapping("/langCombo")
   public List<LangComboResDTO> selectLangComboList(@ModelAttribute ComboReqDTO comboReqDTO) throws Exception {
       comboReqDTO.setDlExpdCoCd(Utils.getDlExpdCoCd(request)); // 회사코드
       comboReqDTO.setUserEeno(Utils.getUserEeno(request)); // 사원번호
       List<LangComboResDTO> list = comboService.selectLangComboList(comboReqDTO);
       return list;
   }

       /***
       *
       * 서브코드 combo용 조회
       *
       * @param
       *  - mainCd        그룹코드

       */
      @Operation(summary = "서브코드 combo용 조회")
      @GetMapping("/subCdCombo")
      public List<SubCdComboResDTO> selectSubCdComboList(@RequestParam String mainCd) throws Exception {
          List<SubCdComboResDTO> list = comboService.selectSubCdComboList(mainCd);
          return list;
      }

      /***
      *
      * 코드테이블 combo용 조회
      *
      */
     @Operation(summary = "코드테이블 combo용 조회")
     @GetMapping("/codeCombo")
     public List<CodeComboResDTO> selectCodeComboList(String dlExpdGCd) throws Exception {
         List<CodeComboResDTO> list = comboService.selectCodeComboList(dlExpdGCd);
         return list;
     }




     /***
     *
     * 그룹테이블 combo용 조회
     *
     */
    @Operation(summary = "그룹테이블 combo용 조회")
    @GetMapping("/grpCombo")
    public List<GrpComboResDTO> selectGrpComboList() throws Exception {
        List<GrpComboResDTO> list = comboService.selectGrpComboList();
        return list;
    }

    /***
    *
    * 차종 및 언어 combo용 조회
    *
    */
   @Operation(summary = "차종 및 언어 combo용 조회")
   @GetMapping("/langByVehlCombo")
   public List<HashMap<String, Object>> selectLangByVehlComboList() throws Exception {
       String userEeno = Utils.getUserEeno(request);
       String dlExpdCoCd = Utils.getDlExpdCoCd(request);

       List<HashMap<String, Object>> list = comboService.selectLangByVehlComboList(userEeno, dlExpdCoCd);
       return list;
   }

   /***
   *
   * 외주제작사 combo용 조회
   * @description 현대 : 코드가 06~10 사이, 기아 : 06 만
   */
  @Operation(summary = "외주제작사 combo용 조회")
  @GetMapping("/outsourcingCombo")
  public List<HashMap<String, Object>> selectOutsourcingComboList() throws Exception {
      String userEeno = Utils.getUserEeno(request);
      String dlExpdCoCd = Utils.getDlExpdCoCd(request);

      List<HashMap<String, Object>> list = comboService.selectOutsourcingComboList(userEeno, dlExpdCoCd);
      return list;
  }


      /***
      *
      * 사용자권한에 따른 차종코드 리스트
      */
     @Operation(summary = "사용자권한에 따른 차종코드 리스트")
     @GetMapping("/vehlsByUserCombo")
     public List<VehlMdyResDTO> selectVehlListByUser() throws Exception {

         ComboReqDTO comboReqDTO = new ComboReqDTO();
         comboReqDTO.setUserEeno(Utils.getUserEeno(request));
         comboReqDTO.setDlExpdCoCd(Utils.getDlExpdCoCd(request));

         List<VehlMdyResDTO> list = comboService.selectVehlListByUser(comboReqDTO);
         return list;
     }

     /***
     *
     * 차종코드에 따른 [연식 리스트]
     */
    @Operation(summary = "차종코드에 따른 [연식 리스트]")
    @GetMapping("/mdysByVehlCdCombo")
    public List<String> selectMdyListByVehlCd(@RequestParam String qltyVehlCd) throws Exception {
        List<String> list = comboService.selectMdyListByVehlCd(qltyVehlCd);
        return list;
    }



    /***
    *
    * 차종코드+연식에 따른 [언어 리스트]
    */
   @Operation(summary = "차종코드+연식에 따른 [언어 리스트]")
   @GetMapping("/langsByVehlCdMdyCombo")
   public List<CommLangComboResDTO> selectLangListByVehlCdAndMdy(@ModelAttribute VehlMdyReqDTO vehlMdyReqDTO) throws Exception {
       List<CommLangComboResDTO> list = comboService.selectLangListByVehlCdAndMdy(vehlMdyReqDTO);
       return list;
   }

   /**
    * vehlMdyLangGrid 그리드용 차종,연식,언어 리스트
    */
   @Operation(summary = "게시판 그리드용 차종,연식,언어 리스트")
   @GetMapping("/vehlMdyLangGrid")
   public List<VehlMdyLangResDTO> selectVehlMdyLangList(@RequestParam String codes  ) throws Exception {

       String[] arr = codes.split(",");

       VehlMdyLangListReqDTO vehlMdyLangListReqDTO = new VehlMdyLangListReqDTO();

       for(int i=0; i<arr.length; i++) {
           String item = arr[i];
           String[] arrItem = item.split("_");

           if(arrItem.length == 1) {       // 차종코드
               vehlMdyLangListReqDTO.getList1().add(new VehlMdyLangReqDTO(arrItem[0], null, null));
           }else if(arrItem.length == 2) { // 차종코드_연식
               vehlMdyLangListReqDTO.getList2().add(new VehlMdyLangReqDTO(arrItem[0], arrItem[1], null));
           }else if(arrItem.length == 3) { // 차종코드_연식_언어
               vehlMdyLangListReqDTO.getList3().add(new VehlMdyLangReqDTO(arrItem[0], arrItem[1], arrItem[2]));
           }
       }

       List<VehlMdyLangResDTO> returnList = comboService.selectVehlMdyLangList(vehlMdyLangListReqDTO);
       return returnList;
   }

}
