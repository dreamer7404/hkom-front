package com.oms.common.scheduler;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.web.util.HtmlUtils;

import com.oms.cmm.utils.Utils;
import com.oms.common.dto.MailDTO;
import com.oms.common.model.Mail;
import com.oms.common.service.MailService;
import com.oms.stm.dao.VehlMgmtDAO;
import com.oms.stm.dto.VehlJobDTO;
import com.oms.stm.service.VehlMgmtService;

import lombok.RequiredArgsConstructor;
import net.javacrumbs.shedlock.spring.annotation.EnableSchedulerLock;
import net.javacrumbs.shedlock.spring.annotation.SchedulerLock;



@Component
@RequiredArgsConstructor
@EnableSchedulerLock(defaultLockAtMostFor = "PT4S")
public class Job1 {
    private final VehlMgmtDAO vehlMgmtDao;
    private final MailService mailService;





//    @Scheduled(fixedRate = 5000)
    @SchedulerLock(name="SchedulerLock",lockAtMostFor = "PT4S", lockAtLeastFor = "PT4S")
    public void SchedulerTest() {
        System.out.println("1번 스케줄러"+new Date());
    }

    @SchedulerLock(name="SchedulerLock",lockAtMostFor = "PT4S", lockAtLeastFor = "PT4S")
//    @Scheduled(cron = "0 0 0 1 * *")
//    @Scheduled(cron = "0 0/1 * * * *")
    public void scheduler() {
//        System.out.println("차종 연식 관리"+new Date());
        VehlJobDTO dto = new VehlJobDTO();
        List<VehlJobDTO> vehlMdyList = vehlMgmtDao.selectDdatyVehlMdyList(dto);
        int listSize = vehlMdyList.size();

       //없으면 종료
        if(listSize>0) {
            for(int i=0; i<listSize; i++) {

                //메일 로직
                MailDTO mailDTO = new MailDTO(); //메일 DTO
//                  List<String> emlIds = new ArrayList<>();
                  List<Mail> rcvList = new ArrayList<Mail>();

                  mailDTO.setEmlTitl("[Owner’s Manual System] 차종 연식 월팩 일정 관련"); // 제목

                  try {
                  String content = Utils.getEmailContent("vehlMdy"); //mdy 파일 템플릿 가져오기

                  String body = HtmlUtils.htmlEscape(
                          content.replace("{qltyVehlCd}", vehlMdyList.get(i).getQltyVehlCd())
                          .replace("{mdlMdyCd}",  vehlMdyList.get(i).getMdlMdyCd()+"연식")
                          .replace("{desmp1Cd}",  vehlMdyList.get(i).getDesmp1Cd())
                          .replace("{defmp1Cd}",  vehlMdyList.get(i).getDefmp1Cd()));


                  mailDTO.setEmlSbc(body);  // 본문 내용
                  mailDTO.setEmlScdCd("16"); //구분코드 현재 차종연식은 없음
                  List<VehlJobDTO> usrList = vehlMgmtDao.selectVehlCrgrList(vehlMdyList.get(i));

                  for(int j=0;j<usrList.size(); j++) {
                      Mail mail = new Mail();
                      mail.setEmlId(usrList.get(j).getUserEeno());
                      mail.setEmlAdr(usrList.get(j).getUserEmlAdr());
                      rcvList.add(mail);
                  }
                  mailDTO.setRcvList(rcvList);
               // 메일로그 저장
                  mailDTO.setSndrId("adminuser");
                  mailService.insertLogEml(mailDTO);

                  // 메일송수신자로그 저장
                  mailService.insertLogEmlSnd(mailDTO);

                  mailService.send(mailDTO); //메일 로직 //dto에 수신자 array를 받아야함

                  } catch(Exception e) {
                      e.printStackTrace();
                  }
            }
        }




    }

}
