package com.oms.common.service;

import java.util.List;

import com.oms.common.dto.AttcFileReqDTO;
import com.oms.common.dto.AttcFileResDTO;
import com.oms.common.dto.MailDTO;
import com.oms.common.model.Mail;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @author 안경수
 * @since 2023. 5. 16.
 * @see
 */

public interface AttcFileService {
    int insertAttcFile(AttcFileReqDTO attcFileReqDTO);
    int updateAttcFile(List<AttcFileReqDTO> list);
    List<AttcFileResDTO> selectAttcFileList(AttcFileReqDTO attcFileReqDTO);
    List<String> selectAttcFilePathList(List<Long> list);
    int deleteAttcFile(List<String> attcSnDeleted);
}
