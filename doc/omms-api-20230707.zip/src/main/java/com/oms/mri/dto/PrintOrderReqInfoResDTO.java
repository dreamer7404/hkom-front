package com.oms.mri.dto;

import org.apache.ibatis.type.Alias;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * <pre>
 * PrintOrderReqInfoResDTO
 * </pre>
 *
 * @author 김정웅
 * @since 2023. 6. 1.
 * @see
 */
@Alias("printOrderReqInfoResDTO")
@Data
@AllArgsConstructor
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown =true)
public class PrintOrderReqInfoResDTO {

    private String newPrntPbcnNo;   //신인쇄발간번호
    private String qltyVehlCd;      //품질차종코드
    private String mdlMdyCd;        //모델년식코드
    private String langCd;          //언어코드
    private String prntParrYmd;     //인쇄예정년월일
    private String dlvgParrYmd;     //납품예정년월일
    private String iWayCd;          //발행방법코드
    private String prntParrQty;     //인쇄예정수량
    private String prntWayCd;       //표지인쇄방법코드
    private String depq1Cd;         //취급설명서인쇄지질코드
    private String oldPrntPbcnNo;   //구인쇄발간번호
    private String pgMgnSbc;        //페이지크기내용
    private String pgNl;            //페이지매수
    private String oordEditPgNl;    //외주편집페이지매수
    private String grnDocNl;        //보증문서매수
    private String mdfyPgNl;        //수정페이지매수
    private String depc1Yn;         //취급설명서인쇄커버유무
    private String prtlImtrSbc;     //특이사항내용
    private String saleUnp;         //판매단가
    private String ordnRqstYmd;     //발주의뢰년월일
    private String ordnCsetCdt;     //발주승인문자형일자
    private String n1Afp2Adr;       //1차첨부파일경로주소
    private String n2Afp2Adr;       //2차첨부파일경로주소
    private String crgrEeno;        //담당자사원번호
    private String crgrEenoNm;      //담당자사원명
    private String csetCrgrEeno;    //승인담당자사원번호
    private String dlExpdMdlMdyCd;  //취급설명서모델년식코드
    private String prtlImtrSbc2;    //발간현황특이사항내용2
    private String prntWayCd2;      //내지인쇄방법코드
    private String prntParrBgt;     //소요인쇄예산
    private String prtlImtrSbc3;    //발간현황특이사항내용3
    private String attcYn;          //첨부파일유무
    private String coverAttcSn;     //표지
    private String innerAttcSn;     //내지
    private String oordEditCoCd;    //외주편집업체코드
    private String pprrEeno;        //작성자사원번호
    private String framDtm;         //작성일시
    private String updrEeno;        //수정자사원번호
    private String mdfyDtm;         //수정일시
    private String blcSn;           //게시물일련번호

    private String qltyVehlNm;
    private String langCdNm;
    private String dataSn;


}
