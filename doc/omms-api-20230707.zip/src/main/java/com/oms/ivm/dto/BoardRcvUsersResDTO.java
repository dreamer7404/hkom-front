package com.oms.ivm.dto;

import java.sql.Timestamp;
import java.util.List;

import org.apache.ibatis.type.Alias;

import com.oms.common.dto.VehlMdyLangReqDTO;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @author Windows i¿½i¿½i¿½i¿½i¿½
 * @since 2023. 6. 15.
 * @see
 */
@NoArgsConstructor
@Alias("boardRcvUsersResDTO")
@Data
public class BoardRcvUsersResDTO {
    private String coNm;
    private String deptNm;
    private String userNm;
    private String userEeno;
}
