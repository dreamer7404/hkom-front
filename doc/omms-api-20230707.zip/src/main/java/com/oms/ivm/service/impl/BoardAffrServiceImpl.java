package com.oms.ivm.service.impl;

import java.util.HashMap;
import java.util.List;

import able.cloud.core.service.HService;

import org.springframework.stereotype.Service;

import com.oms.common.dto.VehlMdyLangReqDTO;
import com.oms.common.dto.VehlMdyLangResDTO;
import com.oms.ivm.dao.BoardAffrDAO;
import com.oms.ivm.dto.BoardAffrRcvUsersSaveDTO;
import com.oms.ivm.dto.BoardAffrReplyReqDTO;
import com.oms.ivm.dto.BoardAffrReplyResDTO;
import com.oms.ivm.dto.BoardAffrReqDTO;
import com.oms.ivm.dto.BoardAffrResDTO;
import com.oms.ivm.dto.BoardRcvUsersResDTO;
import com.oms.ivm.service.BoardAffrService;

import lombok.RequiredArgsConstructor;

/**
 * <pre>
 * BoardAffrServiceImpl
 * </pre>
 *
 * @author 안경수
 * @since 2023. 6. 1
 * @see
 */
@RequiredArgsConstructor
@Service("boardAffrService")
public class BoardAffrServiceImpl extends HService implements BoardAffrService {


    private final BoardAffrDAO boardAffrDAO;

    @Override
    public int insertBoardAffrMgmt(BoardAffrReqDTO boardAffrReqDTO) {

        return boardAffrDAO.insertBoardAffrMgmt(boardAffrReqDTO);
    }

    @Override
    public int insertBoardAffrVehl(List<VehlMdyLangReqDTO> list) {
        return boardAffrDAO.insertBoardAffrVehl(list);
    }

    @Override
    public int insertBoardAffrRcvUsers(BoardAffrRcvUsersSaveDTO boardAffrRcvUsersSaveDTO) {
        return boardAffrDAO.insertBoardAffrRcvUsers(boardAffrRcvUsersSaveDTO);
    }

    @Override
    public List<BoardAffrResDTO> selectBoardAffrMgmtList(String blcTitlNm) {
        return boardAffrDAO.selectBoardAffrMgmtList(blcTitlNm);
    }

    @Override
    public BoardAffrResDTO selectBoardAffrMgmt(Long blcSn) {
        return boardAffrDAO.selectBoardAffrMgmt(blcSn);
    }

    @Override
    public List<VehlMdyLangResDTO> selectBoardAffrVehl(Long blcSn) {
        return boardAffrDAO.selectBoardAffrVehl(blcSn);
    }


    /*
     * @see com.oms.ivm.service.BoardAffrService#selectBoardAffrRcvUsers(java.lang.Long)
     */
    @Override
    public List<BoardRcvUsersResDTO> selectBoardAffrRcvUsers(Long blcSn) {
        return boardAffrDAO.selectBoardAffrRcvUsers(blcSn);
    }

    /*
     * @see com.oms.ivm.service.BoardAffrService#insertBoardAffrReply(com.oms.ivm.dto.BoardAffrReplyReqDTO)
     */
    @Override
    public int insertBoardAffrReply(BoardAffrReplyReqDTO boardAffrReplyReqDTO) {
        return boardAffrDAO.insertBoardAffrReply(boardAffrReplyReqDTO);
    }

    /*
     * @see com.oms.ivm.service.BoardAffrService#selectBoardAffrMgmtReplyList(java.lang.Long)
     */
    @Override
    public List<BoardAffrReplyResDTO> selectBoardAffrMgmtReplyList(HashMap map) {
        return boardAffrDAO.selectBoardAffrMgmtReplyList(map);
    }

    /*
     * @see com.oms.ivm.service.BoardAffrService#updateBoardAffrMgmt(com.oms.ivm.dto.BoardAffrReqDTO)
     */
    @Override
    public int updateBoardAffrMgmt(BoardAffrReqDTO boardAffrReqDTO) {
        return boardAffrDAO.updateBoardAffrMgmt(boardAffrReqDTO);
    }

    /*
     * @see com.oms.ivm.service.BoardAffrService#deleteBoardAffrVehl(java.lang.Long)
     */
    @Override
    public int deleteBoardAffrVehl(Long blcSn) {
        return boardAffrDAO.deleteBoardAffrVehl(blcSn);
    }

    /*
     * @see com.oms.ivm.service.BoardAffrService#deleteBoardAffrMgmt(com.oms.ivm.dto.BoardAffrReqDTO)
     */
    @Override
    public int deleteBoardAffrMgmt(BoardAffrReqDTO boardAffrReqDTO) {
        // TODO Auto-generated method stub
        return boardAffrDAO.deleteBoardAffrMgmt(boardAffrReqDTO);
    }

    /*
     * @see com.oms.ivm.service.BoardAffrService#updateBoardAffrReply(com.oms.ivm.dto.BoardAffrReplyReqDTO)
     */
    @Override
    public int updateBoardAffrReply(BoardAffrReplyReqDTO boardAffrReplyReqDTO) {
        // TODO Auto-generated method stub
        return boardAffrDAO.updateBoardAffrReply(boardAffrReplyReqDTO);
    }

    /*
     * @see com.oms.ivm.service.BoardAffrService#deleteBoardAffrReply(com.oms.ivm.dto.BoardAffrReplyReqDTO)
     */
    @Override
    public int deleteBoardAffrReply(BoardAffrReplyReqDTO boardAffrReplyReqDTO) {
        // TODO Auto-generated method stub
        return  boardAffrDAO.deleteBoardAffrReply(boardAffrReplyReqDTO);
    }





}
