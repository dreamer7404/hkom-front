package com.oms.ivm.dto;

import java.util.Set;

import org.apache.ibatis.type.Alias;

import com.oms.common.dto.CommReqDTO;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @author 김정웅
 * @since 2023. 3. 27.
 * @see
 */
@Alias("sewonIvmReqDTO")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class SewonIvmReqDTO extends ComIvmReqDTO {

    private String vSchYmd;
    private String pFromMdlMdy;
    private String pToMdlMdy;

    private String subCd; //재고상태 ex) OK, 긴급, 발주 등..
}
