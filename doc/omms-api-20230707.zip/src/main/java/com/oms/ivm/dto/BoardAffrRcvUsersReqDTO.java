package com.oms.ivm.dto;

import org.apache.ibatis.type.Alias;

import lombok.AllArgsConstructor;
import lombok.Data;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @author Windows i¿½i¿½i¿½i¿½i¿½
 * @since 2023. 6. 12.
 * @see
 */


@AllArgsConstructor
@Alias("boardAffrRcvUsersReqDTO")
@Data
public class BoardAffrRcvUsersReqDTO {
    private Long blcSn;
    private String userEeno;
    private String emlAdr;
    private String pprrEeno;
}
