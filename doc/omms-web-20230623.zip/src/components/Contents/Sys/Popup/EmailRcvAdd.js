import React, {useState, useMemo, useRef, useEffect,useCallback} from 'react';
import { AgGridReact } from 'ag-grid-react';
import {Button, Modal, Table} from 'react-bootstrap';
import {Form, SelectPicker, Schema} from 'rsuite';
import { API, CONSTANTS } from '../../../../utils/constants';
import { useQuery,useMutation} from 'react-query';
import { getData,postData } from '../../../../utils/async';
import { confirmAlert } from 'react-confirm-alert'; // Import
import ConfirmAlert from '../../../Common/ConfirmAlert';
import CustomModal from '../../../Common/CustomModal';
const { StringType} = Schema.Types;
const model = Schema.Model({
    emlScdCd: StringType().isRequired('국가코드를 선택해주세요.'),    
});
const EmailRcvAdd = ({show, onHide}) => {
    const containerRef = useRef();
    const gridRef = useRef();
    const formRef = useRef();
    const [formError, setFormError] = useState({});
    const [formValue, setFormValue] = useState({
        emlScdCd : '',   
        rcvrList : []
    }); 
    const [usrList , setUsrList] = useState({});
    const paramsCo = {dlExpdGCd: CONSTANTS.grpCdMail};
    const mailCombo = useQuery([API.codeCombo,paramsCo], () => getData(API.codeCombo,paramsCo)) 
  
    //batch 조회
    const queryResult = useQuery([API.userMgmtPop, {}], () => getData(API.userMgmtPop, {}),{
        staleTime: 0,
    });    

    const columnDefs = [
        {
          checkboxSelection: true,
          headerCheckboxSelection: true,
          width:45,
          maxWidth:45,
          minWidth:45,
          sortable:false
        },
        {
            headerName: '부서',
            field: 'deptNm',
            maxWidth:'150',
        },
        {
            headerName: '아이디',
            field: 'userEeno',
            maxWidth:'150',
        },
        {
          headerName: '이름',
          field: 'userNm',
          maxWidth:'150',
        },
    ]

    const defaultColDef = useMemo(() => {
        return {
            initialWidth: 90,
            sortable: true,
            resizable:true,
        };
    }, []);

    const onFirstDataRendered = (params) => {
        params.api.sizeColumnsToFit();
    };


    const handleSubmit = () => {
        if (!formRef.current.check()) { //validation chk
            return;
        }
        confirmAlert({
            closeOnClickOutside: false,
            customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}   title={"알림"}
            msg={"입력하신 내용으로 저장하시겠습니까?"} 
            onOk={onOk}  />
            
        });
        
        
    }; 
    const emlRcvrSave = useMutation((params => postData(API.emlRcvrMgmt, params, CONSTANTS.insert)),{
        onSuccess: res => {
          if(res>0){
            confirmAlert({
                closeOnClickOutside: false,
                customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}   title={"알림"}
                msg={"저장이 완료되었습니다."}   />
                
            });
           }else if(res===-1){
            confirmAlert({
                closeOnClickOutside: false,
                customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}   title={"알림"}
                msg={"중복된 이메일 구분이 존재합니다."}   />
                
            });
           }else{
            confirmAlert({
                closeOnClickOutside: false,
                customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}   title={"알림"}
                msg={"에러가 발생했습니다 관리자에게 문의해주세요."}   />
                
            });
           }
           onHide();
        }
    });


    const onOk = () => {
        console.log("hwew",formValue);
        emlRcvrSave.mutate(formValue);
    }

    const onSelectionChanged = useCallback(() => {
        const userList = gridRef.current.api.getSelectedRows();

        
        setFormValue(item => ({...item, rcvrList : userList}))
        
    }, []);


    useEffect(()=>{
        console.log("formValue",formValue);
    },[formValue])

    return (
        <>
            <Form
                ref={formRef}
                checkTrigger="change"
                onChange={setFormValue}
                onCheck={setFormError}
                formValue={formValue}
                model={model}>
                    <CustomModal open={show} 
                            title={'수신자 등록'}
                            size='md'
                            handleCancel={onHide} 
                    >
             
                            <Table className="tbl-hor" bordered>
                                <colgroup>
                                    <col style={{width:'30%'}}></col>
                                    <col style={{width:''}}></col>
                                </colgroup>
                                <tbody>
                                    <tr>
                                        <th className="essen">구분</th>
                                        <td>
                                        {mailCombo.isSuccess &&
                                                <Form.Control container={()=> containerRef.current}  name="emlScdCd" size="sm" style={{zIndex: 0}} 
                                                    
                                                    placeholder={'선택'}
                                                    defaultValue={''}
                                                    accepter={SelectPicker} 
                                                    searchable={false}
                                                    cleanable={false}
                                                    data={mailCombo.isFetched && mailCombo.data}
                                                    
                                                ></Form.Control>
                                            }
                                        </td>
                                    </tr>
                                    <tr>
                                        <th className="essen">담당자</th>
                                        <td>
                                            <div className="ag-theme-alpine" style={{height:300, minWidth:300}}>
                                                <AgGridReact
                                                    ref = {gridRef}
                                                    rowData={queryResult.data}
                                                    columnDefs={columnDefs}
                                                    defaultColDef={defaultColDef}
                                                    rowSelection={'multiple'}
                                                    suppressRowClickSelection= {true} 
                                                    onFirstDataRendered={onFirstDataRendered}
                                                    suppressSizeToFit={true}    
                                                    onGridSizeChanged={onFirstDataRendered}     
                                                    onSelectionChanged={onSelectionChanged}
                                                    
                                                    >
                                                </AgGridReact>
                                            </div>
                                        </td>
                                    </tr>
                                </tbody>
                            </Table>
                            <div className='modal-footer'>
                                <Button variant="light" size="md" onClick={onHide}>취소</Button>
                                <Button variant="primary" size="md" onClick={handleSubmit} >저장</Button>
                            </div>
                       </CustomModal>
            </Form>
        </>
    );

};
export default EmailRcvAdd;