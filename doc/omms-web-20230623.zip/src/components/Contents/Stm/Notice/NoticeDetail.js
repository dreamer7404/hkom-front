// react
import React, {useState, useMemo,useEffect} from 'react';
import { AgGridReact } from 'ag-grid-react';
import {Button, Table} from 'react-bootstrap';
import { API ,CONSTANTS} from '../../../../utils/constants';
import {Form} from 'rsuite';
import { useQuery, useMutation} from 'react-query';
import { getData, postData } from '../../../../utils/async';
import { useNavigate  } from 'react-router-dom';
import { useLocation } from 'react-router';
import { confirmAlert } from 'react-confirm-alert'; // Import
import ConfirmAlert from '../../../Common/ConfirmAlert';
import qs from 'qs';
import {unescapeHtml, escapeCharChange} from '../../../../utils/commUtils';
import { DEXT5Upload } from 'dext5upload-react';

const NoticeDetail = () => {
    const navigate = useNavigate();
    const location = useLocation();
    const [detailInfo,setDetailInfo] = useState();
    const [files, setFiles] = useState(null)
    
    const [query, setQuery] = useState(
        qs.parse(location.state, { ignoreQueryPrefix: true }),
    )
    
    const columnDefs = [
        {
          headerName: '회사명',
          field: 'coNm',
        },
        {
          headerName: '부서명',
          field: 'deptNm',
        },
        {
          headerName: '아이디',
          field: 'userEeno',
        },
        {
          headerName: '이름',
          field: 'userNm',
        },
    ]
    const queryResult = useQuery([API.boardMgmt, query], () => getData(API.boardMgmt, query));


    useEffect(()=>{
        if(queryResult.isSuccess && queryResult.data){
            setDetailInfo(queryResult.data.boardInfo);
            setFiles(queryResult.data.files);
        }
    },[queryResult.status])


    const defaultColDef = useMemo(() => {
        return {
            initialWidth: 90,
            sortable: true,
        };
    }, []);


    const onFirstDataRendered = (params) => {
        params.api.sizeColumnsToFit();
    };
    const onClickUpdate = () =>{
        let param = {
            blcSn: detailInfo.blcSn,
        }
        navigate('/notice/update',{ state: param }); 
    }
    const onClickDelete = () =>{
        confirmAlert({
            closeOnClickOutside: false,
            customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}   title={"알림"}
            msg={"삭제하시겠습니까?"} 
            onOk={onDelete}  />
        });
    }

    
    const onDelete = () => {
        let param = {
            blcSn: detailInfo.blcSn,
        }
        noticeDelete.mutate(param);
    }
    const onClickHome=()=>{
        navigate('/notice',{ state: ''}); 
    }
 
    const noticeDelete = useMutation((params => postData(API.boardMgmt, params, CONSTANTS.delete)),{
        onSuccess: res => {
           if(res>0){
                confirmAlert({
                    closeOnClickOutside: false,
                    customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}   title={"알림"}
                    msg={"삭제가 완료되었습니다."}   />
                    
                });
           }
           else{
            confirmAlert({
                closeOnClickOutside: false,
                customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}   title={"알림"}
                msg={"에러가 발생했습니다 관리자에게 문의해주세요."}   />
                
            });
           }
           navigate('/notice',{ state: ''}); 
        }
    });

    // 기존업로드된 파일리스트 (수정화면에서 사용)
    const onCreationComplete = e => {
        console.log('files', files)
        if(files){
            console.log('files2', files)
            for(let i=0; i<files.length; i++){
                console.log(''+(i+1), escapeCharChange(files[i].fileNm), '', files[i].fileSize, files[i].attcSn)
                DEXT5UPLOAD.AddUploadedFile(''+(i+1), escapeCharChange(files[i].fileNm), '', files[i].fileSize, files[i].attcSn, 'dext5upload1');
            }
        }
    }
    
    return (
        <>
            <div className="write-wrap">
                <Form>
                    <Table className="tbl-hor" bordered>
                        <colgroup>
                            <col style={{width:'15%'}}></col>
                            <col style={{width:'35%'}}></col>
                            <col style={{width:'15%'}}></col>
                            <col style={{width:'35%'}}></col>
                        </colgroup>
                        <tbody>
                            <tr>
                                <th className="">게시여부</th>
                                <td>{detailInfo && detailInfo.bulYn==='Y'?'게시':'미게시'}</td>
                                <th>게시기간</th>
                                <td>{detailInfo && detailInfo.bulDtm}</td>
                            </tr>
                            <tr>
                                <th className="">업무구분</th>
                                <td colSpan="3">{detailInfo && detailInfo.affrScnNm}</td>
                            </tr>
                            <tr>
                                <th className="">게시대상</th>
                                <td colSpan="3">
                                    <div className="ag-theme-alpine" style={{height: 250, transition:'all ease .3s'}}>
                                        <AgGridReact
                                            rowData={queryResult.data && queryResult.data.rcvrList}
                                            columnDefs={columnDefs}
                                            defaultColDef={defaultColDef}

                                            onFirstDataRendered={onFirstDataRendered}
                                            suppressSizeToFit={true}    
                                            onGridSizeChanged={onFirstDataRendered}    
                                            >
                                        </AgGridReact>
                                    </div>
                                </td>
                            </tr>
                            <tr>
                                <th className="">제목</th>
                                <td colSpan="3">{detailInfo && detailInfo.blcTitlNm}</td>
                            </tr>
                            <tr>
                                <th className="">내용</th>
                                <td colSpan="3">
                                    {/* {detailInfo && detailInfo.blcSbc} */}
                                    <div dangerouslySetInnerHTML={{__html: unescapeHtml(detailInfo && detailInfo.blcSbc)}} /> 
                                    
                                </td>
                            </tr>
                            <tr>
                                <th>첨부파일</th>
                                <td colSpan="3">
                                    {files && files.length > 0 && <DEXT5Upload
                                        onCreationComplete={onCreationComplete}
                                        // onTransferComplete={onTransferComplete}
                                        // onBeforeAddItem={onBeforeAddItem}
                                        debug={false}
                                        id="dext5upload1"
                                        // mode='edit' 
                                        mode='view'  // view Mode
                                        runtimes='html5'
                                        componentUrl="/dext5upload/js/dext5upload.js"
                                        config={{MaxTotalFileSize:'100MB', MaxOneFileSize:'30MB', DevelopLangage:'NONE',
                                        // ButtonBarEdit: "add,remove,remove_all",
                                        ButtonBarView: 'download,download_all', // view Mode
                                        Width:'100%'}}
                                        
                                    />}
                                </td>
                            </tr>
                        </tbody>
                    </Table>
                </Form>
                <div className="btn-wrap">
                    <div className="left-align">
                        <Button variant="light" onClick={onClickHome}>목록</Button>{' '}
                    </div>
                    <div className="right-align">
                        <Button variant="outline-danger" onClick={onClickDelete}>삭제</Button>{' '}
                        <Button className="" variant="primary" size="md" onClick={onClickUpdate}>수정</Button>
                    </div>
                </div>
            </div>
        </>
    )
};
export default NoticeDetail;