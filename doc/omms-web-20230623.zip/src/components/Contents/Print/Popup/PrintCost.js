import React ,{useState} from 'react';
import { postData } from '../../../../utils/async';
import {Button, Modal, Table} from 'react-bootstrap';
import { DatePicker, Form, Schema,useToaster,Notification } from 'rsuite';
import { useQuery,useMutation} from 'react-query';
import { confirmAlert } from 'react-confirm-alert'; // Import
import ConfirmAlert from '../../../Common/ConfirmAlert';
import { API, CONSTANTS } from '../../../../utils/constants';
import { utcToLocalDate,escapeCharChange } from '../../../../utils/commUtils';
import { useEffect } from 'react';
import CustomModal from '../../../Common/CustomModal';
import { DEXT5Upload } from 'dext5upload-react';
 



const { StringType } = Schema.Types;
const model = Schema.Model({
    saleUnp: StringType().isRequired('평균단가를 입력해주세요'),
    
});
const PrintCost = ({data, files, show, onHide}) => {
    const formRef = React.useRef();
    const toaster = useToaster();

    useEffect(() => {
        console.log('files--', files)
    },[])
    
    
    
    const [formError, setFormError] = React.useState({});
    const [formValue, setFormValue] = React.useState({
        newPrntPbcnNo : data.newPrntPbcnNo, //차종코드
        rqQty : data.rqQty,
        saleUnp: data.saleUnp,
        prntParrBgt :data.prntParrBgt,
    });  
  //저장
    const saveData = () => {

        if (!formRef.current.check()) { //validation chk
            return;
        }
        
        confirmAlert({
            closeOnClickOutside: false,
            customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}  msg={"입력하신 내용으로 저장하시겠습니까?"} onOk={onOk} />
        });
    }


    const onOk = () => {
        DEXT5UPLOAD.Transfer();
        // bgtUpdate.mutate(formValue);
    }


    //차종코드 저장
    const bgtUpdate = useMutation((params => 
            
        postData(API.savePrntBgt, params, CONSTANTS.update)),{
            
        onSuccess: res => {
            console.log("res : ",res);
            if(res>0){
                confirmAlert({
                    closeOnClickOutside: false,
                    customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}  title={"알림"} msg={"저장이 완료되었습니다."}  />
                })
                
                onHide(true); // 창닫기 & refetch
            }else{
                confirmAlert({
                    closeOnClickOutside: false,
                    customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}  title={"알림"} msg={"저장이 실패되었습니다."}  />
                })
            }
        }
    });

    //소요예산 자동계산
    const onChangeEvent = val => {
        setFormValue(p=>({...p,
            prntParrBgt : val * data.rqQty
        }))
    }

    // 파일업로드 완료후 데이타저장
    const [fileInfo, setFileInfo] = useState(null);
    useEffect(()=> {
        if(fileInfo){

            const param = formValue;

            // 추가된 파일들
            if(fileInfo.newFile){
                // newFile
                param.attcSn = fileInfo.newFile.uploadPath; // tb_attc_mgmt의 attcSn
                param.size = fileInfo.newFile.size;
                param.extension = fileInfo.newFile.extension;
                param.originalName = fileInfo.newFile.originalName;
            }

            // 저장
            bgtUpdate.mutate(param);
        }
    },[fileInfo]);

    // 파일업로드후 리턴값
    const onTransferComplete = e => {
        const fileList = DEXT5UPLOAD.GetAllFileListForJson("dext5upload1");
        setFileInfo(fileList || {})
    }

    // 파일추가 전 처리할 내용
    const onBeforeAddItem = e => {
        if(!checkUploadFileType(e.eventInfo.paramObj)){
            confirmAlert({
                closeOnClickOutside: false,
                customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}  title={"알림"} msg={"업로드 할 수 없는 파일형식 입니다."}  />
            });
            return false;
        }
        return true;
    }
      // 기존업로드된 파일리스트 (수정화면에서 사용)
      const onCreationComplete = e => {
        if(files){
            for(let i=0; i<files.length; i++){
                DEXT5UPLOAD.AddUploadedFile(''+(i+1), escapeCharChange(files[i].fileNm), '', files[i].fileSize, files[i].attcSn, 'dext5upload1');
            }
        }
    }



    return (
        <>
             <Form ref={formRef}
                checkTrigger="change"
                onChange={setFormValue}
                onCheck={setFormError}
                formValue={formValue}
                model={model}>
                {/* <Modal show={show} onHide={onHide} backdrop="static" keyboard={false} centered size="md" className="modal-custom">
                    <Modal.Header closeButton>
                        <Modal.Title>인쇄비 입력</Modal.Title>
                    </Modal.Header>
                        <Modal.Body> */}

                <CustomModal open={show} 
                        title={'인쇄비 입력'}
                        size='lg'
                        handleCancel={onHide} 
                        >
                            <Table className="tbl-hor" bordered>
                                <colgroup>
                                    <col style={{width:'35%'}}></col>
                                    <col style={{width:''}}></col>
                                </colgroup>
                                <tbody>
                                    <tr>
                                        <th>인쇄부수</th>
                                        <td>{data.rqQty}</td>
                                    </tr>
                                    <tr>
                                        <th className="essen">평균단가</th>
                                        <td>
                                            <Form.Control size="sm" type="text" placeholder="평균단가"  name='saleUnp'  onChange={onChangeEvent} />
                                        </td>
                                    </tr>
                                    <tr>
                                        <th>소요예산</th>
                                        <td>
                                            <Form.Control size="sm" type="text" readOnly placeholder="0" name = 'prntParrBgt' />
                                        </td>
                                    </tr>
                                    <tr>
                                        <th>견적서</th>
                                        <td>
                                        <DEXT5Upload
                                                onCreationComplete={onCreationComplete}
                                                onTransferComplete={onTransferComplete}
                                                onBeforeAddItem={onBeforeAddItem}
                                                debug={false}
                                                id="dext5upload1"
                                                mode='edit' 
                                                // mode='view'  // view Mode
                                                runtimes='html5'
                                                componentUrl="/dext5upload/js/dext5upload.js"
                                                config={{MaxTotalFileSize:'100MB', MaxOneFileSize:'30MB', DevelopLangage:'NONE',
                                                ButtonBarEdit: "add,remove,download",
                                                // ButtonBarView: 'download,download_all', // view Mode
                                                Width:'100%'}}
                                                
                                            />
                                        </td>
                                    </tr>
                                </tbody>
                            </Table>
                        {/* </Modal.Body>

                        <Modal.Footer> */}
                         <div className='modal-footer'>
                            <Button variant="light" size="md" onClick={onHide}>취소</Button>
                            <Button variant="primary" size="md" onClick={() => saveData()}>저장</Button>
                        </div>
                        {/* </Modal.Footer> */}
                </CustomModal>
            </Form>
        </>
    );

};
export default PrintCost;