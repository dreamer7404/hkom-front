import React, {useEffect, useMemo, useRef, useCallback} from 'react';
import { AgGridReact } from 'ag-grid-react';
import { CONSTANTS } from '../../../../utils/constants';
import AttachmentIcon from '@rsuite/icons/Attachment';
import { formatNumber, escapeCharChangeForGrid, escapeCharChange } from '../../../../utils/commUtils';
import 'ag-grid-community/styles/ag-grid.css';
import 'ag-grid-community/styles/ag-theme-alpine.css';
import { useState } from 'react';

const GridPrintOrderClcmList = ({gridHeight, filterValue, queryResult, limit, activePage,onCellClicked, checkRow, thisNewPrntPbcnNo}) => {

  
  const gridRef = useRef();
 
  const columnDefs = [
        {
            headerName: '등록번호',
            field: 'dlExpdAltrNo',
            spanHeaderHeight: true,
            pinned:'left',
            // width:'80',
            minWidth:'80',
        },
        {
            headerName: '수신형태',
            field: 'rcpmShapNm',
            spanHeaderHeight: true,
            pinned:'left',
            minWidth:'80',
        },
        {
          headerName: '수신일',
          field: 'altrYmd',
          spanHeaderHeight: true,
          minWidth:'80',
          pinned:'left'
        },
        {
            headerName: '발신처',
            field: 'dsppNm',
            spanHeaderHeight: true,
            pinned:'left',
            minWidth:'80',
            cellRenderer:"escapeCharChangeForGrid"
        },
        {
          headerName: '개정내용',
          field: 'altrSbc',
          spanHeaderHeight: true,
          cellStyle: () => ({textDecoration: 'underline', cursor: 'pointer', color:'#2589f5'}),
          pinned:'left',
          minWidth:'500',
          tooltipField: 'altrSbc' ,
          tooltipComponentParams: { field: 'altrSbc' },
          cellRenderer:"escapeCharChangeForGrid"
        },
        {
          headerName: '첨부',
          field: 'attcYn',
          spanHeaderHeight: true,
          minWidth:'50',
          pinned:'left',
          cellRenderer: function(params) {
            //첨부파일이 있는경우
            if(params.getValue()==='Y'){
              return <AttachmentIcon style={{fontSize:'14px', cursor: 'pointer'}} />
            }
          }
        },

        {
          headerName: '적용한 발간번호',
          field: 'newPrntPbcnNo',
          spanHeaderHeight: true,
          pinned:'left',
          minWidth:'80',
          cellRenderer:"escapeCharChangeForGrid"
        },

        {
          headerName: '적용여부',
          field: 'checkbox',
          
          checkboxSelection: (prop => {
            return prop.data.newPrntPbcnNo
              ? 
                thisNewPrntPbcnNo === prop.data.newPrntPbcnNo 
                ? true
                : false
              : true
          }),
          
          spanHeaderHeight: true,
          width:'80',
          maxWidth:80,
          minWidth:80,
          pinned:'left',
          cellStyle:() => ({textAlign: 'left', align:'center'})
        },
    ]

  const CustomTooltip = (props) => {
    return (
      <div
        className="custom-tooltip"
        style={{ backgroundColor: 'white', border:'solid 1px', padding:'10px' }}
      >
        <p style={{fontSize:'13px'}}>
          {escapeCharChange(props.data[props.field])}
        </p>
      </div>
    );
  }
    
  const defaultColDef = useMemo(() => {
      return {
          initialWidth: 10,
          sortable: true,
          resizable:true,
          tooltipComponent: CustomTooltip,
      };
  }, []);

  const onFirstDataRendered = (params) => {
      params.api.sizeColumnsToFit();
  };

  const onSelectionChanged = useCallback(() => {
    const selectedRows = gridRef.current.api.getSelectedRows();
    checkRow(selectedRows)
  }, []);

  useEffect(()=>{
    if(queryResult.status === 'loading' && gridRef && gridRef.current && gridRef.current.api){
        gridRef.current.api.showLoadingOverlay();
    }
  },[queryResult]);

  useEffect(()=> {
    if(gridRef && gridRef.current && gridRef.current.api){
      gridRef.current.api.setQuickFilter(filterValue);
    }
  },[filterValue]);

  useEffect(()=> {
    if(gridRef && gridRef.current && gridRef.current.api){
      gridRef.current.api.paginationGoToPage(activePage-1);
    }
  },[activePage]);

  //O/M발주 목록 -> O/M발주 등록 넘어왔을 경우 시작(임시저장의 경우만)
  useEffect(() => {
    if(thisNewPrntPbcnNo.length> 0 && gridRef && gridRef.current && gridRef.current.api){
      const nodes = [];
      gridRef.current.api.forEachNode(node => {
        if(node.data.newPrntPbcnNo === thisNewPrntPbcnNo){
          node.setSelected(true)
        }
      })
    }
  }, [queryResult.data])


  return(
      <div className="ag-theme-alpine" style={{height: 375, transition:'all ease .3s'}}>
        <AgGridReact
            ref={gridRef} 
            rowData={queryResult && queryResult.data} 
            columnDefs={columnDefs}
            defaultColDef={defaultColDef}

            tooltipShowDelay={0}
            tooltipHideDelay={100000}

            // paging
            pagination={true}
            paginationPageSize={limit} //
            suppressPaginationPanel={true} 
            // onPaginationChanged={onPaginationChanged}

            //  filter
            cacheQuickFilter={true}

            onCellClicked={onCellClicked}

            rowSelection={'multiple'}
            suppressRowClickSelection= {true} 

            // overlay
            overlayLoadingTemplate={'<div style="padding-top:90px"><span style="padding: 10px; border: 1px solid #ccc;">차종 및 언어를 선택하세요.</span></div>'}
            overlayNoRowsTemplate={CONSTANTS.gridNoRows}
            frameworkComponents={{
              escapeCharChangeForGrid
            }}

            // checkedRowDatas by Woong
            onSelectionChanged={onSelectionChanged}

            onFirstDataRendered={onFirstDataRendered}
            suppressSizeToFit={true}
            onGridSizeChanged={onFirstDataRendered}    
            >
        </AgGridReact>
    </div>
  )


};
export default GridPrintOrderClcmList;