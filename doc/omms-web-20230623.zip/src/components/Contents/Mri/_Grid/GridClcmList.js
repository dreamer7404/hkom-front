import React, {useEffect, useMemo, useRef, useCallback} from 'react';
import { AgGridReact } from 'ag-grid-react';
import { CONSTANTS } from '../../../../utils/constants';
import AttachmentIcon from '@rsuite/icons/Attachment';
import { formatNumber, escapeCharChangeForGrid, escapeCharChange } from '../../../../utils/commUtils';
import 'ag-grid-community/styles/ag-grid.css';
import 'ag-grid-community/styles/ag-theme-alpine.css';
import { useState } from 'react';

const GridRequestState = ({gridHeight, filterValue, queryResult, limit, activePage,onCellClicked, gridLangHeader, checkRow}) => {

  const gridRef = useRef();

  const columnDefs = [
        {
            checkboxSelection: true,
            spanHeaderHeight: true,
            headerCheckboxSelection: true,
            width:'45',
            maxWidth:45,
            minWidth:45,
            pinned:'left'
        },
        {
            headerName: '등록번호',
            field: 'dlExpdAltrNo',
            spanHeaderHeight: true,
            pinned:'left',
            width:'100',
            minWidth:'80',
        },
        {
            headerName: '수신형태',
            field: 'rcpmShapNm',
            spanHeaderHeight: true,
            pinned:'left',
            minWidth:'80',
        },
        {
            headerName: '발신처',
            field: 'dsppNm',
            spanHeaderHeight: true,
            pinned:'left',
            minWidth:'80',
            cellRenderer:"escapeCharChangeForGrid"
        },
        {
          headerName: '적용차종',
          children: [
            { headerName:'차종코드', field: 'qltyVehlCd', minWidth:'80', pinned:'left'},
            { headerName:'차종명', field: 'qltyVehlNm', minWidth:'80', pinned:'left' , cellRenderer:"escapeCharChangeForGrid"},
          ],
        },
        {
            headerName: '적용언어',
            field: 'langCd',
            spanHeaderHeight: true,
            tooltipField: 'langCd' ,
            tooltipComponentParams: { field: 'langCd' },
            pinned:'left',
            minWidth:'80',
        },
        {
          headerName: '제목',
          field: 'altrTitl',
          spanHeaderHeight: true,
          cellStyle: () => ({textDecoration: 'underline', cursor: 'pointer', color:'#2589f5'}),
          pinned:'left',
          minWidth:'130',
          // tooltipField: 'altrSbc' ,
          //tooltipComponentParams: { field: 'altrSbc' },
          cellRenderer:"escapeCharChangeForGrid"
        },
        {
          headerName: '첨부',
          field: 'attcYn',
          spanHeaderHeight: true,
          minWidth:'50',
          pinned:'left',
          cellRenderer: function(params) {
            //첨부파일이 있는경우
            if(params.getValue()==='Y'){
              return <AttachmentIcon style={{fontSize:'14px', cursor: 'pointer'}} />
            }
          }
        },
        {
          headerName: '등록자',
          field: 'chgrNm',
          spanHeaderHeight: true,
          minWidth:'70',
          pinned:'left'
        },  
        {
          headerName: '등록일',
          field: 'altrYmd',
          spanHeaderHeight: true,
          minWidth:'100',
          pinned:'left'
        },
        {
          headerName: '언어(X:차기반영불필요)',
          children: gridLangHeader,
          
        },
    ]

  const CustomTooltip = (props) => {
    return (
      <div
        className="custom-tooltip"
        style={{ backgroundColor: 'white', border:'solid 1px', padding:'10px' }}
      >
        <p style={{fontSize:'13px'}}>
          {escapeCharChange(props.data[props.field])}
        </p>
      </div>
    );
  }
    
  const defaultColDef = useMemo(() => {
      return {
          initialWidth: 10,
          sortable: true,
          resizable:true,
          tooltipComponent: CustomTooltip,
      };
  }, []);

  const onFirstDataRendered = (params) => {
      params.api.sizeColumnsToFit();
  };

  const onSelectionChanged = useCallback(() => {
    const selectedRows = gridRef.current.api.getSelectedRows();
    checkRow(selectedRows)
  }, []);

  useEffect(()=>{
    if(queryResult.status === 'loading' && gridRef && gridRef.current && gridRef.current.api){
        gridRef.current.api.showLoadingOverlay();
    }
  },[queryResult]);

  useEffect(()=> {
    if(gridRef && gridRef.current && gridRef.current.api){
      gridRef.current.api.setQuickFilter(filterValue);
    }
  },[filterValue]);

  useEffect(()=> {
    if(gridRef && gridRef.current && gridRef.current.api){
      gridRef.current.api.paginationGoToPage(activePage-1);
    }
  },[activePage]);


  return(
      <div className="ag-theme-alpine" style={{height: gridHeight, transition:'all ease .3s'}}>
        <AgGridReact
            ref={gridRef} 
            rowData={queryResult && queryResult.data} 
            columnDefs={columnDefs}
            defaultColDef={defaultColDef}

            tooltipShowDelay={0}
            tooltipHideDelay={100000}
            


            // paging
            pagination={true}
            paginationPageSize={limit} //
            suppressPaginationPanel={true} 
            // onPaginationChanged={onPaginationChanged}

            //  filter
            cacheQuickFilter={true}

            onCellClicked={onCellClicked}

            rowSelection={'multiple'}
            suppressRowClickSelection= {true} 

            // overlay
            overlayLoadingTemplate={CONSTANTS.gridLoading}
            overlayNoRowsTemplate={CONSTANTS.gridNoRows}
            frameworkComponents={{
              escapeCharChangeForGrid
            }}

            // checkedRowDatas by Woong
            onSelectionChanged={onSelectionChanged}

            onFirstDataRendered={onFirstDataRendered}
            suppressSizeToFit={true}    
            onGridSizeChanged={onFirstDataRendered}    
            >
        </AgGridReact>
    </div>
  )


};
export default GridRequestState;