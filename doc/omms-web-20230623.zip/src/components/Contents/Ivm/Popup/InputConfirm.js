import React, {useState, useMemo, useEffect, useCallback, useRef} from 'react';
import {Modal, Button} from 'react-bootstrap';
import {Form, SelectPicker, Notification, toaster, MaskedInput} from 'rsuite';
import { AgGridReact } from 'ag-grid-react';
import { escapeCharChange, escapeCharChangeForGrid, formatNumber, utcToLocalDate } from '../../../../utils/commUtils';
import useStore from '../../../../utils/store';
import moment from 'moment';

// //--------------  서버데이터용 필수 -------------------------------
import { useMutation, useQuery} from 'react-query';
import { postData, getData } from '../../../../utils/async';
import { API, CONSTANTS } from '../../../../utils/constants';
// //--------------// 서버데이터용 필수 -------------------------------

import { confirmAlert } from 'react-confirm-alert'; // Import
import ConfirmAlert from '../../../Common/ConfirmAlert';

const InputConfirm = ({show, onHide, checkedRows}) => {
    // 수량 천단위 콤마 찍기
    const currencyFormatter = (params) => {
        return formatNumber(params.value);
    };

    // 입고상태 가져오기 시작
    const params = {
        mainCd: '0013'
    };
    const subCombo = useQuery([API.subCdCombo, params], () => getData(API.subCdCombo, params), {
        staleTime:0,
        select: data => data.map((item) => ({ label: escapeCharChange(item.dlExpdPrvsNm), value: item.dlExpdPrvsCd })),
        // onSuccess: () => {
        //     queryResult.refetch()
        // }
        
    }); 
    // 입고상태 가져오기 끝

    const param = {'dataSns' : checkedRows.map(item=> {return item['dataSn']}).reduce((dataSns, dataSn, idx, all) => { return idx === 0 ? dataSns+=''+dataSn : dataSns+=','+dataSn },'')};
    //데이터 조회(get)
    const queryResult = useQuery([API.ivmPdiWhsnInfo, param], () => getData(API.ivmPdiWhsnInfo, param),{
        staleTime:0
        // ,enabled: false
        ,select : data => {
            return data.map(item => ({...item, whsnQty: item.whsnQty ? item.whsnQty : 0 }))
        }
    });

    const [formValue, setFormValue] = useState();
    useEffect(() => {
      if(queryResult.isSuccess)  {
        setFormValue(queryResult.data)
      }
    },[queryResult.status])

    const gridRef = useRef();
    const defaultColDef = useMemo(() => {
        return {
            initialWidth: 90,
            resizable:true,
        };
    }, []);
    const columnDefs = [
        {
            checkboxSelection: true,
            headerCheckboxSelection: true,
            spanHeaderHeight: true,
            width:45,
            maxWidth:45,
            minWidth:45,
            sortable: false
        },  
        {
          headerName: 'DTL_SN(테스트용)',
          field: 'dtlSn',
          spanHeaderHeight: true,
        }, 
        {
          headerName: '차종',
          children: [
            { headerName:'차종코드', field: 'qltyVehlCd', minWidth:80,},
            { headerName:'차종명', field: 'qltyVehlNm',minWidth:80, cellRenderer:"escapeCharChangeForGrid" },
            { headerName:'연식', field: 'mdlMdyCd' , minWidth:50,},
          ],
        },
        {
          headerName: '언어',
          children: [
            { headerName:'지역', field: 'dlExpdPrvsNm', minWidth:80,},
            { headerName:'언어코드', field: 'langCd',minWidth:80, },
            { headerName:'언어명', field: 'langCdNm',minWidth:80, cellRenderer:"escapeCharChangeForGrid"},
          ],
        },
        {
          headerName: '발간번호',
          field: 'newPrntPbcnNo',
          spanHeaderHeight: true,
          minWidth:110,
        },  
        {
          headerName: '입고상태',
          field: 'expdWhsnStCd',
          cellRenderer:'SelectComponent',
          spanHeaderHeight: true,
          width:100,
        },  
        {
            headerName: '입고Box',
            field: 'dlExpdBoxQty',
            spanHeaderHeight: true,
            width:65,
            sortable:true,
            valueFormatter: currencyFormatter
        },  
        {
            headerName: '입고수량',
            field: 'rqQty',
            spanHeaderHeight: true,
            width:80,
            sortable:true,
            valueFormatter: currencyFormatter
        },  
        {
            headerName: '과부족',
            field: 'whsnQty',
            spanHeaderHeight: true,
            cellRenderer:'NumberComponent'
        },  
    ]

    const NumberComponent = props => {
        const option = 
            {
              mask: [/\d/, /\d/, /\d/, /\d/, /\d/, /\d/, /\d/]
            }
        const onChangeInput = (newValue, oldValue) => {
            
            if(parseInt(newValue) > parseInt(props.data.rqQty)){
                props.node.setDataValue(props.colDef.field, props.data.rqQty)
            } else {
                props.node.setDataValue(props.colDef.field, newValue.replace(/(^0+)/, ""))
            }
        };

        return (
            <div className="grid-form-wrap">
                    <MaskedInput
                        value={props.value ? props.value : 0}
                        mask={option.mask}
                        guide={false}
                        showMask={false}
                        onChange={e => onChangeInput(e, props.value)}
                        maxLength={props.data.rqQty.length}
                    />
            </div>
        )
    }

    const inputComponent = (props) => {
        const onChangeInput = (newValue, oldValue) => {
            props.node.setDataValue(props.colDef.field, newValue)
        };
        return (
          <div className="grid-form-wrap">
            <Form.Control size="sm" placeholder="" onChange={e => onChangeInput(e, props.value)} value={props.value && escapeCharChange(props.value)}/>
          </div>
        );
    }

    const SelectComponent = (props) => {
        // let selectMenuGroup = subCombo.data;
        const [selectedValue, setSelectedValue] = useState(props.value);
        const onChangeSelectDt = value => {
            setSelectedValue(value);
        };
        useEffect(() => {
            selectedValue 
            ? props.node.setDataValue('expdWhsnStCd',selectedValue)
            : props.node.setDataValue('expdWhsnStCd','01')
        })
        return (
          <div className="grid-form-wrap">
            <SelectPicker 
                size="sm" 
                data={subCombo && subCombo.data ? subCombo.data : []} 
                value={selectedValue?selectedValue:'01'} 
                searchable={false} 
                cleanable={false} 
                onChange={onChangeSelectDt}
            />
          </div>
        );
    }

    const onFirstDataRendered = (params) => {
        params.api.sizeColumnsToFit();
    };

    // 그리드 내에서 체크된 rows by Woong
    const [checkedRowsForOutReqInput, setCheckedRowsForOutReqInput] = useState([]);    
    const [checkedNodesForOutReqInput, setCheckedNodesForOutReqInput] = useState([]);    
    const onSelectionChanged = useCallback(() => {
        setCheckedRowsForOutReqInput(gridRef.current.api.getSelectedRows())
        setCheckedNodesForOutReqInput(gridRef.current.api.getSelectedNodes())
    }, []);

    //데이터 등록(post)
    const submitResult = useMutation([API.ivmPdiWhsnInfo, checkedRowsForOutReqInput], () => postData(API.ivmPdiWhsnInfo, checkedRowsForOutReqInput, CONSTANTS.insert),{
		onSuccess: res => {
		    if(res > 0){
		        toaster.push(
                    <Notification type='success' header='요청성공' closable >입고 저장이 완료되었습니다. </Notification>
                );
                show=false;
                onHide(); // 창닫기
		    }else{
		        toaster.push(
                    <Notification type='error' header='요청실패' closable >입고 저장을 실패했습니다. </Notification>
                );
		    }
		}
	});

    //저장 버튼 클릭시
    const onSubmit = (e, scrollCheck) => {
        
        let errMessage = '';
        if(checkedRowsForOutReqInput.length === 0 && !scrollCheck){
            scrollCheck = true
            confirmAlert({
                closeOnClickOutside: false,
                customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}  title={"알림"} msg={"선택된 항목이 없습니다."}  />
            })
            return false
        }
        // gridRef.current.api.redrawRows()

        // for(let i = 0; i < checkedNodesForOutReqInput.length; i ++){
        //     if(checkedNodesForOutReqInput[i].data.whsnQty === '0' || checkedNodesForOutReqInput[i].data.whsnQty === '' || checkedNodesForOutReqInput[i].data.whsnQty === 0) {
        //         errMessage = '수량을 입력하세요.'
        //         if(scrollCheck !== true) {
        //             gridRef.current.api.ensureIndexVisible(checkedNodesForOutReqInput[i].rowIndex)
        //             confirmAlert({
        //                 closeOnClickOutside: false,
        //                 customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}  title={"알림"} msg={errMessage}  />
        //             })
        //         }
        //         gridRef.current.api.flashCells({ rowNodes: [checkedNodesForOutReqInput[i]], columns: ['whsnQty'], fadeDelay: 400000, flashDelay:10 });        
        //         scrollCheck = true
        //         break
        //     }
        // }

        if(scrollCheck) {
            return false
        } else {
            const onOk = () => {
                submitResult.mutate(checkedRowsForOutReqInput)
            }
            confirmAlert({
                closeOnClickOutside: false,
                customUI: ({ onClose }) => <ConfirmAlert 
                                                onClose={onClose} 
                                                title={"알림"}
                                                msg={"입력하신 내용으로 입고확인하시겠습니까?"} 
                                                onOk={onOk}  
                                            />
            })
        }
    };

    
    return (
        <>
            <Form>
                <Modal show={subCombo.isSuccess && show} onHide={onHide} backdrop="static" keyboard={false} centered size="xl" className="modal-custom size-2xl">
                    <Modal.Header closeButton>
                        <Modal.Title>입고확인</Modal.Title>
                    </Modal.Header>
                    <Modal.Body>
                        <div className="grid-btn-wrap">
                            <div className="right-align">
                                <Button variant="outline-dark" size="sm"><span className="print"></span>{CONSTANTS.print}</Button>{' '}
                            </div>
                        </div>
                        <div className="ag-theme-alpine" style={{height:300, minWidth:300}}>
                            <AgGridReact
                                ref={gridRef} 
                                // rowData={rowData}
                                rowData={subCombo.isSuccess && formValue}
                                columnDefs={columnDefs}
                                defaultColDef={defaultColDef}
                                rowSelection={'multiple'}
                                suppressRowClickSelection= {true} 
                                frameworkComponents={{
                                inputComponent,
                                SelectComponent,
                                escapeCharChangeForGrid,
                                currencyFormatter,
                                NumberComponent
                                }}
                                // checkedRowDatas by Woong
                                onSelectionChanged={onSelectionChanged}

                                overlayLoadingTemplate={CONSTANTS.gridLoading}
                                overlayNoRowsTemplate={CONSTANTS.gridNoRows}

                                onFirstDataRendered={onFirstDataRendered}
                                suppressSizeToFit={true}    
                                onGridSizeChanged={onFirstDataRendered}     
                                onGridColumnsChanged={onFirstDataRendered}
                                >
                            </AgGridReact>
                        </div>
                    </Modal.Body>
                    <Modal.Footer>
                        <Button variant="light" size="md" onClick={onHide}>취소</Button>
                        <Button variant="primary" size="md" onClick={e => {onSubmit(e, false)}}>저장</Button>
                    </Modal.Footer>
                </Modal>
            </Form>
        </>
    );

};
export default InputConfirm;