import React, { useState, useMemo, useRef, useEffect } from 'react';
import {Button, Modal} from 'react-bootstrap';
import { AgGridReact } from 'ag-grid-react';
import { CONSTANTS } from '../../../../utils/constants';
// //--------------  서버데이터용 필수 -------------------------------
import { useQuery } from 'react-query';
import { getData } from '../../../../utils/async';
import { API } from '../../../../utils/constants';
import { formatNumber } from '../../../../utils/commUtils';
// //--------------// 서버데이터용 필수 -------------------------------

const SewonIvmHave = ({show, onHide, clickedRowData}) => {

    // 수량 천단위 콤마 찍기 끝
    const currencyFormatter = (params) => {
        return formatNumber(params.value);
    }; 

    const queryResult = useQuery([API.ivmSewonIvs, clickedRowData], () => getData(API.ivmSewonIvs, clickedRowData), {
        //화면 열렸을때 무조건 실행 방지를 위한 옵션.
        enabled: false,
    });

    useEffect(() => {
        if(show){
            queryResult.refetch();
        }
    }, [clickedRowData]);

    
    const onFirstDataRendered = (params) => {
        params.api.sizeColumnsToFit();
    };

    const defaultColDef = useMemo(() => {
        return {
            sortable: true,
            minWidth:100,
            resizable:false,
            flex:1,
        };
    }, []);

    

    const [rowData] = useState([
    {printNum:'ABCD-20A', printStart:'2023-01-18', printEnd:'2023-01-31', preTot:'0', ivmTot:'150',test:''},
    {printNum:'ABCD-20A', printStart:'2023-01-18', printEnd:'2023-01-31', preTot:'0', ivmTot:'200',test:''},
    ]);

    const columnDefs = [
        {
            headerName: '발간번호',
            field: 'newPrntPbcnNo',
            colSpan: (params) => {
                const newPrntPbcnNo = params.data.newPrntPbcnNo;
                if (newPrntPbcnNo === 'TOTAL') {
                    // have all Russia age columns width 2
                    return 4;
                } else {
                    // all other rows should be just normal
                    return 1;
                }
            }
        },
        {
            headerName: '발주일',
            field: 'prntParrYmd',
        },
        {
            headerName: '납품일',
            field: 'dlvgParrYmd',
        },
        {
            headerName: '기납품수량',
            field: 'prevDlvgQty',
            valueFormatter: currencyFormatter
        }, 
        {
            headerName: '재고수량',
            field: 'ivQty',
            valueFormatter: currencyFormatter
        }, 
        {
            headerName: '타연식 제공내역',
            field: 'ivText',
        }, 
    ]

    const [total, setTotal] = useState({});
    const [queryResultRealDatas, setQueryResultRealDatas] = useState([]);

    useEffect(()=>{
        if(queryResult.isSuccess){
            setTotal(
                queryResult.isSuccess && queryResult.data.filter(item => {
                    return item.newPrntPbcnNo === 'TOTAL'
                })[0]
            )
            setQueryResultRealDatas (
                queryResult.isSuccess && queryResult.data.filter(item => {
                    return item.newPrntPbcnNo !== 'TOTAL'
                })
            )
        }    
    },[queryResult.data]);

    const pinnedBottomRowData = [total];

    return (
        <>
            <Modal show={show} onHide={onHide} backdrop="static" keyboard={false} centered size="lg" className="modal-custom">
                <Modal.Header closeButton>
                    <Modal.Title>세원재고(보유재고)</Modal.Title>
                </Modal.Header>
                <Modal.Body>
                    <div className="grid-btn-wrap">
                        <div className="left-align">
                            <div className="sub-title">
                                <ul>
                                    {/*                                     
                                    <li>차종 <span>(AA-19)AA-CAR</span></li>
                                    <li>언어 <span>EC(영어,불어/캐나다)</span></li>
                                     */}
                                    <li>차종 <span>({clickedRowData.qltyVehlCd} - {clickedRowData.mdlMdyCd}){clickedRowData.qltyVehlNm}</span></li>
                                    <li>언어 <span>{clickedRowData.langCd}({clickedRowData.langCdNm})</span></li>
                                </ul>
                            </div>
                        </div>
                        <div className="right-align">
                            <Button variant="outline-success" size="sm"><span className="excel-down"></span>{CONSTANTS.excelDownload}</Button>{' '}
                            <Button variant="outline-dark" size="sm"><span className="print"></span>{CONSTANTS.print}</Button>{' '}
                        </div>
                    </div>
                    <div style={{ display: 'flex', flexDirection: 'column', height: 300 }} className="ag-theme-alpine" >
                        <div style={{ flex: '1 1 auto'}}>
                            <AgGridReact
                                // rowData={rowData}
                                // rowData={queryResult && queryResult.data}
                                rowData={queryResult && queryResultRealDatas}                                
                                columnDefs={columnDefs}
                                defaultColDef={defaultColDef}
                                onFirstDataRendered={onFirstDataRendered}
                                suppressSizeToFit={true}
                                pinnedBottomRowData={pinnedBottomRowData}
                                // overlay
                                overlayLoadingTemplate={CONSTANTS.gridLoading}
                                overlayNoRowsTemplate={CONSTANTS.gridNoRows}
                                >
                            </AgGridReact>
                        </div>
                    </div>
                </Modal.Body>
                <Modal.Footer>
                    <Button variant="light" size="md" onClick={onHide}>취소</Button>
                </Modal.Footer>
            </Modal>
        </>
    )
};
export default SewonIvmHave;