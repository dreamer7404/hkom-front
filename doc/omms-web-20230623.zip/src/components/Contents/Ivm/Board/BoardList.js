// react
import React, {useState, useEffect, useCallback} from 'react';
import {Col, Button, Collapse} from 'react-bootstrap';
import {Form, Input} from 'rsuite';
import SearchIcon from '@rsuite/icons/Search';
import { useNavigate, Link  } from 'react-router-dom';
//--------------  서버데이터용 필수 -------------------------------
import { useQuery, useQueryClient, useMutation} from 'react-query';
import { getData, postData } from '../../../../utils/async';
import { API, CONSTANTS } from '../../../../utils/constants';
import useStore from '../../../../utils/store';
//--------------// 서버데이터용 필수 -------------------------------

import GridBoardList from '../_Grid/GridBoardList';
import Paging from '../../../Common/Paging';
import { CustomInputGroup } from '../../../Common/CustomInputGroup';


// icon
import {ArrowDownLine, ArrowUpLine, FileDownload} from '@rsuite/icons';


const BoardList = () => {

    //------------------- 필수 공통 ------------------------------
    const [open, setOpen] = useState(true); // 조건창 열기/닫기
    const {keyword } = useStore();  // 조회키워드 가져오기

    const [activePage, setActivePage] = useState(1);    // 페이지번호
    const [limit, setLimit] = useState(50);             // 페이지행수
    const [filterValue, setFilterValue] = useState(''); // 필터값
    const navigate = useNavigate();
    const onChangePage = val => {
        setActivePage(val);
    };
    const onChangeLimit = val => {
        setLimit(val);
    };
    useEffect(()=>{
        onChangePage(1); // 페이지번호 리셋
    },[keyword]);

    // 필터
    const onFilterTextBoxChanged = useCallback((e) => {
        setFilterValue(e.target.value);
    }, []);

    // 검색창 열기/닫기 > 페이지네이션 여부에 따라 +-20px
    const [gridHeight, setGridHeight] = useState(575);
    const gridExpand = () =>{
        setOpen(!open);
        if(open){
            setTimeout(() => setGridHeight(650), 250);
        }else{
            setGridHeight(575)
        }
    }
    //-------------------// 필수 공통 ------------------------------


     // 게시판 목록
   const queryResult = useQuery([API.boardAffrMgmts], () => getData(API.boardAffrMgmts), {
        select: data => { 
            if(data.length === 1) return data;

            data[data.length-1].flag = 1;
            let cnt = 1;
            for(let i=data.length-2; i>=0; i--){
                if(data[i].blcSn === data[i+1].blcSn){
                    data[i+1].flag = 1;
                    data[i].flag = ++cnt;
                }else{
                    cnt = 1;
                    data[i].flag = 1;
                }
            }
            return data;
        }
   });


    // 셀 클릭
    const onCellClicked = e => {
        console.log('click', e)
        if(e.column.colId === 'blcTitlNm'){
            navigate('/board/detail',{ state: e.data.blcSn }); 
        }
    };


    const addButton = () => {
        navigate('/board/add'); 
    }

    // 조회버튼
    const onSearch = () => {
        queryResult.refetch(); // 수동쿼리실행
    };

    //---------------- test -------------------------------------------------------------------------
    const testMutate = useMutation((params => postData("testMail", params, CONSTANTS.insert)),{
        onSuccess: res => {
            console.log('res', res);
        }
    });

    const mailTest = () => {
        testMutate.mutate({
            blcSn: 99,
            rcvUsers: ['H2212239', 'H2212238'], 
            blcTitlNm: 'test1234',
            blcSbc: 'constent123'
        });
    }

    return (
        <>
            <div className="search-area">
                <Collapse in={open}>
                    <div className="form" id="example-collapse-text">
                        <div className="search-group">
                            <div className="row">
                                <Col sm={3} className=""> 
                                    <Form.ControlLabel column="sm">제목</Form.ControlLabel>
                                    <Input size="sm" type="text" />
                                </Col>
                            </div>

                            <div className="search-btn-wrap">
                                <Button className="btn-search" variant="outline-primary" size="sm" onClick={onSearch}><SearchIcon />조회</Button>
                            </div>
                        </div>
                    </div>
                </Collapse>
                <Button size="sm" variant="outline-dark" className="search-control" aria-controls="example-collapse-text" 
                    aria-expanded={open} onClick={gridExpand}>
                    {/* <span className={open === true ? "search-area-close" : "search-area-open"}>{open === true ? CONSTANTS.closeSearch : CONSTANTS.openSearch}</span> */}
                    {open ? <span className="search-area-close"><ArrowUpLine style={{marginRight: '5px', fontSize: '2em'}} />{CONSTANTS.closeSearch}</span> :
                    <span className="search-area-open"><ArrowDownLine style={{marginRight: '5px', fontSize: '2em'}} />{CONSTANTS.openSearch}</span>}
                </Button>
            </div>
            
            <div className="grid-wrap">
                <div className="grid-btn-wrap">
                    <div className="left-align">
                        {/*--------- 필터 -----------*/}
                        <CustomInputGroup size="sm"   onInput={onFilterTextBoxChanged} />
                    </div>
                    <div className="right-align">
                        <Button variant="outline-secondary" size="sm" onClick={addButton}>게시글 등록</Button>{' '}
                        <Button variant="outline-secondary" size="sm" onClick={mailTest}>mail test</Button>{' '}
                    </div>
                </div>
               {/*--------- Grid -----------*/}
                <GridBoardList 
                    gridHeight={gridHeight}
                    filterValue={filterValue}
                    queryResult={queryResult}
                    limit={limit}
                    activePage={activePage}
                    onCellClicked={onCellClicked}
                    />

                {/*--------- 페이징 -----------*/}
                <Paging 
                    total={queryResult && queryResult.data && queryResult.data.length}
                    limit={limit}
                    activePage={activePage}
                    onChangePage={onChangePage}
                    onChangeLimit={onChangeLimit}
                />
            </div>
        </>
    )
};
export default BoardList;