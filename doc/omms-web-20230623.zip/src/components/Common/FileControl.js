import React, {useState, useEffect} from 'react';
//--------------  서버데이터용 필수 -------------------------------
import { API,CONSTANTS } from '../../utils/constants';
import { useQuery} from 'react-query';
// import useStore from '../../../../utils/store';
import { getData,postData } from '../../utils/async';
//--------------// 서버데이터용 필수 -------------------------------

import { DEXT5Upload } from 'dext5upload-react';
import CustomModal from './CustomModal';
import { changeCharToEscape, escapeCharChange, checkUploadFileType, convertYmd, unescapeHtml} from '../../utils/commUtils'; 

import { confirmAlert } from 'react-confirm-alert'; 
import ConfirmAlert from  '../Common/ConfirmAlert';

const FileControl = ({keyValue, gubun, onHide, setFileList}) => {

    // const [fileInfo, setFileInfo] = useState(false);
    const [show, setShow] = useState(false)
    const [files, setFiles] = useState(null)


    const param = {
        attcGbn: gubun, // 게시물구분
        gbnSn: keyValue
    };
    const queryResult = useQuery([API.fileDownload, param], () => getData(API.fileDownload, param),{
        enabled: keyValue
    });

    useEffect(()=>{
        console.log('keyvalue',keyValue)
        if(!keyValue){
            setShow(true);
        }
    },[keyValue])

    useEffect(()=>{
        if(queryResult.data){
            console.log('queryResult.data',queryResult.data)
            setFiles(queryResult.data);
            setShow(true);
        }
    },[queryResult.status])

    // 파일업로드후 - 리턴값(uploadPath)는 여기서만 받음.
    const onTransferComplete = e => {
        const fileList = DEXT5UPLOAD.GetAllFileListForJson("dext5upload1");
        setFileInfo(fileList || {})
    }

    // 파일추가 전 처리할 내용
    const onBeforeAddItem = e => {
        if(!checkUploadFileType(e.eventInfo.paramObj)){
            confirmAlert({
                closeOnClickOutside: false,
                customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}  title={"알림"} msg={"업로드 할 수 없는 파일형식 입니다."}  />
            });
            return false;
        }
        return true;
    }

    // 기존업로드된 파일리스트 (수정화면에서 사용)
    const onCreationComplete = e => {
        if(files){
            for(let i=0; i<files.length; i++){
                DEXT5UPLOAD.AddUploadedFile(''+(i+1), escapeCharChange(files[i].fileNm), '', files[i].fileSize, files[i].attcSn, 'dext5upload1');
            }
        }
    }

    return(
            <CustomModal open={true} 
                        title={'첨부파일'}
                        size='lg'
                        handleCancel={onHide} 
                        >
                       <div>
                            {show && <DEXT5Upload
                                onCreationComplete={onCreationComplete}
                                onTransferComplete={onTransferComplete}
                                onBeforeAddItem={onBeforeAddItem}
                                debug={false}
                                id="dext5upload1"
                                mode={keyValue ? 'edit' : 'view'}  
                                runtimes='html5'
                                componentUrl="/dext5upload/js/dext5upload.js"
                                config={
                                    keyValue ? {MaxTotalFileSize:'100MB', MaxOneFileSize:'30MB', DevelopLangage:'NONE', Width:'100%',
                                    ButtonBarEdit: "add,remove,remove_all,download,download_all" // edit mode
                                } : {
                                    MaxTotalFileSize:'100MB', MaxOneFileSize:'30MB', DevelopLangage:'NONE', Width:'100%',
                                    ButtonBarView: 'download,download_all' // view Mode
                                }}
                                
                            />}
                       </div>
            </CustomModal>
        
    )

};
export default FileControl;
