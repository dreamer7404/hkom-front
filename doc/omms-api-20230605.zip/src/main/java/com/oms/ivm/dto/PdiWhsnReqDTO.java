package com.oms.ivm.dto;

import java.util.Set;

import org.apache.ibatis.type.Alias;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @author 김정웅
 * @since 2023. 5. 9.
 * @see
 */

@Alias("pdiWhsnReqDTO")
@Data
@AllArgsConstructor
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown =true)
public class PdiWhsnReqDTO extends ComIvmReqDTO{

    private String expdWhsnStNm;
    private String dlExpdBoxQty;
    private String rqQty;
    private int deei1Qty;
    private String whsnYmd;
    private String crgrNm;
    private String dtlSn;
    private String expdWhsnStCd;
    private String crgrEeno;
    private String clScnCd;
    private String pwtiNm;
    private int whsnQty;

    private int vDiffRqQty;
    private int vDeei1Qty;

}
