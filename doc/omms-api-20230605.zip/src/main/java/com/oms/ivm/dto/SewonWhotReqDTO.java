package com.oms.ivm.dto;

import java.util.Set;

import org.apache.ibatis.type.Alias;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.oms.common.dto.CommReqDTO;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @author 김정웅
 * @since 2023. 3. 28.
 * @see
 */
@Alias("sewonWhotReqDTO")
@Data
@AllArgsConstructor
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown =true)
public class SewonWhotReqDTO extends ComIvmReqDTO {

    private String whotYmd;
    private String dlExpdRqScnCd;
    private String dlvgParrYmd;
    private String dlvgParrHhmm;
    private String rqQty;
    private String pwtiNm;
    private String prtlImtrSbc;
    private String crgrEeno;
    private String dlExpdBoxQty;
    private String cmplYn;
    private String updrEeno;
    private String qltyVehlCd;
    private String mdlMdyCd;
    private String langCd;
    private String dlExpdMdlMdyCd;
    private String newPrntPbcnNo;
    private String dtlSn;

    private String clScnCd;
    private String dataSn;
    private String dlExpdPrvsNm;
    private String expdCoNm;
    private String expdRqScnNm;
    private String ivQty;
    private String langCdNm;
    private String langSortSn;
    private String pwtiEeno;
    private String pwtiTn;
    private String qltyVehlNm;
}
