package com.oms.stm.dto;



import java.util.List;

import org.apache.ibatis.type.Alias;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


/**
 * <pre>
 * Statements
 * </pre>
 * @ClassName : VehlMgmtResDTO.java
 * @Description :
 * @author 김경훈
 * @since 2023. 3. 13.
 * @see
 */
@JsonIgnoreProperties(ignoreUnknown=true)
@Alias("vehlMgmtResDTO")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class VehlMgmtResDTO {

    private String qltyVehlCd;
    private String mdlMdyCd;
    private String qltyVehlNm;
    private String dlExpdPacScnCd;
    private String pacScnGbn;
    private String dlExpdPdiCd;
    private String pdiNm;
    private String jbMdyRelCd;
    private String jbMdyRelNm;
    private String dytmPlnCd;
    private String prdnMstCd;
    private String bomVehlCd;
    private String saleVehlCd;
    private String hmc;
    private String kyung;
    private String sehwa;
    private String pdi;
    private String dlExpdRegnCd;
    private String dlExpdNatCd;
    private String chkCpVehl;
    private String lastMy;
    private String dlExpdPrvsCd;
    private String regn01;
    private String regn02;
    private String regn03;
    private String regn04;
    private String regn05;
    private String regn06;
    private String dlExpdPrvsNm;
    private String dlExpdPacScnNm;
    private String valCd;
    private String totNm;
    private String useYn;
    private String chkMdy;


    List<VehlMgmtResDTO> vehlList;
    List<VehlMgmtResDTO> vehlCombo;
    List<VehlMgmtResDTO> pdiCombo;
    List<VehlMgmtResDTO> regnList;

}
