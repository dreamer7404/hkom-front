package com.oms.stm.dto;

import java.sql.Timestamp;
import java.util.List;

import org.apache.ibatis.type.Alias;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.oms.common.dto.CommReqDTO;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


/**
 * <pre>
 * Statements
 * </pre>
 * @ClassName : NatlMgmtSaveDTO.java
 * @Description :
 * @author 김경훈
 * @since 2023. 5. 23.
 * @see
 */
@JsonIgnoreProperties(ignoreUnknown=true)
@Alias("natlMgmtSaveDTO")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class NatlMgmtSaveDTO extends CommReqDTO {

    private String dlExpdCoCd;     // DL_EXPD_CO_CD(tb_natl_mgmt) : VARCHAR(4)
    private String dlExpdNatCd;     // DL_EXPD_NAT_CD(tb_natl_mgmt) : VARCHAR(5)
    private String dlExpdRegnCd;     // DL_EXPD_REGN_CD(tb_natl_mgmt) : VARCHAR(4)
    private String natNm;     // NAT_NM(tb_natl_mgmt) : VARCHAR(40)
    private String dytmPlnNatCd;     // DYTM_PLN_NAT_CD(tb_natl_mgmt) : VARCHAR(5)
    private String prdnMstNatCd;     // PRDN_MST_NAT_CD(tb_natl_mgmt) : VARCHAR(5)
    private String userEeno;     // PPRR_EENO(tb_natl_mgmt) : VARCHAR(20)
    private Timestamp framDtm;     // FRAM_DTM(tb_natl_mgmt) : DATETIME(19)
    private String updrEeno;     // UPDR_EENO(tb_natl_mgmt) : VARCHAR(20)
    private Timestamp mdfyDtm;     // MDFY_DTM(tb_natl_mgmt) : DATETIME(19)
    private String qltyVehlCd;  // 차종
    private String mdlMdyCd; //연식
    private String regnNm; //지역명
    private String natCd; //국가코드
    private String langCd; //언어코드
    private String useYn;






    private List<NatlMgmtSaveDTO> vehlList; // 국가별 차량코드,차량별 언어코드 등록
    private List<String> langs; // langCd




}

