package com.oms.common.service.impl;

import java.util.ArrayList;
import java.util.List;

import able.cloud.core.service.HService;

import org.springframework.stereotype.Service;

import com.oms.common.dao.CommComboDAO;
import com.oms.common.dto.CommLangComboReqDTO;
import com.oms.common.dto.CommLangComboResDTO;
import com.oms.common.service.CommComboService;

import lombok.RequiredArgsConstructor;

/**
 * <pre>
 * CommComboServiceImpl
 * </pre>
 *
 * @author 김정웅
 * @since 2023. 3. 13.
 * @see
 */
@RequiredArgsConstructor
@Service("commComboService")
public class CommComboServiceImpl extends HService implements CommComboService {

    private final CommComboDAO commComboDAO;

    @Override
    public List<CommLangComboResDTO> selectCommLangComboList(CommLangComboReqDTO commLangComboReqDTO) throws Exception {
        List<CommLangComboResDTO> result = new ArrayList<CommLangComboResDTO>();
        result = commComboDAO.selectCommLangComboList(commLangComboReqDTO);
        return result;
    }




}
