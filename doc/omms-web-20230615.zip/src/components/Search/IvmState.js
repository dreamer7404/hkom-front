import React from 'react';
import { Form, SelectPicker } from 'rsuite';

//--------------  서버데이터용 필수 -------------------------------
import { useQuery} from 'react-query';
import { getData } from '../../utils/async';
import { API, CONSTANTS } from '../../utils/constants';
import useStore from '../../utils/store';
//--------------// 서버데이터용 필수 -------------------------------


const IvmState = () => {

    const {keyword, 
        setSubCd,  // sub코드 setter
    } = useStore(); 

    const onChangeSubCd = val => {
        setSubCd(val);
    };


    // subCd API가져오기
    const subCdParams = {
        mainCd: '0016'
    };
    const subCdCombo = useQuery([API.subCdCombo, subCdParams], () => getData(API.subCdCombo, subCdParams), {
            select: data => [{label: CONSTANTS.labelAll, value: CONSTANTS.valueAll}].concat(data.map((item) => ({ label: item.dlExpdPrvsNm, value: item.dlExpdPrvsCd })))
    });

    return (
        <>
            <Form.ControlLabel column="sm" >재고상태</Form.ControlLabel>
            <SelectPicker size="sm" style={{width: '100xpx'}}
                value={keyword.subCd} 
                data={subCdCombo.isFetched && subCdCombo.data ? subCdCombo.data : []} 
                onChange={onChangeSubCd}
                placeholder={CONSTANTS.labelAll}
                cleanable={false}
                searchable={false}
                block={false}
            />
        </>
    )
}
export default IvmState;