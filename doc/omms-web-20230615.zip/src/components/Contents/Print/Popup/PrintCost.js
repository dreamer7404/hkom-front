import React from 'react';
import { postData } from '../../../../utils/async';
import {Button, Modal, Table} from 'react-bootstrap';
import { DatePicker, Form, Schema,useToaster,Notification } from 'rsuite';
import { useQuery,useMutation} from 'react-query';
import { confirmAlert } from 'react-confirm-alert'; // Import
import ConfirmAlert from '../../../Common/ConfirmAlert';
import { API, CONSTANTS } from '../../../../utils/constants';
import { utcToLocalDate } from '../../../../utils/commUtils';
import { useEffect } from 'react';



const { StringType } = Schema.Types;
const model = Schema.Model({
    saleUnp: StringType().isRequired('평균단가를 입력해주세요'),
    
});
const PrintCost = ({data,show, onHide}) => {
    const formRef = React.useRef();
    const toaster = useToaster();
    
    
    
    const [formError, setFormError] = React.useState({});
    const [formValue, setFormValue] = React.useState({
        newPrntPbcnNo : data.newPrntPbcnNo, //차종코드
        rqQty : data.rqQty,
        saleUnp: data.saleUnp,
        prntParrBgt :data.prntParrBgt,
    });  
  //저장
    const saveData = () => {
        
        confirmAlert({
            closeOnClickOutside: false,
            customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}  msg={"입력하신 내용으로 저장하시겠습니까?"} onOk={onOk} />
        });
    }


    const onOk = () => {
        if (!formRef.current.check()) { //validation chk
            return;
        }


        bgtUpdate.mutate(formValue);
    }


    //차종코드 저장
const bgtUpdate = useMutation((params => 
        
    postData(API.savePrntBgt, params, CONSTANTS.update)),{
        
    onSuccess: res => {
        console.log("res : ",res);
        if(res>0){
            console.log(res);
            toaster.push(<Notification type='success' header='등록성공' closable >
            저장이 완료되었습니다.
            </Notification>);
            
            onHide(true); // 창닫기 & refetch
        }else{
            toaster.push(<Notification type='success' header='등록성공' closable >
            
            </Notification>);
        }
    }
});

 //소요예산 자동계산
const onChangeEvent = val => {

    setFormValue(p=>({...p,
        prntParrBgt : val * data.rqQty
    }) )
}

useEffect(()=>{

    console.log("1",formValue)


},[formValue])


    return (
        <>
             <Form ref={formRef}
                checkTrigger="change"
                onChange={setFormValue}
                onCheck={setFormError}
                formValue={formValue}
                model={model}>
                <Modal show={show} onHide={onHide} backdrop="static" keyboard={false} centered size="md" className="modal-custom">
                    <Modal.Header closeButton>
                        <Modal.Title>인쇄비 입력</Modal.Title>
                    </Modal.Header>
                        <Modal.Body>
                            <Table className="tbl-hor" bordered>
                                <colgroup>
                                    <col style={{width:'35%'}}></col>
                                    <col style={{width:''}}></col>
                                </colgroup>
                                <tbody>
                                    <tr>
                                        <th>인쇄부수</th>
                                        <td>{data.rqQty}</td>
                                    </tr>
                                    <tr>
                                        <th className="essen">평균단가</th>
                                        <td>
                                            <Form.Control size="sm" type="text" placeholder="평균단가"  name='saleUnp'  onChange={onChangeEvent} />
                                        </td>
                                    </tr>
                                    <tr>
                                        <th>소요예산</th>
                                        <td>
                                            <Form.Control size="sm" type="text" readOnly placeholder="0" name = 'prntParrBgt' />
                                        </td>
                                    </tr>
                                    <tr>
                                        <th>견적서</th>
                                        <td>
                                            파일선택
                                        </td>
                                    </tr>
                                </tbody>
                            </Table>
                        </Modal.Body>

                        <Modal.Footer>
                            <Button variant="light" size="md" onClick={onHide}>취소</Button>
                            <Button variant="primary" size="md" onClick={() => saveData()}>저장</Button>
                        </Modal.Footer>
                </Modal>
            </Form>
        </>
    );

};
export default PrintCost;