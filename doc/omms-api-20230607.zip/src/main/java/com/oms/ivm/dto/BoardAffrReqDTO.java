package com.oms.ivm.dto;

import java.util.List;

import org.apache.ibatis.type.Alias;

import lombok.Data;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @author 안경수
 * @since 2023. 5. 26.
 * @see
 */
@Alias("boardAffrReqDTO")
@Data
public class BoardAffrReqDTO {

    private String blcScnCd;
    private String rgnEeno;
    private String blcRgstYmd;
    private String befmyTrwiYn;
    private String bbYn;
    private String bbVal;
    private String dtrwiYn;
    private String dtrwiRqYmd;
    private String dtrwiMidcsnYn;
    private String altrTrwiYn;
    private String nmtrwiRqYmd;
    private String nmtrwiMidcsnYn;

    private String blcTitlNm; //게시물제목명
    private String blcSbc;  // 게시물내용
//    private String attcYn;   // 첨부여부
//    private String replyYn; // 댓글여부
//    private String delYn;   // 삭제여부
//    private Long emlCd;     // 이메일 코드

    private List<String> langCdByVehl; // 차종코드
    private List<String> rcvUsers; // 수신인

}
