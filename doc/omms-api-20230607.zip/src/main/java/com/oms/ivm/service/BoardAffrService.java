package com.oms.ivm.service;

import com.oms.ivm.dto.BoardAffrReqDTO;


/**
 * <pre>
 * BoardAffrService
 * </pre>
 *
 * @ClassName   : BoardAffrService.java
 * @Description : 재고관리 > 게시판
 * @author 안경수
 * @since 2023.6.1
 * @see
 */

public interface BoardAffrService {

   int insertBoardAffr(BoardAffrReqDTO boardAffrReqDTO);
}
