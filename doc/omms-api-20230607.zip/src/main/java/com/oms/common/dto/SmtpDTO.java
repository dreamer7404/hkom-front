package com.oms.common.dto;

import java.util.ArrayList;
import java.util.List;

import org.apache.ibatis.type.Alias;

import lombok.Data;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @author 안경수
 * @since 2023. 5. 16.
 * @see
 */
@Data
@Alias("smtpDTO")
public class SmtpDTO {
    private String fromAddress;
    private List<String> toAddressList = new ArrayList<>();
    private String subject;
    private String content;
    private boolean isUseHtmlYn; //  HTML인지 여부(true, false)
//    private List<AtchFileDto> attachFileList = new ArrayList<>();
}
