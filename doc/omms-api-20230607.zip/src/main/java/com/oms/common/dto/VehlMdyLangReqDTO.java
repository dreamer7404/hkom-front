package com.oms.common.dto;

import java.util.List;

import org.apache.ibatis.type.Alias;

import lombok.AllArgsConstructor;
import lombok.Data;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @author Windows i¿½i¿½i¿½i¿½i¿½
 * @since 2023. 6. 7.
 * @see
 */
@Alias("vehlMdyLangReqDTO")
@AllArgsConstructor
@Data
public class VehlMdyLangReqDTO {
    private String qltyVehlCd;  // 차종코드
    private String mdlMdyCd;    // 연식
    private String langCd;      // 언어코드


}
