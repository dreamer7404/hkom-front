package com.oms.print.dao;

import java.util.List;

import com.oms.ivm.dto.TotIvmResDTO;
import com.oms.print.dto.PrintStateComDTO;
import com.oms.print.dto.PrintStateReqDTO;
import com.oms.print.dto.PrintStateResDTO;
import com.oms.stm.dto.BoardReqDTO;
import com.oms.stm.dto.BoardResDTO;


/**
 * <pre>
 * Statements
 * </pre>
 * @ClassName : PrintStateDAO.java
 * @Description :
 * @author 김경훈
 * @since 2023. 5. 3.
 * @see
 */
public interface PrintStateDAO {

    /**
     * Statements
     *
     * @param dto
     * @return
     */
    List<PrintStateResDTO> selectPrintStateList(PrintStateReqDTO dto);

    /**
     * Statements
     *
     * @param dto
     * @return
     */
    PrintStateResDTO selectPrntFpInfo(PrintStateComDTO dto);

    /**
     * Statements
     *
     * @param dto
     * @return
     */
    PrintStateResDTO selectPrntApvlInfo(PrintStateComDTO dto);

    /**
     * Statements
     *
     * @param dto
     * @return
     */
    List<PrintStateResDTO> selectReviceInfoList(PrintStateComDTO dto);

    /**
     * Statements
     *
     * @param dto
     * @return
     */
    List<TotIvmResDTO> selectTotalIvm(PrintStateComDTO dto);

    /**
     * Statements
     *
     * @param dto
     * @return
     */
    int outRequestChange(PrintStateReqDTO dto);

    /**
     * Statements
     *
     * @param dto
     * @return
     */
    int updatePrtlImtrSbc3(PrintStateReqDTO dto);

    /**
     * Statements
     *
     * @param dto
     * @return
     */
    int updateSaleUnp(PrintStateReqDTO dto);

    /**
     * Statements
     *
     * @param dto
     * @return
     */
    int updateSewhaIvInfoYmd(PrintStateReqDTO dto);

    /**
     * Statements
     *
     * @param dto
     * @return
     */
    int updateSewhaIvInfoDtlYmd(PrintStateReqDTO dto);

    /**
     * Statements
     *
     * @param dto
     * @return
     */
    int updateSewonDlvgParrYmd(PrintStateReqDTO dto);


}
