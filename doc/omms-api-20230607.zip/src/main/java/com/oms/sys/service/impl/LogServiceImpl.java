package com.oms.sys.service.impl;

import java.util.List;

import org.springframework.stereotype.Service;

import com.oms.sys.dao.LogDAO;
import com.oms.sys.dto.LogUseReqDTO;
import com.oms.sys.dto.LogUseResDTO;
import com.oms.sys.dto.SchedLogDTO;
import com.oms.sys.model.LogUse;
import com.oms.sys.service.LogService;

import lombok.RequiredArgsConstructor;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @author 안경수
 * @since 2023. 5. 19.
 * @see
 */

@RequiredArgsConstructor
@Service("logService")
public class LogServiceImpl implements LogService {

    private final LogDAO logDAO;

    @Override
    public int insertSchedLog(SchedLogDTO schedLogDTO) {
        return logDAO.insertSchedLog(schedLogDTO);
    }

    @Override
    public int insertLogUse(LogUse logUse) {
        return logDAO.insertLogUse(logUse);
    }

    @Override
    public List<LogUseResDTO> selectLogUseList(LogUseReqDTO logUseReqDTO) {
        List<LogUseResDTO> list = logDAO.selectLogUseList(logUseReqDTO);
        return list;
    }

    @Override
    public Integer selectLogUseListTot(LogUseReqDTO logUseReqDTO) {
        return logDAO.selectLogUseListTot(logUseReqDTO);
    }



}
