package com.oms.cmm.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

import com.oms.cmm.global.Consts;
import com.oms.cmm.interceptor.JwtAuthInterceptor;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @author 안경수
 * @since 2023. 2. 6.
 * @see
 */



@Configuration
public class WebMvcConfig implements WebMvcConfigurer {

    @Value("${upload-image-path.url}")
    private String uploadImagePath;

    @Value("${download-file-path.url}")
    private String downloadFilePath;

    @Value("${upload-file-path.url}")
    private String dext5uploaddataPath;

    @Bean
    public JwtAuthInterceptor jwtAuthInterceptor() {
        return new JwtAuthInterceptor();
    }

    @Override
    public void addResourceHandlers(ResourceHandlerRegistry registry) {
        /*
         * 에디터의 파일업로드
         */
        registry.addResourceHandler("/uploadImages/**")
//                .addResourceLocations("file:/DATA/video/"); //리눅스 root에서 시작하는 폴더 경로
//                  .addResourceLocations("file:///D:/temp/"); //윈도우즈
            .addResourceLocations("file:///"+uploadImagePath);

        /*
         * 파일업로더
         */
        registry.addResourceHandler("/downloadFiles/**")
            .addResourceLocations("file:///"+downloadFilePath);


        /*
         * dext5uploaddata
         */
        registry.addResourceHandler("/dext5uploaddata/**")
            .addResourceLocations("file:///"+dext5uploaddataPath);






    }


    /*
     * addInterceptors
     */

    @Override
    public void addInterceptors(InterceptorRegistry registry) {
        registry
//            .addInterceptor(new JwtAuthInterceptor())
            .addInterceptor(jwtAuthInterceptor())
            .addPathPatterns("/**")
            .excludePathPatterns(
                    "/api/login",
                    "/api/initUserPw",
                    "/api/testEmail",
                    "/api/dext5editor",
                    "/api/dext5upload",
                    "/downloadFiles"
                    );

    }


    /*
     * CORS 설정
     */
    @Override
    public void addCorsMappings(CorsRegistry registry) {
        registry.addMapping("/**")
            .allowedOrigins(Consts.ALLOWED_ORIGINS)
            .allowCredentials(true) // receive token
            .allowedMethods("GET", "POST")
            ;
    }




}
