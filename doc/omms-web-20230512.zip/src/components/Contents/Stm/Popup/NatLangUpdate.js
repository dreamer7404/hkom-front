import React, {useState, useMemo} from 'react';
import {Button, Modal, Table} from 'react-bootstrap';
import SearchIcon from '@rsuite/icons/Search';
import PageNextIcon from '@rsuite/icons/PageNext';
import PagePreviousIcon from '@rsuite/icons/PagePrevious';
import { Input, InputGroup, Form } from 'rsuite';
import { AgGridReact } from 'ag-grid-react';

import NatLangCopy from './NatLangCopy';
import NatCodeSearch from './NatCodeSearch';

const NatLangUpdate = ({show, onHide}) => {


    const defaultColDef = useMemo(() => {
        return {
            initialWidth: 90,
            resizable:true,
        };
    }, []);

    const [rowData] = useState([
        {countryCd: "A1",},
        {countryCd: "A2",countryNm:''},
        {countryCd: "A3",countryNm:''},
        {countryCd: "A4",countryNm:''},
        {countryCd: "A5",countryNm:''},
        {countryCd: "A6",countryNm:''},
        {countryCd: "A7",countryNm:''},
        {countryCd: "A8",countryNm:''},
        {countryCd: "A9",countryNm:''},
        {countryCd: "A10",countryNm:''},
        {countryCd: "A11",countryNm:''},
        {countryCd: "A12",countryNm:''},
        {countryCd: "A13",countryNm:''},
        {countryCd: "A14",countryNm:''}
    ]);

    const columnDefs = [
        {
            checkboxSelection: true,
            headerCheckboxSelection: true,
            spanHeaderHeight: true,
            width:45,
            maxWidth:45,
            minWidth:45
        },
        {
            headerName: '차종코드',
            field: 'countryCd',
            spanHeaderHeight: true,
            maxWidth:'100',
            sortable:true,
            filter: 'agTextColumnFilter',
            floatingFilter: true,
            suppressMenu: true,
            filterParams: {
                filterOptions: ['contains'],
            }
        },
        {
            headerName: '언어',
            field: 'lang',
            spanHeaderHeight: true,
        },    
    ]

    const columnDefs2 = [
        {
            checkboxSelection: true,
            headerCheckboxSelection: true,
            spanHeaderHeight: true,
            width:45,
            maxWidth:45,
            minWidth:45
        },
        {
            headerName: '언어코드',
            field: 'langCd',
            spanHeaderHeight: true,
            maxWidth:80,
            sortable:true
        },  
        {
            headerName: '언어명',
            field: 'langNm',
            spanHeaderHeight: true,
        },
        {
            headerName: '지역',
            field: 'region',
            maxWidth:100,
            spanHeaderHeight: true,
        },    
    ]

    const onFirstDataRendered = (params) => {
        params.api.sizeColumnsToFit();
    };

    const CustomInputGroupWidthButton = () => (
        <InputGroup inside >
            <Input style={{fontSize:'12px'}}/>
            <InputGroup.Button style={{height:'24px'}} onClick={() => setNatCodeSearchPop(true)}>
            <SearchIcon />
            </InputGroup.Button>
        </InputGroup>
    );

    const [natLangCopyPop, setNatLangCopyPop] = useState(false);
    const [natCodeSearchPop, setNatCodeSearchPop] = useState(false);

    return (
        <>
            <Form
            
            
            >
                <Modal show={show} onHide={onHide} backdrop="static" keyboard={false} centered size="xl" className="modal-custom">
                    <Modal.Header closeButton>
                        <Modal.Title>국가별 언어 상세/수정</Modal.Title>
                    </Modal.Header>
                        <Modal.Body>
                            <div className="grid-wrap">
                                    <Table className="tbl-hor" bordered>
                                        <colgroup>
                                            <col style={{width:'15%'}}></col>
                                            <col style={{width:'35%'}}></col>
                                            <col style={{width:'15%'}}></col>
                                            <col style={{width:'35%'}}></col>
                                        </colgroup>
                                        <tbody>
                                            <tr>
                                                <th className="essen">국가코드</th>
                                                <td>A01</td>
                                                <th className="">국가명</th>
                                                <td>AFGHANISTAN</td>
                                            </tr>
                                            <tr>
                                                <th className="">지역</th>
                                                <td>일반</td>
                                                <th className="essen">연식</th>
                                                <td>23MY</td>
                                            </tr>
                                            <tr>
                                                <th className="">제외 대리점 코드</th>
                                                <td colSpan="3">
                                                    <Form.Control size="sm" type="text" placeholder=""  />
                                                </td>
                                            </tr>
                                            <tr>
                                                <th>적용 차종 및 언어</th>
                                                <td colspan="3">
                                                     <div className="grid-btn-wrap" style={{marginBottom:'5px'}}>
                                                        <div className="right-align">
                                                            <Button variant="outline-secondary" size="sm" onClick={() => setNatLangCopyPop(true)}>국가언어 복사</Button>{' '}
                                                        </div>
                                                    </div>
                                                    <div className="grid-double">
                                                        <div className="ag-theme-alpine" style={{height:300, width:'60%'}}>
                                                            <AgGridReact
                                                                rowData={rowData}
                                                                columnDefs={columnDefs}
                                                                defaultColDef={defaultColDef}
                                                                rowSelection={'multiple'}
                                                                suppressRowClickSelection= {true} 
                                                                onFirstDataRendered={onFirstDataRendered}
                                                                suppressSizeToFit={true}    
                                                                onGridSizeChanged={onFirstDataRendered}     
                                                                >
                                                            </AgGridReact>
                                                        </div>
                                                        <div className="grid-move-btn">
                                                            <Button className="lang-add-btn" variant="outline-secondary" size="sm"> <PagePreviousIcon/> </Button>{' '}
                                                            <Button className="lang-dlt-btn" variant="outline-secondary" size="sm"> <PageNextIcon/></Button>{' '}
                                                        </div>
                                                        <div className="ag-theme-alpine" style={{height:300, width:'40%'}}>
                                                            <AgGridReact
                                                                rowData={rowData}
                                                                columnDefs={columnDefs2}
                                                                defaultColDef={defaultColDef}
                                                                rowSelection={'multiple'}
                                                                suppressRowClickSelection= {true} 
                                                                onFirstDataRendered={onFirstDataRendered}
                                                                suppressSizeToFit={true}    
                                                                onGridSizeChanged={onFirstDataRendered}     
                                                                >
                                                            </AgGridReact>
                                                        </div>
                                                    </div>
                                                    
                                                </td>
                                            </tr>
                                        </tbody>
                                    </Table>
                                   
                                </div>
                        </Modal.Body>

                        <Modal.Footer>
                            <Button variant="light" size="md" onClick={onHide}>취소</Button>
                            <Button variant="primary" size="md" onClick={onHide}>저장</Button>
                        </Modal.Footer>
                </Modal>
            </Form>

            <NatLangCopy show={natLangCopyPop} onHide={() => setNatLangCopyPop(false)}  />
            <NatCodeSearch show={natCodeSearchPop} onHide={() => setNatCodeSearchPop(false)}  />
        </>
    );

};
export default NatLangUpdate;