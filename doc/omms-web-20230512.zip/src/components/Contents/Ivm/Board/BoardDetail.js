// react
import React, {useState, useMemo} from 'react';
import { AgGridReact } from 'ag-grid-react';

import {Form, Button, Table} from 'react-bootstrap';

const BoardDetail = () => {

    const [rowData] = useState([
            {selectCar: "(AA)AA-CAR", selectYear: "23MY", selectLang: "(EE)영어/유럽" },
            {selectCar: "(AA)AA-CAR", selectYear: "23MY", selectLang: "(EE)영어/유럽" },
            {selectCar: "(AA)AA-CAR", selectYear: "23MY", selectLang: "(EE)영어/유럽" },
            {selectCar: "(AA)AA-CAR", selectYear: "23MY", selectLang: "(EE)영어/유럽" },
            {selectCar: "(AA)AA-CAR", selectYear: "23MY", selectLang: "(EE)영어/유럽" },
    ]);

    const columnDefs = [
        {
          headerName: '차종',
          field: 'selectCar',
        },
        {
          headerName: '연식',
          field: 'selectYear',
          width:100,
          maxWidth:100
        },
        {
          headerName: '언어',
          field: 'selectLang',
        },
    ]

    const [rowData2] = useState([
            {userPart: "현대자동차", userName: "홍길동"},
            {userPart: "현대자동차", userName: "김삼순"},
            {userPart: "현대자동차", userName: "김삼순"},
            {userPart: "현대자동차", userName: "김삼순"},
    ]);

    const columnDefs2 = [
        {
          headerName: '소속',
          field: 'userPart',
        },
        {
          headerName: '이름',
          field: 'userName',
        },
    ]

    const defaultColDef = useMemo(() => {
        return {
            initialWidth: 90,
            sortable: true,
        };
    }, []);


    const onFirstDataRendered = (params) => {
        params.api.sizeColumnsToFit();
    };

    const updateButton = () => {
        window.location.href="./BoardUpdate"
    }

    const listButton = () => {
        window.location.href="./BoardList"
    }

    return (
        <>
            <div className="write-wrap">
                <Table className="tbl-hor" bordered>
                    <colgroup>
                        <col style={{width:'15%'}}></col>
                        <col style={{width:'35%'}}></col>
                        <col style={{width:'15%'}}></col>
                        <col style={{width:'35%'}}></col>
                    </colgroup>
                    <tbody>
                        <tr>
                            <th>분류</th>
                            <td>
                                교체투입
                            </td>
                            <th>등록자</th>
                            <td>홍길동</td>
                        </tr>
                        <tr>
                            <th>적용 차종 및 언어</th>
                            <td>
                                <div className="ag-theme-alpine" style={{height: 130, transition:'all ease .3s'}}>
                                    <AgGridReact
                                        rowData={rowData}
                                        columnDefs={columnDefs}
                                        defaultColDef={defaultColDef}
                                        onFirstDataRendered={onFirstDataRendered}
                                        suppressSizeToFit={true}    
                                        onGridSizeChanged={onFirstDataRendered}    
                                        >
                                    </AgGridReact>
                                </div>
                            </td>
                            <th>수신인</th>
                            <td>
                                <div className="ag-theme-alpine" style={{height: 130, transition:'all ease .3s'}}>
                                    <AgGridReact
                                        rowData={rowData2}
                                        columnDefs={columnDefs2}
                                        defaultColDef={defaultColDef}
                                        onFirstDataRendered={onFirstDataRendered}
                                        suppressSizeToFit={true}    
                                        onGridSizeChanged={onFirstDataRendered}    
                                        >
                                    </AgGridReact>
                                </div>
                            </td>
                        </tr>
                        <tr>
                            <th>교체투입 여부(이전매뉴얼 폐기)</th>
                            <td>Y</td>
                            <th>신규매뉴얼 투입 요청일</th>
                            <td>2023-03-30</td>
                        </tr>
                        <tr>
                            <th>제목</th>
                            <td colspan="3">
                                교체투입 내용 전달드리오니 참고바랍니다.
                            </td>
                        </tr>
                        <tr>
                            <th>내용</th>
                            <td colspan="3">
                                해당 게시물은 교체투입에 대한 내용이므로 참고 부탁드립니다.
                            </td>
                        </tr>
                        <tr>
                            <th>첨부파일</th>
                            <td colspan="3">
                                
                            </td>
                        </tr>
                    </tbody>
                </Table>
                <div className="reply-wrap">
                    <p class="reply-count">댓글 <span>1</span>건</p>
                    <div className="reply-body">
                        <div className="reply-detail">
                                <ul >
                                    <li>
                                        <div className="reply-user">수출선적부 홍길동</div>
                                        <div className="reply-cont">해당 내용 확인하였습니다.</div>
                                        <div className="reply-date">2023-03-25 15:00</div>
                                    </li>
                                </ul>
                         </div>
                        <div className="reply-write">
                            <Form.Control as="textarea" placeholder="내용을 입력해주세요"></Form.Control>
                            <Button className="mt-2" variant="primary" size="sm">댓글 등록</Button>
                        </div>
                    </div>
                </div>
                <div className="btn-wrap">
                    <div className="left-align">
                        <Button variant="light" onClick={listButton}>목록</Button>{' '}
                    </div>
                    <div className="right-align">
                        <Button variant="outline-danger" onClick={listButton}>삭제</Button>{' '}
                        <Button className="" variant="primary" size="md" onClick={updateButton}>수정</Button>
                    </div>
                </div>
            </div>
        </>
    )
};
export default BoardDetail;