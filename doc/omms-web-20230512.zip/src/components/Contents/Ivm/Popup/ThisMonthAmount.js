import React, { useState, useEffect} from 'react';
import {Row, Col, Button, Modal, Table} from 'react-bootstrap';
import { CONSTANTS } from '../../../../utils/constants';
import { formatNumber } from '../../../../utils/commUtils';
// //--------------  서버데이터용 필수 -------------------------------
import { useQuery } from 'react-query';
import { getData } from '../../../../utils/async';
import { API } from '../../../../utils/constants';
// //--------------// 서버데이터용 필수 -------------------------------

const ThisMonthAmount = ({show, onHide, clickedRowData}) => {

    const queryResult = useQuery([API.ivmThisMonTrwis, clickedRowData], () => getData(API.ivmThisMonTrwis, clickedRowData), {
        //화면 열렸을때 무조건 실행 방지를 위한 옵션.
        enabled: false,
    });

    useEffect(() => {
        if(show){
            queryResult.refetch();
        }
    }, [clickedRowData]);

    return (
        <>
            <Modal show={show} onHide={onHide} backdrop="static" keyboard={false} centered size="lg" className="modal-custom">
                <Modal.Header closeButton>
                    <Modal.Title>당월투입(누적)</Modal.Title>
                </Modal.Header>
                <Modal.Body>
                    <div className="grid-btn-wrap">
                        <div className="left-align">
                            <div className="sub-title">
                                <ul>
                                    {/* 
                                    <li>차종 <span>(AA-19)AA-CAR</span></li>
                                    <li>언어 <span>EC(영어,불어/캐나다)</span></li>
                                     */}
                                    <li>차종 <span>({clickedRowData.qltyVehlCd} - {clickedRowData.mdlMdyCd}){clickedRowData.qltyVehlNm}</span></li>
                                    <li>언어 <span>{clickedRowData.langCd}({clickedRowData.langCdNm})</span></li>
                                </ul>
                            </div>
                        </div>
                        <div className="right-align">
                            <Button variant="outline-success" size="sm"><span className="excel-down"></span>{CONSTANTS.excelDownload}</Button>{' '}
                            <Button variant="outline-dark" size="sm"><span className="print"></span>{CONSTANTS.print}</Button>{' '}
                        </div>
                    </div>
                    <Row>
                        <Col xs={6}>
                        <Table className="tbl-ver" bordered>
                            <thead>
                                <tr>
                                    <th>날짜</th>
                                    <th>입고</th>
                                    <th>투입</th>
                                </tr>
                            </thead>
                            <tbody>
                            {queryResult.isFetched && queryResult.data.map((item, index) => (
                                index < 16
                                ?
                                <tr key={index}>
                                    <td>{item.wkYmd}</td>
                                    <td className="item-num">{formatNumber(item.whsnQty)}</td>
                                    <td className="item-num">{formatNumber(item.whotQty)}</td>
                                </tr>
                                :null
                            ))}
                            </tbody>
                        </Table>
                        </Col>
                        <Col xs={6}>
                        <Table className="tbl-ver" bordered>
                            <thead>
                                <tr>
                                    <th>날짜</th>
                                    <th>입고</th>
                                    <th>투입</th>
                                </tr>
                            </thead>
                            <tbody>
                            {queryResult.isFetched && queryResult.data.map((item, index) => (
                                index > 15 
                                ?
                                    item.wkYmd !== 'TOTAL'
                                    ?
                                    <tr key={index}>
                                        <td>{item.wkYmd}</td>
                                        <td className="item-num">{formatNumber(item.whsnQty)}</td>
                                        <td className="item-num">{formatNumber(item.whotQty)}</td>
                                    </tr>
                                    :
                                    <tr key={index}>
                                        <td>합계</td>
                                        <td className="item-num">{formatNumber(item.whsnQty)}</td>
                                        <td className="item-num">{formatNumber(item.whotQty)}</td>
                                    </tr>
                                :null

                            ))}
                            </tbody>
                        </Table>
                        </Col>
                    </Row>
                    </Modal.Body>
                <Modal.Footer>
                    <Button variant="light" size="md" onClick={onHide}>취소</Button>
                </Modal.Footer>
            </Modal>
        </>
    );

};
export default ThisMonthAmount;