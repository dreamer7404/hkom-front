import React, { useState, useEffect} from 'react';
import {Button, Modal, Table} from 'react-bootstrap';
import { CONSTANTS } from '../../../../utils/constants';
import { escapeCharChange, formatNumber} from '../../../../utils/commUtils';
// //--------------  서버데이터용 필수 -------------------------------
import { useQuery } from 'react-query';
import { getData } from '../../../../utils/async';
import { API } from '../../../../utils/constants';
// //--------------// 서버데이터용 필수 -------------------------------

const ProductMonitor = ({show, onHide, checkedRows}) => {

    const queryResult = useQuery([API.ivmPdiPrndMonitorInfo, checkedRows], () => getData(API.ivmPdiPrndMonitorInfo, checkedRows), {
        enabled: false,
    });
    useEffect(() => {
        if(show){
            queryResult.refetch();
        }
    }, [checkedRows]);

    return (
        <>
            <Modal show={show} onHide={onHide} backdrop="static" keyboard={false} centered size="lg" className="modal-custom">
                <Modal.Header closeButton>
                    <Modal.Title>생산라인 모니터링</Modal.Title>
                </Modal.Header>
                <Modal.Body>
                    <div className="grid-btn-wrap">
                        <div className="left-align">
                            <div className="sub-title">
                                <ul>
                                    {/*                                     
                                    <li>차종 <span>(AA-19)AA-CAR</span></li>
                                    <li>언어 <span>EC(영어,불어/캐나다)</span></li> 
                                    */}
                                    <li>차종 <span>({checkedRows.qltyVehlCd} - {checkedRows.mdlMdyCd}){checkedRows.qltyVehlNm}</span></li>
                                    <li>언어 <span>{checkedRows.langCd}({checkedRows.langCdNm})</span></li>
                                </ul>
                            </div>
                        </div>
                        <div className="right-align">
                            <Button variant="outline-success" size="sm"><span className="excel-down"></span>{CONSTANTS.excelDownload}</Button>{' '}
                            <Button variant="outline-dark" size="sm"><span className="print"></span>{CONSTANTS.print}</Button>{' '}
                        </div>
                    </div>
                    <Table className="tbl-ver" bordered>
                        <thead>
                            <tr>
                                <th>구분</th>
                                <th>번호</th>
                                <th>공정명</th>
                                <th>대수</th>
                                <th>From</th>
                                <th>To</th>
                            </tr>
                        </thead>
                        {queryResult.isFetched 
                        ?
                        <tbody>
                            <tr>
                                <td>계획</td>
                                <td>0</td>
                                <td>투입계획(D+2)</td>
                                <td className="item-num">{formatNumber(queryResult.data.th0PowTrwiQty)}</td>
                                <td>{queryResult.data.th0PowStrtYmdhm}</td>
                                <td>{queryResult.data.th0PowFnhYmdhm}</td>
                            </tr>
                            <tr>
                                <td></td>
                                <td>1~5</td>
                                <td></td>
                                <td className="item-num">{formatNumber(Number(queryResult.data.th1PowTrwiQty) + Number(queryResult.data.th2PowTrwiQty) + Number(queryResult.data.th3PowTrwiQty) + Number(queryResult.data.th4PowTrwiQty) + Number(queryResult.data.th5PowTrwiQty))}</td>
                                <td>{queryResult.data.th1PowStrtYmdhm}</td>
                                <td>{queryResult.data.th5PowFnhYmdhm}</td>
                            </tr>
                            <tr>
                                <td>의장</td>
                                <td>6</td>
                                <td>TRIM IN</td>
                                <td className="item-num">{formatNumber(queryResult.data.th6PowTrwiQty)}</td>
                                <td>{escapeCharChange(queryResult.data.th6PowStrtYmdhm)}</td>
                                <td>{escapeCharChange(queryResult.data.th6PowFnhYmdhm)}</td>
                            </tr>
                            <tr>
                                <td>의장</td>
                                <td>7</td>
                                <td>C/FINAL</td>
                                <td className="item-num">{formatNumber(queryResult.data.th7PowTrwiQty)}</td>
                                <td>{escapeCharChange(queryResult.data.th7PowStrtYmdhm)}</td>
                                <td>{escapeCharChange(queryResult.data.th7PowFnhYmdhm)}</td>
                            </tr>
                            <tr>
                                <td>의장</td>
                                <td>8</td>
                                <td>S/OFF</td>
                                <td className="item-num">{formatNumber(queryResult.data.th8PowTrwiQty)}</td>
                                <td>{escapeCharChange(queryResult.data.th8PowStrtYmdhm)}</td>
                                <td>{escapeCharChange(queryResult.data.th8PowFnhYmdhm)}</td>
                            </tr>
                            <tr>
                                <td>PDI</td>
                                <td>9</td>
                                <td>통제소</td>
                                <td className="item-num">{formatNumber(queryResult.data.th9PowTrwiQty)}</td>
                                <td>{escapeCharChange(queryResult.data.th9PowStrtYmdhm)}</td>
                                <td>{escapeCharChange(queryResult.data.th9PowFnhYmdhm)}</td>
                            </tr>
                            <tr>
                                <td>PDI</td>
                                <td>10</td>
                                <td>PDI IN</td>
                                <td className="item-num">{formatNumber(queryResult.data.th10PowTrwiQty)}</td>
                                <td>{escapeCharChange(queryResult.data.th10PowStrtYmdhm)}</td>
                                <td>{escapeCharChange(queryResult.data.th10PowFnhYmdhm)}</td>
                            </tr>
                            <tr>
                                <td>PDI</td>
                                <td>11</td>
                                <td>PDI OUT</td>
                                <td className="item-num">{formatNumber(queryResult.data.th11PowTrwiQty)}</td>
                                <td>{escapeCharChange(queryResult.data.th11PowStrtYmdhm)}</td>
                                <td>{escapeCharChange(queryResult.data.th11PowFnhYmdhm)}</td>
                            </tr>
                            <tr>
                                <td>MP</td>
                                <td>12</td>
                                <td>Motor Pool</td>
                                <td className="item-num">{formatNumber(queryResult.data.th12PowTrwiQty)}</td>
                                <td>{escapeCharChange(queryResult.data.th12PowStrtYmdhm)}</td>
                                <td>{escapeCharChange(queryResult.data.th12PowFnhYmdhm)}</td>
                            </tr>
                                <tr>
                                <td></td>
                                <td>13</td>
                                <td></td>
                                <td className="item-num">{formatNumber(queryResult.data.th13PowTrwiQty)}</td>
                                <td>{escapeCharChange(queryResult.data.th13PowStrtYmdhm)}</td>
                                <td>{escapeCharChange(queryResult.data.th13PowFnhYmdhm)}</td>
                            </tr>
                            <tr>
                                <td></td>
                                <td>14</td>
                                <td></td>
                                <td className="item-num">{formatNumber(queryResult.data.th14PowTrwiQty)}</td>
                                <td>{escapeCharChange(queryResult.data.th14PowStrtYmdhm)}</td>
                                <td>{escapeCharChange(queryResult.data.th14PowFnhYmdhm)}</td>
                            </tr>
                            <tr>
                                <td></td>
                                <td>15</td>
                                <td></td>
                                <td className="item-num">{formatNumber(queryResult.data.th15PowTrwiQty)}</td>
                                <td>{escapeCharChange(queryResult.data.th15PowStrtYmdhm)}</td>
                                <td>{escapeCharChange(queryResult.data.th15PowFnhYmdhm)}</td>
                            </tr>
                            <tr>
                                <td>출하</td>
                                <td>16</td>
                                <td>출고/선적</td>
                                <td className="item-num">{formatNumber(queryResult.data.th16PowTrwiQty)}</td>
                                <td>{escapeCharChange(queryResult.data.th16PowStrtYmdhm)}</td>
                                <td>{escapeCharChange(queryResult.data.th16PowFnhYmdhm)}</td>
                            </tr>
                            <tr>
                                <th colSpan="3">합계</th>
                                <th colSpan="3" className="item-num">{formatNumber(
                                    Number(queryResult.data.th1PowTrwiQty) 
                                    + Number(queryResult.data.th2PowTrwiQty) 
                                    + Number(queryResult.data.th3PowTrwiQty) 
                                    + Number(queryResult.data.th4PowTrwiQty) 
                                    + Number(queryResult.data.th5PowTrwiQty)
                                    + Number(queryResult.data.th6PowTrwiQty)
                                    + Number(queryResult.data.th7PowTrwiQty)
                                    + Number(queryResult.data.th8PowTrwiQty)
                                    + Number(queryResult.data.th9PowTrwiQty)
                                    + Number(queryResult.data.th10PowTrwiQty)
                                    + Number(queryResult.data.th11PowTrwiQty)
                                    + Number(queryResult.data.th12PowTrwiQty)
                                    + Number(queryResult.data.th13PowTrwiQty)
                                    + Number(queryResult.data.th14PowTrwiQty)
                                    + Number(queryResult.data.th15PowTrwiQty)
                                    + Number(queryResult.data.th16PowTrwiQty)
                                )}
                                </th>
                            </tr>
                        </tbody>
                        :
                        <tbody>
                            <tr>
                                <td colSpan="6">데이터가 없습니다.</td>
                            </tr>
                        </tbody>
                        }
                    </Table>
                </Modal.Body>
                <Modal.Footer>
                    <Button variant="light" size="md" onClick={onHide}>취소</Button>
                </Modal.Footer>
            </Modal>
        </>
    );

};
export default ProductMonitor;