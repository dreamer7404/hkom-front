import {create} from 'zustand';
import { persist } from "zustand/middleware";

export const useStoreMem = create(
    set => ({
        gridData: null,
        setGridData: data => set(state => ({...state, gridData: data})), 
    })
);


const useStore = create(
    persist(
        set => ({
            showError: true,
            setShowError:  data => set(state => ({...state, showError: data})),  

            //------------------ user info ------------------------------------------------
            token: 'abc',
            browserId: '',
            grpCd: '100',       // 권한그룹코드 (100: sysadm, 101: HMC, 102: KMC, 103: 외주...)
            coCd: '',         // (자신의)회사코드(01: 현대, 02: 기아, # 09: 공통  => 01/02만사용함) => 어드민(sysadm)는 coCd 변경가능.
            deptCd: '',        // (자신의)부서코드(01: 시스템관리자, 02: 직영(정보팀), 03: PDI, ...) => 어드민(sysadm)는 deptCd 변경가능.
            errCd: null,
            loginUrl: '',
            setGrpCd: data => set(state => ({...state, grpCd: data})),  
            setCoCd: data => set(state => ({...state, coCd: data})), 
            setDeptCd: data => set(state => ({...state, deptCd: data})), 
            setToken: data => set(state => ({...state, token: data})),  
            setErrCd: data => set(state => ({...state, errCd: data})),  
            setLoginUrl: data => set(state => ({...state, loginUrl: data})),  
            resetUser: data => set(state => ({...state, 
                token: data.token, 
                browserId: data.browserId, 
                grpCd: data.grpCd,
                coCd: data.coCd, 
                deptCd: data.userDcd, 
                loginUrl: data.loginUrl
            })),  
            //------------------// user info ------------------------------------------------
            
            // theme: 'hd', // useStoreAuth의 coCd가 01=> hd, 02=> kia, 03=> hd/kia 변동(초기 hd)
            menu: [],
            tab: 'tab1',
            keyword:{
                bDate: '2023-02-03',     // 기준일(새로 로그인시 오늘날짜세팅)
                sDate: '2023-01-01',     // 시작일
                eDate: '2023-02-03',     // 종료일
                sMonth: '2022-03-01',    // 시작월
                eMonth: '2023-02-28',    // 종료월
                dlExpdPdiCd: 'ALL',      // PDI code
                qltyVehlCd: 'ALL',       // 차종 code
                mdlMdyCd:'23',           // 차량 Mdy code

                dlExpdRegnCd: 'ALL',     // 지역코드
                langCd: 'ALL',           // 언어코드
                langCds:[],              // 언어코드 다중선택
                subCd: 'ALL',            // 재고상태
                dlvtState: 'ALL',        // 배송여부
                iWayCd: '',           // 발행구분
            },
            setTheme: data => set(state => ({...state, theme: data})),  // Theme setter

            setMenu: data => set(state => ({...state, menu: data})),  // 메뉴  setter
            setTab: data => set(state => ({...state, tab: data})),  // Tab  setter

            setBDate: data => set(state => ({keyword: {...state.keyword, bDate: data }})),  // 기준일  setter
            setSDate: data => set(state => ({keyword: {...state.keyword, sDate: data }})),  // 시작일  setter
            setEDate: data => set(state => ({keyword: {...state.keyword, eDate: data }})),  // 종료일  setter
            setSMonth: data => set(state => ({keyword: {...state.keyword, sMonth: data }})),  // 시작월  setter
            setEMonth: data => set(state => ({keyword: {...state.keyword, eMonth: data }})),  // 시작월  setter
            setDlExpdPdiCd: data => {set(state => ({keyword: {...state.keyword, dlExpdPdiCd: data }}))},  // PDI코드 setter
            setQltyVehlCd: data => {set(state => ({keyword: {...state.keyword, qltyVehlCd: data }}))},  // 차종코드 setter
            setMdlMdyCd: data => {set(state => ({keyword: {...state.keyword, mdlMdyCd: data }}))},  // 차량Mdy코드 setter
            setDlExpdRegnCd: data => {set(state => ({keyword: {...state.keyword, dlExpdRegnCd: data }}))},  // 지역코드 setter
            setLangCd: data => {set(state => ({keyword: {...state.keyword, langCd: data }}))},  // 언어코드 setter
            setLangCds: data => {set(state => ({keyword: {...state.keyword, langCds: data }}))},  // 언어코드 다중선택 setter
            setSubCd: data => {set(state => ({keyword: {...state.keyword, subCd: data }}))},  // sub코드 setter
            setDlvtState: data => {set(state => ({keyword: {...state.keyword, dlvtState: data }}))},  // 배송여부 setter
            setIWayCd: data => {set(state => ({keyword: {...state.keyword, iWayCd: data }}))},  // 배송여부 setter
            

           
        }),{name: "omms"}
    )
);




export default useStore;



