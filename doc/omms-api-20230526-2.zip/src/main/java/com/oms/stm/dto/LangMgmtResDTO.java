package com.oms.stm.dto;

import java.sql.Timestamp;
import java.util.List;

import org.apache.ibatis.type.Alias;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName : LangMgmtResDTO.java
 * @Description :
 * @author 김경훈
 * @since 2023. 3. 23.
 * @see
 */
@Alias("langMgmtResDTO")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class LangMgmtResDTO {

    private String n1InsYn;
    private String aaCode;                   //A코드
    private String sortSn;                      //순서
    private String qltyVehlNm;              //차종명
    private String qltyVehlCd;              //차종코드
    private String useYn;               //사용여부
    private String langCdNm;            //언어코드명
    private String dlExpdRegnCd;            //지역코드
    private String langCd;                  //언어코드
    private String dataSn;                      //순서
    private String mdlMdyCd;                //연식코드
    private String regnNm;                  //지역명
    private String dlExpdRegnNm;        //지역코드명
    private String framDtm;                     //등록일자
    private String userNm;                  //등록자

    List<LangMgmtResDTO> langMgmtList;
    List<LangMgmtResDTO> langMstList;
    List<LangMgmtResDTO> dlExpdRegnCdList;
    List<LangMgmtResDTO> langCdList;
    List<LangMgmtResDTO> vehlList;
    List<LangMgmtResDTO> vehlLangCdList;
    List<LangMgmtResDTO> totVehlList;
    List<LangMgmtResDTO> natlCdMstList;



}
