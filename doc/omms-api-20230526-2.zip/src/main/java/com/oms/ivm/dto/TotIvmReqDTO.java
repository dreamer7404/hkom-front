package com.oms.ivm.dto;

import org.apache.ibatis.type.Alias;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @author 김정웅
 * @since 2023. 3. 7.
 * @see
 */
@Alias("totIvmReqDTO")
@Data
@AllArgsConstructor
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown =true)
public class TotIvmReqDTO extends ComIvmReqDTO {

    private String menuId;
    private String dlExpdPdiCd;
    private String ivmState;
    private String postback;
    private String mainCd;
    private String subCd;
}
