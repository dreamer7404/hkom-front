package com.oms.ivm.dto;

import org.apache.ibatis.type.Alias;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @author 김정웅
 * @since 2023. 3. 17.
 * @see
 */
@Alias("ivmSewonIvResDTO")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class IvmSewonIvResDTO {

    private String newPrntPbcnNo;
    private String dlExpdMdlMdyCd;
    private String ivStateNm;
    private String trtmYmd;
    private String prntParrYmd;
    private String dlvgParrYmd;
    private String ivQty;
    private String prevDlvgQty;
    private String ivText;
    private String plntQty;

}
