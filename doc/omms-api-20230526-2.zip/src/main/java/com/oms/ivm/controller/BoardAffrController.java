package com.oms.ivm.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import able.cloud.core.web.HController;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
//import io.swagger.v3.oas.annotations.parameters.RequestBody; 잊지 말자.. 스웨거의 RequestBody...
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.oms.cmm.global.Consts;
import com.oms.cmm.utils.Utils;
import com.oms.common.service.MailService;
import com.oms.ivm.dto.ComIvmReqDTO;
import com.oms.ivm.dto.Ivm2WeekPlanReqDTO;
import com.oms.ivm.dto.Ivm2WeekPlanResDTO;
import com.oms.ivm.dto.Ivm3DayPlanReqDTO;
import com.oms.ivm.dto.Ivm3DayPlanResDTO;
import com.oms.ivm.dto.IvmPdiOrYongsanIvResDTO;
import com.oms.ivm.dto.IvmSewonIvResDTO;
import com.oms.ivm.dto.IvmThisMonTrwiResDTO;
import com.oms.ivm.dto.SewonIvModReqDTO;
import com.oms.ivm.dto.SewonIvModResDTO;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;


/**
 * <pre>
 * BoardAffrController
 * </pre>
 *
 * @ClassName   : BoardAffrController.java
 * @Description : 재고관리 > 게시판
 * @author 안경수
 * @since 2023.3.13
 * @see
 */
@Tag(name = "BoardAffrController", description = "")
@RequiredArgsConstructor
@RestController
@RequestMapping("/api")
public class BoardAffrController extends HController {

    /**
     * 클래스 Injection
     */
    private final HttpServletRequest request;
    private final MailService mailService;


    /**
     * 재고관리 > 게시판 등록, 수정, 삭제
     */
    @Operation(summary = "게시판 등록, 수정, 삭제", description = "")
    @Parameter(in = ParameterIn.HEADER, name="_method")
    @PostMapping("/boardAffrMgmt")
    public Integer boardAffrMgmt() throws Exception {

        String method = Utils.getMethod(request);
        String userEeno = Utils.getUserEeno(request);
        String dlExpdCoCd = Utils.getDlExpdCoCd(request);
        int result = 0;

        if(method.equals(Consts.INSERT)) {
        }

        return 1;
    }



}