package com.oms.ivm.dto;

import org.apache.ibatis.type.Alias;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @author 김정웅
 * @since 2023. 3. 15.
 * @see
 */
@Alias("ivm3DayPlanReqDTO")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Ivm3DayPlanReqDTO extends ComIvmReqDTO {
    private String vWrkYmd;
    private String vFramYmd;
    private String vLocalChar;

    private int vTddPrdnPlanQty;
    private int vTddPrdnQty3;
    private int vTddPrdnQty;

    private String dlExpdPacScnCd;
    private String dlExpdPdiCd;
}
