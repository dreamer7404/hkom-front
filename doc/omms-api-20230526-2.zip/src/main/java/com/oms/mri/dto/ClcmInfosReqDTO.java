package com.oms.mri.dto;

import org.apache.ibatis.type.Alias;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * <pre>
 * PrintOrderInfosResDTO
 * </pre>
 *
 * @author 김정웅
 * @since 2023. 5. 11.
 * @see
 */
@Alias("clcmInfosReqDTO")
@Data
@AllArgsConstructor
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown =true)
public class ClcmInfosReqDTO extends PrintOrderComDTO{

    private String dlExpdAltrNo;    //등록번호
    private String crgrEeno;        //등록자
    private String altrTitl;        //제목
    private String altrSbc;         //내용
    private String dlExpdPacScnCd;  //승상구분코드


}
