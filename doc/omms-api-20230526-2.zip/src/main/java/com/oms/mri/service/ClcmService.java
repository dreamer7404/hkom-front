package com.oms.mri.service;

import java.util.List;

import com.oms.mri.dto.ClcmInfoPopReqDTO;
import com.oms.mri.dto.ClcmInfosReqDTO;
import com.oms.mri.dto.ClcmInfosResDTO;

/**
 * <pre>
 * ClcmService
 * </pre>
 * @ClassName : ClcmService.java
 * @Description : 제작준비 > 법규및변경관리 서비스
 * @author 김정웅
 * @since 2023. 5. 22.
 * @see
 */

public interface ClcmService {
    //법규 및 변경관리 조회
    List<ClcmInfosResDTO> selectClcmInfoList(ClcmInfosReqDTO reqDto) throws Exception;

    //법규 및 변경관리 등록
    Integer insertClcmInfoPop(ClcmInfoPopReqDTO reqDto) throws Exception;
}
