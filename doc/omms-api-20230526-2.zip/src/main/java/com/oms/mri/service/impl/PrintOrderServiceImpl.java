package com.oms.mri.service.impl;

import java.util.ArrayList;
import java.util.List;

import able.cloud.core.service.HService;

import org.springframework.stereotype.Service;

import com.oms.mri.dao.PrintOrderDAO;
import com.oms.mri.dto.PrintOrderComDTO;
import com.oms.mri.dto.PrintOrderInfosResDTO;
import com.oms.mri.service.PrintOrderService;

import lombok.RequiredArgsConstructor;


/**
 * <pre>
 * PrintOrderServiceImpl
 * </pre>
 * @ClassName : PrintOrderServiceImpl.java
 * @Description : 제작준비 > O/M발주 서비스
 * @author 김정웅
 * @since 2023. 5. 11.
 * @see
 */
@RequiredArgsConstructor
@Service("PrintOrderService")
public class PrintOrderServiceImpl extends HService implements PrintOrderService {

    private final PrintOrderDAO printOrderDao;

    @Override
    public List<PrintOrderInfosResDTO> selectPrintOrderList(PrintOrderComDTO reqDto) {
        List<PrintOrderInfosResDTO> result = new ArrayList<PrintOrderInfosResDTO>();
        result = printOrderDao.selectPrintOrderList(reqDto);
        return result;
    }


}





