package com.oms.common.model;

import org.apache.ibatis.type.Alias;

import lombok.Data;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @author 안경수
 * @since 2023. 5. 18.
 * @see
 */

@Data
@Alias("yongsanStock")
public class YongsanIv {
    private String aplYmd;          // 적용(기준)일자

    private String company;         // 회사코드
    private String vehCd;           // 차종코드

    private String mtrlCd;          // 품번 **

    private Integer vehlStock;       // 차량재고
    private Integer stockOnMove;     // 이동중재고
    private Integer stockOneAllItem; // 원올단품
    private Integer stockOneAllKit;  // 원올KIT
    private Integer stockOnLocal;    // 지역재고
    private Integer stockSum;        // 재고합계 ***

    private Integer deliverVehlCnt;  // 출고대수
    private Integer responseDays;    // 대응일수
    private Integer orderAmount;     // 발주
    private Integer restAmount;      // 입고잔량
}
