package com.oms.common.service.impl;

import javax.mail.internet.MimeMessage;

import org.apache.commons.validator.routines.EmailValidator;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
//import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

import com.oms.common.dao.MailDAO;
import com.oms.common.dto.MailDTO;
import com.oms.common.service.MailService;

import lombok.RequiredArgsConstructor;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @author 안경수
 * @since 2023. 5. 16.
 * @see
 */

@RequiredArgsConstructor
@Service
public class MailServiceImpl implements MailService {

    private final JavaMailSender mailSender;
    private final MailDAO mailDao;


    @Value("${spring.mail.from}")
    private String from;

    @Override
    public int send(MailDTO mailDTO)  {
        int sendResult = 0;
        try {

            if(mailDTO.getAdreEml() == null || !EmailValidator.getInstance().isValid(mailDTO.getAdreEml())) {
                   return sendResult;
            }

            //  메일전송
            MimeMessage mimeMessage = mailSender.createMimeMessage();
            MimeMessageHelper mimeMessageHelper = new MimeMessageHelper(mimeMessage, false, "UTF-8");
            mimeMessageHelper.setFrom(from); // 보낸이 주소
//          mimeMessageHelper.setTo(mailDTO.getAdreEml()); // 반듣이 주소
            mimeMessageHelper.setTo("9426036@ict-companion.com"); // 받는이 주소
            mimeMessageHelper.setSubject(mailDTO.getEmlTitl()); // 제목
            mimeMessageHelper.setText(mailDTO.getEmlSbc(), true); // 내용
            mailSender.send(mimeMessage);
            sendResult = 1;

        } catch (Exception e) {
            sendResult = -1;

        }finally {
            // 로그저장 -  TB_LOG_EML 저장
            mailDTO.setEmlScdCd(sendResult == 1 ? "발송" : "실패"); // 발신상태
            mailDao.insertLogEml(mailDTO);
        }

        return sendResult;

    }

    /*
     * TB_LOG_EML 저장
     */
    @Override
    public int insertLogEml(MailDTO mailDTO) {
        return mailDao.insertLogEml(mailDTO);
    }



}
