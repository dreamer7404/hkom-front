package com.oms.common.service.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import able.cloud.core.service.HService;

import org.springframework.stereotype.Service;

import com.oms.cmm.utils.Utils;
import com.oms.common.dao.ComboDAO;
import com.oms.common.dto.CodeComboResDTO;
import com.oms.common.dto.ComboReqDTO;
import com.oms.common.dto.GrpComboResDTO;
import com.oms.common.dto.LangComboResDTO;
import com.oms.common.dto.PdiComboResDTO;
import com.oms.common.dto.RegionComboResDTO;
import com.oms.common.dto.SubCdComboResDTO;
import com.oms.common.dto.VehlComboResDTO;
import com.oms.common.service.ComboService;

import lombok.RequiredArgsConstructor;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @author 안경수
 * @since 2023. 3. 22.
 * @see
 */


@RequiredArgsConstructor
@Service("comboService")
public class ComboServiceImpl  extends HService implements ComboService {

    private final ComboDAO comboDAO;

    @Override
    public List<PdiComboResDTO> selectPdiComboList(ComboReqDTO comboReqDTO) throws Exception {
        return comboDAO.selectPdiComboList(comboReqDTO);
    }

    @Override
    public List<VehlComboResDTO> selectVehlComboList(ComboReqDTO comboReqDTO) throws Exception {
        return comboDAO.selectVehlComboList(comboReqDTO);
    }

    @Override
    public List<String> selectMdyComboList(ComboReqDTO comboReqDTO) throws Exception {
        return comboDAO.selectMdyComboList(comboReqDTO);
    }

    @Override
    public List<RegionComboResDTO> selectRegionComboList(ComboReqDTO comboReqDTO) throws Exception {
        return comboDAO.selectRegionComboList(comboReqDTO);
    }

    @Override
    public List<LangComboResDTO> selectLangComboList(ComboReqDTO comboReqDTO) throws Exception {
        return comboDAO.selectLangComboList(comboReqDTO);
    }

    /*
     * @see com.oms.common.service.ComboService#selectSubCdComboList(java.lang.String)
     */
    @Override
    public List<SubCdComboResDTO> selectSubCdComboList(String mainCd) throws Exception {
       return comboDAO.selectSubCdComboList(mainCd);
    }

    /*
     * @see com.oms.common.service.ComboService#selectCoComboList()
     */
    @Override
    public List<CodeComboResDTO> selectCodeComboList(String dlExpdGCd) throws Exception {
        return comboDAO.selectCodeComboList(dlExpdGCd);
    }



    /*
     * @see com.oms.common.service.ComboService#selectGrpComboList()
     */
    @Override
    public List<GrpComboResDTO> selectGrpComboList() throws Exception {
        return comboDAO.selectGrpComboList();
    }

    @Override
    public List<HashMap<String, Object>> selectLangByVehlComboList(String userEeno, String dlExpdCoCd) throws Exception {

        List<HashMap<String, Object>> resultFinals = new ArrayList<HashMap<String, Object>>();

        List<HashMap<String, Object>> result = comboDAO.selectLangByVehlComboList(userEeno, dlExpdCoCd);

        List<HashMap<String, Object>> keys = new ArrayList<HashMap<String, Object>>();
        for(HashMap<String, Object> key : result) {
            HashMap<String, Object> qltyVehlCd = new HashMap<String, Object>();
            qltyVehlCd.put("qltyVehlCd", key.get("qltyVehlCd"));
            qltyVehlCd.put("qltyVehlNm", key.get("qltyVehlNm"));
            keys.add(qltyVehlCd);
        }
        Set<HashMap<String, Object>> set = new HashSet<HashMap<String, Object>>(keys);
        List<HashMap<String, Object>> qltyVehlCds = new ArrayList<HashMap<String, Object>>(set);


        for(HashMap<String, Object> keyMap: qltyVehlCds) {
            HashMap<String, Object> qltyVehlCdTmp = new HashMap<String, Object>();
            qltyVehlCdTmp.put("label", keyMap.get("qltyVehlNm"));
            qltyVehlCdTmp.put("value", keyMap.get("qltyVehlCd"));

            List<HashMap<String, Object>> langCdListTmp = new ArrayList<HashMap<String, Object>>();

            for(HashMap<String, Object> langCd: result) {
                HashMap<String, Object> langCdTmp = new HashMap<String, Object>();
                if(keyMap.get("qltyVehlCd").equals(langCd.get("qltyVehlCd")) && langCd.get("langCdNm") != null) {
                    langCdTmp.put("label", langCd.get("langCdNm"));
                    String vehlLangCd = langCd.get("qltyVehlCd") + "___" + langCd.get("langCd");
                    langCdTmp.put("value", vehlLangCd);
                    langCdListTmp.add(langCdTmp);
                }
            }

            if(langCdListTmp.size() > 0) {
                qltyVehlCdTmp.put("children", langCdListTmp);
            }

            resultFinals.add(qltyVehlCdTmp);
        }

        return resultFinals;
    }



}
