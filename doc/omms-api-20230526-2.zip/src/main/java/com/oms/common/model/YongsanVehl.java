package com.oms.common.model;

import org.apache.ibatis.type.Alias;

import lombok.Data;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @author 안경수
 * @since 2023. 5. 18.
 * @see
 */

@Data
@Alias("yongsanVehl")
public class YongsanVehl {
    private String company; // 회사코드
    private String vehCd;   // 차종코드
    private String vehlNM;  // 차종명
}
