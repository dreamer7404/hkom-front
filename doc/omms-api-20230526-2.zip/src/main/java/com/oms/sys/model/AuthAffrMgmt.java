package com.oms.sys.model;

import java.sql.Timestamp;

import org.apache.ibatis.type.Alias;

import lombok.Data;

/**
 * <pre>
 * 그룹별 매뉴권한
 * </pre>
 *
 * @author 안경수
 * @since 2023. 3. 9.
 * @see
 */
@Alias("authAffrMgmt")
@Data
public class AuthAffrMgmt {

   private String grpCd;
   private String menuId;
   private String menuAuthCd;
   private String useYn;
   private String pprrEeno;
   private String framDtm;
   private String updrEeno;
   private String mdfyDtm;

   private Boolean selected;
   private String pgmId;

}
