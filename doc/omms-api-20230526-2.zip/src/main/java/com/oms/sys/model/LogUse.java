package com.oms.sys.model;

import org.apache.ibatis.type.Alias;

import lombok.AllArgsConstructor;
import lombok.Data;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @author 안경수
 * @since 2023. 5. 24.
 * @see
 */
@Data
@Alias("logUse")
@AllArgsConstructor
public class LogUse {
    private String useEeno;
    private String apiUrl;
    private String cmd; // select, update insert delete
    private String classNm; // class Name
    private String methodNm; // method name
    private Integer processTime; // processing milliseconds
}
