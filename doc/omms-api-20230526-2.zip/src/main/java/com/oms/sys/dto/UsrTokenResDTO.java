package com.oms.sys.dto;

import java.sql.Timestamp;

import org.apache.ibatis.type.Alias;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @author 안경수
 * @since 2023. 4. 20.
 * @see
 */


@Alias("usrTokenResDTO")
@Data
@NoArgsConstructor
public class UsrTokenResDTO {
    private String userEeno;
    private String ip;
    private Timestamp accessTime;
    private String browserId;
    private String refreshToken;
    private Long refreshTokenValidTime;
    private Timestamp refreshTokenDtm;

    private Long accessTimeDiff;

    private String blnsCoCd;
    private String userDcd;
    private String grpCd;
}
