CREATE OR REPLACE
FUNCTION FU_GET_MIN_YMDHM(P_PAC_SCN_CD          VARCHAR2,
  		   						 P_PDI_CD	           VARCHAR2,
								 P_LANG_CD			   VARCHAR2,
								 P_TH9_POW_STRT_YMDHM  VARCHAR2,
								 P_TH10_POW_STRT_YMDHM VARCHAR2,
								 P_TH11_POW_STRT_YMDHM VARCHAR2,
								 P_TH12_POW_STRT_YMDHM VARCHAR2,
								 P_TH13_POW_STRT_YMDHM VARCHAR2,
								 P_TH14_POW_STRT_YMDHM VARCHAR2,
								 P_TH15_POW_STRT_YMDHM VARCHAR2,
								 P_TH16_POW_STRT_YMDHM VARCHAR2) RETURN VARCHAR2
	   IS
	   	 
		 V_POW_STRT_YMDHM VARCHAR2(16);
		 
	   BEGIN
	   		
			V_POW_STRT_YMDHM := '9999/12/31 23:59';
			
			IF P_TH9_POW_STRT_YMDHM IS NOT NULL THEN
				  	 
			    V_POW_STRT_YMDHM := P_TH9_POW_STRT_YMDHM;
					 
			END IF;
			   
			IF P_LANG_CD = 'KO' THEN
			   
			   IF P_TH10_POW_STRT_YMDHM IS NOT NULL THEN
			   
			      IF V_POW_STRT_YMDHM > P_TH10_POW_STRT_YMDHM THEN
				  	 
			          V_POW_STRT_YMDHM := P_TH10_POW_STRT_YMDHM;
				  
				  END IF;
					 
			   END IF;
				  
			   IF P_TH11_POW_STRT_YMDHM IS NOT NULL THEN
			   
				  IF V_POW_STRT_YMDHM > P_TH11_POW_STRT_YMDHM THEN
				  	 
				      V_POW_STRT_YMDHM := P_TH11_POW_STRT_YMDHM;
				  
				  END IF;
					 
			   END IF;
			   
			   IF P_TH12_POW_STRT_YMDHM IS NOT NULL THEN
			   
				  IF V_POW_STRT_YMDHM > P_TH12_POW_STRT_YMDHM THEN
				  	 
			          V_POW_STRT_YMDHM := P_TH12_POW_STRT_YMDHM;
				  
				  END IF;
					 
			   END IF;
				  
			   IF P_TH13_POW_STRT_YMDHM IS NOT NULL THEN
			   
				  IF V_POW_STRT_YMDHM > P_TH13_POW_STRT_YMDHM THEN
				  	 
				      V_POW_STRT_YMDHM := P_TH13_POW_STRT_YMDHM;
				   
				  END IF;
					 
			   END IF;
			   
			   IF P_TH14_POW_STRT_YMDHM IS NOT NULL THEN
			   
				  IF V_POW_STRT_YMDHM > P_TH14_POW_STRT_YMDHM THEN
				  	 
				      V_POW_STRT_YMDHM := P_TH14_POW_STRT_YMDHM;
				   
				  END IF;
					 
			   END IF;
			   
			   IF P_TH15_POW_STRT_YMDHM IS NOT NULL THEN
			   
				  IF V_POW_STRT_YMDHM > P_TH15_POW_STRT_YMDHM THEN
				  	 
				      V_POW_STRT_YMDHM := P_TH15_POW_STRT_YMDHM;
				   
				  END IF;
					 
			   END IF;
			   
			    IF P_TH16_POW_STRT_YMDHM IS NOT NULL THEN
				
				   IF V_POW_STRT_YMDHM > P_TH16_POW_STRT_YMDHM THEN
				  	 
				       V_POW_STRT_YMDHM := P_TH16_POW_STRT_YMDHM;
				   
				   END IF;
				   	 
			   END IF;
			   	  
			ELSE
				
				IF P_PAC_SCN_CD = '01' THEN
			   
			   	   IF P_PDI_CD = '04' THEN
			   	  
				   	  IF P_TH10_POW_STRT_YMDHM IS NOT NULL THEN
					  
			          	 IF V_POW_STRT_YMDHM > P_TH10_POW_STRT_YMDHM THEN
				  	 
			                 V_POW_STRT_YMDHM := P_TH10_POW_STRT_YMDHM;
						  
						 END IF;
					 
			          END IF;
				  
			          IF P_TH11_POW_STRT_YMDHM IS NOT NULL THEN
			             
				         IF V_POW_STRT_YMDHM > P_TH11_POW_STRT_YMDHM THEN
				  	 
				             V_POW_STRT_YMDHM := P_TH11_POW_STRT_YMDHM;
						 
						 END IF;
					 
			          END IF;
				  
			       ELSE
			   	  
				      IF P_TH10_POW_STRT_YMDHM IS NOT NULL THEN
					  
			             IF V_POW_STRT_YMDHM > P_TH10_POW_STRT_YMDHM THEN
				  	 
			                 V_POW_STRT_YMDHM := P_TH10_POW_STRT_YMDHM;
							 
						 END IF;
					 
			          END IF;
				  
			       END IF;
			   
			   ELSE
			       
				   IF P_TH10_POW_STRT_YMDHM IS NOT NULL THEN
					  
			          IF V_POW_STRT_YMDHM > P_TH10_POW_STRT_YMDHM THEN
				  	 
			              V_POW_STRT_YMDHM := P_TH10_POW_STRT_YMDHM;
						  
					  END IF;
					 
			       END IF;
				  
			       IF P_TH11_POW_STRT_YMDHM IS NOT NULL THEN
			             
				      IF V_POW_STRT_YMDHM > P_TH11_POW_STRT_YMDHM THEN
				  	 
				          V_POW_STRT_YMDHM := P_TH11_POW_STRT_YMDHM;
						 
					  END IF;
					 
			       END IF;
					  
			   END IF;
			
			END IF;
			
			IF V_POW_STRT_YMDHM = '9999/12/31 23:59' THEN
			   
			   V_POW_STRT_YMDHM := '';
			   
			END IF;
			
			RETURN V_POW_STRT_YMDHM;
			
	   END FU_GET_MIN_YMDHM;