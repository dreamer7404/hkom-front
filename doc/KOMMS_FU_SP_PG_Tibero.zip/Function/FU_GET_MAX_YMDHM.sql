CREATE OR REPLACE

--9공정 ~ 투입전 공정 사이의 최대 시각 얻어오기 		
	   FUNCTION FU_GET_MAX_YMDHM(P_PAC_SCN_CD          VARCHAR2,
  		   					     P_PDI_CD	           VARCHAR2,
							     P_LANG_CD			   VARCHAR2,
							     P_TH9_POW_FNH_YMDHM   VARCHAR2,
								 P_TH10_POW_FNH_YMDHM  VARCHAR2,
								 P_TH11_POW_FNH_YMDHM  VARCHAR2,
								 P_TH12_POW_FNH_YMDHM  VARCHAR2,
								 P_TH13_POW_FNH_YMDHM  VARCHAR2,
								 P_TH14_POW_FNH_YMDHM  VARCHAR2,
								 P_TH15_POW_FNH_YMDHM  VARCHAR2,
								 P_TH16_POW_FNH_YMDHM  VARCHAR2) RETURN VARCHAR2
	   IS
	   	 
		 V_POW_FNH_YMDHM VARCHAR2(16);
		 
	   BEGIN
	   		
			V_POW_FNH_YMDHM := '0000/00/00 00:00';
			
			IF P_TH9_POW_FNH_YMDHM IS NOT NULL THEN
				  	 
			    V_POW_FNH_YMDHM := P_TH9_POW_FNH_YMDHM;
					 
			END IF;
			   
			IF P_LANG_CD = 'KO' THEN
			   
			   IF P_TH10_POW_FNH_YMDHM IS NOT NULL THEN
			   
			      IF V_POW_FNH_YMDHM < P_TH10_POW_FNH_YMDHM THEN
				  	 
			          V_POW_FNH_YMDHM := P_TH10_POW_FNH_YMDHM;
				  
				  END IF;
					 
			   END IF;
				  
			   IF P_TH11_POW_FNH_YMDHM IS NOT NULL THEN
			   
				  IF V_POW_FNH_YMDHM < P_TH11_POW_FNH_YMDHM THEN
				  	 
				      V_POW_FNH_YMDHM := P_TH11_POW_FNH_YMDHM;
				  
				  END IF;
					 
			   END IF;
			   
			   IF P_TH12_POW_FNH_YMDHM IS NOT NULL THEN
			   
				  IF V_POW_FNH_YMDHM < P_TH12_POW_FNH_YMDHM THEN
				  	 
			          V_POW_FNH_YMDHM := P_TH12_POW_FNH_YMDHM;
				  
				  END IF;
					 
			   END IF;
				  
			   IF P_TH13_POW_FNH_YMDHM IS NOT NULL THEN
			   
				  IF V_POW_FNH_YMDHM < P_TH13_POW_FNH_YMDHM THEN
				  	 
				      V_POW_FNH_YMDHM := P_TH13_POW_FNH_YMDHM;
				   
				  END IF;
					 
			   END IF;
			   
			   IF P_TH14_POW_FNH_YMDHM IS NOT NULL THEN
			   
				  IF V_POW_FNH_YMDHM < P_TH14_POW_FNH_YMDHM THEN
				  	 
				      V_POW_FNH_YMDHM := P_TH14_POW_FNH_YMDHM;
				   
				  END IF;
					 
			   END IF;
			   
			   IF P_TH15_POW_FNH_YMDHM IS NOT NULL THEN
			   
				  IF V_POW_FNH_YMDHM < P_TH15_POW_FNH_YMDHM THEN
				  	 
				      V_POW_FNH_YMDHM := P_TH15_POW_FNH_YMDHM;
				   
				  END IF;
					 
			   END IF;
			   
			    IF P_TH16_POW_FNH_YMDHM IS NOT NULL THEN
				
				   IF V_POW_FNH_YMDHM < P_TH16_POW_FNH_YMDHM THEN
				  	 
				       V_POW_FNH_YMDHM := P_TH16_POW_FNH_YMDHM;
				   
				   END IF;
				   	 
			   END IF;
			   	  
			ELSE
				
				IF P_PAC_SCN_CD = '01' THEN
			   
			   	   IF P_PDI_CD = '04' THEN
			   	  
				   	  IF P_TH10_POW_FNH_YMDHM IS NOT NULL THEN
					  
			          	 IF V_POW_FNH_YMDHM < P_TH10_POW_FNH_YMDHM THEN
				  	 
			                 V_POW_FNH_YMDHM := P_TH10_POW_FNH_YMDHM;
						  
						 END IF;
					 
			          END IF;
				  
			          IF P_TH11_POW_FNH_YMDHM IS NOT NULL THEN
			             
				         IF V_POW_FNH_YMDHM < P_TH11_POW_FNH_YMDHM THEN
				  	 
				             V_POW_FNH_YMDHM := P_TH11_POW_FNH_YMDHM;
						 
						 END IF;
					 
			          END IF;
				  
			       ELSE
			   	  
				      IF P_TH10_POW_FNH_YMDHM IS NOT NULL THEN
					  
			             IF V_POW_FNH_YMDHM < P_TH10_POW_FNH_YMDHM THEN
				  	 
			                 V_POW_FNH_YMDHM := P_TH10_POW_FNH_YMDHM;
							 
						 END IF;
					 
			          END IF;
				  
			       END IF;
			   
			   ELSE
			       
				   IF P_TH10_POW_FNH_YMDHM IS NOT NULL THEN
					  
			          IF V_POW_FNH_YMDHM < P_TH10_POW_FNH_YMDHM THEN
				  	 
			              V_POW_FNH_YMDHM := P_TH10_POW_FNH_YMDHM;
						  
					  END IF;
					 
			       END IF;
				  
			       IF P_TH11_POW_FNH_YMDHM IS NOT NULL THEN
			             
				      IF V_POW_FNH_YMDHM < P_TH11_POW_FNH_YMDHM THEN
				  	 
				          V_POW_FNH_YMDHM := P_TH11_POW_FNH_YMDHM;
						 
					  END IF;
					 
			       END IF;
					  
			   END IF;
			
			END IF;
			
			IF V_POW_FNH_YMDHM = '0000/00/00 00:00' THEN
			   
			   V_POW_FNH_YMDHM := '';
			   
			END IF;
			
			RETURN V_POW_FNH_YMDHM;
			
	   END FU_GET_MAX_YMDHM;