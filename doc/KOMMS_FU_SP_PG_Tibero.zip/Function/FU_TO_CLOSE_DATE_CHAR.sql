CREATE OR REPLACE 	  --마감일자에 마감시간을 더해서 한글 형태로 변경하여 리턴 
  	  FUNCTION FU_TO_CLOSE_DATE_CHAR(P_CURR_YMD VARCHAR2, 
  		   						     P_EXPD_CO_CD VARCHAR2) RETURN VARCHAR2
      IS
   	 
	  	V_LOCAL_CHAR VARCHAR2(30);
	    
		V_LOCAL_DATE DATE;
		
   	  BEGIN
   	  	   
		   V_LOCAL_DATE := TO_DATE(P_CURR_YMD || '0530', 'YYYYMMDDHH24MI');
			  
		   
		   V_LOCAL_CHAR := TO_CHAR(V_LOCAL_DATE, 'MM')   || '월' || 
						   TO_CHAR(V_LOCAL_DATE, 'DD')   || '일' || '(' ||
						   TO_CHAR(V_LOCAL_DATE, 'HH24') || '시' ||
					       TO_CHAR(V_LOCAL_DATE, 'MI')   || '분' || ')'; 
		
		   RETURN V_LOCAL_CHAR;
	  
	  END FU_TO_CLOSE_DATE_CHAR;