CREATE OR REPLACE 
	--세화재고 조회(승상구분, PDI, 차종, 연식, 지역, 언어) 						  
    PROCEDURE SP_GET_SEWHA_IV_INFO2(P_USER_EENO    VARCHAR2,
								    P_CURR_YMD	   VARCHAR2,
								    P_PAC_SCN_CD   VARCHAR2,
 								    P_PDI_CD	   VARCHAR2,
								    P_VEHL_CD	   VARCHAR2,
								    P_MDL_MDY	   VARCHAR2,
								    P_REGN_CD	   VARCHAR2,
								    P_LANG_CD	   VARCHAR2,
								    P_DLVY_STATE   VARCHAR2,
								    P_IV_STATE     VARCHAR2,
                                    RS 		       OUT SYS_REFCURSOR)
	   IS
	   	  
		  V_FROM_MDL_MDY VARCHAR2(2);
		  V_TO_MDL_MDY   VARCHAR2(2);


	   BEGIN
	   	  
		  PG_COMMON.SP_GET_VALID_MDL_MDY4(P_CURR_YMD, '', V_FROM_MDL_MDY, V_TO_MDL_MDY);
		  
		  
		  IF P_DLVY_STATE = 'ALL' THEN
		  	 
			 OPEN RS FOR
			 	  WITH T AS (SELECT A.CL_SCN_CD,
			          	 		    C.DATA_SN,
			  					    C.QLTY_VEHL_CD,
                                    C.MDL_MDY_CD,
                                    C.LANG_CD,
                                    --'(' || C.QLTY_VEHL_CD || ')' || B.QLTY_VEHL_NM || '-' || C.MDL_MDY_CD || 'MY' AS QLTY_VEHL_NM,
									C.QLTY_VEHL_CD || '-' || C.MDL_MDY_CD AS QLTY_VEHL_NM,
                                    --C.LANG_CD_NM,
									'(' || C.LANG_CD || ')' || C.LANG_CD_NM AS LANG_CD_NM,
                                    C.DL_EXPD_REGN_CD,
									C.SORT_SN AS LANG_SORT_SN
                             FROM (SELECT QLTY_VEHL_CD,
                                          MAX(CL_SCN_CD) AS CL_SCN_CD
                                   FROM TB_AUTH_VEHL
                                   WHERE USER_EENO = PG_COMMON.FU_RPAD(P_USER_EENO, 7)
                                   AND QLTY_VEHL_CD = DECODE(P_VEHL_CD, 'ALL', QLTY_VEHL_CD, P_VEHL_CD)
                                   GROUP BY QLTY_VEHL_CD
                                  ) A,
                                  TB_VEHL_MGMT B,
                                  TB_LANG_MGMT C
                             WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
                             AND A.QLTY_VEHL_CD = C.QLTY_VEHL_CD
                             AND B.MDL_MDY_CD = C.MDL_MDY_CD
                             AND B.MDL_MDY_CD BETWEEN V_FROM_MDL_MDY AND V_TO_MDL_MDY
                             AND B.MDL_MDY_CD = DECODE(P_MDL_MDY , '', B.MDL_MDY_CD, P_MDL_MDY)
						     AND B.DL_EXPD_PAC_SCN_CD = DECODE(P_PAC_SCN_CD, 'ALL', B.DL_EXPD_PAC_SCN_CD, P_PAC_SCN_CD)
                             AND B.DL_EXPD_PDI_CD = DECODE(P_PDI_CD, 'ALL', B.DL_EXPD_PDI_CD, P_PDI_CD)
						     AND C.DL_EXPD_REGN_CD = DECODE(P_REGN_CD, 'ALL', C.DL_EXPD_REGN_CD, P_REGN_CD)
                             AND C.LANG_CD = DECODE(P_LANG_CD, 'ALL', C.LANG_CD, P_LANG_CD)
							 AND B.USE_YN = 'Y'
							 AND C.USE_YN = 'Y'
                            )
                                    SELECT '1' CL_SCN_CD,
			   		   '1' DATA_SN,
					     '1' QLTY_VEHL_CD,
					     '1' MDL_MDY_CD,
					     '1' LANG_CD,
					     '1' DL_EXPD_REGN_CD,
					     '1' QLTY_VEHL_NM,
					     '1' LANG_CD_NM,
					     '1' DL_EXPD_REGN_NM,
					     '1' WEK2_PLAN_QTY,
					     '1' DAY3_PLAN_QTY,
					     '1' CURR_MTH_TRWI_QTY,
					     '1' PREV_1DAY_TRWI_QTY,
					     '1' SEWHA_IV_QTY,
					     '1' SEWHA_PRNT_YN, --세화 인쇄중 데이터 존재여부 확인 
					     '1' SEWHA_DLVY_QTY,
					     '1' PDI_DEEI1_QTY,
						   '1' EXPD_WHSN_ST_NM,
						   '1' PDI_IV_QTY,
					     '1' DSID3_QTY,
						   '1' DAY3_AFTR_IV_QTY,
						   '1' WEK2_AFTR_IV_QTY,
						   '1' PRNT_STATE,
						   '1' PRNT_STATE_NM,
						   '1' PLNT_DAY3_QTY_TEXT,
					     '1' PLNT_WEK2_QTY_TEXT,
					     '1' PLNT_YN
					     FROM DUAL
					     UNION ALL
        SELECT '2' CL_SCN_CD,
			   		   '2' DATA_SN,
					     '2' QLTY_VEHL_CD,
					     '2' MDL_MDY_CD,
					     '2' LANG_CD,
					     '2' DL_EXPD_REGN_CD,
					     '2' QLTY_VEHL_NM,
					     '2' LANG_CD_NM,
					     '2' DL_EXPD_REGN_NM,
					     '2' WEK2_PLAN_QTY,
					     '2' DAY3_PLAN_QTY,
					     '2' CURR_MTH_TRWI_QTY,
					     '2' PREV_1DAY_TRWI_QTY,
					     '2' SEWHA_IV_QTY,
					     '2' SEWHA_PRNT_YN, --세화 인쇄중 데이터 존재여부 확인 
					     '2' SEWHA_DLVY_QTY,
					     '2' PDI_DEEI1_QTY,
						   '2' EXPD_WHSN_ST_NM,
						   '2' PDI_IV_QTY,
					     '2' DSID3_QTY,
						   '2' DAY3_AFTR_IV_QTY,
						   '2' WEK2_AFTR_IV_QTY,
						   '2' PRNT_STATE,
						   '2' PRNT_STATE_NM,
						   '2' PLNT_DAY3_QTY_TEXT,
					     '2' PLNT_WEK2_QTY_TEXT,
					     '2' PLNT_YN
					     FROM DUAL;
					     
                            /*
			      SELECT A.CL_SCN_CD,
			   		     A.DATA_SN,
					     A.QLTY_VEHL_CD,
					     A.MDL_MDY_CD,
					     A.LANG_CD,
					     A.DL_EXPD_REGN_CD,
					     A.QLTY_VEHL_NM,
					     A.LANG_CD_NM,
					     A.DL_EXPD_REGN_NM,
					     A.WEK2_PLAN_QTY,
					     A.DAY3_PLAN_QTY,
					     A.CURR_MTH_TRWI_QTY,
					     A.PREV_1DAY_TRWI_QTY,
					     A.SEWHA_IV_QTY,
					     A.SEWHA_PRNT_YN, --세화 인쇄중 데이터 존재여부 확인 
					     A.SEWHA_DLVY_QTY,
					     A.PDI_DEEI1_QTY,
						 A.EXPD_WHSN_ST_NM,
						 A.PDI_IV_QTY,
					     A.DSID3_QTY,
						 A.DAY3_AFTR_IV_QTY,
						 A.WEK2_AFTR_IV_QTY,
						 A.PRNT_STATE,
						 B.DL_EXPD_PRVS_NM AS PRNT_STATE_NM,
						 PLNT_DAY3_QTY_TEXT,
					     PLNT_WEK2_QTY_TEXT,
					     PLNT_YN
			      FROM (SELECT A.CL_SCN_CD,
			   		           A.DATA_SN,
					           A.QLTY_VEHL_CD,
					           A.MDL_MDY_CD,
					           A.LANG_CD,
					           A.DL_EXPD_REGN_CD,
					           A.QLTY_VEHL_NM,
					           A.LANG_CD_NM,
					           B.DL_EXPD_PRVS_NM AS DL_EXPD_REGN_NM,
					           A.WEK2_PLAN_QTY,
					           A.DAY3_PLAN_QTY,
					           A.CURR_MTH_TRWI_QTY,
					           A.PREV_1DAY_TRWI_QTY,
					           A.SEWHA_IV_QTY,
					           A.SEWHA_PRNT_YN, --세화 인쇄중 데이터 존재여부 확인 
							   A.SEWHA_DLVY_QTY,
							   A.PDI_DEEI1_QTY,
							   A.EXPD_WHSN_ST_NM,
							   A.PDI_IV_QTY,
					           A.DSID3_QTY,
							   (A.PDI_IV_QTY - A.DAY3_PLAN_QTY) AS DAY3_AFTR_IV_QTY,
					           (A.PDI_IV_QTY - A.WEK2_PLAN_QTY) AS WEK2_AFTR_IV_QTY,
							   CASE WHEN A.DSID3_QTY * 1.5 <= A.PDI_IV_QTY - A.DAY3_PLAN_QTY THEN '01'
							     WHEN A.DSID3_QTY <= A.PDI_IV_QTY - A.DAY3_PLAN_QTY THEN '02'
								 WHEN A.DSID3_QTY > A.PDI_IV_QTY - A.DAY3_PLAN_QTY AND
								      A.DAY2_PLAN_QTY <= A.PDI_IV_QTY - A.DAY3_PLAN_QTY THEN '03'
								 ELSE '04' END AS PRNT_STATE,
							   PLNT_DAY3_QTY_TEXT,
							   PLNT_WEK2_QTY_TEXT,
							   PLNT_YN 
			         FROM (SELECT A.CL_SCN_CD,
			   				      A.DATA_SN,
							      A.QLTY_VEHL_CD,
							      A.MDL_MDY_CD,
							      A.LANG_CD,
							      A.DL_EXPD_REGN_CD,
							      A.QLTY_VEHL_NM,
							      A.LANG_CD_NM,
								  A.LANG_SORT_SN,
			   				      NVL(B.WEK2_PLAN_QTY, 0) AS WEK2_PLAN_QTY,
							      --CASE WHEN NVL(B.DAY3_PLAN_QTY1, 0) > NVL(B.DAY3_PLAN_QTY2, 0) THEN NVL(B.DAY3_PLAN_QTY1, 0)
     							  --     ELSE NVL(B.DAY3_PLAN_QTY2, 0)
								  --END AS DAY3_PLAN_QTY,
								  NVL(B.DAY3_PLAN_QTY1, 0) AS DAY3_PLAN_QTY,
							      NVL(B.CURR_MTH_TRWI_QTY, 0) AS CURR_MTH_TRWI_QTY,
							      NVL(B.PREV_1DAY_TRWI_QTY, 0) AS PREV_1DAY_TRWI_QTY,
							      NVL(C.SEWHA_IV_QTY, 0) AS SEWHA_IV_QTY,
							      NVL(C.SEWHA_PRNT_YN, 'N') AS SEWHA_PRNT_YN,
								  NVL(D.SEWHA_DLVY_QTY, 0) AS SEWHA_DLVY_QTY,
								  NVL(E.PDI_DEEI1_QTY, 0) AS PDI_DEEI1_QTY,
								  NVL(E.EXPD_WHSN_ST_NM, '') AS EXPD_WHSN_ST_NM,
							      NVL(F.PDI_IV_QTY, 0) AS PDI_IV_QTY,
							      NVL(B.DSID3_QTY, 0) AS DSID3_QTY,
								  NVL(B.DAY2_PLAN_QTY, 0) AS DAY2_PLAN_QTY,
								  NVL(G.PLNT_DAY3_QTY_TEXT, ' ') AS PLNT_DAY3_QTY_TEXT,
								  NVL(G.PLNT_WEK2_QTY_TEXT, ' ') AS PLNT_WEK2_QTY_TEXT,
								  NVL(G.PLNT_YN, 'N') AS PLNT_YN
					       FROM T A,
						   		(SELECT A.QLTY_VEHL_CD, 
										A.MDL_MDY_CD, 
										A.LANG_CD,
							      		NVL(B.WEK2_PRDN_PLN_QTY, 0) + NVL(B.TDD_PRDN_QTY3, 0) AS WEK2_PLAN_QTY,
								  		NVL(B.TDD_PRDN_PLN_QTY, 0) + NVL(B.TDD_PRDN_QTY3, 0) AS DAY3_PLAN_QTY1,
										--NVL(B.TDD_PRDN_QTY, 0) AS DAY3_PLAN_QTY2,
								  		NVL(B.TMM_TRWI_QTY, 0) AS CURR_MTH_TRWI_QTY,
								  		NVL(B.BOD_TRWI_QTY, 0) AS PREV_1DAY_TRWI_QTY,
										CASE WHEN A.LANG_CD = 'EU' THEN NVL(B.TDD_PRDN_PLN_QTY, 0) + NVL(B.TDD_PRDN_QTY2, 0)
										     ELSE NVL(B.TDD_PRDN_PLN_QTY2, 0) + NVL(B.TDD_PRDN_QTY2, 0)
									    END AS DSID3_QTY,
										NVL(B.TDD_PRDN_PLN_QTY3, 0) + NVL(B.TDD_PRDN_QTY2, 0) AS DAY2_PLAN_QTY
								 FROM T A,
						         	  TB_APS_PROD_SUM_INFO B
						         WHERE A.DATA_SN = B.DATA_SN
						   		 AND B.APL_YMD = P_CURR_YMD
								) B,
						        --세화재고
        				        (SELECT A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD, SUM(B.SFTY_IV_QTY) AS SEWHA_IV_QTY,
						                --인쇄중 데이터 존재 여부 확인 ==> DL_EXPD_TMP_IV_QTY 값은 인쇄중 이전인 경우에는 NULL, 인쇄중인경우에는 인쇄 수량, 납품이후에는 0으로 설정되어 있음 
						  		        CASE WHEN SUM(B.DL_EXPD_TMP_IV_QTY) > 0 THEN 'Y' ELSE 'N'END AS SEWHA_PRNT_YN
         				         FROM T A,
              				          TB_SEWHA_IV_INFO_DTL B
         				         WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
         				         AND A.MDL_MDY_CD = B.MDL_MDY_CD
         				         AND A.LANG_CD = B.LANG_CD
         				         AND B.CLS_YMD = P_CURR_YMD
								 AND B.SFTY_IV_QTY > 0 --안전재고수량이 없는 것은 가져오지 않는다. 
						         GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD 
								
                                ) C,
								--배송중 데이터 조회
								(SELECT A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD, SUM(B.RQ_QTY) AS SEWHA_DLVY_QTY
								 FROM T A,
									  TB_SEWHA_WHOT_INFO B
								 WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
         				         AND A.MDL_MDY_CD = B.MDL_MDY_CD							 
								 AND A.LANG_CD = B.LANG_CD
								 AND B.WHSN_YMD > P_CURR_YMD
								 AND B.WHOT_YMD <= P_CURR_YMD
								 AND B.DEL_YN = 'N'
								 GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD 
								
								 
								) D,
								--입고확인 데이터 조회 
								(SELECT A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD, 
										SUM(B.DEEI1_QTY) AS PDI_DEEI1_QTY,
										MAX(C.DL_EXPD_PRVS_NM) AS EXPD_WHSN_ST_NM
								 FROM T A,
									  TB_PDI_WHSN_INFO B,
									  TB_CODE_MGMT C
								 WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
         				         AND A.MDL_MDY_CD = B.MDL_MDY_CD								 
								 AND A.LANG_CD = B.LANG_CD
								 AND B.WHSN_YMD = P_CURR_YMD
								 AND B.DL_EXPD_WHSN_ST_CD = C.DL_EXPD_PRVS_CD(+)
						         AND C.DL_EXPD_G_CD(+) = '0013'
								 GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD
								 
								 
								) E,
                                --PDI재고
                                (SELECT A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD, SUM(B.SFTY_IV_QTY) AS PDI_IV_QTY
                                 FROM T A,
                                      TB_PDI_IV_INFO_DTL B
                                 WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
                                 AND A.MDL_MDY_CD = B.MDL_MDY_CD
                                 AND A.LANG_CD = B.LANG_CD
                                 AND B.CLS_YMD = P_CURR_YMD
								 AND B.SFTY_IV_QTY > 0 --안전재고수량이 없는 것은 가져오지 않는다. 
						         GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD

								 
                                ) F,
								(SELECT A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD,
										PG_TOT_IV_INFO.FU_GET_PLNT_DAY3_PLAN_QTY(P_CURR_YMD, A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD) AS PLNT_DAY3_QTY_TEXT,
										PG_TOT_IV_INFO.FU_GET_PLNT_WEK2_PLAN_QTY(P_CURR_YMD, A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD) AS PLNT_WEK2_QTY_TEXT,
										'Y' AS PLNT_YN
                                 FROM T A,
                                      TB_PLNT_APS_PROD_SUM_INFO B
                                 WHERE A.DATA_SN = B.DATA_SN
                                 AND B.APL_YMD = P_CURR_YMD
						         GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD
								) G
					 	   WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD(+)
                           AND A.MDL_MDY_CD = B.MDL_MDY_CD(+)
                           AND A.LANG_CD = B.LANG_CD(+)
                           AND A.QLTY_VEHL_CD = C.QLTY_VEHL_CD(+)
                           AND A.MDL_MDY_CD = C.MDL_MDY_CD(+)
                           AND A.LANG_CD = C.LANG_CD(+)
                           AND A.QLTY_VEHL_CD = D.QLTY_VEHL_CD(+)
                           AND A.MDL_MDY_CD = D.MDL_MDY_CD(+)
                           AND A.LANG_CD = D.LANG_CD(+)
                           AND A.QLTY_VEHL_CD = E.QLTY_VEHL_CD(+)
                           AND A.MDL_MDY_CD = E.MDL_MDY_CD(+)
                           AND A.LANG_CD = E.LANG_CD(+)
                           AND A.QLTY_VEHL_CD = F.QLTY_VEHL_CD(+)
                           AND A.MDL_MDY_CD = F.MDL_MDY_CD(+)
                           AND A.LANG_CD = F.LANG_CD(+)
 						   AND A.QLTY_VEHL_CD = G.QLTY_VEHL_CD(+)
						   AND A.MDL_MDY_CD = G.MDL_MDY_CD(+)
						   AND A.LANG_CD = G.LANG_CD(+)
						   
						   
			             ) A,
				         TB_CODE_MGMT B
			         WHERE A.DL_EXPD_REGN_CD = B.DL_EXPD_PRVS_CD
			         AND B.DL_EXPD_G_CD = '0008'
			         AND WEK2_PLAN_QTY + DAY3_PLAN_QTY + CURR_MTH_TRWI_QTY +
			   	         PREV_1DAY_TRWI_QTY + SEWHA_IV_QTY + SEWHA_DLVY_QTY + PDI_DEEI1_QTY + PDI_IV_QTY > 0
			         --ORDER BY QLTY_VEHL_NM, B.SORT_SN, LANG_CD_NM 
					 --ORDER BY QLTY_VEHL_CD, B.SORT_SN, LANG_CD, MDL_MDY_CD
					 ORDER BY QLTY_VEHL_CD, LANG_SORT_SN, MDL_MDY_CD
					) A,
					TB_CODE_MGMT B
			    WHERE A.PRNT_STATE = B.DL_EXPD_PRVS_CD
				AND B.DL_EXPD_G_CD = '0016'
				AND PRNT_STATE = DECODE(P_IV_STATE, 'ALL', PRNT_STATE, P_IV_STATE);
		  
		  --배송중인 데이터 조회인 경우 		
		  ELSIF P_DLVY_STATE = '01' THEN
		  		
		  		OPEN RS FOR
			 	  WITH T AS (SELECT A.CL_SCN_CD,
			          	 		    C.DATA_SN,
			  					    C.QLTY_VEHL_CD,
                                    C.MDL_MDY_CD,
                                    C.LANG_CD,
                                    --'(' || C.QLTY_VEHL_CD || ')' || B.QLTY_VEHL_NM || '-' || C.MDL_MDY_CD || 'MY' AS QLTY_VEHL_NM,
									C.QLTY_VEHL_CD || '-' || C.MDL_MDY_CD AS QLTY_VEHL_NM,
                                    --C.LANG_CD_NM,
									'(' || C.LANG_CD || ')' || C.LANG_CD_NM AS LANG_CD_NM,
                                    C.DL_EXPD_REGN_CD,
									C.SORT_SN AS LANG_SORT_SN
                             FROM (SELECT QLTY_VEHL_CD,
                                          MAX(CL_SCN_CD) AS CL_SCN_CD
                                   FROM TB_AUTH_VEHL
                                   WHERE USER_EENO = PG_COMMON.FU_RPAD(P_USER_EENO, 7)
                                   AND QLTY_VEHL_CD = DECODE(P_VEHL_CD, 'ALL', QLTY_VEHL_CD, P_VEHL_CD)
                                   GROUP BY QLTY_VEHL_CD
                                  ) A,
                                  TB_VEHL_MGMT B,
                                  TB_LANG_MGMT C
                             WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
                             AND A.QLTY_VEHL_CD = C.QLTY_VEHL_CD
                             AND B.MDL_MDY_CD = C.MDL_MDY_CD
                             AND B.MDL_MDY_CD BETWEEN V_FROM_MDL_MDY AND V_TO_MDL_MDY
                             AND B.MDL_MDY_CD = DECODE(P_MDL_MDY , '', B.MDL_MDY_CD, P_MDL_MDY)
						     AND B.DL_EXPD_PAC_SCN_CD = DECODE(P_PAC_SCN_CD, 'ALL', B.DL_EXPD_PAC_SCN_CD, P_PAC_SCN_CD)
                             AND B.DL_EXPD_PDI_CD = DECODE(P_PDI_CD, 'ALL', B.DL_EXPD_PDI_CD, P_PDI_CD)
						     AND C.DL_EXPD_REGN_CD = DECODE(P_REGN_CD, 'ALL', C.DL_EXPD_REGN_CD, P_REGN_CD)
                             AND C.LANG_CD = DECODE(P_LANG_CD, 'ALL', C.LANG_CD, P_LANG_CD)
							 AND B.USE_YN = 'Y'
							 AND C.USE_YN = 'Y'
                            )
			      SELECT A.CL_SCN_CD,
			   		     A.DATA_SN,
					     A.QLTY_VEHL_CD,
					     A.MDL_MDY_CD,
					     A.LANG_CD,
					     A.DL_EXPD_REGN_CD,
					     A.QLTY_VEHL_NM,
					     A.LANG_CD_NM,
					     A.DL_EXPD_REGN_NM,
					     A.WEK2_PLAN_QTY,
					     A.DAY3_PLAN_QTY,
					     A.CURR_MTH_TRWI_QTY,
					     A.PREV_1DAY_TRWI_QTY,
					     A.SEWHA_IV_QTY,
					     A.SEWHA_PRNT_YN, --세화 인쇄중 데이터 존재여부 확인 
					     A.SEWHA_DLVY_QTY,
					     A.PDI_DEEI1_QTY,
						 A.EXPD_WHSN_ST_NM,
						 A.PDI_IV_QTY,
					     A.DSID3_QTY,
						 A.DAY3_AFTR_IV_QTY,
						 A.WEK2_AFTR_IV_QTY,
						 A.PRNT_STATE,
						 B.DL_EXPD_PRVS_NM AS PRNT_STATE_NM,
						 PLNT_DAY3_QTY_TEXT,
						 PLNT_WEK2_QTY_TEXT,
						 PLNT_YN
			      FROM (SELECT A.CL_SCN_CD,
			   		           A.DATA_SN,
					           A.QLTY_VEHL_CD,
					           A.MDL_MDY_CD,
					           A.LANG_CD,
					           A.DL_EXPD_REGN_CD,
					           A.QLTY_VEHL_NM,
					           A.LANG_CD_NM,
					           B.DL_EXPD_PRVS_NM AS DL_EXPD_REGN_NM,
					           A.WEK2_PLAN_QTY,
					           A.DAY3_PLAN_QTY,
					           A.CURR_MTH_TRWI_QTY,
					           A.PREV_1DAY_TRWI_QTY,
					           A.SEWHA_IV_QTY,
					           A.SEWHA_PRNT_YN, --세화 인쇄중 데이터 존재여부 확인 
							   A.SEWHA_DLVY_QTY,
							    0 AS PDI_DEEI1_QTY,
							   '' AS EXPD_WHSN_ST_NM,
							   A.PDI_IV_QTY,
					           A.DSID3_QTY,
							   (A.PDI_IV_QTY - A.DAY3_PLAN_QTY) AS DAY3_AFTR_IV_QTY,
					           (A.PDI_IV_QTY - A.WEK2_PLAN_QTY) AS WEK2_AFTR_IV_QTY,
							   CASE WHEN A.DSID3_QTY * 1.5 <= A.PDI_IV_QTY - A.DAY3_PLAN_QTY THEN '01'
							        WHEN A.DSID3_QTY <= A.PDI_IV_QTY - A.DAY3_PLAN_QTY THEN '02'
								    WHEN A.DSID3_QTY > A.PDI_IV_QTY - A.DAY3_PLAN_QTY AND
								         A.DAY2_PLAN_QTY <= A.PDI_IV_QTY - A.DAY3_PLAN_QTY THEN '03'
							   ELSE '04' END AS PRNT_STATE,
							   PLNT_DAY3_QTY_TEXT,
							   PLNT_WEK2_QTY_TEXT,
							   PLNT_YN
			         FROM (SELECT A.CL_SCN_CD,
			   				      A.DATA_SN,
							      A.QLTY_VEHL_CD,
							      A.MDL_MDY_CD,
							      A.LANG_CD,
							      A.DL_EXPD_REGN_CD,
							      A.QLTY_VEHL_NM,
							      A.LANG_CD_NM,
								  A.LANG_SORT_SN,
			   				      NVL(B.WEK2_PLAN_QTY, 0) AS WEK2_PLAN_QTY,
								  --CASE WHEN NVL(B.DAY3_PLAN_QTY1, 0) > NVL(B.DAY3_PLAN_QTY2, 0) THEN NVL(B.DAY3_PLAN_QTY1, 0)
     							  --     ELSE NVL(B.DAY3_PLAN_QTY2, 0)
								  --END AS DAY3_PLAN_QTY,
								  NVL(B.DAY3_PLAN_QTY1, 0) AS DAY3_PLAN_QTY,
							      NVL(B.CURR_MTH_TRWI_QTY, 0) AS CURR_MTH_TRWI_QTY,
							      NVL(B.PREV_1DAY_TRWI_QTY, 0) AS PREV_1DAY_TRWI_QTY,
							      NVL(C.SEWHA_IV_QTY, 0) AS SEWHA_IV_QTY,
							      NVL(C.SEWHA_PRNT_YN, 'N') AS SEWHA_PRNT_YN,
								  NVL(D.SEWHA_DLVY_QTY, 0) AS SEWHA_DLVY_QTY,
							      NVL(E.PDI_IV_QTY, 0) AS PDI_IV_QTY,
							      NVL(B.DSID3_QTY, 0) AS DSID3_QTY,
								  NVL(B.DAY2_PLAN_QTY, 0) AS DAY2_PLAN_QTY,
								  NVL(F.PLNT_DAY3_QTY_TEXT, ' ') AS PLNT_DAY3_QTY_TEXT,
								  NVL(F.PLNT_WEK2_QTY_TEXT, ' ') AS PLNT_WEK2_QTY_TEXT,
								  NVL(F.PLNT_YN, 'N') AS PLNT_YN
						   FROM T A,
							     (SELECT A.QLTY_VEHL_CD, 
										A.MDL_MDY_CD, 
										A.LANG_CD,
										NVL(B.WEK2_PRDN_PLN_QTY, 0) + NVL(B.TDD_PRDN_QTY3, 0) AS WEK2_PLAN_QTY,
										NVL(B.TDD_PRDN_PLN_QTY, 0) + NVL(B.TDD_PRDN_QTY3, 0) AS DAY3_PLAN_QTY1,
										--NVL(B.TDD_PRDN_QTY, 0) AS DAY3_PLAN_QTY2,
										NVL(B.TMM_TRWI_QTY, 0) AS CURR_MTH_TRWI_QTY,
								  		NVL(B.BOD_TRWI_QTY, 0) AS PREV_1DAY_TRWI_QTY,
										CASE WHEN A.LANG_CD = 'EU' THEN NVL(B.TDD_PRDN_PLN_QTY, 0) + NVL(B.TDD_PRDN_QTY2, 0)
										     ELSE NVL(B.TDD_PRDN_PLN_QTY2, 0) + NVL(B.TDD_PRDN_QTY2, 0)
									    END AS DSID3_QTY,
										NVL(B.TDD_PRDN_PLN_QTY3, 0) + NVL(B.TDD_PRDN_QTY2, 0) AS DAY2_PLAN_QTY
								 FROM T A,
						         	  TB_APS_PROD_SUM_INFO B
						         WHERE A.DATA_SN = B.DATA_SN
						   		 AND B.APL_YMD = P_CURR_YMD
								) B,
								--세화재고
        				        (SELECT A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD, SUM(B.SFTY_IV_QTY) AS SEWHA_IV_QTY,
						                --인쇄중 데이터 존재 여부 확인 ==> DL_EXPD_TMP_IV_QTY 값은 인쇄중 이전인 경우에는 NULL, 인쇄중인경우에는 인쇄 수량, 납품이후에는 0으로 설정되어 있음 
						  		        CASE WHEN SUM(B.DL_EXPD_TMP_IV_QTY) > 0 THEN 'Y' ELSE 'N'END AS SEWHA_PRNT_YN
         				         FROM T A,
              				          TB_SEWHA_IV_INFO_DTL B
         				         WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
         				         AND A.MDL_MDY_CD = B.MDL_MDY_CD
         				         AND A.LANG_CD = B.LANG_CD
         				         AND B.CLS_YMD = P_CURR_YMD
								 AND B.SFTY_IV_QTY > 0 --안전재고수량이 없는 것은 가져오지 않는다. 
						         GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD 
								

								 
                                ) C,
								--배송중 데이터 조회
								(SELECT A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD, SUM(B.RQ_QTY) AS SEWHA_DLVY_QTY
								 FROM T A,
									  TB_SEWHA_WHOT_INFO B
								 WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
         				         AND A.MDL_MDY_CD = B.MDL_MDY_CD
								 AND A.LANG_CD = B.LANG_CD
								 AND B.WHSN_YMD > P_CURR_YMD
								 AND B.WHOT_YMD <= P_CURR_YMD
								 AND B.DEL_YN = 'N'
								 GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD 
								 
								) D,
                                --PDI재고
                                (SELECT A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD, SUM(B.SFTY_IV_QTY) AS PDI_IV_QTY
                                 FROM T A,
                                      TB_PDI_IV_INFO_DTL B
                                 WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
                                 AND A.MDL_MDY_CD = B.MDL_MDY_CD
                                 AND A.LANG_CD = B.LANG_CD
                                 AND B.CLS_YMD = P_CURR_YMD
								 AND B.SFTY_IV_QTY > 0 --안전재고수량이 없는 것은 가져오지 않는다. 
						         GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD 
	
								 
                                ) E,
								(SELECT A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD,
										PG_TOT_IV_INFO.FU_GET_PLNT_DAY3_PLAN_QTY(P_CURR_YMD, A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD) AS PLNT_DAY3_QTY_TEXT,
										PG_TOT_IV_INFO.FU_GET_PLNT_WEK2_PLAN_QTY(P_CURR_YMD, A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD) AS PLNT_WEK2_QTY_TEXT,
										'Y' AS PLNT_YN
                                 FROM T A,
                                      TB_PLNT_APS_PROD_SUM_INFO B
                                 WHERE A.DATA_SN = B.DATA_SN
                                 AND B.APL_YMD = P_CURR_YMD
						         GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD
								) F 
					       WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD(+)
                           AND A.MDL_MDY_CD = B.MDL_MDY_CD(+)
                           AND A.LANG_CD = B.LANG_CD(+)
                           AND A.QLTY_VEHL_CD = C.QLTY_VEHL_CD(+)
                           AND A.MDL_MDY_CD = C.MDL_MDY_CD(+)
                           AND A.LANG_CD = C.LANG_CD(+)
						   --배송중인 데이터만을 표시해 주기 위해서 OUTER JOIN을 빼준다..
                           AND A.QLTY_VEHL_CD = D.QLTY_VEHL_CD
                           AND A.MDL_MDY_CD = D.MDL_MDY_CD
                           AND A.LANG_CD = D.LANG_CD
                           AND A.QLTY_VEHL_CD = E.QLTY_VEHL_CD(+)
                           AND A.MDL_MDY_CD = E.MDL_MDY_CD(+)
                           AND A.LANG_CD = E.LANG_CD(+)
						   AND A.QLTY_VEHL_CD = F.QLTY_VEHL_CD(+)
						   AND A.MDL_MDY_CD = F.MDL_MDY_CD(+)
						   AND A.LANG_CD = F.LANG_CD(+)
						   
			             ) A,
				         TB_CODE_MGMT B
			         WHERE A.DL_EXPD_REGN_CD = B.DL_EXPD_PRVS_CD
			         AND B.DL_EXPD_G_CD = '0008'
			         AND WEK2_PLAN_QTY + DAY3_PLAN_QTY + CURR_MTH_TRWI_QTY +
			   	         PREV_1DAY_TRWI_QTY + SEWHA_IV_QTY + SEWHA_DLVY_QTY + PDI_IV_QTY > 0
			         --ORDER BY QLTY_VEHL_NM, B.SORT_SN, LANG_CD_NM
					 ORDER BY QLTY_VEHL_CD, LANG_SORT_SN, MDL_MDY_CD
					) A,
					TB_CODE_MGMT B
			    WHERE A.PRNT_STATE = B.DL_EXPD_PRVS_CD
				AND B.DL_EXPD_G_CD = '0016'
				AND PRNT_STATE = DECODE(P_IV_STATE, 'ALL', PRNT_STATE, P_IV_STATE);
		  
		  ELSE
		  	  
			  --배송완료된 데이터 조회인 경우
			  	
		  	  OPEN RS FOR
			 	  WITH T AS (SELECT A.CL_SCN_CD,
			          	 		    C.DATA_SN,
			  					    C.QLTY_VEHL_CD,
                                    C.MDL_MDY_CD,
                                    C.LANG_CD,
                                    --'(' || C.QLTY_VEHL_CD || ')' || B.QLTY_VEHL_NM || '-' || C.MDL_MDY_CD || 'MY' AS QLTY_VEHL_NM,
									C.QLTY_VEHL_CD || '-' || C.MDL_MDY_CD AS QLTY_VEHL_NM,
                                    --C.LANG_CD_NM,
									'(' || C.LANG_CD || ')' || C.LANG_CD_NM AS LANG_CD_NM,
                                    C.DL_EXPD_REGN_CD,
									C.SORT_SN AS LANG_SORT_SN
                             FROM (SELECT QLTY_VEHL_CD,
                                          MAX(CL_SCN_CD) AS CL_SCN_CD
                                   FROM TB_AUTH_VEHL
                                   WHERE USER_EENO = PG_COMMON.FU_RPAD(P_USER_EENO, 7)
                                   AND QLTY_VEHL_CD = DECODE(P_VEHL_CD, 'ALL', QLTY_VEHL_CD, P_VEHL_CD)
                                   GROUP BY QLTY_VEHL_CD
                                  ) A,
                                  TB_VEHL_MGMT B,
                                  TB_LANG_MGMT C
                             WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
                             AND A.QLTY_VEHL_CD = C.QLTY_VEHL_CD
                             AND B.MDL_MDY_CD = C.MDL_MDY_CD
                             AND B.MDL_MDY_CD BETWEEN V_FROM_MDL_MDY AND V_TO_MDL_MDY
                             AND B.MDL_MDY_CD = DECODE(P_MDL_MDY, '', B.MDL_MDY_CD, P_MDL_MDY)
						     AND B.DL_EXPD_PAC_SCN_CD = DECODE(P_PAC_SCN_CD, 'ALL', B.DL_EXPD_PAC_SCN_CD, P_PAC_SCN_CD)
                             AND B.DL_EXPD_PDI_CD = DECODE(P_PDI_CD, 'ALL', B.DL_EXPD_PDI_CD, P_PDI_CD)
						     AND C.DL_EXPD_REGN_CD = DECODE(P_REGN_CD, 'ALL', C.DL_EXPD_REGN_CD, P_REGN_CD)
                             AND C.LANG_CD = DECODE(P_LANG_CD, 'ALL', C.LANG_CD, P_LANG_CD)
							 AND B.USE_YN = 'Y'
							 AND C.USE_YN = 'Y'
                            )
			      SELECT A.CL_SCN_CD,
			   		     A.DATA_SN,
					     A.QLTY_VEHL_CD,
					     A.MDL_MDY_CD,
					     A.LANG_CD,
					     A.DL_EXPD_REGN_CD,
					     A.QLTY_VEHL_NM,
					     A.LANG_CD_NM,
					     A.DL_EXPD_REGN_NM,
					     A.WEK2_PLAN_QTY,
					     A.DAY3_PLAN_QTY,
					     A.CURR_MTH_TRWI_QTY,
					     A.PREV_1DAY_TRWI_QTY,
					     A.SEWHA_IV_QTY,
					     A.SEWHA_PRNT_YN, --세화 인쇄중 데이터 존재여부 확인 
					     A.SEWHA_DLVY_QTY,
					     A.PDI_DEEI1_QTY,
						 A.EXPD_WHSN_ST_NM,
						 A.PDI_IV_QTY,
					     A.DSID3_QTY,
						 A.DAY3_AFTR_IV_QTY,
						 A.WEK2_AFTR_IV_QTY,
						 A.PRNT_STATE,
						 B.DL_EXPD_PRVS_NM AS PRNT_STATE_NM,
						 PLNT_DAY3_QTY_TEXT,
						 PLNT_WEK2_QTY_TEXT,
						 PLNT_YN
			      FROM (SELECT A.CL_SCN_CD,
			   		           A.DATA_SN,
					           A.QLTY_VEHL_CD,
					           A.MDL_MDY_CD,
					           A.LANG_CD,
					           A.DL_EXPD_REGN_CD,
					           A.QLTY_VEHL_NM,
					           A.LANG_CD_NM,
					           B.DL_EXPD_PRVS_NM AS DL_EXPD_REGN_NM,
					           A.WEK2_PLAN_QTY,
					           A.DAY3_PLAN_QTY,
					           A.CURR_MTH_TRWI_QTY,
					           A.PREV_1DAY_TRWI_QTY,
					           A.SEWHA_IV_QTY,
					           A.SEWHA_PRNT_YN, --세화 인쇄중 데이터 존재여부 확인 
							   0 AS SEWHA_DLVY_QTY,
							   A.PDI_DEEI1_QTY,
							   A.EXPD_WHSN_ST_NM,
							   A.PDI_IV_QTY,
					           A.DSID3_QTY,
							   (A.PDI_IV_QTY - A.DAY3_PLAN_QTY) AS DAY3_AFTR_IV_QTY,
					           (A.PDI_IV_QTY - A.WEK2_PLAN_QTY) AS WEK2_AFTR_IV_QTY,
							   CASE WHEN A.DSID3_QTY * 1.5 <= A.PDI_IV_QTY - A.DAY3_PLAN_QTY THEN '01'
							        WHEN A.DSID3_QTY <= A.PDI_IV_QTY - A.DAY3_PLAN_QTY THEN '02'
								    WHEN A.DSID3_QTY > A.PDI_IV_QTY - A.DAY3_PLAN_QTY AND
								         A.DAY2_PLAN_QTY <= A.PDI_IV_QTY - A.DAY3_PLAN_QTY THEN '03'
								    ELSE '04' 
							   END AS PRNT_STATE,
							   PLNT_DAY3_QTY_TEXT,
							   PLNT_WEK2_QTY_TEXT,
							   PLNT_YN
			         FROM (SELECT A.CL_SCN_CD,
			   				      A.DATA_SN,
							      A.QLTY_VEHL_CD,
							      A.MDL_MDY_CD,
							      A.LANG_CD,
							      A.DL_EXPD_REGN_CD,
							      A.QLTY_VEHL_NM,
							      A.LANG_CD_NM,
								  A.LANG_SORT_SN,
			   				      NVL(B.WEK2_PLAN_QTY, 0) AS WEK2_PLAN_QTY,
								  --CASE WHEN NVL(B.DAY3_PLAN_QTY1, 0) > NVL(B.DAY3_PLAN_QTY2, 0) THEN NVL(B.DAY3_PLAN_QTY1, 0)
     							  --     ELSE NVL(B.DAY3_PLAN_QTY2, 0)
								  --END AS DAY3_PLAN_QTY,
								  NVL(B.DAY3_PLAN_QTY1, 0) AS DAY3_PLAN_QTY,
							      NVL(B.CURR_MTH_TRWI_QTY, 0) AS CURR_MTH_TRWI_QTY,
							      NVL(B.PREV_1DAY_TRWI_QTY, 0) AS PREV_1DAY_TRWI_QTY,
							      NVL(C.SEWHA_IV_QTY, 0) AS SEWHA_IV_QTY,
							      NVL(C.SEWHA_PRNT_YN, 'N') AS SEWHA_PRNT_YN,
								  NVL(D.PDI_DEEI1_QTY, 0) AS PDI_DEEI1_QTY,
								  NVL(D.EXPD_WHSN_ST_NM, '') AS EXPD_WHSN_ST_NM,
							      NVL(E.PDI_IV_QTY, 0) AS PDI_IV_QTY,
							      NVL(B.DSID3_QTY, 0) AS DSID3_QTY,
								  NVL(B.DAY2_PLAN_QTY, 0) AS DAY2_PLAN_QTY,
								  NVL(F.PLNT_DAY3_QTY_TEXT, ' ') AS PLNT_DAY3_QTY_TEXT,
								  NVL(F.PLNT_WEK2_QTY_TEXT, ' ') AS PLNT_WEK2_QTY_TEXT,
								  NVL(F.PLNT_YN, 'N') AS PLNT_YN
						   FROM T A,
						        (SELECT A.QLTY_VEHL_CD, 
										A.MDL_MDY_CD, 
										A.LANG_CD,
										NVL(B.WEK2_PRDN_PLN_QTY, 0) + NVL(B.TDD_PRDN_QTY3, 0) AS WEK2_PLAN_QTY,
										NVL(B.TDD_PRDN_PLN_QTY, 0) + NVL(B.TDD_PRDN_QTY3, 0) AS DAY3_PLAN_QTY1,
										--NVL(B.TDD_PRDN_QTY, 0) AS DAY3_PLAN_QTY2,
										NVL(B.TMM_TRWI_QTY, 0) AS CURR_MTH_TRWI_QTY,
								  		NVL(B.BOD_TRWI_QTY, 0) AS PREV_1DAY_TRWI_QTY,
										CASE WHEN A.LANG_CD = 'EU' THEN NVL(B.TDD_PRDN_PLN_QTY, 0) + NVL(B.TDD_PRDN_QTY2, 0)
										     ELSE NVL(B.TDD_PRDN_PLN_QTY2, 0) + NVL(B.TDD_PRDN_QTY2, 0)
									    END AS DSID3_QTY,
										NVL(B.TDD_PRDN_PLN_QTY3, 0) + NVL(B.TDD_PRDN_QTY2, 0) AS DAY2_PLAN_QTY
								 FROM T A,
						         	  TB_APS_PROD_SUM_INFO B
						         WHERE A.DATA_SN = B.DATA_SN
						   		 AND B.APL_YMD = P_CURR_YMD
								) B,
								--세화재고
        				        (SELECT A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD, SUM(B.SFTY_IV_QTY) AS SEWHA_IV_QTY,
						                --인쇄중 데이터 존재 여부 확인 ==> DL_EXPD_TMP_IV_QTY 값은 인쇄중 이전인 경우에는 NULL, 인쇄중인경우에는 인쇄 수량, 납품이후에는 0으로 설정되어 있음 
						  		        CASE WHEN SUM(B.DL_EXPD_TMP_IV_QTY) > 0 THEN 'Y' ELSE 'N'END AS SEWHA_PRNT_YN
         				         FROM T A,
              				          TB_SEWHA_IV_INFO_DTL B
         				         WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
         				         AND A.MDL_MDY_CD = B.MDL_MDY_CD
         				         AND A.LANG_CD = B.LANG_CD
         				         AND B.CLS_YMD = P_CURR_YMD
								 AND B.SFTY_IV_QTY > 0 --안전재고수량이 없는 것은 가져오지 않는다. 
						         GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD
								 
                                ) C,
								--입고확인 데이터 조회 
								(SELECT A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD, 
										SUM(B.DEEI1_QTY) AS PDI_DEEI1_QTY,
										MAX(C.DL_EXPD_PRVS_NM) AS EXPD_WHSN_ST_NM
								 FROM T A,
									  TB_PDI_WHSN_INFO B,
									  TB_CODE_MGMT C
								 WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
         				         AND A.MDL_MDY_CD = B.MDL_MDY_CD
							 	 AND A.LANG_CD = B.LANG_CD
								 AND B.WHSN_YMD = P_CURR_YMD
								 AND B.DL_EXPD_WHSN_ST_CD = C.DL_EXPD_PRVS_CD(+)
						         AND C.DL_EXPD_G_CD(+) = '0013'
								 GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD 
								 
								) D,
                                --PDI재고
                                (SELECT A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD, SUM(B.SFTY_IV_QTY) AS PDI_IV_QTY
                                 FROM T A,
                                      TB_PDI_IV_INFO_DTL B
                                 WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
                                 AND A.MDL_MDY_CD = B.MDL_MDY_CD
                                 AND A.LANG_CD = B.LANG_CD
                                 AND B.CLS_YMD = P_CURR_YMD
								 AND B.SFTY_IV_QTY > 0 --안전재고수량이 없는 것은 가져오지 않는다. 
						         GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD

                                ) E,
								(SELECT A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD,
										PG_TOT_IV_INFO.FU_GET_PLNT_DAY3_PLAN_QTY(P_CURR_YMD, A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD) AS PLNT_DAY3_QTY_TEXT,
										PG_TOT_IV_INFO.FU_GET_PLNT_WEK2_PLAN_QTY(P_CURR_YMD, A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD) AS PLNT_WEK2_QTY_TEXT,
										'Y' AS PLNT_YN
                                 FROM T A,
                                      TB_PLNT_APS_PROD_SUM_INFO B
                                 WHERE A.DATA_SN = B.DATA_SN
                                 AND B.APL_YMD = P_CURR_YMD
						         GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD
								) F 
						   WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD(+)
                           AND A.MDL_MDY_CD = B.MDL_MDY_CD(+)
                           AND A.LANG_CD = B.LANG_CD(+)
                           AND A.QLTY_VEHL_CD = C.QLTY_VEHL_CD(+)
                           AND A.MDL_MDY_CD = C.MDL_MDY_CD(+)
                           AND A.LANG_CD = C.LANG_CD(+)
						   AND A.QLTY_VEHL_CD = D.QLTY_VEHL_CD
                           AND A.MDL_MDY_CD = D.MDL_MDY_CD
                           AND A.LANG_CD = D.LANG_CD
                           AND A.QLTY_VEHL_CD = E.QLTY_VEHL_CD(+)
                           AND A.MDL_MDY_CD = E.MDL_MDY_CD(+)
                           AND A.LANG_CD = E.LANG_CD(+)
                           AND A.QLTY_VEHL_CD = F.QLTY_VEHL_CD(+)
						   AND A.MDL_MDY_CD = F.MDL_MDY_CD(+)
						   AND A.LANG_CD = F.LANG_CD(+)
			             ) A,
				         TB_CODE_MGMT B
			         WHERE A.DL_EXPD_REGN_CD = B.DL_EXPD_PRVS_CD
			         AND B.DL_EXPD_G_CD = '0008'
			         AND WEK2_PLAN_QTY + DAY3_PLAN_QTY + CURR_MTH_TRWI_QTY +
			   	         PREV_1DAY_TRWI_QTY + SEWHA_IV_QTY + PDI_DEEI1_QTY + PDI_IV_QTY > 0
					 ORDER BY QLTY_VEHL_CD, LANG_SORT_SN, MDL_MDY_CD
					) A,
					TB_CODE_MGMT B
			    WHERE A.PRNT_STATE = B.DL_EXPD_PRVS_CD
				AND B.DL_EXPD_G_CD = '0016'
				AND PRNT_STATE = DECODE(P_IV_STATE, 'ALL', PRNT_STATE, P_IV_STATE);
		  */
		  END IF;
		  
	   END SP_GET_SEWHA_IV_INFO2;


