CREATE OR REPLACE 
       --재고상세 내역 재계산 작업 수행 								   
	   PROCEDURE SP_RECALCULATE_SEWHA_IV_DTL4(P_CLS_YMD   VARCHAR2,
										      P_VEHL_CD   VARCHAR2,
			  						          P_LANG_CD   VARCHAR2,
										      P_USER_EENO VARCHAR2
										      , P_PRDN_PLNT_CD VARCHAR2
										      )
	   IS
	   	 
		 CURSOR SEWHA_IV_LIST_INFO IS SELECT QLTY_VEHL_CD,
		 						   	  		 DL_EXPD_MDL_MDY_CD,
		 						  	 	     LANG_CD,
										     N_PRNT_PBCN_NO
										     , NVL(PRDN_PLNT_CD,'N') AS PRDN_PLNT_CD 
		 						  	  FROM TB_SEWHA_IV_INFO
									  --재고수량이 0보다 큰 것 보다 현재일에 존재하는 모든 항목을 해 주어야 한다.
									  --AND IV_QTY > 0 
									  WHERE CLS_YMD = P_CLS_YMD
									  AND QLTY_VEHL_CD = P_VEHL_CD
									  AND LANG_CD = P_LANG_CD
									  AND NVL(PRDN_PLNT_CD,'N') = DECODE(P_PRDN_PLNT_CD,'7','7','6','7',P_PRDN_PLNT_CD)
									  GROUP BY QLTY_VEHL_CD, LANG_CD, N_PRNT_PBCN_NO, DL_EXPD_MDL_MDY_CD, NVL(PRDN_PLNT_CD,'N')
									  --정렬조건을 아래와 같은 순서를 준수하여야 한다. 
									  ORDER BY QLTY_VEHL_CD, LANG_CD, N_PRNT_PBCN_NO, DL_EXPD_MDL_MDY_CD;
									
	   BEGIN
	   		
			--취급설명서 연식과 차종연식이 다른 항목은 우선 삭제한다. 
			DELETE FROM TB_SEWHA_IV_INFO_DTL 
			WHERE CLS_YMD = P_CLS_YMD 
			AND QLTY_VEHL_CD = P_VEHL_CD 
			AND MDL_MDY_CD <> DL_EXPD_MDL_MDY_CD 
			AND LANG_CD = P_LANG_CD;
			
			--취급설명서 연식과 차종연식이 같은 경우에는 안전재고수량을 재고수량으로 업데이트 해 준다. 
			UPDATE TB_SEWHA_IV_INFO_DTL 
			SET SFTY_IV_QTY = IV_QTY,
			    UPDR_EENO = P_USER_EENO,
				MDFY_DTM = SYSDATE
			WHERE CLS_YMD = P_CLS_YMD
			AND QLTY_VEHL_CD = P_VEHL_CD 
			AND MDL_MDY_CD = DL_EXPD_MDL_MDY_CD 
			AND LANG_CD = P_LANG_CD
			AND NVL(PRDN_PLNT_CD,'N') = DECODE(P_PRDN_PLNT_CD,'7','7','6','7',P_PRDN_PLNT_CD);
			
			FOR SEWHA_IV_LIST IN SEWHA_IV_LIST_INFO LOOP
				
				SP_RECALCULATE_SEWHA_IV_SUB(P_CLS_YMD,
										    SEWHA_IV_LIST.QLTY_VEHL_CD,
										    SEWHA_IV_LIST.DL_EXPD_MDL_MDY_CD,
										    SEWHA_IV_LIST.LANG_CD,
										    SEWHA_IV_LIST.N_PRNT_PBCN_NO,
										    P_USER_EENO
										    , P_PRDN_PLNT_CD);
			END LOOP;
			
	   END SP_RECALCULATE_SEWHA_IV_DTL4;
