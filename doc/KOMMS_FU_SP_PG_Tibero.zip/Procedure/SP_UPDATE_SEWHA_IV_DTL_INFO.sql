CREATE OR REPLACE PROCEDURE KOMMS_ADM.SP_UPDATE_SEWHA_IV_DTL_INFO(P_VEHL_CD         VARCHAR2,
			  							     P_EXPD_MDL_MDY_CD VARCHAR2,
									         P_LANG_CD         VARCHAR2,
									         P_N_PRNT_PBCN_NO  VARCHAR2,
									         P_CLS_YMD		   VARCHAR2,
										     P_USER_EENO	   VARCHAR2
										     , P_PRDN_PLNT_CD    VARCHAR2
										     )
	   IS
	   		 
		 V_IV_QTY      	   NUMBER;
		 V_EXPD_TMP_IV_QTY NUMBER;
		 V_CNT	           NUMBER;
		 V_CMPL_YN     	   VARCHAR2(1);
		 V_TMP_TRTM_YN 	   VARCHAR2(1);

	   BEGIN

			--재고 테이블 재고 수량 조회 
			SELECT SUM(IV_QTY),
				   SUM(DL_EXPD_TMP_IV_QTY),
			   	   MAX(CMPL_YN),
				   MAX(TMP_TRTM_YN)
			INTO V_IV_QTY,
				 V_EXPD_TMP_IV_QTY,
			     V_CMPL_YN,
				 V_TMP_TRTM_YN
			FROM TB_SEWHA_IV_INFO
			WHERE CLS_YMD = P_CLS_YMD
			AND QLTY_VEHL_CD = P_VEHL_CD
			AND DL_EXPD_MDL_MDY_CD = P_EXPD_MDL_MDY_CD
			AND LANG_CD = P_LANG_CD
			AND N_PRNT_PBCN_NO = P_N_PRNT_PBCN_NO
			AND NVL(PRDN_PLNT_CD,'N') = DECODE(P_PRDN_PLNT_CD,'7','7','6','7',P_PRDN_PLNT_CD);
			
			--재고 테이블에 데이터가 존재하는 경우에 아래의 작업을 수행한다. 
			IF V_CMPL_YN IS NOT NULL THEN
			   
			   --재고상세 테이블내에 취급설명서연식으로 적용된 항목의 재고수량을 변경된 수량으로 
			   --모두 업데이트 해 준다. 
			   --단, 차종의 연식과 취급설명서의 연식이 같은 경우에만 업데이트 해준다.
			   --(왜냐하면 같은 않은 항목은 재고 상세 내역 재계산시에 우선 삭제된 뒤에 다시 계산하기 때문에 의미가 없다.)  
			   UPDATE TB_SEWHA_IV_INFO_DTL
			   SET IV_QTY = V_IV_QTY,
			   	   --안전재고의 수량을 재고수량과 같게 해준다.
			   	   SFTY_IV_QTY = V_IV_QTY,
			   	   DL_EXPD_TMP_IV_QTY = V_EXPD_TMP_IV_QTY,
			   	   CMPL_YN = V_CMPL_YN,
				   UPDR_EENO = P_USER_EENO,
				   MDFY_DTM = SYSDATE,
				   TMP_TRTM_YN = V_TMP_TRTM_YN
			   WHERE CLS_YMD = P_CLS_YMD
			   AND QLTY_VEHL_CD = P_VEHL_CD
			   --차종의 연식과 취급설명서의 연식이 같은 경우에만 업데이트 해 주도록 한다. 
			   AND MDL_MDY_CD = P_EXPD_MDL_MDY_CD 
			   AND LANG_CD = P_LANG_CD
			   AND DL_EXPD_MDL_MDY_CD = P_EXPD_MDL_MDY_CD
			   AND N_PRNT_PBCN_NO = P_N_PRNT_PBCN_NO
			   AND NVL(PRDN_PLNT_CD,'N') = DECODE(P_PRDN_PLNT_CD,'7','7','6','7',P_PRDN_PLNT_CD);
			   
			   IF SQL%NOTFOUND THEN
			   	  
				  INSERT INTO TB_SEWHA_IV_INFO_DTL
				   (CLS_YMD,
				   	QLTY_VEHL_CD,
				   	MDL_MDY_CD,
				   	LANG_CD,
				   	DL_EXPD_MDL_MDY_CD,
				   	N_PRNT_PBCN_NO,
				   	IV_QTY,
				   	SFTY_IV_QTY,
					DL_EXPD_TMP_IV_QTY,
				   	CMPL_YN,
				   	PPRR_EENO,
				   	FRAM_DTM,
				   	UPDR_EENO,
				   	MDFY_DTM,
					TMP_TRTM_YN
					, PRDN_PLNT_CD
				   )
				   VALUES
				   (P_CLS_YMD,
				   	P_VEHL_CD,
					--차종의 연식과 취급설명서의 연식을 같은 값으로 입력해 준다.(반드시 취급설명서의 연식으로 입력) 
				   	P_EXPD_MDL_MDY_CD,
				   	P_LANG_CD,
				   	P_EXPD_MDL_MDY_CD,
				   	P_N_PRNT_PBCN_NO,
				   	V_IV_QTY,
					--차종의 연식과 취급설명서의 연식이 같은 경우에는 안전재고의 수량을 재고수량과 같게 해준다.
				   	V_IV_QTY,
					V_EXPD_TMP_IV_QTY,
				   	V_CMPL_YN,
				   	P_USER_EENO,
				   	SYSDATE,
				   	P_USER_EENO,
				   	SYSDATE,
					V_TMP_TRTM_YN
					,  DECODE(P_PRDN_PLNT_CD,'7','7','6','7',P_PRDN_PLNT_CD)
				   );
				  
			   END IF;
    
			END IF;
			
	   END SP_UPDATE_SEWHA_IV_DTL_INFO;