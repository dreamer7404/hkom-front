CREATE OR REPLACE  PROCEDURE SP_RECALCULATE_SEWHA_IV_SUB(P_CLS_YMD	       VARCHAR2,
										     P_VEHL_CD         VARCHAR2,
			  						         P_EXPD_MDL_MDY_CD VARCHAR2,
									         P_LANG_CD         VARCHAR2,
										     P_N_PRNT_PBCN_NO  VARCHAR2,
										     P_USER_EENO       VARCHAR2
										     , P_PRDN_PLNT_CD VARCHAR2
										     )
	   IS
	   
	   	 V_CURR_MDL_MDY_CD    VARCHAR2(2);
		 V_CURR_WEK2_PLAN_QTY NUMBER;
		 V_CURR_SFTY_IV_QTY   NUMBER;
		 V_CURR_PDI_IV_QTY	  NUMBER;
		 
		 V_SFTY_IV_DIFF_QTY NUMBER;
		 V_SFTY_IV_DIFF 	NUMBER;
		 
		 V_DL_IV_QTY          NUMBER;
		 V_DL_PDI_IV_QTY      NUMBER;
		 V_DL_EXPD_TMP_IV_QTY NUMBER;
		 V_DL_CMPL_YN         VARCHAR(1);
		 V_DL_TMP_TRTM_YN     VARCHAR(1);
		 V_DL_WEK2_PLAN_QTY	  NUMBER;
		 
		 V_CURR_IV_QTY		  NUMBER;
		 V_TEMP_IV_QTY		  NUMBER;
		 V_FLAG				  VARCHAR(1);
		 
		 CURSOR SEWHA_IV_DTL_LIST_INFO IS SELECT MDL_MDY_CD
									      FROM (
										        --[변경2]차종연식과 취급설명서 연식이 같은 경우도 가져와서 계산하게 되면 수량이 남더라도 
												--이전연식의 안전재고수량은 무조건 2주생산계획 만큼만 남게 되고 나머지 수량은 가장 최근의 연식으로 포함되게 된다.
												--이것 역시 문제가 될 수 있다.
												--그래서 다시 차종연식과 취급설명서 연식이 같은 경우는 제외하도록 하고 로직에서 [변경1]의 문제를 해결하도록 한다.
										        --[변경1]전방통합, 전체통합과 같이 이전 연식의 수량을 이후 연식에서 사용할 경우를 대비하여
												--차종연식과 취급설명서 연식이 같은 경우도 가져와야 한다.
										  	    
												/***  세원 입고현황은 차종연식과 취급설명서 연식이 다른 경우가 현재는 존재치 않는다.
												       그래서 조회할 필요가 없다.
													   
										  	    SELECT MDL_MDY_CD 
                                                FROM TB_SEWHA_WHSN_INFO 
												WHERE WHSN_YMD = P_CLS_YMD 
												AND QLTY_VEHL_CD = P_VEHL_CD 
												AND DL_EXPD_MDL_MDY_CD = P_EXPD_MDL_MDY_CD 
												AND LANG_CD = P_LANG_CD
												AND N_PRNT_PBCN_NO = P_N_PRNT_PBCN_NO 
												--차종연식과 취급설명서 연식이 다른 항목만을 가져온다.
                                                AND MDL_MDY_CD <> DL_EXPD_MDL_MDY_CD 
												GROUP BY MDL_MDY_CD 
											    
											    UNION ALL 
												***/
												
											    SELECT MDL_MDY_CD
											    FROM TB_SEWHA_WHOT_INFO
												WHERE WHOT_YMD = P_CLS_YMD
												AND QLTY_VEHL_CD = P_VEHL_CD
												AND DL_EXPD_MDL_MDY_CD = P_EXPD_MDL_MDY_CD
												AND LANG_CD = P_LANG_CD
												AND N_PRNT_PBCN_NO = P_N_PRNT_PBCN_NO
												--차종연식과 취급설명서 연식이 다른 항목만을 가져온다.
											    AND MDL_MDY_CD <> DL_EXPD_MDL_MDY_CD
												AND DEL_YN = 'N'
												GROUP BY MDL_MDY_CD

											    UNION ALL
											  
											    SELECT A.MDL_MDY_CD
											    FROM TB_LANG_MGMT A,
     										         TB_DL_EXPD_MDY_MGMT B,
	 											     TB_SEWHA_IV_INFO C
                                                WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
											    AND A.MDL_MDY_CD = B.MDL_MDY_CD
			 			 		   			    AND A.DL_EXPD_REGN_CD = B.DL_EXPD_REGN_CD 								   
											    AND A.QLTY_VEHL_CD = C.QLTY_VEHL_CD
											    AND B.DL_EXPD_MDL_MDY_CD = C.DL_EXPD_MDL_MDY_CD
											    AND A.LANG_CD = C.LANG_CD
											    --차종연식과 취급설명서 연식이 다른 항목만을 가져온다.
											    AND B.MDL_MDY_CD <> B.DL_EXPD_MDL_MDY_CD
											    AND C.CLS_YMD = P_CLS_YMD
											    AND C.QLTY_VEHL_CD = P_VEHL_CD
											    AND C.DL_EXPD_MDL_MDY_CD = P_EXPD_MDL_MDY_CD
											    AND C.LANG_CD = P_LANG_CD
											    AND C.N_PRNT_PBCN_NO = P_N_PRNT_PBCN_NO
											    GROUP BY A.MDL_MDY_CD
										       )
										  GROUP BY MDL_MDY_CD
										  --정렬순서를 아래와 같이 하여야 한다.
										  ORDER BY MDL_MDY_CD;
	   BEGIN
	   		
			SELECT MAX(IV_QTY),
				   MAX(DL_EXPD_TMP_IV_QTY),
				   MAX(CMPL_YN),
				   MAX(TMP_TRTM_YN)
			INTO V_DL_IV_QTY,
			     V_DL_EXPD_TMP_IV_QTY,
				 V_DL_CMPL_YN,
				 V_DL_TMP_TRTM_YN
			FROM TB_SEWHA_IV_INFO
			WHERE CLS_YMD = P_CLS_YMD
			AND QLTY_VEHL_CD = P_VEHL_CD
			AND DL_EXPD_MDL_MDY_CD = P_EXPD_MDL_MDY_CD
			AND LANG_CD = P_LANG_CD
			AND N_PRNT_PBCN_NO = P_N_PRNT_PBCN_NO
			AND NVL(PRDN_PLNT_CD,'N') = DECODE(P_PRDN_PLNT_CD,'7','7','6','7',P_PRDN_PLNT_CD) ;
			
			IF P_VEHL_CD = 'PS' or P_VEHL_CD = 'AM' or P_VEHL_CD = 'SK' THEN
				--취급설명서 연식의 2주생산 계획 데이터 조회 
				SELECT NVL(SUM(WEK2_PRDN_PLN_QTY), 0) + NVL(SUM(TDD_PRDN_QTY3), 0)
				INTO V_DL_WEK2_PLAN_QTY
				FROM TB_PLNT_APS_PROD_SUM_INFO
				WHERE APL_YMD = P_CLS_YMD
				AND QLTY_VEHL_CD = P_VEHL_CD
				AND MDL_MDY_CD = P_EXPD_MDL_MDY_CD
				AND LANG_CD = P_LANG_CD
				AND NVL(PRDN_PLNT_CD,'N') = DECODE(P_PRDN_PLNT_CD,'7','7','6','7',P_PRDN_PLNT_CD) ;
			ELSE
				--취급설명서 연식의 2주생산 계획 데이터 조회 
				SELECT NVL(SUM(WEK2_PRDN_PLN_QTY), 0) + NVL(SUM(TDD_PRDN_QTY3), 0)
				INTO V_DL_WEK2_PLAN_QTY
				FROM TB_APS_PROD_SUM_INFO
				WHERE APL_YMD = P_CLS_YMD
				AND QLTY_VEHL_CD = P_VEHL_CD
				AND MDL_MDY_CD = P_EXPD_MDL_MDY_CD
				AND LANG_CD = P_LANG_CD;
			END IF;
			
			--취급설명서 연식의 PDI 안전재고수량 조회 
			SELECT SUM(SFTY_IV_QTY)
			INTO V_DL_PDI_IV_QTY
			FROM TB_PDI_IV_INFO_DTL
			WHERE CLS_YMD = P_CLS_YMD
			AND QLTY_VEHL_CD = P_VEHL_CD
			AND MDL_MDY_CD = P_EXPD_MDL_MDY_CD
			AND LANG_CD = P_LANG_CD
			AND NVL(PRDN_PLNT_CD,'N') = P_PRDN_PLNT_CD;
					
			V_CURR_IV_QTY := V_DL_IV_QTY;
			
			FOR SEWHA_IV_DTL_LIST IN SEWHA_IV_DTL_LIST_INFO LOOP
				
				V_CURR_MDL_MDY_CD := SEWHA_IV_DTL_LIST.MDL_MDY_CD;
				
				
				IF P_VEHL_CD = 'PS' or P_VEHL_CD = 'AM' or P_VEHL_CD = 'SK' THEN
					SELECT NVL(SUM(WEK2_PRDN_PLN_QTY), 0) + NVL(SUM(TDD_PRDN_QTY3), 0)
					INTO V_CURR_WEK2_PLAN_QTY
					FROM TB_PLNT_APS_PROD_SUM_INFO
					WHERE APL_YMD = P_CLS_YMD
					AND QLTY_VEHL_CD = P_VEHL_CD
					AND MDL_MDY_CD = V_CURR_MDL_MDY_CD
					AND LANG_CD = P_LANG_CD
					AND NVL(PRDN_PLNT_CD,'N') = P_PRDN_PLNT_CD;
				ELSE
				--2주생산 계획 데이터 조회 
					SELECT NVL(SUM(WEK2_PRDN_PLN_QTY), 0) + NVL(SUM(TDD_PRDN_QTY3), 0)
					INTO V_CURR_WEK2_PLAN_QTY
					FROM TB_APS_PROD_SUM_INFO
					WHERE APL_YMD = P_CLS_YMD
					AND QLTY_VEHL_CD = P_VEHL_CD
					AND MDL_MDY_CD = V_CURR_MDL_MDY_CD
					AND LANG_CD = P_LANG_CD;
				END IF;
				
				
				   
				--현재 안전재고 수량 조회 
				SELECT NVL(SUM(SFTY_IV_QTY), 0)
				INTO V_CURR_SFTY_IV_QTY
				FROM TB_SEWHA_IV_INFO_DTL
				WHERE CLS_YMD = P_CLS_YMD
				AND QLTY_VEHL_CD = P_VEHL_CD
				AND MDL_MDY_CD = V_CURR_MDL_MDY_CD
				AND LANG_CD = P_LANG_CD
                AND NVL(PRDN_PLNT_CD,'N') = P_PRDN_PLNT_CD;
				
				--PDI 안전재고수량 조회 
				SELECT SUM(SFTY_IV_QTY)
				INTO V_CURR_PDI_IV_QTY
				FROM TB_PDI_IV_INFO_DTL
				WHERE CLS_YMD = P_CLS_YMD
				AND QLTY_VEHL_CD = P_VEHL_CD
				AND MDL_MDY_CD = V_CURR_MDL_MDY_CD
				AND LANG_CD = P_LANG_CD
				AND NVL(PRDN_PLNT_CD,'N') = P_PRDN_PLNT_CD;
				
				-- 2주생산계획 수량 - (현재의 안전재고 수량 + PDI 안전재고 수량)    
				V_SFTY_IV_DIFF_QTY := V_CURR_WEK2_PLAN_QTY - (V_CURR_SFTY_IV_QTY + V_CURR_PDI_IV_QTY);
				
				--2주 생산계획과 안전재고의 차이가 0 보다 큰 경우에만 계산 작업을 진행한다.
				--(왜냐하면 사전에 초기화 한 상태에서 진행하므로 순수하게 현재 연식에 관계된 것만 있으므로 0 보다 작으면 
				-- 재고가 충분하다는 것이므로 작업할 필요가 없다.) 
				IF V_SFTY_IV_DIFF_QTY > 0 THEN
				   
				   --재계산할 재고수량이 존재하는 경우에만 재계산 작업을 수행한다. 
				   IF V_CURR_IV_QTY > 0 THEN
				   	  
					  --재계산할 연식이 취급설명서 연식보다 이전 연식이라면
					  --재계산 작업을 수행한다.  
					  IF V_CURR_MDL_MDY_CD <= P_EXPD_MDL_MDY_CD THEN
				   
				   	  	 IF V_SFTY_IV_DIFF_QTY >= V_CURR_IV_QTY THEN
				   	  
					  	 	V_SFTY_IV_DIFF := V_CURR_IV_QTY;
					  	 	V_CURR_IV_QTY  := 0;

				   	  	 ELSE
				      
					  	 	V_SFTY_IV_DIFF := V_SFTY_IV_DIFF_QTY;
					  	 	V_CURR_IV_QTY  := V_CURR_IV_QTY - V_SFTY_IV_DIFF_QTY;
					  
				         END IF;
					  	 
						 V_FLAG := 'Y';
						 
					  --재계산할 연식이 취급설명서 연식보다 최근 연식이라면 
					  --이전연식의 2주생산계획 수량보다 재고수량이 큰 경우에만 작업해 주도록 한다. 
				   	  ELSE
					  	  
						  SELECT NVL(SUM(SFTY_IV_QTY), 0)
						  INTO V_TEMP_IV_QTY
						  FROM TB_SEWHA_IV_INFO_DTL
						  WHERE CLS_YMD = P_CLS_YMD
						  AND QLTY_VEHL_CD = P_VEHL_CD
						  AND MDL_MDY_CD = P_EXPD_MDL_MDY_CD
						  AND LANG_CD = P_LANG_CD
						  AND NVL(PRDN_PLNT_CD,'N') = DECODE(P_PRDN_PLNT_CD,'7','7','6','7',P_PRDN_PLNT_CD);
						  
						  V_TEMP_IV_QTY := (V_TEMP_IV_QTY + V_DL_PDI_IV_QTY) - V_DL_WEK2_PLAN_QTY;
						  
						  IF V_TEMP_IV_QTY > 0 THEN
						  	 
							 IF V_CURR_IV_QTY < V_TEMP_IV_QTY THEN
							 	
								V_TEMP_IV_QTY := V_CURR_IV_QTY;
								
							 END IF;
							 
							 IF V_SFTY_IV_DIFF_QTY >= V_TEMP_IV_QTY THEN
				   	  
					  	  	 	V_SFTY_IV_DIFF := V_TEMP_IV_QTY;
					  	 	 	V_CURR_IV_QTY  := V_CURR_IV_QTY - V_TEMP_IV_QTY;

				   	  	     ELSE
				      
					  	 	 	V_SFTY_IV_DIFF := V_SFTY_IV_DIFF_QTY;
					  	 	 	V_CURR_IV_QTY  := V_CURR_IV_QTY - V_SFTY_IV_DIFF_QTY;
					  
				             END IF;
							 
							 V_FLAG := 'Y';
						  
						  ELSE
						  	  
							  V_FLAG         := 'N';
							  V_SFTY_IV_DIFF := 0;
					   		  
					   
						  END IF;

					  END IF; --이전연식여부 비교 End 
				   
				   ELSE
				   	   
					   V_FLAG         := 'N';
					   V_SFTY_IV_DIFF := 0;
					   
					   
				   END IF; --재계산할 재고수량 존재여부 확인 End 
				   
				ELSE
					
					V_FLAG         := 'N';
					V_SFTY_IV_DIFF := 0;
					
				END IF; --2주생산 계획 수량 존재여부 확인 End 
				
				--재고 재계산에 의하여 취급설명서 연식의 안전재고 수량이 변경된 경우 
				IF V_FLAG = 'Y' THEN
				   
				   --차종연식과 취급설명서연식이 같은 항목에 
				   --재고 상세 재계산 후 남은 수량을 업데이트 해 준다. 
				   UPDATE TB_SEWHA_IV_INFO_DTL
				   SET SFTY_IV_QTY        = V_CURR_IV_QTY,
					   UPDR_EENO          = P_USER_EENO,
					   MDFY_DTM           = SYSDATE
				   WHERE CLS_YMD          = P_CLS_YMD
				   AND QLTY_VEHL_CD       = P_VEHL_CD
				   AND MDL_MDY_CD         = P_EXPD_MDL_MDY_CD
				   AND LANG_CD            = P_LANG_CD
				   AND DL_EXPD_MDL_MDY_CD = P_EXPD_MDL_MDY_CD
				   AND N_PRNT_PBCN_NO     = P_N_PRNT_PBCN_NO
				   AND NVL(PRDN_PLNT_CD,'N') = DECODE(P_PRDN_PLNT_CD,'7','7','6','7',P_PRDN_PLNT_CD);
					  
				END IF;
				
				UPDATE TB_SEWHA_IV_INFO_DTL
				SET IV_QTY             = V_DL_IV_QTY,
				    SFTY_IV_QTY        = V_SFTY_IV_DIFF,
					DL_EXPD_TMP_IV_QTY = V_DL_EXPD_TMP_IV_QTY,
					CMPL_YN            = V_DL_CMPL_YN,
					UPDR_EENO          = P_USER_EENO,
					MDFY_DTM           = SYSDATE,
					TMP_TRTM_YN        = V_DL_TMP_TRTM_YN
				WHERE CLS_YMD          = P_CLS_YMD
				AND QLTY_VEHL_CD       = P_VEHL_CD
				AND MDL_MDY_CD         = V_CURR_MDL_MDY_CD
				AND LANG_CD            = P_LANG_CD
				AND DL_EXPD_MDL_MDY_CD = P_EXPD_MDL_MDY_CD
				AND N_PRNT_PBCN_NO     = P_N_PRNT_PBCN_NO
				AND NVL(PRDN_PLNT_CD,'N') = DECODE(P_PRDN_PLNT_CD,'7','7','6','7',P_PRDN_PLNT_CD);
				
				IF SQL%NOTFOUND THEN
				   
				   INSERT INTO TB_SEWHA_IV_INFO_DTL
				   (CLS_YMD,
				    QLTY_VEHL_CD,
					MDL_MDY_CD,
					LANG_CD,
					DL_EXPD_MDL_MDY_CD,
					N_PRNT_PBCN_NO,
					IV_QTY,
					SFTY_IV_QTY,
					DL_EXPD_TMP_IV_QTY,
					CMPL_YN,
					PPRR_EENO,
					FRAM_DTM,
					UPDR_EENO,
					MDFY_DTM,
					TMP_TRTM_YN
					, PRDN_PLNT_CD
				   )
				   VALUES
				   (P_CLS_YMD,
				    P_VEHL_CD,
					V_CURR_MDL_MDY_CD,
					P_LANG_CD,
					P_EXPD_MDL_MDY_CD,
					P_N_PRNT_PBCN_NO,
					V_DL_IV_QTY,
					V_SFTY_IV_DIFF,
					V_DL_EXPD_TMP_IV_QTY,
					V_DL_CMPL_YN,
					P_USER_EENO,
					SYSDATE,
					P_USER_EENO,
					SYSDATE,
					V_DL_TMP_TRTM_YN
					, DECODE(P_PRDN_PLNT_CD,'7','7','6','7',P_PRDN_PLNT_CD)
				   );
				   	
				END IF;
				
			END LOOP;
			
	   END SP_RECALCULATE_SEWHA_IV_SUB;
