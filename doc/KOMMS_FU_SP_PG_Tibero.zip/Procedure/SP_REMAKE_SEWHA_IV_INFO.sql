CREATE OR REPLACE PROCEDURE KOMMS_ADM.SP_REMAKE_SEWHA_IV_INFO(P_DATA_SN_LIST VARCHAR2,
			  					         P_CURR_YMD     VARCHAR2,
								         P_SYST_YMD	    VARCHAR2,
										 P_USER_EENO    VARCHAR2)
	   IS
	   	 
		 V_CNT       NUMBER;
		  
		 V_DATA_SN_LIST PG_COMMON.LIST_TYPE;
		  
		 V_DATA_SN_CNT  BINARY_INTEGER;
		 
		 V_QLTY_VEHL_CD VARCHAR2(4);
		 V_MDL_MDY_CD	VARCHAR2(4);
		 V_LANG_CD		VARCHAR2(4);
		 
--		 V_CLS_YMD		      VARCHAR2(8);
		 V_DL_EXPD_MDL_MDY_CD VARCHAR2(2);
		 V_N_PRNT_PBCN_NO	  VARCHAR2(100);
		 
		 V_DL_EXPD_REGN_CD	  VARCHAR2(4);
		 
	   BEGIN
	   		
			/** 
			--작성일이 현재일자가 아니면 생성해 주지 않는다. 
			IF P_CURR_YMD <> P_SYST_YMD THEN 
			   
			   RETURN;
			   
			END IF;
			**/ 
			
			V_DATA_SN_LIST := PG_COMMON.FU_SPLIT(P_DATA_SN_LIST, V_DATA_SN_CNT);
			
			--체크리스트 상세정보에서 현재 차종에 발간번호가 설정되지 않은 항목을 삭제한다. 
		  	FOR DATA_SN_NUM IN 1..V_DATA_SN_CNT LOOP
		    	
				SELECT QLTY_VEHL_CD,
					   MDL_MDY_CD,
					   LANG_CD,
					   DL_EXPD_REGN_CD
				INTO V_QLTY_VEHL_CD,
				     V_MDL_MDY_CD,
					 V_LANG_CD,
					 V_DL_EXPD_REGN_CD
				FROM TB_LANG_MGMT
				WHERE DATA_SN = TO_NUMBER(V_DATA_SN_LIST(DATA_SN_NUM));
				
				/*** [변경] TB_SEWHA_IV_INFO 테이블이 아니라 TB_SEWHA_IV_INFO_DTL 테이블에서 조회하는 것으로 변경 
				            왜냐하면 이곳에서는 즉시 재고 재계산 작업이 이루어지지 않기 때문에 TB_SEWHA_IV_INFO_DTL 테이블에 
							직접 써주어야 하기 때문이다. 
				 
				SELECT COUNT(*)
				INTO V_CNT
				FROM TB_SEWHA_IV_INFO A,
				     TB_DL_EXPD_MDY_MGMT B 
				WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD 
				AND A.DL_EXPD_MDL_MDY_CD = B.DL_EXPD_MDL_MDY_CD 
				AND A.CLS_YMD = P_CURR_YMD
				--인쇄중인 항목은 제외하고.... 납품되었던 항목만을 조회한다. 
				AND A.DL_EXPD_TMP_IV_QTY = 0 
				AND B.QLTY_VEHL_CD = V_QLTY_VEHL_CD 
				AND B.MDL_MDY_CD = V_MDL_MDY_CD 
--[수정예정] 나중에 주석 제거해 줄 것				
				--AND B.DL_EXPD_REGN_CD = V_DL_EXPD_REGN_CD 
				AND A.LANG_CD = V_LANG_CD; 
				***/
				
				SELECT COUNT(*)
				INTO V_CNT
				FROM TB_SEWHA_IV_INFO_DTL
				WHERE CLS_YMD = P_CURR_YMD
				AND QLTY_VEHL_CD = V_QLTY_VEHL_CD
				AND MDL_MDY_CD = V_MDL_MDY_CD 
				AND LANG_CD = V_LANG_CD
				--인쇄중인 항목은 제외하고.... 납품되었던 항목만을 조회한다. 
				AND DL_EXPD_TMP_IV_QTY = 0;
				
				IF V_CNT = 0 THEN
 
				   --현재는 무조건 가장 최근(큰) 연식을 가져오도록 처리함 
				   --(필요에 따라 현재의 차종연식과 같은 연식이 있으면 그것을 가져오도록 변경할 여지도 있을듯함) 
				   SELECT MAX(A.DL_EXPD_MDL_MDY_CD)
				   INTO V_DL_EXPD_MDL_MDY_CD
				   FROM TB_SEWHA_IV_INFO A,
				        TB_DL_EXPD_MDY_MGMT B
				   WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
				   AND A.DL_EXPD_MDL_MDY_CD = B.DL_EXPD_MDL_MDY_CD
				   AND A.CLS_YMD <= P_CURR_YMD
				   --인쇄중인 항목은 제외하고.... 납품되었던 항목만을 조회한다. 
				   AND A.DL_EXPD_TMP_IV_QTY = 0
				   AND B.QLTY_VEHL_CD = V_QLTY_VEHL_CD
				   AND B.MDL_MDY_CD = V_MDL_MDY_CD				   
				   AND B.DL_EXPD_REGN_CD = V_DL_EXPD_REGN_CD 
				   AND A.LANG_CD = V_LANG_CD;
				   
				   IF V_DL_EXPD_MDL_MDY_CD IS NOT NULL THEN
				   	  
					  SELECT MAX(N_PRNT_PBCN_NO)
				   	  INTO V_N_PRNT_PBCN_NO
				   	  FROM TB_SEWHA_IV_INFO
					  WHERE QLTY_VEHL_CD = V_QLTY_VEHL_CD
					  AND DL_EXPD_MDL_MDY_CD = V_DL_EXPD_MDL_MDY_CD
					  AND LANG_CD = V_LANG_CD
					  AND CLS_YMD <= P_CURR_YMD
					  --인쇄중인 항목은 제외하고.... 납품되었던 항목만을 조회한다. 
				   	  AND DL_EXPD_TMP_IV_QTY = 0;
					  
					  IF V_N_PRNT_PBCN_NO IS NOT NULL THEN
						  
						  SELECT COUNT(*)
						  INTO V_CNT
						  FROM TB_SEWHA_IV_INFO
						  WHERE CLS_YMD = P_CURR_YMD
						  AND QLTY_VEHL_CD = V_QLTY_VEHL_CD
						  AND DL_EXPD_MDL_MDY_CD = V_DL_EXPD_MDL_MDY_CD
						  AND LANG_CD = V_LANG_CD
						  AND N_PRNT_PBCN_NO = V_N_PRNT_PBCN_NO;
						  
						  IF V_CNT = 0 THEN
						  	 
							 INSERT INTO TB_SEWHA_IV_INFO
						     (CLS_YMD,
						   	  QLTY_VEHL_CD,
						   	  DL_EXPD_MDL_MDY_CD,
						   	  LANG_CD,
						      N_PRNT_PBCN_NO,
						   	  IV_QTY,
						   	  DL_EXPD_TMP_IV_QTY,
						   	  CMPL_YN,
						   	  PPRR_EENO,
						   	  FRAM_DTM,
						   	  UPDR_EENO,
						   	  MDFY_DTM,
						   	  TMP_TRTM_YN
						     )
						  	 VALUES
							 (P_CURR_YMD,
							  V_QLTY_VEHL_CD,
							  V_DL_EXPD_MDL_MDY_CD,
							  V_LANG_CD,
							  V_N_PRNT_PBCN_NO,
							  0,
							  0,
							  CASE WHEN P_CURR_YMD = P_SYST_YMD THEN 'N' ELSE 'Y' END,
							  P_USER_EENO,
							  SYSDATE,
							  P_USER_EENO,
							  SYSDATE,
							  --임시 생성하는 데이터란 정보를 표시하여 준다. 
							  'Y'
							 );
							 
						  END IF;
						  
						  --재고상세 내역에도 데이터를 추가해 준다. 
						  --(재고보정작업이 자동으로 이루어지지 않기 때문에 재고상세 내역에도 데이터를 추가해 주는 것이다.) 

						  SELECT COUNT(*)
						  INTO V_CNT
						  FROM TB_SEWHA_IV_INFO_DTL
						  WHERE CLS_YMD = P_CURR_YMD
						  AND QLTY_VEHL_CD = V_QLTY_VEHL_CD
						  AND MDL_MDY_CD = V_MDL_MDY_CD
						  AND LANG_CD = V_LANG_CD
						  AND DL_EXPD_MDL_MDY_CD = V_DL_EXPD_MDL_MDY_CD
						  AND N_PRNT_PBCN_NO = V_N_PRNT_PBCN_NO;
						  
						  IF V_CNT = 0 THEN
						  	 
							 INSERT INTO TB_SEWHA_IV_INFO_DTL
							 (CLS_YMD,
							  QLTY_VEHL_CD,
							  MDL_MDY_CD,
							  LANG_CD,
							  DL_EXPD_MDL_MDY_CD,
							  N_PRNT_PBCN_NO,
							  IV_QTY,
							  SFTY_IV_QTY,
							  DL_EXPD_TMP_IV_QTY,
							  CMPL_YN,
							  PPRR_EENO,
							  FRAM_DTM,
							  UPDR_EENO,
							  MDFY_DTM,
							  TMP_TRTM_YN
							 )
							 VALUES
							 (P_CURR_YMD,
							  V_QLTY_VEHL_CD,
							  V_MDL_MDY_CD,
							  V_LANG_CD,
							  V_DL_EXPD_MDL_MDY_CD,
							  V_N_PRNT_PBCN_NO,
							  0,
							  0,
							  0,
							  CASE WHEN P_CURR_YMD = P_SYST_YMD THEN 'N' ELSE 'Y' END,
							  P_USER_EENO,
							  SYSDATE,
							  P_USER_EENO,
							  SYSDATE,
							  --임시 생성하는 데이터란 정보를 표시하여 준다. 
							  'Y'
							 );
							 
						  END IF;
						  
					   END IF;
 
				   END IF;

				END IF;

			END LOOP;
			
	   END SP_REMAKE_SEWHA_IV_INFO;