CREATE OR REPLACE PACKAGE KOMMS_ADM.PG_TOT_IV_INFO AS

   TYPE REFCUR IS REF CURSOR;

   EXPD_CO_CD_HMC  CONSTANT VARCHAR2(4) := PG_DATA.EXPD_CO_CD_HMC;  -- HMC
   EXPD_CO_CD_KMC  CONSTANT VARCHAR2(4) := PG_DATA.EXPD_CO_CD_KMC;  -- KMC

   HMC_CLOSE_TIME  CONSTANT VARCHAR2(4) := PG_DATA.HMC_CLOSE_TIME;  -- 현재 I/F 마감기준시간
   KMC_CLOSE_TIME  CONSTANT VARCHAR2(4) := PG_DATA.KMC_CLOSE_TIME;  -- 기아 I/F 마감기준시간

   --별도요청 정보 저장
   PROCEDURE SP_EXTRA_REQ_SAVE(P_VEHL_CD        VARCHAR2,
	   			 			   P_MDL_MDY_CD     VARCHAR2,
							   P_LANG_CD        VARCHAR2,
							   P_EXPD_RQ_SCN_CD VARCHAR2,
							   P_CRGR_EENO      VARCHAR2,
							   P_RQ_QTY		    NUMBER,
							   P_PWMR_EENO      VARCHAR2,
							   P_RQ_RSON_SBC    VARCHAR2,
							   P_USER_EENO      VARCHAR2
							   , P_PRDN_PLNT_CD VARCHAR2);

   PROCEDURE SP_EXTRA_REQ_SAVE2(P_VEHL_CD        VARCHAR2,
	   			 			    P_MDL_MDY_CD     VARCHAR2,
							    P_LANG_CD        VARCHAR2,
							    P_EXPD_RQ_SCN_CD VARCHAR2,
							    P_CRGR_EENO      VARCHAR2,
							    P_RQ_QTY		 NUMBER,
							    P_PWMR_EENO      VARCHAR2,
							    P_RQ_RSON_SBC    VARCHAR2,
							    P_USER_EENO      VARCHAR2
							    , P_PRDN_PLNT_CD VARCHAR2);

   --별도요청 출고 정보 저장
   PROCEDURE SP_EXTRA_REQ_UPDATE(P_VEHL_CD         VARCHAR2,
	   			 			     P_MDL_MDY_CD      VARCHAR2,
							     P_LANG_CD         VARCHAR2,
								 P_N_PRNT_PBCN_NO  VARCHAR2,
								 P_EXPD_RQ_SCN_CD  VARCHAR2,
								 P_RQ_QTY          NUMBER,
								 P_PREV_RQ_QTY	   NUMBER,
								 P_USER_EENO       VARCHAR2
								 , P_PRDN_PLNT_CD VARCHAR2);

   --총재고 조회(PDI, 차종, 연식, 지역, 언어)
   PROCEDURE SP_GET_TOT_IV_INFO(P_MENU_ID 	   VARCHAR2,
								P_USER_EENO    VARCHAR2,
								P_CURR_YMD	   VARCHAR2,
								P_EXPD_CO_CD   VARCHAR2,
 								P_PDI_CD	   VARCHAR2,
								P_VEHL_CD	   VARCHAR2,
								P_MDL_MDY	   VARCHAR2,
								P_REGN_CD	   VARCHAR2,
								P_LANG_CD	   VARCHAR2,
								P_IV_STATE     VARCHAR2,
                                RS 			   OUT REFCUR,
                                P_MESSAGE      OUT VARCHAR2);

   --총재고 조회(승상구분, PDI, 차종, 연식, 지역, 언어)
   PROCEDURE SP_GET_TOT_IV_INFO2(P_MENU_ID 	    VARCHAR2,
								 P_USER_EENO 	VARCHAR2,
								 P_CURR_YMD	    VARCHAR2,
								 P_EXPD_CO_CD   VARCHAR2,
								 P_PAC_SCN_CD	VARCHAR2,
 								 P_PDI_CD		VARCHAR2,
								 P_VEHL_CD	    VARCHAR2,
								 P_MDL_MDY	    VARCHAR2,
								 P_REGN_CD	    VARCHAR2,
								 P_LANG_CD	    VARCHAR2,
								 P_IV_STATE     VARCHAR2,
                                 RS 		  OUT REFCUR
                                 );

   --월간 오더 정보 조회
   PROCEDURE SP_GET_MTH_ODR_INFO(P_CURR_YMD VARCHAR2,
   			 					 P_VEHL_CD	VARCHAR2,
								 P_MDL_MDY	VARCHAR2,
								 P_REGN_CD	VARCHAR2,
								 P_LANG_CD  VARCHAR2,
								 P_FROM_MTH VARCHAR2,
								 P_TO_MTH	VARCHAR2,
                                 RS         OUT REFCUR,
                                 P_MESSAGE  OUT VARCHAR2);

   --월간 생산 정보 조회
   PROCEDURE SP_GET_PROD_MST_INFO(P_VEHL_CD	 VARCHAR2,
								  P_MDL_MDY	 VARCHAR2,
								  P_REGN_CD	 VARCHAR2,
								  P_LANG_CD  VARCHAR2,
								  P_FROM_MTH VARCHAR2,
								  P_TO_MTH	 VARCHAR2,
                                  RS         OUT REFCUR,
                                  P_MESSAGE  OUT VARCHAR2);
   --월간 오더,생산 정보 조회
   PROCEDURE SP_GET_ODR_PROD_INFO(P_CURR_YMD VARCHAR2,
   			 					  P_VEHL_CD	 VARCHAR2,
								  P_MDL_MDY	 VARCHAR2,
								  P_REGN_CD	 VARCHAR2,
								  P_LANG_CD  VARCHAR2,
								  P_FROM_MTH VARCHAR2,
								  P_TO_MTH	 VARCHAR2,
                                  RS         OUT REFCUR,
                                  P_MESSAGE  OUT VARCHAR2);

   --조회기간에 따란 Dynamic Query 생성 함수
   FUNCTION FU_GET_MTH_PACK_QRY(P_FROM_MTH VARCHAR2,
								P_TO_MTH   VARCHAR2) RETURN VARCHAR2;

   --언어별 차종 재고 내역 조회
   PROCEDURE SP_GET_IV_BY_LANG(P_VEHL_CD  VARCHAR2,
							   P_MDL_MDY  VARCHAR2,
							   P_REGN_CD  VARCHAR2,
							   P_LANG_CD  VARCHAR2,
							   P_FROM_YMD VARCHAR2,
							   P_TO_YMD	  VARCHAR2,
                               RS         OUT REFCUR);

  --날짜별 차종 재고 내역 조회
  PROCEDURE SP_GET_IV_BY_YMD(P_VEHL_CD  VARCHAR2,
							 P_MDL_MDY  VARCHAR2,
							 P_REGN_CD  VARCHAR2,
							 P_LANG_CD  VARCHAR2,
							 P_FROM_YMD VARCHAR2,
							 P_TO_YMD	VARCHAR2,
							 --P_FROM_NUM NUMBER,
							 --P_TO_NUM   NUMBER,
							 --P_CNT OUT NUMBER,
                             RS    OUT REFCUR);


  --주간계획(2주) 데이터 조회
  PROCEDURE SP_GET_2WEK_PLAN_INFO(P_DATA_SN  NUMBER,
   			 					  P_CURR_YMD VARCHAR2,
								  RS        OUT REFCUR,
                                  P_MESSAGE OUT VARCHAR2);

  PROCEDURE SP_GET_2WEK_PLAN_INFO2(P_DATA_SN      NUMBER,
   			 					   P_CURR_YMD     VARCHAR2,
								   P_PRDN_PLNT_CD VARCHAR2,
								   RS             OUT REFCUR,
                                   P_MESSAGE      OUT VARCHAR2);

  --주간계획(2주) 화면 내의 Summary 내역 조회
  PROCEDURE SP_GET_TOT_ODR_INFO(P_DATA_SN  NUMBER,
   			 					P_CURR_YMD VARCHAR2,
								RS OUT REFCUR);

  --단기계획(3일) 데이터 조회
  PROCEDURE SP_GET_3DAY_PLAN_INFO(P_DATA_SN  NUMBER,
   			 					  P_CURR_YMD VARCHAR2,
								  RS OUT REFCUR ,
								  P_PLAN_TOT_QTY OUT NUMBER,
								  P_MESSAGE		 OUT VARCHAR2
								  );

  PROCEDURE SP_GET_3DAY_PLAN_INFO2(P_DATA_SN      NUMBER,
   			 					   P_CURR_YMD     VARCHAR2,
								   P_PRDN_PLNT_CD VARCHAR2,
								   RS             OUT REFCUR ,
								   P_PLAN_TOT_QTY OUT NUMBER,
								   P_MESSAGE	  OUT VARCHAR2
								  );

  --9공정 ~ 투입전 공정 사이의 최소 시각 얻어오기
  FUNCTION FU_GET_MIN_YMDHM(P_PAC_SCN_CD          VARCHAR2,
  		   					P_PDI_CD	          VARCHAR2,
							P_LANG_CD			  VARCHAR2,
							P_TH9_POW_STRT_YMDHM  VARCHAR2,
							P_TH10_POW_STRT_YMDHM VARCHAR2,
							P_TH11_POW_STRT_YMDHM VARCHAR2,
							P_TH12_POW_STRT_YMDHM VARCHAR2,
							P_TH13_POW_STRT_YMDHM VARCHAR2,
							P_TH14_POW_STRT_YMDHM VARCHAR2,
							P_TH15_POW_STRT_YMDHM VARCHAR2,
							P_TH16_POW_STRT_YMDHM VARCHAR2) RETURN VARCHAR2;

  --9공정 ~ 투입전 공정 사이의 최대 시각 얻어오기
  FUNCTION FU_GET_MAX_YMDHM(P_PAC_SCN_CD          VARCHAR2,
  		   					P_PDI_CD	          VARCHAR2,
							P_LANG_CD			  VARCHAR2,
							P_TH9_POW_FNH_YMDHM   VARCHAR2,
							P_TH10_POW_FNH_YMDHM  VARCHAR2,
							P_TH11_POW_FNH_YMDHM  VARCHAR2,
							P_TH12_POW_FNH_YMDHM  VARCHAR2,
							P_TH13_POW_FNH_YMDHM  VARCHAR2,
							P_TH14_POW_FNH_YMDHM  VARCHAR2,
							P_TH15_POW_FNH_YMDHM  VARCHAR2,
							P_TH16_POW_FNH_YMDHM  VARCHAR2) RETURN VARCHAR2;

  --PPMS에서 넘어온 시간값이 적절한지의 여부를 확인
  FUNCTION FU_GET_VALID_YMDHM(P_YMDHM VARCHAR2) RETURN VARCHAR2;

  --당월투입현황 조회
  PROCEDURE SP_GET_1MTH_TRWI_INFO(P_VEHL_CD  VARCHAR2,
							      P_MDL_MDY  VARCHAR2,
								  P_LANG_CD  VARCHAR2,
								  P_CURR_YMD VARCHAR2,
								  RS         OUT REFCUR,
                                  P_MESSAGE  OUT VARCHAR2);
  --세화재고현황 조회
  PROCEDURE SP_GET_SEWHA_IV_INFO(P_VEHL_CD  VARCHAR2,
							     P_MDL_MDY  VARCHAR2,
								 P_LANG_CD  VARCHAR2,
								 P_CURR_YMD VARCHAR2,
								 RS OUT REFCUR);

  --당월 PDI 재고현황 조회
  PROCEDURE SP_GET_1MTH_PDI_INFO(P_VEHL_CD  VARCHAR2,
							     P_MDL_MDY  VARCHAR2,
								 P_LANG_CD  VARCHAR2,
								 P_CURR_YMD VARCHAR2,
								 RS OUT REFCUR);

  --당월 PDI 재고현황 조회
  PROCEDURE SP_GET_1MTH_PDI_INFO2(P_VEHL_CD  VARCHAR2,
							     P_MDL_MDY  VARCHAR2,
								 P_LANG_CD  VARCHAR2,
								 P_CURR_YMD VARCHAR2,
								 RS OUT REFCUR);

  --메일 발송 작업 수행
  PROCEDURE SP_SEND_MAIL(P_VEHL_CD        VARCHAR2,
	   			 		 P_MDL_MDY_CD     VARCHAR2,
						 P_BLNS_CO_CD     VARCHAR2,
						 P_USER_EENO      VARCHAR2,
						 P_MAIL_TITLE	  VARCHAR2,
						 P_MAIL_CONTENT   VARCHAR2);

  --인터페이스 메세지 정보 조회(DATA_SN을 이용하여 생산계획 과 생산마스터 인터페이스 시간정보를 조회함)
  PROCEDURE SP_GET_MSG_PLAN_PROD(P_DATA_SN  NUMBER,
   			 				     P_CURR_YMD VARCHAR2,
							     P_SCH_YMD  OUT VARCHAR2,
							     P_MESSAGE  OUT VARCHAR2);

  PROCEDURE SP_GET_MSG_PROD2(P_DATA_SN  NUMBER,
   			 				 P_CURR_YMD VARCHAR2,
							 P_SCH_YMD  OUT VARCHAR2,
							 P_MESSAGE  OUT VARCHAR2);

  --인터페이스 메세지 정보 조회(차종과 연식을 이용하여 오더계획 인터페이스 시간정보를 조회함)
  PROCEDURE SP_GET_MSG_ODR(P_VEHL_CD  VARCHAR2,
						   P_MDL_MDY  VARCHAR2,
   			 			   P_CURR_YMD VARCHAR2,
						   P_SCH_YMD  OUT VARCHAR2,
 						   P_MESSAGE  OUT VARCHAR2);

  --인터페이스 메세지 정보 조회(차종과 연식을 이용하여 생산마스터 인터페이스 시간정보를 조회함)
  PROCEDURE SP_GET_MSG_PROD(P_VEHL_CD  VARCHAR2,
						    P_MDL_MDY  VARCHAR2,
   			 			    P_CURR_YMD VARCHAR2,
							P_SCH_YMD  OUT VARCHAR2,
 						    P_MESSAGE  OUT VARCHAR2);

  /**  현재 사용 안함
  --인터페이스 메세지 정보 조회(차종과 연식을 이용하여 오더계획 과 생산마스터 인터페이스 시간정보를 조회함)
  PROCEDURE SP_GET_MSG_ODR_PROD(P_VEHL_CD  VARCHAR2,
						        P_MDL_MDY  VARCHAR2,
   			 			        P_CURR_YMD VARCHAR2,
						        P_SCH_YMD  OUT VARCHAR2,
 						        P_MESSAGE  OUT VARCHAR2);
  **/

  /**   현재 사용 안함
  --인터페이스 메세지 정보 조회(DATA_SN을 이용하여 오더계획과 생산계획 인터페이스 시간정보를 조회함)
  PROCEDURE SP_GET_MSG_ODR_PLAN(P_DATA_SN  NUMBER,
   			 				    P_CURR_YMD VARCHAR2,
							    P_SCH_YMD1 OUT VARCHAR2,
								P_SCH_YMD2 OUT VARCHAR2,
							    P_MESSAGE  OUT VARCHAR2);
  **/

  PROCEDURE SP_GET_MESSAGE(P_CURR_YMD VARCHAR2,
  						   P_MESSAGE  OUT VARCHAR2);

  --마감일자에 마감시간을 더해서 한글 형태로 변경하여 리턴
  FUNCTION FU_TO_CLOSE_DATE_CHAR(P_CURR_YMD VARCHAR2,
  		   						 P_EXPD_CO_CD VARCHAR2) RETURN VARCHAR2;

  --세원 차종연식에 소속된 취급설명서 연식의 재고수량을 이전연식부터 문자형태로 표현해서 리턴하는 함수
  FUNCTION FU_GET_SEWHA_IV_TEXT(P_CURR_YMD   VARCHAR2,
  		   						P_VEHL_CD    VARCHAR2,
								P_MDL_MDY_CD VARCHAR2,
								P_LANG_CD	 VARCHAR2) RETURN VARCHAR2;

  --PDI 차종연식에 소속된 취급설명서 연식의 재고수량을 이전연식부터 문자형태로 표현해서 리턴하는 함수
  FUNCTION FU_GET_PDI_IV_TEXT(P_CURR_YMD   VARCHAR2,
  		   					  P_VEHL_CD    VARCHAR2,
							  P_MDL_MDY_CD VARCHAR2,
							  P_LANG_CD	   VARCHAR2) RETURN VARCHAR2;

  --[추가].2010.04.20.김동근 공장별 2주생산계획을 문자형태로 리턴
  FUNCTION FU_GET_PLNT_WEK2_PLAN_QTY(P_CURR_YMD   VARCHAR2,
  		   					         P_VEHL_CD    VARCHAR2,
							         P_MDL_MDY_CD VARCHAR2,
							         P_LANG_CD	   VARCHAR2) RETURN VARCHAR2;

  --[추가].2010.04.20.김동근 공장별 3일생산계획을 문자형태로 리턴
  FUNCTION FU_GET_PLNT_DAY3_PLAN_QTY(P_CURR_YMD   VARCHAR2,
  		   					         P_VEHL_CD    VARCHAR2,
							         P_MDL_MDY_CD VARCHAR2,
							         P_LANG_CD	   VARCHAR2) RETURN VARCHAR2;

END PG_TOT_IV_INFO;