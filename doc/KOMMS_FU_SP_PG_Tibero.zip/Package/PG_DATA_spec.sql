CREATE OR REPLACE PACKAGE KOMMS_ADM.PG_DATA AS

    TYPE REFCUR IS REF CURSOR;

	EXPD_CO_CD_HMC  CONSTANT VARCHAR2(4) := '01';    -- HMC
	EXPD_CO_CD_KMC  CONSTANT VARCHAR2(4) := '02';    -- KMC
	EXPD_DOM_NAT_CD CONSTANT VARCHAR2(5) := 'A99VA'; -- 내수 국가코드
	BTCH_USER_EENO  CONSTANT VARCHAR2(7) := '9266842'; -- 배치작업 담당자 코드

	HMC_CLOSE_TIME  CONSTANT VARCHAR2(4) := '0600';  -- 현재 I/F 마감기준시간
	KMC_CLOSE_TIME  CONSTANT VARCHAR2(4) := '0530';	 -- 기아 I/F 마감기준시간

/**********************************************************/
	--생산 마스터 배치 작업 시 생산 수량에 따른 재고 보정 작업 처리
   	PROCEDURE SP_PROD_MST_PDI_IV_UPDATE(P_VEHL_CD    VARCHAR2,
	   			 			   		    P_MDL_MDY_CD VARCHAR2,
							   			P_LANG_CD    VARCHAR2,
							   			P_CLS_YMD	 VARCHAR2,
										P_TRWI_QTY	 NUMBER,
										P_USER_EENO	 VARCHAR2
										, P_PRDN_PLNT_CD VARCHAR2 -- 광주분리
										);

	--원래의 출고수량보다 투입수량이 많아진 경우 호출
	PROCEDURE SP_UPDATE_PDI_IV_INFO1(P_QLTY_VEHL_CD IN VARCHAR2,
	   			 				     P_MDL_MDY_CD   IN VARCHAR2,
								     P_LANG_CD      IN VARCHAR2,
								     P_APL_YMD      IN VARCHAR2,
								     P_TRWI_DIFF    IN NUMBER,
									 P_USER_EENO	IN VARCHAR2
									 , P_PRDN_PLNT_CD VARCHAR2 -- 광주분리
									 );

	--원래의 출고수량보다 투입수량이 적어진 경우 호출
	PROCEDURE SP_UPDATE_PDI_IV_INFO2(P_QLTY_VEHL_CD IN VARCHAR2,
	   			 				     P_MDL_MDY_CD   IN VARCHAR2,
								     P_LANG_CD      IN VARCHAR2,
								     P_APL_YMD      IN VARCHAR2,
								     P_TRWI_DIFF    IN NUMBER,
									 P_USER_EENO	IN VARCHAR2
									 , P_PRDN_PLNT_CD VARCHAR2 -- 광주분리
									 );

	--PDI 재고정보 Insert(입고확인)
	PROCEDURE SP_PDI_IV_INFO_SAVE_BY_WHSN(P_CURR_YMD		VARCHAR2,
			  							  P_VEHL_CD         VARCHAR2,
										  P_MDL_MDY_CD      VARCHAR2,
								          P_LANG_CD         VARCHAR2,
										  P_EXPD_MDL_MDY_CD VARCHAR2,
								    	  P_N_PRNT_PBCN_NO  VARCHAR2,
								    	  P_DTL_SN          NUMBER,
								    	  P_EXPD_WHSN_ST_CD VARCHAR2,
								    	  P_EXPD_BOX_QTY    NUMBER,
								    	  P_WHSN_QTY		NUMBER,
								    	  P_DEEI1_QTY		NUMBER,
								    	  P_USER_EENO		VARCHAR2
								    	  , P_PRDN_PLNT_CD VARCHAR2 -- 광주분리
								    	  );

	--PDI 재고 정보 저장
   	PROCEDURE SP_PDI_IV_INFO_UPDATE(P_VEHL_CD         VARCHAR2,
	                                P_MDL_MDY_CD      VARCHAR2,
							        P_LANG_CD         VARCHAR2,
									P_EXPD_MDL_MDY_CD VARCHAR2,
								    P_N_PRNT_PBCN_NO  VARCHAR2,
								    P_CLS_YMD		  VARCHAR2,
								    P_DIFF_WHOT_QTY	  NUMBER,
								    P_BATCH_FLAG	  VARCHAR2, --배치프로그램에서 호출 여부
									P_CASCADE_FLAG	  VARCHAR2, --현재일 이전날짜의 재고보정 허용 여부
								    P_USER_EENO	      VARCHAR2
								    , P_PRDN_PLNT_CD VARCHAR2 -- 광주분리
								    );

	--PDI 재고정보 업데이트 수행(재고전환 기능)
	PROCEDURE SP_PDI_IV_INFO_UPDATE3(P_VEHL_CD         VARCHAR2,
			  						 P_MDL_MDY_CD	   VARCHAR2,
									 P_LANG_CD         VARCHAR2,
									 P_EXPD_MDL_MDY_CD VARCHAR2,
									 P_N_PRNT_PBCN_NO  VARCHAR2,
									 P_CLS_YMD		   VARCHAR2,
									 P_DIFF_RQ_QTY	   NUMBER,
									 P_USER_EENO	   VARCHAR2,
									 P_FLAG			   VARCHAR2
									 , P_PRDN_PLNT_CD VARCHAR2 -- 광주분리
									 );

    --PDI 재고 데이터가 존재하지 않는 경우 가장 최근의 발간번호및 취급설명서 연식코드를 조회
    PROCEDURE SP_GET_PDI_N_PRNT_PBCN_NO(P_VEHL_CD      		 VARCHAR2,
                                        P_MDL_MDY_CD 		 VARCHAR2,
                                        P_LANG_CD    		 VARCHAR2,
                                        P_CLS_YMD	         VARCHAR2,
								        P_DL_EXPD_MDL_MDY_CD OUT VARCHAR2,
								        P_N_PRNT_PBCN_NO     OUT VARCHAR2
								        , P_PRDN_PLNT_CD VARCHAR2 -- 광주분리
								       );
/**********************************************************/

/**********************************************************/

	--이미 재고데이터가 이전 날짜에 소진된 항목에 대해서
	--인자로 주어진 날짜의 재고 데이터를 새로이 생성해 주는 작업 수행
	PROCEDURE SP_REMAKE_SEWHA_IV_INFO(P_DATA_SN_LIST VARCHAR2,
			  					      P_CURR_YMD     VARCHAR2,
								      P_SYST_YMD	 VARCHAR2,
									  P_USER_EENO    VARCHAR2
									  , P_PRDN_PLNT_CD VARCHAR2 -- 광주분리
									  );

	--세화 재고정보 Insert(세화 입고)
	PROCEDURE SP_SEWHA_IV_INFO_SAVE_BY_WHSN(P_WHSN_YMD        VARCHAR2,
			  						        P_QLTY_VEHL_CD    VARCHAR2,
											P_MDL_MDY_CD	  VARCHAR2,
									        P_LANG_CD         VARCHAR2,
											P_EXPD_MDL_MDY_CD VARCHAR2,
									        P_N_PRNT_PBCN_NO  VARCHAR2,
									        P_WHSN_QTY        NUMBER,
									        --P_CRGR_EENO       VARCHAR2,
									        --P_PRNT_PARR_YMD   VARCHAR2,
									        P_DLVG_PARR_YMD   VARCHAR2,
									        P_USER_EENO       VARCHAR2
									        , P_PRDN_PLNT_CD VARCHAR2 -- 광주분리
									        );

	--세화 재고정보 취소 수행(세화 입고)
	PROCEDURE SP_SEWHA_IV_INFO_CANCL_BY_WHSN(P_WHSN_YMD        VARCHAR2,
			  						       	 P_QLTY_VEHL_CD    VARCHAR2,
											 P_MDL_MDY_CD	   VARCHAR2,
									       	 P_LANG_CD         VARCHAR2,
											 P_EXPD_MDL_MDY_CD VARCHAR2,
									       	 P_N_PRNT_PBCN_NO  VARCHAR2,
									       	 --P_WHSN_QTY        NUMBER,
									       	 P_USER_EENO       VARCHAR2
									       	 , P_PRDN_PLNT_CD VARCHAR2 -- 광주분리
									       	 );

	--세화 납품예정일 변경
	PROCEDURE SP_SEWHA_DLVG_PARR_YMD_UPDATE(P_WHSN_YMD        VARCHAR2,
			  								P_VEHL_CD         VARCHAR2,
	   			 					        P_MDL_MDY_CD	  VARCHAR2,
									        P_LANG_CD         VARCHAR2,
											P_EXPD_MDL_MDY_CD VARCHAR2,
									        P_N_PRNT_PBCN_NO  VARCHAR2,
											P_DLVG_PARR_YMD   VARCHAR2,
										    P_USER_EENO       VARCHAR2
										    , P_PRDN_PLNT_CD VARCHAR2 -- 광주분리
										    );

	--세화 재고정보 업데이트 수행
	PROCEDURE SP_SEWHA_IV_INFO_UPDATE(P_VEHL_CD         VARCHAR2,
			  						  P_MDL_MDY_CD	    VARCHAR2,
									  P_LANG_CD         VARCHAR2,
									  P_EXPD_MDL_MDY_CD VARCHAR2,
									  P_N_PRNT_PBCN_NO  VARCHAR2,
									  P_CLS_YMD			VARCHAR2,
									  P_DIFF_RQ_QTY		NUMBER,
									  P_USER_EENO		VARCHAR2,
									  P_FLAG			VARCHAR2
									  , P_PRDN_PLNT_CD VARCHAR2 -- 광주분리
									  );

	--PDI 재고보정(반출, 불량)시에 세화재고 업데이트 작업 수행
	PROCEDURE SP_SEWHA_IV_INFO_UPDATE2(P_VEHL_CD         VARCHAR2,
			  						   P_MDL_MDY_CD	     VARCHAR2,
									   P_LANG_CD         VARCHAR2,
									   P_EXPD_MDL_MDY_CD VARCHAR2,
									   P_N_PRNT_PBCN_NO  VARCHAR2,
									   P_CLS_YMD		 VARCHAR2,
									   P_DIFF_RQ_QTY	 NUMBER,
									   P_CASCADE_FLAG	 VARCHAR2, --현재일 이전날짜의 재고보정 허용 여부
									   P_USER_EENO		 VARCHAR2
									   , P_PRDN_PLNT_CD VARCHAR2 -- 광주분리
									   );

	--세화 재고정보 업데이트 수행(재고전환 기능)
	PROCEDURE SP_SEWHA_IV_INFO_UPDATE3(P_VEHL_CD         VARCHAR2,
			  						   P_MDL_MDY_CD	     VARCHAR2,
									   P_LANG_CD         VARCHAR2,
									   P_EXPD_MDL_MDY_CD VARCHAR2,
									   P_N_PRNT_PBCN_NO  VARCHAR2,
									   P_CLS_YMD		 VARCHAR2,
									   P_DIFF_RQ_QTY	 NUMBER,
									   P_USER_EENO		 VARCHAR2,
									   P_FLAG			 VARCHAR2
									   , P_PRDN_PLNT_CD VARCHAR2 -- 광주분리
									   );
/**********************************************************/

/**********************************************************/
    --입고/출고된 항목에 대한 PDI 재고상세 테이블 업데이트 작업 수행
    PROCEDURE SP_UPDATE_PDI_IV_DTL_INFO(P_VEHL_CD         VARCHAR2,
			  						    P_EXPD_MDL_MDY_CD VARCHAR2,
									    P_LANG_CD         VARCHAR2,
									    P_N_PRNT_PBCN_NO  VARCHAR2,
									    P_CLS_YMD		  VARCHAR2,
										P_USER_EENO	      VARCHAR2
										, P_PRDN_PLNT_CD VARCHAR2 -- 광주분리
										);

	--재고상세 내역 재계산 작업 수행
	PROCEDURE SP_RECALCULATE_PDI_IV_DTL1(P_CLS_YMD	       VARCHAR2,
										 P_VEHL_CD         VARCHAR2,
			  						     P_EXPD_MDL_MDY_CD VARCHAR2,
									     P_LANG_CD         VARCHAR2,
										 P_N_PRNT_PBCN_NO  VARCHAR2,
										 P_USER_EENO       VARCHAR2
										 , P_PRDN_PLNT_CD VARCHAR2 -- 광주분리
										 );

	--재고상세 내역 재계산 작업 수행(배치 프로그램 전용)
	PROCEDURE SP_RECALCULATE_PDI_IV_DTL2(P_CLS_YMD	 VARCHAR2,
										 P_USER_EENO VARCHAR2);

	PROCEDURE SP_RECALCULATE_PDI_IV_DTL3(P_CLS_YMD	 VARCHAR2,
	                                     P_VEHL_CD   VARCHAR2,
										 P_USER_EENO VARCHAR2);

	PROCEDURE SP_RECALCULATE_PDI_IV_DTL4(P_CLS_YMD	 VARCHAR2,
	                                     P_VEHL_CD   VARCHAR2,
										 P_LANG_CD	 VARCHAR2,
										 P_USER_EENO VARCHAR2
										 , P_PRDN_PLNT_CD VARCHAR2 -- 광주분리
										 );

	PROCEDURE SP_RECALCULATE_PDI_IV_SUB(P_CLS_YMD	      VARCHAR2,
										P_VEHL_CD         VARCHAR2,
			  						    P_EXPD_MDL_MDY_CD VARCHAR2,
									    P_LANG_CD         VARCHAR2,
										P_N_PRNT_PBCN_NO  VARCHAR2,
										P_USER_EENO       VARCHAR2
										, P_PRDN_PLNT_CD VARCHAR2 -- 광주분리
										);

	--PDI 재고상세 내역 재계산 작업 수행(외부 호출)
	PROCEDURE GET_PDI_IV_DTL_LIST(FROM_YMD IN VARCHAR2,
	                              TO_YMD   IN VARCHAR2);

/**********************************************************/

/**********************************************************/
    --입고/출고된 항목에 대한 세원 재고상세 테이블 업데이트 작업 수행
    PROCEDURE SP_UPDATE_SEWHA_IV_DTL_INFO(P_VEHL_CD         VARCHAR2,
			  							  P_EXPD_MDL_MDY_CD VARCHAR2,
									      P_LANG_CD         VARCHAR2,
									      P_N_PRNT_PBCN_NO  VARCHAR2,
									      P_CLS_YMD		    VARCHAR2,
										  P_USER_EENO	    VARCHAR2
										  , P_PRDN_PLNT_CD   VARCHAR2 -- 광주분리
										  );

	--재고상세 내역 재계산 작업 수행
	PROCEDURE SP_RECALCULATE_SEWHA_IV_DTL1(P_CLS_YMD	     VARCHAR2,
										   P_VEHL_CD         VARCHAR2,
			  						       P_EXPD_MDL_MDY_CD VARCHAR2,
									       P_LANG_CD         VARCHAR2,
										   P_N_PRNT_PBCN_NO  VARCHAR2,
										   P_USER_EENO       VARCHAR2
										   , P_PRDN_PLNT_CD   VARCHAR2 -- 광주분리
										   );

	--재고상세 내역 재계산 작업 수행(배치 프로그램 전용)
	PROCEDURE SP_RECALCULATE_SEWHA_IV_DTL2(P_CLS_YMD	     VARCHAR2,
										   P_USER_EENO       VARCHAR2);

	PROCEDURE SP_RECALCULATE_SEWHA_IV_DTL3(P_CLS_YMD   VARCHAR2,
	                                       P_VEHL_CD   VARCHAR2,
										   P_USER_EENO VARCHAR2
										   );

	--재고상세 내역 재계산 작업 수행
	PROCEDURE SP_RECALCULATE_SEWHA_IV_DTL4(P_CLS_YMD   VARCHAR2,
										   P_VEHL_CD   VARCHAR2,
			  						       P_LANG_CD   VARCHAR2,
										   P_USER_EENO VARCHAR2
										   , P_PRDN_PLNT_CD   VARCHAR2 -- 광주분리
										   );

	PROCEDURE SP_RECALCULATE_SEWHA_IV_SUB(P_CLS_YMD	        VARCHAR2,
										  P_VEHL_CD         VARCHAR2,
			  						      P_EXPD_MDL_MDY_CD VARCHAR2,
									      P_LANG_CD         VARCHAR2,
										  P_N_PRNT_PBCN_NO  VARCHAR2,
										  P_USER_EENO       VARCHAR2
										  , P_PRDN_PLNT_CD   VARCHAR2 -- 광주분리
										  );

	--세원 재고상세 내역 재계산 작업 수행(외부 호출)
	PROCEDURE GET_SEWHA_IV_DTL_LIST(FROM_YMD IN VARCHAR2,
	                                TO_YMD   IN VARCHAR2);

/**********************************************************/

/**********************************************************/
    --일자변경시에 작업 수행(배치 실행)
	--반드시 현재일 시작시간에 돌려야 한다.
    PROCEDURE OWNERS_DATE_CHANGE_BATCH;

/**********************************************************/

END PG_DATA;