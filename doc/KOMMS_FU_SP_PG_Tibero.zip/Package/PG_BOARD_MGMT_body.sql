CREATE or replace PACKAGE BODY KOMMS_ADM.PG_BOARD_MGMT AS

    
     -- 게시판 조회 
        PROCEDURE SP_BOARD_SEARCH(P_AFFR_SCN_CD CHAR,
                                  P_BLC_TITL_NM VARCHAR2,
                                  RS OUT REFCUR)
        IS
        BEGIN
            
        OPEN RS FOR
            SELECT ROWNUM RN, LIST.*
            FROM
            (
                SELECT
                    *
                FROM TB_BOARD_MGMT BM, 
                     (SELECT USER_NM, USER_EENO FROM TB_USR_MGMT) UM, 
                     (SELECT DL_EXPD_PRVS_NM, DL_EXPD_PRVS_CD FROM TB_CODE_MGMT 
                      WHERE USE_YN = 'Y' AND DL_EXPD_G_CD = '0027') CM
                WHERE BM.RGN_EENO = UM.USER_EENO
                      AND BM.AFFR_SCN_CD = CM.DL_EXPD_PRVS_CD
                      AND BM.AFFR_SCN_CD = DECODE(P_AFFR_SCN_CD, 'ALL', BM.AFFR_SCN_CD, P_AFFR_SCN_CD) 
                      AND BM.BLC_TITL_NM LIKE '%' || DECODE(P_BLC_TITL_NM, '', '', P_BLC_TITL_NM) || '%'
                ORDER BY BM.FRAM_DTM 
            )LIST
            ORDER BY RN DESC;
            
        END SP_BOARD_SEARCH;
        
        
        -- 게시판 상세 
        PROCEDURE SP_BOARD_VIEW(P_SCRN_SN NUMBER, 
                                RS OUT REFCUR)
        IS
        BEGIN
        
        OPEN RS FOR
            SELECT 
                USER_NM AS RGN_EENO_NM,
                SCRN_SN,
                DL_EXPD_PRVS_NM AS AFFR_SCN_NM,
                AFFR_SCN_CD,
                BLC_RGST_YMD,
                BLC_TITL_NM,
                ATTC_YN,
                N1AFP2_ADR,
                BUL_STRT_YMD,
                BUL_FNH_YMD,
                BUL_YN,
                BLC_SBC                
            FROM TB_BOARD_MGMT BM, 
                 (SELECT USER_NM, USER_EENO FROM TB_USR_MGMT) UM,
                 (SELECT DL_EXPD_PRVS_CD, DL_EXPD_PRVS_NM FROM TB_CODE_MGMT WHERE DL_EXPD_G_CD = '0027') CM
            WHERE 
                BM.RGN_EENO = UM.USER_EENO
                AND BM.AFFR_SCN_CD = CM.DL_EXPD_PRVS_CD
                AND SCRN_SN = P_SCRN_SN;
            
        END SP_BOARD_VIEW;
        
        
        -- 게시대상 목록 
        PROCEDURE SP_SUBJ_LIST(P_SCRN_SN NUMBER, 
                                RS OUT REFCUR)
        IS
        BEGIN
        
        OPEN RS FOR
            SELECT 
                BUL_SUBJ_CD,
                DL_EXPD_PRVS_NM AS BUL_SUBJ_NM
            FROM TB_BOARD_SUBJ_MGMT BSM, 
                 (SELECT DL_EXPD_PRVS_CD, DL_EXPD_PRVS_NM FROM TB_CODE_MGMT WHERE DL_EXPD_G_CD = '0011') CM
            WHERE 
                BSM.BUL_SUBJ_CD = CM.DL_EXPD_PRVS_CD
                AND SCRN_SN = P_SCRN_SN;
            
        END SP_SUBJ_LIST;
        
        -- 게시판 등록, 수정 
        PROCEDURE SP_BOARD_INSERT(P_SCRN_SN      NUMBER,
                                  P_AFFR_SCN_CD  VARCHAR2,
                                  P_RGN_EENO     CHAR,    
                                  P_BLC_TITL_NM  VARCHAR2,   
                                  P_BLC_SBC      CLOB,   
                                  P_ATTC_YN      CHAR,   
                                  P_N1AFP2_ADR   VARCHAR2,
                                  P_BUL_STRT_YMD VARCHAR2,
                                  P_BUL_FNH_YMD  VARCHAR2,
                                  P_BUL_YN       CHAR,
                                  P_RE_SCRN_SN  OUT NUMBER)
                                          
        IS
        BEGIN
        
            IF P_SCRN_SN = 0 THEN
                BEGIN
                    
                    SELECT NVL(MAX(SCRN_SN), 0)+1 INTO P_RE_SCRN_SN FROM TB_BOARD_MGMT;
                                    
                    INSERT INTO TB_BOARD_MGMT
                    (
                        SCRN_SN,      -- 화면일련번호
                        AFFR_SCN_CD,  -- 업무구분코드
                        RGN_EENO,     -- 등록자사원번호   
                        BLC_RGST_YMD, -- 게시물등록년월일 
                        BLC_TITL_NM,  -- 게시물제목명 
                        BLC_SBC,      -- 게시물내용
                        ATTC_YN,      -- 첨부여부
                        N1AFP2_ADR,   -- 1차첨부파일경로주소 
                        PPRR_EENO,    -- 작성자사원번호
                        FRAM_DTM,     -- 작성일시 
                        UPDR_EENO,    -- 수정자사원번호
                        MDFY_DTM,      -- 수정일시 
                        BUL_STRT_YMD, -- 게시시작년월일 
                        BUL_FNH_YMD,  -- 게시종료년월일 
                        BUL_YN        -- 게시여부 
                    )
                    VALUES
                    (
                        P_RE_SCRN_SN,
                        P_AFFR_SCN_CD,
                        P_RGN_EENO,
                        TO_CHAR(SYSDATE, 'YYYYMMDD'),
                        P_BLC_TITL_NM,
                        P_BLC_SBC,
                        P_ATTC_YN,
                        P_N1AFP2_ADR,
                        P_RGN_EENO,
                        SYSDATE,
                        P_RGN_EENO,
                        SYSDATE,
                        P_BUL_STRT_YMD,
                        P_BUL_FNH_YMD,
                        P_BUL_YN
                    );
                    
                END;
            
            ELSE
                BEGIN
					
					P_RE_SCRN_SN := P_SCRN_SN;
					
                    UPDATE TB_BOARD_MGMT
                        SET AFFR_SCN_CD = P_AFFR_SCN_CD,
                            BLC_TITL_NM = P_BLC_TITL_NM,
                            BLC_SBC = P_BLC_SBC,
                            ATTC_YN = P_ATTC_YN,
                            N1AFP2_ADR = P_N1AFP2_ADR,
                            UPDR_EENO = P_RGN_EENO,
                            MDFY_DTM = SYSDATE,
                            BUL_STRT_YMD = P_BUL_STRT_YMD, 
                            BUL_FNH_YMD = P_BUL_FNH_YMD,  
                            BUL_YN = P_BUL_YN        
                    WHERE SCRN_SN = P_SCRN_SN;         
                            
                END;
            
            END IF;
        END SP_BOARD_INSERT;
        
        -- 게시대상 등록
        PROCEDURE SP_SUBJ_INSERT(P_SCRN_SN     NUMBER,
                                 P_RGN_EENO    CHAR,
                                 P_BUL_SUBJ_CD VARCHAR2)
        IS
        BEGIN
            
            INSERT INTO TB_BOARD_SUBJ_MGMT
                    (
                        SCRN_SN,
                        BUL_SUBJ_CD,
                        SORT_SN,
                        PPRR_EENO,
                        FRAM_DTM,
                        UPDR_EENO,
                        MDFY_DTM
                    )
                    VALUES
                    (
                        P_SCRN_SN,
                        P_BUL_SUBJ_CD,
                        1,
                        P_RGN_EENO,
                        SYSDATE,
                        P_RGN_EENO,
                        SYSDATE
                    );
        
        END SP_SUBJ_INSERT;
                                  
        -- 게시판 삭제 
        PROCEDURE SP_BOARD_DELETE(P_SCRN_SN NUMBER)
        
        IS
        BEGIN
            
            DELETE TB_BOARD_MGMT
            WHERE SCRN_SN = P_SCRN_SN;
            
        END SP_BOARD_DELETE;
        
        -- 게시대상 삭제 
        PROCEDURE SP_SUBJ_DELETE(P_SCRN_SN NUMBER)
        
        IS 
        BEGIN
        
            DELETE TB_BOARD_SUBJ_MGMT
            WHERE SCRN_SN = P_SCRN_SN;
            
        END SP_SUBJ_DELETE;
        
END PG_BOARD_MGMT;