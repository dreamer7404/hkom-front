CREATE or replace package BODY KOMMS_ADM.pg_code_mgmt as

   /**
   -- 차종코드, 회사코드에 맞는 모델년식값 검색
   PROCEDURE SP_GET_MDL_MDY_CD(VEHL_CD IN TB_VEHL_MGMT.QLTY_VEHL_CD%TYPE,
                               EXPD_CO_CD IN TB_VEHL_MGMT.MDL_MDY_CD%TYPE,
                               RS OUT REFCUR)
     AS
   BEGIN
    OPEN RS FOR
      SELECT
        MDL_MDY_CD
      FROM
        TB_VEHL_MGMT
      WHERE
        TB_VEHL_MGMT.QLTY_VEHL_CD = VEHL_CD
      AND
        TB_VEHL_MGMT.DL_EXPD_CO_CD = EXPD_CO_CD;
    END SP_GET_MDL_MDY_CD;
    **/

   -- 수정할 값을 구함
   PROCEDURE SP_UPDATE_VALUE(EXPD_G_CD IN TB_CODE_MGMT.DL_EXPD_G_CD%TYPE,
                             EXPD_PRVS_CD IN TB_CODE_MGMT.DL_EXPD_PRVS_CD%TYPE,
                             RS OUT REFCUR)
    as
  begin
    OPEN RS FOR
      SELECT
        TB_CODE_GRP_MGMT.DL_EXPD_G_CD as DL_EXPD_G_CD,
        TB_CODE_GRP_MGMT.DL_EXPD_G_NM as DL_EXPD_G_NM,
        TB_CODE_MGMT.DL_EXPD_PRVS_CD as DL_EXPD_PRVS_CD,
        TB_CODE_MGMT.DL_EXPD_PRVS_NM as DL_EXPD_PRVS_NM,
        TB_CODE_MGMT.SORT_SN as SORT_SN,
        TB_CODE_MGMT.USE_YN as USE_YN,
        TB_CODE_MGMT.PPRR_EENO as PPRR_EENO,
        TB_CODE_MGMT.FRAM_DTM as FRAM_DTM
      FROM
        TB_CODE_GRP_MGMT, TB_CODE_MGMT
      WHERE
        TB_CODE_GRP_MGMT.DL_EXPD_G_CD = TB_CODE_MGMT.DL_EXPD_G_CD
      AND
        TB_CODE_GRP_MGMT.DL_EXPD_G_CD = EXPD_G_CD
      AND
        TB_CODE_MGMT.DL_EXPD_PRVS_CD = EXPD_PRVS_CD;
  end SP_UPDATE_VALUE;

  -- 항목명으로 그룹코드 검색
  PROCEDURE SP_GCODE_SEARCH(EXPD_PRVS_NM IN TB_CODE_MGMT.DL_EXPD_PRVS_CD%TYPE,
                            RS OUT REFCUR)
    as
  begin
    OPEN RS FOR
      SELECT
        DL_EXPD_G_CD
      FROM
        TB_CODE_MGMT
      WHERE
        DL_EXPD_PRVS_NM = EXPD_PRVS_NM
	  ORDER BY DL_EXPD_G_CD;

   end SP_GCODE_SEARCH;

  -- 그룹코드값에 의한 조회
  PROCEDURE SP_CODE_GRP_MGMT_SELECT(EXPD_G_CD IN TB_CODE_MGMT.DL_EXPD_G_CD%TYPE,
                                    RS OUT REFCUR)
    as
  begin
    OPEN RS FOR
      SELECT
        *
      FROM
        TB_CODE_MGMT
      WHERE
        DL_EXPD_G_CD = EXPD_G_CD
      ORDER BY
        DL_EXPD_PRVS_NM;

  end SP_CODE_GRP_MGMT_SELECT;

  -- 시스템코드 조건정보검색(전체검색포함)
  PROCEDURE SP_SC_MGMT_LIST(EXPD_G_CD IN TB_CODE_MGMT.DL_EXPD_G_CD%TYPE,
                            EXPD_PRVS_CD IN TB_CODE_MGMT.DL_EXPD_PRVS_CD%TYPE,
                            YN IN TB_CODE_MGMT.USE_YN%TYPE,
                            RS OUT REFCUR)
    AS
  BEGIN
    OPEN RS FOR
         SELECT
            A.DL_EXPD_G_CD as DL_EXPD_G_CD,
            A.DL_EXPD_G_NM as DL_EXPD_G_NM,
            B.DL_EXPD_PRVS_CD as DL_EXPD_PRVS_CD,
            B.DL_EXPD_PRVS_NM as DL_EXPD_PRVS_NM,
            B.SORT_SN as SORT_SN,
            B.USE_YN as USE_YN,
            B.PPRR_EENO as PPRR_EENO,
            B.FRAM_DTM as FRAM_DTM
          FROM
            TB_CODE_GRP_MGMT A,
            TB_CODE_MGMT B
          WHERE
            A.DL_EXPD_G_CD = B.DL_EXPD_G_CD
          AND
            A.DL_EXPD_G_CD = DECODE(EXPD_G_CD, 'ALL', B.DL_EXPD_G_CD, EXPD_G_CD)
          AND
            B.DL_EXPD_PRVS_CD = DECODE(EXPD_PRVS_CD, 'ALL', B.DL_EXPD_PRVS_CD, EXPD_PRVS_CD)
          AND
            B.USE_YN = DECODE(YN, 'ALL', B.USE_YN, YN)
        ORDER BY
          A.DL_EXPD_G_CD, B.DL_EXPD_PRVS_CD;

  end SP_SC_MGMT_LIST;

  -- 코드값에 의한 조회
  PROCEDURE SP_CODE_MGMT_LIST(EXPD_G_CD IN TB_CODE_MGMT.DL_EXPD_G_CD%TYPE,
                                    RS OUT REFCUR)
    AS
  BEGIN
    OPEN RS FOR
    SELECT
      DL_EXPD_PRVS_CD AS EXPD_PRVS_CD,
      DL_EXPD_PRVS_NM AS EXPD_PRVS_NM
    FROM
      TB_CODE_MGMT
    WHERE
      DL_EXPD_G_CD = EXPD_G_CD
    ORDER BY
      DL_EXPD_PRVS_NM;

  end SP_CODE_MGMT_LIST;

  -- 코드값등록
  PROCEDURE SP_CODE_MGMT_INSERT(DL_EXPD_G_CD IN TB_CODE_MGMT.DL_EXPD_G_CD%TYPE,
                                DL_EXPD_PRVS_CD IN TB_CODE_MGMT.DL_EXPD_PRVS_CD%TYPE,
                                DL_EXPD_PRVS_NM IN TB_CODE_MGMT.DL_EXPD_PRVS_NM%TYPE,
                                SORT_SN IN TB_CODE_MGMT.SORT_SN%TYPE,
                                USE_YN IN TB_CODE_MGMT.USE_YN%TYPE,
                                PPRR_EENO IN TB_CODE_MGMT.PPRR_EENO%TYPE,
                                UPDR_EENO IN TB_CODE_MGMT.UPDR_EENO%TYPE)
    AS
  BEGIN
    INSERT INTO TB_CODE_MGMT (
                              DL_EXPD_G_CD,
                              DL_EXPD_PRVS_CD,
                              DL_EXPD_PRVS_NM,
                              SORT_SN,
                              USE_YN,
                              PPRR_EENO,
                              FRAM_DTM,
                              UPDR_EENO,
                              MDFY_DTM)
     VALUES (
            DL_EXPD_G_CD,
            DL_EXPD_PRVS_CD,
            DL_EXPD_PRVS_NM,
            SORT_SN,
            USE_YN,
            PPRR_EENO,
            SYSDATE,
            UPDR_EENO,
            SYSDATE);
  END SP_CODE_MGMT_INSERT;

  -- 코드,항목내용수정
  PROCEDURE SP_CODE_MGMT_UPDATE(EXPD_G_CD IN TB_CODE_MGMT.DL_EXPD_G_CD%TYPE,
                                EXPD_G_NM IN TB_CODE_GRP_MGMT.DL_EXPD_G_NM%TYPE,
                                EXPD_PRVS_CD IN TB_CODE_MGMT.DL_EXPD_PRVS_CD%TYPE,
                                EXPD_PRVS_NM IN TB_CODE_MGMT.DL_EXPD_PRVS_NM%TYPE,
                                SN IN TB_CODE_MGMT.SORT_SN%TYPE,
                                YN IN TB_CODE_MGMT.USE_YN%TYPE,
                                EENO IN TB_CODE_MGMT.UPDR_EENO%TYPE)
    AS
  BEGIN
    UPDATE
      TB_CODE_GRP_MGMT
    SET
      DL_EXPD_G_NM = EXPD_G_NM,
      UPDR_EENO = EENO,
      MDFY_DTM = SYSDATE
    WHERE
      TB_CODE_GRP_MGMT.DL_EXPD_G_CD = EXPD_G_CD;

    UPDATE
      TB_CODE_MGMT
    SET
      DL_EXPD_PRVS_NM = EXPD_PRVS_NM,
      SORT_SN = SN,
      USE_YN = YN,
      UPDR_EENO = EENO,
      MDFY_DTM = SYSDATE
    WHERE
      TB_CODE_MGMT.DL_EXPD_G_CD = EXPD_G_CD
    AND
      TB_CODE_MGMT.DL_EXPD_PRVS_CD = EXPD_PRVS_CD;
  end SP_CODE_MGMT_UPDATE;

   -- 코드관리 사용여부 선택
  PROCEDURE SP_CODE_MGMT_DELETE(EXPD_G_CD IN TB_CODE_MGMT.DL_EXPD_G_CD%TYPE,
                                EXPD_PRVS_CD IN TB_CODE_MGMT.DL_EXPD_PRVS_CD%TYPE)
    AS
  BEGIN
    UPDATE
      TB_CODE_MGMT
    SET
      USE_YN = 'N'
    WHERE
      DL_EXPD_G_CD = EXPD_G_CD
    AND
      DL_EXPD_PRVS_CD = EXPD_PRVS_CD;
  END SP_CODE_MGMT_DELETE;

   -- 대분류 중복 판별
  PROCEDURE SP_GCODE_FLAG(P_DL_EXPD_G_CD IN VARCHAR2,
                          RS OUT REFCUR)
    IS
   BEGIN
    OPEN RS FOR
      SELECT
        DL_EXPD_G_CD
      FROM
        TB_CODE_GRP_MGMT
      WHERE
        DL_EXPD_G_CD = P_DL_EXPD_G_CD;
   END SP_GCODE_FLAG;

  -- 소분류 중복 판별
  PROCEDURE SP_CODE_FLAG(P_DL_EXPD_G_CD IN VARCHAR2,
                         P_DL_EXPD_PRVS_CD IN VARCHAR2,
                         RS OUT REFCUR)
    IS
  BEGIN
    OPEN RS FOR
      SELECT
        DL_EXPD_PRVS_CD
      FROM
        TB_CODE_MGMT
      WHERE
        DL_EXPD_G_CD = P_DL_EXPD_G_CD
      AND
        DL_EXPD_PRVS_CD = P_DL_EXPD_PRVS_CD;
   END SP_CODE_FLAG;

END PG_CODE_MGMT;