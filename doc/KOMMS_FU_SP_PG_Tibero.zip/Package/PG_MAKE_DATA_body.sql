CREATE OR REPLACE PACKAGE BODY KOMMS_ADM.PG_MAKE_DATA AS
	  
	  /************************************************************
	   시스템 운영 중 현업 요청 사항에 대응하기 위한 프로시저/함수 
	  ************************************************************/
	  
 	   --사원번호 변경 									   
	   PROCEDURE SP_CHANGE_USER_EENO(P_PREV_USER_EENO VARCHAR2,
	                                P_NEW_USER_EENO  VARCHAR2)
	   IS
	  	
		 V_PREV_USER_EENO CHAR(7);
		
	   BEGIN
	  	   
		   	V_PREV_USER_EENO := P_PREV_USER_EENO;
		   
		   	UPDATE TB_USR_MGMT
		   	SET USER_EENO = P_NEW_USER_EENO,
		   	   	USER_PW = P_NEW_USER_EENO
		   	WHERE USER_EENO = V_PREV_USER_EENO;
		   
		    UPDATE TB_VEHL_CRGR_MGMT
		    SET CRGR_EENO = P_NEW_USER_EENO
		    WHERE CRGR_EENO = V_PREV_USER_EENO;
		   
		    UPDATE TB_AUTH_AFFR_MGMT
		    SET USER_EENO = P_NEW_USER_EENO
		    WHERE USER_EENO = V_PREV_USER_EENO;

		    UPDATE TB_AUTH_VEHL_MGMT
		    SET USER_EENO = P_NEW_USER_EENO
		    WHERE USER_EENO = V_PREV_USER_EENO;
		   
		    COMMIT;

	   END SP_CHANGE_USER_EENO;	   
	   
	   --차종코드 변경(기존의 차종코드를 새로운 차종코드로 변경)  									
	   PROCEDURE SP_UPDATE_VEHL_CD1(P_PREV_VEHL_CD VARCHAR2,
	                                P_NEW_VEHL_CD  VARCHAR2)
	   IS
	   BEGIN
	   		
			UPDATE TB_ALTN_VEHL_MGMT
			SET QLTY_VEHL_CD = P_NEW_VEHL_CD
			WHERE QLTY_VEHL_CD = P_PREV_VEHL_CD;
			
			/**
			UPDATE TB_APS_ODR_ACUM_INFO
			SET QLTY_VEHL_CD = P_NEW_VEHL_CD
			WHERE QLTY_VEHL_CD = P_PREV_VEHL_CD;
			
			UPDATE TB_APS_ODR_INFO
			SET QLTY_VEHL_CD = P_NEW_VEHL_CD
			WHERE QLTY_VEHL_CD = P_PREV_VEHL_CD;
			
			UPDATE TB_APS_ODR_NOAPIM_INFO
			SET QLTY_VEHL_CD = P_NEW_VEHL_CD
			WHERE QLTY_VEHL_CD = P_PREV_VEHL_CD;
												
			UPDATE TB_APS_ODR_SUM_INFO
			SET QLTY_VEHL_CD = P_NEW_VEHL_CD
			WHERE QLTY_VEHL_CD = P_PREV_VEHL_CD;
			
			UPDATE TB_APS_PLAN_NOAPIM_INFO
			SET QLTY_VEHL_CD = P_NEW_VEHL_CD
			WHERE QLTY_VEHL_CD = P_PREV_VEHL_CD;
			
			UPDATE TB_APS_PROD_PLAN_INFO
			SET QLTY_VEHL_CD = P_NEW_VEHL_CD
			WHERE QLTY_VEHL_CD = P_PREV_VEHL_CD;
			
			UPDATE TB_APS_PROD_PLAN_SUM_INFO
			SET QLTY_VEHL_CD = P_NEW_VEHL_CD
			WHERE QLTY_VEHL_CD = P_PREV_VEHL_CD;
			
			UPDATE TB_APS_PROD_PLAN_SUM_TEMP
			SET QLTY_VEHL_CD = P_NEW_VEHL_CD
			WHERE QLTY_VEHL_CD = P_PREV_VEHL_CD;
			
			UPDATE TB_APS_PROD_SUM_INFO
			SET QLTY_VEHL_CD = P_NEW_VEHL_CD
			WHERE QLTY_VEHL_CD = P_PREV_VEHL_CD;
			**/
			
			UPDATE TB_AUTH_VEHL_MGMT
			SET QLTY_VEHL_CD = P_NEW_VEHL_CD
			WHERE QLTY_VEHL_CD = P_PREV_VEHL_CD;
			
			UPDATE TB_CHKLIST_DTL_INFO
			SET QLTY_VEHL_CD = P_NEW_VEHL_CD
			WHERE QLTY_VEHL_CD = P_PREV_VEHL_CD;
			
			UPDATE TB_DL_EXPD_MDY_MGMT
			SET QLTY_VEHL_CD = P_NEW_VEHL_CD
			WHERE QLTY_VEHL_CD = P_PREV_VEHL_CD;
			
			UPDATE TB_DL_LANG_MDY_MGMT
			SET QLTY_VEHL_CD = P_NEW_VEHL_CD
			WHERE QLTY_VEHL_CD = P_PREV_VEHL_CD;
			
			UPDATE TB_EXTRA_REQ_INFO
			SET QLTY_VEHL_CD = P_NEW_VEHL_CD
			WHERE QLTY_VEHL_CD = P_PREV_VEHL_CD;
			
			UPDATE TB_GLOVIS_DLVH_REQ_INFO
			SET QLTY_VEHL_CD = P_NEW_VEHL_CD
			WHERE QLTY_VEHL_CD = P_PREV_VEHL_CD;
			
			UPDATE TB_GLOVIS_DPCR_INFO
			SET QLTY_VEHL_CD = P_NEW_VEHL_CD
			WHERE QLTY_VEHL_CD = P_PREV_VEHL_CD;
			
			UPDATE TB_LANG_MGMT
			SET QLTY_VEHL_CD = P_NEW_VEHL_CD
			WHERE QLTY_VEHL_CD = P_PREV_VEHL_CD;
			
			UPDATE TB_NATL_LANG_EXCEL
			SET QLTY_VEHL_CD = P_NEW_VEHL_CD
			WHERE QLTY_VEHL_CD = P_PREV_VEHL_CD;
			
			UPDATE TB_NATL_LANG_MGMT
			SET QLTY_VEHL_CD = P_NEW_VEHL_CD
			WHERE QLTY_VEHL_CD = P_PREV_VEHL_CD;
			
			UPDATE TB_NATL_VEHL_MGMT
			SET QLTY_VEHL_CD = P_NEW_VEHL_CD
			WHERE QLTY_VEHL_CD = P_PREV_VEHL_CD;
			
			UPDATE TB_PDI_COM_VEHL_MGMT
			SET QLTY_VEHL_CD = P_NEW_VEHL_CD
			WHERE QLTY_VEHL_CD = P_PREV_VEHL_CD;
			
			UPDATE TB_PDI_DIVS_INFO
			SET QLTY_VEHL_CD = P_NEW_VEHL_CD
			WHERE QLTY_VEHL_CD = P_PREV_VEHL_CD;
			
			UPDATE TB_PDI_DLVH_REQ_INFO
			SET QLTY_VEHL_CD = P_NEW_VEHL_CD
			WHERE QLTY_VEHL_CD = P_PREV_VEHL_CD;
			
			UPDATE TB_PDI_IV_INFO
			SET QLTY_VEHL_CD = P_NEW_VEHL_CD
			WHERE QLTY_VEHL_CD = P_PREV_VEHL_CD;
			
			UPDATE TB_PDI_IV_INFO_DTL
			SET QLTY_VEHL_CD = P_NEW_VEHL_CD
			WHERE QLTY_VEHL_CD = P_PREV_VEHL_CD;
			
			UPDATE TB_PDI_WHOT_INFO
			SET QLTY_VEHL_CD = P_NEW_VEHL_CD
			WHERE QLTY_VEHL_CD = P_PREV_VEHL_CD;
			
			UPDATE TB_PDI_WHSN_INFO
			SET QLTY_VEHL_CD = P_NEW_VEHL_CD
			WHERE QLTY_VEHL_CD = P_PREV_VEHL_CD;
			
			UPDATE TB_PLNT_APS_ODR_SUM_INFO
			SET QLTY_VEHL_CD = P_NEW_VEHL_CD
			WHERE QLTY_VEHL_CD = P_PREV_VEHL_CD;
			
			UPDATE TB_PLNT_APS_PROD_PLAN_SUM_INFO
			SET QLTY_VEHL_CD = P_NEW_VEHL_CD
			WHERE QLTY_VEHL_CD = P_PREV_VEHL_CD;
			
			/**
			UPDATE TB_PLNT_APS_PROD_PLAN_SUM_TEMP
			SET QLTY_VEHL_CD = P_NEW_VEHL_CD
			WHERE QLTY_VEHL_CD = P_PREV_VEHL_CD;
			
			UPDATE TB_PLNT_APS_PROD_SUM_INFO
			SET QLTY_VEHL_CD = P_NEW_VEHL_CD
			WHERE QLTY_VEHL_CD = P_PREV_VEHL_CD;
			
			UPDATE TB_PLNT_PROD_MST_SUM_INFO
			SET QLTY_VEHL_CD = P_NEW_VEHL_CD
			WHERE QLTY_VEHL_CD = P_PREV_VEHL_CD;
			**/
			
			UPDATE TB_PLNT_VEHL_MGMT
			SET QLTY_VEHL_CD = P_NEW_VEHL_CD
			WHERE QLTY_VEHL_CD = P_PREV_VEHL_CD;
			
			UPDATE TB_PRNT_ALGN_INFO
			SET QLTY_VEHL_CD = P_NEW_VEHL_CD
			WHERE QLTY_VEHL_CD = P_PREV_VEHL_CD;
			
			UPDATE TB_PRNT_BKGD_INFO
			SET QLTY_VEHL_CD = P_NEW_VEHL_CD
			WHERE QLTY_VEHL_CD = P_PREV_VEHL_CD;
			
			UPDATE TB_PRNT_FP_INFO
			SET QLTY_VEHL_CD = P_NEW_VEHL_CD
			WHERE QLTY_VEHL_CD = P_PREV_VEHL_CD;
			
			UPDATE TB_PRNT_PAGE_MGMT
			SET QLTY_VEHL_CD = P_NEW_VEHL_CD
			WHERE QLTY_VEHL_CD = P_PREV_VEHL_CD;
			
			UPDATE TB_PRNT_REQ_INFO
			SET QLTY_VEHL_CD = P_NEW_VEHL_CD
			WHERE QLTY_VEHL_CD = P_PREV_VEHL_CD;
			
			/**
			UPDATE TB_PROD_MST_INFO
			SET QLTY_VEHL_CD = P_NEW_VEHL_CD
			WHERE QLTY_VEHL_CD = P_PREV_VEHL_CD;
			
			UPDATE TB_PROD_MST_NOAPIM_INFO
			SET QLTY_VEHL_CD = P_NEW_VEHL_CD
			WHERE QLTY_VEHL_CD = P_PREV_VEHL_CD;
			
			UPDATE TB_PROD_MST_PROG_INFO
			SET QLTY_VEHL_CD = P_NEW_VEHL_CD
			WHERE QLTY_VEHL_CD = P_PREV_VEHL_CD;
			
			UPDATE TB_PROD_MST_SUM_INFO
			SET QLTY_VEHL_CD = P_NEW_VEHL_CD
			WHERE QLTY_VEHL_CD = P_PREV_VEHL_CD;
			
			UPDATE TB_PROD_MST_TRWI_INFO
			SET QLTY_VEHL_CD = P_NEW_VEHL_CD
			WHERE QLTY_VEHL_CD = P_PREV_VEHL_CD;
			
			UPDATE TB_PROD_ODR_INFO
			SET QLTY_VEHL_CD = P_NEW_VEHL_CD
			WHERE QLTY_VEHL_CD = P_PREV_VEHL_CD;
			
			UPDATE TB_SEWHA_DIVS_INFO
			SET QLTY_VEHL_CD = P_NEW_VEHL_CD
			WHERE QLTY_VEHL_CD = P_PREV_VEHL_CD;
			
			UPDATE TB_SEWHA_IV_INFO
			SET QLTY_VEHL_CD = P_NEW_VEHL_CD
			WHERE QLTY_VEHL_CD = P_PREV_VEHL_CD;
			
			UPDATE TB_SEWHA_IV_INFO_DTL
			SET QLTY_VEHL_CD = P_NEW_VEHL_CD
			WHERE QLTY_VEHL_CD = P_PREV_VEHL_CD;
			
			UPDATE TB_SEWHA_WHOT_INFO
			SET QLTY_VEHL_CD = P_NEW_VEHL_CD
			WHERE QLTY_VEHL_CD = P_PREV_VEHL_CD;
			
			UPDATE TB_SEWHA_WHSN_INFO
			SET QLTY_VEHL_CD = P_NEW_VEHL_CD
			WHERE QLTY_VEHL_CD = P_PREV_VEHL_CD;
			
			UPDATE TB_SFTY_IV_MGMT
			SET QLTY_VEHL_CD = P_NEW_VEHL_CD
			WHERE QLTY_VEHL_CD = P_PREV_VEHL_CD;
			**/
			
			UPDATE TB_VEHL_CRGR_MGMT
			SET QLTY_VEHL_CD = P_NEW_VEHL_CD
			WHERE QLTY_VEHL_CD = P_PREV_VEHL_CD;
			
			UPDATE TB_VEHL_MDY_MGMT
			SET QLTY_VEHL_CD = P_NEW_VEHL_CD
			WHERE QLTY_VEHL_CD = P_PREV_VEHL_CD;
			
			UPDATE TB_VEHL_MDY_REL_MGMT
			SET QLTY_VEHL_CD = P_NEW_VEHL_CD
			WHERE QLTY_VEHL_CD = P_PREV_VEHL_CD;
			
			UPDATE TB_VEHL_MGMT
			SET QLTY_VEHL_CD = P_NEW_VEHL_CD
			WHERE QLTY_VEHL_CD = P_PREV_VEHL_CD;
			
			COMMIT;
			
	   END SP_UPDATE_VEHL_CD1;
	   
	   --차종코드에 해당하는 언어코드 변경 									
	   PROCEDURE SP_UPDATE_LANG_CD1(P_VEHL_CD	   VARCHAR2,
	   			 					P_PREV_LANG_CD VARCHAR2,
	                                P_NEW_LANG_CD  VARCHAR2)
	   IS
	   BEGIN
	   		
			UPDATE TB_LANG_MGMT
			SET LANG_CD = P_NEW_LANG_CD
			WHERE QLTY_VEHL_CD = P_VEHL_CD
			AND LANG_CD = P_PREV_LANG_CD;
												
			UPDATE TB_NATL_LANG_MGMT
			SET LANG_CD = P_NEW_LANG_CD
			WHERE QLTY_VEHL_CD = P_VEHL_CD
			AND LANG_CD = P_PREV_LANG_CD;
			
			UPDATE TB_SFTY_IV_MGMT
			SET LANG_CD = P_NEW_LANG_CD
			WHERE QLTY_VEHL_CD = P_VEHL_CD
			AND LANG_CD = P_PREV_LANG_CD;
			
			UPDATE TB_PRNT_PAGE_MGMT
			SET LANG_CD = P_NEW_LANG_CD
			WHERE QLTY_VEHL_CD = P_VEHL_CD
			AND LANG_CD = P_PREV_LANG_CD;
			
			UPDATE TB_APS_ODR_SUM_INFO
			SET LANG_CD = P_NEW_LANG_CD
			WHERE QLTY_VEHL_CD = P_VEHL_CD
			AND LANG_CD = P_PREV_LANG_CD;
			
			UPDATE TB_APS_PROD_PLAN_SUM_INFO
			SET LANG_CD = P_NEW_LANG_CD
			WHERE QLTY_VEHL_CD = P_VEHL_CD
			AND LANG_CD = P_PREV_LANG_CD;
			
			UPDATE TB_APS_PROD_SUM_INFO
			SET LANG_CD = P_NEW_LANG_CD
			WHERE QLTY_VEHL_CD = P_VEHL_CD
			AND LANG_CD = P_PREV_LANG_CD;
			
			UPDATE TB_CHKLIST_DTL_INFO
			SET LANG_CD = P_NEW_LANG_CD
			WHERE QLTY_VEHL_CD = P_VEHL_CD
			AND LANG_CD = P_PREV_LANG_CD;
			
			UPDATE TB_EXTRA_REQ_INFO
			SET LANG_CD = P_NEW_LANG_CD
			WHERE QLTY_VEHL_CD = P_VEHL_CD
			AND LANG_CD = P_PREV_LANG_CD;
			
			UPDATE TB_GLOVIS_DLVH_REQ_INFO
			SET LANG_CD = P_NEW_LANG_CD
			WHERE QLTY_VEHL_CD = P_VEHL_CD
			AND LANG_CD = P_PREV_LANG_CD;
			
			UPDATE TB_PDI_DLVH_REQ_INFO
			SET LANG_CD = P_NEW_LANG_CD
			WHERE QLTY_VEHL_CD = P_VEHL_CD
			AND LANG_CD = P_PREV_LANG_CD;
			
			UPDATE TB_PDI_IV_INFO
			SET LANG_CD = P_NEW_LANG_CD
			WHERE QLTY_VEHL_CD = P_VEHL_CD
			AND LANG_CD = P_PREV_LANG_CD;
			
			UPDATE TB_PDI_WHOT_INFO
			SET LANG_CD = P_NEW_LANG_CD
			WHERE QLTY_VEHL_CD = P_VEHL_CD
			AND LANG_CD = P_PREV_LANG_CD;
			
			UPDATE TB_PDI_WHSN_INFO
			SET LANG_CD = P_NEW_LANG_CD
			WHERE QLTY_VEHL_CD = P_VEHL_CD
			AND LANG_CD = P_PREV_LANG_CD;
			
			UPDATE TB_PRNT_ALGN_INFO
			SET LANG_CD = P_NEW_LANG_CD
			WHERE QLTY_VEHL_CD = P_VEHL_CD
			AND LANG_CD = P_PREV_LANG_CD;
			
			UPDATE TB_PRNT_BKGD_INFO
			SET LANG_CD = P_NEW_LANG_CD
			WHERE QLTY_VEHL_CD = P_VEHL_CD
			AND LANG_CD = P_PREV_LANG_CD;
			
			UPDATE TB_PRNT_FP_INFO
			SET LANG_CD = P_NEW_LANG_CD
			WHERE QLTY_VEHL_CD = P_VEHL_CD
			AND LANG_CD = P_PREV_LANG_CD;
			
			UPDATE TB_PRNT_REQ_INFO
			SET LANG_CD = P_NEW_LANG_CD
			WHERE QLTY_VEHL_CD = P_VEHL_CD
			AND LANG_CD = P_PREV_LANG_CD;
			
			UPDATE TB_PROD_MST_SUM_INFO
			SET LANG_CD = P_NEW_LANG_CD
			WHERE QLTY_VEHL_CD = P_VEHL_CD
			AND LANG_CD = P_PREV_LANG_CD;
			
			UPDATE TB_PROD_ODR_INFO
			SET LANG_CD = P_NEW_LANG_CD
			WHERE QLTY_VEHL_CD = P_VEHL_CD
			AND LANG_CD = P_PREV_LANG_CD;
			
			UPDATE TB_SEWHA_IV_INFO
			SET LANG_CD = P_NEW_LANG_CD
			WHERE QLTY_VEHL_CD = P_VEHL_CD
			AND LANG_CD = P_PREV_LANG_CD;
			
			UPDATE TB_SEWHA_WHOT_INFO
			SET LANG_CD = P_NEW_LANG_CD
			WHERE QLTY_VEHL_CD = P_VEHL_CD
			AND LANG_CD = P_PREV_LANG_CD;
			
			UPDATE TB_SEWHA_WHSN_INFO
			SET LANG_CD = P_NEW_LANG_CD
			WHERE QLTY_VEHL_CD = P_VEHL_CD
			AND LANG_CD = P_PREV_LANG_CD;
			
	   		COMMIT;
	   
	   END SP_UPDATE_LANG_CD1;
	   
	   --템플릿 차종코드, 연식에 해당하는 항목으로 차종코드, 연식의 언어, 국가/언어 항목을 추가 
	   PROCEDURE SP_UPDATE_VEHL_LANG_CD(P_TEMPLATE_VEHL_CD VARCHAR2,
	   			 						P_TEMPLATE_MDY_CD  VARCHAR2,
										P_VEHL_CD		   VARCHAR2,
										P_MDL_MDY_CD	   VARCHAR2)
	   IS
	   	 
		 CURSOR LANG_LIST_MGMT IS SELECT LANG_CD, DL_EXPD_REGN_CD, LANG_CD_NM, 
		 					   	  		 SORT_SN, A_CODE, NVL(N1_INS_YN, 'N') AS N1_INS_YN
								  FROM TB_LANG_MGMT
								  WHERE QLTY_VEHL_CD = P_TEMPLATE_VEHL_CD
								  AND MDL_MDY_CD = P_TEMPLATE_MDY_CD;
								  
		 CURSOR NATL_LANG_LIST_MGMT IS SELECT DL_EXPD_CO_CD, DL_EXPD_NAT_CD, LANG_CD
								    FROM TB_NATL_LANG_MGMT
								    WHERE QLTY_VEHL_CD = P_TEMPLATE_VEHL_CD
								    AND MDL_MDY_CD = P_TEMPLATE_MDY_CD;
		
		 V_CNT     NUMBER;
		 V_DATA_SN NUMBER;
		 				  
	   BEGIN
	   		
			FOR LANG_LIST IN LANG_LIST_MGMT LOOP
				
				SELECT COUNT(*)
				INTO V_CNT
				FROM TB_LANG_MGMT
				WHERE QLTY_VEHL_CD = P_VEHL_CD
				AND MDL_MDY_CD = P_MDL_MDY_CD
				AND LANG_CD = LANG_LIST.LANG_CD;
				
				IF V_CNT = 0 THEN
				   
				   SELECT NVL(MAX(DATA_SN), 0) + 1
				   INTO V_DATA_SN 
				   FROM TB_LANG_MGMT;
				   
				   INSERT INTO TB_LANG_MGMT
				   (DATA_SN,
				   	QLTY_VEHL_CD,
					MDL_MDY_CD,
					LANG_CD,
					DL_EXPD_REGN_CD,
					LANG_CD_NM,
					USE_YN,
					NAPC_YN,
					PPRR_EENO,
					FRAM_DTM,
					UPDR_EENO,
					MDFY_DTM,
					SORT_SN,
					A_CODE,
					N1_INS_YN
				   )
				   VALUES(V_DATA_SN,
				          P_VEHL_CD,
						  P_MDL_MDY_CD,
						  LANG_LIST.LANG_CD,
						  LANG_LIST.DL_EXPD_REGN_CD,
						  LANG_LIST.LANG_CD_NM,
						  'Y',
						  'Y',
						  'SYSTEM',
						  SYSDATE,
						  'SYSTEM',
						  SYSDATE,
						  LANG_LIST.SORT_SN,
						  LANG_LIST.A_CODE,
						  LANG_LIST.N1_INS_YN
						 );
						  
				  PG_LANG_MGMT.SP_N1_INS_YN_UPDATE2(V_DATA_SN, 
				  								    'SYSTEM');
				END IF;
				
			END LOOP;
			
			FOR NATL_LANG_LIST IN NATL_LANG_LIST_MGMT LOOP
				
				SELECT COUNT(*)
				INTO V_CNT
				FROM TB_NATL_LANG_MGMT
				WHERE QLTY_VEHL_CD = P_VEHL_CD
				AND MDL_MDY_CD = P_MDL_MDY_CD
				AND LANG_CD = NATL_LANG_LIST.LANG_CD
				AND DL_EXPD_CO_CD = NATL_LANG_LIST.DL_EXPD_CO_CD
				AND DL_EXPD_NAT_CD = NATL_LANG_LIST.DL_EXPD_NAT_CD;
				
				IF V_CNT = 0 THEN
				   
				   INSERT INTO TB_NATL_LANG_MGMT
				   VALUES(NATL_LANG_LIST.DL_EXPD_CO_CD,
				          NATL_LANG_LIST.DL_EXPD_NAT_CD,
				          P_VEHL_CD,
						  P_MDL_MDY_CD,
						  NATL_LANG_LIST.LANG_CD,
						  'Y',
						  'N',
						  'SYSTEM',
						  SYSDATE,
						  'SYSTEM',
						  SYSDATE
						 );
						 
				  PG_NATL_LANG_MGMT.SP_NATL_VEHL_SAVE(NATL_LANG_LIST.DL_EXPD_CO_CD,
	   							   					  NATL_LANG_LIST.DL_EXPD_NAT_CD,
								   					  P_VEHL_CD,
								   					  P_MDL_MDY_CD,
								   					  NATL_LANG_LIST.LANG_CD,
								   					  'SYSTEM');
				END IF;
				
			END LOOP;
			
			COMMIT;
			
			EXCEPTION
		     WHEN OTHERS THEN
			     ROLLBACK;
				 RAISE;
				 
	   END SP_UPDATE_VEHL_LANG_CD;
	   
	   --[주의] GOMS와의 인터페이스 처리로 인하여... GOMS에서 한꺼번에 처리해 주면 됨 
	   --이전 연식에 해당하는 차종정보를 기반으로 신규 차종, 언어, 국가/언어 항목 추가
	   --이미 현재 연식으로 지정되어 있는 항목은 신규생성 대상에서 제외함 
	   PROCEDURE SP_CREATE_NEW_VEHL_INFO(P_PREV_MDL_MDY_CD   VARCHAR2,
	                                     P_EXCLUDE_VEHL_LIST VARCHAR2)
	   IS
	     
		 V_CNT        NUMBER;
		 V_MDL_MDY_CD VARCHAR(2);
		 
	   	 CURSOR VEHL_LIST_MGMT IS WITH T AS (SELECT QLTY_VEHL_CD                                                                                                                                                              
                               	  	   	     FROM (SELECT SUBSTRB(STR, A01+LEN, A02-A01-LEN) QLTY_VEHL_CD                                                                                                                      
                                      		 	   FROM (SELECT STR                                                                                                                                                               
                                                               ,INSTRB(STR, GUB, 1, LEVEL)    A01  -- 위치 인덱스                                                                                                                 
                                                  			   ,INSTRB(STR, GUB, 1, LEVEL+ 1) A02  -- 다음위치 인덱스                                                                                                             
                                                  			   ,LEN                                                                                                                                                               
                                              		     FROM (SELECT GUB||STR||GUB  STR          -- 처리를 위해 문자변환                                                                                                       
                                                          	  		 ,LENGTH(GUB)    LEN          -- 구분자 길이                                                                                                                
                                                          			 ,GUB                                                                                                                                                       
                                                               FROM (SELECT P_EXCLUDE_VEHL_LIST STR    -- 입력받은 문자                                                                                                       
                                                                           ,','                 GUB    -- 구분자                                                                                                              
                                                                     FROM DUAL                                                                                                                                              
                                                                    )                                                                                                                                                         
                                                              )                                                                                                                                                                
                                                         CONNECT BY LEVEL <= 100                                                                                                                                                   
                                                       )                                                                                                                                                                         
                                                  )                                                                                                                                                                                
                                             WHERE QLTY_VEHL_CD IS NOT NULL
		 					   	  	   	    )
		 					   	  SELECT A.*,
				 			   	  		 PG_VEHL_MGMT.FU_GET_MDY_REL_CD(A.QLTY_VEHL_CD, A.MDL_MDY_CD, B.EXPD_REGN_CD1) AS MDY_REL_CD1,
										 PG_VEHL_MGMT.FU_GET_MDY_REL_CD(A.QLTY_VEHL_CD, A.MDL_MDY_CD, B.EXPD_REGN_CD2) AS MDY_REL_CD2,
										 PG_VEHL_MGMT.FU_GET_MDY_REL_CD(A.QLTY_VEHL_CD, A.MDL_MDY_CD, B.EXPD_REGN_CD3) AS MDY_REL_CD3,
										 PG_VEHL_MGMT.FU_GET_MDY_REL_CD(A.QLTY_VEHL_CD, A.MDL_MDY_CD, B.EXPD_REGN_CD4) AS MDY_REL_CD4,
										 PG_VEHL_MGMT.FU_GET_MDY_REL_CD(A.QLTY_VEHL_CD, A.MDL_MDY_CD, B.EXPD_REGN_CD5) AS MDY_REL_CD5,
										 PG_VEHL_MGMT.FU_GET_MDY_REL_CD(A.QLTY_VEHL_CD, A.MDL_MDY_CD, B.EXPD_REGN_CD6) AS MDY_REL_CD6
				                  FROM (SELECT A.QLTY_VEHL_CD,
				   		      	  	   		   A.MDL_MDY_CD,
				  		      				   A.DL_EXPD_CO_CD,
					    	  				   A.QLTY_VEHL_NM,
							  				   A.DL_EXPD_PAC_SCN_CD,
							  				   A.DL_EXPD_PDI_CD,
							  				   --A.JB_MDY_REL_CD,
							  				   NULL AS JB_MDY_REL_CD,
							  				   PG_VEHL_MGMT.FU_GET_PRDN_VEHL_LIST(A.QLTY_VEHL_CD, 'A') AS DYTM_PLN_VEHL_LIST,
							  				   PG_VEHL_MGMT.FU_GET_PRDN_VEHL_LIST(A.QLTY_VEHL_CD, 'B') AS PRDN_MST_VEHL_LIST,
							  				   PG_VEHL_MGMT.FU_GET_PRDN_VEHL_LIST(A.QLTY_VEHL_CD, 'C') AS BOM_VEHL_LIST,
							  				   PG_VEHL_MGMT.FU_GET_PRDN_VEHL_LIST(A.QLTY_VEHL_CD, 'D') AS SALE_VEHL_LIST,
											   PG_VEHL_MGMT.FU_GET_CRGR_USER_ID_LIST(A.QLTY_VEHL_CD, A.MDL_MDY_CD, '01') AS USER_ID_LIST1,
											   PG_VEHL_MGMT.FU_GET_CRGR_USER_ID_LIST(A.QLTY_VEHL_CD, A.MDL_MDY_CD, '02') AS USER_ID_LIST2,
											   PG_VEHL_MGMT.FU_GET_CRGR_USER_ID_LIST(A.QLTY_VEHL_CD, A.MDL_MDY_CD, '03') AS USER_ID_LIST3,
											   PG_VEHL_MGMT.FU_GET_CRGR_USER_ID_LIST(A.QLTY_VEHL_CD, A.MDL_MDY_CD, '04') AS USER_ID_LIST4,
											   PG_VEHL_MGMT.FU_GET_CRGR_USER_ID_LIST(A.QLTY_VEHL_CD, A.MDL_MDY_CD, '05') AS USER_ID_LIST5,
							  				   A.USE_YN
				       			        FROM TB_VEHL_MGMT A,
											 T B
				 	   					WHERE A.MDL_MDY_CD = P_PREV_MDL_MDY_CD
										AND A.QLTY_VEHL_CD <> B.QLTY_VEHL_CD
					                   ) A,
					                   VW_EXPD_REGN_CD_VIEW B;
	   BEGIN
	   		
			V_MDL_MDY_CD := TRIM(TO_CHAR(TO_NUMBER(P_PREV_MDL_MDY_CD) + 1, '00'));
			
			FOR VEHL_LIST IN VEHL_LIST_MGMT LOOP
				
				/**
				SELECT COUNT(*)
				INTO V_CNT
				FROM TB_VEHL_MGMT
				WHERE QLTY_VEHL_CD = VEHL_LIST.QLTY_VEHL_CD
				AND MDL_MDY_CD = V_MDL_MDY_CD;
				**/
				
				--아직 생성되지 않은 항목만 생성하여 준다. 
				--IF V_CNT = 0 THEN
				   
				   PG_VEHL_MGMT.SP_VEHL_INFO_SAVE(VEHL_LIST.QLTY_VEHL_CD,
				   								  V_MDL_MDY_CD,
												  VEHL_LIST.DL_EXPD_CO_CD,
												  VEHL_LIST.DL_EXPD_PAC_SCN_CD,
												  VEHL_LIST.DL_EXPD_PDI_CD,
												  VEHL_LIST.QLTY_VEHL_NM,
												  VEHL_LIST.JB_MDY_REL_CD,
												  VEHL_LIST.DYTM_PLN_VEHL_LIST,
												  VEHL_LIST.PRDN_MST_VEHL_LIST,
												  VEHL_LIST.BOM_VEHL_LIST,
												  VEHL_LIST.SALE_VEHL_LIST,
												  VEHL_LIST.USER_ID_LIST1,
												  VEHL_LIST.USER_ID_LIST2,
												  VEHL_LIST.USER_ID_LIST3,
												  VEHL_LIST.USER_ID_LIST4,
												  VEHL_LIST.USER_ID_LIST5,
												  VEHL_LIST.USE_YN,
												  'SYSTEM',
												  VEHL_LIST.MDY_REL_CD1,
												  VEHL_LIST.MDY_REL_CD2,
												  VEHL_LIST.MDY_REL_CD3,
												  VEHL_LIST.MDY_REL_CD4,
												  VEHL_LIST.MDY_REL_CD5,
												  VEHL_LIST.MDY_REL_CD6,
												  'N'
												 );
				   
				--END IF;
				
			END LOOP;
			
			COMMIT;
	   		
			EXCEPTION
		     WHEN OTHERS THEN
			     ROLLBACK;
				 RAISE;
				 
	   END SP_CREATE_NEW_VEHL_INFO;
	   
	   /** 2010.12.09.김동근 PG_VEHL_MGMT 패키지로 이동 
	   --그룹별 담당자 아이디 리스트를 얻어오는 함수 
	   FUNCTION GET_CRGR_USER_LIST(P_QLTY_VEHL_CD VARCHAR2,
	                               P_MDL_MDY_CD   VARCHAR2,
	                               P_BLNS_CO_CD   VARCHAR2
								  ) RETURN VARCHAR2
       IS
	   
	   	 V_USER_ID_LIST VARCHAR2(8000);
	   
	   	 CURSOR USER_MGMT_LIST IS SELECT A.CRGR_EENO
	   	                          FROM TB_VEHL_CRGR_MGMT A
							      WHERE A.QLTY_VEHL_CD  = P_QLTY_VEHL_CD
								  AND A.MDL_MDY_CD = P_MDL_MDY_CD
							      AND A.BLNS_CO_CD = P_BLNS_CO_CD
							      ORDER BY A.CRGR_EENO;
	   BEGIN
	   		
			V_USER_ID_LIST := '';
		
			FOR USER_LIST IN USER_MGMT_LIST LOOP
			
				V_USER_ID_LIST := V_USER_ID_LIST || USER_LIST.CRGR_EENO || ',';
			
			END LOOP;
		
			IF LENGTH(V_USER_ID_LIST) > 0 THEN
		   
		   	   V_USER_ID_LIST := SUBSTR(V_USER_ID_LIST, 1, LENGTH(V_USER_ID_LIST) - 1);
		   
		    END IF;
		
			RETURN V_USER_ID_LIST;
		
	   END 	GET_CRGR_USER_LIST;							   								   
	   **/
	   
	   --차종코드 전체의 직전연식관계 정보를 재 설정 											   
	   PROCEDURE SP_UPDATE_VEHL_MDY_REL_CD
	   IS
	   	 CURSOR VEHL_LIST_MGMT IS SELECT A.QLTY_VEHL_CD, 
		 					   	  		 A.MDL_MDY_CD, 
										 B.DL_EXPD_REGN_CD, 
										 B.JB_MDY_REL_CD
								  FROM TB_VEHL_MGMT A,
								  	   TB_VEHL_MDY_REL_MGMT B
								  WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
								  AND A.MDL_MDY_CD = B.MDL_MDY_CD
								  GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, B.DL_EXPD_REGN_CD, B.JB_MDY_REL_CD
								  ORDER BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, B.DL_EXPD_REGN_CD;
	   BEGIN
	   		
			FOR VEHL_LIST IN VEHL_LIST_MGMT LOOP
				
				PG_VEHL_MGMT.SP_VEHL_MDY_REL_CD_UPDATE(VEHL_LIST.QLTY_VEHL_CD,
	   							      				   VEHL_LIST.MDL_MDY_CD,
													   VEHL_LIST.DL_EXPD_REGN_CD,
									  				   VEHL_LIST.JB_MDY_REL_CD,
								      				   'SYSTEM'); 
			END LOOP;
			
			COMMIT;
			
	   END SP_UPDATE_VEHL_MDY_REL_CD;
	   
/**	   --해당날짜의 세화 재고 데이터 이전날짜의 데이터로 초기화 하는 작업 수행 
	   PROCEDURE SP_RESET_SEWHA_IV_INFO 
	   IS
	   
	   	 CURSOR PREV_IV_INFO IS SELECT QLTY_VEHL_CD,
		 					 	       DL_EXPD_MDL_MDY_CD,
									   LANG_CD,
									   N_PRNT_PBCN_NO,
									   IV_QTY
								FROM TB_SEWHA_IV_INFO
								WHERE CLS_YMD = '20090225'
								AND LANG_CD = 'KO';
	   BEGIN
	   		
			FOR IV_LIST IN PREV_IV_INFO LOOP
				
				UPDATE TB_SEWHA_IV_INFO
				SET IV_QTY = IV_LIST.IV_QTY
				WHERE CLS_YMD = '20090226'
				AND QLTY_VEHL_CD = IV_LIST.QLTY_VEHL_CD
				AND LANG_CD = IV_LIST.LANG_CD
				AND N_PRNT_PBCN_NO = IV_LIST.N_PRNT_PBCN_NO
				AND DL_EXPD_MDL_MDY_CD = IV_LIST.DL_EXPD_MDL_MDY_CD;
			
			END LOOP;
			
			COMMIT;
			
	   END SP_RESET_SEWHA_IV_INFO;
**/ 
	   
	   --국가별 신규 차종, 언어 등록(EXCEL 자료 이용) 
	   PROCEDURE SP_UPDATE_NEW_NATL_LANG_INFO
	   IS
	   	 
		 CURSOR NATL_LANG_EXCEL IS SELECT DL_EXPD_CO_CD,
		 						   		  DL_EXPD_NAT_CD,
										  NAT_NM,
										  QLTY_VEHL_CD,
										  MDL_MDY_CD,
										  LANG_CD_LIST
								   FROM TB_NATL_LANG_EXCEL;
								   
		 V_CNT NUMBER;
		 
		 V_LANG_LIST PG_COMMON.LIST_TYPE;
		 V_LANG_CNT  BINARY_INTEGER;
		  
	   BEGIN
	   		
			FOR NATL_LANG_LIST IN NATL_LANG_EXCEL LOOP
				
				SELECT COUNT(*)
				INTO V_CNT
				FROM TB_VEHL_MGMT
				WHERE QLTY_VEHL_CD = NATL_LANG_LIST.QLTY_VEHL_CD
				AND MDL_MDY_CD = NATL_LANG_LIST.MDL_MDY_CD;
				
				IF V_CNT = 0 THEN
				   
				   RAISE_APPLICATION_ERROR(-20001, 'Vehl info is not exist ' || 
			   								       'vehl:'  || NATL_LANG_LIST.QLTY_VEHL_CD || ',' || 
											       'mkyr:' || NATL_LANG_LIST.MDL_MDY_CD);
											   
				END IF;
				
				--언어코드의 경우에는 , 로 구분지어서 둘 이상이 들어 있을 수 있다. 
				--그런 경우를 대비하여 데이터를 Split 하여 읽어옴 
				
				V_LANG_LIST := PG_COMMON.FU_SPLIT(NATL_LANG_LIST.LANG_CD_LIST, V_LANG_CNT);
				
				FOR LANG_NUM IN 1..V_LANG_CNT LOOP
					
					SELECT COUNT(*)
					INTO V_CNT
					FROM TB_LANG_MGMT
					WHERE QLTY_VEHL_CD = NATL_LANG_LIST.QLTY_VEHL_CD
					AND MDL_MDY_CD = NATL_LANG_LIST.MDL_MDY_CD
					AND LANG_CD = V_LANG_LIST(LANG_NUM);
					
					IF V_CNT = 0 THEN
				   
				   	   RAISE_APPLICATION_ERROR(-20001, 'Lang info is not exist ' || 
			   								           'vehl:' || NATL_LANG_LIST.QLTY_VEHL_CD || ',' || 
											           'mkyr:' || NATL_LANG_LIST.MDL_MDY_CD || ',' ||
													   'lang:' || V_LANG_LIST(LANG_NUM));
											   
				    END IF;
				
				END LOOP;
				
				SELECT COUNT(*)
				INTO V_CNT
				FROM TB_NATL_MGMT
				WHERE DL_EXPD_CO_CD = NATL_LANG_LIST.DL_EXPD_CO_CD
				AND DL_EXPD_NAT_CD  = NATL_LANG_LIST.DL_EXPD_NAT_CD;
				
				IF V_CNT = 0 THEN
				   
				   INSERT INTO TB_NATL_MGMT
				   (DL_EXPD_CO_CD,
				    DL_EXPD_NAT_CD,
					NAT_NM,
					PPRR_EENO,
					FRAM_DTM,
					UPDR_EENO,
					MDFY_DTM
				   )
				   VALUES
				   (NATL_LANG_LIST.DL_EXPD_CO_CD,
				    NATL_LANG_LIST.DL_EXPD_NAT_CD,
					NATL_LANG_LIST.NAT_NM,
					'SYSTEM',
					SYSDATE,
					'SYSTEM',
					SYSDATE
				   );
				   
				END IF;

				PG_NATL_LANG_MGMT.SP_VEHL_LANG_INFO_SAVE(NATL_LANG_LIST.DL_EXPD_CO_CD,
													     NATL_LANG_LIST.DL_EXPD_NAT_CD,
														 '',
														 NATL_LANG_LIST.MDL_MDY_CD,
														 NATL_LANG_LIST.QLTY_VEHL_CD,
														 NATL_LANG_LIST.LANG_CD_LIST,
														 'SYSTEM');
			END LOOP;
			
			--추가된 항목들을 EXCEL 테이블에서 삭제해 준다. 
			DELETE FROM TB_NATL_LANG_EXCEL;
			
			COMMIT;
			
			EXCEPTION
		     WHEN OTHERS THEN
			     ROLLBACK;
				 RAISE;
				 
	   END SP_UPDATE_NEW_NATL_LANG_INFO;
	   
	   
	   --제작준비과정에서 차종코드, 언어코드 오입력시에 수정하는 작업 수행	   
	   --만일 승인완료된 경우 승인취소가 된 뒤에 작업이 이루어져야 함 
	   PROCEDURE SP_CHANGE_PRNT_VEHL_INFO(P_PRNT_PBCN_NO VARCHAR2,
	                                      P_VEHL_CD      VARCHAR2,
										  P_MDL_MDY_CD	 VARCHAR2,
										  P_LANG_CD		 VARCHAR2)
	   IS
	   	 
		 V_IV_QTY1         NUMBER;
	 	 V_IV_QTY2		   NUMBER;
	 	 V_ORD_QTY         NUMBER;
	 	 V_MO_AVG_PRDN_QTY NUMBER;
	 	 
		 V_CURR_YMD        VARCHAR2(8);
		 
	   BEGIN
	   		
	   		UPDATE TB_CHKLIST_DTL_INFO
			SET N_PRNT_PBCN_NO = NULL
			WHERE N_PRNT_PBCN_NO = P_PRNT_PBCN_NO
			AND (QLTY_VEHL_CD <> P_VEHL_CD OR LANG_CD <> P_LANG_CD);
			
			UPDATE TB_PRNT_REQ_INFO
			SET QLTY_VEHL_CD = P_VEHL_CD,
			    MDL_MDY_CD = P_MDL_MDY_CD,
				LANG_CD = P_LANG_CD 
			WHERE N_PRNT_PBCN_NO = P_PRNT_PBCN_NO;
			
			UPDATE TB_PRNT_ALGN_INFO
			SET QLTY_VEHL_CD = P_VEHL_CD,
			    MDL_MDY_CD = P_MDL_MDY_CD,
				LANG_CD = P_LANG_CD
			WHERE N_PRNT_PBCN_NO = P_PRNT_PBCN_NO;
			
			UPDATE TB_PRNT_BKGD_INFO
			SET QLTY_VEHL_CD = P_VEHL_CD,
			    MDL_MDY_CD = P_MDL_MDY_CD,
				LANG_CD = P_LANG_CD
			WHERE N_PRNT_PBCN_NO = P_PRNT_PBCN_NO;
			
			UPDATE TB_PRNT_PAGE_MGMT
			SET QLTY_VEHL_CD = P_VEHL_CD,
			    MDL_MDY_CD = P_MDL_MDY_CD,
				LANG_CD = P_LANG_CD
			WHERE N_PRNT_PBCN_NO = P_PRNT_PBCN_NO;
			
			V_CURR_YMD := TO_CHAR(SYSDATE, 'YYYYMMDD');
			
			--현재의 연식을 취급설명서 연식으로 간주하여 계산해 주도록 한다. 	
			SELECT NVL(SUM(IV_QTY), 0)
			INTO V_IV_QTY1
			FROM TB_SEWHA_IV_INFO
			WHERE QLTY_VEHL_CD = P_VEHL_CD
			AND DL_EXPD_MDL_MDY_CD = P_MDL_MDY_CD
        	AND LANG_CD = P_LANG_CD
			AND CLS_YMD = V_CURR_YMD;			
		
			--현재의 연식을 취급설명서 연식으로 간주하여 계산해 주도록 한다. 
			SELECT NVL(SUM(IV_QTY), 0)
			INTO V_IV_QTY2
			FROM TB_PDI_IV_INFO
			WHERE QLTY_VEHL_CD = P_VEHL_CD
			AND DL_EXPD_MDL_MDY_CD = P_MDL_MDY_CD
        	AND LANG_CD = P_LANG_CD
			AND CLS_YMD = V_CURR_YMD;
		
			--현재의 연식을 취급설명서 연식으로 간주하여 계산해 주도록 한다. 
			--그리고 순수하게 현재 취급서명서 연식의 투입및 오더 수량을 계산해 주도록 한다. 
			SELECT NVL(SUM(TMM_ORD_QTY), 0),
		       	   NVL(SUM(MTH3_MO_AVG_TRWI_QTY), 0)
			INTO V_ORD_QTY,
		     	 V_MO_AVG_PRDN_QTY
            FROM TB_APS_PROD_SUM_INFO
			WHERE QLTY_VEHL_CD = P_VEHL_CD
			AND MDL_MDY_CD = P_MDL_MDY_CD
			AND LANG_CD = P_LANG_CD
			AND APL_YMD = V_CURR_YMD;
			
			UPDATE TB_PRNT_FP_INFO
			SET QLTY_VEHL_CD = P_VEHL_CD,
			    MDL_MDY_CD = P_MDL_MDY_CD,
				LANG_CD = P_LANG_CD,
				IV_QTY = V_IV_QTY1 + V_IV_QTY2,
				ORD_QTY = V_ORD_QTY,
				MO_AVG_PRDN_QTY = V_MO_AVG_PRDN_QTY
			WHERE N_PRNT_PBCN_NO = P_PRNT_PBCN_NO;
			
	   END SP_CHANGE_PRNT_VEHL_INFO;
	   
	   
	   --ABLE_ADM 위한 배치 로그 생성 작업(임시) 
	   PROCEDURE SP_CREATE_BATCH_LOG_TEMP
	   IS
	   	 
		 V_FROM_DATE DATE;
		 V_TO_DATE	 DATE;
		 
		 V_STRT_DATE DATE;
		 V_FNH_DATE  DATE;
		 
		 V_CNT		 NUMBER;
		 
		 V_STRT_CHAR VARCHAR2(10);
		 V_FNH_CHAR  VARCHAR2(10);
		 
	   BEGIN

			V_FROM_DATE := TO_DATE('20081018', 'YYYYMMDD');
			V_TO_DATE   := TO_DATE('20090320', 'YYYYMMDD');
			
			V_CNT := ROUND(V_TO_DATE - V_FROM_DATE);

			FOR NUM IN 0..V_CNT LOOP 
				
				--[ALC마스터배치작업_H/KMC] 
				--V_STRT_DATE := TO_DATE(TO_CHAR(V_FROM_DATE + NUM, 'YYYYMMDD') || '0600' || GET_RANDOM_NUM('M', 0, 6), 'YYYYMMDDHH24MISS');
				--V_FNH_DATE  := TO_DATE(TO_CHAR(V_FROM_DATE + NUM, 'YYYYMMDD') || '06' || GET_RANDOM_NUM('M', 3, 2) || GET_RANDOM_NUM('S', 0, 0), 'YYYYMMDDHH24MISS');
				
				--[APS 배치작업] 
				--V_STRT_DATE := TO_DATE(TO_CHAR(V_FROM_DATE + NUM, 'YYYYMMDD') || '0900' || GET_RANDOM_NUM('M', 2, 5), 'YYYYMMDDHH24MISS');
				--V_FNH_DATE  := TO_DATE(TO_CHAR(V_FROM_DATE + NUM, 'YYYYMMDD') || '09' || GET_RANDOM_NUM('M', 2, 4) || GET_RANDOM_NUM('S', 0, 0), 'YYYYMMDDHH24MISS');
				
				--[일자변경 배치] 
				SP_GET_RANDOM_NUM(V_STRT_CHAR, V_FNH_CHAR);
				V_STRT_DATE := TO_DATE(TO_CHAR(V_FROM_DATE + NUM, 'YYYYMMDD') || '0000' || V_STRT_CHAR, 'YYYYMMDDHH24MISS');
				V_FNH_DATE  := TO_DATE(TO_CHAR(V_FROM_DATE + NUM, 'YYYYMMDD') || '0000' || V_FNH_CHAR, 'YYYYMMDDHH24MISS');
				
				--V_STRT_DATE := TO_DATE(TO_CHAR(V_FROM_DATE + NUM, 'YYYYMMDD') || '0900' || GET_RANDOM_NUM('M', 2, 5), 'YYYYMMDDHH24MISS');
				--V_FNH_DATE  := TO_DATE(TO_CHAR(V_FROM_DATE + NUM, 'YYYYMMDD') || '09' || GET_RANDOM_NUM('M', 2, 4) || GET_RANDOM_NUM('S', 0, 0), 'YYYYMMDDHH24MISS');
				
				INSERT INTO TB_BATCH_RSLT_INFO
				(BTCH_NM,
				 BTCH_FIN_STRT_DTM,
				 BTCH_FNH_DTM,
				 BTCH_WK_CD,
				 BTCH_WK_RSLT_SBC
				)
				VALUES
				('생산마스터일자변경배치작업_HMC',
				 V_STRT_DATE,
				 V_FNH_DATE,
				 'S',
				 '배치처리완료'
				);
				
			END LOOP;
			
			COMMIT;
			
			EXCEPTION
		     WHEN OTHERS THEN
			     ROLLBACK;
				 RAISE;
			
	   END SP_CREATE_BATCH_LOG_TEMP;
	   
	   PROCEDURE SP_CREATE_BATCH_LOG_TEMP2(P_FROM_YMD VARCHAR2,
	   			 						   P_TO_YMD   VARCHAR2)
	   IS
	   	 
		 CURSOR TEMP_LOG_INFO IS SELECT  A.WK_YMD,
			   	 					  	 (SELECT COUNT(*)
			    						  FROM TB_APS_ODR_SUM_INFO B
										  WHERE APL_STRT_YMD <= A.WK_YMD AND APL_FNH_YMD >= A.WK_YMD
										  AND EXISTS (SELECT 'EXIST'
		                    			  	  		  FROM TB_VEHL_MGMT
					        						  WHERE QLTY_VEHL_CD = B.QLTY_VEHL_CD
					        						  AND DL_EXPD_CO_CD = '01'
				            						  AND ROWNUM <= 1
				                                     )
			    						 ) AS CNT1,
			   							 (SELECT COUNT(*)
			    						  FROM TB_APS_ODR_SUM_INFO B
										  WHERE APL_STRT_YMD <= A.WK_YMD AND APL_FNH_YMD >= A.WK_YMD
										  AND EXISTS (SELECT 'EXIST'
		                    			  	          FROM TB_VEHL_MGMT
					        						  WHERE QLTY_VEHL_CD = B.QLTY_VEHL_CD
					        						  AND DL_EXPD_CO_CD = '02'
				            						  AND ROWNUM <= 1
				                                     )
			    						 ) AS CNT2,
										 (SELECT COUNT(*)
				 						  FROM TB_PROD_MST_SUM_INFO B
				 						  WHERE APL_YMD = A.WK_YMD
				 						  AND EXISTS (SELECT 'EXIST'
		                     			  	  		  FROM TB_VEHL_MGMT
					         			  			  WHERE QLTY_VEHL_CD = B.QLTY_VEHL_CD
					         			  			  AND DL_EXPD_CO_CD = '01'
				             			  			  AND ROWNUM <= 1
				            			 			 )
										 ) AS CNT3,
										 (SELECT COUNT(*)
				 						  FROM TB_PROD_MST_SUM_INFO B
				 						  WHERE APL_YMD = A.WK_YMD
				 						  AND EXISTS (SELECT 'EXIST'
		                     			  	  		  FROM TB_VEHL_MGMT
					         						  WHERE QLTY_VEHL_CD = B.QLTY_VEHL_CD
					         						  AND DL_EXPD_CO_CD = '02'
				             						  AND ROWNUM <= 1
				            						 )
										 ) AS CNT4,
										 (SELECT COUNT(*)
				 						  FROM TB_SEWHA_IV_INFO
				 						  WHERE CLS_YMD = A.WK_YMD
										 ) AS CNT5,
										 (SELECT COUNT(*)
				 						  FROM TB_PDI_IV_INFO
				 						  WHERE CLS_YMD = A.WK_YMD
										 ) AS CNT6,
										 (SELECT COUNT(*)
										  FROM TB_ALC_MST_INFO
										  WHERE T10PS1_YMDHM BETWEEN TO_CHAR(TO_DATE(A.WK_YMD, 'YYYYMMDD') - 1, 'YYYYMMDD') || '090001' AND A.WK_YMD || '060000'
										 ) AS CNT7,
										 (SELECT COUNT(*)
		        						  FROM TB_APS_ODR_INFO
										  WHERE APL_STRT_YMD <= A.WK_YMD AND APL_FNH_YMD >= A.WK_YMD
										  AND DL_EXPD_CO_CD ='01'
			   							 ) AS CNT8,
			   							 (SELECT COUNT(*)
		        						  FROM TB_APS_ODR_INFO
										  WHERE APL_STRT_YMD <= A.WK_YMD AND APL_FNH_YMD >= A.WK_YMD
										  AND DL_EXPD_CO_CD ='02'
			   							 ) AS CNT9,
										 (SELECT COUNT(*)
										  FROM TB_ALC_MST_INFO
										  WHERE T10PS1_YMDHM BETWEEN A.WK_YMD || '060001' AND A.WK_YMD || '090000'
										  AND DL_EXPD_CO_CD = '01'
										 ) AS CNT10,
										 (SELECT COUNT(*)
										  FROM TB_ALC_MST_INFO
										  WHERE T10PS1_YMDHM BETWEEN A.WK_YMD || '060001' AND A.WK_YMD || '090000'
										  AND DL_EXPD_CO_CD = '02'
										 ) AS CNT11,
			   							 (SELECT COUNT(*)
		        						  FROM TB_PROD_MST_INFO
										  WHERE APL_YMD = TO_CHAR(TO_DATE(A.WK_YMD, 'YYYYMMDD') - 1, 'YYYYMMDD')
										  AND DL_EXPD_CO_CD ='01'
			   							 ) AS CNT12,
			   							 (SELECT COUNT(*)
		        						  FROM TB_PROD_MST_INFO
										  WHERE APL_YMD = TO_CHAR(TO_DATE(A.WK_YMD, 'YYYYMMDD') - 1, 'YYYYMMDD')
										  AND DL_EXPD_CO_CD ='02'
			   							 ) AS CNT13
								 FROM TB_WRK_DATE_MGMT A
								 WHERE WK_YMD BETWEEN P_FROM_YMD AND P_TO_YMD;
				
	   BEGIN
	   		
			DELETE FROM TB_ABLE_ADM_LOG_TEMP;
			
			FOR LOG_LIST IN TEMP_LOG_INFO LOOP
				
				INSERT INTO TB_ABLE_ADM_LOG_TEMP
				VALUES(LOG_LIST.WK_YMD, '01', 365);
				
				INSERT INTO TB_ABLE_ADM_LOG_TEMP
				VALUES(LOG_LIST.WK_YMD, '02', LOG_LIST.CNT1);
				
				INSERT INTO TB_ABLE_ADM_LOG_TEMP
				VALUES(LOG_LIST.WK_YMD, '03', LOG_LIST.CNT2);
				
				INSERT INTO TB_ABLE_ADM_LOG_TEMP
				VALUES(LOG_LIST.WK_YMD, '04', LOG_LIST.CNT3);
				
				INSERT INTO TB_ABLE_ADM_LOG_TEMP
				VALUES(LOG_LIST.WK_YMD, '05', LOG_LIST.CNT4);
				
				INSERT INTO TB_ABLE_ADM_LOG_TEMP
				VALUES(LOG_LIST.WK_YMD, '06', LOG_LIST.CNT5);
				
				INSERT INTO TB_ABLE_ADM_LOG_TEMP
				VALUES(LOG_LIST.WK_YMD, '07', LOG_LIST.CNT6);
				
				INSERT INTO TB_ABLE_ADM_LOG_TEMP
				VALUES(LOG_LIST.WK_YMD, '08', LOG_LIST.CNT7);
				
				INSERT INTO TB_ABLE_ADM_LOG_TEMP
				VALUES(LOG_LIST.WK_YMD, '09', LOG_LIST.CNT8);
				
				INSERT INTO TB_ABLE_ADM_LOG_TEMP
				VALUES(LOG_LIST.WK_YMD, '10', LOG_LIST.CNT9);
				
				INSERT INTO TB_ABLE_ADM_LOG_TEMP
				VALUES(LOG_LIST.WK_YMD, '11', LOG_LIST.CNT10);
				
				INSERT INTO TB_ABLE_ADM_LOG_TEMP
				VALUES(LOG_LIST.WK_YMD, '12', LOG_LIST.CNT11);
				
				INSERT INTO TB_ABLE_ADM_LOG_TEMP
				VALUES(LOG_LIST.WK_YMD, '13', LOG_LIST.CNT12);
				
				INSERT INTO TB_ABLE_ADM_LOG_TEMP
				VALUES(LOG_LIST.WK_YMD, '14', LOG_LIST.CNT13);
				
			END LOOP;
			
			COMMIT;
			
	   END SP_CREATE_BATCH_LOG_TEMP2;
	   
	   --랜덤 시간 정보 임시 생성 프로시저1 
	   PROCEDURE SP_GET_RANDOM_NUM(P_STRT_CHAR OUT VARCHAR2,
	                               P_FNH_CHAR  OUT VARCHAR2)
	   IS
	   	 
		 V_STRT_NUM NUMBER;
		 
	   BEGIN
	   
	   		V_STRT_NUM := 1 + ABS(MOD(DBMS_RANDOM.RANDOM, 6));
			
			P_STRT_CHAR := TO_CHAR(V_STRT_NUM, '00');
			
			P_FNH_CHAR := GET_RANDOM_NUM('M', V_STRT_NUM, 2);
	   		
	   END SP_GET_RANDOM_NUM;
	   
	   --랜덤 시간 정보 임시 생성 프로시저2 							   
	   FUNCTION GET_RANDOM_NUM(P_MODE     CHAR,
	   						   P_SEED_NUM NUMBER,
	   						   P_DIV_NUM  NUMBER)RETURN VARCHAR2
	   IS
	   	 
		 V_NUM_CHAR VARCHAR2(10);
		 		 
	   BEGIN
	   		
			--분 단위 RANDOM 값 조회 
			IF P_MODE = 'M' THEN
			   
			   V_NUM_CHAR := TO_CHAR(P_SEED_NUM + ABS(MOD(DBMS_RANDOM.RANDOM, P_DIV_NUM)), '00');
			
			--초 단위 RANDOM 값 조회 
			ELSIF P_MODE = 'S' THEN
			   
			   V_NUM_CHAR := TO_CHAR(P_SEED_NUM + ABS(MOD(DBMS_RANDOM.RANDOM, 60)), '00');
			   
			END IF;
			
			RETURN V_NUM_CHAR;
			
	   END GET_RANDOM_NUM;
	   
	   --생산마스터진행정보 테이블의 데이터 삭제 
	   PROCEDURE SP_RESET_PROD_PROG_INFO(P_USF_CD VARCHAR2)
	   IS
	   BEGIN
	   		
			DELETE FROM TB_PROD_MST_PROG_INFO
			WHERE USF_CD = 'D';
			
			COMMIT;
			
	   END SP_RESET_PROD_PROG_INFO;
	   
	   --생산계획 데이터 일자별 임시 생성 - 2010.08.18.김동근 양희주 과장 요청으로 특정 오더번호에 해당하는 생산계획 데이터 임시 생성
	   PROCEDURE GET_APS_PROD_SUM2(CURR_YMD   IN VARCHAR2,
	                               EXPD_CO_CD IN VARCHAR2)
	   IS
	   
	   	 V_APL_FNH_YMD VARCHAR2(8);
		  
		 V_MDL_MDY_CD  VARCHAR2(2);
		 
		 V_CNT		   NUMBER;

		 --생산계획 데이터 조회를 위한 부분
		 --(PDI 공통차종 오더내역 조회 부분 포함) 
		 --[작업순서]
		 --1. TRUNCATE TABLE TB_PRDN_ORD_NO_EXCEL;
		 --   TRUNCATE TABLE TB_PRDN_ORD_NO_TEMP;
		 --2. 엑셀자료 입력
		 --3. INSERT INTO TB_PRDN_ORD_NO_TEMP
         --   SELECT SUBSTR(PRDN_ORD_NO, 1, 9), BASC_MDL_CD, DEST_NAT_CD, ORD_QTY, PRDN_QTY, PRDN_PLN_QTY,
         --   SUBSTR(PRDN_ORD_NO, 10, LENGTH(PRDN_ORD_NO) - 9)
         --   FROM TB_PRDN_ORD_NO_EXCEL;
		 --4. 아래의 프로시저 실행 						 
	   	 CURSOR APS_PROD_INFO IS WITH T AS (SELECT A.PRDN_ORD_NO,
		 					  	 	  	   		   A.QLTY_VEHL_CD,
		 					  	           		   A.MDL_MDY_CD,
		 					  	 				   B.LANG_CD, 
       								    		   A.PLN_PARR_YMD,
       								    		   SUM(A.PRDN_PLN_QTY) AS PRDN_PLN_QTY,
       											   MIN(A.DCSN_YN) AS DCSN_YN,
												   MAX(A.DCSN_YMD) AS DCSN_YMD
		 					  	 			FROM (SELECT A.PRDN_ORD_NO,
												 		 A.QLTY_VEHL_CD,
								 	  		  	 		 A.MDL_MDY_CD,
											  			 A.DL_EXPD_NAT_CD AS EXPD_NAT_CD,
											  			 A.PLN_PARR_YMD,
											  			 SUM(A.PRDN_PLN_QTY) AS PRDN_PLN_QTY,
											  			 MIN(A.DCSN_YN) AS DCSN_YN,
											  			 MAX(A.DCSN_YMD) AS DCSN_YMD
									   			  FROM TB_APS_PROD_PLAN_INFO A,
												  	   TB_PRDN_ORD_NO_TEMP B
									   			  WHERE DL_EXPD_CO_CD = EXPD_CO_CD
                                       			  AND APL_STRT_YMD <= CURR_YMD
                                       			  AND APL_FNH_YMD >= CURR_YMD
									   			  AND QLTY_VEHL_CD IS NOT NULL   --현재 사용중인 차종에 대해서만 가져오도록 한다. 
									   			  AND MDL_MDY_CD IS NOT NULL     --연식이 지정된 항목만 가져온다.
									   			  AND DL_EXPD_NAT_CD IS NOT NULL --취급설명서국가코드가 등록된 항목만 가져온다.
												  AND A.PRDN_ORD_NO = B.PRDN_ORD_NO
												  --AND A.DYTM_PLN_NAT_CD = B.DYTM_PLN_NAT_CD
									   			  AND A.DEST_NAT_CD = B.DEST_NAT_CD
												  GROUP BY A.PRDN_ORD_NO,
												  		   A.QLTY_VEHL_CD,
									  		      		   A.MDL_MDY_CD,
														   A.PLN_PARR_YMD,
       													   A.DL_EXPD_NAT_CD
								      			 ) A,
									  			 TB_NATL_LANG_MGMT B
								            WHERE A.EXPD_NAT_CD = B.DL_EXPD_NAT_CD
								 			AND B.DL_EXPD_CO_CD = EXPD_CO_CD
								 			AND A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
								 			AND A.MDL_MDY_CD = B.MDL_MDY_CD
								 			GROUP BY A.PRDN_ORD_NO, A.QLTY_VEHL_CD, A.MDL_MDY_CD, B.LANG_CD, A.PLN_PARR_YMD
		 					  	 	  	   )
								 SELECT PRDN_ORD_NO,
								 		QLTY_VEHL_CD,
								 		MDL_MDY_CD,
										LANG_CD,
										PLN_PARR_YMD,
										PRDN_PLN_QTY,
										DCSN_YN,
										DCSN_YMD
								 FROM T;								 				 
	   BEGIN
	   		
			/****
			
			--과거일에 입력되었으나 데이터가 변경되지 않아서 현재일 이후로 종료일이 설정 되어 있는 경우에는
			--종료일을 하루전으로 설정해 준다. 
			UPDATE TB_APS_PROD_PLAN_SUM_TEMP A
			SET A.APL_FNH_YMD = TO_CHAR(TO_DATE(CURR_YMD, 'YYYYMMDD') - 1, 'YYYYMMDD')
			WHERE A.APL_STRT_YMD < CURR_YMD
			AND A.APL_FNH_YMD >= CURR_YMD
			AND EXISTS (SELECT 'EXIST'
                        FROM TB_VEHL_MGMT
			            WHERE QLTY_VEHL_CD = A.QLTY_VEHL_CD
			            AND DL_EXPD_CO_CD = EXPD_CO_CD
		                AND ROWNUM <= 1
		               );
			
			--현재일에 순수하게 입력된 항목은 삭제하도록 한다.
			DELETE FROM TB_APS_PROD_PLAN_SUM_TEMP A
			WHERE A.APL_STRT_YMD = CURR_YMD
			AND A.APL_FNH_YMD >= CURR_YMD
			AND EXISTS (SELECT 'EXIST'
                        FROM TB_VEHL_MGMT
			            WHERE QLTY_VEHL_CD = A.QLTY_VEHL_CD
			            AND DL_EXPD_CO_CD = EXPD_CO_CD
		                AND ROWNUM <= 1
		               );
			
			--[추가] 2010.04.15.김동근 생산계획정보 현황 - 공장별 내역 삭제 기능 추가 
			
			UPDATE TB_APS_PROD_PLAN_SUM_TEMP A
			SET A.APL_FNH_YMD = TO_CHAR(TO_DATE(CURR_YMD, 'YYYYMMDD') - 1, 'YYYYMMDD')
			WHERE A.APL_STRT_YMD < CURR_YMD
			AND A.APL_FNH_YMD >= CURR_YMD
			AND EXISTS (SELECT 'EXIST'
                        FROM TB_VEHL_MGMT
			            WHERE QLTY_VEHL_CD = A.QLTY_VEHL_CD
			            AND DL_EXPD_CO_CD = EXPD_CO_CD
		                AND ROWNUM <= 1
		               );
			
			DELETE FROM TB_APS_PROD_PLAN_SUM_TEMP A
			WHERE A.APL_STRT_YMD = CURR_YMD
			AND A.APL_FNH_YMD >= CURR_YMD
			AND EXISTS (SELECT 'EXIST'
                        FROM TB_VEHL_MGMT
			            WHERE QLTY_VEHL_CD = A.QLTY_VEHL_CD
			            AND DL_EXPD_CO_CD = EXPD_CO_CD
		                AND ROWNUM <= 1
		               );
					   	   
			FOR PROD_LIST IN APS_PROD_INFO LOOP
				
			   --변경여부를 검사할 데이터가 존재하는지의 여부를 확인 
			   SELECT MAX(APL_FNH_YMD)
			   INTO V_APL_FNH_YMD
			   FROM TB_APS_PROD_PLAN_SUM_TEMP A
			   WHERE A.APL_STRT_YMD <= CURR_YMD
			   AND A.APL_FNH_YMD <= CURR_YMD --현재일 이전의 데이터에서 조회하도록 한다...
			   AND A.PLN_PARR_YMD = PROD_LIST.PLN_PARR_YMD
		       AND A.QLTY_VEHL_CD = PROD_LIST.QLTY_VEHL_CD
		       AND A.MDL_MDY_CD = PROD_LIST.MDL_MDY_CD
		       AND A.LANG_CD = PROD_LIST.LANG_CD;
			   
			   IF V_APL_FNH_YMD IS NULL THEN
			   	  
				  --지금까지 한번도 추가되지 않은 경우(무조건 Insert 해 준다.) 
				  
				  INSERT INTO TB_APS_PROD_PLAN_SUM_TEMP
   		    	  (APL_STRT_YMD,
				   APL_FNH_YMD,
				   PLN_PARR_YMD,
				   DATA_SN,
   				   QLTY_VEHL_CD,
   			 	   MDL_MDY_CD,
   			 	   LANG_CD,
   			 	   PRDN_PLN_QTY,
				   DCSN_YN,
				   DCSN_YMD,
   			 	   FRAM_DTM
   				  )
				  SELECT CURR_YMD,
				         CURR_YMD,
						 PROD_LIST.PLN_PARR_YMD,
				         A.DATA_SN,
						 PROD_LIST.QLTY_VEHL_CD,
						 PROD_LIST.MDL_MDY_CD,
						 PROD_LIST.LANG_CD,
						 PROD_LIST.PRDN_PLN_QTY,
						 PROD_LIST.DCSN_YN,
						 PROD_LIST.DCSN_YMD,
						 SYSDATE
				  FROM TB_LANG_MGMT A
				  WHERE A.QLTY_VEHL_CD = PROD_LIST.QLTY_VEHL_CD
				  AND A.MDL_MDY_CD = PROD_LIST.MDL_MDY_CD
				  AND A.LANG_CD = PROD_LIST.LANG_CD;
			   
			   ELSE
			   	   
				   --바로이전의 데이터가 변경되지 않은 경우에는 종료일 업데이트만 해준다.
				
			   	   UPDATE TB_APS_PROD_PLAN_SUM_TEMP A
		 	   	   SET APL_FNH_YMD = CURR_YMD --적용완료일을 현재일로 해준다.
			   	   WHERE A.APL_STRT_YMD <= CURR_YMD
			   	   AND A.APL_FNH_YMD = V_APL_FNH_YMD
			   	   AND A.PLN_PARR_YMD = PROD_LIST.PLN_PARR_YMD
		       	   AND A.QLTY_VEHL_CD = PROD_LIST.QLTY_VEHL_CD
		       	   AND A.MDL_MDY_CD = PROD_LIST.MDL_MDY_CD
		       	   AND A.LANG_CD = PROD_LIST.LANG_CD
				   AND A.PRDN_PLN_QTY = PROD_LIST.PRDN_PLN_QTY
				   AND A.DCSN_YN = PROD_LIST.DCSN_YN
				   AND A.DCSN_YMD = PROD_LIST.DCSN_YMD;
				   
				   IF SQL%NOTFOUND THEN
				   	  
					  INSERT INTO TB_APS_PROD_PLAN_SUM_TEMP
   		    	  	  (APL_STRT_YMD,
				   	   APL_FNH_YMD,
				   	   PLN_PARR_YMD,
				   	   DATA_SN,
   				   	   QLTY_VEHL_CD,
   			 	   	   MDL_MDY_CD,
   			 	   	   LANG_CD,
   			 	   	   PRDN_PLN_QTY,
				   	   DCSN_YN,
				   	   DCSN_YMD,
   			 	   	   FRAM_DTM
   				  	  )
				  	  SELECT CURR_YMD,
				             CURR_YMD,
						     PROD_LIST.PLN_PARR_YMD,
				             A.DATA_SN,
						     PROD_LIST.QLTY_VEHL_CD,
						     PROD_LIST.MDL_MDY_CD,
						     PROD_LIST.LANG_CD,
						     PROD_LIST.PRDN_PLN_QTY,
						     PROD_LIST.DCSN_YN,
						     PROD_LIST.DCSN_YMD,
						     SYSDATE
				     FROM TB_LANG_MGMT A
				     WHERE A.QLTY_VEHL_CD = PROD_LIST.QLTY_VEHL_CD
				     AND A.MDL_MDY_CD = PROD_LIST.MDL_MDY_CD
				     AND A.LANG_CD = PROD_LIST.LANG_CD;
				  
				   END IF;
			    
			   END IF;

			END LOOP;
			
			--[추가] 2010.04.15.김동근 생산계획정보 현황 - 공장별 내역 저장 
			FOR PLNT_PROD_LIST IN PLNT_PROD_INFO LOOP
				
			   --변경여부를 검사할 데이터가 존재하는지의 여부를 확인 
			   SELECT MAX(APL_FNH_YMD)
			   INTO V_APL_FNH_YMD
			   FROM TB_PLNT_APS_PROD_PLAN_SUM_TEMP A
			   WHERE A.APL_STRT_YMD <= CURR_YMD
			   AND A.APL_FNH_YMD <= CURR_YMD --현재일 이전의 데이터에서 조회하도록 한다...
			   AND A.PLN_PARR_YMD = PLNT_PROD_LIST.PLN_PARR_YMD
		       AND A.QLTY_VEHL_CD = PLNT_PROD_LIST.QLTY_VEHL_CD
		       AND A.MDL_MDY_CD = PLNT_PROD_LIST.MDL_MDY_CD
		       AND A.LANG_CD = PLNT_PROD_LIST.LANG_CD
			   AND A.PRDN_PLNT_CD = PLNT_PROD_LIST.PRDN_PLNT_CD;
			   
			   IF V_APL_FNH_YMD IS NULL THEN
			   	  
				  --지금까지 한번도 추가되지 않은 경우(무조건 Insert 해 준다.) 
				  
				  INSERT INTO TB_PLNT_APS_PROD_PLAN_SUM_TEMP
   		    	  (APL_STRT_YMD,
				   APL_FNH_YMD,
				   PLN_PARR_YMD,
				   DATA_SN,
   				   QLTY_VEHL_CD,
   			 	   MDL_MDY_CD,
   			 	   LANG_CD,
   			 	   PRDN_PLN_QTY,
				   DCSN_YN,
				   DCSN_YMD,
   			 	   FRAM_DTM,
				   PRDN_PLNT_CD
   				  )
				  SELECT CURR_YMD,
				         CURR_YMD,
						 PLNT_PROD_LIST.PLN_PARR_YMD,
				         A.DATA_SN,
						 PLNT_PROD_LIST.QLTY_VEHL_CD,
						 PLNT_PROD_LIST.MDL_MDY_CD,
						 PLNT_PROD_LIST.LANG_CD,
						 PLNT_PROD_LIST.PRDN_PLN_QTY,
						 PLNT_PROD_LIST.DCSN_YN,
						 PLNT_PROD_LIST.DCSN_YMD,
						 SYSDATE,
						 PLNT_PROD_LIST.PRDN_PLNT_CD
				  FROM TB_LANG_MGMT A
				  WHERE A.QLTY_VEHL_CD = PLNT_PROD_LIST.QLTY_VEHL_CD
				  AND A.MDL_MDY_CD = PLNT_PROD_LIST.MDL_MDY_CD
				  AND A.LANG_CD = PLNT_PROD_LIST.LANG_CD;
			   
			   ELSE
			   	   
				   --바로이전의 데이터가 변경되지 않은 경우에는 종료일 업데이트만 해준다.
				
			   	   UPDATE TB_PLNT_APS_PROD_PLAN_SUM_TEMP A
		 	   	   SET APL_FNH_YMD = CURR_YMD --적용완료일을 현재일로 해준다.
			   	   WHERE A.APL_STRT_YMD <= CURR_YMD
			   	   AND A.APL_FNH_YMD = V_APL_FNH_YMD
			   	   AND A.PLN_PARR_YMD = PLNT_PROD_LIST.PLN_PARR_YMD
		       	   AND A.QLTY_VEHL_CD = PLNT_PROD_LIST.QLTY_VEHL_CD
		       	   AND A.MDL_MDY_CD = PLNT_PROD_LIST.MDL_MDY_CD
		       	   AND A.LANG_CD = PLNT_PROD_LIST.LANG_CD
				   AND A.PRDN_PLN_QTY = PLNT_PROD_LIST.PRDN_PLN_QTY
				   AND A.DCSN_YN = PLNT_PROD_LIST.DCSN_YN
				   AND A.DCSN_YMD = PLNT_PROD_LIST.DCSN_YMD
				   AND A.PRDN_PLNT_CD = PLNT_PROD_LIST.PRDN_PLNT_CD;
				   
				   IF SQL%NOTFOUND THEN
				   	  
					  INSERT INTO TB_PLNT_APS_PROD_PLAN_SUM_TEMP
   		    	  	  (APL_STRT_YMD,
				   	   APL_FNH_YMD,
				   	   PLN_PARR_YMD,
				   	   DATA_SN,
   				   	   QLTY_VEHL_CD,
   			 	   	   MDL_MDY_CD,
   			 	   	   LANG_CD,
   			 	   	   PRDN_PLN_QTY,
				   	   DCSN_YN,
				   	   DCSN_YMD,
   			 	   	   FRAM_DTM,
					   PRDN_PLNT_CD
   				  	  )
				  	  SELECT CURR_YMD,
				             CURR_YMD,
						     PLNT_PROD_LIST.PLN_PARR_YMD,
				             A.DATA_SN,
						     PLNT_PROD_LIST.QLTY_VEHL_CD,
						     PLNT_PROD_LIST.MDL_MDY_CD,
						     PLNT_PROD_LIST.LANG_CD,
						     PLNT_PROD_LIST.PRDN_PLN_QTY,
						     PLNT_PROD_LIST.DCSN_YN,
						     PLNT_PROD_LIST.DCSN_YMD,
						     SYSDATE,
							 PLNT_PROD_LIST.PRDN_PLNT_CD
				     FROM TB_LANG_MGMT A
				     WHERE A.QLTY_VEHL_CD = PLNT_PROD_LIST.QLTY_VEHL_CD
				     AND A.MDL_MDY_CD = PLNT_PROD_LIST.MDL_MDY_CD
				     AND A.LANG_CD = PLNT_PROD_LIST.LANG_CD;
				  
				   END IF;
			    
			   END IF;

			END LOOP;
			
			COMMIT;
			
			****/
			
			RETURN;
			
		END GET_APS_PROD_SUM2;
		
	   /**********************************************************************************
	    [사용보류] 검증되지 않았음
			
	   --연식재지정시(배치가 실행된 직후에 연식을 임의로 변경한 경우)에 이미 배치돌았던 작업을 원복하는 프로시저 
	   PROCEDURE SP_RESET_IF_VEHL_IV_INFO(P_VEHL_CD VARCHAR2,
	                                      P_CURR_YMD VARCHAR2)
	   IS
	   
	   	 CURSOR PDI_WHOT_INFO IS SELECT WHOT_YMD,
		 						   		QLTY_VEHL_CD,
										DL_EXPD_MDL_MDY_CD,
										LANG_CD,
										N_PRNT_PBCN_NO,
										DTL_SN,
										DL_EXPD_WHOT_QTY,
										MDL_MDY_CD
								      FROM TB_PDI_WHOT_INFO
									  WHERE QLTY_VEHL_CD = P_VEHL_CD
									  AND DL_EXPD_WHOT_ST_CD = '01'
									  AND TO_CHAR(MDFY_DTM, 'YYYYMMDD') = P_CURR_YMD;
								   
	   BEGIN
	   		
			FOR PDI_WHOT_LIST IN PDI_WHOT_INFO LOOP
			
			
				PG_DATA.SP_PDI_IV_INFO_UPDATE(PDI_WHOT_LIST.QLTY_VEHL_CD,
	   			 					   		  PDI_WHOT_LIST.MDL_MDY_CD,
							                  PDI_WHOT_LIST.LANG_CD,
									          PDI_WHOT_LIST.DL_EXPD_MDL_MDY_CD,
								              PDI_WHOT_LIST.N_PRNT_PBCN_NO,
								              PDI_WHOT_LIST.WHOT_YMD,
								              PDI_WHOT_LIST.DL_EXPD_WHOT_QTY * (-1),
									          'Y',
									          'Y',
								       		  'SYSTEM');
											  
				DELETE FROM TB_PDI_WHOT_INFO
				WHERE WHOT_YMD = PDI_WHOT_LIST.WHOT_YMD
				AND QLTY_VEHL_CD = PDI_WHOT_LIST.QLTY_VEHL_CD
				AND DL_EXPD_MDL_MDY_CD = PDI_WHOT_LIST.DL_EXPD_MDL_MDY_CD
				AND LANG_CD = PDI_WHOT_LIST.LANG_CD
				AND N_PRNT_PBCN_NO = PDI_WHOT_LIST.N_PRNT_PBCN_NO
				AND DTL_SN = PDI_WHOT_LIST.DTL_SN
				AND MDL_MDY_CD = PDI_WHOT_LIST.MDL_MDY_CD;
									   
			END LOOP;
			
			COMMIT;
			
			EXCEPTION
		     WHEN OTHERS THEN
			     ROLLBACK;
				 RAISE;
			
	   END SP_RESET_IF_VEHL_IV_INFO;
	   
	   --세원 출고정보 오입력 대비 PDI(글로비스) 입고 내역 취소 작업 수행 프로시저 
	   PROCEDURE SP_RESET_SEWHA_IN_OUT_IV_INFO(P_LANG_CD VARCHAR2,
	   			 							   P_WHSN_YMD VARCHAR2)
	   IS
	   	 CURSOR PDI_WHSN_INFO IS SELECT QLTY_VEHL_CD,
										DL_EXPD_MDL_MDY_CD,
										LANG_CD,
										N_PRNT_PBCN_NO,
										DTL_SN,
										WHSN_YMD,
										WHSN_QTY,
										MDL_MDY_CD
								 FROM TB_PDI_WHSN_INFO
							     WHERE WHSN_YMD = P_WHSN_YMD
								 AND LANG_CD = P_LANG_CD;
	   BEGIN
	   		
			FOR PDI_WHSN_LIST IN PDI_WHSN_INFO LOOP
				
				--PDI 재고 수량 보정 
				PG_DATA.SP_PDI_IV_INFO_UPDATE(PDI_WHSN_LIST.QLTY_VEHL_CD,
	   			 					   		  PDI_WHSN_LIST.MDL_MDY_CD,
							                  PDI_WHSN_LIST.LANG_CD,
									          PDI_WHSN_LIST.DL_EXPD_MDL_MDY_CD,
								              PDI_WHSN_LIST.N_PRNT_PBCN_NO,
								              PDI_WHSN_LIST.WHSN_YMD,
								              PDI_WHSN_LIST.WHSN_QTY * (-1),
									          'N',
									          'N',
								       		  'SYSTEM');
				
				--세원 재고 수량 보정 
				PG_DATA.SP_SEWHA_IV_INFO_UPDATE(PDI_WHSN_LIST.QLTY_VEHL_CD,
	   			 					            PDI_WHSN_LIST.MDL_MDY_CD,
									            PDI_WHSN_LIST.LANG_CD,
										        PDI_WHSN_LIST.DL_EXPD_MDL_MDY_CD,
									     		PDI_WHSN_LIST.N_PRNT_PBCN_NO,
									     		PDI_WHSN_LIST.WHSN_YMD,
									     		PDI_WHSN_LIST.WHSN_QTY * (-1),
									     		'SYSTEM',
										 		'Y');
				
				--PDI 입고 확인 정보 제거 							  
				DELETE FROM TB_PDI_WHSN_INFO
				WHERE QLTY_VEHL_CD = PDI_WHSN_LIST.QLTY_VEHL_CD
				AND DL_EXPD_MDL_MDY_CD = PDI_WHSN_LIST.DL_EXPD_MDL_MDY_CD
				AND LANG_CD = PDI_WHSN_LIST.LANG_CD
				AND N_PRNT_PBCN_NO = PDI_WHSN_LIST.N_PRNT_PBCN_NO
				AND DTL_SN = PDI_WHSN_LIST.DTL_SN
				AND MDL_MDY_CD = PDI_WHSN_LIST.MDL_MDY_CD;
								   
			END LOOP;
			
	   END SP_RESET_SEWHA_IN_OUT_IV_INFO;
	   
	   **********************************************************************************/ 
	   
	   --자바 ADO 패키지 작성용 테스트 프로시저 							   
	   PROCEDURE SP_SELECT_TEST(RS OUT REFCUR)
	   IS
	   	 V_VEHL_LIST1    VARCHAR2(100);
		 
	   BEGIN
	   		
	   		V_VEHL_LIST1 := 'AM,SL,HD';
			
			OPEN RS FOR
				 SELECT A.*, NULL AS SAMPL
				 FROM TB_VEHL_MGMT A
				 WHERE PG_MAKE_DATA.FU_DATA_EXIST(QLTY_VEHL_CD, V_VEHL_LIST1) = 'Y'
				 ;
				 
	   END SP_SELECT_TEST;
	   
	   FUNCTION FU_DATA_EXIST(P_VAL  VARCHAR2,
	   						  P_LIST VARCHAR2)RETURN VARCHAR2
	   IS
	   	 --Split 구분자 
  		 V_DEL VARCHAR2(1) := ',';
    
    	 V_LIST     VARCHAR2(32767):= P_LIST;
		 V_CURR_IDX PLS_INTEGER;
		 
		 V_NUM       BINARY_INTEGER;
		 
	   BEGIN
	   
	   		V_NUM := 0;

            LOOP
     
     	   	   V_NUM := V_NUM + 1;
     
               V_CURR_IDX := INSTR(V_LIST, V_DEL);
     
               IF V_CURR_IDX > 0 THEN
     
                  IF P_VAL = SUBSTR(V_LIST, 1, V_CURR_IDX - 1) THEN
				  	 
					 RETURN 'Y';
					 
				  END IF;
     
                  V_LIST := SUBSTR(V_LIST, V_CURR_IDX + LENGTH(V_DEL));
     	    
                ELSE
     			   
				    IF P_VAL = V_LIST THEN
				  	 
					 RETURN 'Y';
					 
				  END IF;
				  
                   EXIT;
     
                END IF;
     
             END LOOP;
			
			 RETURN 'N';
			
	   END FU_DATA_EXIST;					  					
	   /***************************************************************************** 
	    시스템 개발 후 OPEN 초기 이전 데이터를 처리 하기위해서 사용했던 프로시저/함수 
	    *****************************************************************************
	   
	   --차종코드 삭제시 이용 
--	   DELETE FROM TB_VEHL_MGMT WHERE QLTY_VEHL_CD = :VEHL_CD;
--	   DELETE FROM TB_ALTN_VEHL_MGMT WHERE QLTY_VEHL_CD = :VEHL_CD;
--	   DELETE FROM TB_AUTH_VEHL_MGMT WHERE QLTY_VEHL_CD = :VEHL_CD;
--	   DELETE FROM TB_DL_EXPD_MDY_MGMT WHERE QLTY_VEHL_CD = :VEHL_CD;
--	   DELETE FROM TB_LANG_MGMT WHERE QLTY_VEHL_CD = :VEHL_CD;
--	   DELETE FROM TB_NATL_LANG_MGMT WHERE QLTY_VEHL_CD = :VEHL_CD;
--	   DELETE FROM TB_NATL_VEHL_MGMT WHERE QLTY_VEHL_CD = :VEHL_CD;
--	   DELETE FROM TB_VEHL_MDY_MGMT WHERE QLTY_VEHL_CD = :VEHL_CD;
	   
	   
	   --차종코드 등록 
	   PROCEDURE SP_MAKE_VEHL_INFO(P_QLTY_VEHL_CD       VARCHAR2,
	   			 				   P_MDL_MDY_CD         VARCHAR2,
								   P_DL_EXPD_CO_CD      VARCHAR2,
								   P_QLTY_VEHL_NM       VARCHAR2,
								   P_DL_EXPD_PAC_SCN_CD VARCHAR2,
								   P_DL_EXPD_PDI_CD		VARCHAR2,
								   P_JB_MDY_REL_CD      VARCHAR2,
								   P_DYTM_PLN_VEHL_CD   VARCHAR2,
								   P_PRDN_MST_VEHL_CD	VARCHAR2,
								   P_BOM_VEHL_CD        VARCHAR2)
	   IS
	   	 
		 V_CURR_EENO VARCHAR2(8) := 'SYSTEM';
		 
		 CURSOR AUTH_AFFR_MGMT IS SELECT MENU_ID
								  FROM TB_AUTH_AFFR_MGMT
								  WHERE USER_EENO = PG_COMMON.FU_RPAD(V_CURR_EENO, 7)
								  AND MENU_AUTH_CD = 'R';
	   BEGIN
	   		
											   
			UPDATE TB_VEHL_MGMT
			SET DL_EXPD_CO_CD = P_DL_EXPD_CO_CD,
			    QLTY_VEHL_NM = P_QLTY_VEHL_NM,
				DL_EXPD_PAC_SCN_CD = P_DL_EXPD_PAC_SCN_CD,
				DL_EXPD_PDI_CD = P_DL_EXPD_PDI_CD,
				JB_MDY_REL_CD = P_JB_MDY_REL_CD,
				--DYTM_PLN_VEHL_CD = P_DYTM_PLN_VEHL_CD,
				--PRDN_MST_VEHL_CD = P_PRDN_MST_VEHL_CD,
				--BOM_VEHL_CD = P_BOM_VEHL_CD,
				USE_YN = 'Y',
				UPDR_EENO = V_CURR_EENO,
				MDFY_DTM = SYSDATE
			WHERE QLTY_VEHL_CD = P_QLTY_VEHL_CD
			AND MDL_MDY_CD = P_MDL_MDY_CD;
			
			IF SQL%NOTFOUND THEN
			   
			   INSERT INTO TB_VEHL_MGMT
			   (QLTY_VEHL_CD,
			    MDL_MDY_CD,
				DL_EXPD_CO_CD,
				QLTY_VEHL_NM,
				DL_EXPD_PAC_SCN_CD,
				DL_EXPD_PDI_CD,
				JB_MDY_REL_CD,
				--DYTM_PLN_VEHL_CD,
				--PRDN_MST_VEHL_CD,
				--BOM_VEHL_CD,
				USE_YN,
				PPRR_EENO,
				FRAM_DTM,
				UPDR_EENO,
				MDFY_DTM
			   )
			   VALUES
			   (P_QLTY_VEHL_CD,
			    P_MDL_MDY_CD,
				P_DL_EXPD_CO_CD,
				P_QLTY_VEHL_NM,
				P_DL_EXPD_PAC_SCN_CD,
				P_DL_EXPD_PDI_CD,
				P_JB_MDY_REL_CD,
				--P_DYTM_PLN_VEHL_CD,
				--P_PRDN_MST_VEHL_CD,
				--P_BOM_VEHL_CD,
				'Y',
				V_CURR_EENO,
				SYSDATE,
				V_CURR_EENO,
				SYSDATE
			   );
			   
			END IF;
			
			SP_MAKE_ALTN_VEHL_INFO(P_QLTY_VEHL_CD, P_DYTM_PLN_VEHL_CD, 'A');
			SP_MAKE_ALTN_VEHL_INFO(P_QLTY_VEHL_CD, P_PRDN_MST_VEHL_CD, 'B');
			SP_MAKE_ALTN_VEHL_INFO(P_QLTY_VEHL_CD, P_BOM_VEHL_CD,      'C');
			
			
			--직전연식관계에 따른 취급설명서 연식정보 매칭 작업 수행 
			PG_VEHL_MGMT.SP_VEHL_MDY_REL_CD_UPDATE(P_QLTY_VEHL_CD, P_MDL_MDY_CD, P_JB_MDY_REL_CD, V_CURR_EENO);
			
			--PDI코드가 기타가 아닌경우에만 입력하도록 한다. 
			IF P_DL_EXPD_PDI_CD <> '07' THEN
			   
			   --테스트를 위한 권한 추가 부분임....
			   --권한테이블에 무조건 추가해 준다. 
			   FOR AUTH_LIST IN AUTH_AFFR_MGMT LOOP
				
				   UPDATE TB_AUTH_VEHL_MGMT
				   SET CL_SCN_CD = 'U',
			    	   UPDR_EENO = V_CURR_EENO,
					   MDFY_DTM = SYSDATE
				   WHERE USER_EENO = PG_COMMON.FU_RPAD(V_CURR_EENO, 7)
			       AND MENU_ID = AUTH_LIST.MENU_ID
				   AND QLTY_VEHL_CD = P_QLTY_VEHL_CD;
				
				   IF SQL%NOTFOUND THEN
				   
				       INSERT INTO TB_AUTH_VEHL_MGMT
				       (USER_EENO,
				        MENU_ID,
				    	QLTY_VEHL_CD,
						CL_SCN_CD,
						PPRR_EENO,
						FRAM_DTM,
						UPDR_EENO,
						MDFY_DTM
				   	   )
				       VALUES
				   	   (V_CURR_EENO,
				        AUTH_LIST.MENU_ID,
						P_QLTY_VEHL_CD,
						'U',
						V_CURR_EENO,
						SYSDATE,
						V_CURR_EENO,
						SYSDATE
				       );
				   END IF;
				
			   END LOOP;
			
			END IF;
			
			COMMIT;
			
			EXCEPTION
		     WHEN OTHERS THEN
			     ROLLBACK;
				 RAISE;
				 
	   END SP_MAKE_VEHL_INFO;
	   
	   --연계차종코드 등록
	   PROCEDURE SP_MAKE_ALTN_VEHL_INFO(P_QLTY_VEHL_CD VARCHAR2,
	   			 						P_PRDN_VEHL_CD VARCHAR2,
			 						    P_PRVS_SCN_CD  VARCHAR2)
	   IS
	   	 
		 V_CURR_EENO VARCHAR2(8) := 'SYSTEM';
		 
		 V_CNT       NUMBER;
		 
	   BEGIN
	   		
			IF P_PRDN_VEHL_CD IS NULL OR P_PRDN_VEHL_CD = '' THEN
			   
			   RETURN;
			   
			END IF;
			
			SELECT COUNT(*)
			INTO V_CNT
			FROM TB_ALTN_VEHL_MGMT
			WHERE QLTY_VEHL_CD = P_QLTY_VEHL_CD
			AND PRDN_VEHL_CD = P_PRDN_VEHL_CD
			AND PRVS_SCN_CD = P_PRVS_SCN_CD;
			
			IF V_CNT = 0 THEN
			
			   INSERT INTO TB_ALTN_VEHL_MGMT
			   (QLTY_VEHL_CD,
			    PRDN_VEHL_CD,
				PRVS_SCN_CD,
				PPRR_EENO,
				FRAM_DTM,
				UPDR_EENO,
				MDFY_DTM
			   )
			   VALUES
			   (P_QLTY_VEHL_CD,
			    P_PRDN_VEHL_CD,
				P_PRVS_SCN_CD,
				V_CURR_EENO,
				SYSDATE,
				V_CURR_EENO,
				SYSDATE
			   );
			END IF;
			
			COMMIT;
			
			EXCEPTION
		     WHEN OTHERS THEN
			     ROLLBACK;
				 RAISE;
				 
	   END SP_MAKE_ALTN_VEHL_INFO;
	   
	   --국가코드 리스트 등록 
	   PROCEDURE SP_MAKE_NATL_LIST
	   IS
	   	 
		 
		 CURSOR NATL_MGMT IS SELECT DL_EXPD_CO_CD, 
		 				  	 		DL_EXPD_NAT_CD, 
									NVL(DYTM_PLN_NAT_CD, 'NULL') AS DYTM_PLN_NAT_CD,
									NAT_NM
						     FROM TB_NATL_MGMT_TEMP 
							 ORDER BY DL_EXPD_CO_CD, DL_EXPD_NAT_CD, DYTM_PLN_NAT_CD;
		 
		 V_CNT NUMBER;
		 					  
	   BEGIN
	   		
			FOR NATL_LIST IN NATL_MGMT LOOP
				
				UPDATE TB_NATL_MGMT
				SET NAT_NM = NATL_LIST.NAT_NM,
				    UPDR_EENO = 'SYSTEM',
					MDFY_DTM = SYSDATE
			    WHERE DL_EXPD_CO_CD = NATL_LIST.DL_EXPD_CO_CD
				AND DL_EXPD_NAT_CD = NATL_LIST.DL_EXPD_NAT_CD;
				
				IF SQL%NOTFOUND THEN
				   
				   INSERT INTO TB_NATL_MGMT
    			  (DL_EXPD_CO_CD,
    			   DL_EXPD_NAT_CD,
    			   NAT_NM,
    			   PPRR_EENO,
    			   FRAM_DTM,
    			   UPDR_EENO,
    			   MDFY_DTM
    			  )
    			  VALUES
    			  (NATL_LIST.DL_EXPD_CO_CD,
    			   NATL_LIST.DL_EXPD_NAT_CD,
    			   NATL_LIST.NAT_NM,
    			   'SYSTEM',
    			   SYSDATE,
    			   'SYSTEM',
    			   SYSDATE
    			  );
				   
				END IF;
				
				IF NATL_LIST.DYTM_PLN_NAT_CD <> 'NULL' THEN
				   
				   SELECT COUNT(*)
				   INTO V_CNT
				   FROM TB_ALTN_NATL_MGMT
				   WHERE DL_EXPD_CO_CD = NATL_LIST.DL_EXPD_CO_CD
				   AND DL_EXPD_NAT_CD = NATL_LIST.DL_EXPD_NAT_CD
				   AND DYTM_PLN_NAT_CD = NATL_LIST.DYTM_PLN_NAT_CD
				   AND PRVS_SCN_CD = 'A';
				
				   IF V_CNT = 0 THEN
				   	  
					  INSERT INTO TB_ALTN_NATL_MGMT
					  (DL_EXPD_CO_CD,
					   DL_EXPD_NAT_CD,
					   DYTM_PLN_NAT_CD,
					   PRVS_SCN_CD,
					   PPRR_EENO,
					   FRAM_DTM,
					   UPDR_EENO,
					   MDFY_DTM
					  )
					  VALUES
					  (NATL_LIST.DL_EXPD_CO_CD,
					   NATL_LIST.DL_EXPD_NAT_CD,
					   NATL_LIST.DYTM_PLN_NAT_CD,
					   'A',
					   'SYSTEM',
    			   	   SYSDATE,
    			   	   'SYSTEM',
    			   	   SYSDATE
					  );
				   
				   END IF;
				
				END IF;
				
			END LOOP;
			
			COMMIT;
			
			EXCEPTION
		     WHEN OTHERS THEN
			     ROLLBACK;
				 RAISE;
				 
	   END SP_MAKE_NATL_LIST;
	   
	   --국가코드 등록 
	   PROCEDURE SP_MAKE_NATL_INFO(P_DL_EXPD_CO_CD   VARCHAR2,
	  							   P_DL_EXPD_NAT_CD  VARCHAR2,
								   P_NAT_NM			 VARCHAR2)
	   IS
	   	 
		 V_CURR_EENO VARCHAR2(8) := 'SYSTEM';
		 
	   BEGIN
	   		
			UPDATE TB_NATL_MGMT
			SET NAT_NM = P_NAT_NM,
				DYTM_PLN_NAT_CD = P_DL_EXPD_NAT_CD,
				PRDN_MST_NAT_CD = P_DL_EXPD_NAT_CD,
				UPDR_EENO = V_CURR_EENO,
				MDFY_DTM = SYSDATE
		   WHERE DL_EXPD_CO_CD = P_DL_EXPD_CO_CD
		   AND DL_EXPD_NAT_CD = P_DL_EXPD_NAT_CD;
		   
		   IF SQL%NOTFOUND THEN
		   	  
			  INSERT INTO TB_NATL_MGMT
			  (DL_EXPD_CO_CD,
			   DL_EXPD_NAT_CD,
			   NAT_NM,
			   DYTM_PLN_NAT_CD,
			   PRDN_MST_NAT_CD,
			   PPRR_EENO,
			   FRAM_DTM,
			   UPDR_EENO,
			   MDFY_DTM
			  )
			  VALUES
			  (P_DL_EXPD_CO_CD,
			   P_DL_EXPD_NAT_CD,
			   P_NAT_NM,
			   P_DL_EXPD_NAT_CD,
			   P_DL_EXPD_NAT_CD,
			   V_CURR_EENO,
			   SYSDATE,
			   V_CURR_EENO,
			   SYSDATE
			  );
			  
		   END IF;
		   
		   COMMIT;
			
			EXCEPTION
		     WHEN OTHERS THEN
			     ROLLBACK;
				 RAISE;
				 
	   END SP_MAKE_NATL_INFO;
	   
	   --국가/언어 리스트 등록 
	   PROCEDURE SP_MAKE_NATL_NALG_LIST(P_DL_EXPD_CO_CD     VARCHAR2,
	  							        P_DL_EXPD_NAT_LIST  VARCHAR2,
									    P_QLTY_VEHL_LIST	VARCHAR2,
								        P_LANG_CD           VARCHAR2)
	   IS
	   	  
		  V_NATL_LIST PG_COMMON.LIST_TYPE;
		  V_VEHL_LIST PG_COMMON.LIST_TYPE;
		  
		  V_NATL_CNT BINARY_INTEGER;
		  V_VEHL_CNT BINARY_INTEGER;
		  
	   BEGIN
	   		
			V_NATL_LIST := PG_COMMON.FU_SPLIT(P_DL_EXPD_NAT_LIST , V_NATL_CNT);
		  	V_VEHL_LIST := PG_COMMON.FU_SPLIT(P_QLTY_VEHL_LIST,    V_VEHL_CNT);
			
			FOR NATL_NUM IN 1..V_NATL_CNT LOOP
				
				FOR VEHL_NUM IN 1..V_VEHL_CNT LOOP
					
					SP_MAKE_NATL_LANG_INFO(P_DL_EXPD_CO_CD, V_NATL_LIST(NATL_NUM), V_VEHL_LIST(VEHL_NUM), '08', P_LANG_CD);
					SP_MAKE_NATL_LANG_INFO(P_DL_EXPD_CO_CD, V_NATL_LIST(NATL_NUM), V_VEHL_LIST(VEHL_NUM), '09', P_LANG_CD);
					SP_MAKE_NATL_LANG_INFO(P_DL_EXPD_CO_CD, V_NATL_LIST(NATL_NUM), V_VEHL_LIST(VEHL_NUM), '10', P_LANG_CD);
					
				END LOOP;
				
			END LOOP;
			
	   END SP_MAKE_NATL_NALG_LIST;
	   
	   
	   --기아 국가/언어 코드 등록
	   PROCEDURE SP_MAKE_NATL_NALG_LIST_KMC
	   IS
	   
	   	 --V_CURR_EENO VARCHAR2(8) := 'SYSTEM';
		 
		 CURSOR NATL_LANG_MGMT IS SELECT A.DL_EXPD_CO_CD,
		 					   	         B.DL_EXPD_NAT_CD,
										 A.LANG_CD,
										 A.QLTY_VEHL_CD1,
										 A.QLTY_VEHL_CD2,
										 A.QLTY_VEHL_CD3,
										 A.QLTY_VEHL_CD4,
										 A.QLTY_VEHL_CD5,
										 A.QLTY_VEHL_CD6,
										 A.QLTY_VEHL_CD7,
										 A.QLTY_VEHL_CD8,
										 A.QLTY_VEHL_CD9,
										 A.QLTY_VEHL_CD10,
										 A.QLTY_VEHL_CD11,
										 A.QLTY_VEHL_CD12,
										 A.QLTY_VEHL_CD13,
										 A.QLTY_VEHL_CD14
								  FROM TB_NATL_LANG_MGMT_KMC A,
								       TB_NATL_MGMT B
								  WHERE A.DL_EXPD_CO_CD IS NOT NULL
								  AND A.DL_EXPD_NAT_CD IS NOT NULL
								  AND A.LANG_CD IS NOT NULL
								  AND B.DL_EXPD_CO_CD = A.DL_EXPD_CO_CD
								  AND B.DL_EXPD_NAT_CD = A.DL_EXPD_NAT_CD
								  ORDER BY A.DL_EXPD_CO_CD, B.DL_EXPD_NAT_CD, A.LANG_CD;
	   BEGIN
	   		
			FOR LANG_LIST IN NATL_LANG_MGMT LOOP
				
				IF LANG_LIST.QLTY_VEHL_CD1 IS NOT NULL THEN
				   
				   SP_MAKE_NATL_LANG_INFO(LANG_LIST.DL_EXPD_CO_CD,
									   LANG_LIST.DL_EXPD_NAT_CD,
									   LANG_LIST.QLTY_VEHL_CD1,
									   '08',
									   LANG_LIST.LANG_CD);
									   
				   SP_MAKE_NATL_LANG_INFO(LANG_LIST.DL_EXPD_CO_CD,
									   LANG_LIST.DL_EXPD_NAT_CD,
									   LANG_LIST.QLTY_VEHL_CD1,
									   '09',
									   LANG_LIST.LANG_CD);
									   
				   SP_MAKE_NATL_LANG_INFO(LANG_LIST.DL_EXPD_CO_CD,
									   LANG_LIST.DL_EXPD_NAT_CD,
									   LANG_LIST.QLTY_VEHL_CD1,
									   '10',
									   LANG_LIST.LANG_CD);
									   
				END IF;
				 
				IF LANG_LIST.QLTY_VEHL_CD2 IS NOT NULL THEN
				   
				   SP_MAKE_NATL_LANG_INFO(LANG_LIST.DL_EXPD_CO_CD,
									   LANG_LIST.DL_EXPD_NAT_CD,
									   LANG_LIST.QLTY_VEHL_CD2,
									   '08',
									   LANG_LIST.LANG_CD);
									   
				   SP_MAKE_NATL_LANG_INFO(LANG_LIST.DL_EXPD_CO_CD,
									   LANG_LIST.DL_EXPD_NAT_CD,
									   LANG_LIST.QLTY_VEHL_CD2,
									   '09',
									   LANG_LIST.LANG_CD);
									   
				   SP_MAKE_NATL_LANG_INFO(LANG_LIST.DL_EXPD_CO_CD,
									   LANG_LIST.DL_EXPD_NAT_CD,
									   LANG_LIST.QLTY_VEHL_CD2,
									   '10',
									   LANG_LIST.LANG_CD);
									   
				END IF;
				
				IF LANG_LIST.QLTY_VEHL_CD3 IS NOT NULL THEN
				   
				   SP_MAKE_NATL_LANG_INFO(LANG_LIST.DL_EXPD_CO_CD,
									   LANG_LIST.DL_EXPD_NAT_CD,
									   LANG_LIST.QLTY_VEHL_CD3,
									   '08',
									   LANG_LIST.LANG_CD);
									   
				   SP_MAKE_NATL_LANG_INFO(LANG_LIST.DL_EXPD_CO_CD,
									   LANG_LIST.DL_EXPD_NAT_CD,
									   LANG_LIST.QLTY_VEHL_CD3,
									   '09',
									   LANG_LIST.LANG_CD);
									   
				   SP_MAKE_NATL_LANG_INFO(LANG_LIST.DL_EXPD_CO_CD,
									   LANG_LIST.DL_EXPD_NAT_CD,
									   LANG_LIST.QLTY_VEHL_CD3,
									   '10',
									   LANG_LIST.LANG_CD);
									   
				END IF;
				
				IF LANG_LIST.QLTY_VEHL_CD4 IS NOT NULL THEN
				   
				   SP_MAKE_NATL_LANG_INFO(LANG_LIST.DL_EXPD_CO_CD,
									   LANG_LIST.DL_EXPD_NAT_CD,
									   LANG_LIST.QLTY_VEHL_CD4,
									   '08',
									   LANG_LIST.LANG_CD);
									   
				   SP_MAKE_NATL_LANG_INFO(LANG_LIST.DL_EXPD_CO_CD,
									   LANG_LIST.DL_EXPD_NAT_CD,
									   LANG_LIST.QLTY_VEHL_CD4,
									   '09',
									   LANG_LIST.LANG_CD);
									   
				   SP_MAKE_NATL_LANG_INFO(LANG_LIST.DL_EXPD_CO_CD,
									   LANG_LIST.DL_EXPD_NAT_CD,
									   LANG_LIST.QLTY_VEHL_CD4,
									   '10',
									   LANG_LIST.LANG_CD);
									   
				END IF;
				
				IF LANG_LIST.QLTY_VEHL_CD5 IS NOT NULL THEN
				   
				   SP_MAKE_NATL_LANG_INFO(LANG_LIST.DL_EXPD_CO_CD,
									   LANG_LIST.DL_EXPD_NAT_CD,
									   LANG_LIST.QLTY_VEHL_CD5,
									   '08',
									   LANG_LIST.LANG_CD);
									   
				   SP_MAKE_NATL_LANG_INFO(LANG_LIST.DL_EXPD_CO_CD,
									   LANG_LIST.DL_EXPD_NAT_CD,
									   LANG_LIST.QLTY_VEHL_CD5,
									   '09',
									   LANG_LIST.LANG_CD);
									   
				   SP_MAKE_NATL_LANG_INFO(LANG_LIST.DL_EXPD_CO_CD,
									   LANG_LIST.DL_EXPD_NAT_CD,
									   LANG_LIST.QLTY_VEHL_CD5,
									   '10',
									   LANG_LIST.LANG_CD);
									   
				END IF;
				
				IF LANG_LIST.QLTY_VEHL_CD6 IS NOT NULL THEN
				   
				   SP_MAKE_NATL_LANG_INFO(LANG_LIST.DL_EXPD_CO_CD,
									   LANG_LIST.DL_EXPD_NAT_CD,
									   LANG_LIST.QLTY_VEHL_CD6,
									   '08',
									   LANG_LIST.LANG_CD);
									   
				   SP_MAKE_NATL_LANG_INFO(LANG_LIST.DL_EXPD_CO_CD,
									   LANG_LIST.DL_EXPD_NAT_CD,
									   LANG_LIST.QLTY_VEHL_CD6,
									   '09',
									   LANG_LIST.LANG_CD);
									   
				   SP_MAKE_NATL_LANG_INFO(LANG_LIST.DL_EXPD_CO_CD,
									   LANG_LIST.DL_EXPD_NAT_CD,
									   LANG_LIST.QLTY_VEHL_CD6,
									   '10',
									   LANG_LIST.LANG_CD);
									   
				END IF;
				
				IF LANG_LIST.QLTY_VEHL_CD7 IS NOT NULL THEN
				   
				   SP_MAKE_NATL_LANG_INFO(LANG_LIST.DL_EXPD_CO_CD,
									   LANG_LIST.DL_EXPD_NAT_CD,
									   LANG_LIST.QLTY_VEHL_CD7,
									   '08',
									   LANG_LIST.LANG_CD);
									   
				   SP_MAKE_NATL_LANG_INFO(LANG_LIST.DL_EXPD_CO_CD,
									   LANG_LIST.DL_EXPD_NAT_CD,
									   LANG_LIST.QLTY_VEHL_CD7,
									   '09',
									   LANG_LIST.LANG_CD);
									   
				   SP_MAKE_NATL_LANG_INFO(LANG_LIST.DL_EXPD_CO_CD,
									   LANG_LIST.DL_EXPD_NAT_CD,
									   LANG_LIST.QLTY_VEHL_CD7,
									   '10',
									   LANG_LIST.LANG_CD);
									   
				END IF;
				
				IF LANG_LIST.QLTY_VEHL_CD8 IS NOT NULL THEN
				   
				   SP_MAKE_NATL_LANG_INFO(LANG_LIST.DL_EXPD_CO_CD,
									   LANG_LIST.DL_EXPD_NAT_CD,
									   LANG_LIST.QLTY_VEHL_CD8,
									   '08',
									   LANG_LIST.LANG_CD);
									   
				   SP_MAKE_NATL_LANG_INFO(LANG_LIST.DL_EXPD_CO_CD,
									   LANG_LIST.DL_EXPD_NAT_CD,
									   LANG_LIST.QLTY_VEHL_CD8,
									   '09',
									   LANG_LIST.LANG_CD);
									   
				   SP_MAKE_NATL_LANG_INFO(LANG_LIST.DL_EXPD_CO_CD,
									   LANG_LIST.DL_EXPD_NAT_CD,
									   LANG_LIST.QLTY_VEHL_CD8,
									   '10',
									   LANG_LIST.LANG_CD);
									   
				END IF;
				
				IF LANG_LIST.QLTY_VEHL_CD9 IS NOT NULL THEN
				   
				   SP_MAKE_NATL_LANG_INFO(LANG_LIST.DL_EXPD_CO_CD,
									   LANG_LIST.DL_EXPD_NAT_CD,
									   LANG_LIST.QLTY_VEHL_CD9,
									   '08',
									   LANG_LIST.LANG_CD);
									   
				   SP_MAKE_NATL_LANG_INFO(LANG_LIST.DL_EXPD_CO_CD,
									   LANG_LIST.DL_EXPD_NAT_CD,
									   LANG_LIST.QLTY_VEHL_CD9,
									   '09',
									   LANG_LIST.LANG_CD);
									   
				   SP_MAKE_NATL_LANG_INFO(LANG_LIST.DL_EXPD_CO_CD,
									   LANG_LIST.DL_EXPD_NAT_CD,
									   LANG_LIST.QLTY_VEHL_CD9,
									   '10',
									   LANG_LIST.LANG_CD);
									   
				END IF;
				
				IF LANG_LIST.QLTY_VEHL_CD10 IS NOT NULL THEN
				   
				   SP_MAKE_NATL_LANG_INFO(LANG_LIST.DL_EXPD_CO_CD,
									   LANG_LIST.DL_EXPD_NAT_CD,
									   LANG_LIST.QLTY_VEHL_CD10,
									   '08',
									   LANG_LIST.LANG_CD);
									   
				   SP_MAKE_NATL_LANG_INFO(LANG_LIST.DL_EXPD_CO_CD,
									   LANG_LIST.DL_EXPD_NAT_CD,
									   LANG_LIST.QLTY_VEHL_CD10,
									   '09',
									   LANG_LIST.LANG_CD);
									   
				   SP_MAKE_NATL_LANG_INFO(LANG_LIST.DL_EXPD_CO_CD,
									   LANG_LIST.DL_EXPD_NAT_CD,
									   LANG_LIST.QLTY_VEHL_CD10,
									   '10',
									   LANG_LIST.LANG_CD);
									   
				END IF;
				
				IF LANG_LIST.QLTY_VEHL_CD11 IS NOT NULL THEN
				   
				   SP_MAKE_NATL_LANG_INFO(LANG_LIST.DL_EXPD_CO_CD,
									   LANG_LIST.DL_EXPD_NAT_CD,
									   LANG_LIST.QLTY_VEHL_CD11,
									   '08',
									   LANG_LIST.LANG_CD);
									   
				   SP_MAKE_NATL_LANG_INFO(LANG_LIST.DL_EXPD_CO_CD,
									   LANG_LIST.DL_EXPD_NAT_CD,
									   LANG_LIST.QLTY_VEHL_CD11,
									   '09',
									   LANG_LIST.LANG_CD);
									   
				   SP_MAKE_NATL_LANG_INFO(LANG_LIST.DL_EXPD_CO_CD,
									   LANG_LIST.DL_EXPD_NAT_CD,
									   LANG_LIST.QLTY_VEHL_CD11,
									   '10',
									   LANG_LIST.LANG_CD);
									   
				END IF;
				
				IF LANG_LIST.QLTY_VEHL_CD12 IS NOT NULL THEN
				   
				   SP_MAKE_NATL_LANG_INFO(LANG_LIST.DL_EXPD_CO_CD,
									   LANG_LIST.DL_EXPD_NAT_CD,
									   LANG_LIST.QLTY_VEHL_CD12,
									   '08',
									   LANG_LIST.LANG_CD);
									   
				   SP_MAKE_NATL_LANG_INFO(LANG_LIST.DL_EXPD_CO_CD,
									   LANG_LIST.DL_EXPD_NAT_CD,
									   LANG_LIST.QLTY_VEHL_CD12,
									   '09',
									   LANG_LIST.LANG_CD);
									   
				   SP_MAKE_NATL_LANG_INFO(LANG_LIST.DL_EXPD_CO_CD,
									   LANG_LIST.DL_EXPD_NAT_CD,
									   LANG_LIST.QLTY_VEHL_CD12,
									   '10',
									   LANG_LIST.LANG_CD);
									   
				END IF;
				
				IF LANG_LIST.QLTY_VEHL_CD13 IS NOT NULL THEN
				   
				   SP_MAKE_NATL_LANG_INFO(LANG_LIST.DL_EXPD_CO_CD,
									   LANG_LIST.DL_EXPD_NAT_CD,
									   LANG_LIST.QLTY_VEHL_CD13,
									   '08',
									   LANG_LIST.LANG_CD);
									   
				   SP_MAKE_NATL_LANG_INFO(LANG_LIST.DL_EXPD_CO_CD,
									   LANG_LIST.DL_EXPD_NAT_CD,
									   LANG_LIST.QLTY_VEHL_CD13,
									   '09',
									   LANG_LIST.LANG_CD);
									   
				   SP_MAKE_NATL_LANG_INFO(LANG_LIST.DL_EXPD_CO_CD,
									   LANG_LIST.DL_EXPD_NAT_CD,
									   LANG_LIST.QLTY_VEHL_CD13,
									   '10',
									   LANG_LIST.LANG_CD);
									   
				END IF;
				
				IF LANG_LIST.QLTY_VEHL_CD14 IS NOT NULL THEN
				   
				   SP_MAKE_NATL_LANG_INFO(LANG_LIST.DL_EXPD_CO_CD,
									   LANG_LIST.DL_EXPD_NAT_CD,
									   LANG_LIST.QLTY_VEHL_CD14,
									   '08',
									   LANG_LIST.LANG_CD);
									   
				   SP_MAKE_NATL_LANG_INFO(LANG_LIST.DL_EXPD_CO_CD,
									   LANG_LIST.DL_EXPD_NAT_CD,
									   LANG_LIST.QLTY_VEHL_CD14,
									   '09',
									   LANG_LIST.LANG_CD);
									   
				   SP_MAKE_NATL_LANG_INFO(LANG_LIST.DL_EXPD_CO_CD,
									   LANG_LIST.DL_EXPD_NAT_CD,
									   LANG_LIST.QLTY_VEHL_CD14,
									   '10',
									   LANG_LIST.LANG_CD);
									   
				END IF;
							   
			END LOOP;
			
	   END SP_MAKE_NATL_NALG_LIST_KMC;
	   
	   --현대 승용 국가/언어 코드 등록							   
	   PROCEDURE SP_MAKE_NATL_NALG_LIST_HMC1
	   IS 
	   	  
		  CURSOR NATL_LANG_MGMT IS SELECT A.DL_EXPD_CO_CD,
		 					   	          B.DL_EXPD_NAT_CD,
										  A.LANG_CD,
										  A.QLTY_VEHL_CD1,
										  A.QLTY_VEHL_CD2,
										  A.QLTY_VEHL_CD3,
										  A.QLTY_VEHL_CD4,
										  A.QLTY_VEHL_CD5,
										  A.QLTY_VEHL_CD6,
										  A.QLTY_VEHL_CD7,
										  A.QLTY_VEHL_CD8,
										  A.QLTY_VEHL_CD9,
										  A.QLTY_VEHL_CD10,
										  A.QLTY_VEHL_CD11,
										  A.QLTY_VEHL_CD12,
										  A.QLTY_VEHL_CD13,
										  A.QLTY_VEHL_CD14,
										  A.QLTY_VEHL_CD15
								   FROM TB_NATL_LANG_MGMT_HMC1 A,
								        TB_NATL_MGMT B
								   WHERE A.DL_EXPD_CO_CD IS NOT NULL
								   AND A.DL_EXPD_NAT_CD IS NOT NULL
								   AND A.LANG_CD IS NOT NULL
								   AND B.DL_EXPD_CO_CD = A.DL_EXPD_CO_CD
								   AND B.DL_EXPD_NAT_CD = A.DL_EXPD_NAT_CD
								   ORDER BY A.DL_EXPD_CO_CD, B.DL_EXPD_NAT_CD, A.LANG_CD;
	   BEGIN
	   		
			FOR LANG_LIST IN NATL_LANG_MGMT LOOP
				
				IF LANG_LIST.QLTY_VEHL_CD1 IS NOT NULL THEN
				   
				   SP_MAKE_NATL_LANG_INFO(LANG_LIST.DL_EXPD_CO_CD,
									   LANG_LIST.DL_EXPD_NAT_CD,
									   LANG_LIST.QLTY_VEHL_CD1,
									   '08',
									   LANG_LIST.LANG_CD);
									   
				   SP_MAKE_NATL_LANG_INFO(LANG_LIST.DL_EXPD_CO_CD,
									   LANG_LIST.DL_EXPD_NAT_CD,
									   LANG_LIST.QLTY_VEHL_CD1,
									   '09',
									   LANG_LIST.LANG_CD);
									   
				   SP_MAKE_NATL_LANG_INFO(LANG_LIST.DL_EXPD_CO_CD,
									   LANG_LIST.DL_EXPD_NAT_CD,
									   LANG_LIST.QLTY_VEHL_CD1,
									   '10',
									   LANG_LIST.LANG_CD);
									   
				END IF;
				
				IF LANG_LIST.QLTY_VEHL_CD2 IS NOT NULL THEN
				   
				   SP_MAKE_NATL_LANG_INFO(LANG_LIST.DL_EXPD_CO_CD,
									   LANG_LIST.DL_EXPD_NAT_CD,
									   LANG_LIST.QLTY_VEHL_CD2,
									   '08',
									   LANG_LIST.LANG_CD);
									   
				   SP_MAKE_NATL_LANG_INFO(LANG_LIST.DL_EXPD_CO_CD,
									   LANG_LIST.DL_EXPD_NAT_CD,
									   LANG_LIST.QLTY_VEHL_CD2,
									   '09',
									   LANG_LIST.LANG_CD);
									   
				   SP_MAKE_NATL_LANG_INFO(LANG_LIST.DL_EXPD_CO_CD,
									   LANG_LIST.DL_EXPD_NAT_CD,
									   LANG_LIST.QLTY_VEHL_CD2,
									   '10',
									   LANG_LIST.LANG_CD);
									   
				END IF;
				
				IF LANG_LIST.QLTY_VEHL_CD3 IS NOT NULL THEN
				   
				   SP_MAKE_NATL_LANG_INFO(LANG_LIST.DL_EXPD_CO_CD,
									   LANG_LIST.DL_EXPD_NAT_CD,
									   LANG_LIST.QLTY_VEHL_CD3,
									   '08',
									   LANG_LIST.LANG_CD);
									   
				   SP_MAKE_NATL_LANG_INFO(LANG_LIST.DL_EXPD_CO_CD,
									   LANG_LIST.DL_EXPD_NAT_CD,
									   LANG_LIST.QLTY_VEHL_CD3,
									   '09',
									   LANG_LIST.LANG_CD);
									   
				   SP_MAKE_NATL_LANG_INFO(LANG_LIST.DL_EXPD_CO_CD,
									   LANG_LIST.DL_EXPD_NAT_CD,
									   LANG_LIST.QLTY_VEHL_CD3,
									   '10',
									   LANG_LIST.LANG_CD);
									   
				END IF;
				
				IF LANG_LIST.QLTY_VEHL_CD4 IS NOT NULL THEN
				   
				   SP_MAKE_NATL_LANG_INFO(LANG_LIST.DL_EXPD_CO_CD,
									   LANG_LIST.DL_EXPD_NAT_CD,
									   LANG_LIST.QLTY_VEHL_CD4,
									   '08',
									   LANG_LIST.LANG_CD);
									   
				   SP_MAKE_NATL_LANG_INFO(LANG_LIST.DL_EXPD_CO_CD,
									   LANG_LIST.DL_EXPD_NAT_CD,
									   LANG_LIST.QLTY_VEHL_CD4,
									   '09',
									   LANG_LIST.LANG_CD);
									   
				   SP_MAKE_NATL_LANG_INFO(LANG_LIST.DL_EXPD_CO_CD,
									   LANG_LIST.DL_EXPD_NAT_CD,
									   LANG_LIST.QLTY_VEHL_CD4,
									   '10',
									   LANG_LIST.LANG_CD);
									   
				END IF;
				
				IF LANG_LIST.QLTY_VEHL_CD5 IS NOT NULL THEN
				   
				   SP_MAKE_NATL_LANG_INFO(LANG_LIST.DL_EXPD_CO_CD,
									   LANG_LIST.DL_EXPD_NAT_CD,
									   LANG_LIST.QLTY_VEHL_CD5,
									   '08',
									   LANG_LIST.LANG_CD);
									   
				   SP_MAKE_NATL_LANG_INFO(LANG_LIST.DL_EXPD_CO_CD,
									   LANG_LIST.DL_EXPD_NAT_CD,
									   LANG_LIST.QLTY_VEHL_CD5,
									   '09',
									   LANG_LIST.LANG_CD);
									   
				   SP_MAKE_NATL_LANG_INFO(LANG_LIST.DL_EXPD_CO_CD,
									   LANG_LIST.DL_EXPD_NAT_CD,
									   LANG_LIST.QLTY_VEHL_CD5,
									   '10',
									   LANG_LIST.LANG_CD);
									   
				END IF;
				
				IF LANG_LIST.QLTY_VEHL_CD6 IS NOT NULL THEN
				   
				   SP_MAKE_NATL_LANG_INFO(LANG_LIST.DL_EXPD_CO_CD,
									   LANG_LIST.DL_EXPD_NAT_CD,
									   LANG_LIST.QLTY_VEHL_CD6,
									   '08',
									   LANG_LIST.LANG_CD);
									   
				   SP_MAKE_NATL_LANG_INFO(LANG_LIST.DL_EXPD_CO_CD,
									   LANG_LIST.DL_EXPD_NAT_CD,
									   LANG_LIST.QLTY_VEHL_CD6,
									   '09',
									   LANG_LIST.LANG_CD);
									   
				   SP_MAKE_NATL_LANG_INFO(LANG_LIST.DL_EXPD_CO_CD,
									   LANG_LIST.DL_EXPD_NAT_CD,
									   LANG_LIST.QLTY_VEHL_CD6,
									   '10',
									   LANG_LIST.LANG_CD);
									   
				END IF;
				
				IF LANG_LIST.QLTY_VEHL_CD7 IS NOT NULL THEN
				   
				   SP_MAKE_NATL_LANG_INFO(LANG_LIST.DL_EXPD_CO_CD,
									   LANG_LIST.DL_EXPD_NAT_CD,
									   LANG_LIST.QLTY_VEHL_CD7,
									   '08',
									   LANG_LIST.LANG_CD);
									   
				   SP_MAKE_NATL_LANG_INFO(LANG_LIST.DL_EXPD_CO_CD,
									   LANG_LIST.DL_EXPD_NAT_CD,
									   LANG_LIST.QLTY_VEHL_CD7,
									   '09',
									   LANG_LIST.LANG_CD);
									   
				   SP_MAKE_NATL_LANG_INFO(LANG_LIST.DL_EXPD_CO_CD,
									   LANG_LIST.DL_EXPD_NAT_CD,
									   LANG_LIST.QLTY_VEHL_CD7,
									   '10',
									   LANG_LIST.LANG_CD);
									   
				END IF;
				
				IF LANG_LIST.QLTY_VEHL_CD8 IS NOT NULL THEN
				   
				   SP_MAKE_NATL_LANG_INFO(LANG_LIST.DL_EXPD_CO_CD,
									   LANG_LIST.DL_EXPD_NAT_CD,
									   LANG_LIST.QLTY_VEHL_CD8,
									   '08',
									   LANG_LIST.LANG_CD);
									   
				   SP_MAKE_NATL_LANG_INFO(LANG_LIST.DL_EXPD_CO_CD,
									   LANG_LIST.DL_EXPD_NAT_CD,
									   LANG_LIST.QLTY_VEHL_CD8,
									   '09',
									   LANG_LIST.LANG_CD);
									   
				   SP_MAKE_NATL_LANG_INFO(LANG_LIST.DL_EXPD_CO_CD,
									   LANG_LIST.DL_EXPD_NAT_CD,
									   LANG_LIST.QLTY_VEHL_CD8,
									   '10',
									   LANG_LIST.LANG_CD);
									   
				END IF;
				
				IF LANG_LIST.QLTY_VEHL_CD9 IS NOT NULL THEN
				   
				   SP_MAKE_NATL_LANG_INFO(LANG_LIST.DL_EXPD_CO_CD,
									   LANG_LIST.DL_EXPD_NAT_CD,
									   LANG_LIST.QLTY_VEHL_CD9,
									   '08',
									   LANG_LIST.LANG_CD);
									   
				   SP_MAKE_NATL_LANG_INFO(LANG_LIST.DL_EXPD_CO_CD,
									   LANG_LIST.DL_EXPD_NAT_CD,
									   LANG_LIST.QLTY_VEHL_CD9,
									   '09',
									   LANG_LIST.LANG_CD);
									   
				   SP_MAKE_NATL_LANG_INFO(LANG_LIST.DL_EXPD_CO_CD,
									   LANG_LIST.DL_EXPD_NAT_CD,
									   LANG_LIST.QLTY_VEHL_CD9,
									   '10',
									   LANG_LIST.LANG_CD);
									   
				END IF;
				
				IF LANG_LIST.QLTY_VEHL_CD10 IS NOT NULL THEN
				   
				   SP_MAKE_NATL_LANG_INFO(LANG_LIST.DL_EXPD_CO_CD,
									   LANG_LIST.DL_EXPD_NAT_CD,
									   LANG_LIST.QLTY_VEHL_CD10,
									   '08',
									   LANG_LIST.LANG_CD);
									   
				   SP_MAKE_NATL_LANG_INFO(LANG_LIST.DL_EXPD_CO_CD,
									   LANG_LIST.DL_EXPD_NAT_CD,
									   LANG_LIST.QLTY_VEHL_CD10,
									   '09',
									   LANG_LIST.LANG_CD);
									   
				   SP_MAKE_NATL_LANG_INFO(LANG_LIST.DL_EXPD_CO_CD,
									   LANG_LIST.DL_EXPD_NAT_CD,
									   LANG_LIST.QLTY_VEHL_CD10,
									   '10',
									   LANG_LIST.LANG_CD);
									   
				END IF;
				
				IF LANG_LIST.QLTY_VEHL_CD11 IS NOT NULL THEN
				   
				   SP_MAKE_NATL_LANG_INFO(LANG_LIST.DL_EXPD_CO_CD,
									   LANG_LIST.DL_EXPD_NAT_CD,
									   LANG_LIST.QLTY_VEHL_CD11,
									   '08',
									   LANG_LIST.LANG_CD);
									   
				   SP_MAKE_NATL_LANG_INFO(LANG_LIST.DL_EXPD_CO_CD,
									   LANG_LIST.DL_EXPD_NAT_CD,
									   LANG_LIST.QLTY_VEHL_CD11,
									   '09',
									   LANG_LIST.LANG_CD);
									   
				   SP_MAKE_NATL_LANG_INFO(LANG_LIST.DL_EXPD_CO_CD,
									   LANG_LIST.DL_EXPD_NAT_CD,
									   LANG_LIST.QLTY_VEHL_CD11,
									   '10',
									   LANG_LIST.LANG_CD);
									   
				END IF;
				
				IF LANG_LIST.QLTY_VEHL_CD12 IS NOT NULL THEN
				   
				   SP_MAKE_NATL_LANG_INFO(LANG_LIST.DL_EXPD_CO_CD,
									   LANG_LIST.DL_EXPD_NAT_CD,
									   LANG_LIST.QLTY_VEHL_CD12,
									   '08',
									   LANG_LIST.LANG_CD);
									   
				   SP_MAKE_NATL_LANG_INFO(LANG_LIST.DL_EXPD_CO_CD,
									   LANG_LIST.DL_EXPD_NAT_CD,
									   LANG_LIST.QLTY_VEHL_CD12,
									   '09',
									   LANG_LIST.LANG_CD);
									   
				   SP_MAKE_NATL_LANG_INFO(LANG_LIST.DL_EXPD_CO_CD,
									   LANG_LIST.DL_EXPD_NAT_CD,
									   LANG_LIST.QLTY_VEHL_CD12,
									   '10',
									   LANG_LIST.LANG_CD);
									   
				END IF;
				
				IF LANG_LIST.QLTY_VEHL_CD13 IS NOT NULL THEN
				   
				   SP_MAKE_NATL_LANG_INFO(LANG_LIST.DL_EXPD_CO_CD,
									   LANG_LIST.DL_EXPD_NAT_CD,
									   LANG_LIST.QLTY_VEHL_CD13,
									   '08',
									   LANG_LIST.LANG_CD);
									   
				   SP_MAKE_NATL_LANG_INFO(LANG_LIST.DL_EXPD_CO_CD,
									   LANG_LIST.DL_EXPD_NAT_CD,
									   LANG_LIST.QLTY_VEHL_CD13,
									   '09',
									   LANG_LIST.LANG_CD);
									   
				   SP_MAKE_NATL_LANG_INFO(LANG_LIST.DL_EXPD_CO_CD,
									   LANG_LIST.DL_EXPD_NAT_CD,
									   LANG_LIST.QLTY_VEHL_CD13,
									   '10',
									   LANG_LIST.LANG_CD);
									   
				END IF;
				
				IF LANG_LIST.QLTY_VEHL_CD14 IS NOT NULL THEN
				   
				   SP_MAKE_NATL_LANG_INFO(LANG_LIST.DL_EXPD_CO_CD,
									   LANG_LIST.DL_EXPD_NAT_CD,
									   LANG_LIST.QLTY_VEHL_CD14,
									   '08',
									   LANG_LIST.LANG_CD);
									   
				   SP_MAKE_NATL_LANG_INFO(LANG_LIST.DL_EXPD_CO_CD,
									   LANG_LIST.DL_EXPD_NAT_CD,
									   LANG_LIST.QLTY_VEHL_CD14,
									   '09',
									   LANG_LIST.LANG_CD);
									   
				   SP_MAKE_NATL_LANG_INFO(LANG_LIST.DL_EXPD_CO_CD,
									   LANG_LIST.DL_EXPD_NAT_CD,
									   LANG_LIST.QLTY_VEHL_CD14,
									   '10',
									   LANG_LIST.LANG_CD);
									   
				END IF;
				
				IF LANG_LIST.QLTY_VEHL_CD15 IS NOT NULL THEN
				   
				   SP_MAKE_NATL_LANG_INFO(LANG_LIST.DL_EXPD_CO_CD,
									   LANG_LIST.DL_EXPD_NAT_CD,
									   LANG_LIST.QLTY_VEHL_CD15,
									   '08',
									   LANG_LIST.LANG_CD);
									   
				   SP_MAKE_NATL_LANG_INFO(LANG_LIST.DL_EXPD_CO_CD,
									   LANG_LIST.DL_EXPD_NAT_CD,
									   LANG_LIST.QLTY_VEHL_CD15,
									   '09',
									   LANG_LIST.LANG_CD);
									   
				   SP_MAKE_NATL_LANG_INFO(LANG_LIST.DL_EXPD_CO_CD,
									   LANG_LIST.DL_EXPD_NAT_CD,
									   LANG_LIST.QLTY_VEHL_CD15,
									   '10',
									   LANG_LIST.LANG_CD);
									   
				END IF;
				
			END LOOP;
	   
	   END SP_MAKE_NATL_NALG_LIST_HMC1;
	   
	   --국가/언어 코드 등록 
	   PROCEDURE SP_MAKE_NATL_LANG_INFO(P_DL_EXPD_CO_CD   VARCHAR2,
	  							        P_DL_EXPD_NAT_CD  VARCHAR2,
									    P_QLTY_VEHL_CD	  VARCHAR2,
									    P_MDL_MDY_CD	  VARCHAR2,
								        P_LANG_CD         VARCHAR2)
	   IS
	   	 
		 V_CURR_EENO VARCHAR2(8) := 'SYSTEM';
		 V_CNT		 NUMBER;
		 V_DATA_SN   NUMBER;
		 
	   BEGIN
	   		
			--차종코드 존재여부 확인 
			SELECT COUNT(*)
			INTO V_CNT
			FROM TB_VEHL_MGMT
			WHERE QLTY_VEHL_CD = P_QLTY_VEHL_CD
			AND MDL_MDY_CD = P_MDL_MDY_CD;
			
			IF V_CNT = 0 THEN
			   
			   RAISE_APPLICATION_ERROR(-20001, 'Invalid vehl info ' || 
			   								   'vehl:'  || P_QLTY_VEHL_CD || ',' || 
											   'mkyr: ' || P_MDL_MDY_CD);
											   
			END IF;
			
			--국가코드 존재여부 확인 
			SELECT COUNT(*)
			INTO V_CNT
			FROM TB_NATL_MGMT
			WHERE DL_EXPD_CO_CD = P_DL_EXPD_CO_CD
			AND DL_EXPD_NAT_CD = P_DL_EXPD_NAT_CD;
			
			IF V_CNT = 0 THEN
			   
			   RAISE_APPLICATION_ERROR(-20001, 'Invalid lang info ' || 
			   								   'company:' || P_DL_EXPD_CO_CD ||
			   								   'Latl:'  || P_DL_EXPD_NAT_CD);
											   
			END IF;
			
			--언어코드 존재여부 확인(언어코드 TEMP 테이블) 
			SELECT COUNT(*)
			INTO V_CNT
			FROM TB_LANG_MGMT_ORIGINAL --언어코드등록을 위하여 임시로 사용하는 테이블임(프로그램 실행시에는 사용안함)
			WHERE LANG_CD = P_LANG_CD;
			
			IF V_CNT = 0 THEN
			   
			   RAISE_APPLICATION_ERROR(-20001, 'Invalid lang info ' || 
			   								   'lang:'  || P_LANG_CD);
											   
			END IF;
			
--			SELECT COUNT(*)
--			INTO V_CNT
--			FROM TB_LANG_MGMT
--			WHERE QLTY_VEHL_CD = P_QLTY_VEHL_CD
--			AND MDL_MDY_CD = P_MDL_MDY_CD
--			AND LANG_CD = P_LANG_CD;
			
			UPDATE TB_LANG_MGMT
			SET DL_EXPD_REGN_CD = (SELECT DL_EXPD_REGN_CD
                                   FROM TB_LANG_MGMT_ORIGINAL
				                   WHERE LANG_CD = P_LANG_CD
			                      ),
				LANG_CD_NM = (SELECT LANG_CD_NM
                              FROM TB_LANG_MGMT_ORIGINAL
				              WHERE LANG_CD = P_LANG_CD
			                 ),
				USE_YN = 'Y',
				NAPC_YN = 'N',
			    UPDR_EENO = V_CURR_EENO,
				MDFY_DTM = SYSDATE
			WHERE QLTY_VEHL_CD = P_QLTY_VEHL_CD
			AND MDL_MDY_CD = P_MDL_MDY_CD
			AND LANG_CD = P_LANG_CD;
			
--			--언어코드 테이블에 데이터 존재치 않을 경우 데이터 Insert
--			IF V_CNT = 0 THEN 
            IF SQL%NOTFOUND THEN
			   
			   SELECT NVL(MAX(DATA_SN), 0) + 1
			   INTO V_DATA_SN
			   FROM TB_LANG_MGMT;
			   
			   INSERT INTO TB_LANG_MGMT
			   (DATA_SN, 
			    QLTY_VEHL_CD, 
				MDL_MDY_CD, 
				LANG_CD, 
				DL_EXPD_REGN_CD,
				LANG_CD_NM,
				USE_YN,
				NAPC_YN,
				PPRR_EENO,
				FRAM_DTM,
				UPDR_EENO,
				MDFY_DTM
			   )
			   VALUES
			   (V_DATA_SN,
			    P_QLTY_VEHL_CD,
			    P_MDL_MDY_CD,
				P_LANG_CD,
			    (SELECT DL_EXPD_REGN_CD
                 FROM TB_LANG_MGMT_ORIGINAL
				 WHERE LANG_CD = P_LANG_CD
			    ),
			    (SELECT LANG_CD_NM
                 FROM TB_LANG_MGMT_ORIGINAL
				 WHERE LANG_CD = P_LANG_CD
			    ),
				'Y',
				'N',
				V_CURR_EENO,
				SYSDATE,
				V_CURR_EENO,
			 	SYSDATE
			   );
			   
			END IF;
			
			--국가/언어코드 테이블에 데이터 저장 
			UPDATE TB_NATL_LANG_MGMT
			SET USE_YN = 'Y',
			    NAPC_YN = 'N',
				UPDR_EENO = V_CURR_EENO,
				MDFY_DTM = SYSDATE
			WHERE DL_EXPD_CO_CD = P_DL_EXPD_CO_CD
			AND DL_EXPD_NAT_CD = P_DL_EXPD_NAT_CD
			AND QLTY_VEHL_CD = P_QLTY_VEHL_CD
			AND MDL_MDY_CD = P_MDL_MDY_CD
			AND LANG_CD = P_LANG_CD;
			
			IF SQL%NOTFOUND THEN
			   
			   INSERT INTO TB_NATL_LANG_MGMT
			   (DL_EXPD_CO_CD,
			    DL_EXPD_NAT_CD,
				QLTY_VEHL_CD,
				MDL_MDY_CD,
				LANG_CD,
				USE_YN,
				NAPC_YN,
				PPRR_EENO,
				FRAM_DTM,
				UPDR_EENO,
				MDFY_DTM
			   )
			   VALUES
			   (P_DL_EXPD_CO_CD,
			    P_DL_EXPD_NAT_CD,
				P_QLTY_VEHL_CD,
				P_MDL_MDY_CD,
				P_LANG_CD,
				'Y',
				'N',
				V_CURR_EENO,
			    SYSDATE,
			    V_CURR_EENO,
				SYSDATE
			   );
			   
			END IF;
			
			--국가/차종/지역정보 매핑작업 수행 
			PG_NATL_LANG_MGMT.SP_NATL_VEHL_SAVE(P_DL_EXPD_CO_CD,
			                                    P_DL_EXPD_NAT_CD,
				                                P_QLTY_VEHL_CD,
				                                P_MDL_MDY_CD,
				                                P_LANG_CD,
				                                V_CURR_EENO);
			COMMIT;
			
			EXCEPTION
		     WHEN OTHERS THEN
			     ROLLBACK;
				 RAISE;
			
	   END SP_MAKE_NATL_LANG_INFO;
	   
	   --국가/차종/언어 수정(이미 입력된 값을 수정하는 작업을 수행하는 것임) 
	   PROCEDURE SP_SAVE_NATL_VEHL_LANG_INFO(P_DL_EXPD_CO_CD   VARCHAR2,
	  							             P_DL_EXPD_NAT_CD  VARCHAR2,
									         P_QLTY_VEHL_CD	   VARCHAR2,
											 P_MDL_MDY_CD	   VARCHAR2,
											 P_LANG_CD         VARCHAR2)
	   IS
	   	 V_DATA_SN   NUMBER;
		 
	   BEGIN
	   		
			UPDATE TB_LANG_MGMT
			SET DL_EXPD_REGN_CD = (SELECT DL_EXPD_REGN_CD
                                   FROM TB_LANG_MGMT_ORIGINAL
				                   WHERE LANG_CD = P_LANG_CD
			                      ),
				LANG_CD_NM = (SELECT LANG_CD_NM
                              FROM TB_LANG_MGMT_ORIGINAL
				              WHERE LANG_CD = P_LANG_CD
			                 ),
				USE_YN = 'Y',
				NAPC_YN = 'N',
			    UPDR_EENO = 'SYSTEM',
				MDFY_DTM = SYSDATE
			WHERE QLTY_VEHL_CD = P_QLTY_VEHL_CD
			AND MDL_MDY_CD = P_MDL_MDY_CD
			AND LANG_CD = P_LANG_CD;
			
--			--언어코드 테이블에 데이터 존재치 않을 경우 데이터 Insert
--			IF V_CNT = 0 THEN 
            IF SQL%NOTFOUND THEN
			   
			   SELECT NVL(MAX(DATA_SN), 0) + 1
			   INTO V_DATA_SN
			   FROM TB_LANG_MGMT;
			   
			   INSERT INTO TB_LANG_MGMT
			   (DATA_SN, 
			    QLTY_VEHL_CD, 
				MDL_MDY_CD, 
				LANG_CD, 
				DL_EXPD_REGN_CD,
				LANG_CD_NM,
				USE_YN,
				NAPC_YN,
				PPRR_EENO,
				FRAM_DTM,
				UPDR_EENO,
				MDFY_DTM
			   )
			   VALUES
			   (V_DATA_SN,
			    P_QLTY_VEHL_CD,
			    P_MDL_MDY_CD,
				P_LANG_CD,
			    (SELECT DL_EXPD_REGN_CD
                 FROM TB_LANG_MGMT_ORIGINAL
				 WHERE LANG_CD = P_LANG_CD
			    ),
			    (SELECT LANG_CD_NM
                 FROM TB_LANG_MGMT_ORIGINAL
				 WHERE LANG_CD = P_LANG_CD
			    ),
				'Y',
				'N',
				'SYSTEM',
				SYSDATE,
				'SYSTEM',
			 	SYSDATE
			   );
			   
			END IF;
			
			--국가/언어코드 테이블에 데이터 저장 
			UPDATE TB_NATL_LANG_MGMT
			SET LANG_CD = P_LANG_CD,
				USE_YN = 'Y',
			    NAPC_YN = 'N',
				UPDR_EENO = 'SYSTEM',
				MDFY_DTM = SYSDATE
			WHERE DL_EXPD_CO_CD = P_DL_EXPD_CO_CD
			AND DL_EXPD_NAT_CD = P_DL_EXPD_NAT_CD
			AND QLTY_VEHL_CD = P_QLTY_VEHL_CD
			AND MDL_MDY_CD = P_MDL_MDY_CD;
			
			IF SQL%NOTFOUND THEN
			   
			   INSERT INTO TB_NATL_LANG_MGMT
			   (DL_EXPD_CO_CD,
			    DL_EXPD_NAT_CD,
				QLTY_VEHL_CD,
				MDL_MDY_CD,
				LANG_CD,
				USE_YN,
				NAPC_YN,
				PPRR_EENO,
				FRAM_DTM,
				UPDR_EENO,
				MDFY_DTM
			   )
			   VALUES
			   (P_DL_EXPD_CO_CD,
			    P_DL_EXPD_NAT_CD,
				P_QLTY_VEHL_CD,
				P_MDL_MDY_CD,
				P_LANG_CD,
				'Y',
				'N',
				'SYSTEM',
			    SYSDATE,
			    'SYSTEM',
				SYSDATE
			   );
			   
			END IF;
			
			--국가/차종/지역정보 매핑작업 수행 
			PG_NATL_LANG_MGMT.SP_NATL_VEHL_SAVE(P_DL_EXPD_CO_CD,
			                                    P_DL_EXPD_NAT_CD,
				                                P_QLTY_VEHL_CD,
				                                P_MDL_MDY_CD,
				                                P_LANG_CD,
				                                'SYSTEM');
			COMMIT;
			
	   END SP_SAVE_NATL_VEHL_LANG_INFO;
	   
	   PROCEDURE SP_TEMP_COPY_AUTH(P_USER_EENO VARCHAR2)
	   IS
	   BEGIN
	   		
		  SP_COPY_AUTH_VEHL_INFO(P_USER_EENO,  '0003');
		  SP_COPY_AUTH_VEHL_INFO(P_USER_EENO,  '0004');
		  SP_COPY_AUTH_VEHL_INFO(P_USER_EENO,  '0005');
		  SP_COPY_AUTH_VEHL_INFO(P_USER_EENO,  '0008');
		  SP_COPY_AUTH_VEHL_INFO(P_USER_EENO,  '0009');
		  SP_COPY_AUTH_VEHL_INFO(P_USER_EENO,  '0010');
		  SP_COPY_AUTH_VEHL_INFO(P_USER_EENO,  '0011');
		  SP_COPY_AUTH_VEHL_INFO(P_USER_EENO,  '0013');
		  SP_COPY_AUTH_VEHL_INFO(P_USER_EENO,  '0015');
		  SP_COPY_AUTH_VEHL_INFO(P_USER_EENO,  '0019');
		  SP_COPY_AUTH_VEHL_INFO(P_USER_EENO,  '0020');
		  SP_COPY_AUTH_VEHL_INFO(P_USER_EENO,  '0021');
		  SP_COPY_AUTH_VEHL_INFO(P_USER_EENO,  '0022');
		  SP_COPY_AUTH_VEHL_INFO(P_USER_EENO,  '0023');
		  SP_COPY_AUTH_VEHL_INFO(P_USER_EENO,  '0024');
		  
		  COMMIT;
		    
	   END SP_TEMP_COPY_AUTH;
	   
	   
	   --사용자 권한정보 임시 복사하는 함수 
	   PROCEDURE SP_COPY_AUTH_VEHL_INFO(P_USER_EENO VARCHAR2,
	                                    P_MENU_ID   VARCHAR2)
	   IS
	   BEGIN
	   		
			INSERT INTO TB_AUTH_VEHL_MGMT
			(USER_EENO, MENU_ID, QLTY_VEHL_CD, CL_SCN_CD, PPRR_EENO, FRAM_DTM, UPDR_EENO, MDFY_DTM)
			SELECT P_USER_EENO, P_MENU_ID, QLTY_VEHL_CD, CL_SCN_CD, 'SYSTEM', SYSDATE, 'SYSTEM', SYSDATE
			FROM TB_AUTH_VEHL_MGMT
			WHERE USER_EENO = P_USER_EENO
			AND MENU_ID = '0002';
			
	   END SP_COPY_AUTH_VEHL_INFO;
	   
	   --체크리스트변경 정보 저장 
	   PROCEDURE SP_CHKLIST_INFO_SAVE
	   IS
	   	 
		 CURSOR CHK_LIST_INFO IS SELECT NO,
		 					  	 		ALTR_YMD,
		                                RCPM_SHAP_CD,
										DSPP_NM,
										CRGR_NM,
										VEHL_CD,
										ALTR_SBC
								 FROM TB_CHKLIST_INFO_TEMP
								 ORDER BY ALTR_YMD;
								 
		 V_EXPD_ALTR_NO TB_CHKLIST_INFO.DL_EXPD_ALTR_NO%TYPE;
								   
	   BEGIN
	   
	   		FOR CHK_LIST IN CHK_LIST_INFO LOOP
				
    			 --변경번호 생성 
    			 SELECT TO_CHAR(CHK_LIST.ALTR_YMD, 'YY') || '-' ||
    			        TRIM(TO_CHAR(NVL(TO_NUMBER(SUBSTR(MAX(DL_EXPD_ALTR_NO), 4, 4)) + 1, 1), '0000'))
    			 INTO V_EXPD_ALTR_NO
    			 FROM TB_CHKLIST_INFO
    			 WHERE ALTR_YMD LIKE TO_CHAR(CHK_LIST.ALTR_YMD, 'YYYY') || '%';
    			 
    			 --TB_CHKLIST_INFO 테이블에 값 신규 추가 
    			 INSERT INTO TB_CHKLIST_INFO
                 (DL_EXPD_ALTR_NO,
                  ALTR_YMD, 
    		      RCPM_SHAP_CD,
                  DSPP_NM, 
    		      CHGR_EENO,
                  CRGR_NM, 
    		      ALTR_SBC,
                  PPRR_EENO,
                  FRAM_DTM,
                  UPDR_EENO,
                  MDFY_DTM,
				  DEL_YN
    		     )
                 VALUES 
    		     (V_EXPD_ALTR_NO,
                  TO_CHAR(CHK_LIST.ALTR_YMD, 'YYYYMMDD'),
                  CHK_LIST.RCPM_SHAP_CD,
                  CHK_LIST.DSPP_NM,
    			  'SYSTEM',
                  CHK_LIST.CRGR_NM,
    			  CHK_LIST.ALTR_SBC,
    			  'SYSTEM',
    			  SYSDATE,
    			  'SYSTEM',
    			  SYSDATE,
				  'N'
    		     );
			     
				 INSERT INTO TB_CHKLIST_INFO_TEMP2
				 (NO,
				  ALTR_YMD,
				  DL_EXPD_ALTR_NO,
				  VEHL_CD
				 )
				 VALUES
				 (CHK_LIST.NO,
				  CHK_LIST.ALTR_YMD,
				  V_EXPD_ALTR_NO,
				  CHK_LIST.VEHL_CD
				 );
				 
			END LOOP;
	   		
			COMMIT;
			
	   END SP_CHKLIST_INFO_SAVE;
	   
	   --체크리스트변경 정보 저장2  
	   PROCEDURE SP_CHKLIST_INFO_SAVE2
	   IS
	   	 
		 CURSOR CHK_LIST_INFO IS SELECT NO,
		 					  	 		ALTR_YMD,
		                                RCPM_SHAP_CD,
										DSPP_NM,
										CRGR_NM,
										VEHL_CD,
										ALTR_SBC
								 FROM TB_CHKLIST_INFO_TEMP
								 ORDER BY ALTR_YMD, NO, RCPM_SHAP_CD;
								 
		 V_EXPD_ALTR_NO TB_CHKLIST_INFO.DL_EXPD_ALTR_NO%TYPE;
		 
		 V_CNT NUMBER;
		 				   
	   BEGIN
	   
	   		FOR CHK_LIST IN CHK_LIST_INFO LOOP
				
				SELECT COUNT(*)
				INTO V_CNT
				FROM TB_CHKLIST_INFO_TEMP2
				WHERE NO = CHK_LIST.NO
				AND ALTR_YMD = CHK_LIST.ALTR_YMD;
				
				IF V_CNT = 0 THEN
				   
				     --변경번호 생성 
        			 SELECT TO_CHAR(CHK_LIST.ALTR_YMD, 'YY') || '-' ||
        			        TRIM(TO_CHAR(NVL(TO_NUMBER(SUBSTR(MAX(DL_EXPD_ALTR_NO), 4, 4)) + 1, 1), '0000'))
        			 INTO V_EXPD_ALTR_NO
        			 FROM TB_CHKLIST_INFO
        			 WHERE ALTR_YMD LIKE TO_CHAR(CHK_LIST.ALTR_YMD, 'YYYY') || '%';
        			 
        			 --TB_CHKLIST_INFO 테이블에 값 신규 추가 
        			 INSERT INTO TB_CHKLIST_INFO
                     (DL_EXPD_ALTR_NO,
                      ALTR_YMD, 
        		      RCPM_SHAP_CD,
                      DSPP_NM, 
        		      CHGR_EENO,
                      CRGR_NM, 
        		      ALTR_SBC,
                      PPRR_EENO,
                      FRAM_DTM,
                      UPDR_EENO,
                      MDFY_DTM,
    				  DEL_YN
        		     )
                     VALUES 
        		     (V_EXPD_ALTR_NO,
                      TO_CHAR(CHK_LIST.ALTR_YMD, 'YYYYMMDD'),
                      CHK_LIST.RCPM_SHAP_CD,
                      CHK_LIST.DSPP_NM,
        			  'SYSTEM',
                      CHK_LIST.CRGR_NM,
        			  CHK_LIST.ALTR_SBC,
        			  'SYSTEM',
        			  SYSDATE,
        			  'SYSTEM',
        			  SYSDATE,
    				  'N'
        		     );
				 
				END IF;
				
				SELECT COUNT(*)
				INTO V_CNT
				FROM TB_CHKLIST_INFO_TEMP2
				WHERE NO = CHK_LIST.NO
				--AND ALTR_YMD = CHK_LIST.ALTR_YMD;
				AND VEHL_CD = CHK_LIST.VEHL_CD;
					
				IF V_CNT = 0 THEN
				   
				   INSERT INTO TB_CHKLIST_INFO_TEMP2
				   (NO,
				    ALTR_YMD,
				 	DL_EXPD_ALTR_NO,
				 	VEHL_CD
				   )
				   VALUES
				   (CHK_LIST.NO,
				    CHK_LIST.ALTR_YMD,
				    V_EXPD_ALTR_NO,
				    CHK_LIST.VEHL_CD
				   );
				
				END IF;
				
				 
			END LOOP;
	   		
			COMMIT;
			
	   END SP_CHKLIST_INFO_SAVE2;
	   
	   --체크리스트변경 상세정보 저장 
	   PROCEDURE SP_CHKLIST_DTL_INFO_SAVE
	   IS
	   
	   	 --V_LANG_CD  VARCHAR2(3);
         --V_LANG_VAL VARCHAR2(100);
		 
	   	 CURSOR CHK_LIST_DTL_INFO IS SELECT B.DL_EXPD_ALTR_NO,
		 					  	 			A.VEHL_CD,
										    COL_AR,
                                            COL_AS,
                                            COL_CH,
                                            COL_CN,
                                            COL_DE,
                                            COL_EA,
                                            COL_EC,
                                            COL_EE,
                                            COL_EM,
                                            COL_EP,
                                            COL_EU,
                                            COL_FE,
                                            COL_FG,
                                            COL_GE,
                                            COL_HO,
                                            COL_HU,
                                            COL_IT,
                                            COL_JA,
                                            COL_KO,
                                            COL_NR,
                                            COL_PB,
                                            COL_PE,
                                            COL_PO,
                                            COL_RU,
                                            COL_LY,
                                            COL_SE,
                                            COL_SG,
                                            COL_SM,
                                            COL_SV,
                                            COL_SW,
                                            COL_TW,
                                            COL_UK
								 FROM TB_CHKLIST_DTL_INFO_TEMP A,
								 	  TB_CHKLIST_INFO_TEMP2 B
								 WHERE A.NO = B.NO
								 AND A.VEHL_CD = B.VEHL_CD
								 ORDER BY A.NO;
								 
			
	   BEGIN
	   		
			FOR CHK_LIST IN CHK_LIST_DTL_INFO LOOP
				
				
				INSERT INTO TB_CHKLIST_DTL_INFO
    		    (DL_EXPD_ALTR_NO,
    		     QLTY_VEHL_CD,
    		     LANG_CD,
    		     N_PRNT_PBCN_NO,
    		     PPRR_EENO,
    		     FRAM_DTM,
    		     UPDR_EENO,
    		     MDFY_DTM
    		    )
    		    VALUES
    		    (CHK_LIST.DL_EXPD_ALTR_NO,
    		     CHK_LIST.VEHL_CD,
    		     'AR',
    		     CHK_LIST.COL_AR,
    		     'SYSTEM',
    		     SYSDATE,
    		     'SYSTEM',
    		     SYSDATE
    		    );
				
				
				INSERT INTO TB_CHKLIST_DTL_INFO
				(DL_EXPD_ALTR_NO,
				 QLTY_VEHL_CD,
				 LANG_CD,
				 N_PRNT_PBCN_NO,
				 PPRR_EENO,
				 FRAM_DTM,
				 UPDR_EENO,
				 MDFY_DTM
				)
				VALUES
				(CHK_LIST.DL_EXPD_ALTR_NO,
				 CHK_LIST.VEHL_CD,
				 'AS',
				 CHK_LIST.COL_AS,
				 'SYSTEM',
				 SYSDATE,
				 'SYSTEM',
				 SYSDATE
				);
				
				INSERT INTO TB_CHKLIST_DTL_INFO
				(DL_EXPD_ALTR_NO,
				 QLTY_VEHL_CD,
				 LANG_CD,
				 N_PRNT_PBCN_NO,
				 PPRR_EENO,
				 FRAM_DTM,
				 UPDR_EENO,
				 MDFY_DTM
				)
				VALUES
				(CHK_LIST.DL_EXPD_ALTR_NO,
				 CHK_LIST.VEHL_CD,
				 'CH',
				 CHK_LIST.COL_CH,
				 'SYSTEM',
				 SYSDATE,
				 'SYSTEM',
				 SYSDATE
				);
				
				INSERT INTO TB_CHKLIST_DTL_INFO
				(DL_EXPD_ALTR_NO,
				 QLTY_VEHL_CD,
				 LANG_CD,
				 N_PRNT_PBCN_NO,
				 PPRR_EENO,
				 FRAM_DTM,
				 UPDR_EENO,
				 MDFY_DTM
				)
				VALUES
				(CHK_LIST.DL_EXPD_ALTR_NO,
				 CHK_LIST.VEHL_CD,
				 'CN',
				 CHK_LIST.COL_CN,
				 'SYSTEM',
				 SYSDATE,
				 'SYSTEM',
				 SYSDATE
				);
				
				INSERT INTO TB_CHKLIST_DTL_INFO
				(DL_EXPD_ALTR_NO,
				 QLTY_VEHL_CD,
				 LANG_CD,
				 N_PRNT_PBCN_NO,
				 PPRR_EENO,
				 FRAM_DTM,
				 UPDR_EENO,
				 MDFY_DTM
				)
				VALUES
				(CHK_LIST.DL_EXPD_ALTR_NO,
				 CHK_LIST.VEHL_CD,
				 'DE',
				 CHK_LIST.COL_DE,
				 'SYSTEM',
				 SYSDATE,
				 'SYSTEM',
				 SYSDATE
				);
				
				INSERT INTO TB_CHKLIST_DTL_INFO
				(DL_EXPD_ALTR_NO,
				 QLTY_VEHL_CD,
				 LANG_CD,
				 N_PRNT_PBCN_NO,
				 PPRR_EENO,
				 FRAM_DTM,
				 UPDR_EENO,
				 MDFY_DTM
				)
				VALUES
				(CHK_LIST.DL_EXPD_ALTR_NO,
				 CHK_LIST.VEHL_CD,
				 'EA',
				 CHK_LIST.COL_EA,
				 'SYSTEM',
				 SYSDATE,
				 'SYSTEM',
				 SYSDATE
				);
				
				INSERT INTO TB_CHKLIST_DTL_INFO
				(DL_EXPD_ALTR_NO,
				 QLTY_VEHL_CD,
				 LANG_CD,
				 N_PRNT_PBCN_NO,
				 PPRR_EENO,
				 FRAM_DTM,
				 UPDR_EENO,
				 MDFY_DTM
				)
				VALUES
				(CHK_LIST.DL_EXPD_ALTR_NO,
				 CHK_LIST.VEHL_CD,
				 'EC',
				 CHK_LIST.COL_EC,
				 'SYSTEM',
				 SYSDATE,
				 'SYSTEM',
				 SYSDATE
				);
				
				INSERT INTO TB_CHKLIST_DTL_INFO
				(DL_EXPD_ALTR_NO,
				 QLTY_VEHL_CD,
				 LANG_CD,
				 N_PRNT_PBCN_NO,
				 PPRR_EENO,
				 FRAM_DTM,
				 UPDR_EENO,
				 MDFY_DTM
				)
				VALUES
				(CHK_LIST.DL_EXPD_ALTR_NO,
				 CHK_LIST.VEHL_CD,
				 'EE',
				 CHK_LIST.COL_EE,
				 'SYSTEM',
				 SYSDATE,
				 'SYSTEM',
				 SYSDATE
				);
				
				INSERT INTO TB_CHKLIST_DTL_INFO
				(DL_EXPD_ALTR_NO,
				 QLTY_VEHL_CD,
				 LANG_CD,
				 N_PRNT_PBCN_NO,
				 PPRR_EENO,
				 FRAM_DTM,
				 UPDR_EENO,
				 MDFY_DTM
				)
				VALUES
				(CHK_LIST.DL_EXPD_ALTR_NO,
				 CHK_LIST.VEHL_CD,
				 'EM',
				 CHK_LIST.COL_EM,
				 'SYSTEM',
				 SYSDATE,
				 'SYSTEM',
				 SYSDATE
				);
				
				INSERT INTO TB_CHKLIST_DTL_INFO
				(DL_EXPD_ALTR_NO,
				 QLTY_VEHL_CD,
				 LANG_CD,
				 N_PRNT_PBCN_NO,
				 PPRR_EENO,
				 FRAM_DTM,
				 UPDR_EENO,
				 MDFY_DTM
				)
				VALUES
				(CHK_LIST.DL_EXPD_ALTR_NO,
				 CHK_LIST.VEHL_CD,
				 'EP',
				 CHK_LIST.COL_EP,
				 'SYSTEM',
				 SYSDATE,
				 'SYSTEM',
				 SYSDATE
				);
				
				INSERT INTO TB_CHKLIST_DTL_INFO
				(DL_EXPD_ALTR_NO,
				 QLTY_VEHL_CD,
				 LANG_CD,
				 N_PRNT_PBCN_NO,
				 PPRR_EENO,
				 FRAM_DTM,
				 UPDR_EENO,
				 MDFY_DTM
				)
				VALUES
				(CHK_LIST.DL_EXPD_ALTR_NO,
				 CHK_LIST.VEHL_CD,
				 'EU',
				 CHK_LIST.COL_EU,
				 'SYSTEM',
				 SYSDATE,
				 'SYSTEM',
				 SYSDATE
				);
				
				INSERT INTO TB_CHKLIST_DTL_INFO
				(DL_EXPD_ALTR_NO,
				 QLTY_VEHL_CD,
				 LANG_CD,
				 N_PRNT_PBCN_NO,
				 PPRR_EENO,
				 FRAM_DTM,
				 UPDR_EENO,
				 MDFY_DTM
				)
				VALUES
				(CHK_LIST.DL_EXPD_ALTR_NO,
				 CHK_LIST.VEHL_CD,
				 'FE',
				 CHK_LIST.COL_FE,
				 'SYSTEM',
				 SYSDATE,
				 'SYSTEM',
				 SYSDATE
				);
				
				INSERT INTO TB_CHKLIST_DTL_INFO
				(DL_EXPD_ALTR_NO,
				 QLTY_VEHL_CD,
				 LANG_CD,
				 N_PRNT_PBCN_NO,
				 PPRR_EENO,
				 FRAM_DTM,
				 UPDR_EENO,
				 MDFY_DTM
				)
				VALUES
				(CHK_LIST.DL_EXPD_ALTR_NO,
				 CHK_LIST.VEHL_CD,
				 'FG',
				 CHK_LIST.COL_FG,
				 'SYSTEM',
				 SYSDATE,
				 'SYSTEM',
				 SYSDATE
				);
				
				INSERT INTO TB_CHKLIST_DTL_INFO
				(DL_EXPD_ALTR_NO,
				 QLTY_VEHL_CD,
				 LANG_CD,
				 N_PRNT_PBCN_NO,
				 PPRR_EENO,
				 FRAM_DTM,
				 UPDR_EENO,
				 MDFY_DTM
				)
				VALUES
				(CHK_LIST.DL_EXPD_ALTR_NO,
				 CHK_LIST.VEHL_CD,
				 'GE',
				 CHK_LIST.COL_GE,
				 'SYSTEM',
				 SYSDATE,
				 'SYSTEM',
				 SYSDATE
				);
                
				INSERT INTO TB_CHKLIST_DTL_INFO
				(DL_EXPD_ALTR_NO,
				 QLTY_VEHL_CD,
				 LANG_CD,
				 N_PRNT_PBCN_NO,
				 PPRR_EENO,
				 FRAM_DTM,
				 UPDR_EENO,
				 MDFY_DTM
				)
				VALUES
				(CHK_LIST.DL_EXPD_ALTR_NO,
				 CHK_LIST.VEHL_CD,
				 'HO',
				 CHK_LIST.COL_HO,
				 'SYSTEM',
				 SYSDATE,
				 'SYSTEM',
				 SYSDATE
				);                            
                                            
                INSERT INTO TB_CHKLIST_DTL_INFO
				(DL_EXPD_ALTR_NO,
				 QLTY_VEHL_CD,
				 LANG_CD,
				 N_PRNT_PBCN_NO,
				 PPRR_EENO,
				 FRAM_DTM,
				 UPDR_EENO,
				 MDFY_DTM
				)
				VALUES
				(CHK_LIST.DL_EXPD_ALTR_NO,
				 CHK_LIST.VEHL_CD,
				 'HU',
				 CHK_LIST.COL_HU,
				 'SYSTEM',
				 SYSDATE,
				 'SYSTEM',
				 SYSDATE
				);                                    
                
				INSERT INTO TB_CHKLIST_DTL_INFO
				(DL_EXPD_ALTR_NO,
				 QLTY_VEHL_CD,
				 LANG_CD,
				 N_PRNT_PBCN_NO,
				 PPRR_EENO,
				 FRAM_DTM,
				 UPDR_EENO,
				 MDFY_DTM
				)
				VALUES
				(CHK_LIST.DL_EXPD_ALTR_NO,
				 CHK_LIST.VEHL_CD,
				 'IT',
				 CHK_LIST.COL_IT,
				 'SYSTEM',
				 SYSDATE,
				 'SYSTEM',
				 SYSDATE
				);                                  
                                            
                INSERT INTO TB_CHKLIST_DTL_INFO
				(DL_EXPD_ALTR_NO,
				 QLTY_VEHL_CD,
				 LANG_CD,
				 N_PRNT_PBCN_NO,
				 PPRR_EENO,
				 FRAM_DTM,
				 UPDR_EENO,
				 MDFY_DTM
				)
				VALUES
				(CHK_LIST.DL_EXPD_ALTR_NO,
				 CHK_LIST.VEHL_CD,
				 'JA',
				 CHK_LIST.COL_JA,
				 'SYSTEM',
				 SYSDATE,
				 'SYSTEM',
				 SYSDATE
				);                                    
                
				INSERT INTO TB_CHKLIST_DTL_INFO
				(DL_EXPD_ALTR_NO,
				 QLTY_VEHL_CD,
				 LANG_CD,
				 N_PRNT_PBCN_NO,
				 PPRR_EENO,
				 FRAM_DTM,
				 UPDR_EENO,
				 MDFY_DTM
				)
				VALUES
				(CHK_LIST.DL_EXPD_ALTR_NO,
				 CHK_LIST.VEHL_CD,
				 'KO',
				 CHK_LIST.COL_KO,
				 'SYSTEM',
				 SYSDATE,
				 'SYSTEM',
				 SYSDATE
				);                                    
                
				INSERT INTO TB_CHKLIST_DTL_INFO
				(DL_EXPD_ALTR_NO,
				 QLTY_VEHL_CD,
				 LANG_CD,
				 N_PRNT_PBCN_NO,
				 PPRR_EENO,
				 FRAM_DTM,
				 UPDR_EENO,
				 MDFY_DTM
				)
				VALUES
				(CHK_LIST.DL_EXPD_ALTR_NO,
				 CHK_LIST.VEHL_CD,
				 'NR',
				 CHK_LIST.COL_NR,
				 'SYSTEM',
				 SYSDATE,
				 'SYSTEM',
				 SYSDATE
				);                                       
                                            
                INSERT INTO TB_CHKLIST_DTL_INFO
				(DL_EXPD_ALTR_NO,
				 QLTY_VEHL_CD,
				 LANG_CD,
				 N_PRNT_PBCN_NO,
				 PPRR_EENO,
				 FRAM_DTM,
				 UPDR_EENO,
				 MDFY_DTM
				)
				VALUES
				(CHK_LIST.DL_EXPD_ALTR_NO,
				 CHK_LIST.VEHL_CD,
				 'PB',
				 CHK_LIST.COL_PB,
				 'SYSTEM',
				 SYSDATE,
				 'SYSTEM',
				 SYSDATE
				);                               
                
				INSERT INTO TB_CHKLIST_DTL_INFO
				(DL_EXPD_ALTR_NO,
				 QLTY_VEHL_CD,
				 LANG_CD,
				 N_PRNT_PBCN_NO,
				 PPRR_EENO,
				 FRAM_DTM,
				 UPDR_EENO,
				 MDFY_DTM
				)
				VALUES
				(CHK_LIST.DL_EXPD_ALTR_NO,
				 CHK_LIST.VEHL_CD,
				 'PE',
				 CHK_LIST.COL_PE,
				 'SYSTEM',
				 SYSDATE,
				 'SYSTEM',
				 SYSDATE
				);                               
                
				INSERT INTO TB_CHKLIST_DTL_INFO
				(DL_EXPD_ALTR_NO,
				 QLTY_VEHL_CD,
				 LANG_CD,
				 N_PRNT_PBCN_NO,
				 PPRR_EENO,
				 FRAM_DTM,
				 UPDR_EENO,
				 MDFY_DTM
				)
				VALUES
				(CHK_LIST.DL_EXPD_ALTR_NO,
				 CHK_LIST.VEHL_CD,
				 'PO',
				 CHK_LIST.COL_PO,
				 'SYSTEM',
				 SYSDATE,
				 'SYSTEM',
				 SYSDATE
				);                                
                                            
                INSERT INTO TB_CHKLIST_DTL_INFO
				(DL_EXPD_ALTR_NO,
				 QLTY_VEHL_CD,
				 LANG_CD,
				 N_PRNT_PBCN_NO,
				 PPRR_EENO,
				 FRAM_DTM,
				 UPDR_EENO,
				 MDFY_DTM
				)
				VALUES
				(CHK_LIST.DL_EXPD_ALTR_NO,
				 CHK_LIST.VEHL_CD,
				 'RU',
				 CHK_LIST.COL_RU,
				 'SYSTEM',
				 SYSDATE,
				 'SYSTEM',
				 SYSDATE
				);                          
                
				INSERT INTO TB_CHKLIST_DTL_INFO
				(DL_EXPD_ALTR_NO,
				 QLTY_VEHL_CD,
				 LANG_CD,
				 N_PRNT_PBCN_NO,
				 PPRR_EENO,
				 FRAM_DTM,
				 UPDR_EENO,
				 MDFY_DTM
				)
				VALUES
				(CHK_LIST.DL_EXPD_ALTR_NO,
				 CHK_LIST.VEHL_CD,
				 'LY',
				 CHK_LIST.COL_LY,
				 'SYSTEM',
				 SYSDATE,
				 'SYSTEM',
				 SYSDATE
				);                                      
                
				INSERT INTO TB_CHKLIST_DTL_INFO
				(DL_EXPD_ALTR_NO,
				 QLTY_VEHL_CD,
				 LANG_CD,
				 N_PRNT_PBCN_NO,
				 PPRR_EENO,
				 FRAM_DTM,
				 UPDR_EENO,
				 MDFY_DTM
				)
				VALUES
				(CHK_LIST.DL_EXPD_ALTR_NO,
				 CHK_LIST.VEHL_CD,
				 'SE',
				 CHK_LIST.COL_SE,
				 'SYSTEM',
				 SYSDATE,
				 'SYSTEM',
				 SYSDATE  
				);                          
                                            
                INSERT INTO TB_CHKLIST_DTL_INFO
				(DL_EXPD_ALTR_NO,
				 QLTY_VEHL_CD,
				 LANG_CD,
				 N_PRNT_PBCN_NO,
				 PPRR_EENO,
				 FRAM_DTM,
				 UPDR_EENO,
				 MDFY_DTM
				)
				VALUES
				(CHK_LIST.DL_EXPD_ALTR_NO,
				 CHK_LIST.VEHL_CD,
				 'SG',
				 CHK_LIST.COL_SG,
				 'SYSTEM',
				 SYSDATE,
				 'SYSTEM',
				 SYSDATE  
				);                                    
                
				INSERT INTO TB_CHKLIST_DTL_INFO
				(DL_EXPD_ALTR_NO,
				 QLTY_VEHL_CD,
				 LANG_CD,
				 N_PRNT_PBCN_NO,
				 PPRR_EENO,
				 FRAM_DTM,
				 UPDR_EENO,
				 MDFY_DTM
				)
				VALUES
				(CHK_LIST.DL_EXPD_ALTR_NO,
				 CHK_LIST.VEHL_CD,
				 'SM',
				 CHK_LIST.COL_SM,
				 'SYSTEM',
				 SYSDATE,
				 'SYSTEM',
				 SYSDATE  
				);                              
                
				INSERT INTO TB_CHKLIST_DTL_INFO
				(DL_EXPD_ALTR_NO,
				 QLTY_VEHL_CD,
				 LANG_CD,
				 N_PRNT_PBCN_NO,
				 PPRR_EENO,
				 FRAM_DTM,
				 UPDR_EENO,
				 MDFY_DTM
				)
				VALUES
				(CHK_LIST.DL_EXPD_ALTR_NO,
				 CHK_LIST.VEHL_CD,
				 'SV',
				 CHK_LIST.COL_SV,
				 'SYSTEM',
				 SYSDATE,
				 'SYSTEM',
				 SYSDATE  
				);                                   
                                            
                INSERT INTO TB_CHKLIST_DTL_INFO
				(DL_EXPD_ALTR_NO,
				 QLTY_VEHL_CD,
				 LANG_CD,
				 N_PRNT_PBCN_NO,
				 PPRR_EENO,
				 FRAM_DTM,
				 UPDR_EENO,
				 MDFY_DTM
				)
				VALUES
				(CHK_LIST.DL_EXPD_ALTR_NO,
				 CHK_LIST.VEHL_CD,
				 'SW',
				 CHK_LIST.COL_SW,
				 'SYSTEM',
				 SYSDATE,
				 'SYSTEM',
				 SYSDATE  
				);                             
                 
				INSERT INTO TB_CHKLIST_DTL_INFO
				(DL_EXPD_ALTR_NO,
				 QLTY_VEHL_CD,
				 LANG_CD,
				 N_PRNT_PBCN_NO,
				 PPRR_EENO,
				 FRAM_DTM,
				 UPDR_EENO,
				 MDFY_DTM
				)
				VALUES
				(CHK_LIST.DL_EXPD_ALTR_NO,
				 CHK_LIST.VEHL_CD,
				 'TW',
				 CHK_LIST.COL_TW,
				 'SYSTEM',
				 SYSDATE,
				 'SYSTEM',
				 SYSDATE  
				);    
				 
				INSERT INTO TB_CHKLIST_DTL_INFO
				(DL_EXPD_ALTR_NO,
				 QLTY_VEHL_CD,
				 LANG_CD,
				 N_PRNT_PBCN_NO,
				 PPRR_EENO,
				 FRAM_DTM,
				 UPDR_EENO,
				 MDFY_DTM
				)
				VALUES
				(CHK_LIST.DL_EXPD_ALTR_NO,
				 CHK_LIST.VEHL_CD,
				 'UK',
				 CHK_LIST.COL_UK,
				 'SYSTEM',
				 SYSDATE,
				 'SYSTEM',
				 SYSDATE  
				);                               
						
			END LOOP;
			
	   END SP_CHKLIST_DTL_INFO_SAVE;
	   
	   --체크리스트변경 상세정보 저장2 
	   PROCEDURE SP_CHKLIST_DTL_INFO_SAVE2
	   IS
	   	 
		 V_ALTR_NO VARCHAR2(15);
		 V_VEHL_CD VARCHAR2(4);
		 
	   	 CURSOR CHK_LIST_DTL_INFO IS SELECT B.DL_EXPD_ALTR_NO,
		 					  	 			A.VEHL_CD,
										    COL_AR,
                                            COL_AS,
                                            COL_CH,
                                            COL_CN,
											COL_CZ,
                                            COL_DE,
                                            COL_EA,
                                            COL_EC,
                                            COL_EE,
											COL_EG,
                                            COL_EM,
                                            COL_EP,
                                            COL_EU,
                                            COL_FE,
                                            COL_FG,
                                            COL_GE,
                                            COL_HO,
                                            COL_HU,
                                            COL_IT,
                                            COL_JA,
                                            COL_KO,
                                            COL_NR,
                                            COL_PB,
                                            COL_PE,
                                            COL_PO,
                                            COL_RU,
                                            COL_LY,
                                            COL_SE,
                                            COL_SG,
                                            COL_SM,
                                            COL_SV,
                                            COL_SW,
                                            COL_TW,
                                            COL_UK
								 FROM TB_CHKLIST_DTL_INFO_TEMP2 A,
								 	  TB_CHKLIST_INFO_TEMP2 B
								 WHERE A.NO = B.NO
								 AND A.VEHL_CD = B.VEHL_CD
								 ORDER BY A.NO;
								 
			
	   BEGIN
	   		
			FOR CHK_LIST IN CHK_LIST_DTL_INFO LOOP
				
				V_ALTR_NO := CHK_LIST.DL_EXPD_ALTR_NO;
		 		V_VEHL_CD := CHK_LIST.VEHL_CD;
		 
				INSERT INTO TB_CHKLIST_DTL_INFO
    		    (DL_EXPD_ALTR_NO,
    		     QLTY_VEHL_CD,
    		     LANG_CD,
    		     N_PRNT_PBCN_NO,
    		     PPRR_EENO,
    		     FRAM_DTM,
    		     UPDR_EENO,
    		     MDFY_DTM
    		    )
    		    VALUES
    		    (CHK_LIST.DL_EXPD_ALTR_NO,
    		     CHK_LIST.VEHL_CD,
    		     'AR',
    		     CHK_LIST.COL_AR,
    		     'SYSTEM',
    		     SYSDATE,
    		     'SYSTEM',
    		     SYSDATE
    		    );
				
				
				INSERT INTO TB_CHKLIST_DTL_INFO
				(DL_EXPD_ALTR_NO,
				 QLTY_VEHL_CD,
				 LANG_CD,
				 N_PRNT_PBCN_NO,
				 PPRR_EENO,
				 FRAM_DTM,
				 UPDR_EENO,
				 MDFY_DTM
				)
				VALUES
				(CHK_LIST.DL_EXPD_ALTR_NO,
				 CHK_LIST.VEHL_CD,
				 'AS',
				 CHK_LIST.COL_AS,
				 'SYSTEM',
				 SYSDATE,
				 'SYSTEM',
				 SYSDATE
				);
				
				INSERT INTO TB_CHKLIST_DTL_INFO
				(DL_EXPD_ALTR_NO,
				 QLTY_VEHL_CD,
				 LANG_CD,
				 N_PRNT_PBCN_NO,
				 PPRR_EENO,
				 FRAM_DTM,
				 UPDR_EENO,
				 MDFY_DTM
				)
				VALUES
				(CHK_LIST.DL_EXPD_ALTR_NO,
				 CHK_LIST.VEHL_CD,
				 'CH',
				 CHK_LIST.COL_CH,
				 'SYSTEM',
				 SYSDATE,
				 'SYSTEM',
				 SYSDATE
				);
				
				INSERT INTO TB_CHKLIST_DTL_INFO
				(DL_EXPD_ALTR_NO,
				 QLTY_VEHL_CD,
				 LANG_CD,
				 N_PRNT_PBCN_NO,
				 PPRR_EENO,
				 FRAM_DTM,
				 UPDR_EENO,
				 MDFY_DTM
				)
				VALUES
				(CHK_LIST.DL_EXPD_ALTR_NO,
				 CHK_LIST.VEHL_CD,
				 'CN',
				 CHK_LIST.COL_CN,
				 'SYSTEM',
				 SYSDATE,
				 'SYSTEM',
				 SYSDATE
				);
				
				INSERT INTO TB_CHKLIST_DTL_INFO
				(DL_EXPD_ALTR_NO,
				 QLTY_VEHL_CD,
				 LANG_CD,
				 N_PRNT_PBCN_NO,
				 PPRR_EENO,
				 FRAM_DTM,
				 UPDR_EENO,
				 MDFY_DTM
				)
				VALUES
				(CHK_LIST.DL_EXPD_ALTR_NO,
				 CHK_LIST.VEHL_CD,
				 'CZ',
				 CHK_LIST.COL_CZ,
				 'SYSTEM',
				 SYSDATE,
				 'SYSTEM',
				 SYSDATE
				);
				
				INSERT INTO TB_CHKLIST_DTL_INFO
				(DL_EXPD_ALTR_NO,
				 QLTY_VEHL_CD,
				 LANG_CD,
				 N_PRNT_PBCN_NO,
				 PPRR_EENO,
				 FRAM_DTM,
				 UPDR_EENO,
				 MDFY_DTM
				)
				VALUES
				(CHK_LIST.DL_EXPD_ALTR_NO,
				 CHK_LIST.VEHL_CD,
				 'DE',
				 CHK_LIST.COL_DE,
				 'SYSTEM',
				 SYSDATE,
				 'SYSTEM',
				 SYSDATE
				);
				
				INSERT INTO TB_CHKLIST_DTL_INFO
				(DL_EXPD_ALTR_NO,
				 QLTY_VEHL_CD,
				 LANG_CD,
				 N_PRNT_PBCN_NO,
				 PPRR_EENO,
				 FRAM_DTM,
				 UPDR_EENO,
				 MDFY_DTM
				)
				VALUES
				(CHK_LIST.DL_EXPD_ALTR_NO,
				 CHK_LIST.VEHL_CD,
				 'EA',
				 CHK_LIST.COL_EA,
				 'SYSTEM',
				 SYSDATE,
				 'SYSTEM',
				 SYSDATE
				);
				
				INSERT INTO TB_CHKLIST_DTL_INFO
				(DL_EXPD_ALTR_NO,
				 QLTY_VEHL_CD,
				 LANG_CD,
				 N_PRNT_PBCN_NO,
				 PPRR_EENO,
				 FRAM_DTM,
				 UPDR_EENO,
				 MDFY_DTM
				)
				VALUES
				(CHK_LIST.DL_EXPD_ALTR_NO,
				 CHK_LIST.VEHL_CD,
				 'EC',
				 CHK_LIST.COL_EC,
				 'SYSTEM',
				 SYSDATE,
				 'SYSTEM',
				 SYSDATE
				);
				
				INSERT INTO TB_CHKLIST_DTL_INFO
				(DL_EXPD_ALTR_NO,
				 QLTY_VEHL_CD,
				 LANG_CD,
				 N_PRNT_PBCN_NO,
				 PPRR_EENO,
				 FRAM_DTM,
				 UPDR_EENO,
				 MDFY_DTM
				)
				VALUES
				(CHK_LIST.DL_EXPD_ALTR_NO,
				 CHK_LIST.VEHL_CD,
				 'EE',
				 CHK_LIST.COL_EE,
				 'SYSTEM',
				 SYSDATE,
				 'SYSTEM',
				 SYSDATE
				);
				
				INSERT INTO TB_CHKLIST_DTL_INFO
				(DL_EXPD_ALTR_NO,
				 QLTY_VEHL_CD,
				 LANG_CD,
				 N_PRNT_PBCN_NO,
				 PPRR_EENO,
				 FRAM_DTM,
				 UPDR_EENO,
				 MDFY_DTM
				)
				VALUES
				(CHK_LIST.DL_EXPD_ALTR_NO,
				 CHK_LIST.VEHL_CD,
				 'EG',
				 CHK_LIST.COL_EG,
				 'SYSTEM',
				 SYSDATE,
				 'SYSTEM',
				 SYSDATE
				);
				
				INSERT INTO TB_CHKLIST_DTL_INFO
				(DL_EXPD_ALTR_NO,
				 QLTY_VEHL_CD,
				 LANG_CD,
				 N_PRNT_PBCN_NO,
				 PPRR_EENO,
				 FRAM_DTM,
				 UPDR_EENO,
				 MDFY_DTM
				)
				VALUES
				(CHK_LIST.DL_EXPD_ALTR_NO,
				 CHK_LIST.VEHL_CD,
				 'EM',
				 CHK_LIST.COL_EM,
				 'SYSTEM',
				 SYSDATE,
				 'SYSTEM',
				 SYSDATE
				);
				
				INSERT INTO TB_CHKLIST_DTL_INFO
				(DL_EXPD_ALTR_NO,
				 QLTY_VEHL_CD,
				 LANG_CD,
				 N_PRNT_PBCN_NO,
				 PPRR_EENO,
				 FRAM_DTM,
				 UPDR_EENO,
				 MDFY_DTM
				)
				VALUES
				(CHK_LIST.DL_EXPD_ALTR_NO,
				 CHK_LIST.VEHL_CD,
				 'EP',
				 CHK_LIST.COL_EP,
				 'SYSTEM',
				 SYSDATE,
				 'SYSTEM',
				 SYSDATE
				);
				
				INSERT INTO TB_CHKLIST_DTL_INFO
				(DL_EXPD_ALTR_NO,
				 QLTY_VEHL_CD,
				 LANG_CD,
				 N_PRNT_PBCN_NO,
				 PPRR_EENO,
				 FRAM_DTM,
				 UPDR_EENO,
				 MDFY_DTM
				)
				VALUES
				(CHK_LIST.DL_EXPD_ALTR_NO,
				 CHK_LIST.VEHL_CD,
				 'EU',
				 CHK_LIST.COL_EU,
				 'SYSTEM',
				 SYSDATE,
				 'SYSTEM',
				 SYSDATE
				);
				
				INSERT INTO TB_CHKLIST_DTL_INFO
				(DL_EXPD_ALTR_NO,
				 QLTY_VEHL_CD,
				 LANG_CD,
				 N_PRNT_PBCN_NO,
				 PPRR_EENO,
				 FRAM_DTM,
				 UPDR_EENO,
				 MDFY_DTM
				)
				VALUES
				(CHK_LIST.DL_EXPD_ALTR_NO,
				 CHK_LIST.VEHL_CD,
				 'FE',
				 CHK_LIST.COL_FE,
				 'SYSTEM',
				 SYSDATE,
				 'SYSTEM',
				 SYSDATE
				);
				
				INSERT INTO TB_CHKLIST_DTL_INFO
				(DL_EXPD_ALTR_NO,
				 QLTY_VEHL_CD,
				 LANG_CD,
				 N_PRNT_PBCN_NO,
				 PPRR_EENO,
				 FRAM_DTM,
				 UPDR_EENO,
				 MDFY_DTM
				)
				VALUES
				(CHK_LIST.DL_EXPD_ALTR_NO,
				 CHK_LIST.VEHL_CD,
				 'FG',
				 CHK_LIST.COL_FG,
				 'SYSTEM',
				 SYSDATE,
				 'SYSTEM',
				 SYSDATE
				);
				
				INSERT INTO TB_CHKLIST_DTL_INFO
				(DL_EXPD_ALTR_NO,
				 QLTY_VEHL_CD,
				 LANG_CD,
				 N_PRNT_PBCN_NO,
				 PPRR_EENO,
				 FRAM_DTM,
				 UPDR_EENO,
				 MDFY_DTM
				)
				VALUES
				(CHK_LIST.DL_EXPD_ALTR_NO,
				 CHK_LIST.VEHL_CD,
				 'GE',
				 CHK_LIST.COL_GE,
				 'SYSTEM',
				 SYSDATE,
				 'SYSTEM',
				 SYSDATE
				);
                
				INSERT INTO TB_CHKLIST_DTL_INFO
				(DL_EXPD_ALTR_NO,
				 QLTY_VEHL_CD,
				 LANG_CD,
				 N_PRNT_PBCN_NO,
				 PPRR_EENO,
				 FRAM_DTM,
				 UPDR_EENO,
				 MDFY_DTM
				)
				VALUES
				(CHK_LIST.DL_EXPD_ALTR_NO,
				 CHK_LIST.VEHL_CD,
				 'HO',
				 CHK_LIST.COL_HO,
				 'SYSTEM',
				 SYSDATE,
				 'SYSTEM',
				 SYSDATE
				);                            
                                            
                INSERT INTO TB_CHKLIST_DTL_INFO
				(DL_EXPD_ALTR_NO,
				 QLTY_VEHL_CD,
				 LANG_CD,
				 N_PRNT_PBCN_NO,
				 PPRR_EENO,
				 FRAM_DTM,
				 UPDR_EENO,
				 MDFY_DTM
				)
				VALUES
				(CHK_LIST.DL_EXPD_ALTR_NO,
				 CHK_LIST.VEHL_CD,
				 'HU',
				 CHK_LIST.COL_HU,
				 'SYSTEM',
				 SYSDATE,
				 'SYSTEM',
				 SYSDATE
				);                                    
                
				INSERT INTO TB_CHKLIST_DTL_INFO
				(DL_EXPD_ALTR_NO,
				 QLTY_VEHL_CD,
				 LANG_CD,
				 N_PRNT_PBCN_NO,
				 PPRR_EENO,
				 FRAM_DTM,
				 UPDR_EENO,
				 MDFY_DTM
				)
				VALUES
				(CHK_LIST.DL_EXPD_ALTR_NO,
				 CHK_LIST.VEHL_CD,
				 'IT',
				 CHK_LIST.COL_IT,
				 'SYSTEM',
				 SYSDATE,
				 'SYSTEM',
				 SYSDATE
				);                                  
                                            
                INSERT INTO TB_CHKLIST_DTL_INFO
				(DL_EXPD_ALTR_NO,
				 QLTY_VEHL_CD,
				 LANG_CD,
				 N_PRNT_PBCN_NO,
				 PPRR_EENO,
				 FRAM_DTM,
				 UPDR_EENO,
				 MDFY_DTM
				)
				VALUES
				(CHK_LIST.DL_EXPD_ALTR_NO,
				 CHK_LIST.VEHL_CD,
				 'JA',
				 CHK_LIST.COL_JA,
				 'SYSTEM',
				 SYSDATE,
				 'SYSTEM',
				 SYSDATE
				);                                    
                
				INSERT INTO TB_CHKLIST_DTL_INFO
				(DL_EXPD_ALTR_NO,
				 QLTY_VEHL_CD,
				 LANG_CD,
				 N_PRNT_PBCN_NO,
				 PPRR_EENO,
				 FRAM_DTM,
				 UPDR_EENO,
				 MDFY_DTM
				)
				VALUES
				(CHK_LIST.DL_EXPD_ALTR_NO,
				 CHK_LIST.VEHL_CD,
				 'KO',
				 CHK_LIST.COL_KO,
				 'SYSTEM',
				 SYSDATE,
				 'SYSTEM',
				 SYSDATE
				);                                    
                
				INSERT INTO TB_CHKLIST_DTL_INFO
				(DL_EXPD_ALTR_NO,
				 QLTY_VEHL_CD,
				 LANG_CD,
				 N_PRNT_PBCN_NO,
				 PPRR_EENO,
				 FRAM_DTM,
				 UPDR_EENO,
				 MDFY_DTM
				)
				VALUES
				(CHK_LIST.DL_EXPD_ALTR_NO,
				 CHK_LIST.VEHL_CD,
				 'NR',
				 CHK_LIST.COL_NR,
				 'SYSTEM',
				 SYSDATE,
				 'SYSTEM',
				 SYSDATE
				);                                       
                                            
                INSERT INTO TB_CHKLIST_DTL_INFO
				(DL_EXPD_ALTR_NO,
				 QLTY_VEHL_CD,
				 LANG_CD,
				 N_PRNT_PBCN_NO,
				 PPRR_EENO,
				 FRAM_DTM,
				 UPDR_EENO,
				 MDFY_DTM
				)
				VALUES
				(CHK_LIST.DL_EXPD_ALTR_NO,
				 CHK_LIST.VEHL_CD,
				 'PB',
				 CHK_LIST.COL_PB,
				 'SYSTEM',
				 SYSDATE,
				 'SYSTEM',
				 SYSDATE
				);                               
                
				INSERT INTO TB_CHKLIST_DTL_INFO
				(DL_EXPD_ALTR_NO,
				 QLTY_VEHL_CD,
				 LANG_CD,
				 N_PRNT_PBCN_NO,
				 PPRR_EENO,
				 FRAM_DTM,
				 UPDR_EENO,
				 MDFY_DTM
				)
				VALUES
				(CHK_LIST.DL_EXPD_ALTR_NO,
				 CHK_LIST.VEHL_CD,
				 'PE',
				 CHK_LIST.COL_PE,
				 'SYSTEM',
				 SYSDATE,
				 'SYSTEM',
				 SYSDATE
				);                               
                
				INSERT INTO TB_CHKLIST_DTL_INFO
				(DL_EXPD_ALTR_NO,
				 QLTY_VEHL_CD,
				 LANG_CD,
				 N_PRNT_PBCN_NO,
				 PPRR_EENO,
				 FRAM_DTM,
				 UPDR_EENO,
				 MDFY_DTM
				)
				VALUES
				(CHK_LIST.DL_EXPD_ALTR_NO,
				 CHK_LIST.VEHL_CD,
				 'PO',
				 CHK_LIST.COL_PO,
				 'SYSTEM',
				 SYSDATE,
				 'SYSTEM',
				 SYSDATE
				);                                
                                            
                INSERT INTO TB_CHKLIST_DTL_INFO
				(DL_EXPD_ALTR_NO,
				 QLTY_VEHL_CD,
				 LANG_CD,
				 N_PRNT_PBCN_NO,
				 PPRR_EENO,
				 FRAM_DTM,
				 UPDR_EENO,
				 MDFY_DTM
				)
				VALUES
				(CHK_LIST.DL_EXPD_ALTR_NO,
				 CHK_LIST.VEHL_CD,
				 'RU',
				 CHK_LIST.COL_RU,
				 'SYSTEM',
				 SYSDATE,
				 'SYSTEM',
				 SYSDATE
				);                          
                
				INSERT INTO TB_CHKLIST_DTL_INFO
				(DL_EXPD_ALTR_NO,
				 QLTY_VEHL_CD,
				 LANG_CD,
				 N_PRNT_PBCN_NO,
				 PPRR_EENO,
				 FRAM_DTM,
				 UPDR_EENO,
				 MDFY_DTM
				)
				VALUES
				(CHK_LIST.DL_EXPD_ALTR_NO,
				 CHK_LIST.VEHL_CD,
				 'LY',
				 CHK_LIST.COL_LY,
				 'SYSTEM',
				 SYSDATE,
				 'SYSTEM',
				 SYSDATE
				);                                      
                
				INSERT INTO TB_CHKLIST_DTL_INFO
				(DL_EXPD_ALTR_NO,
				 QLTY_VEHL_CD,
				 LANG_CD,
				 N_PRNT_PBCN_NO,
				 PPRR_EENO,
				 FRAM_DTM,
				 UPDR_EENO,
				 MDFY_DTM
				)
				VALUES
				(CHK_LIST.DL_EXPD_ALTR_NO,
				 CHK_LIST.VEHL_CD,
				 'SE',
				 CHK_LIST.COL_SE,
				 'SYSTEM',
				 SYSDATE,
				 'SYSTEM',
				 SYSDATE  
				);                          
                                            
                INSERT INTO TB_CHKLIST_DTL_INFO
				(DL_EXPD_ALTR_NO,
				 QLTY_VEHL_CD,
				 LANG_CD,
				 N_PRNT_PBCN_NO,
				 PPRR_EENO,
				 FRAM_DTM,
				 UPDR_EENO,
				 MDFY_DTM
				)
				VALUES
				(CHK_LIST.DL_EXPD_ALTR_NO,
				 CHK_LIST.VEHL_CD,
				 'SG',
				 CHK_LIST.COL_SG,
				 'SYSTEM',
				 SYSDATE,
				 'SYSTEM',
				 SYSDATE  
				);                                    
                
				INSERT INTO TB_CHKLIST_DTL_INFO
				(DL_EXPD_ALTR_NO,
				 QLTY_VEHL_CD,
				 LANG_CD,
				 N_PRNT_PBCN_NO,
				 PPRR_EENO,
				 FRAM_DTM,
				 UPDR_EENO,
				 MDFY_DTM
				)
				VALUES
				(CHK_LIST.DL_EXPD_ALTR_NO,
				 CHK_LIST.VEHL_CD,
				 'SM',
				 CHK_LIST.COL_SM,
				 'SYSTEM',
				 SYSDATE,
				 'SYSTEM',
				 SYSDATE  
				);                              
                
				INSERT INTO TB_CHKLIST_DTL_INFO
				(DL_EXPD_ALTR_NO,
				 QLTY_VEHL_CD,
				 LANG_CD,
				 N_PRNT_PBCN_NO,
				 PPRR_EENO,
				 FRAM_DTM,
				 UPDR_EENO,
				 MDFY_DTM
				)
				VALUES
				(CHK_LIST.DL_EXPD_ALTR_NO,
				 CHK_LIST.VEHL_CD,
				 'SV',
				 CHK_LIST.COL_SV,
				 'SYSTEM',
				 SYSDATE,
				 'SYSTEM',
				 SYSDATE  
				);                                   
                                            
                INSERT INTO TB_CHKLIST_DTL_INFO
				(DL_EXPD_ALTR_NO,
				 QLTY_VEHL_CD,
				 LANG_CD,
				 N_PRNT_PBCN_NO,
				 PPRR_EENO,
				 FRAM_DTM,
				 UPDR_EENO,
				 MDFY_DTM
				)
				VALUES
				(CHK_LIST.DL_EXPD_ALTR_NO,
				 CHK_LIST.VEHL_CD,
				 'SW',
				 CHK_LIST.COL_SW,
				 'SYSTEM',
				 SYSDATE,
				 'SYSTEM',
				 SYSDATE  
				);                             
                 
				INSERT INTO TB_CHKLIST_DTL_INFO
				(DL_EXPD_ALTR_NO,
				 QLTY_VEHL_CD,
				 LANG_CD,
				 N_PRNT_PBCN_NO,
				 PPRR_EENO,
				 FRAM_DTM,
				 UPDR_EENO,
				 MDFY_DTM
				)
				VALUES
				(CHK_LIST.DL_EXPD_ALTR_NO,
				 CHK_LIST.VEHL_CD,
				 'TW',
				 CHK_LIST.COL_TW,
				 'SYSTEM',
				 SYSDATE,
				 'SYSTEM',
				 SYSDATE  
				);    
				 
				INSERT INTO TB_CHKLIST_DTL_INFO
				(DL_EXPD_ALTR_NO,
				 QLTY_VEHL_CD,
				 LANG_CD,
				 N_PRNT_PBCN_NO,
				 PPRR_EENO,
				 FRAM_DTM,
				 UPDR_EENO,
				 MDFY_DTM
				)
				VALUES
				(CHK_LIST.DL_EXPD_ALTR_NO,
				 CHK_LIST.VEHL_CD,
				 'UK',
				 CHK_LIST.COL_UK,
				 'SYSTEM',
				 SYSDATE,
				 'SYSTEM',
				 SYSDATE  
				);                               
						
			END LOOP;
	   		
			EXCEPTION
		     WHEN OTHERS THEN
			     ROLLBACK;
				 RAISE_APPLICATION_ERROR(-20001, SQLERRM || 
			   								     'altr_no:' || V_ALTR_NO || ',' || 
											     'vehl_cd:' || V_VEHL_CD);
	   END SP_CHKLIST_DTL_INFO_SAVE2;
	   
	   PROCEDURE SP_CHKLIST_DTL_INFO_SAVE3
	   IS
	   
	   	 CURSOR CHK_LIST_DTL_INFO IS SELECT ALTR_NO,
		 					  	 			VEHL_CD,
										    COL_AR, --1 
                                            COL_AS, --2 
                                            COL_CH, --3 
                                            COL_CN, --4 
											COL_CX, --5 
                                            COL_DE, --6 
                                            COL_EA, --7 
                                            COL_EC, --8 
                                            COL_EE, --9 
                                            COL_EM, --10 
                                            COL_EP, --11 
                                            COL_EU, --12 
                                            COL_FE, --13 
                                            COL_FG, --14 
                                            COL_GE, --15 
                                            COL_HO, --16 
                                            COL_HU, --17 
                                            COL_IT, --18 
                                            COL_JA, --19 
                                            COL_KO, --20 
											COL_LP, --21 
											COL_LY, --22 
											COL_MM, --23 
                                            COL_NR, --24 
                                            COL_PB, --25 
                                            COL_PE, --26 
                                            COL_PO, --27 
											COL_RR, --28 
                                            COL_RU, --29 
                                            COL_SE, --30 
                                            COL_SG, --31 
                                            COL_SM, --32 
                                            COL_SV, --33  
                                            COL_SW, --34  
											COL_TS, --35  
                                            COL_TW, --36 
                                            COL_UK, --37 
											COL_XI, --38 
											COL_XM, --39 
											COL_XX, --40 
											COL_XZ  --41 
								 FROM TB_CHKLIST_DTL_INFO_TEMP3;
								 
		 	V_LANG_CD      VARCHAR2(3);
			V_PRNT_PBCN_NO VARCHAR2(50);
			
	   BEGIN
	   		
			FOR CHK_LIST IN CHK_LIST_DTL_INFO LOOP
				
				FOR NUM IN   1..41   LOOP
					
					IF NUM = 1 THEN
					   
					   V_LANG_CD      := 'AR';
					   V_PRNT_PBCN_NO := CHK_LIST.COL_AR;
					
					ELSIF NUM = 2 THEN
					   
					   V_LANG_CD      := 'AS';
					   V_PRNT_PBCN_NO := CHK_LIST.COL_AS;
					
					ELSIF NUM = 3 THEN
					   
					   V_LANG_CD      := 'CH';
					   V_PRNT_PBCN_NO := CHK_LIST.COL_CH;
					   
					ELSIF NUM = 4 THEN
					   
					   V_LANG_CD      := 'CN';
					   V_PRNT_PBCN_NO := CHK_LIST.COL_CN;
					   
					   
					ELSIF NUM = 5 THEN
					   
					   V_LANG_CD      := 'CX';
					   V_PRNT_PBCN_NO := CHK_LIST.COL_CX;
					   
					ELSIF NUM = 6 THEN
					   
					   V_LANG_CD      := 'DE';
					   V_PRNT_PBCN_NO := CHK_LIST.COL_DE;
					   
					ELSIF NUM = 7 THEN
					   
					   V_LANG_CD      := 'EA';
					   V_PRNT_PBCN_NO := CHK_LIST.COL_EA;
					   
					ELSIF NUM = 8 THEN
					   
					   V_LANG_CD      := 'EC';
					   V_PRNT_PBCN_NO := CHK_LIST.COL_EC;
					   
					ELSIF NUM = 9 THEN
					   
					   V_LANG_CD      := 'EE';
					   V_PRNT_PBCN_NO := CHK_LIST.COL_EE;
					   
					ELSIF NUM = 10 THEN
					   
					   V_LANG_CD      := 'EM';
					   V_PRNT_PBCN_NO := CHK_LIST.COL_EM;
					   
					ELSIF NUM = 11 THEN
					   
					   V_LANG_CD      := 'EP';
					   V_PRNT_PBCN_NO := CHK_LIST.COL_EP;
					   
					ELSIF NUM = 12 THEN
					   
					   V_LANG_CD      := 'EU';
					   V_PRNT_PBCN_NO := CHK_LIST.COL_EU;
					   
					   
					ELSIF NUM = 13 THEN
					   
					   V_LANG_CD      := 'FE';
					   V_PRNT_PBCN_NO := CHK_LIST.COL_FE;
					   
					   
					ELSIF NUM = 14 THEN
					   
					   V_LANG_CD      := 'FG';
					   V_PRNT_PBCN_NO := CHK_LIST.COL_FG;
					   
					   
					ELSIF NUM = 15 THEN
					   
					   V_LANG_CD      := 'GE';
					   V_PRNT_PBCN_NO := CHK_LIST.COL_GE;
					   
					   
					ELSIF NUM = 16 THEN
					   
					   V_LANG_CD      := 'HO';
					   V_PRNT_PBCN_NO := CHK_LIST.COL_HO;
					   
					   
					ELSIF NUM = 17 THEN
					   
					   V_LANG_CD      := 'HU';
					   V_PRNT_PBCN_NO := CHK_LIST.COL_HU;
					   
					   
					ELSIF NUM = 18 THEN
					   
					   V_LANG_CD      := 'IT';
					   V_PRNT_PBCN_NO := CHK_LIST.COL_IT;
					   
					   
					ELSIF NUM = 19 THEN
					   
					   V_LANG_CD      := 'JA';
					   V_PRNT_PBCN_NO := CHK_LIST.COL_JA;
					   
					   
					ELSIF NUM = 20 THEN
					   
					   V_LANG_CD      := 'KO';
					   V_PRNT_PBCN_NO := CHK_LIST.COL_KO;
					   
					   
					ELSIF NUM = 21 THEN
					   
					   V_LANG_CD      := 'LP';
					   V_PRNT_PBCN_NO := CHK_LIST.COL_LP;
					   
					   
					ELSIF NUM = 22 THEN
					   
					   V_LANG_CD      := 'LY';
					   V_PRNT_PBCN_NO := CHK_LIST.COL_LY;
					   
					   
					ELSIF NUM = 23 THEN
					   
					   V_LANG_CD      := 'MM';
					   V_PRNT_PBCN_NO := CHK_LIST.COL_MM;
					   
					   
					ELSIF NUM = 24 THEN
					   
					   V_LANG_CD      := 'NR';
					   V_PRNT_PBCN_NO := CHK_LIST.COL_NR;
					   
					   
					ELSIF NUM = 25 THEN
					   
					   V_LANG_CD      := 'PB';
					   V_PRNT_PBCN_NO := CHK_LIST.COL_PB;
					   
					   
					ELSIF NUM = 26 THEN
					   
					   V_LANG_CD      := 'PE';
					   V_PRNT_PBCN_NO := CHK_LIST.COL_PE;
					   
					   
					ELSIF NUM = 27 THEN
					   
					   V_LANG_CD      := 'PO';
					   V_PRNT_PBCN_NO := CHK_LIST.COL_PO;
					   
					   
					ELSIF NUM = 28 THEN
					   
					   V_LANG_CD      := 'RR';
					   V_PRNT_PBCN_NO := CHK_LIST.COL_RR;
					   
					ELSIF NUM = 29 THEN
					   
					   V_LANG_CD      := 'RU';
					   V_PRNT_PBCN_NO := CHK_LIST.COL_RU;
					   
					   
					ELSIF NUM = 30 THEN
					   
					   V_LANG_CD      := 'SE';
					   V_PRNT_PBCN_NO := CHK_LIST.COL_SE;
					   
					   
					ELSIF NUM = 31 THEN
					   
					   V_LANG_CD      := 'SG';
					   V_PRNT_PBCN_NO := CHK_LIST.COL_SG;
					   
					   
					ELSIF NUM = 32 THEN
					   
					   V_LANG_CD      := 'SM';
					   V_PRNT_PBCN_NO := CHK_LIST.COL_SM;
					   
					   
					ELSIF NUM = 33 THEN
					   
					   V_LANG_CD      := 'SV';
					   V_PRNT_PBCN_NO := CHK_LIST.COL_SV;
					   
					   
					ELSIF NUM = 34 THEN
					   
					   V_LANG_CD      := 'SW';
					   V_PRNT_PBCN_NO := CHK_LIST.COL_SW;
					   
					   
					ELSIF NUM = 35 THEN
					   
					   V_LANG_CD      := 'TS';
					   V_PRNT_PBCN_NO := CHK_LIST.COL_TS;
					   
					   
					ELSIF NUM = 36 THEN
					   
					   V_LANG_CD      := 'TW';
					   V_PRNT_PBCN_NO := CHK_LIST.COL_TW;
					   
					   
					ELSIF NUM = 37 THEN
					   
					   V_LANG_CD      := 'UK';
					   V_PRNT_PBCN_NO := CHK_LIST.COL_UK;
					   
					   
					ELSIF NUM = 38 THEN
					   
					   V_LANG_CD      := 'XI';
					   V_PRNT_PBCN_NO := CHK_LIST.COL_XI;
					   
					   
					ELSIF NUM = 39 THEN
					   
					   V_LANG_CD      := 'XM';
					   V_PRNT_PBCN_NO := CHK_LIST.COL_XM;
					   
					   
					ELSIF NUM = 40 THEN
					   
					   V_LANG_CD      := 'XX';
					   V_PRNT_PBCN_NO := CHK_LIST.COL_XX;
					   
					   
					ELSIF NUM = 41 THEN
					   
					   V_LANG_CD      := 'XZ';
					   V_PRNT_PBCN_NO := CHK_LIST.COL_XZ;
					   
					END IF;
					
					UPDATE TB_CHKLIST_DTL_INFO
					SET N_PRNT_PBCN_NO = V_PRNT_PBCN_NO
					WHERE DL_EXPD_ALTR_NO = CHK_LIST.ALTR_NO
					AND QLTY_VEHL_CD = CHK_LIST.VEHL_CD
					AND LANG_CD = V_LANG_CD;
					
					IF SQL%NOTFOUND THEN
					   
					   INSERT INTO TB_CHKLIST_DTL_INFO
					   (DL_EXPD_ALTR_NO,
					    QLTY_VEHL_CD,
						LANG_CD,
						N_PRNT_PBCN_NO,
						PPRR_EENO,
						FRAM_DTM,
						UPDR_EENO,
						MDFY_DTM
					   )
					   VALUES
					   (CHK_LIST.ALTR_NO,
					    CHK_LIST.VEHL_CD,
						V_LANG_CD,
						V_PRNT_PBCN_NO,
						'SYSTEM',
						SYSDATE,
						'SYSTEM',
						SYSDATE
					   );
					   
					END IF;
					   
				END LOOP;
				      
			END LOOP;
			
	   END SP_CHKLIST_DTL_INFO_SAVE3;
	   
	   PROCEDURE SP_CHKLIST_DTL_INFO_SAVE4
	   IS
	   
	   	 CURSOR CHK_LIST_DTL_INFO IS SELECT B.DL_EXPD_ALTR_NO AS ALTR_NO,
		 					  	 			A.VEHL_CD,
										    COL_AR, --1 
                                            COL_AS, --2 
                                            COL_CH, --3 
                                            COL_CN, --4 
											COL_CX, --5 
                                            COL_DE, --6 
                                            COL_EA, --7 
                                            COL_EC, --8 
                                            COL_EE, --9 
                                            COL_EM, --10 
                                            COL_EP, --11 
                                            COL_EU, --12 
                                            COL_FE, --13 
                                            COL_FG, --14 
                                            COL_GE, --15 
                                            COL_HO, --16 
                                            COL_HU, --17 
                                            COL_IT, --18 
                                            COL_JA, --19 
                                            COL_KO, --20 
											COL_LP, --21 
											COL_LY, --22 
											COL_MM, --23 
                                            COL_NR, --24 
                                            COL_PB, --25 
                                            COL_PE, --26 
                                            COL_PO, --27 
											COL_RR, --28 
                                            COL_RU, --29 
                                            COL_SE, --30 
                                            COL_SG, --31 
                                            COL_SM, --32 
                                            COL_SV, --33  
                                            COL_SW, --34  
											COL_TS, --35  
                                            COL_TW, --36 
                                            COL_UK, --37 
											COL_XI, --38 
											COL_XM, --39 
											COL_XX, --40 
											COL_XZ  --41 
								 FROM TB_CHKLIST_DTL_INFO_TEMP4 A,
								      TB_CHKLIST_INFO_TEMP2 B
								 WHERE A.NO = B.NO
								 AND A.VEHL_CD = B.VEHL_CD
								 ORDER BY A.NO;
								 
		 	V_LANG_CD      VARCHAR2(3);
			V_PRNT_PBCN_NO VARCHAR2(50);
			
	   BEGIN
	   		
			FOR CHK_LIST IN CHK_LIST_DTL_INFO LOOP
				
				FOR NUM IN   1..41   LOOP
					
					IF NUM = 1 THEN
					   
					   V_LANG_CD      := 'AR';
					   V_PRNT_PBCN_NO := CHK_LIST.COL_AR;
					
					ELSIF NUM = 2 THEN
					   
					   V_LANG_CD      := 'AS';
					   V_PRNT_PBCN_NO := CHK_LIST.COL_AS;
					
					ELSIF NUM = 3 THEN
					   
					   V_LANG_CD      := 'CH';
					   V_PRNT_PBCN_NO := CHK_LIST.COL_CH;
					   
					ELSIF NUM = 4 THEN
					   
					   V_LANG_CD      := 'CN';
					   V_PRNT_PBCN_NO := CHK_LIST.COL_CN;
					   
					   
					ELSIF NUM = 5 THEN
					   
					   V_LANG_CD      := 'CX';
					   V_PRNT_PBCN_NO := CHK_LIST.COL_CX;
					   
					ELSIF NUM = 6 THEN
					   
					   V_LANG_CD      := 'DE';
					   V_PRNT_PBCN_NO := CHK_LIST.COL_DE;
					   
					ELSIF NUM = 7 THEN
					   
					   V_LANG_CD      := 'EA';
					   V_PRNT_PBCN_NO := CHK_LIST.COL_EA;
					   
					ELSIF NUM = 8 THEN
					   
					   V_LANG_CD      := 'EC';
					   V_PRNT_PBCN_NO := CHK_LIST.COL_EC;
					   
					ELSIF NUM = 9 THEN
					   
					   V_LANG_CD      := 'EE';
					   V_PRNT_PBCN_NO := CHK_LIST.COL_EE;
					   
					ELSIF NUM = 10 THEN
					   
					   V_LANG_CD      := 'EM';
					   V_PRNT_PBCN_NO := CHK_LIST.COL_EM;
					   
					ELSIF NUM = 11 THEN
					   
					   V_LANG_CD      := 'EP';
					   V_PRNT_PBCN_NO := CHK_LIST.COL_EP;
					   
					ELSIF NUM = 12 THEN
					   
					   V_LANG_CD      := 'EU';
					   V_PRNT_PBCN_NO := CHK_LIST.COL_EU;
					   
					   
					ELSIF NUM = 13 THEN
					   
					   V_LANG_CD      := 'FE';
					   V_PRNT_PBCN_NO := CHK_LIST.COL_FE;
					   
					   
					ELSIF NUM = 14 THEN
					   
					   V_LANG_CD      := 'FG';
					   V_PRNT_PBCN_NO := CHK_LIST.COL_FG;
					   
					   
					ELSIF NUM = 15 THEN
					   
					   V_LANG_CD      := 'GE';
					   V_PRNT_PBCN_NO := CHK_LIST.COL_GE;
					   
					   
					ELSIF NUM = 16 THEN
					   
					   V_LANG_CD      := 'HO';
					   V_PRNT_PBCN_NO := CHK_LIST.COL_HO;
					   
					   
					ELSIF NUM = 17 THEN
					   
					   V_LANG_CD      := 'HU';
					   V_PRNT_PBCN_NO := CHK_LIST.COL_HU;
					   
					   
					ELSIF NUM = 18 THEN
					   
					   V_LANG_CD      := 'IT';
					   V_PRNT_PBCN_NO := CHK_LIST.COL_IT;
					   
					   
					ELSIF NUM = 19 THEN
					   
					   V_LANG_CD      := 'JA';
					   V_PRNT_PBCN_NO := CHK_LIST.COL_JA;
					   
					   
					ELSIF NUM = 20 THEN
					   
					   V_LANG_CD      := 'KO';
					   V_PRNT_PBCN_NO := CHK_LIST.COL_KO;
					   
					   
					ELSIF NUM = 21 THEN
					   
					   V_LANG_CD      := 'LP';
					   V_PRNT_PBCN_NO := CHK_LIST.COL_LP;
					   
					   
					ELSIF NUM = 22 THEN
					   
					   V_LANG_CD      := 'LY';
					   V_PRNT_PBCN_NO := CHK_LIST.COL_LY;
					   
					   
					ELSIF NUM = 23 THEN
					   
					   V_LANG_CD      := 'MM';
					   V_PRNT_PBCN_NO := CHK_LIST.COL_MM;
					   
					   
					ELSIF NUM = 24 THEN
					   
					   V_LANG_CD      := 'NR';
					   V_PRNT_PBCN_NO := CHK_LIST.COL_NR;
					   
					   
					ELSIF NUM = 25 THEN
					   
					   V_LANG_CD      := 'PB';
					   V_PRNT_PBCN_NO := CHK_LIST.COL_PB;
					   
					   
					ELSIF NUM = 26 THEN
					   
					   V_LANG_CD      := 'PE';
					   V_PRNT_PBCN_NO := CHK_LIST.COL_PE;
					   
					   
					ELSIF NUM = 27 THEN
					   
					   V_LANG_CD      := 'PO';
					   V_PRNT_PBCN_NO := CHK_LIST.COL_PO;
					   
					   
					ELSIF NUM = 28 THEN
					   
					   V_LANG_CD      := 'RR';
					   V_PRNT_PBCN_NO := CHK_LIST.COL_RR;
					   
					ELSIF NUM = 29 THEN
					   
					   V_LANG_CD      := 'RU';
					   V_PRNT_PBCN_NO := CHK_LIST.COL_RU;
					   
					   
					ELSIF NUM = 30 THEN
					   
					   V_LANG_CD      := 'SE';
					   V_PRNT_PBCN_NO := CHK_LIST.COL_SE;
					   
					   
					ELSIF NUM = 31 THEN
					   
					   V_LANG_CD      := 'SG';
					   V_PRNT_PBCN_NO := CHK_LIST.COL_SG;
					   
					   
					ELSIF NUM = 32 THEN
					   
					   V_LANG_CD      := 'SM';
					   V_PRNT_PBCN_NO := CHK_LIST.COL_SM;
					   
					   
					ELSIF NUM = 33 THEN
					   
					   V_LANG_CD      := 'SV';
					   V_PRNT_PBCN_NO := CHK_LIST.COL_SV;
					   
					   
					ELSIF NUM = 34 THEN
					   
					   V_LANG_CD      := 'SW';
					   V_PRNT_PBCN_NO := CHK_LIST.COL_SW;
					   
					   
					ELSIF NUM = 35 THEN
					   
					   V_LANG_CD      := 'TS';
					   V_PRNT_PBCN_NO := CHK_LIST.COL_TS;
					   
					   
					ELSIF NUM = 36 THEN
					   
					   V_LANG_CD      := 'TW';
					   V_PRNT_PBCN_NO := CHK_LIST.COL_TW;
					   
					   
					ELSIF NUM = 37 THEN
					   
					   V_LANG_CD      := 'UK';
					   V_PRNT_PBCN_NO := CHK_LIST.COL_UK;
					   
					   
					ELSIF NUM = 38 THEN
					   
					   V_LANG_CD      := 'XI';
					   V_PRNT_PBCN_NO := CHK_LIST.COL_XI;
					   
					   
					ELSIF NUM = 39 THEN
					   
					   V_LANG_CD      := 'XM';
					   V_PRNT_PBCN_NO := CHK_LIST.COL_XM;
					   
					   
					ELSIF NUM = 40 THEN
					   
					   V_LANG_CD      := 'XX';
					   V_PRNT_PBCN_NO := CHK_LIST.COL_XX;
					   
					   
					ELSIF NUM = 41 THEN
					   
					   V_LANG_CD      := 'XZ';
					   V_PRNT_PBCN_NO := CHK_LIST.COL_XZ;
					   
					END IF;
					
					UPDATE TB_CHKLIST_DTL_INFO
					SET N_PRNT_PBCN_NO = V_PRNT_PBCN_NO
					WHERE DL_EXPD_ALTR_NO = CHK_LIST.ALTR_NO
					AND QLTY_VEHL_CD = CHK_LIST.VEHL_CD
					AND LANG_CD = V_LANG_CD;
					
					IF SQL%NOTFOUND THEN
					   
					   INSERT INTO TB_CHKLIST_DTL_INFO
					   (DL_EXPD_ALTR_NO,
					    QLTY_VEHL_CD,
						LANG_CD,
						N_PRNT_PBCN_NO,
						PPRR_EENO,
						FRAM_DTM,
						UPDR_EENO,
						MDFY_DTM
					   )
					   VALUES
					   (CHK_LIST.ALTR_NO,
					    CHK_LIST.VEHL_CD,
						V_LANG_CD,
						V_PRNT_PBCN_NO,
						'SYSTEM',
						SYSDATE,
						'SYSTEM',
						SYSDATE
					   );
					   
					END IF;
					   
				END LOOP;
				      
			END LOOP;	   
	   
	   END SP_CHKLIST_DTL_INFO_SAVE4;
	   
	   
	   --체크리스트 내용 임시 테이블에 저장하는 프로시저 
	   PROCEDURE SP_INSERT_CHKLIST_TEMP(P_NO           TB_CHKLIST_INFO_TEMP.NO%TYPE,
	  								    P_ALTR_YMD     TB_CHKLIST_INFO_TEMP.ALTR_YMD%TYPE,
									    P_RCPM_SHAP_CD TB_CHKLIST_INFO_TEMP.RCPM_SHAP_CD%TYPE,
									    P_DSPP_NM      TB_CHKLIST_INFO_TEMP.DSPP_NM%TYPE,
									    P_CRGR_NM      TB_CHKLIST_INFO_TEMP.CRGR_NM%TYPE,
									    P_VEHL_CD      TB_CHKLIST_INFO_TEMP.VEHL_CD%TYPE,
									    P_ALTR_SBC     TB_CHKLIST_INFO_TEMP.ALTR_SBC%TYPE)
	   IS
	   BEGIN
	   		
			INSERT INTO TB_CHKLIST_INFO_TEMP
			VALUES(P_NO, P_ALTR_YMD, P_RCPM_SHAP_CD, P_DSPP_NM, P_CRGR_NM, P_VEHL_CD, P_ALTR_SBC);
	   
	   END SP_INSERT_CHKLIST_TEMP;		   
	   
	   --체크리스트 상세정보 임시 저장 
	   PROCEDURE SP_INSERT_CHKDTL_LIST_TEMP(P_NO       NUMBER,
                                            P_VEHL_CD  VARCHAR2,
                                            P_COL_AR   VARCHAR2,
                                            P_COL_AS   VARCHAR2,
                                            P_COL_CH   VARCHAR2,
                                            P_COL_CN   VARCHAR2,
                                            P_COL_CZ   VARCHAR2,
                                            P_COL_DE   VARCHAR2,
                                            P_COL_EA   VARCHAR2,
                                            P_COL_EC   VARCHAR2,
                                            P_COL_EE   VARCHAR2,
                                            P_COL_EG   VARCHAR2,
                                            P_COL_EM   VARCHAR2,
                                            P_COL_EP   VARCHAR2,
                                            P_COL_EU   VARCHAR2,
                                            P_COL_FE   VARCHAR2,
                                            P_COL_FG   VARCHAR2,
                                            P_COL_GE   VARCHAR2,
                                            P_COL_HO   VARCHAR2,
                                            P_COL_HU   VARCHAR2,
                                            P_COL_IT   VARCHAR2,
                                            P_COL_JA   VARCHAR2,
                                            P_COL_KO   VARCHAR2,
                                            P_COL_NR   VARCHAR2,
                                            P_COL_PB   VARCHAR2,
                                            P_COL_PE   VARCHAR2,
                                            P_COL_PO   VARCHAR2,
                                            P_COL_RU   VARCHAR2,
                                            P_COL_LY   VARCHAR2,
                                            P_COL_SE   VARCHAR2,
                                            P_COL_SG   VARCHAR2,
                                            P_COL_SM   VARCHAR2,
                                            P_COL_SV   VARCHAR2,
                                            P_COL_SW   VARCHAR2,
                                            P_COL_TW   VARCHAR2,
                                            P_COL_UK   VARCHAR2)
	   IS
	   BEGIN
	   		
			INSERT INTO TB_CHKLIST_DTL_INFO_TEMP2
			VALUES(P_NO,     
                   P_VEHL_CD,
                   P_COL_AR ,
                   P_COL_AS ,
                   P_COL_CH ,
                   P_COL_CN ,
                   P_COL_CZ ,
                   P_COL_DE ,
                   P_COL_EA ,
                   P_COL_EC ,
                   P_COL_EE ,
                   P_COL_EG ,
                   P_COL_EM ,
                   P_COL_EP ,
                   P_COL_EU ,
                   P_COL_FE ,
                   P_COL_FG ,
                   P_COL_GE ,
                   P_COL_HO ,
                   P_COL_HU ,
                   P_COL_IT ,
                   P_COL_JA ,
                   P_COL_KO ,
                   P_COL_NR ,
                   P_COL_PB ,
                   P_COL_PE ,
                   P_COL_PO ,
                   P_COL_RU ,
                   P_COL_LY ,
                   P_COL_SE ,
                   P_COL_SG ,
                   P_COL_SM ,
                   P_COL_SV ,
                   P_COL_SW ,
                   P_COL_TW ,
                   P_COL_UK  
				  );
				  
	   END SP_INSERT_CHKDTL_LIST_TEMP;
	   
	   PROCEDURE SP_MAKE_IV_INFO
	   IS
	   	 CURSOR IV_LIST_INFO IS SELECT QLTY_VEHL_CD, 
		 					 		   MDL_MDY_CD, 
									   LANG_CD, 
									   N_PRNT_PBCN_NO,
									   IV_QTY1,
									   IV_QTY2
		 					    FROM TB_IV_INFO_TEMP;
	   BEGIN
	   		
			RAISE_APPLICATION_ERROR(-20001, '사용할 수 없습니다.- 이미 입력되었습니다.');
			
			
			FOR IV_LIST IN IV_LIST_INFO LOOP
				
				INSERT INTO TB_SEWHA_IV_INFO
				(CLS_YMD,
				 QLTY_VEHL_CD,
				 DL_EXPD_MDL_MDY_CD,
				 LANG_CD,
				 N_PRNT_PBCN_NO,
				 IV_QTY,
				 DL_EXPD_TMP_IV_QTY,
				 CMPL_YN,
				 PPRR_EENO,
				 FRAM_DTM,
				 UPDR_EENO,
				 MDFY_DTM
				)
				VALUES
				('20081205',
				 IV_LIST.QLTY_VEHL_CD,
				 IV_LIST.MDL_MDY_CD,
				 IV_LIST.LANG_CD,
				 IV_LIST.N_PRNT_PBCN_NO,
				 IV_LIST.IV_QTY1,
				 0,
				 'N',
				 'SYSTEM',
				 SYSDATE,
				 'SYSTEM',
				 SYSDATE
				);
				
				
				INSERT INTO TB_PDI_IV_INFO
				(CLS_YMD,
				 QLTY_VEHL_CD,
				 DL_EXPD_MDL_MDY_CD,
				 LANG_CD,
				 N_PRNT_PBCN_NO,
				 IV_QTY,
				 CMPL_YN,
				 PPRR_EENO,
				 FRAM_DTM,
				 UPDR_EENO,
				 MDFY_DTM
				)
				VALUES
				('20081205',
				 IV_LIST.QLTY_VEHL_CD,
				 IV_LIST.MDL_MDY_CD,
				 IV_LIST.LANG_CD,
				 IV_LIST.N_PRNT_PBCN_NO,
				 IV_LIST.IV_QTY2,
				 'N',
				 'SYSTEM',
				 SYSDATE,
				 'SYSTEM',
				 SYSDATE
				);
				
			END LOOP;
						
	   END SP_MAKE_IV_INFO;
	   
	   PROCEDURE SP_ROLLBACK_IV_INFO(P_CURR_YMD VARCHAR2)
	   IS
	   	 CURSOR IV_LIST_INFO IS SELECT WHOT_YMD,
		 					 		   QLTY_VEHL_CD, 
		 					 		   DL_EXPD_MDL_MDY_CD, 
									   LANG_CD, 
									   N_PRNT_PBCN_NO,
									   DL_EXPD_WHOT_QTY
		 					    FROM TB_PDI_WHOT_INFO
								WHERE WHOT_YMD = P_CURR_YMD
								AND DEL_YN = 'N';
								
	   BEGIN
	   		
			FOR IV_LIST IN IV_LIST_INFO LOOP
				
				UPDATE TB_PDI_IV_INFO
				SET IV_QTY = IV_QTY + IV_LIST.DL_EXPD_WHOT_QTY
				WHERE CLS_YMD = IV_LIST.WHOT_YMD
				AND QLTY_VEHL_cD = IV_LIST.QLTY_VEHL_CD
				AND DL_EXPD_MDL_MDY_CD = IV_LIST.DL_EXPD_MDL_MDY_CD
				AND LANG_CD = IV_LIST.LANG_CD
				AND N_PRNT_PBCN_NO = IV_LIST.N_PRNT_PBCN_NO;
				
			END LOOP;
			
	   END SP_ROLLBACK_IV_INFO;
	   
	   
	   PROCEDURE SP_MAKEWHSN_IV_INFO(P_CURR_YMD VARCHAR2)
	   IS
	   	 CURSOR IV_LIST_INFO IS SELECT WHSN_YMD,
		 					 		   QLTY_VEHL_CD, 
		 					 		   DL_EXPD_MDL_MDY_CD, 
									   LANG_CD, 
									   N_PRNT_PBCN_NO,
									   WHSN_QTY
		 					    FROM TB_PDI_WHSN_INFO
								WHERE WHSN_YMD = P_CURR_YMD;
								
	   BEGIN
	   		
			FOR IV_LIST IN IV_LIST_INFO LOOP
				
				UPDATE TB_PDI_IV_INFO
				SET IV_QTY = IV_QTY + IV_LIST.WHSN_QTY
				WHERE CLS_YMD = IV_LIST.WHSN_YMD
				AND QLTY_VEHL_cD = IV_LIST.QLTY_VEHL_CD
				AND DL_EXPD_MDL_MDY_CD = IV_LIST.DL_EXPD_MDL_MDY_CD
				AND LANG_CD = IV_LIST.LANG_CD
				AND N_PRNT_PBCN_NO = IV_LIST.N_PRNT_PBCN_NO;
				
				IF SQL%NOTFOUND THEN
				   
				    INSERT INTO TB_PDI_IV_INFO
					(CLS_YMD,
					 QLTY_VEHL_CD,
					 DL_EXPD_MDL_MDY_CD,
					 LANG_CD,
					 N_PRNT_PBCN_NO,
					 IV_QTY,
					 CMPL_YN,
					 PPRR_EENO,
					 FRAM_DTM,
					 UPDR_EENO,
					 MDFY_DTM
					)
					VALUES
					(IV_LIST.WHSN_YMD,
					 IV_LIST.QLTY_VEHL_CD,
					 IV_LIST.DL_EXPD_MDL_MDY_CD,
					 IV_LIST.LANG_CD,
					 IV_LIST.N_PRNT_PBCN_NO,
					 IV_LIST.WHSN_QTY,
					 'N',
					 'SYSTEM',
					 SYSDATE,
					 'SYSTEM',
					 SYSDATE
					);
				
				END IF;
				
			END LOOP;
			
	   END SP_MAKEWHSN_IV_INFO;
	   
	   PROCEDURE SP_MAKE_NATL_VEHL_MDY
	   IS
	       
		   CURSOR MDY_LIST_INFO IS SELECT DL_EXPD_CO_CD,
		   		  			   	  		  DL_EXPD_NAT_CD,
										  QLTY_VEHL_CD,
										  MDL_MDY_CD,
										  LANG_CD
		 					       FROM TB_NATL_LANG_MGMT
								   WHERE USE_YN = 'Y';
								
	   BEGIN
	   		
			FOR MDY_LIST IN MDY_LIST_INFO LOOP
				
				SP_NATL_VEHL_SAVE_TEMP(MDY_LIST.DL_EXPD_CO_CD,
				                       MDY_LIST.DL_EXPD_NAT_CD,
									   MDY_LIST.QLTY_VEHL_CD,
									   MDY_LIST.MDL_MDY_CD,
									   MDY_LIST.LANG_CD);
				                       
				
			END LOOP;
			
	   END SP_MAKE_NATL_VEHL_MDY;
	   
	   PROCEDURE SP_NATL_VEHL_SAVE_TEMP(P_EXPD_CO_CD   VARCHAR2,
	   							        P_EXPD_NAT_CD  VARCHAR2,
								        P_QLTY_VEHL_CD VARCHAR2,
								        P_MDL_MDY_CD   VARCHAR2,
								        P_LANG_CD      VARCHAR2)
	   IS
	   	 
		 V_EXPD_REGN_CD VARCHAR2(4);
		 
		 V_CNT NUMBER;
		 
	   BEGIN
	   		
			SELECT DL_EXPD_REGN_CD
			INTO V_EXPD_REGN_CD
			FROM TB_LANG_MGMT
			WHERE QLTY_VEHL_CD = P_QLTY_VEHL_CD
			AND MDL_MDY_CD = P_MDL_MDY_CD
			AND LANG_CD = P_LANG_CD;
			
			UPDATE TB_NATL_VEHL_MGMT
			SET DL_EXPD_REGN_CD = V_EXPD_REGN_CD,
			    UPDR_EENO = 'SYSTEM',
				MDFY_DTM = SYSDATE
		    WHERE DL_EXPD_CO_CD = P_EXPD_CO_CD
			AND DL_EXPD_NAT_CD = P_EXPD_NAT_CD
			AND QLTY_VEHL_CD = P_QLTY_VEHL_CD;
			
--			SELECT COUNT(*)
--			INTO V_CNT
--			FROM TB_NATL_VEHL_MGMT
--			WHERE DL_EXPD_CO_CD = P_EXPD_CO_CD
--			AND DL_EXPD_NAT_CD = P_EXPD_NAT_CD
--			AND QLTY_VEHL_CD = P_QLTY_VEHL_CD
--			AND DL_EXPD_REGN_CD = V_EXPD_REGN_CD; 
			
			IF SQL%NOTFOUND THEN
			   
			   INSERT INTO TB_NATL_VEHL_MGMT
			   (DL_EXPD_CO_CD,
			    DL_EXPD_NAT_CD,
				QLTY_VEHL_CD,
				DL_EXPD_REGN_CD,
				PPRR_EENO,
				FRAM_DTM,
				UPDR_EENO,
				MDFY_DTM
			   )
			   VALUES
			   (P_EXPD_CO_CD,
			    P_EXPD_NAT_CD,
				P_QLTY_VEHL_CD,
				V_EXPD_REGN_CD,
				'SYSTEM',
				SYSDATE,
				'SYSTEM',
				SYSDATE
			   );
			   
			END IF;
			
	   END SP_NATL_VEHL_SAVE_TEMP; 
	   
	   *********************************************************/ 
	   
	   --메일서버 변경 관련 테스트 
	   PROCEDURE MAIL_TEST
	   IS
	   BEGIN
	   		
			SP_CHNL_INSERTSIMPLEEMAIL('김동근', 
							   		  'kimdk@autoeversystems.com', 
							   		  '5800607', 
							   		  'H', 
							   		  '0', 
							   		  '0', 
							   		  '변경후 메일 테스트 입니다.',
                               		  SYSDATE, 
							   		  '메일테스트(변경후4)', 
							   		  '0', 
							   		  '0', 
							   		  '김동근', 
							   		  'kimdk@autoeversystems.com', 
							   		  '5800607');
							   
	   END MAIL_TEST;
	   
END PG_MAKE_DATA;