CREATE or replace PACKAGE BODY KOMMS_ADM.PG_PRNT_REQ_INFO AS

	   --발간번호 리스트 조회
	   PROCEDURE SP_GET_PBCN_LIST(P_VEHL_CD	        VARCHAR2,
	   			 				  P_EXPD_MDL_MDY_CD VARCHAR2, --(주의) 취급설명서 연식코드임
								  P_LANG_CD	        VARCHAR2,
								  P_PRNT_PBCN_NO    VARCHAR2,
							      RS OUT REFCUR)
	   IS
	   BEGIN


			OPEN RS FOR
				 SELECT A.N_PRNT_PBCN_NO,
				 		A.OLD_PRNT_PBCN_NO,
				 	    A.MDL_MDY_CD,
						A.LANG_CD,
						A.DL_EXPD_RDCS_ST_CD,
						B.QLTY_VEHL_NM,
						A.LANG_CD_NM
				 FROM (SELECT A.N_PRNT_PBCN_NO,
				 	  		  A.QLTY_VEHL_CD,
				 	  		  A.MDL_MDY_CD,
							  A.LANG_CD,
							  A.OLD_PRNT_PBCN_NO,
						      A.DL_EXPD_RDCS_ST_CD,
							  B.LANG_CD_NM
					   FROM TB_PRNT_BKGD_INFO A,
					   		TB_LANG_MGMT B,
					        TB_DL_EXPD_MDY_MGMT C
					   WHERE A.QLTY_VEHL_CD     = B.QLTY_VEHL_CD
					   AND A.MDL_MDY_CD         = B.MDL_MDY_CD
					   AND A.LANG_CD            = B.LANG_CD
					   AND A.QLTY_VEHL_CD       = C.QLTY_VEHL_CD
					   AND A.MDL_MDY_CD         = C.MDL_MDY_CD
					   AND B.DL_EXPD_REGN_CD    = C.DL_EXPD_REGN_CD
					   AND A.QLTY_VEHL_CD       = P_VEHL_CD
					   --현재의 연식을 취급설명서 연식으로 간주하고 작업을 진행한다.
					   AND C.DL_EXPD_MDL_MDY_CD = P_EXPD_MDL_MDY_CD
					   AND A.LANG_CD            = P_LANG_CD
					   AND A.N_PRNT_PBCN_NO LIKE P_PRNT_PBCN_NO || '%'
				 	  ) A,
					  TB_VEHL_MGMT B
				 WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
				 AND A.MDL_MDY_CD = B.MDL_MDY_CD
				 --[변경]. 2010.01.27.김동근 로직 처리된 발간번호 최근 순으로 정렬방식 변경
				 --ORDER BY A.N_PRNT_PBCN_NO DESC
				 ORDER BY PG_COMMON.FU_GET_SORT_PBCN(A.N_PRNT_PBCN_NO) DESC
				 ;

				 /***  이전버전
				 SELECT A.N_PRNT_PBCN_NO,
				 		A.OLD_PRNT_PBCN_NO,
				 	    A.MDL_MDY_CD,
						A.LANG_CD,
						A.DL_EXPD_RDCS_ST_CD,
						B.QLTY_VEHL_NM,
						C.LANG_CD_NM
				 FROM (SELECT A.N_PRNT_PBCN_NO,
				 	  		  A.QLTY_VEHL_CD,
				 	  		  A.MDL_MDY_CD,
							  A.LANG_CD,
							  A.OLD_PRNT_PBCN_NO,
						      A.DL_EXPD_RDCS_ST_CD
					   FROM TB_PRNT_BKGD_INFO A,
					        TB_DL_EXPD_MDY_MGMT B
					   WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
					   AND A.MDL_MDY_CD = B.MDL_MDY_CD
					   AND A.QLTY_VEHL_CD = P_VEHL_CD
					   AND A.LANG_CD = P_LANG_CD
					   AND B.DL_EXPD_MDL_MDY_CD = P_EXPD_MDL_MDY_CD
					   AND N_PRNT_PBCN_NO LIKE P_PRNT_PBCN_NO || '%'
				 	  ) A,
					  TB_VEHL_MGMT B,
					  TB_LANG_MGMT C
				 WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
				 AND A.MDL_MDY_CD = B.MDL_MDY_CD
				 AND A.QLTY_VEHL_CD = C.QLTY_VEHL_CD
				 AND A.MDL_MDY_CD = C.MDL_MDY_CD
				 AND A.LANG_CD = C.LANG_CD
				 ORDER BY A.N_PRNT_PBCN_NO DESC;
				 ***/

	   END SP_GET_PBCN_LIST;

	   --제작의뢰 내역 조회
	   PROCEDURE SP_GET_PRNT_REQ_INFO(P_VEHL_CD	       VARCHAR2,
	   			 				      P_MDL_MDY_CD     VARCHAR2,
								      P_LANG_CD	       VARCHAR2,
								      P_N_PRNT_PBCN_NO VARCHAR2,
							          RS OUT REFCUR)
	   IS
	   BEGIN

			OPEN RS FOR

				 /***

				 --연식관계를 고려하여 현재 선택된 연식과 구발간번호의 연식이 다를 수 있다.
				 --이런 경우를 대비하여 쿼리를 변경함

				 SELECT A.*,
				        '(' || C.QLTY_VEHL_CD || ')' || C.QLTY_VEHL_NM || '-' || C.MDL_MDY_CD || 'MY' AS QLTY_VEHL_NM,
						'(' || B.LANG_CD || ')' || B.LANG_CD_NM AS LANG_CD_NM
				 FROM TB_PRNT_REQ_INFO A,
				      TB_LANG_MGMT B,
					  TB_VEHL_MGMT C
				 WHERE A.N_PRNT_PBCN_NO = P_N_PRNT_PBCN_NO
				 AND A.QLTY_VEHL_CD = P_VEHL_CD
				 AND A.MDL_MDY_CD = P_MDL_MDY_CD
				 AND A.LANG_CD = P_LANG_CD
				 AND A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
				 AND A.MDL_MDY_CD = B.MDL_MDY_CD
				 AND A.LANG_CD = B.LANG_CD
				 AND A.QLTY_VEHL_CD = C.QLTY_VEHL_CD
				 AND A.MDL_MDY_CD = C.MDL_MDY_CD;
				 ***/

				 SELECT A.*,
				        (SELECT '(' || QLTY_VEHL_CD || ')' || QLTY_VEHL_NM || '-' || MDL_MDY_CD || 'MY'
						 FROM TB_VEHL_MGMT
						 WHERE QLTY_VEHL_CD = P_VEHL_CD
						 AND MDL_MDY_CD = P_MDL_MDY_CD
						) AS QLTY_VEHL_NM,
						(SELECT '(' || LANG_CD || ')' || LANG_CD_NM
						 FROM TB_LANG_MGMT
						 WHERE QLTY_VEHL_CD = P_VEHL_CD
						 AND MDL_MDY_CD = P_MDL_MDY_CD
						 AND LANG_CD = P_LANG_CD
						) AS LANG_CD_NM
				 FROM TB_PRNT_REQ_INFO A
				 WHERE A.N_PRNT_PBCN_NO = P_N_PRNT_PBCN_NO;

	   END SP_GET_PRNT_REQ_INFO;

	   --체크리스트 정보 조회
	   PROCEDURE SP_GET_CHK_LIST(P_VEHL_CD	        VARCHAR2,
	   			 				 P_MDL_MDY_CD       VARCHAR2,
								 P_LANG_CD	        VARCHAR2,
								 P_N_PRNT_PBCN_NO   VARCHAR2,
								 P_OLD_PRNT_PBCN_NO VARCHAR2,
							     RS OUT REFCUR)
	   IS

		 V_N_PRNT_PBCN_NO TB_CHKLIST_DTL_INFO.N_PRNT_PBCN_NO%TYPE;

	   BEGIN

		 IF P_N_PRNT_PBCN_NO IS NULL OR P_N_PRNT_PBCN_NO = '' THEN

			V_N_PRNT_PBCN_NO := 'NULL';

		 ELSE

			V_N_PRNT_PBCN_NO := P_N_PRNT_PBCN_NO;

		 END IF;

		 OPEN RS FOR
		 	  SELECT A.DL_EXPD_ALTR_NO,
			  		 D.ALTR_YMD,
					 D.RCPM_SHAP_CD,
					 D.DSPP_NM,
					 D.CHGR_EENO,
					 D.CRGR_NM,
					 B.QLTY_VEHL_NM,
                     A.N1AFP2_ADR,
                     A.N1AFP2_ADR1,
					 C.LANG_CD_NM,
					 D.ALTR_SBC,
					 A.N_PRNT_PBCN_NO,
					 D.ATTC_YN
			  FROM (SELECT A.DL_EXPD_ALTR_NO,
			  	   		   A.QLTY_VEHL_CD,
						   A.LANG_CD,
						   NVL(A.N_PRNT_PBCN_NO, '') AS N_PRNT_PBCN_NO,
						   B.N1AFP2_ADR,
						   B.N1AFP2_ADR1,
						   CASE WHEN B.RCPM_SHAP_CD = '05' THEN 2
						        WHEN B.RCPM_SHAP_CD = '06' THEN 0
						        WHEN B.RCPM_SHAP_CD = '07' THEN 1
						   		WHEN A.N_PRNT_PBCN_NO IS NULL THEN 3
						        WHEN A.N_PRNT_PBCN_NO = V_N_PRNT_PBCN_NO THEN 4
								WHEN A.N_PRNT_PBCN_NO = P_OLD_PRNT_PBCN_NO THEN 5
						   END AS IDX
			        FROM TB_CHKLIST_DTL_INFO A,
			             TB_CHKLIST_INFO B
			        WHERE A.DL_EXPD_ALTR_NO = B.DL_EXPD_ALTR_NO
			        AND A.QLTY_VEHL_CD = P_VEHL_CD
			        AND A.LANG_CD = P_LANG_CD
					AND B.DEL_YN = 'N'
					AND (B.RCPM_SHAP_CD IN ('05', '06', '07')  --법규의 경우에는 무조건 표시되도록 한다.
					     OR (A.N_PRNT_PBCN_NO IS NULL OR
			                 A.N_PRNT_PBCN_NO IN (V_N_PRNT_PBCN_NO, P_OLD_PRNT_PBCN_NO)
							)
						)
			       ) A,
				   (SELECT QLTY_VEHL_CD,
				   		   QLTY_VEHL_NM
					FROM TB_VEHL_MGMT
					WHERE QLTY_VEHL_CD = P_VEHL_CD
					AND MDL_MDY_CD = P_MDL_MDY_CD
				   ) B,
				   (SELECT QLTY_VEHL_CD,
				   		   LANG_CD,
				   		   LANG_CD_NM
					FROM TB_LANG_MGMT
					WHERE QLTY_VEHL_CD = P_VEHL_CD
					AND MDL_MDY_CD = P_MDL_MDY_CD
					AND LANG_CD = P_LANG_CD
				   ) C,
				   TB_CHKLIST_INFO D
			  WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
			  AND A.QLTY_VEHL_CD = C.QLTY_VEHL_CD
			  AND A.LANG_CD = C.LANG_CD
			  AND A.DL_EXPD_ALTR_NO = D.DL_EXPD_ALTR_NO
			  --[변경]. 2010.01.27.김동근 정렬순서 변경 - 변경번호 역순
			  --ORDER BY A.IDX, A.DL_EXPD_ALTR_NO
			  ORDER BY A.IDX, A.DL_EXPD_ALTR_NO DESC
			  ;

	   END SP_GET_CHK_LIST;

       --제작의뢰 정보 삭제
	   PROCEDURE SP_PRNT_REQ_INFO_DEL(P_N_PRNT_PBCN_NO VARCHAR2,
	   			 					  P_USER_EENO      VARCHAR2)
	   IS
	   	 V_RDCS_ST_CD VARCHAR2(4);

	   BEGIN

			--삭제 조건을 만족하는 경우에만 삭제가 가능하다.
			IF FU_CHECK_RDCS_ST_CD(P_N_PRNT_PBCN_NO, 'D', V_RDCS_ST_CD) = 'Y' THEN

			   --제작의뢰 내역 삭제
			   DELETE FROM TB_PRNT_REQ_INFO
			   WHERE N_PRNT_PBCN_NO = P_N_PRNT_PBCN_NO;

			   --제작의뢰 상태 정보 삭제
			   DELETE FROM TB_PRNT_BKGD_INFO
			   WHERE N_PRNT_PBCN_NO = P_N_PRNT_PBCN_NO;

			   --인쇄 세부내역 삭제
			   DELETE FROM TB_PRNT_FP_INFO
			   WHERE N_PRNT_PBCN_NO = P_N_PRNT_PBCN_NO;

			   --인쇄배열표 내역 삭제
			   DELETE FROM TB_PRNT_ALGN_INFO
			   WHERE N_PRNT_PBCN_NO = P_N_PRNT_PBCN_NO;

			   --체크리스트 발간번호 정보 제거
			   UPDATE TB_CHKLIST_DTL_INFO
			   SET N_PRNT_PBCN_NO = NULL,
			       UPDR_EENO = P_USER_EENO,
				   MDFY_DTM = SYSDATE,
				   ET_YN = 'N'
			   WHERE N_PRNT_PBCN_NO = P_N_PRNT_PBCN_NO;

			END IF;

	   END SP_PRNT_REQ_INFO_DEL;

       --체크리스트 정보 삭제
	   PROCEDURE SP_CHKLIST_DTL_INFO_DEL(P_EXPD_ALTR_NO   VARCHAR2,
	   			 						 P_VEHL_CD		  VARCHAR2,
										 P_LANG_CD		  VARCHAR2,
	   			 						 P_N_PRNT_PBCN_NO VARCHAR2,
	   			 					     P_USER_EENO      VARCHAR2)
	   IS

		 V_RDCS_ST_CD VARCHAR2(4);

	   BEGIN

			IF FU_CHECK_RDCS_ST_CD(P_N_PRNT_PBCN_NO, 'D', V_RDCS_ST_CD) = 'Y' THEN

			   UPDATE TB_CHKLIST_DTL_INFO
			   SET N_PRNT_PBCN_NO = NULL,
			       UPDR_EENO = P_USER_EENO,
				   MDFY_DTM = SYSDATE,
				   ET_YN = 'N'
			   WHERE DL_EXPD_ALTR_NO = P_EXPD_ALTR_NO
			   AND QLTY_VEHL_CD = P_VEHL_CD
			   AND LANG_CD = P_LANG_CD;

			END IF;

	   END SP_CHKLIST_DTL_INFO_DEL;

       --제작의뢰 내역 저장
	   PROCEDURE SP_PRNT_REQ_INFO_SAVE(P_N_PRNT_PBCN_NO      VARCHAR2,
                                       P_QLTY_VEHL_CD        VARCHAR2,
                                       P_MDL_MDY_CD          VARCHAR2,
                                       P_LANG_CD             VARCHAR2,
                                       P_PRNT_PARR_YMD       VARCHAR2,
                                       P_DLVG_PARR_YMD       VARCHAR2,
                                       P_I_WAY_CD            VARCHAR2,
                                       P_PRNT_PARR_QTY       NUMBER,
                                       P_PRNT_WAY_CD         VARCHAR2,
                                       P_DEPQ1_CD            VARCHAR2,
                                       P_OLD_PRNT_PBCN_NO    VARCHAR2,
                                       P_PG_MGN_SBC          VARCHAR2,
                                       P_PG_NL               NUMBER,
                                       P_OORD_EDIT_PG_NL     NUMBER,
                                       P_MDFY_PG_NL          NUMBER,
                                       P_PRTL_IMTR_SBC       VARCHAR2,
                                       P_N1AFP2_ADR          VARCHAR2,
                                       P_N2AFP2_ADR          VARCHAR2,
                                       P_GRN_DOC_NL          NUMBER,
                                       P_DEPC1_YN            VARCHAR2,
                                       P_CRGR_EENO	         VARCHAR2,
                                       P_STATE		         VARCHAR2,
                                       P_USER_EENO           VARCHAR2,
                                       P_PRNT_WAY_CD2        VARCHAR2)
	  IS

		V_RDCS_ST_CD       VARCHAR2(4);

		V_OLD_PRNT_PBCN_NO TB_PRNT_BKGD_INFO.OLD_PRNT_PBCN_NO%TYPE;

		V_USE_YN		   VARCHAR2(1);

	  BEGIN

		   --차종코드 테이블에서 사용여부 정보를 확인한다.
		   SELECT MAX(USE_YN)
		   INTO V_USE_YN
		   FROM TB_VEHL_MGMT
		   WHERE QLTY_VEHL_CD = P_QLTY_VEHL_CD
		   AND MDL_MDY_CD = P_MDL_MDY_CD;

		   IF V_USE_YN = 'N' THEN

			  RAISE_APPLICATION_ERROR(-20001, 'Invalid vehl cd - not using ' ||
			   								  'vehl:' || P_QLTY_VEHL_CD || ',' ||
											  'mkyr:' || P_MDL_MDY_CD);

		   END IF;

		   --언어코드 테이블에서 사용여부 정보를 확인한다.
		   SELECT MAX(USE_YN)
		   INTO V_USE_YN
		   FROM TB_LANG_MGMT
		   WHERE QLTY_VEHL_CD = P_QLTY_VEHL_CD
		   AND MDL_MDY_CD = P_MDL_MDY_CD
		   AND LANG_CD = P_LANG_CD;

		   IF V_USE_YN = 'N' THEN

			  RAISE_APPLICATION_ERROR(-20001, 'Invalid lang cd - not using ' ||
			   								  'vehl:' || P_QLTY_VEHL_CD || ',' ||
											  'mkyr:' || P_MDL_MDY_CD || ',' ||
											  'lang:' || P_LANG_CD);
		   END IF;

		   IF FU_CHECK_RDCS_ST_CD(P_N_PRNT_PBCN_NO, P_STATE, V_RDCS_ST_CD) = 'Y' THEN

			  IF P_OLD_PRNT_PBCN_NO IS NULL OR P_OLD_PRNT_PBCN_NO = '' THEN

					V_OLD_PRNT_PBCN_NO := P_N_PRNT_PBCN_NO;

			  ELSE

				 	V_OLD_PRNT_PBCN_NO := P_OLD_PRNT_PBCN_NO;

			  END IF;

			  UPDATE TB_PRNT_REQ_INFO
			  SET
			  	  --[변경]2009-04-22. 연식은 변경해 줄수 있도록 한다.
			  	  --수정시에는 차종코드, 연식, 언어를 변경하지 않는다.
			  	  QLTY_VEHL_CD = P_QLTY_VEHL_CD,
			      MDL_MDY_CD = P_MDL_MDY_CD,
				  LANG_CD = P_LANG_CD,

				  --인쇄예정일은 무조건 현재일로 처리해 준다.
				  --PRNT_PARR_YMD = P_PRNT_PARR_YMD,
				  PRNT_PARR_YMD = TO_CHAR(SYSDATE, 'YYYYMMDD'),

				  DLVG_PARR_YMD = P_DLVG_PARR_YMD,
				  I_WAY_CD = P_I_WAY_CD,
				  PRNT_PARR_QTY = P_PRNT_PARR_QTY,
				  PRNT_WAY_CD = P_PRNT_WAY_CD,
                  PRNT_WAY_CD2 = P_PRNT_WAY_CD2,
				  DEPQ1_CD = P_DEPQ1_CD,
				  OLD_PRNT_PBCN_NO = V_OLD_PRNT_PBCN_NO,
				  PG_MGN_SBC = P_PG_MGN_SBC,
				  PG_NL = P_PG_NL,
				  OORD_EDIT_PG_NL = P_OORD_EDIT_PG_NL,
				  MDFY_PG_NL = P_MDFY_PG_NL,
				  PRTL_IMTR_SBC = P_PRTL_IMTR_SBC,
				  ORDN_RQST_YMD = TO_CHAR(SYSDATE, 'YYYYMMDD'),
				  N1AFP2_ADR = P_N1AFP2_ADR,
				  N2AFP2_ADR = P_N2AFP2_ADR,
                  GRN_DOC_NL = P_GRN_DOC_NL,
                  DEPC1_YN = P_DEPC1_YN,
				  CRGR_EENO = P_CRGR_EENO,
				  DL_EXPD_MDL_MDY_CD = P_MDL_MDY_CD,
				  UPDR_EENO = P_USER_EENO,
				  MDFY_DTM = SYSDATE
			  WHERE N_PRNT_PBCN_NO = P_N_PRNT_PBCN_NO;

			  IF SQL%NOTFOUND THEN

				 INSERT INTO TB_PRNT_REQ_INFO
				 (N_PRNT_PBCN_NO,
                  QLTY_VEHL_CD,
				  MDL_MDY_CD,
				  LANG_CD,
				  PRNT_PARR_YMD,
				  DLVG_PARR_YMD,
				  I_WAY_CD,
				  PRNT_PARR_QTY,
				  PRNT_WAY_CD,
                  PRNT_WAY_CD2,
				  DEPQ1_CD,
				  OLD_PRNT_PBCN_NO,
				  PG_MGN_SBC,
				  PG_NL,
				  OORD_EDIT_PG_NL,
				  MDFY_PG_NL,
				  PRTL_IMTR_SBC,
				  ORDN_RQST_YMD,
				  N1AFP2_ADR,
				  N2AFP2_ADR,
                  GRN_DOC_NL,
                  DEPC1_YN,
				  CRGR_EENO,
				  DL_EXPD_MDL_MDY_CD,
				  PPRR_EENO,
				  FRAM_DTM,
				  UPDR_EENO,
				  MDFY_DTM
				 )
				 VALUES
				 (P_N_PRNT_PBCN_NO,
                  P_QLTY_VEHL_CD,
				  P_MDL_MDY_CD,
				  P_LANG_CD,
				  --P_PRNT_PARR_YMD,
				  TO_CHAR(SYSDATE, 'YYYYMMDD'),
				  P_DLVG_PARR_YMD,
				  P_I_WAY_CD,
				  P_PRNT_PARR_QTY,
				  P_PRNT_WAY_CD,
                  P_PRNT_WAY_CD2,
				  P_DEPQ1_CD,
				  V_OLD_PRNT_PBCN_NO,
				  P_PG_MGN_SBC,
				  P_PG_NL,
				  P_OORD_EDIT_PG_NL,
				  P_MDFY_PG_NL,
				  P_PRTL_IMTR_SBC,
				  TO_CHAR(SYSDATE, 'YYYYMMDD'),
				  P_N1AFP2_ADR,
				  P_N2AFP2_ADR,
                  P_GRN_DOC_NL,
                  P_DEPC1_YN,
				  P_CRGR_EENO,
				  P_MDL_MDY_CD,
				  P_USER_EENO,
				  SYSDATE,
				  P_USER_EENO,
				  SYSDATE
				 );

			  END IF;

			  UPDATE TB_PRNT_BKGD_INFO
			  SET
			  	  --[변경]2009-04-22. 연식은 변경해 줄수 있도록 한다.
			  	  --수정시에는 차종코드, 연식, 언어를 변경하지 않는다.
			  	  QLTY_VEHL_CD = P_QLTY_VEHL_CD,
			      MDL_MDY_CD = P_MDL_MDY_CD,
				  LANG_CD = P_LANG_CD,
			  	  DL_EXPD_RDCS_ST_CD = V_RDCS_ST_CD,
			      TRTM_YMD = TO_CHAR(SYSDATE, 'YYYYMMDD'),
				  UPDR_EENO = P_USER_EENO,
				  MDFY_DTM = SYSDATE
			  WHERE N_PRNT_PBCN_NO = P_N_PRNT_PBCN_NO;

			  IF SQL%NOTFOUND THEN

				 INSERT INTO TB_PRNT_BKGD_INFO
				 (N_PRNT_PBCN_NO,
				  QLTY_VEHL_CD,
				  MDL_MDY_CD,
				  LANG_CD,
				  OLD_PRNT_PBCN_NO,
				  CRE_YMD,
				  DL_EXPD_RDCS_ST_CD,
				  TRTM_YMD,
				  PPRR_EENO,
				  FRAM_DTM,
				  UPDR_EENO,
				  MDFY_DTM
				 )
				 VALUES
				 (P_N_PRNT_PBCN_NO,
				  P_QLTY_VEHL_CD,
				  P_MDL_MDY_CD,
				  P_LANG_CD,
				  V_OLD_PRNT_PBCN_NO,
				  TO_CHAR(SYSDATE, 'YYYYMMDD'),
				  V_RDCS_ST_CD,
				  TO_CHAR(SYSDATE, 'YYYYMMDD'),
				  P_USER_EENO,
				  SYSDATE,
				  P_USER_EENO,
				  SYSDATE
				 );

			  END IF;

		   ELSE

			   RAISE_APPLICATION_ERROR(-20001, 'Invalid State Code1 - STATE:[' || P_STATE || '] RDCS_ST_CD:[' || V_RDCS_ST_CD || ']');

		   END IF;

	  END SP_PRNT_REQ_INFO_SAVE;

      --체크리스트 정보 저장
	  PROCEDURE SP_CHKLIST_DTL_INFO_SAVE(P_EXPD_ALTR_NO   VARCHAR2,
	   			 					     P_VEHL_CD		  VARCHAR2,
										 P_LANG_CD		  VARCHAR2,
	   			 						 P_N_PRNT_PBCN_NO VARCHAR2,
										 P_STATE		  VARCHAR2,
	   			 					     P_USER_EENO      VARCHAR2)
	  IS

		V_RDCS_ST_CD VARCHAR2(4);

		V_QLTY_VEHL_CD VARCHAR2(4);
		V_LANG_CD	   VARCHAR2(3);

	  BEGIN

		   --의뢰내역이 먼저저장된다고 함... 그래서 별도로 상태를 체크해 줄 필요가 없다.(상태를 체크하면 오히려 에러가 발생할 여지가 있음)
--		   IF FU_CHECK_RDCS_ST_CD(P_N_PRNT_PBCN_NO, P_STATE, V_RDCS_ST_CD) = 'Y' THEN

			   IF P_N_PRNT_PBCN_NO IS NULL OR P_N_PRNT_PBCN_NO = '' THEN

				   UPDATE TB_CHKLIST_DTL_INFO
			       SET N_PRNT_PBCN_NO = NULL,
			           UPDR_EENO = P_USER_EENO,
				       MDFY_DTM = SYSDATE,
					   ET_YN = 'N'
			       WHERE DL_EXPD_ALTR_NO = P_EXPD_ALTR_NO
			       AND QLTY_VEHL_CD = P_VEHL_CD
			       AND LANG_CD = P_LANG_CD;

			   ELSE

				   --[변경] 2010.08.31.김동근 P_VEHL_CD, P_LANG_CD 값이 이상하게 들어오는 경우가 있어서
		   		   --인쇄의뢰 정보에서 읽어와서 처리하는 것으로 변경
		   		   SELECT MAX(QLTY_VEHL_CD),
		   		   		  MAX(LANG_CD)
		   		   INTO V_QLTY_VEHL_CD,
		           		V_LANG_CD
		           FROM TB_PRNT_REQ_INFO
		   		   WHERE N_PRNT_PBCN_NO = P_N_PRNT_PBCN_NO;

				   UPDATE TB_CHKLIST_DTL_INFO
			   	   SET N_PRNT_PBCN_NO = P_N_PRNT_PBCN_NO,
			       	   UPDR_EENO = P_USER_EENO,
				   	   MDFY_DTM = SYSDATE,
					   ET_YN = 'N'
			   	   WHERE DL_EXPD_ALTR_NO = P_EXPD_ALTR_NO
			       AND QLTY_VEHL_CD = V_QLTY_VEHL_CD
			       AND LANG_CD = V_LANG_CD;

			   END IF;

--		   ELSE

--			   RAISE_APPLICATION_ERROR(-20001, 'Invalid State Code2 - STATE:[' || P_STATE || '] RDCS_ST_CD:[' || V_RDCS_ST_CD || ']');

--		   END IF;

	  END SP_CHKLIST_DTL_INFO_SAVE;

      --제작의뢰 정보 저장시의 상태값 체크
	  FUNCTION FU_CHECK_RDCS_ST_CD(P_N_PRNT_PBCN_NO VARCHAR2,
	   							   P_STATE          VARCHAR2,
								   P_RDCS_ST_CD OUT VARCHAR2)RETURN VARCHAR2
	  IS

		V_RETURN	 CHAR(1);

	  BEGIN

		   V_RETURN := 'N';

		   SELECT MAX(DL_EXPD_RDCS_ST_CD) INTO P_RDCS_ST_CD
		   FROM TB_PRNT_BKGD_INFO
		   WHERE N_PRNT_PBCN_NO = P_N_PRNT_PBCN_NO;

		   --제작의뢰의 저장인 경우
		   IF P_STATE = 'S' THEN

			  IF P_RDCS_ST_CD  IS NULL  OR P_RDCS_ST_CD IN ('03', '05') THEN

				 V_RETURN := 'Y';

			  	 P_RDCS_ST_CD := '05';

			  END IF;

		   --제작의뢰의 승인의뢰인 경우
		   ELSIF P_STATE = 'Q' THEN

		   	  --신규작성, 반려, 저장된 항목은 승인의뢰 할 수  있다.
			  IF P_RDCS_ST_CD  IS NULL OR P_RDCS_ST_CD IN ('03', '05') THEN

				 V_RETURN := 'Y';

				 IF P_RDCS_ST_CD = '03' THEN

					 P_RDCS_ST_CD := '04';

				  ELSE

					 P_RDCS_ST_CD := '01';

				  END IF;

			  END IF;

		   --발주/승인의 승인인 경우
		   ELSIF P_STATE = 'C' THEN

			  --의뢰, 재의뢰 된 항목은 승인할 수 있다.
			  IF P_RDCS_ST_CD IN ('01', '04') THEN

				 V_RETURN := 'Y';

				 P_RDCS_ST_CD := '02';

			  END IF;

		   --발주/승인의 반려인 경우
		   ELSIF P_STATE = 'R' THEN

			  --의뢰, 재의뢰 된 항목은 반려 할 수 있다.
			  IF P_RDCS_ST_CD IN ('01', '04') THEN

				 V_RETURN := 'Y';

				 P_RDCS_ST_CD := '03';

			  END IF;

		   --승인 취소인 경우
		   ELSIF P_STATE = 'W'  THEN

			  --승인된 항목만 취소할 수 있다.
			  IF P_RDCS_ST_CD IN ('02') THEN

				 V_RETURN := 'Y';

				 P_RDCS_ST_CD := '01';

			  END IF;

		   --삭제인 경우
		   ELSE

			 --반려, 저장된 항목은  삭제가 가능한다.
			 IF P_RDCS_ST_CD IN ('03', '05') THEN

				 V_RETURN := 'Y';

			  END IF;

		   END IF;

		   RETURN V_RETURN;

	  END FU_CHECK_RDCS_ST_CD;

END PG_PRNT_REQ_INFO;