CREATE OR REPLACE PACKAGE KOMMS_ADM.PG_PRNT_APVL_INFO AS

	   TYPE REFCUR IS REF CURSOR;

	   --발간번호 리스트 조회
	   PROCEDURE SP_GET_PBCN_LIST(P_VEHL_CD	     VARCHAR2,
	   			 				  P_MDL_MDY_CD   VARCHAR2,
								  P_LANG_CD	     VARCHAR2,
								  P_PRNT_PBCN_NO VARCHAR2,
							      RS OUT REFCUR);

       --제작의뢰 내용 조회
	   PROCEDURE SP_GET_PRNT_APVL_INFO(P_VEHL_CD	    VARCHAR2,
	   			 				       P_MDL_MDY_CD     VARCHAR2,
								       P_LANG_CD	    VARCHAR2,
								       P_N_PRNT_PBCN_NO VARCHAR2,
							           RS OUT REFCUR);


	   --체크리스트 정보 조회
	   PROCEDURE SP_GET_CHK_LIST(P_VEHL_CD	        VARCHAR2,
	   			 				 P_MDL_MDY_CD       VARCHAR2,
								 P_LANG_CD	        VARCHAR2,
								 P_N_PRNT_PBCN_NO   VARCHAR2,
								 P_OLD_PRNT_PBCN_NO VARCHAR2,
							     RS OUT REFCUR);
       --반려 내역 조회
	   PROCEDURE SP_PRNT_APVL_SBC_INFO(P_N_PRNT_PBCN_NO VARCHAR2,
	  				                   RS 		  OUT REFCUR);

	   --제작승인 내역 저장
	   PROCEDURE SP_PRNT_APVL_INFO_SAVE(P_QLTY_VEHL_CD    VARCHAR2,
									    P_EXPD_MDL_MDY_CD VARCHAR2,
									    P_LANG_CD         VARCHAR2,
									    P_N_PRNT_PBCN_NO  VARCHAR2,
	   			 						P_PRNT_PARR_QTY   NUMBER,
										P_PRNT_PARR_YMD   VARCHAR2,
									    P_DLVG_PARR_YMD   VARCHAR2,
                                        P_STATE      	  VARCHAR2,
                                        P_USER_EENO       VARCHAR2,
                                        P_PRTL_SBC        VARCHAR2);

	   --제작승인 취소 작업 수행
	   PROCEDURE SP_PRNT_APVL_INFO_CANCEL(P_QLTY_VEHL_CD    VARCHAR2,
									      P_EXPD_MDL_MDY_CD VARCHAR2,
									      P_LANG_CD         VARCHAR2,
									      P_N_PRNT_PBCN_NO  VARCHAR2,
										  P_STATE      	    VARCHAR2,
										  P_USER_EENO       VARCHAR2);

	   --발주의뢰서에 전달할 내역 조회
	   PROCEDURE SP_GET_ORDER_REQ_INFO(P_VEHL_CD	    VARCHAR2,
	   			 				       P_MDL_MDY_CD     VARCHAR2,
								       P_LANG_CD	    VARCHAR2,
								       P_N_PRNT_PBCN_NO VARCHAR2,
							           RS OUT REFCUR);

	   --언어코드에 해당하는 발주의뢰서 언어명칭 리턴
	   FUNCTION FU_GET_LANG_CD_NM(P_LANG_CD VARCHAR2)RETURN VARCHAR2;


	   --판매단가 인터페이스(배치 프로그램에서 호출)
	   PROCEDURE SP_UPDATE_SALE_UNP(P_N_PRNT_PBCN_NO VARCHAR2,
	   			 					P_SALE_UNP		 NUMBER);



END PG_PRNT_APVL_INFO;