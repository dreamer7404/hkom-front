CREATE OR REPLACE PACKAGE BODY KOMMS_ADM.PG_PDI_IV_INFO AS
  
  --PDI 배송요청 정보 저장 
  PROCEDURE PDI_DLVH_REQ_SAVE(P_VEHL_CD    VARCHAR2,
	   			 			  P_MDL_MDY_CD VARCHAR2,
							  P_LANG_CD    VARCHAR2,
							  P_RQ_QTY	   NUMBER,
							  P_PWMR_EENO  VARCHAR2,
							  P_USER_EENO  VARCHAR2
							  , P_PRDN_PLNT_CD  VARCHAR2
							  )
  IS
  	
	V_CURR_YMD VARCHAR2(8);
		 
	V_DATA_SN  NUMBER(7);
		 
	V_DTL_SN   NUMBER(11);
	
	V_MAIL_TITLE   VARCHAR2(8000);
    V_MAIL_CONTENT VARCHAR2(8000);
		 
	V_QLTY_VEHL_NM TB_VEHL_MGMT.QLTY_VEHL_NM%TYPE;
	V_LANG_CD_NM   TB_LANG_MGMT.LANG_CD_NM%TYPE;
		  
  BEGIN
  	   
	   V_CURR_YMD := TO_CHAR(SYSDATE, 'YYYYMMDD');
			
       SELECT A.DATA_SN,
              B.QLTY_VEHL_NM,
              CASE WHEN A.A_CODE IS NULL THEN '(' || A.LANG_CD || ')'
                   ELSE '(' || A.LANG_CD || '-' || A.A_CODE || ')' 
              END || A.LANG_CD_NM AS LANG_CD_NM
         INTO V_DATA_SN,
              V_QLTY_VEHL_NM,
              V_LANG_CD_NM
         FROM TB_LANG_MGMT A,
              TB_VEHL_MGMT B
        WHERE A.QLTY_VEHL_CD = P_VEHL_CD
          AND A.MDL_MDY_CD = P_MDL_MDY_CD
          AND A.LANG_CD = P_LANG_CD
          AND A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
          AND A.MDL_MDY_CD = B.MDL_MDY_CD;
 	
 	   INSERT INTO TB_PDI_DLVH_REQ_INFO
 	   (
 	    RQ_YMD,
 	    DATA_SN,
 	 	DTL_SN,
 	 	QLTY_VEHL_CD,
 	 	MDL_MDY_CD,
 	 	LANG_CD,
		PWMR_EENO,
 	 	RQ_QTY,
 	 	PPRR_EENO,
 	 	FRAM_DTM,
 	 	UPDR_EENO,
 	 	MDFY_DTM
 	 	, PRDN_PLNT_CD
 	   )
	 	SELECT V_CURR_YMD,
	 		   V_DATA_SN,
	 		   (NVL(MAX(DTL_SN), 0) + 1), 
	 		   P_VEHL_CD,
	 		   P_MDL_MDY_CD,
	 		   P_LANG_CD,
	 		   P_PWMR_EENO,
	 		   P_RQ_QTY,
	 		   P_USER_EENO,
	 		   SYSDATE,
	 		   P_USER_EENO,
	 		   SYSDATE
	 		   , P_PRDN_PLNT_CD
	      FROM TB_PDI_DLVH_REQ_INFO
	     WHERE RQ_YMD   = V_CURR_YMD
	       AND DATA_SN = V_DATA_SN;
 	
	
	--메일 발송 
	V_MAIL_TITLE   := '오너스매뉴얼 긴급 배송 요청합니다.';
	V_MAIL_CONTENT := '현재 재고부족으로 상기 메뉴얼의 긴급 배송을 요청합니다.<br>' ||
					  '차종    : (' || P_VEHL_CD || ')' || V_QLTY_VEHL_NM || '-' || P_MDL_MDY_CD || 'MY<br>' ||
					  --'언어    : (' || P_LANG_CD || ')' || V_LANG_CD_NM || '<br>' ||
					  '언어    : ' || V_LANG_CD_NM || '<br>' ||
					  '수량    : ' || TO_CHAR(P_RQ_QTY) || '부<br>';
    
--	--서비스기술 정보팀 메일 발송 
--	PG_TOT_IV_INFO.SP_SEND_MAIL(P_VEHL_CD, P_MDL_MDY_CD, '01', P_PWMR_EENO, V_MAIL_TITLE, V_MAIL_CONTENT);
	
	--세화 메일 발송 						  
	PG_TOT_IV_INFO.SP_SEND_MAIL(P_VEHL_CD, P_MDL_MDY_CD, '03', P_PWMR_EENO, V_MAIL_TITLE, V_MAIL_CONTENT);
		
  END PDI_DLVH_REQ_SAVE;
  							   
							   
  --PDI재고 조회(PDI, 차종, 연식, 지역, 언어)
  PROCEDURE SP_GET_PDI_IV_INFO(P_MENU_ID 	VARCHAR2,
							   P_USER_EENO  VARCHAR2,
							   P_CURR_YMD	VARCHAR2,
 							   P_PDI_CD	    VARCHAR2,
							   P_VEHL_CD	VARCHAR2,
							   P_MDL_MDY	VARCHAR2,
							   P_REGN_CD	VARCHAR2,
							   P_LANG_CD	VARCHAR2,
							   P_DLVY_STATE VARCHAR2,
                               RS 		  OUT REFCUR,
                               P_MESSAGE OUT VARCHAR2)
   IS
   	 V_MESSAGE VARCHAR2(8000);
   BEGIN
	   		PG_TOT_IV_INFO.SP_GET_MESSAGE(P_CURR_YMD, V_MESSAGE);
			
			P_MESSAGE := V_MESSAGE;
			
			SP_GET_PDI_IV_INFO2(P_MENU_ID,
								P_USER_EENO,
								P_CURR_YMD,
								'ALL',
								P_PDI_CD,
								P_VEHL_CD,
								P_MDL_MDY,
								P_REGN_CD,
								P_LANG_CD,
								P_DLVY_STATE,
								RS);
								  
   END SP_GET_PDI_IV_INFO;
	
   --PDI재고 조회(승상구분, PDI, 차종, 연식, 지역, 언어)
   PROCEDURE SP_GET_PDI_IV_INFO2(P_MENU_ID 	  VARCHAR2,
								 P_USER_EENO  VARCHAR2,
								 P_CURR_YMD	  VARCHAR2,
								 P_PAC_SCN_CD VARCHAR2,
 								 P_PDI_CD	  VARCHAR2,
								 P_VEHL_CD	  VARCHAR2,
								 P_MDL_MDY	  VARCHAR2,
								 P_REGN_CD	  VARCHAR2,
								 P_LANG_CD	  VARCHAR2,
								 P_DLVY_STATE VARCHAR2,
                                 RS 		OUT REFCUR)
	   IS
	   	  
		  V_FROM_MDL_MDY VARCHAR2(2);
		  V_TO_MDL_MDY   VARCHAR2(2);
		  
	   BEGIN
	   	  
		  PG_COMMON.SP_GET_VALID_MDL_MDY4(P_CURR_YMD, '', V_FROM_MDL_MDY, V_TO_MDL_MDY);
		  
		  IF P_DLVY_STATE = 'ALL' THEN
		  	 
			 OPEN RS FOR
			 	  WITH T AS (SELECT A.CL_SCN_CD,
			          	 		    C.DATA_SN,
			  					    C.QLTY_VEHL_CD,
                                    C.MDL_MDY_CD,
                                    C.LANG_CD,
                                    --'(' || C.QLTY_VEHL_CD || ')' || B.QLTY_VEHL_NM || '-' || C.MDL_MDY_CD || 'MY' AS QLTY_VEHL_NM,
									C.QLTY_VEHL_CD || '-' || C.MDL_MDY_CD AS QLTY_VEHL_NM,
									--C.LANG_CD_NM,
                                    CASE WHEN C.A_CODE IS NULL THEN '(' || C.LANG_CD || ')'
									     ELSE '(' || C.LANG_CD || '-' || C.A_CODE || ')' 
								    END || C.LANG_CD_NM AS LANG_CD_NM,
                                    C.DL_EXPD_REGN_CD,
									C.SORT_SN AS LANG_SORT_SN
                             FROM (SELECT QLTY_VEHL_CD,
                                          MAX(CL_SCN_CD) AS CL_SCN_CD
                                   FROM TB_AUTH_VEHL
                                   WHERE USER_EENO = PG_COMMON.FU_RPAD(P_USER_EENO, 7)
                                   AND QLTY_VEHL_CD = DECODE(P_VEHL_CD, 'ALL', QLTY_VEHL_CD, P_VEHL_CD)
                                   GROUP BY QLTY_VEHL_CD
                                  ) A,
                                  TB_VEHL_MGMT B,
                                  TB_LANG_MGMT C
                             WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
                             AND A.QLTY_VEHL_CD = C.QLTY_VEHL_CD
                             AND B.MDL_MDY_CD = C.MDL_MDY_CD
                             AND B.MDL_MDY_CD BETWEEN V_FROM_MDL_MDY AND V_TO_MDL_MDY
                             AND B.MDL_MDY_CD = DECODE(P_MDL_MDY , '', B.MDL_MDY_CD, P_MDL_MDY)
						     AND B.DL_EXPD_PAC_SCN_CD = DECODE(P_PAC_SCN_CD, 'ALL', B.DL_EXPD_PAC_SCN_CD, P_PAC_SCN_CD)
                             AND B.DL_EXPD_PDI_CD = DECODE(P_PDI_CD, 'ALL', B.DL_EXPD_PDI_CD, P_PDI_CD)
						     AND C.DL_EXPD_REGN_CD = DECODE(P_REGN_CD, 'ALL', C.DL_EXPD_REGN_CD, P_REGN_CD)
							 AND C.LANG_CD <> 'KO'
							 AND C.LANG_CD = DECODE(P_LANG_CD, 'ALL', C.LANG_CD, P_LANG_CD)
							 AND B.USE_YN = 'Y'
							 AND C.USE_YN = 'Y'
                            )
			      SELECT A.CL_SCN_CD,
			   		     A.DATA_SN,
					     A.QLTY_VEHL_CD,
					     A.MDL_MDY_CD,
					     A.LANG_CD,
					     A.DL_EXPD_REGN_CD,
					     A.QLTY_VEHL_NM,
					     A.LANG_CD_NM,
					     A.DL_EXPD_REGN_NM,
					     A.WEK2_PLAN_QTY,
					     A.DAY3_PLAN_QTY,
					     A.CURR_MTH_TRWI_QTY,
					     A.PREV_1DAY_TRWI_QTY,
					     A.SEWHA_IV_QTY,
					     A.SEWHA_PRNT_YN, --세화 인쇄중 데이터 존재여부 확인 
					     A.SEWHA_DLVY_QTY,
					     A.PDI_DEEI1_QTY,
						 A.PDI_IV_QTY,
					     A.DSID3_QTY,
						 A.DAY3_AFTR_IV_QTY,
						 A.WEK2_AFTR_IV_QTY,
						 A.PRNT_STATE,
						 B.DL_EXPD_PRVS_NM AS PRNT_STATE_NM,
						 PLNT_DAY3_QTY_TEXT,
						 PLNT_WEK2_QTY_TEXT,
						 PLNT_YN
			      FROM (SELECT A.CL_SCN_CD,
			   		           A.DATA_SN,
					           A.QLTY_VEHL_CD,
					           A.MDL_MDY_CD,
					           A.LANG_CD,
					           A.DL_EXPD_REGN_CD,
					           A.QLTY_VEHL_NM,
					           A.LANG_CD_NM,
					           B.DL_EXPD_PRVS_NM AS DL_EXPD_REGN_NM,
					           A.WEK2_PLAN_QTY,
					           A.DAY3_PLAN_QTY,
					           A.CURR_MTH_TRWI_QTY,
					           A.PREV_1DAY_TRWI_QTY,
					           A.SEWHA_IV_QTY,
					           A.SEWHA_PRNT_YN, --세화 인쇄중 데이터 존재여부 확인 
							   A.SEWHA_DLVY_QTY,
							   A.PDI_DEEI1_QTY,
							   A.PDI_IV_QTY,
					           A.DSID3_QTY,
							   (A.PDI_IV_QTY - A.DAY3_PLAN_QTY) AS DAY3_AFTR_IV_QTY,
					           (A.PDI_IV_QTY - A.WEK2_PLAN_QTY) AS WEK2_AFTR_IV_QTY,
							   CASE WHEN A.DSID3_QTY * 1.5 <= A.PDI_IV_QTY - A.DAY3_PLAN_QTY THEN '01'
							     WHEN A.DSID3_QTY <= A.PDI_IV_QTY - A.DAY3_PLAN_QTY THEN '02'
								 WHEN A.DSID3_QTY > A.PDI_IV_QTY - A.DAY3_PLAN_QTY AND
								      A.DAY2_PLAN_QTY <= A.PDI_IV_QTY - A.DAY3_PLAN_QTY THEN '03'
								 ELSE '04' 
							   END AS PRNT_STATE,
							   PLNT_DAY3_QTY_TEXT,
							   PLNT_WEK2_QTY_TEXT,
							   PLNT_YN
			         FROM (SELECT A.CL_SCN_CD,
			   				      A.DATA_SN,
							      A.QLTY_VEHL_CD,
							      A.MDL_MDY_CD,
							      A.LANG_CD,
							      A.DL_EXPD_REGN_CD,
							      A.QLTY_VEHL_NM,
							      A.LANG_CD_NM,
								  A.LANG_SORT_SN,
			   				      NVL(B.WEK2_PLAN_QTY, 0) AS WEK2_PLAN_QTY,
								  --CASE WHEN NVL(B.DAY3_PLAN_QTY1, 0) > NVL(B.DAY3_PLAN_QTY2, 0) THEN NVL(B.DAY3_PLAN_QTY1, 0)
     							  --     ELSE NVL(B.DAY3_PLAN_QTY2, 0)
								  --END AS DAY3_PLAN_QTY,
								  NVL(B.DAY3_PLAN_QTY1, 0) AS DAY3_PLAN_QTY,
							      NVL(B.CURR_MTH_TRWI_QTY, 0) AS CURR_MTH_TRWI_QTY,
							      NVL(B.PREV_1DAY_TRWI_QTY, 0) AS PREV_1DAY_TRWI_QTY,
							      NVL(C.SEWHA_IV_QTY, 0) AS SEWHA_IV_QTY,
							      NVL(C.SEWHA_PRNT_YN, 'N') AS SEWHA_PRNT_YN,
								  NVL(D.SEWHA_DLVY_QTY, 0) AS SEWHA_DLVY_QTY,
								  NVL(E.PDI_DEEI1_QTY, 0) AS PDI_DEEI1_QTY,
							      NVL(F.PDI_IV_QTY, 0) AS PDI_IV_QTY,
							      NVL(B.DSID3_QTY, 0) AS DSID3_QTY,
								  NVL(B.DAY2_PLAN_QTY, 0) AS DAY2_PLAN_QTY,
								  NVL(G.PLNT_DAY3_QTY_TEXT, ' ') AS PLNT_DAY3_QTY_TEXT,
								  NVL(G.PLNT_WEK2_QTY_TEXT, ' ') AS PLNT_WEK2_QTY_TEXT,
								  NVL(G.PLNT_YN, 'N') AS PLNT_YN
			   		       FROM T A,
						   		(SELECT A.QLTY_VEHL_CD, 
										A.MDL_MDY_CD, 
										A.LANG_CD,
										NVL(B.WEK2_PRDN_PLN_QTY, 0) + NVL(B.TDD_PRDN_QTY3, 0) AS WEK2_PLAN_QTY,
							      		NVL(B.TDD_PRDN_PLN_QTY, 0) + NVL(B.TDD_PRDN_QTY3, 0) AS DAY3_PLAN_QTY1,
										--NVL(B.TDD_PRDN_QTY, 0) AS DAY3_PLAN_QTY2,																		  		
								  		NVL(B.TMM_TRWI_QTY, 0) AS CURR_MTH_TRWI_QTY,
								  		NVL(B.BOD_TRWI_QTY, 0) AS PREV_1DAY_TRWI_QTY,
										CASE WHEN A.LANG_CD = 'EU' THEN NVL(B.TDD_PRDN_PLN_QTY, 0) + NVL(B.TDD_PRDN_QTY2, 0)
										     ELSE NVL(B.TDD_PRDN_PLN_QTY2, 0) + NVL(B.TDD_PRDN_QTY2, 0)
									    END AS DSID3_QTY,
										NVL(B.TDD_PRDN_PLN_QTY3, 0) + NVL(B.TDD_PRDN_QTY2, 0) AS DAY2_PLAN_QTY																														
								 FROM T A,
						         	  TB_APS_PROD_SUM_INFO B
						         WHERE A.DATA_SN = B.DATA_SN
						   		 AND B.APL_YMD = P_CURR_YMD
								) B,
        				        --세화재고
        				        (SELECT A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD, SUM(B.SFTY_IV_QTY) AS SEWHA_IV_QTY,
						                --인쇄중 데이터 존재 여부 확인 ==> DL_EXPD_TMP_IV_QTY 값은 인쇄중 이전인 경우에는 NULL, 인쇄중인경우에는 인쇄 수량, 납품이후에는 0으로 설정되어 있음 
						  		        CASE WHEN SUM(B.DL_EXPD_TMP_IV_QTY) > 0 THEN 'Y' ELSE 'N'END AS SEWHA_PRNT_YN
         				         FROM T A,
              		   		          TB_SEWHA_IV_INFO_DTL B
         				         WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
         				         AND A.MDL_MDY_CD = B.MDL_MDY_CD
         				         AND A.LANG_CD = B.LANG_CD
         				         AND B.CLS_YMD = P_CURR_YMD
								 AND B.SFTY_IV_QTY > 0 --안전재고수량이 없는 것은 가져오지 않는다. 
						         GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD
								 
								 
                                ) C,
								--배송중 데이터 조회
								(SELECT A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD, SUM(B.RQ_QTY) AS SEWHA_DLVY_QTY
								 FROM T A,
									  TB_SEWHA_WHOT_INFO B
								 WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
         				         AND A.MDL_MDY_CD = B.MDL_MDY_CD
								 AND A.LANG_CD = B.LANG_CD
								 AND B.WHSN_YMD > P_CURR_YMD
								 AND B.WHOT_YMD <= P_CURR_YMD
								 AND B.DEL_YN = 'N'
								 GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD 
								 
								 
								) D,
								--입고확인 데이터 조회 
								(SELECT A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD,
										SUM(B.DEEI1_QTY) AS PDI_DEEI1_QTY
								 FROM T A,
									  TB_PDI_WHSN_INFO B
								 WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
         				         AND A.MDL_MDY_CD = B.MDL_MDY_CD
								 AND A.LANG_CD = B.LANG_CD
								 AND B.WHSN_YMD = P_CURR_YMD
								 GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD 
								 
								 
								) E,
                                --PDI재고
                                (SELECT A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD, SUM(B.SFTY_IV_QTY) AS PDI_IV_QTY
                                 FROM T A,
                                      TB_PDI_IV_INFO_DTL B
                                 WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
                                 AND A.MDL_MDY_CD = B.MDL_MDY_CD
                               	 AND A.LANG_CD = B.LANG_CD
                                 AND B.CLS_YMD = P_CURR_YMD
								 AND B.SFTY_IV_QTY > 0 --안전재고수량이 없는 것은 가져오지 않는다. 
						         GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD 
								 
								 
                                ) F,
								(SELECT A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD,
										PG_TOT_IV_INFO.FU_GET_PLNT_DAY3_PLAN_QTY(P_CURR_YMD, A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD) AS PLNT_DAY3_QTY_TEXT,
										PG_TOT_IV_INFO.FU_GET_PLNT_WEK2_PLAN_QTY(P_CURR_YMD, A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD) AS PLNT_WEK2_QTY_TEXT,
										'Y' AS PLNT_YN
                                 FROM T A,
                                      TB_PLNT_APS_PROD_SUM_INFO B
                                 WHERE A.DATA_SN = B.DATA_SN
                                 AND B.APL_YMD = P_CURR_YMD
						         GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD
								) G
                           WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD(+)
                           AND A.MDL_MDY_CD = B.MDL_MDY_CD(+)
                           AND A.LANG_CD = B.LANG_CD(+)
                           AND A.QLTY_VEHL_CD = C.QLTY_VEHL_CD(+)
                           AND A.MDL_MDY_CD = C.MDL_MDY_CD(+)
                           AND A.LANG_CD = C.LANG_CD(+)
                           AND A.QLTY_VEHL_CD = D.QLTY_VEHL_CD(+)
                           AND A.MDL_MDY_CD = D.MDL_MDY_CD(+)
                           AND A.LANG_CD = D.LANG_CD(+)
                           AND A.QLTY_VEHL_CD = E.QLTY_VEHL_CD(+)
                           AND A.MDL_MDY_CD = E.MDL_MDY_CD(+)
                           AND A.LANG_CD = E.LANG_CD(+)
                           AND A.QLTY_VEHL_CD = F.QLTY_VEHL_CD(+)
                           AND A.MDL_MDY_CD = F.MDL_MDY_CD(+)
                           AND A.LANG_CD = F.LANG_CD(+)
                           AND A.QLTY_VEHL_CD = G.QLTY_VEHL_CD(+)
						   AND A.MDL_MDY_CD = G.MDL_MDY_CD(+)
						   AND A.LANG_CD = G.LANG_CD(+)
						   
					 	   /****  속도 개선을 위한 쿼리 변경 
					 	   SELECT A.CL_SCN_CD,
			   				      A.DATA_SN,
							      A.QLTY_VEHL_CD,
							      A.MDL_MDY_CD,
							      A.LANG_CD,
							      A.DL_EXPD_REGN_CD,
							      A.QLTY_VEHL_NM,
							      A.LANG_CD_NM,
			   				      NVL(B.WEK2_PLAN_QTY, 0) AS WEK2_PLAN_QTY,
							      NVL(C.DAY3_PLAN_QTY, 0) AS DAY3_PLAN_QTY,
							      NVL(D.CURR_MTH_TRWI_QTY, 0) AS CURR_MTH_TRWI_QTY,
							      NVL(E.PREV_1DAY_TRWI_QTY, 0) AS PREV_1DAY_TRWI_QTY,
							      NVL(F.SEWHA_IV_QTY, 0) AS SEWHA_IV_QTY,
							      NVL(F.SEWHA_PRNT_YN, 'N') AS SEWHA_PRNT_YN,
								  NVL(G.SEWHA_DLVY_QTY, 0) AS SEWHA_DLVY_QTY,
								  NVL(H.PDI_DEEI1_QTY, 0) AS PDI_DEEI1_QTY,
							      NVL(I.PDI_IV_QTY, 0) AS PDI_IV_QTY,
							      NVL(J.DSID3_QTY, 0) AS DSID3_QTY
			   		       FROM T A,
                                --생산계획(2주)
                                (SELECT A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD, SUM(PRDN_PLN_QTY) AS WEK2_PLAN_QTY
                                 FROM T A,
                                      TB_APS_PROD_PLAN_SUM_INFO B
                                 WHERE A.DATA_SN = B.DATA_SN
      				             AND B.APL_STRT_YMD <= P_CURR_YMD
                                 AND B.APL_FNH_YMD >= P_CURR_YMD
      				             AND B.PLN_PARR_YMD BETWEEN P_CURR_YMD AND V_NEXT_2WEK_YMD
      				             GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD
                                ) B,
                                --단기계획(3일)
                                (SELECT A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD, SUM(NVL(B.PRDN_PLN_QTY, 0) + NVL(C.PRDN_QTY, 0)) AS DAY3_PLAN_QTY
                                 FROM T A,
                                      TB_APS_PROD_PLAN_SUM_INFO B,
                                      TB_PROD_MST_SUM_INFO C
                                 WHERE A.DATA_SN = B.DATA_SN(+)
                                 AND A.DATA_SN = C.DATA_SN(+)
                                 AND B.APL_STRT_YMD(+) <= P_CURR_YMD
                                 AND B.APL_FNH_YMD(+) >= P_CURR_YMD
                                 AND B.PLN_PARR_YMD(+) = P_CURR_YMD
                                 AND C.APL_YMD(+) = P_CURR_YMD
                                 GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD
                                ) C,
        				        --당월투입
        				        (SELECT A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD, SUM(PRDN_TRWI_QTY) AS CURR_MTH_TRWI_QTY
         				         FROM T A,
              		                  TB_PROD_MST_SUM_INFO B
         				         WHERE A.DATA_SN = B.DATA_SN
      				             AND B.APL_YMD BETWEEN V_CURR_FSTD_YMD AND P_CURR_YMD
      				             GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD
        				        ) D,
      				            --전일투입
      				            (SELECT A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD, SUM(PRDN_TRWI_QTY) AS PREV_1DAY_TRWI_QTY
         				         FROM T A,
              		                  TB_PROD_MST_SUM_INFO B
         				         WHERE A.DATA_SN = B.DATA_SN
      				             AND B.APL_YMD = V_PREV_1DAY_YMD
      				             GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD
        				        ) E,
        				        --세화재고
        				        (SELECT A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD, SUM(IV_QTY) AS SEWHA_IV_QTY,
						                --인쇄중 데이터 존재 여부 확인 ==> DL_EXPD_TMP_IV_QTY 값은 인쇄중 이전인 경우에는 NULL, 인쇄중인경우에는 인쇄 수량, 납품이후에는 0으로 설정되어 있음 
						  		        CASE WHEN SUM(DL_EXPD_TMP_IV_QTY) > 0 THEN 'Y' ELSE 'N'END AS SEWHA_PRNT_YN
         				         FROM T A,
              		   		          TB_DL_EXPD_MDY_MGMT B,
              				          TB_SEWHA_IV_INFO C
         				         WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
         				         AND A.MDL_MDY_CD = B.MDL_MDY_CD 
								 AND A.DL_EXPD_REGN_CD = B.DL_EXPD_REGN_CD 
         				         AND A.QLTY_VEHL_CD = C.QLTY_VEHL_CD
         				         AND B.DL_EXPD_MDL_MDY_CD = C.DL_EXPD_MDL_MDY_CD
         				         AND A.LANG_CD = C.LANG_CD
         				         AND C.CLS_YMD = P_CURR_YMD
						         GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD
                                ) F,
								--배송중 데이터 조회
								(SELECT A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD, SUM(RQ_QTY) AS SEWHA_DLVY_QTY
								 FROM T A,
								      TB_DL_EXPD_MDY_MGMT B,
									  TB_SEWHA_WHOT_INFO C
								 WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
         				         AND A.MDL_MDY_CD = B.MDL_MDY_CD 
								 AND A.DL_EXPD_REGN_CD = B.DL_EXPD_REGN_CD 
         				         AND A.QLTY_VEHL_CD = C.QLTY_VEHL_CD
         				         AND B.DL_EXPD_MDL_MDY_CD = C.DL_EXPD_MDL_MDY_CD
								 AND C.WHSN_YMD > P_CURR_YMD
								 GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD
								) G,
								--입고확인 데이터 조회 
								(SELECT A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD,
										SUM(DEEI1_QTY) AS PDI_DEEI1_QTY
								 FROM T A,
								      TB_DL_EXPD_MDY_MGMT B,
									  TB_PDI_WHSN_INFO C
								 WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
         				         AND A.MDL_MDY_CD = B.MDL_MDY_CD 
								 AND A.DL_EXPD_REGN_CD = B.DL_EXPD_REGN_CD 
         				         AND A.QLTY_VEHL_CD = C.QLTY_VEHL_CD
         				         AND B.DL_EXPD_MDL_MDY_CD = C.DL_EXPD_MDL_MDY_CD
								 AND C.WHSN_YMD = P_CURR_YMD
								 GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD
								) H,
                                --PDI재고
                                (SELECT A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD, SUM(IV_QTY) AS PDI_IV_QTY
                                 FROM T A,
                                      TB_DL_EXPD_MDY_MGMT B,
                                      TB_PDI_IV_INFO C
                                 WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
                                 AND A.MDL_MDY_CD = B.MDL_MDY_CD 
								 AND A.DL_EXPD_REGN_CD = B.DL_EXPD_REGN_CD 
                                 AND A.QLTY_VEHL_CD = C.QLTY_VEHL_CD
                                 AND B.DL_EXPD_MDL_MDY_CD = C.DL_EXPD_MDL_MDY_CD
                                 AND A.LANG_CD = C.LANG_CD
                                 AND C.CLS_YMD = P_CURR_YMD
						         GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD
                                ) I,
						        --안전재고 조회
						        (SELECT A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD,
						                CASE WHEN B.DSID31_QTY IS NULL THEN (SELECT NVL(ROUND((SUM(PRDN_TRWI_QTY) / 365 + 1.96 + STDDEV(PRDN_TRWI_QTY)) * 3), 0)
								  	   					  	 	  	          FROM TB_PROD_MST_SUM_INFO C
																	          WHERE C.DATA_SN = A.DATA_SN
																	          AND C.APL_YMD BETWEEN V_PREV_YEAR_YMD AND V_PREV_1MTH_YMD)
								             ELSE B.DSID31_QTY END AS DSID3_QTY
						         FROM T A,
						   		      TB_SFTY_IV_MGMT B
						         WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD(+)
                                 AND A.MDL_MDY_CD = B.MDL_MDY_CD(+)
                                 AND A.QLTY_VEHL_CD = B.QLTY_VEHL_CD(+)
						        ) J
                           WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD(+)
                           AND A.MDL_MDY_CD = B.MDL_MDY_CD(+)
                           AND A.LANG_CD = B.LANG_CD(+)
                           AND A.QLTY_VEHL_CD = C.QLTY_VEHL_CD(+)
                           AND A.MDL_MDY_CD = C.MDL_MDY_CD(+)
                           AND A.LANG_CD = C.LANG_CD(+)
                           AND A.QLTY_VEHL_CD = D.QLTY_VEHL_CD(+)
                           AND A.MDL_MDY_CD = D.MDL_MDY_CD(+)
                           AND A.LANG_CD = D.LANG_CD(+)
                           AND A.QLTY_VEHL_CD = E.QLTY_VEHL_CD(+)
                           AND A.MDL_MDY_CD = E.MDL_MDY_CD(+)
                           AND A.LANG_CD = E.LANG_CD(+)
                           AND A.QLTY_VEHL_CD = F.QLTY_VEHL_CD(+)
                           AND A.MDL_MDY_CD = F.MDL_MDY_CD(+)
                           AND A.LANG_CD = F.LANG_CD(+)
                           AND A.QLTY_VEHL_CD = G.QLTY_VEHL_CD(+)
                           AND A.MDL_MDY_CD = G.MDL_MDY_CD(+)
                           AND A.LANG_CD = G.LANG_CD(+)
                           AND A.QLTY_VEHL_CD = H.QLTY_VEHL_CD(+)
                           AND A.MDL_MDY_CD = H.MDL_MDY_CD(+)
                           AND A.LANG_CD = H.LANG_CD(+)
						   AND A.QLTY_VEHL_CD = I.QLTY_VEHL_CD(+)
                           AND A.MDL_MDY_CD = I.MDL_MDY_CD(+)
                           AND A.LANG_CD = I.LANG_CD(+)
						   AND A.QLTY_VEHL_CD = J.QLTY_VEHL_CD(+)
                           AND A.MDL_MDY_CD = J.MDL_MDY_CD(+)
                           AND A.LANG_CD = J.LANG_CD(+)
						   ****/
						   
			             ) A,
				         TB_CODE_MGMT B
			         WHERE A.DL_EXPD_REGN_CD = B.DL_EXPD_PRVS_CD
			         AND B.DL_EXPD_G_CD = '0008'
			         AND WEK2_PLAN_QTY + DAY3_PLAN_QTY + CURR_MTH_TRWI_QTY +
			   	         PREV_1DAY_TRWI_QTY + SEWHA_IV_QTY + SEWHA_DLVY_QTY + PDI_DEEI1_QTY + PDI_IV_QTY > 0
			         --ORDER BY QLTY_VEHL_NM, B.SORT_SN, LANG_CD_NM
					 --ORDER BY QLTY_VEHL_CD, B.SORT_SN, A.LANG_SORT_SN, MDL_MDY_CD 
					 ORDER BY QLTY_VEHL_CD, A.LANG_SORT_SN, MDL_MDY_CD
					) A,
					TB_CODE_MGMT B
			    WHERE A.PRNT_STATE = B.DL_EXPD_PRVS_CD
				AND B.DL_EXPD_G_CD = '0016'
                ORDER BY
                         A.QLTY_VEHL_CD,
                         A.LANG_CD,
                         A.MDL_MDY_CD
                ;
		  
		  --배송중인 데이터 조회인 경우 		
		  ELSIF P_DLVY_STATE = '01' THEN
		  		
		  		OPEN RS FOR
			 	  WITH T AS (SELECT A.CL_SCN_CD,
			          	 		    C.DATA_SN,
			  					    C.QLTY_VEHL_CD,
                                    C.MDL_MDY_CD,
                                    C.LANG_CD,
                                    --'(' || C.QLTY_VEHL_CD || ')' || B.QLTY_VEHL_NM || '-' || C.MDL_MDY_CD || 'MY' AS QLTY_VEHL_NM,
									C.QLTY_VEHL_CD || '-' || C.MDL_MDY_CD AS QLTY_VEHL_NM,
                                    --C.LANG_CD_NM,
									CASE WHEN C.A_CODE IS NULL THEN '(' || C.LANG_CD || ')'
									     ELSE '(' || C.A_CODE || ' ' || C.LANG_CD || ')' 
								    END || C.LANG_CD_NM AS LANG_CD_NM,
                                    C.DL_EXPD_REGN_CD,
									C.SORT_SN AS LANG_SORT_SN
                             FROM (SELECT QLTY_VEHL_CD,
                                          MAX(CL_SCN_CD) AS CL_SCN_CD
                                   FROM TB_AUTH_VEHL_MGMT
                                   WHERE MENU_ID = PG_COMMON.FU_RPAD(P_MENU_ID, 10)
                                   AND USER_EENO = PG_COMMON.FU_RPAD(P_USER_EENO, 7)
                                   AND QLTY_VEHL_CD = DECODE(P_VEHL_CD, 'ALL', QLTY_VEHL_CD, P_VEHL_CD)
                                   GROUP BY QLTY_VEHL_CD
                                  ) A,
                                  TB_VEHL_MGMT B,
                                  TB_LANG_MGMT C
                             WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
                             AND A.QLTY_VEHL_CD = C.QLTY_VEHL_CD
                             AND B.MDL_MDY_CD = C.MDL_MDY_CD
                             AND B.MDL_MDY_CD BETWEEN V_FROM_MDL_MDY AND V_TO_MDL_MDY
                             AND B.MDL_MDY_CD = DECODE(P_MDL_MDY , '', B.MDL_MDY_CD, P_MDL_MDY)
						     AND B.DL_EXPD_PAC_SCN_CD = DECODE(P_PAC_SCN_CD, 'ALL', B.DL_EXPD_PAC_SCN_CD, P_PAC_SCN_CD)
                             AND B.DL_EXPD_PDI_CD = DECODE(P_PDI_CD, 'ALL', B.DL_EXPD_PDI_CD, P_PDI_CD)
						     AND C.DL_EXPD_REGN_CD = DECODE(P_REGN_CD, 'ALL', C.DL_EXPD_REGN_CD, P_REGN_CD)
							 AND C.LANG_CD <> 'KO'
                             AND C.LANG_CD = DECODE(P_LANG_CD, 'ALL', C.LANG_CD, P_LANG_CD)
							 AND B.USE_YN = 'Y'
							 AND C.USE_YN = 'Y'
                            )
			      SELECT A.CL_SCN_CD,
			   		     A.DATA_SN,
					     A.QLTY_VEHL_CD,
					     A.MDL_MDY_CD,
					     A.LANG_CD,
					     A.DL_EXPD_REGN_CD,
					     A.QLTY_VEHL_NM,
					     A.LANG_CD_NM,
					     A.DL_EXPD_REGN_NM,
					     A.WEK2_PLAN_QTY,
					     A.DAY3_PLAN_QTY,
					     A.CURR_MTH_TRWI_QTY,
					     A.PREV_1DAY_TRWI_QTY,
					     A.SEWHA_IV_QTY,
					     A.SEWHA_PRNT_YN, --세화 인쇄중 데이터 존재여부 확인 
					     A.SEWHA_DLVY_QTY,
					     A.PDI_DEEI1_QTY,
						 A.PDI_IV_QTY,
					     A.DSID3_QTY,
						 A.DAY3_AFTR_IV_QTY,
						 A.WEK2_AFTR_IV_QTY,
						 A.PRNT_STATE,
						 B.DL_EXPD_PRVS_NM AS PRNT_STATE_NM,
						 PLNT_DAY3_QTY_TEXT,
						 PLNT_WEK2_QTY_TEXT,
						 PLNT_YN
			      FROM (SELECT A.CL_SCN_CD,
			   		           A.DATA_SN,
					           A.QLTY_VEHL_CD,
					           A.MDL_MDY_CD,
					           A.LANG_CD,
					           A.DL_EXPD_REGN_CD,
					           A.QLTY_VEHL_NM,
					           A.LANG_CD_NM,
					           B.DL_EXPD_PRVS_NM AS DL_EXPD_REGN_NM,
					           A.WEK2_PLAN_QTY,
					           A.DAY3_PLAN_QTY,
					           A.CURR_MTH_TRWI_QTY,
					           A.PREV_1DAY_TRWI_QTY,
					           A.SEWHA_IV_QTY,
					           A.SEWHA_PRNT_YN, --세화 인쇄중 데이터 존재여부 확인 
							   A.SEWHA_DLVY_QTY,
							   0 AS PDI_DEEI1_QTY,
							   A.PDI_IV_QTY,
					           A.DSID3_QTY,
							   (A.PDI_IV_QTY - A.DAY3_PLAN_QTY) AS DAY3_AFTR_IV_QTY,
					           (A.PDI_IV_QTY - A.WEK2_PLAN_QTY) AS WEK2_AFTR_IV_QTY,
							   CASE WHEN A.DSID3_QTY * 1.5 <= A.PDI_IV_QTY - A.DAY3_PLAN_QTY THEN '01'
							        WHEN A.DSID3_QTY <= A.PDI_IV_QTY - A.DAY3_PLAN_QTY THEN '02'
								    WHEN A.DSID3_QTY > A.PDI_IV_QTY - A.DAY3_PLAN_QTY AND
								         A.DAY2_PLAN_QTY <= A.PDI_IV_QTY - A.DAY3_PLAN_QTY THEN '03'
								    ELSE '04' 
							   END AS PRNT_STATE,
							   PLNT_DAY3_QTY_TEXT,
							   PLNT_WEK2_QTY_TEXT,
							   PLNT_YN
			         FROM (SELECT A.CL_SCN_CD,
			   				      A.DATA_SN,
							      A.QLTY_VEHL_CD,
							      A.MDL_MDY_CD,
							      A.LANG_CD,
							      A.DL_EXPD_REGN_CD,
							      A.QLTY_VEHL_NM,
							      A.LANG_CD_NM,
								  A.LANG_SORT_SN,
			   				      NVL(B.WEK2_PLAN_QTY, 0) AS WEK2_PLAN_QTY,
								  --CASE WHEN NVL(B.DAY3_PLAN_QTY1, 0) > NVL(B.DAY3_PLAN_QTY2, 0) THEN NVL(B.DAY3_PLAN_QTY1, 0)
     							  --     ELSE NVL(B.DAY3_PLAN_QTY2, 0)
								  --END AS DAY3_PLAN_QTY,
								  NVL(B.DAY3_PLAN_QTY1, 0) AS DAY3_PLAN_QTY,
							      NVL(B.CURR_MTH_TRWI_QTY, 0) AS CURR_MTH_TRWI_QTY,
							      NVL(B.PREV_1DAY_TRWI_QTY, 0) AS PREV_1DAY_TRWI_QTY,
							      NVL(C.SEWHA_IV_QTY, 0) AS SEWHA_IV_QTY,
							      NVL(C.SEWHA_PRNT_YN, 'N') AS SEWHA_PRNT_YN,
								  NVL(D.SEWHA_DLVY_QTY, 0) AS SEWHA_DLVY_QTY,
							      NVL(E.PDI_IV_QTY, 0) AS PDI_IV_QTY,
							      NVL(B.DSID3_QTY, 0) AS DSID3_QTY,
								  NVL(B.DAY2_PLAN_QTY, 0) AS DAY2_PLAN_QTY,
								  NVL(F.PLNT_DAY3_QTY_TEXT, ' ') AS PLNT_DAY3_QTY_TEXT,
								  NVL(F.PLNT_WEK2_QTY_TEXT, ' ') AS PLNT_WEK2_QTY_TEXT,
								  NVL(F.PLNT_YN, 'N') AS PLNT_YN
			   		       FROM T A,
						        (SELECT A.QLTY_VEHL_CD, 
										A.MDL_MDY_CD, 
										A.LANG_CD,
										NVL(B.WEK2_PRDN_PLN_QTY, 0) + NVL(B.TDD_PRDN_QTY3, 0) AS WEK2_PLAN_QTY,
										NVL(B.TDD_PRDN_PLN_QTY, 0) + NVL(B.TDD_PRDN_QTY3, 0) AS DAY3_PLAN_QTY1,
										--NVL(B.TDD_PRDN_QTY, 0) AS DAY3_PLAN_QTY2,
								  		NVL(B.TMM_TRWI_QTY, 0) AS CURR_MTH_TRWI_QTY,
								  		NVL(B.BOD_TRWI_QTY, 0) AS PREV_1DAY_TRWI_QTY,
										CASE WHEN A.LANG_CD = 'EU' THEN NVL(B.TDD_PRDN_PLN_QTY, 0) + NVL(B.TDD_PRDN_QTY2, 0)
										     ELSE NVL(B.TDD_PRDN_PLN_QTY2, 0) + NVL(B.TDD_PRDN_QTY2, 0)
									    END AS DSID3_QTY,
										NVL(B.TDD_PRDN_PLN_QTY3, 0) + NVL(B.TDD_PRDN_QTY2, 0) AS DAY2_PLAN_QTY
								 FROM T A,
						         	  TB_APS_PROD_SUM_INFO B
						         WHERE A.DATA_SN = B.DATA_SN
						   		 AND B.APL_YMD = P_CURR_YMD
								) B,
        				        --세화재고
        				        (SELECT A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD, SUM(B.SFTY_IV_QTY) AS SEWHA_IV_QTY,
						                --인쇄중 데이터 존재 여부 확인 ==> DL_EXPD_TMP_IV_QTY 값은 인쇄중 이전인 경우에는 NULL, 인쇄중인경우에는 인쇄 수량, 납품이후에는 0으로 설정되어 있음 
						  		        CASE WHEN SUM(B.DL_EXPD_TMP_IV_QTY) > 0 THEN 'Y' ELSE 'N'END AS SEWHA_PRNT_YN
         				         FROM T A,
              				          TB_SEWHA_IV_INFO_DTL B
         				         WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
         				         AND A.MDL_MDY_CD = B.MDL_MDY_CD
         				         AND A.LANG_CD = B.LANG_CD
         				         AND B.CLS_YMD = P_CURR_YMD
								 AND B.SFTY_IV_QTY > 0 --안전재고수량이 없는 것은 가져오지 않는다. 
						         GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD 
								 
								 /***
								 SELECT A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD, SUM(IV_QTY) AS SEWHA_IV_QTY,
						                --인쇄중 데이터 존재 여부 확인 ==> DL_EXPD_TMP_IV_QTY 값은 인쇄중 이전인 경우에는 NULL, 인쇄중인경우에는 인쇄 수량, 납품이후에는 0으로 설정되어 있음 
						  		        CASE WHEN SUM(DL_EXPD_TMP_IV_QTY) > 0 THEN 'Y' ELSE 'N'END AS SEWHA_PRNT_YN
         				         FROM T A,
              		   		          TB_DL_EXPD_MDY_MGMT B,
              				          TB_SEWHA_IV_INFO C
         				         WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
         				         AND A.MDL_MDY_CD = B.MDL_MDY_CD 
								 AND A.DL_EXPD_REGN_CD = B.DL_EXPD_REGN_CD 
         				         AND A.QLTY_VEHL_CD = C.QLTY_VEHL_CD
         				         AND B.DL_EXPD_MDL_MDY_CD = C.DL_EXPD_MDL_MDY_CD
         				         AND A.LANG_CD = C.LANG_CD
         				         AND C.CLS_YMD = P_CURR_YMD
						         GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD 
								 ***/ 
								 
                                ) C,
								--배송중 데이터 조회
								(SELECT A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD, SUM(B.RQ_QTY) AS SEWHA_DLVY_QTY
								 FROM T A,
									  TB_SEWHA_WHOT_INFO B
								 WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
         				         AND A.MDL_MDY_CD = B.MDL_MDY_CD
								 AND A.LANG_CD = B.LANG_CD
								 AND B.WHSN_YMD > P_CURR_YMD
								 AND B.WHOT_YMD <= P_CURR_YMD
								 AND B.DEL_YN = 'N'
								 GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD
								 
								 
								) D,
                                --PDI재고
                                (SELECT A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD, SUM(B.SFTY_IV_QTY) AS PDI_IV_QTY
                                 FROM T A,
                                      TB_PDI_IV_INFO_DTL B
                                 WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
                                 AND A.MDL_MDY_CD = B.MDL_MDY_CD
                                 AND A.LANG_CD = B.LANG_CD
                                 AND B.CLS_YMD = P_CURR_YMD
								 AND B.SFTY_IV_QTY > 0 --안전재고수량이 없는 것은 가져오지 않는다. 
						         GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD
								
								 
                                ) E,
								(SELECT A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD,
										PG_TOT_IV_INFO.FU_GET_PLNT_DAY3_PLAN_QTY(P_CURR_YMD, A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD) AS PLNT_DAY3_QTY_TEXT,
										PG_TOT_IV_INFO.FU_GET_PLNT_WEK2_PLAN_QTY(P_CURR_YMD, A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD) AS PLNT_WEK2_QTY_TEXT,
										'Y' AS PLNT_YN
                                 FROM T A,
                                      TB_PLNT_APS_PROD_SUM_INFO B
                                 WHERE A.DATA_SN = B.DATA_SN
                                 AND B.APL_YMD = P_CURR_YMD
						         GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD
								) F 
                           WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD(+)
                           AND A.MDL_MDY_CD = B.MDL_MDY_CD(+)
                           AND A.LANG_CD = B.LANG_CD(+)
                           AND A.QLTY_VEHL_CD = C.QLTY_VEHL_CD(+)
                           AND A.MDL_MDY_CD = C.MDL_MDY_CD(+)
                           AND A.LANG_CD = C.LANG_CD(+)
						   --배송중인 데이터만을 표시해 주기 위해서 OUTER JOIN을 빼준다..
                           AND A.QLTY_VEHL_CD = D.QLTY_VEHL_CD
                           AND A.MDL_MDY_CD = D.MDL_MDY_CD
                           AND A.LANG_CD = D.LANG_CD
                           AND A.QLTY_VEHL_CD = E.QLTY_VEHL_CD(+)
                           AND A.MDL_MDY_CD = E.MDL_MDY_CD(+)
                           AND A.LANG_CD = E.LANG_CD(+)
                           AND A.QLTY_VEHL_CD = F.QLTY_VEHL_CD(+)
						   AND A.MDL_MDY_CD = F.MDL_MDY_CD(+)
						   AND A.LANG_CD = F.LANG_CD(+)
						   
						   /****  속도 개선을 위한 쿼리 변경 
					 	   SELECT A.CL_SCN_CD,
			   				      A.DATA_SN,
							      A.QLTY_VEHL_CD,
							      A.MDL_MDY_CD,
							      A.LANG_CD,
							      A.DL_EXPD_REGN_CD,
							      A.QLTY_VEHL_NM,
							      A.LANG_CD_NM,
			   				      NVL(B.WEK2_PLAN_QTY, 0) AS WEK2_PLAN_QTY,
							      NVL(C.DAY3_PLAN_QTY, 0) AS DAY3_PLAN_QTY,
							      NVL(D.CURR_MTH_TRWI_QTY, 0) AS CURR_MTH_TRWI_QTY,
							      NVL(E.PREV_1DAY_TRWI_QTY, 0) AS PREV_1DAY_TRWI_QTY,
							      NVL(F.SEWHA_IV_QTY, 0) AS SEWHA_IV_QTY,
							      NVL(F.SEWHA_PRNT_YN, 'N') AS SEWHA_PRNT_YN,
								  NVL(G.SEWHA_DLVY_QTY, 0) AS SEWHA_DLVY_QTY,
							      NVL(H.PDI_IV_QTY, 0) AS PDI_IV_QTY,
							      NVL(I.DSID3_QTY, 0) AS DSID3_QTY
			   		       FROM T A,
                                --생산계획(2주)
                                (SELECT A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD, SUM(PRDN_PLN_QTY) AS WEK2_PLAN_QTY
                                 FROM T A,
                                      TB_APS_PROD_PLAN_SUM_INFO B
                                 WHERE A.DATA_SN = B.DATA_SN
      				             AND B.APL_STRT_YMD <= P_CURR_YMD
                                 AND B.APL_FNH_YMD >= P_CURR_YMD
      				             AND B.PLN_PARR_YMD BETWEEN P_CURR_YMD AND V_NEXT_2WEK_YMD
      				             GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD
                                ) B,
                                --단기계획(3일)
                                (SELECT A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD, SUM(NVL(B.PRDN_PLN_QTY, 0) + NVL(C.PRDN_QTY, 0)) AS DAY3_PLAN_QTY
                                 FROM T A,
                                      TB_APS_PROD_PLAN_SUM_INFO B,
                                      TB_PROD_MST_SUM_INFO C
                                 WHERE A.DATA_SN = B.DATA_SN(+)
                                 AND A.DATA_SN = C.DATA_SN(+)
                                 AND B.APL_STRT_YMD(+) <= P_CURR_YMD
                                 AND B.APL_FNH_YMD(+) >= P_CURR_YMD
                                 AND B.PLN_PARR_YMD(+) = P_CURR_YMD
                                 AND C.APL_YMD(+) = P_CURR_YMD
                                 GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD
                                ) C,
        				        --당월투입
        				        (SELECT A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD, SUM(PRDN_TRWI_QTY) AS CURR_MTH_TRWI_QTY
         				         FROM T A,
              		                  TB_PROD_MST_SUM_INFO B
         				         WHERE A.DATA_SN = B.DATA_SN
      				             AND B.APL_YMD BETWEEN V_CURR_FSTD_YMD AND P_CURR_YMD
      				             GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD
        				        ) D,
      				            --전일투입
      				            (SELECT A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD, SUM(PRDN_TRWI_QTY) AS PREV_1DAY_TRWI_QTY
         				         FROM T A,
              		                  TB_PROD_MST_SUM_INFO B
         				         WHERE A.DATA_SN = B.DATA_SN
      				             AND B.APL_YMD = V_PREV_1DAY_YMD
      				             GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD
        				        ) E,
        				        --세화재고
        				        (SELECT A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD, SUM(IV_QTY) AS SEWHA_IV_QTY,
						                --인쇄중 데이터 존재 여부 확인 ==> DL_EXPD_TMP_IV_QTY 값은 인쇄중 이전인 경우에는 NULL, 인쇄중인경우에는 인쇄 수량, 납품이후에는 0으로 설정되어 있음 
						  		        CASE WHEN SUM(DL_EXPD_TMP_IV_QTY) > 0 THEN 'Y' ELSE 'N'END AS SEWHA_PRNT_YN
         				         FROM T A,
              		   		          TB_DL_EXPD_MDY_MGMT B,
              				          TB_SEWHA_IV_INFO C
         				         WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
         				         AND A.MDL_MDY_CD = B.MDL_MDY_CD 
								 AND A.DL_EXPD_REGN_CD = B.DL_EXPD_REGN_CD 
         				         AND A.QLTY_VEHL_CD = C.QLTY_VEHL_CD
         				         AND B.DL_EXPD_MDL_MDY_CD = C.DL_EXPD_MDL_MDY_CD
         				         AND A.LANG_CD = C.LANG_CD
         				         AND C.CLS_YMD = P_CURR_YMD
						         GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD
                                ) F,
								--배송중 데이터 조회
								(SELECT A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD, SUM(RQ_QTY) AS SEWHA_DLVY_QTY
								 FROM T A,
								      TB_DL_EXPD_MDY_MGMT B,
									  TB_SEWHA_WHOT_INFO C
								 WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
         				         AND A.MDL_MDY_CD = B.MDL_MDY_CD 
								 AND A.DL_EXPD_REGN_CD = B.DL_EXPD_REGN_CD 
         				         AND A.QLTY_VEHL_CD = C.QLTY_VEHL_CD
         				         AND B.DL_EXPD_MDL_MDY_CD = C.DL_EXPD_MDL_MDY_CD
								 AND C.WHSN_YMD > P_CURR_YMD
								 GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD
								) G,
                                --PDI재고
                                (SELECT A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD, SUM(IV_QTY) AS PDI_IV_QTY
                                 FROM T A,
                                      TB_DL_EXPD_MDY_MGMT B,
                                      TB_PDI_IV_INFO C
                                 WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
                                 AND A.MDL_MDY_CD = B.MDL_MDY_CD 
								 AND A.DL_EXPD_REGN_CD = B.DL_EXPD_REGN_CD 
                                 AND A.QLTY_VEHL_CD = C.QLTY_VEHL_CD
                                 AND B.DL_EXPD_MDL_MDY_CD = C.DL_EXPD_MDL_MDY_CD
                                 AND A.LANG_CD = C.LANG_CD
                                 AND C.CLS_YMD = P_CURR_YMD
						         GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD
                                ) H,
						        --안전재고 조회
						        (SELECT A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD,
						                CASE WHEN B.DSID31_QTY IS NULL THEN (SELECT NVL(ROUND((SUM(PRDN_TRWI_QTY) / 365 + 1.96 + STDDEV(PRDN_TRWI_QTY)) * 3), 0)
								  	   					  	 	  	          FROM TB_PROD_MST_SUM_INFO C
																	          WHERE C.DATA_SN = A.DATA_SN
																	          AND C.APL_YMD BETWEEN V_PREV_YEAR_YMD AND V_PREV_1MTH_YMD)
								             ELSE B.DSID31_QTY END AS DSID3_QTY
						         FROM T A,
						   		      TB_SFTY_IV_MGMT B
						         WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD(+)
                                 AND A.MDL_MDY_CD = B.MDL_MDY_CD(+)
                                 AND A.QLTY_VEHL_CD = B.QLTY_VEHL_CD(+)
						        ) I
                           WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD(+)
                           AND A.MDL_MDY_CD = B.MDL_MDY_CD(+)
                           AND A.LANG_CD = B.LANG_CD(+)
                           AND A.QLTY_VEHL_CD = C.QLTY_VEHL_CD(+)
                           AND A.MDL_MDY_CD = C.MDL_MDY_CD(+)
                           AND A.LANG_CD = C.LANG_CD(+)
                           AND A.QLTY_VEHL_CD = D.QLTY_VEHL_CD(+)
                           AND A.MDL_MDY_CD = D.MDL_MDY_CD(+)
                           AND A.LANG_CD = D.LANG_CD(+)
                           AND A.QLTY_VEHL_CD = E.QLTY_VEHL_CD(+)
                           AND A.MDL_MDY_CD = E.MDL_MDY_CD(+)
                           AND A.LANG_CD = E.LANG_CD(+)
                           AND A.QLTY_VEHL_CD = F.QLTY_VEHL_CD(+)
                           AND A.MDL_MDY_CD = F.MDL_MDY_CD(+)
                           AND A.LANG_CD = F.LANG_CD(+)
                           AND A.QLTY_VEHL_CD = G.QLTY_VEHL_CD(+)
                           AND A.MDL_MDY_CD = G.MDL_MDY_CD(+)
                           AND A.LANG_CD = G.LANG_CD(+)
                           AND A.QLTY_VEHL_CD = H.QLTY_VEHL_CD(+)
                           AND A.MDL_MDY_CD = H.MDL_MDY_CD(+)
                           AND A.LANG_CD = H.LANG_CD(+)
						   AND A.QLTY_VEHL_CD = I.QLTY_VEHL_CD(+)
                           AND A.MDL_MDY_CD = I.MDL_MDY_CD(+)
                           AND A.LANG_CD = I.LANG_CD(+)
						   ****/
						   
			             ) A,
				         TB_CODE_MGMT B
			         WHERE A.DL_EXPD_REGN_CD = B.DL_EXPD_PRVS_CD
			         AND B.DL_EXPD_G_CD = '0008'
			         AND WEK2_PLAN_QTY + DAY3_PLAN_QTY + CURR_MTH_TRWI_QTY +
			   	         PREV_1DAY_TRWI_QTY + SEWHA_IV_QTY + SEWHA_DLVY_QTY + PDI_IV_QTY > 0
			         --ORDER BY QLTY_VEHL_NM, B.SORT_SN, LANG_CD_NM
					 --ORDER BY QLTY_VEHL_CD, B.SORT_SN, A.LANG_SORT_SN, MDL_MDY_CD
					 ORDER BY QLTY_VEHL_CD, A.LANG_SORT_SN, MDL_MDY_CD
					) A,
					TB_CODE_MGMT B
			    WHERE A.PRNT_STATE = B.DL_EXPD_PRVS_CD
				AND B.DL_EXPD_G_CD = '0016'
                ORDER BY
                         A.QLTY_VEHL_CD,
                         A.LANG_CD,
                         A.MDL_MDY_CD
                ;
		  
		  ELSE
		  	  
			  --배송완료된 데이터 조회인 경우
			  	
		  	  OPEN RS FOR
			 	  WITH T AS (SELECT A.CL_SCN_CD,
			          	 		    C.DATA_SN,
			  					    C.QLTY_VEHL_CD,
                                    C.MDL_MDY_CD,
                                    C.LANG_CD,
                                    --'(' || C.QLTY_VEHL_CD || ')' || B.QLTY_VEHL_NM || '-' || C.MDL_MDY_CD || 'MY' AS QLTY_VEHL_NM,
									C.QLTY_VEHL_CD || '-' || C.MDL_MDY_CD AS QLTY_VEHL_NM,
                                    --C.LANG_CD_NM,
									CASE WHEN C.A_CODE IS NULL THEN '(' || C.LANG_CD || ')'
									     ELSE '(' || C.A_CODE || ' ' || C.LANG_CD || ')' 
								    END || C.LANG_CD_NM AS LANG_CD_NM,
                                    C.DL_EXPD_REGN_CD,
									C.SORT_SN AS LANG_SORT_SN
                             FROM (SELECT QLTY_VEHL_CD,
                                          MAX(CL_SCN_CD) AS CL_SCN_CD
                                   FROM TB_AUTH_VEHL_MGMT
								   WHERE MENU_ID = PG_COMMON.FU_RPAD(P_MENU_ID, 10)
                                   AND USER_EENO = PG_COMMON.FU_RPAD(P_USER_EENO, 7)
                                   AND QLTY_VEHL_CD = DECODE(P_VEHL_CD, 'ALL', QLTY_VEHL_CD, P_VEHL_CD)
                                   GROUP BY QLTY_VEHL_CD
                                  ) A,
                                  TB_VEHL_MGMT B,
                                  TB_LANG_MGMT C
                             WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
                             AND A.QLTY_VEHL_CD = C.QLTY_VEHL_CD
                             AND B.MDL_MDY_CD = C.MDL_MDY_CD
                             AND B.MDL_MDY_CD BETWEEN V_FROM_MDL_MDY AND V_TO_MDL_MDY
                             AND B.MDL_MDY_CD = DECODE(P_MDL_MDY , '', B.MDL_MDY_CD, P_MDL_MDY)
						     AND B.DL_EXPD_PAC_SCN_CD = DECODE(P_PAC_SCN_CD, 'ALL', B.DL_EXPD_PAC_SCN_CD, P_PAC_SCN_CD)
                             AND B.DL_EXPD_PDI_CD = DECODE(P_PDI_CD, 'ALL', B.DL_EXPD_PDI_CD, P_PDI_CD)
						     AND C.DL_EXPD_REGN_CD = DECODE(P_REGN_CD, 'ALL', C.DL_EXPD_REGN_CD, P_REGN_CD)
							 AND C.LANG_CD <> 'KO'
                             AND C.LANG_CD = DECODE(P_LANG_CD, 'ALL', C.LANG_CD, P_LANG_CD)
							 AND B.USE_YN = 'Y'
							 AND C.USE_YN = 'Y'
                            )
			      SELECT A.CL_SCN_CD,
			   		     A.DATA_SN,
					     A.QLTY_VEHL_CD,
					     A.MDL_MDY_CD,
					     A.LANG_CD,
					     A.DL_EXPD_REGN_CD,
					     A.QLTY_VEHL_NM,
					     A.LANG_CD_NM,
					     A.DL_EXPD_REGN_NM,
					     A.WEK2_PLAN_QTY,
					     A.DAY3_PLAN_QTY,
					     A.CURR_MTH_TRWI_QTY,
					     A.PREV_1DAY_TRWI_QTY,
					     A.SEWHA_IV_QTY,
					     A.SEWHA_PRNT_YN, --세화 인쇄중 데이터 존재여부 확인 
					     A.SEWHA_DLVY_QTY,
					     A.PDI_DEEI1_QTY,
						 A.PDI_IV_QTY,
					     A.DSID3_QTY,
						 A.DAY3_AFTR_IV_QTY,
						 A.WEK2_AFTR_IV_QTY,
						 A.PRNT_STATE,
						 B.DL_EXPD_PRVS_NM AS PRNT_STATE_NM,
						 PLNT_DAY3_QTY_TEXT,
						 PLNT_WEK2_QTY_TEXT,
						 PLNT_YN
			      FROM (SELECT A.CL_SCN_CD,
			   		           A.DATA_SN,
					           A.QLTY_VEHL_CD,
					           A.MDL_MDY_CD,
					           A.LANG_CD,
					           A.DL_EXPD_REGN_CD,
					           A.QLTY_VEHL_NM,
					           A.LANG_CD_NM,
					           B.DL_EXPD_PRVS_NM AS DL_EXPD_REGN_NM,
					           A.WEK2_PLAN_QTY,
					           A.DAY3_PLAN_QTY,
					           A.CURR_MTH_TRWI_QTY,
					           A.PREV_1DAY_TRWI_QTY,
					           A.SEWHA_IV_QTY,
					           A.SEWHA_PRNT_YN, --세화 인쇄중 데이터 존재여부 확인 
							   0 AS SEWHA_DLVY_QTY,
							   A.PDI_DEEI1_QTY,
							   A.PDI_IV_QTY,
					           A.DSID3_QTY,
							   (A.PDI_IV_QTY - A.DAY3_PLAN_QTY) AS DAY3_AFTR_IV_QTY,
					           (A.PDI_IV_QTY - A.WEK2_PLAN_QTY) AS WEK2_AFTR_IV_QTY,
							   CASE WHEN A.DSID3_QTY * 1.5 <= A.PDI_IV_QTY - A.DAY3_PLAN_QTY THEN '01'
							        WHEN A.DSID3_QTY <= A.PDI_IV_QTY - A.DAY3_PLAN_QTY THEN '02'
								    WHEN A.DSID3_QTY > A.PDI_IV_QTY - A.DAY3_PLAN_QTY AND
								         A.DAY2_PLAN_QTY <= A.PDI_IV_QTY - A.DAY3_PLAN_QTY THEN '03'
								    ELSE '04' 
							   END AS PRNT_STATE,
							   PLNT_DAY3_QTY_TEXT,
							   PLNT_WEK2_QTY_TEXT,
							   PLNT_YN
			         FROM (SELECT A.CL_SCN_CD,
			   				      A.DATA_SN,
							      A.QLTY_VEHL_CD,
							      A.MDL_MDY_CD,
							      A.LANG_CD,
							      A.DL_EXPD_REGN_CD,
							      A.QLTY_VEHL_NM,
							      A.LANG_CD_NM,
								  A.LANG_SORT_SN,
			   				      NVL(B.WEK2_PLAN_QTY, 0) AS WEK2_PLAN_QTY,
							      --CASE WHEN NVL(B.DAY3_PLAN_QTY1, 0) > NVL(B.DAY3_PLAN_QTY2, 0) THEN NVL(B.DAY3_PLAN_QTY1, 0)
     							  --     ELSE NVL(B.DAY3_PLAN_QTY2, 0)
								  --END AS DAY3_PLAN_QTY,
								  NVL(B.DAY3_PLAN_QTY1, 0) AS DAY3_PLAN_QTY,
							      NVL(B.CURR_MTH_TRWI_QTY, 0) AS CURR_MTH_TRWI_QTY,
							      NVL(B.PREV_1DAY_TRWI_QTY, 0) AS PREV_1DAY_TRWI_QTY,
							      NVL(C.SEWHA_IV_QTY, 0) AS SEWHA_IV_QTY,
							      NVL(C.SEWHA_PRNT_YN, 'N') AS SEWHA_PRNT_YN,
								  NVL(D.PDI_DEEI1_QTY, 0) AS PDI_DEEI1_QTY,
							      NVL(E.PDI_IV_QTY, 0) AS PDI_IV_QTY,
							      NVL(B.DSID3_QTY, 0) AS DSID3_QTY,
								  NVL(B.DAY2_PLAN_QTY, 0) AS DAY2_PLAN_QTY,
								  NVL(F.PLNT_DAY3_QTY_TEXT, ' ') AS PLNT_DAY3_QTY_TEXT,
								  NVL(F.PLNT_WEK2_QTY_TEXT, ' ') AS PLNT_WEK2_QTY_TEXT,
								  NVL(F.PLNT_YN, 'N') AS PLNT_YN
			   		       FROM T A,
						   		(SELECT A.QLTY_VEHL_CD, 
										A.MDL_MDY_CD, 
										A.LANG_CD,
										NVL(B.WEK2_PRDN_PLN_QTY, 0) + NVL(B.TDD_PRDN_QTY3, 0) AS WEK2_PLAN_QTY,
								  		NVL(B.TDD_PRDN_PLN_QTY, 0) + NVL(B.TDD_PRDN_QTY3, 0) AS DAY3_PLAN_QTY1,
										--NVL(B.TDD_PRDN_QTY, 0) AS DAY3_PLAN_QTY2,
								  		NVL(B.TMM_TRWI_QTY, 0) AS CURR_MTH_TRWI_QTY,
								  		NVL(B.BOD_TRWI_QTY, 0) AS PREV_1DAY_TRWI_QTY,
										CASE WHEN A.LANG_CD = 'EU' THEN NVL(B.TDD_PRDN_PLN_QTY, 0) + NVL(B.TDD_PRDN_QTY2, 0)
										     ELSE NVL(B.TDD_PRDN_PLN_QTY2, 0) + NVL(B.TDD_PRDN_QTY2, 0)
									    END AS DSID3_QTY,
										NVL(B.TDD_PRDN_PLN_QTY3, 0) + NVL(B.TDD_PRDN_QTY2, 0) AS DAY2_PLAN_QTY 
								 FROM T A,
						         	  TB_APS_PROD_SUM_INFO B
						         WHERE A.DATA_SN = B.DATA_SN
						   		 AND B.APL_YMD = P_CURR_YMD
								) B,
        				        --세화재고
        				        (SELECT A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD, SUM(B.SFTY_IV_QTY) AS SEWHA_IV_QTY,
						                --인쇄중 데이터 존재 여부 확인 ==> DL_EXPD_TMP_IV_QTY 값은 인쇄중 이전인 경우에는 NULL, 인쇄중인경우에는 인쇄 수량, 납품이후에는 0으로 설정되어 있음 
						  		        CASE WHEN SUM(B.DL_EXPD_TMP_IV_QTY) > 0 THEN 'Y' ELSE 'N'END AS SEWHA_PRNT_YN
         				         FROM T A,
              				          TB_SEWHA_IV_INFO_DTL B
         				         WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
         				         AND A.MDL_MDY_CD = B.MDL_MDY_CD
         				         AND A.LANG_CD = B.LANG_CD
         				         AND B.CLS_YMD = P_CURR_YMD
								 AND B.SFTY_IV_QTY > 0 --안전재고수량이 없는 것은 가져오지 않는다. 
						         GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD
								
								 
                                ) C,
								--입고확인 데이터 조회 
								(SELECT A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD, 
										SUM(B.DEEI1_QTY) AS PDI_DEEI1_QTY
								 FROM T A,
									  TB_PDI_WHSN_INFO B
								 WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
         				         AND A.MDL_MDY_CD = B.MDL_MDY_CD
								 AND A.LANG_CD = B.LANG_CD
								 AND B.WHSN_YMD = P_CURR_YMD
								 GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD
								
								 
								) D,
                                --PDI재고
                                (SELECT A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD, SUM(B.SFTY_IV_QTY) AS PDI_IV_QTY
                                 FROM T A,
                                      TB_PDI_IV_INFO_DTL B
                                 WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
                                 AND A.MDL_MDY_CD = B.MDL_MDY_CD
                                 AND A.LANG_CD = B.LANG_CD
                                 AND B.CLS_YMD = P_CURR_YMD
								 AND B.SFTY_IV_QTY > 0 --안전재고수량이 없는 것은 가져오지 않는다. 
						         GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD
								
								 
                                ) E,
								(SELECT A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD,
										PG_TOT_IV_INFO.FU_GET_PLNT_DAY3_PLAN_QTY(P_CURR_YMD, A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD) AS PLNT_DAY3_QTY_TEXT,
										PG_TOT_IV_INFO.FU_GET_PLNT_WEK2_PLAN_QTY(P_CURR_YMD, A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD) AS PLNT_WEK2_QTY_TEXT,
										'Y' AS PLNT_YN
                                 FROM T A,
                                      TB_PLNT_APS_PROD_SUM_INFO B
                                 WHERE A.DATA_SN = B.DATA_SN
                                 AND B.APL_YMD = P_CURR_YMD
						         GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD
								) F
                           WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD(+)
                           AND A.MDL_MDY_CD = B.MDL_MDY_CD(+)
                           AND A.LANG_CD = B.LANG_CD(+)
                           AND A.QLTY_VEHL_CD = C.QLTY_VEHL_CD(+)
                           AND A.MDL_MDY_CD = C.MDL_MDY_CD(+)
                           AND A.LANG_CD = C.LANG_CD(+)
						   --입고확인된 데이터만을 표시해 주기 위해서 OUTER JOIN을 빼준다..
                           AND A.QLTY_VEHL_CD = D.QLTY_VEHL_CD
                           AND A.MDL_MDY_CD = D.MDL_MDY_CD
                           AND A.LANG_CD = D.LANG_CD
                           AND A.QLTY_VEHL_CD = E.QLTY_VEHL_CD(+)
                           AND A.MDL_MDY_CD = E.MDL_MDY_CD(+)
                           AND A.LANG_CD = E.LANG_CD(+)
                           AND A.QLTY_VEHL_CD = F.QLTY_VEHL_CD(+)
						   AND A.MDL_MDY_CD = F.MDL_MDY_CD(+)
						   AND A.LANG_CD = F.LANG_CD(+)
						   
						   /****  속도 개선을 위한 쿼리 변경 
					 	   SELECT A.CL_SCN_CD,
			   				      A.DATA_SN,
							      A.QLTY_VEHL_CD,
							      A.MDL_MDY_CD,
							      A.LANG_CD,
							      A.DL_EXPD_REGN_CD,
							      A.QLTY_VEHL_NM,
							      A.LANG_CD_NM,
			   				      NVL(B.WEK2_PLAN_QTY, 0) AS WEK2_PLAN_QTY,
							      NVL(C.DAY3_PLAN_QTY, 0) AS DAY3_PLAN_QTY,
							      NVL(D.CURR_MTH_TRWI_QTY, 0) AS CURR_MTH_TRWI_QTY,
							      NVL(E.PREV_1DAY_TRWI_QTY, 0) AS PREV_1DAY_TRWI_QTY,
							      NVL(F.SEWHA_IV_QTY, 0) AS SEWHA_IV_QTY,
							      NVL(F.SEWHA_PRNT_YN, 'N') AS SEWHA_PRNT_YN,
								  NVL(G.PDI_DEEI1_QTY, 0) AS PDI_DEEI1_QTY,
							      NVL(H.PDI_IV_QTY, 0) AS PDI_IV_QTY,
							      NVL(I.DSID3_QTY, 0) AS DSID3_QTY
			   		       FROM T A,
                                --생산계획(2주)
                                (SELECT A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD, SUM(PRDN_PLN_QTY) AS WEK2_PLAN_QTY
                                 FROM T A,
                                      TB_APS_PROD_PLAN_SUM_INFO B
                                 WHERE A.DATA_SN = B.DATA_SN
      				             AND B.APL_STRT_YMD <= P_CURR_YMD
                                 AND B.APL_FNH_YMD >= P_CURR_YMD
      				             AND B.PLN_PARR_YMD BETWEEN P_CURR_YMD AND V_NEXT_2WEK_YMD
      				             GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD
                                ) B,
                                --단기계획(3일)
                                (SELECT A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD, SUM(NVL(B.PRDN_PLN_QTY, 0) + NVL(C.PRDN_QTY, 0)) AS DAY3_PLAN_QTY
                                 FROM T A,
                                      TB_APS_PROD_PLAN_SUM_INFO B,
                                      TB_PROD_MST_SUM_INFO C
                                 WHERE A.DATA_SN = B.DATA_SN(+)
                                 AND A.DATA_SN = C.DATA_SN(+)
                                 AND B.APL_STRT_YMD(+) <= P_CURR_YMD
                                 AND B.APL_FNH_YMD(+) >= P_CURR_YMD
                                 AND B.PLN_PARR_YMD(+) = P_CURR_YMD
                                 AND C.APL_YMD(+) = P_CURR_YMD
                                 GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD
                                ) C,
        				        --당월투입
        				        (SELECT A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD, SUM(PRDN_TRWI_QTY) AS CURR_MTH_TRWI_QTY
         				         FROM T A,
              		                  TB_PROD_MST_SUM_INFO B
         				         WHERE A.DATA_SN = B.DATA_SN
      				             AND B.APL_YMD BETWEEN V_CURR_FSTD_YMD AND P_CURR_YMD
      				             GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD
        				        ) D,
      				            --전일투입
      				            (SELECT A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD, SUM(PRDN_TRWI_QTY) AS PREV_1DAY_TRWI_QTY
         				         FROM T A,
              		                  TB_PROD_MST_SUM_INFO B
         				         WHERE A.DATA_SN = B.DATA_SN
      				             AND B.APL_YMD = V_PREV_1DAY_YMD
      				             GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD
        				        ) E,
        				        --세화재고
        				        (SELECT A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD, SUM(IV_QTY) AS SEWHA_IV_QTY,
						                --인쇄중 데이터 존재 여부 확인 ==> DL_EXPD_TMP_IV_QTY 값은 인쇄중 이전인 경우에는 NULL, 인쇄중인경우에는 인쇄 수량, 납품이후에는 0으로 설정되어 있음 
						  		        CASE WHEN SUM(DL_EXPD_TMP_IV_QTY) > 0 THEN 'Y' ELSE 'N'END AS SEWHA_PRNT_YN
         				         FROM T A,
              		   		          TB_DL_EXPD_MDY_MGMT B,
              				          TB_SEWHA_IV_INFO C
         				         WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
         				         AND A.MDL_MDY_CD = B.MDL_MDY_CD 
								 AND A.DL_EXPD_REGN_CD = B.DL_EXPD_REGN_CD 
         				         AND A.QLTY_VEHL_CD = C.QLTY_VEHL_CD
         				         AND B.DL_EXPD_MDL_MDY_CD = C.DL_EXPD_MDL_MDY_CD
         				         AND A.LANG_CD = C.LANG_CD
         				         AND C.CLS_YMD = P_CURR_YMD
						         GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD
                                ) F,
								--입고확인 데이터 조회 
								(SELECT A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD, 
										SUM(DEEI1_QTY) AS PDI_DEEI1_QTY
								 FROM T A,
								      TB_DL_EXPD_MDY_MGMT B,
									  TB_PDI_WHSN_INFO C
								 WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
         				         AND A.MDL_MDY_CD = B.MDL_MDY_CD 
								 AND A.DL_EXPD_REGN_CD = B.DL_EXPD_REGN_CD 
         				         AND A.QLTY_VEHL_CD = C.QLTY_VEHL_CD
         				         AND B.DL_EXPD_MDL_MDY_CD = C.DL_EXPD_MDL_MDY_CD
								 AND C.WHSN_YMD = P_CURR_YMD
								 GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD
								) G,
                                --PDI재고
                                (SELECT A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD, SUM(IV_QTY) AS PDI_IV_QTY
                                 FROM T A,
                                      TB_DL_EXPD_MDY_MGMT B,
                                      TB_PDI_IV_INFO C
                                 WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
                                 AND A.MDL_MDY_CD = B.MDL_MDY_CD 
								 AND A.DL_EXPD_REGN_CD = B.DL_EXPD_REGN_CD 
                                 AND A.QLTY_VEHL_CD = C.QLTY_VEHL_CD
                                 AND B.DL_EXPD_MDL_MDY_CD = C.DL_EXPD_MDL_MDY_CD
                                 AND A.LANG_CD = C.LANG_CD
                                 AND C.CLS_YMD = P_CURR_YMD
						         GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD
                                ) H,
						        --안전재고 조회
						        (SELECT A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD,
						                CASE WHEN B.DSID31_QTY IS NULL THEN (SELECT NVL(ROUND((SUM(PRDN_TRWI_QTY) / 365 + 1.96 + STDDEV(PRDN_TRWI_QTY)) * 3), 0)
								  	   					  	 	  	          FROM TB_PROD_MST_SUM_INFO C
																	          WHERE C.DATA_SN = A.DATA_SN
																	          AND C.APL_YMD BETWEEN V_PREV_YEAR_YMD AND V_PREV_1MTH_YMD)
								             ELSE B.DSID31_QTY END AS DSID3_QTY
						         FROM T A,
						   		      TB_SFTY_IV_MGMT B
						         WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD(+)
                                 AND A.MDL_MDY_CD = B.MDL_MDY_CD(+)
                                 AND A.QLTY_VEHL_CD = B.QLTY_VEHL_CD(+)
						        ) I
                           WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD(+)
                           AND A.MDL_MDY_CD = B.MDL_MDY_CD(+)
                           AND A.LANG_CD = B.LANG_CD(+)
                           AND A.QLTY_VEHL_CD = C.QLTY_VEHL_CD(+)
                           AND A.MDL_MDY_CD = C.MDL_MDY_CD(+)
                           AND A.LANG_CD = C.LANG_CD(+)
                           AND A.QLTY_VEHL_CD = D.QLTY_VEHL_CD(+)
                           AND A.MDL_MDY_CD = D.MDL_MDY_CD(+)
                           AND A.LANG_CD = D.LANG_CD(+)
                           AND A.QLTY_VEHL_CD = E.QLTY_VEHL_CD(+)
                           AND A.MDL_MDY_CD = E.MDL_MDY_CD(+)
                           AND A.LANG_CD = E.LANG_CD(+)
                           AND A.QLTY_VEHL_CD = F.QLTY_VEHL_CD(+)
                           AND A.MDL_MDY_CD = F.MDL_MDY_CD(+)
                           AND A.LANG_CD = F.LANG_CD(+)
                           AND A.QLTY_VEHL_CD = G.QLTY_VEHL_CD(+)
                           AND A.MDL_MDY_CD = G.MDL_MDY_CD(+)
                           AND A.LANG_CD = G.LANG_CD(+)
                           AND A.QLTY_VEHL_CD = H.QLTY_VEHL_CD(+)
                           AND A.MDL_MDY_CD = H.MDL_MDY_CD(+)
                           AND A.LANG_CD = H.LANG_CD(+)
						   AND A.QLTY_VEHL_CD = I.QLTY_VEHL_CD(+)
                           AND A.MDL_MDY_CD = I.MDL_MDY_CD(+)
                           AND A.LANG_CD = I.LANG_CD(+)
						   ****/
						   
			             ) A,
				         TB_CODE_MGMT B
			         WHERE A.DL_EXPD_REGN_CD = B.DL_EXPD_PRVS_CD
			         AND B.DL_EXPD_G_CD = '0008'
			         AND WEK2_PLAN_QTY + DAY3_PLAN_QTY + CURR_MTH_TRWI_QTY +
			   	         PREV_1DAY_TRWI_QTY + SEWHA_IV_QTY + PDI_DEEI1_QTY + PDI_IV_QTY > 0
			         --ORDER BY QLTY_VEHL_NM, B.SORT_SN, LANG_CD_NM
					 --ORDER BY QLTY_VEHL_CD, B.SORT_SN, A.LANG_SORT_SN, MDL_MDY_CD
					 ORDER BY QLTY_VEHL_CD, A.LANG_SORT_SN, MDL_MDY_CD
					) A,
					TB_CODE_MGMT B
			    WHERE A.PRNT_STATE = B.DL_EXPD_PRVS_CD
				AND B.DL_EXPD_G_CD = '0016'
                ORDER BY
                         A.QLTY_VEHL_CD,
                         A.LANG_CD,
                         A.MDL_MDY_CD
                ;
		  
		  END IF;
		  
	   END SP_GET_PDI_IV_INFO2;
	   
	   --입고확인 데이터 조회 
	   PROCEDURE SP_GET_PDI_WHSN_INFO(P_MENU_ID    VARCHAR2,
								      P_USER_EENO  VARCHAR2,
								      P_FROM_YMD   VARCHAR2,
								      P_TO_YMD     VARCHAR2,
								      P_PDI_CD	   VARCHAR2,
								      P_VEHL_CD	   VARCHAR2,
								      P_MDL_MDY	   VARCHAR2,
								      P_REGN_CD	   VARCHAR2,
								      P_LANG_CD	   VARCHAR2,
									  P_USF_CD	   VARCHAR2,  -- D: 내수만, E: 수출만 조회,
									  --P_FROM_NUM NUMBER,
							 		  --P_TO_NUM   NUMBER,
									  --P_CNT     OUT NUMBER,
								      RS 		OUT REFCUR)
       IS
	   	  
		  --V_CURR_YMD VARCHAR2(8);
		  
		  V_FROM_MDL_MDY VARCHAR2(2);
		  V_TO_MDL_MDY   VARCHAR2(2);
		  
		  --V_END_NUM      NUMBER;
		  
	   BEGIN
	   		
			--V_CURR_YMD := TO_CHAR(SYSDATE, 'YYYYMMDD');
			
			PG_COMMON.SP_GET_VALID_MDL_MDY4(P_FROM_YMD, P_TO_YMD, V_FROM_MDL_MDY, V_TO_MDL_MDY);
			
			/***  이전버전 방식(차종연식과 취급설명서 연식 관련 JOIN 조건이 현재 방식과 차이가 있어서 사용불가)   
			WITH T AS (SELECT C.QLTY_VEHL_CD,
                              D.DL_EXPD_MDL_MDY_CD,
                              C.LANG_CD
                       FROM (SELECT QLTY_VEHL_CD
                             FROM TB_AUTH_VEHL_MGMT
                             WHERE MENU_ID = PG_COMMON.FU_RPAD(P_MENU_ID, 10)
                             AND USER_EENO = PG_COMMON.FU_RPAD(P_USER_EENO, 7)
                             AND QLTY_VEHL_CD = DECODE(P_VEHL_CD, 'ALL', QLTY_VEHL_CD, P_VEHL_CD)
                             GROUP BY QLTY_VEHL_CD
                            ) A,
                            TB_VEHL_MGMT B,
                            TB_LANG_MGMT C,
							TB_DL_EXPD_MDY_MGMT D 
                       WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
                       AND A.QLTY_VEHL_CD = C.QLTY_VEHL_CD
                       AND B.MDL_MDY_CD = C.MDL_MDY_CD
					   AND C.QLTY_VEHL_CD = D.QLTY_VEHL_CD 
					   AND C.MDL_MDY_CD = D.MDL_MDY_CD 
					   AND C.DL_EXPD_REGN_CD = D.DL_EXPD_REGN_CD  
                       AND C.MDL_MDY_CD BETWEEN V_FROM_MDL_MDY AND V_TO_MDL_MDY
                       AND C.MDL_MDY_CD = DECODE(P_MDL_MDY , '', C.MDL_MDY_CD, P_MDL_MDY)
                       AND B.DL_EXPD_PDI_CD = DECODE(P_PDI_CD, 'ALL', B.DL_EXPD_PDI_CD, P_PDI_CD)
					   AND C.DL_EXPD_REGN_CD = DECODE(P_REGN_CD, 'ALL', C.DL_EXPD_REGN_CD, P_REGN_CD)
					   AND C.LANG_CD = DECODE(P_USF_CD, 'D', 'KO', C.LANG_CD)
  				       AND C.LANG_CD <> DECODE(P_USF_CD, 'E', 'KO', 'NULL')
                       AND C.LANG_CD = DECODE(P_LANG_CD, 'ALL', C.LANG_CD, P_LANG_CD)
				      )
			SELECT COUNT(*)
			INTO P_CNT 
			FROM T A,
                 TB_SEWHA_WHOT_INFO B 
			WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
		    AND A.DL_EXPD_MDL_MDY_CD = B.DL_EXPD_MDL_MDY_CD 
			AND A.LANG_CD = B.LANG_CD
			--별도요청을 제외한 일반항목만 가져오도록 한다. 
			AND B.DL_EXPD_RQ_SCN_CD = '01' 
			AND (B.CMPL_YN = 'N' OR 
				 B.WHSN_YMD BETWEEN P_FROM_YMD AND P_TO_YMD); 
				 
			IF P_TO_NUM > P_CNT THEN
		   	  
			   V_END_NUM := P_CNT;
			  
		    ELSE
		      
			   V_END_NUM := P_TO_NUM;
			  
		    END IF;	 
			
		    ***/ 
			
			/** [페이징 처리용] 현재 사용 안함
			
			--신버전
			WITH T AS (SELECT C.QLTY_VEHL_CD,
                              C.MDL_MDY_CD,
                              C.LANG_CD
                       FROM (SELECT QLTY_VEHL_CD
                             FROM TB_AUTH_VEHL_MGMT
                             WHERE MENU_ID = PG_COMMON.FU_RPAD(P_MENU_ID, 10)
                             AND USER_EENO = PG_COMMON.FU_RPAD(P_USER_EENO, 7)
                             AND QLTY_VEHL_CD = DECODE(P_VEHL_CD, 'ALL', QLTY_VEHL_CD, P_VEHL_CD)
                             GROUP BY QLTY_VEHL_CD
                            ) A,
                            TB_VEHL_MGMT B,
                            TB_LANG_MGMT C
                       WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
                       AND A.QLTY_VEHL_CD = C.QLTY_VEHL_CD
                       AND B.MDL_MDY_CD = C.MDL_MDY_CD
					   AND C.MDL_MDY_CD BETWEEN V_FROM_MDL_MDY AND V_TO_MDL_MDY
                       AND C.MDL_MDY_CD = DECODE(P_MDL_MDY , '', C.MDL_MDY_CD, P_MDL_MDY)
                       AND B.DL_EXPD_PDI_CD = DECODE(P_PDI_CD, 'ALL', B.DL_EXPD_PDI_CD, P_PDI_CD)
					   AND C.DL_EXPD_REGN_CD = DECODE(P_REGN_CD, 'ALL', C.DL_EXPD_REGN_CD, P_REGN_CD)
					   AND C.LANG_CD = DECODE(P_USF_CD, 'D', 'KO', C.LANG_CD)
  				       AND C.LANG_CD <> DECODE(P_USF_CD, 'E', 'KO', 'NULL')
                       AND C.LANG_CD = DECODE(P_LANG_CD, 'ALL', C.LANG_CD, P_LANG_CD)
				      )
			SELECT COUNT(*)
			INTO P_CNT 
			FROM T A,
                 TB_SEWHA_WHOT_INFO B 
			WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
		    AND A.MDL_MDY_CD = B.MDL_MDY_CD
			AND A.LANG_CD = B.LANG_CD 
			AND B.DEL_YN = 'N' 
			--별도요청을 제외한 일반항목만 가져오도록 한다. 
			AND B.DL_EXPD_RQ_SCN_CD = '01' 
			AND (B.CMPL_YN = 'N' OR 
				 B.WHSN_YMD BETWEEN P_FROM_YMD AND P_TO_YMD); 
				 
			IF P_TO_NUM > P_CNT THEN
		   	  
			   V_END_NUM := P_CNT;
			  
		    ELSE
		      
			   V_END_NUM := P_TO_NUM;
			  
		    END IF;	 
			**/
										
			/*** 이전버전 방식(차종연식과 취급설명서 연식 관련 JOIN 조건이 현재 방식과 차이가 있어서 사용불가)    
			OPEN RS FOR
				WITH T AS (SELECT A.CL_SCN_CD,
			          	 		  --C.DATA_SN,
			  					  C.QLTY_VEHL_CD,
                                  C.MDL_MDY_CD,
								  D.DL_EXPD_MDL_MDY_CD,
                                  C.LANG_CD,
                                  --'(' || C.QLTY_VEHL_CD || ')' || B.QLTY_VEHL_NM || '-' || C.MDL_MDY_CD || 'MY' AS QLTY_VEHL_NM,
								  '(' || C.QLTY_VEHL_CD || '-' || C.MDL_MDY_CD || ')' || B.QLTY_VEHL_NM AS QLTY_VEHL_NM,
                                  --'(' || C.LANG_CD || ')' || C.LANG_CD_NM AS LANG_CD_NM 
								  CASE WHEN C.A_CODE IS NULL THEN '(' || C.LANG_CD || ')'
									   ELSE '(' || C.LANG_CD || '-' || C.A_CODE || ')' 
								  END || C.LANG_CD_NM AS LANG_CD_NM,
								  C.SORT_SN AS LANG_SORT_SN
                           FROM (SELECT QLTY_VEHL_CD,
                                        MAX(CL_SCN_CD) AS CL_SCN_CD
                                 FROM TB_AUTH_VEHL_MGMT
                                 WHERE MENU_ID = PG_COMMON.FU_RPAD(P_MENU_ID, 10)
                                 AND USER_EENO = PG_COMMON.FU_RPAD(P_USER_EENO, 7)
                                 AND QLTY_VEHL_CD = DECODE(P_VEHL_CD, 'ALL', QLTY_VEHL_CD, P_VEHL_CD)
                                 GROUP BY QLTY_VEHL_CD
                                ) A,
                                TB_VEHL_MGMT B,
                                TB_LANG_MGMT C,
								TB_DL_EXPD_MDY_MGMT D
                           WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
                           AND A.QLTY_VEHL_CD = C.QLTY_VEHL_CD
                           AND B.MDL_MDY_CD = C.MDL_MDY_CD
						   AND C.QLTY_VEHL_CD = D.QLTY_VEHL_CD
						   AND C.MDL_MDY_CD = D.MDL_MDY_CD 
						   AND C.DL_EXPD_REGN_CD = D.DL_EXPD_REGN_CD 
                           AND C.MDL_MDY_CD BETWEEN V_FROM_MDL_MDY AND V_TO_MDL_MDY
                           AND C.MDL_MDY_CD = DECODE(P_MDL_MDY , '', C.MDL_MDY_CD, P_MDL_MDY)
                           AND B.DL_EXPD_PDI_CD = DECODE(P_PDI_CD, 'ALL', B.DL_EXPD_PDI_CD, P_PDI_CD)
						   AND C.DL_EXPD_REGN_CD = DECODE(P_REGN_CD, 'ALL', C.DL_EXPD_REGN_CD, P_REGN_CD)
						   AND C.LANG_CD = DECODE(P_USF_CD, 'D', 'KO', C.LANG_CD)
  				           AND C.LANG_CD <> DECODE(P_USF_CD, 'E', 'KO', 'NULL')
                           AND C.LANG_CD = DECODE(P_LANG_CD, 'ALL', C.LANG_CD, P_LANG_CD)
						   AND B.USE_YN = 'Y'
						   AND C.USE_YN = 'Y'
				          )
				 SELECT A.QLTY_VEHL_NM,
				 		A.LANG_CD_NM,
						A.N_PRNT_PBCN_NO,
						NVL(B.DL_EXPD_PRVS_NM, '') AS EXPD_WHSN_ST_NM,
						A.DL_EXPD_BOX_QTY,
						A.RQ_QTY,
						A.DEEI1_QTY,
						A.WHSN_YMD,
						NVL(C.USER_NM, '') AS CRGR_NM,
						A.QLTY_VEHL_CD,
						A.DL_EXPD_MDL_MDY_CD,
						A.LANG_CD,
						A.DTL_SN,
						A.EXPD_WHSN_ST_CD,
						A.CRGR_EENO,
						A.CL_SCN_CD,
						A.MDL_MDY_CD
				 FROM (SELECT B.QLTY_VEHL_NM,
				 	  		  B.LANG_CD_NM,
							  B.LANG_SORT_SN,
							  A.N_PRNT_PBCN_NO,
							  NVL(D.DL_EXPD_WHSN_ST_CD, '') AS EXPD_WHSN_ST_CD,
							  NVL(C.DL_EXPD_BOX_QTY, 0) AS DL_EXPD_BOX_QTY,
							  C.RQ_QTY,
							  NVL(D.DEEI1_QTY, 0) AS DEEI1_QTY,
							  NVL(TO_CHAR(TO_DATE(D.WHSN_YMD,'YYYYMMDD'),'YYYY-MM-DD'), 
							  	  DECODE(C.CMPL_YN, 'Y', TO_CHAR(TO_DATE(C.WHSN_YMD,'YYYYMMDD'),'YYYY-MM-DD'), '')) AS WHSN_YMD,
							  NVL(D.CRGR_EENO, DECODE(C.CMPL_YN, 'Y', C.PWTI_EENO, '')) AS CRGR_EENO,
							  A.QLTY_VEHL_CD,
							  A.DL_EXPD_MDL_MDY_CD,
							  A.LANG_CD,
							  A.DTL_SN,
							  --수정권한이 있는 차종이면서 또한 입고확인이 되지 않은 경우에만 수정가능하다.
							  CASE WHEN B.CL_SCN_CD = 'U' AND C.CMPL_YN = 'N' THEN 'Y' 
							       ELSE 'N' END AS CL_SCN_CD,
							  A.MDL_MDY_CD
				       FROM (SELECT QLTY_VEHL_CD,
				 	  		        DL_EXPD_MDL_MDY_CD,
							        LANG_CD,
							        N_PRNT_PBCN_NO,
							        DTL_SN,
									MDL_MDY_CD
				             FROM (SELECT A.QLTY_VEHL_CD,
				 	  		              A.DL_EXPD_MDL_MDY_CD,
							              A.LANG_CD,
							              B.N_PRNT_PBCN_NO,
							              B.DTL_SN,
							              ROWNUM AS ROWNM,
										  A.MDL_MDY_CD
				                   FROM T A,
					                    TB_SEWHA_WHOT_INFO B
					               WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
								   AND A.MDL_MDY_CD = B.MDL_MDY_CD
					               AND A.LANG_CD = B.LANG_CD
								   AND A.DL_EXPD_MDL_MDY_CD = B.DL_EXPD_MDL_MDY_CD
								   --삭제되지 않은 항목만 조회하도록 한다. 
								   AND B.DEL_YN = 'N'  
								   --별도요청을 제외한 일반항목만 가져오도록 한다. 
								   AND B.DL_EXPD_RQ_SCN_CD = '01' 
					               AND (B.CMPL_YN = 'N' OR 
					                    B.WHSN_YMD BETWEEN P_FROM_YMD AND P_TO_YMD)
							       ORDER BY CASE WHEN B.CMPL_YN = 'N' THEN 1 ELSE 2 END, B.WHSN_YMD
					              )
					         --WHERE ROWNM BETWEEN P_FROM_NUM AND V_END_NUM 
					        ) A,
					        T B,
					        TB_SEWHA_WHOT_INFO C,
					        TB_PDI_WHSN_INFO D
				      WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
					  AND A.MDL_MDY_CD = B.MDL_MDY_CD
				      AND A.DL_EXPD_MDL_MDY_CD = B.DL_EXPD_MDL_MDY_CD
				      AND A.LANG_CD = B.LANG_CD
				      AND A.QLTY_VEHL_CD = C.QLTY_VEHL_CD
					  AND A.MDL_MDY_CD = C.MDL_MDY_CD
				      AND A.DL_EXPD_MDL_MDY_CD = C.DL_EXPD_MDL_MDY_CD
				      AND A.LANG_CD = C.LANG_CD
				      AND A.N_PRNT_PBCN_NO = C.N_PRNT_PBCN_NO
				      AND A.DTL_SN = C.DTL_SN
				      AND A.QLTY_VEHL_CD = D.QLTY_VEHL_CD(+)
					  AND A.MDL_MDY_CD = D.MDL_MDY_CD(+)
				      AND A.DL_EXPD_MDL_MDY_CD = D.DL_EXPD_MDL_MDY_CD(+)
				      AND A.LANG_CD = D.LANG_CD(+)
				      AND A.N_PRNT_PBCN_NO = D.N_PRNT_PBCN_NO(+)
				      AND A.DTL_SN = D.DTL_SN(+)
					 ) A,
				     TB_CODE_MGMT B,
					 TB_USR_MGMT C
				  WHERE A.CRGR_EENO = C.USER_EENO(+)
				  AND A.EXPD_WHSN_ST_CD = B.DL_EXPD_PRVS_CD(+)
				  AND B.DL_EXPD_G_CD(+) = '0013'
				  --ORDER BY QLTY_VEHL_CD, LANG_CD, DL_EXPD_MDL_MDY_CD, N_PRNT_PBCN_NO;
				  ORDER BY QLTY_VEHL_CD, LANG_SORT_SN, MDL_MDY_CD, DL_EXPD_MDL_MDY_CD, N_PRNT_PBCN_NO, WHSN_YMD DESC;
			 ***/
			 
			 --신버전 
			 OPEN RS FOR
				WITH T AS (SELECT A.CL_SCN_CD,
			          	 		  --C.DATA_SN,
			  					  C.QLTY_VEHL_CD,
                                  C.MDL_MDY_CD,
                                  C.LANG_CD,
                                  --'(' || C.QLTY_VEHL_CD || ')' || B.QLTY_VEHL_NM || '-' || C.MDL_MDY_CD || 'MY' AS QLTY_VEHL_NM,
								  '(' || C.QLTY_VEHL_CD || '-' || C.MDL_MDY_CD || ')' || B.QLTY_VEHL_NM AS QLTY_VEHL_NM,
                                  --'(' || C.LANG_CD || ')' || C.LANG_CD_NM AS LANG_CD_NM 
								  CASE WHEN C.A_CODE IS NULL THEN '(' || C.LANG_CD || ')'
									   ELSE '(' || C.LANG_CD || '-' || C.A_CODE || ')' 
								  END || C.LANG_CD_NM AS LANG_CD_NM,
								  C.SORT_SN AS LANG_SORT_SN
                           FROM (SELECT QLTY_VEHL_CD,
                                        MAX(CL_SCN_CD) AS CL_SCN_CD
                                 FROM TB_AUTH_VEHL_MGMT
                                 WHERE MENU_ID = PG_COMMON.FU_RPAD(P_MENU_ID, 10)
                                 AND USER_EENO = PG_COMMON.FU_RPAD(P_USER_EENO, 7)
                                 AND QLTY_VEHL_CD = DECODE(P_VEHL_CD, 'ALL', QLTY_VEHL_CD, P_VEHL_CD)
                                 GROUP BY QLTY_VEHL_CD
                                ) A,
                                TB_VEHL_MGMT B,
                                TB_LANG_MGMT C
                           WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
                           AND A.QLTY_VEHL_CD = C.QLTY_VEHL_CD
                           AND B.MDL_MDY_CD = C.MDL_MDY_CD
                           AND C.MDL_MDY_CD BETWEEN V_FROM_MDL_MDY AND V_TO_MDL_MDY
                           AND C.MDL_MDY_CD = DECODE(P_MDL_MDY , '', C.MDL_MDY_CD, P_MDL_MDY)
                           AND B.DL_EXPD_PDI_CD = DECODE(P_PDI_CD, 'ALL', B.DL_EXPD_PDI_CD, P_PDI_CD)
						   AND C.DL_EXPD_REGN_CD = DECODE(P_REGN_CD, 'ALL', C.DL_EXPD_REGN_CD, P_REGN_CD)
						   AND C.LANG_CD = DECODE(P_USF_CD, 'D', 'KO', C.LANG_CD)
  				           AND C.LANG_CD <> DECODE(P_USF_CD, 'E', 'KO', 'NULL')
                           AND C.LANG_CD = DECODE(P_LANG_CD, 'ALL', C.LANG_CD, P_LANG_CD)
						   AND B.USE_YN = 'Y'
						   AND C.USE_YN = 'Y'
				          )
				 SELECT A.QLTY_VEHL_NM,
				 		A.LANG_CD_NM,
						A.N_PRNT_PBCN_NO,
						NVL(B.DL_EXPD_PRVS_NM, '') AS EXPD_WHSN_ST_NM,
						A.DL_EXPD_BOX_QTY,
						A.RQ_QTY,
						A.DEEI1_QTY,
						A.WHSN_YMD,
						NVL(C.USER_NM, '') AS CRGR_NM,
						A.QLTY_VEHL_CD,
						A.DL_EXPD_MDL_MDY_CD,
						A.LANG_CD,
						A.DTL_SN,
						A.EXPD_WHSN_ST_CD,
						A.CRGR_EENO,
						A.CL_SCN_CD,
						A.MDL_MDY_CD
				 FROM (SELECT B.QLTY_VEHL_NM,
				 	  		  B.LANG_CD_NM,
							  B.LANG_SORT_SN,
							  A.N_PRNT_PBCN_NO,
							  NVL(D.DL_EXPD_WHSN_ST_CD, '') AS EXPD_WHSN_ST_CD,
							  NVL(C.DL_EXPD_BOX_QTY, 0) AS DL_EXPD_BOX_QTY,
							  C.RQ_QTY,
							  NVL(D.DEEI1_QTY, 0) AS DEEI1_QTY,
							  NVL(TO_CHAR(TO_DATE(D.WHSN_YMD,'YYYYMMDD'),'YYYY-MM-DD'), 
							  	  DECODE(C.CMPL_YN, 'Y', TO_CHAR(TO_DATE(C.WHSN_YMD,'YYYYMMDD'),'YYYY-MM-DD'), '')) AS WHSN_YMD,
							  NVL(D.CRGR_EENO, DECODE(C.CMPL_YN, 'Y', C.PWTI_EENO, '')) AS CRGR_EENO,
							  A.QLTY_VEHL_CD,
							  A.DL_EXPD_MDL_MDY_CD,
							  A.LANG_CD,
							  A.DTL_SN,
							  --수정권한이 있는 차종이면서 또한 입고확인이 되지 않은 경우에만 수정가능하다.
							  CASE WHEN B.CL_SCN_CD = 'U' AND C.CMPL_YN = 'N' THEN 'Y' 
							       ELSE 'N' END AS CL_SCN_CD,
							  A.MDL_MDY_CD
				       FROM (SELECT QLTY_VEHL_CD,
					   				MDL_MDY_CD,
							        LANG_CD,
									DL_EXPD_MDL_MDY_CD,
							        N_PRNT_PBCN_NO,
							        DTL_SN
				             FROM (SELECT A.QLTY_VEHL_CD,
				 	  		              A.MDL_MDY_CD,
							              A.LANG_CD,
										  B.DL_EXPD_MDL_MDY_CD,
							              B.N_PRNT_PBCN_NO,
							              B.DTL_SN,
							              ROWNUM AS ROWNM
				                   FROM T A,
					                    TB_SEWHA_WHOT_INFO B
					               WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
								   AND A.MDL_MDY_CD = B.MDL_MDY_CD
					               AND A.LANG_CD = B.LANG_CD
								   --삭제되지 않은 항목만 조회하도록 한다. 
								   AND B.DEL_YN = 'N'  
								   --별도요청을 제외한 일반항목만 가져오도록 한다. 
								   AND B.DL_EXPD_RQ_SCN_CD = '01' 
					               AND (B.CMPL_YN = 'N' OR 
					                    B.WHSN_YMD BETWEEN P_FROM_YMD AND P_TO_YMD)
							       ORDER BY CASE WHEN B.CMPL_YN = 'N' THEN 1 ELSE 2 END, B.WHSN_YMD
					              )
					         --WHERE ROWNM BETWEEN P_FROM_NUM AND V_END_NUM 
					        ) A,
					        T B,
					        TB_SEWHA_WHOT_INFO C,
					        TB_PDI_WHSN_INFO D
				      WHERE A.QLTY_VEHL_CD     = B.QLTY_VEHL_CD
					  AND A.MDL_MDY_CD         = B.MDL_MDY_CD
				      AND A.LANG_CD            = B.LANG_CD
				      AND A.QLTY_VEHL_CD       = C.QLTY_VEHL_CD
					  AND A.MDL_MDY_CD         = C.MDL_MDY_CD
					  AND A.LANG_CD            = C.LANG_CD
				      AND A.DL_EXPD_MDL_MDY_CD = C.DL_EXPD_MDL_MDY_CD
				      AND A.N_PRNT_PBCN_NO     = C.N_PRNT_PBCN_NO
				      AND A.DTL_SN             = C.DTL_SN
				      AND A.QLTY_VEHL_CD       = D.QLTY_VEHL_CD(+)
					  AND A.MDL_MDY_CD         = D.MDL_MDY_CD(+)
				      AND A.LANG_CD            = D.LANG_CD(+)
					  AND A.DL_EXPD_MDL_MDY_CD = D.DL_EXPD_MDL_MDY_CD(+)
				      AND A.N_PRNT_PBCN_NO     = D.N_PRNT_PBCN_NO(+)
				      AND A.DTL_SN             = D.DTL_SN(+)
					 ) A,
				     TB_CODE_MGMT B,
					 TB_USR_MGMT C
				  WHERE A.CRGR_EENO = C.USER_EENO(+)
				  AND A.EXPD_WHSN_ST_CD = B.DL_EXPD_PRVS_CD(+)
				  AND B.DL_EXPD_G_CD(+) = '0013'
				  ORDER BY QLTY_VEHL_CD, LANG_SORT_SN, MDL_MDY_CD, N_PRNT_PBCN_NO, DL_EXPD_MDL_MDY_CD, WHSN_YMD DESC;	 
				 
	   END SP_GET_PDI_WHSN_INFO;
	   
	   --입고확인 데이터 조회2						  
   	   PROCEDURE SP_GET_PDI_WHSN_INFO2(P_MENU_ID 	  VARCHAR2,
								   	   P_USER_EENO    VARCHAR2,
			  					       P_DATA_SN_LIST VARCHAR2,
			  					       RS OUT REFCUR)
	   IS
	   	 
		 V_QUERY    VARCHAR2(8000);
		 
	   BEGIN
	   		
			V_QUERY := 'SELECT A.QLTY_VEHL_NM,' ||
	   			              'A.LANG_CD_NM,' ||
	   			              'B.N_PRNT_PBCN_NO,' ||
	   			              ''''' AS EXPD_WHSN_ST_NM,' ||
	   			             'NVL(B.DL_EXPD_BOX_QTY, 0 ) AS DL_EXPD_BOX_QTY,' ||
	   			             'B.RQ_QTY,' ||
	   			             '0 DEEI1_QTY,' ||
	   			             ''''' AS WHSN_YMD,' ||
	   			             ''''' AS CRGR_NM,' ||
	   			             'A.QLTY_VEHL_CD,' ||
	   			             'B.DL_EXPD_MDL_MDY_CD,' ||
	   			             'A.LANG_CD,' ||
	   			             'B.DTL_SN,' ||
	   			             ''''' AS EXPD_WHSN_ST_CD,' ||
	   			             ''''' AS CRGR_EENO,' ||
	   			     		 'CASE WHEN A.CL_SCN_CD = ''U'' THEN ''Y'' ' || 
				   		          'ELSE ''N'' ' || 
	   			             'END AS CL_SCN_CD,' ||
							 'A.MDL_MDY_CD, ' ||
							 'B.PRDN_PLNT_CD ' || -- 광주공장 분리
		               'FROM (SELECT MAX(B.CL_SCN_CD) AS CL_SCN_CD,' ||
	 		 	 		            'A.QLTY_VEHL_CD,' ||
	 		 			            'A.MDL_MDY_CD,' ||
			 			            'A.LANG_CD,' ||
			 			          --'''('' || A.QLTY_VEHL_CD || '')'' || MAX(D.QLTY_VEHL_NM) || ''-'' || A.MDL_MDY_CD || ''MY'' AS QLTY_VEHL_NM,' || 
								  '''('' || A.QLTY_VEHL_CD || ''-'' || A.MDL_MDY_CD || '')'' || MAX(C.QLTY_VEHL_NM) AS QLTY_VEHL_NM,' ||
			 			            --'''('' || A.LANG_CD || '')'' || MAX(A.LANG_CD_NM) AS LANG_CD_NM ' || 
									'CASE WHEN MAX(A.A_CODE) IS NULL THEN ''('' || A.LANG_CD || '')'' ' ||
									     'ELSE ''('' || A.LANG_CD || ''-'' || MAX(A.A_CODE) || '')'' ' || 
								    'END || MAX(A.LANG_CD_NM) AS LANG_CD_NM,' ||
								    'MAX(A.SORT_SN) AS LANG_SORT_SN ' ||
	  			             'FROM TB_LANG_MGMT A,' ||
	  	   		  	              'TB_AUTH_VEHL B,' ||
		   			              'TB_VEHL_MGMT C ' ||
	  			             'WHERE A.DATA_SN IN ( ' || P_DATA_SN_LIST || ') ' ||
	                         'AND A.QLTY_VEHL_CD = B.QLTY_VEHL_CD ' ||
	              			 'AND A.QLTY_VEHL_CD = C.QLTY_VEHL_CD ' ||
	              			 'AND A.MDL_MDY_CD = C.MDL_MDY_CD ' ||
	              			 'AND B.MENU_ID = PG_COMMON.FU_RPAD(''' || P_MENU_ID || ''', 10) ' ||
	              			 'AND B.USER_EENO = PG_COMMON.FU_RPAD(''' || P_USER_EENO || ''', 7) ' ||
	              			 'GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD ' ||
	                        ') A,' ||
	             			'TB_SEWHA_WHOT_INFO B ' ||
           			 'WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD ' ||
           			 'AND A.MDL_MDY_CD = B.MDL_MDY_CD ' ||
           			 'AND A.LANG_CD = B.LANG_CD ' ||
           			 'AND B.DL_EXPD_RQ_SCN_CD = ''01'' ' || --별도요청을 제외한 일반항목만 가져오도록 한다. 
           			 'AND B.CMPL_YN = ''N'' ' ||            --입고확인이 되지 않은 항목만을 가져온다.
					 'AND B.DEL_YN = ''N'' ' ||             --삭제되지 않은 항목만 조회하도록 한다. 
					 'ORDER BY A.QLTY_VEHL_CD, A.LANG_SORT_SN, A.MDL_MDY_CD, B.N_PRNT_PBCN_NO, B.DL_EXPD_MDL_MDY_CD, B.WHOT_YMD, B.PRDN_PLNT_CD ';
			
			OPEN RS FOR V_QUERY;
				 
	   END SP_GET_PDI_WHSN_INFO2;
								   
	   PROCEDURE SP_PDI_WHSN_INFO_SAVE(P_VEHL_CD         VARCHAR2,
	   			 					   P_MDL_MDY_CD	 	 VARCHAR2,
								       P_LANG_CD         VARCHAR2,
									   P_EXPD_MDL_MDY_CD VARCHAR2,
								       P_N_PRNT_PBCN_NO  VARCHAR2,
								       P_DTL_SN          NUMBER,
								       P_EXPD_WHSN_ST_CD VARCHAR2,
								       P_EXPD_BOX_QTY    NUMBER,
								       P_WHSN_QTY		 NUMBER,
								       P_DEEI1_QTY		 NUMBER,
								       P_USER_EENO		 VARCHAR2
								       , P_PRDN_PLNT_CD    VARCHAR2   -- 광주분리
								       )
	   IS
	   	 
		 V_WHSN_QTY NUMBER;
		 
		 V_CURR_YMD VARCHAR2(8);
		 
		 V_CNT		NUMBER;
		 
	   BEGIN
	   
			V_CURR_YMD := TO_CHAR(SYSDATE, 'YYYYMMDD');
			
			--입고확인된 데이터가 아닌지의 여부 확인 
			--현재 가장 최근의 세화 출고요청수량을 다시 읽어온다. 
			SELECT SUM(RQ_QTY)
			INTO V_WHSN_QTY
			FROM TB_SEWHA_WHOT_INFO
			WHERE QLTY_VEHL_CD = P_VEHL_CD
			AND MDL_MDY_CD = P_MDL_MDY_CD
			AND LANG_CD = P_LANG_CD
			AND DL_EXPD_MDL_MDY_CD = P_EXPD_MDL_MDY_CD
			AND N_PRNT_PBCN_NO = P_N_PRNT_PBCN_NO
			AND DTL_SN = P_DTL_SN
			AND CMPL_YN = 'N'
			AND DEL_YN = 'N'
			AND PRDN_PLNT_CD = P_PRDN_PLNT_CD   -- 광주분리
			;
			
			--입고확인되지 않은 데이터만을 저장하도록 한다. 
			IF V_WHSN_QTY IS NOT NULL THEN
			   
			   --입고상태가 부족인 경우 에는 입고수량에서 부족 수량을 빼준다.
			   IF P_EXPD_WHSN_ST_CD = '02' THEN
			   	  
				  --V_WHSN_QTY := V_WHSN_QTY - P_DEEI1_QTY;
				  V_WHSN_QTY := P_WHSN_QTY - NVL(P_DEEI1_QTY, 0);
			   	  
				  IF V_WHSN_QTY < 0 THEN
				  	 
					 RAISE_APPLICATION_ERROR(-20001, 'Sewon delivery quantity(include shortage qty) is more than zero ' || 
			   								    	 'date:' || TO_CHAR(TO_DATE(V_CURR_YMD, 'YYYYMMDD'), 'YYYY-MM-DD') || ',' ||
											    	 'vehl:' || P_VEHL_CD || ',' || 
											    	 'mkyr:' || P_EXPD_MDL_MDY_CD || ',' || 
											    	 'lang:' || P_LANG_CD || ',' || P_N_PRNT_PBCN_NO || ',' ||
											    	 'sn  :' || TO_CHAR(P_DTL_SN));
												
				  END IF;
				  
			   ELSE
			   	  
				  V_WHSN_QTY := P_WHSN_QTY;
				  
			   END IF;
			
			   INSERT INTO TB_PDI_WHSN_INFO
			   (QLTY_VEHL_CD,
			    DL_EXPD_MDL_MDY_CD,
				LANG_CD,
				N_PRNT_PBCN_NO,
				DTL_SN,
				WHSN_YMD,
				DL_EXPD_WHSN_ST_CD,
				WHSN_QTY,
				DEEI1_QTY,
				CRGR_EENO,
				DL_EXPD_BOX_QTY,
				PPRR_EENO,
				FRAM_DTM,
				UPDR_EENO,
				MDFY_DTM,
				MDL_MDY_CD
				,PRDN_PLNT_CD   -- 광주분리
			   )
			   VALUES
			   (P_VEHL_CD,
			    P_EXPD_MDL_MDY_CD,
				P_LANG_CD,
				P_N_PRNT_PBCN_NO,
				P_DTL_SN,
				V_CURR_YMD,
				P_EXPD_WHSN_ST_CD,
				V_WHSN_QTY,  
				DECODE(P_EXPD_WHSN_ST_CD, '01', 0, P_DEEI1_QTY),
				P_USER_EENO,
				P_EXPD_BOX_QTY,
				P_USER_EENO,
				SYSDATE,
				P_USER_EENO,
				SYSDATE,
				P_MDL_MDY_CD
				, P_PRDN_PLNT_CD    -- 광주분리
			   );
			   
			   --이미 재고등록된 항목이 존재하는지의 여부를 확인한다.
			   SELECT COUNT(*)
			   INTO V_CNT
			   FROM TB_PDI_IV_INFO
			   WHERE CLS_YMD = V_CURR_YMD
			   AND QLTY_VEHL_CD = P_VEHL_CD
			   AND DL_EXPD_MDL_MDY_CD = P_EXPD_MDL_MDY_CD
			   AND LANG_CD = P_LANG_CD
			   AND N_PRNT_PBCN_NO = P_N_PRNT_PBCN_NO
			   AND PRDN_PLNT_CD = P_PRDN_PLNT_CD    -- 광주분리
			   ;
			   
			   IF V_CNT = 0 THEN
			   	  
				  PG_DATA.SP_PDI_IV_INFO_SAVE_BY_WHSN(V_CURR_YMD,
	   			 							 		  P_VEHL_CD,
													  P_MDL_MDY_CD,
								          	 		  P_LANG_CD,
													  P_EXPD_MDL_MDY_CD,
								    	  	 		  P_N_PRNT_PBCN_NO,
								    	  	 		  P_DTL_SN,
								    	  	 		  P_EXPD_WHSN_ST_CD,
								    	  	 		  P_EXPD_BOX_QTY,
								    	  	 		  V_WHSN_QTY,
								    	  	 		  P_DEEI1_QTY,
								    	  	 		  P_USER_EENO
								    	  	 		  , P_PRDN_PLNT_CD    -- 광주분리
								    	  	 		  );
				  
			   ELSE
			   	   
				   --재고데이터 업데이트 작업 수행 
				   PG_DATA.SP_PDI_IV_INFO_UPDATE(P_VEHL_CD,
				                                 P_MDL_MDY_CD,
							                     P_LANG_CD,
												 P_EXPD_MDL_MDY_CD,
								         		 P_N_PRNT_PBCN_NO,
								         		 V_CURR_YMD,
										 		 V_WHSN_QTY * (-1),
								         		 'N',
												 'N',
								         		 P_USER_EENO
								         		 , P_PRDN_PLNT_CD    -- 광주분리
								         		 );
								  
			   END IF;
			   
			   --세화 출고내역에서 입고확인상태로 변경하는 작업 수행(세화재고에서 제외하는 작업도 같이 수행)
			   PG_SEWHA_IV_INFO.SP_SEWHA_WHOT_INFO_UPDATE(P_VEHL_CD,
			                                              P_MDL_MDY_CD,
				                                          P_LANG_CD,
														  P_EXPD_MDL_MDY_CD,
				                                          P_N_PRNT_PBCN_NO,
				                                          P_DTL_SN,
														  V_CURR_YMD,
														  V_WHSN_QTY,
														  P_USER_EENO
--														  , P_PRDN_PLNT_CD
														  );
			ELSE
				
				RAISE_APPLICATION_ERROR(-20001, 'Sewon delivery quantity is not exist ' || 
			   								    'date:' || TO_CHAR(TO_DATE(V_CURR_YMD, 'YYYYMMDD'), 'YYYY-MM-DD') || ',' ||
											    'vehl:' || P_VEHL_CD || ',' || 
											    'mkyr:' || P_EXPD_MDL_MDY_CD || ',' || 
											    'lang:' || P_LANG_CD || ',' || P_N_PRNT_PBCN_NO || ',' ||
											    'sn  :' || TO_CHAR(P_DTL_SN));
			END IF;
			
	   END SP_PDI_WHSN_INFO_SAVE;
	   
	   PROCEDURE SP_GET_PDI_REVICE_INFO(P_MENU_ID    VARCHAR2,
								        P_USER_EENO  VARCHAR2,
								        P_CURR_YMD   VARCHAR2,
								        P_PAC_SCN_CD VARCHAR2,
								        P_VEHL_CD	 VARCHAR2,
								        P_MDL_MDY	 VARCHAR2,
								        P_REGN_CD	 VARCHAR2,
								        P_LANG_CD	 VARCHAR2,
								        P_USF_CD	 VARCHAR2,  -- D: 내수만, E: 수출만 조회,
										--P_FROM_NUM NUMBER,
							 			--P_TO_NUM   NUMBER,
										--P_CNT   OUT NUMBER,
								        RS 		OUT REFCUR)
	   IS
	   	  
		  V_CURR_YMD      VARCHAR2(8);
		  
		  V_FROM_MDL_MDY VARCHAR2(2);
		  V_TO_MDL_MDY   VARCHAR2(2);
		  
		  --V_END_NUM      NUMBER;
		  
	   BEGIN
	   		
			V_CURR_YMD := TO_CHAR(SYSDATE, 'YYYYMMDD');
			
			PG_COMMON.SP_GET_VALID_MDL_MDY4(P_CURR_YMD, '', V_FROM_MDL_MDY, V_TO_MDL_MDY);
			
			/*** 이전버전 방식(차종연식과 취급설명서 연식 관련 JOIN 조건이 현재 방식과 차이가 있어서 사용불가)    
			WITH T AS (SELECT C.QLTY_VEHL_CD,
                              D.DL_EXPD_MDL_MDY_CD,
                              C.LANG_CD
                       FROM (SELECT QLTY_VEHL_CD
                             FROM TB_AUTH_VEHL_MGMT
                             WHERE MENU_ID = PG_COMMON.FU_RPAD(P_MENU_ID, 10)
                             AND USER_EENO = PG_COMMON.FU_RPAD(P_USER_EENO, 7)
                             AND QLTY_VEHL_CD = DECODE(P_VEHL_CD, 'ALL', QLTY_VEHL_CD, P_VEHL_CD)
                             GROUP BY QLTY_VEHL_CD
                            ) A,
                            TB_VEHL_MGMT B,
                            TB_LANG_MGMT C,
							TB_DL_EXPD_MDY_MGMT D 
                       WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
                       AND A.QLTY_VEHL_CD = C.QLTY_VEHL_CD
                       AND B.MDL_MDY_CD = C.MDL_MDY_CD
					   AND C.QLTY_VEHL_CD = D.QLTY_VEHL_CD
					   AND C.MDL_MDY_CD = D.MDL_MDY_CD 
					   AND C.DL_EXPD_REGN_CD = D.DL_EXPD_REGN_CD  
                       AND C.MDL_MDY_CD BETWEEN V_FROM_MDL_MDY AND V_TO_MDL_MDY
                       AND C.MDL_MDY_CD = DECODE(P_MDL_MDY , '', C.MDL_MDY_CD, P_MDL_MDY)
                       AND B.DL_EXPD_PAC_SCN_CD = DECODE(P_PAC_SCN_CD, 'ALL', B.DL_EXPD_PAC_SCN_CD, P_PAC_SCN_CD)
					   AND C.DL_EXPD_REGN_CD = DECODE(P_REGN_CD, 'ALL', C.DL_EXPD_REGN_CD, P_REGN_CD)
					   AND C.LANG_CD = DECODE(P_USF_CD, 'D', 'KO', C.LANG_CD) 
  				       AND C.LANG_CD <> DECODE(P_USF_CD, 'E', 'KO', 'NULL')
                       AND C.LANG_CD = DECODE(P_LANG_CD, 'ALL', C.LANG_CD, P_LANG_CD)
				      )
			SELECT COUNT(*)
			INTO P_CNT
		    FROM T A,
			     TB_PDI_IV_INFO B 
			WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
			AND A.DL_EXPD_MDL_MDY_CD = B.DL_EXPD_MDL_MDY_CD
			AND A.LANG_CD = B.LANG_CD
			AND CLS_YMD = P_CURR_YMD
			ORDER BY A.QLTY_VEHL_CD, A.LANG_CD;
			
			IF P_TO_NUM > P_CNT THEN
		   	  
			   V_END_NUM := P_CNT;
			  
		    ELSE
		      
			   V_END_NUM := P_TO_NUM;
			  
		    END IF;	 
			
			***/
			
			/** [페이징 처리용] 현재 사용 안함
			
			--신버전 
			WITH T AS (SELECT C.QLTY_VEHL_CD,
				   	  		  C.MDL_MDY_CD,
                              C.LANG_CD
                       FROM (SELECT QLTY_VEHL_CD
                             FROM TB_AUTH_VEHL_MGMT
                             WHERE MENU_ID = PG_COMMON.FU_RPAD(P_MENU_ID, 10)
                             AND USER_EENO = PG_COMMON.FU_RPAD(P_USER_EENO, 7)
                             AND QLTY_VEHL_CD = DECODE(P_VEHL_CD, 'ALL', QLTY_VEHL_CD, P_VEHL_CD)
                             GROUP BY QLTY_VEHL_CD
                            ) A,
                            TB_VEHL_MGMT B,
                            TB_LANG_MGMT C
                       WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
                       AND A.QLTY_VEHL_CD = C.QLTY_VEHL_CD
                       AND B.MDL_MDY_CD = C.MDL_MDY_CD
					   AND C.MDL_MDY_CD BETWEEN V_FROM_MDL_MDY AND V_TO_MDL_MDY
                       AND C.MDL_MDY_CD = DECODE(P_MDL_MDY , '', C.MDL_MDY_CD, P_MDL_MDY)
                       AND B.DL_EXPD_PAC_SCN_CD = DECODE(P_PAC_SCN_CD, 'ALL', B.DL_EXPD_PAC_SCN_CD, P_PAC_SCN_CD)
					   AND C.DL_EXPD_REGN_CD = DECODE(P_REGN_CD, 'ALL', C.DL_EXPD_REGN_CD, P_REGN_CD)
					   AND C.LANG_CD = DECODE(P_USF_CD, 'D', 'KO', C.LANG_CD) 
  				       AND C.LANG_CD <> DECODE(P_USF_CD, 'E', 'KO', 'NULL')
                       AND C.LANG_CD = DECODE(P_LANG_CD, 'ALL', C.LANG_CD, P_LANG_CD)
				      )
			SELECT COUNT(*)
			INTO P_CNT
		    FROM T A,
			     TB_PDI_IV_INFO_DTL B,
				 TB_PDI_WHOT_INFO C 
			WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
			AND A.MDL_MDY_CD     = B.MDL_MDY_CD
			AND A.LANG_CD        = B.LANG_CD
			AND B.CLS_YMD = P_CURR_YMD
			AND A.QLTY_VEHL_CD   = C.QLTY_VEHL_CD(+)
			AND A.MDL_MDY_CD     = C.MDL_MDY_CD(+)
		    AND A.LANG_CD        = C.LANG_CD(+)
		    AND B.DL_EXPD_MDL_MDY_CD = C.DL_EXPD_MDL_MDY_CD(+)
			AND B.N_PRNT_PBCN_NO     = C.N_PRNT_PBCN_NO(+)
			AND B.CLS_YMD            = C.WHOT_YMD(+)
			AND C.DL_EXPD_WHOT_ST_CD(+) <> '01' --배치작업에서 출고되는 항목은 제외한다.
			AND C.DEL_YN(+) = 'N'
			--ORDER BY A.QLTY_VEHL_CD, A.LANG_CD 
			;
			
			IF P_TO_NUM > P_CNT THEN
		   	  
			   V_END_NUM := P_CNT;
			  
		    ELSE
		      
			   V_END_NUM := P_TO_NUM;
			  
		    END IF;	 
			**/ 
			
			
			/*** 이전버전 방식(차종연식과 취급설명서 연식 관련 JOIN 조건이 현재 방식과 차이가 있어서 사용불가)    
			
			OPEN RS FOR
				WITH T AS (SELECT A.CL_SCN_CD,
			          	 		  C.DATA_SN, B.DL_EXPD_CO_CD,
			  					  C.QLTY_VEHL_CD,
                                  C.MDL_MDY_CD,
								  D.DL_EXPD_MDL_MDY_CD,
                                  C.LANG_CD,
                                  '(' || C.QLTY_VEHL_CD || '-' || C.MDL_MDY_CD || ')' || B.QLTY_VEHL_NM AS QLTY_VEHL_NM,
								  C.MDL_MDY_CD || 'MY' AS MDL_MDY_NM,
                                  --'(' || C.LANG_CD || ')' || C.LANG_CD_NM AS LANG_CD_NM 
								  CASE WHEN C.A_CODE IS NULL THEN '(' || C.LANG_CD || ')'
				   				  	   ELSE '(' || C.LANG_CD || '-' || C.A_CODE || ')' 
			  					  END || C.LANG_CD_NM AS LANG_CD_NM,
								  C.SORT_SN AS LANG_SORT_SN
                           FROM (SELECT QLTY_VEHL_CD,
                                        MAX(CL_SCN_CD) AS CL_SCN_CD
                                 FROM TB_AUTH_VEHL_MGMT
                                 WHERE MENU_ID = PG_COMMON.FU_RPAD(P_MENU_ID, 10)
                                 AND USER_EENO = PG_COMMON.FU_RPAD(P_USER_EENO, 7)
                                 AND QLTY_VEHL_CD = DECODE(P_VEHL_CD, 'ALL', QLTY_VEHL_CD, P_VEHL_CD)
                                 GROUP BY QLTY_VEHL_CD 
                                ) A,
                                TB_VEHL_MGMT B,
                                TB_LANG_MGMT C,
								TB_DL_EXPD_MDY_MGMT D 
                           WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD 
                           AND A.QLTY_VEHL_CD = C.QLTY_VEHL_CD 
                           AND B.MDL_MDY_CD = C.MDL_MDY_CD 
						   AND C.QLTY_VEHL_CD = D.QLTY_VEHL_CD 
						   AND C.MDL_MDY_CD = D.MDL_MDY_CD 
						   AND C.DL_EXPD_REGN_CD = D.DL_EXPD_REGN_CD  
                           AND C.MDL_MDY_CD BETWEEN V_FROM_MDL_MDY AND V_TO_MDL_MDY
                           AND C.MDL_MDY_CD = DECODE(P_MDL_MDY , '', C.MDL_MDY_CD, P_MDL_MDY)
                           AND B.DL_EXPD_PAC_SCN_CD = DECODE(P_PAC_SCN_CD, 'ALL', B.DL_EXPD_PAC_SCN_CD, P_PAC_SCN_CD)
						   AND C.DL_EXPD_REGN_CD = DECODE(P_REGN_CD, 'ALL', C.DL_EXPD_REGN_CD, P_REGN_CD)
						   AND C.LANG_CD = DECODE(P_USF_CD, 'D', 'KO', C.LANG_CD)
  				           AND C.LANG_CD <> DECODE(P_USF_CD, 'E', 'KO', 'NULL')
                           AND C.LANG_CD = DECODE(P_LANG_CD, 'ALL', C.LANG_CD, P_LANG_CD)
						   AND B.USE_YN = 'Y'
						   AND C.USE_YN = 'Y'
				          )
				 SELECT A.QLTY_VEHL_NM,
				 		A.MDL_MDY_NM,
				 		A.LANG_CD_NM,
						A.N_PRNT_PBCN_NO,
						NVL(B.DL_EXPD_PRVS_NM, '') AS EXPD_WHOT_ST_NM,
						CASE WHEN A.EXPD_WHOT_ST_CD = '05' THEN A.IV_QTY - A.EXPD_WHOT_QTY --추가일 경우에는 현재에서 보정수량을 빼주어서 이전재고 수량을 표시한다.
						     ELSE A.IV_QTY + A.EXPD_WHOT_QTY
						END AS IV_QTY,
						--A.IV_QTY,
						ABS(A.EXPD_WHOT_QTY) AS EXPD_WHOT_QTY,
						A.IV_QTY AS FIXED_IV_QTY,
						--0 AS FIXED_IV_QTY,
						A.WHOT_YMD,
						NVL(C.USER_NM, '') AS CRGR_NM,
						A.QLTY_VEHL_CD,
						A.DL_EXPD_MDL_MDY_CD,
						A.LANG_CD,
						A.DTL_SN,
						A.EXPD_WHOT_ST_CD,
						A.CRGR_EENO,
						A.CL_SCN_CD,
                        A.DL_EXPD_CO_CD,
						A.PRTL_IMTR_SBC,
						A.MDL_MDY_CD
				 FROM (SELECT B.DL_EXPD_CO_CD, B.QLTY_VEHL_NM,
				 	  		  B.MDL_MDY_NM,
				 	  		  B.LANG_CD_NM,
							  B.LANG_SORT_SN,
							  A.N_PRNT_PBCN_NO,
							  NVL(D.DL_EXPD_WHOT_ST_CD, '') AS EXPD_WHOT_ST_CD,
							  C.IV_QTY,
							  NVL(ABS(D.DL_EXPD_WHOT_QTY), 0) AS EXPD_WHOT_QTY, --추가의 경우에는 출고수량이 - 로 표시되는데 화면에서는 무조건 양수로 표현해준다.
							  NVL(TO_CHAR(TO_DATE(D.WHOT_YMD,'YYYYMMDD'),'YYYY-MM-DD'), '') AS WHOT_YMD,
							  NVL(D.CRGR_EENO, '') AS CRGR_EENO,
							  A.QLTY_VEHL_CD,
							  A.DL_EXPD_MDL_MDY_CD,
							  A.LANG_CD,
							  NVL(D.DTL_SN, 0 ) AS DTL_SN,
							  --수정권한이 있는 차종이면서 또한 보정일이 현재일인 경우에만 수정가능하다.
							  CASE WHEN B.CL_SCN_CD = 'U' AND A.CLS_YMD = V_CURR_YMD THEN 'Y' 
							       ELSE 'N' END AS CL_SCN_CD,
							  D.PRTL_IMTR_SBC,
							  B.MDL_MDY_CD
				       FROM (SELECT QLTY_VEHL_CD,
				 	  		        DL_EXPD_MDL_MDY_CD,
							        LANG_CD,
									CLS_YMD,
							        N_PRNT_PBCN_NO
				             FROM (SELECT A.QLTY_VEHL_CD,
				 	  		              A.DL_EXPD_MDL_MDY_CD,
							              A.LANG_CD,
										  B.CLS_YMD,
							              B.N_PRNT_PBCN_NO,
							              ROWNUM AS ROWNM
				                   FROM T A,
					                    TB_PDI_IV_INFO B
					               WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
					               AND A.DL_EXPD_MDL_MDY_CD = B.DL_EXPD_MDL_MDY_CD
					               AND A.LANG_CD = B.LANG_CD
								   AND CLS_YMD = P_CURR_YMD
								   ORDER BY A.QLTY_VEHL_CD, A.LANG_CD
					              )
					         --WHERE ROWNM BETWEEN P_FROM_NUM AND V_END_NUM 
					        ) A,
					        T B,
					        TB_PDI_IV_INFO C,
					        TB_PDI_WHOT_INFO D 
				      WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
				      AND A.DL_EXPD_MDL_MDY_CD = B.DL_EXPD_MDL_MDY_CD 
				      AND A.LANG_CD = B.LANG_CD
				      AND A.QLTY_VEHL_CD = C.QLTY_VEHL_CD
				      AND A.DL_EXPD_MDL_MDY_CD = C.DL_EXPD_MDL_MDY_CD 
				      AND A.LANG_CD = C.LANG_CD
					  AND A.CLS_YMD = C.CLS_YMD
				      AND A.N_PRNT_PBCN_NO = C.N_PRNT_PBCN_NO 
				      AND A.QLTY_VEHL_CD = D.QLTY_VEHL_CD(+) 
				      AND A.DL_EXPD_MDL_MDY_CD = D.DL_EXPD_MDL_MDY_CD(+) 
				      AND A.LANG_CD = D.LANG_CD(+)
					  AND A.CLS_YMD = D.WHOT_YMD(+)
				      AND A.N_PRNT_PBCN_NO = D.N_PRNT_PBCN_NO(+)
					  AND D.DL_EXPD_WHOT_ST_CD(+) <> '01' --배치작업에서 출고되는 항목은 제외한다.
					  AND D.DEL_YN(+) = 'N'
					 ) A,
				     TB_CODE_MGMT B,
					 TB_USR_MGMT C
				  WHERE A.CRGR_EENO = C.USER_EENO(+)
				  AND A.EXPD_WHOT_ST_CD = B.DL_EXPD_PRVS_CD(+)
				  AND B.DL_EXPD_G_CD(+) = '0014'
				  --ORDER BY QLTY_VEHL_CD, LANG_CD, DL_EXPD_MDL_MDY_CD, N_PRNT_PBCN_NO;
				  ORDER BY QLTY_VEHL_CD, LANG_SORT_SN, DL_EXPD_MDL_MDY_CD, N_PRNT_PBCN_NO;
		    ***/		  
			
			--신버전 
			OPEN RS FOR
				WITH T AS (SELECT A.CL_SCN_CD,
			          	 		  C.DATA_SN, 
								  B.DL_EXPD_CO_CD,
			  					  C.QLTY_VEHL_CD,
                                  C.MDL_MDY_CD,
                                  C.LANG_CD,
                                  '(' || C.QLTY_VEHL_CD || '-' || C.MDL_MDY_CD || ')' || B.QLTY_VEHL_NM AS QLTY_VEHL_NM,
								  C.MDL_MDY_CD || 'MY' AS MDL_MDY_NM,
                                  --'(' || C.LANG_CD || ')' || C.LANG_CD_NM AS LANG_CD_NM 
								  CASE WHEN C.A_CODE IS NULL THEN '(' || C.LANG_CD || ')'
				   				  	   ELSE '(' || C.LANG_CD || '-' || C.A_CODE || ')' 
			  					  END || C.LANG_CD_NM AS LANG_CD_NM,
								  C.SORT_SN AS LANG_SORT_SN
                           FROM (SELECT QLTY_VEHL_CD,
                                        MAX(CL_SCN_CD) AS CL_SCN_CD
                                 FROM TB_AUTH_VEHL_MGMT
                                 WHERE MENU_ID = PG_COMMON.FU_RPAD(P_MENU_ID, 10)
                                 AND USER_EENO = PG_COMMON.FU_RPAD(P_USER_EENO, 7)
                                 AND QLTY_VEHL_CD = DECODE(P_VEHL_CD, 'ALL', QLTY_VEHL_CD, P_VEHL_CD)
                                 GROUP BY QLTY_VEHL_CD
                                ) A,
                                TB_VEHL_MGMT B,
                                TB_LANG_MGMT C
                           WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
                           AND A.QLTY_VEHL_CD = C.QLTY_VEHL_CD
                           AND B.MDL_MDY_CD = C.MDL_MDY_CD
                           AND C.MDL_MDY_CD BETWEEN V_FROM_MDL_MDY AND V_TO_MDL_MDY
                           AND C.MDL_MDY_CD = DECODE(P_MDL_MDY , '', C.MDL_MDY_CD, P_MDL_MDY)
                           AND B.DL_EXPD_PAC_SCN_CD = DECODE(P_PAC_SCN_CD, 'ALL', B.DL_EXPD_PAC_SCN_CD, P_PAC_SCN_CD)
						   AND C.DL_EXPD_REGN_CD = DECODE(P_REGN_CD, 'ALL', C.DL_EXPD_REGN_CD, P_REGN_CD)
						   AND C.LANG_CD = DECODE(P_USF_CD, 'D', 'KO', C.LANG_CD)
  				           AND C.LANG_CD <> DECODE(P_USF_CD, 'E', 'KO', 'NULL')
                           AND C.LANG_CD = DECODE(P_LANG_CD, 'ALL', C.LANG_CD, P_LANG_CD)
						   AND B.USE_YN = 'Y'
						   AND C.USE_YN = 'Y'
				          )
				 SELECT A.QLTY_VEHL_NM,
				 		A.MDL_MDY_NM,
				 		A.LANG_CD_NM,
						A.N_PRNT_PBCN_NO,
						NVL(B.DL_EXPD_PRVS_NM, '') AS EXPD_WHOT_ST_NM,
						CASE WHEN A.EXPD_WHOT_ST_CD = '05' THEN A.IV_QTY - A.EXPD_WHOT_QTY --추가일 경우에는 현재에서 보정수량을 빼주어서 이전재고 수량을 표시한다.
						     ELSE A.IV_QTY + A.EXPD_WHOT_QTY
						END AS IV_QTY,
						--A.IV_QTY,
						ABS(A.EXPD_WHOT_QTY) AS EXPD_WHOT_QTY,
						A.IV_QTY AS FIXED_IV_QTY,
						--0 AS FIXED_IV_QTY,
						A.WHOT_YMD,
						NVL(C.USER_NM, '') AS CRGR_NM,
						A.QLTY_VEHL_CD,
						A.DL_EXPD_MDL_MDY_CD,
						A.LANG_CD,
						A.DTL_SN,
						A.EXPD_WHOT_ST_CD,
						A.CRGR_EENO,
						A.CL_SCN_CD,
                        A.DL_EXPD_CO_CD,
						A.PRTL_IMTR_SBC,
						A.MDL_MDY_CD
				 FROM (SELECT B.DL_EXPD_CO_CD, B.QLTY_VEHL_NM,
				 	  		  B.MDL_MDY_NM,
				 	  		  B.LANG_CD_NM,
							  B.LANG_SORT_SN,
							  A.N_PRNT_PBCN_NO,
							  NVL(D.DL_EXPD_WHOT_ST_CD, '') AS EXPD_WHOT_ST_CD,
							  C.IV_QTY,
							  NVL(ABS(D.DL_EXPD_WHOT_QTY), 0) AS EXPD_WHOT_QTY, --추가의 경우에는 출고수량이 - 로 표시되는데 화면에서는 무조건 양수로 표현해준다.
							  NVL(TO_CHAR(TO_DATE(D.WHOT_YMD,'YYYYMMDD'),'YYYY-MM-DD'), '') AS WHOT_YMD,
							  NVL(D.CRGR_EENO, '') AS CRGR_EENO,
							  A.QLTY_VEHL_CD,
							  A.DL_EXPD_MDL_MDY_CD,
							  A.LANG_CD,
							  NVL(D.DTL_SN, 0 ) AS DTL_SN,
							  --수정권한이 있는 차종이면서 또한 보정일이 현재일인 경우에만 수정가능하다.
							  CASE WHEN B.CL_SCN_CD = 'U' AND A.CLS_YMD = V_CURR_YMD THEN 'Y' 
							       ELSE 'N' END AS CL_SCN_CD,
							  D.PRTL_IMTR_SBC,
							  B.MDL_MDY_CD
				       FROM (SELECT QLTY_VEHL_CD,
					   				MDL_MDY_CD,
							        LANG_CD,
									DL_EXPD_MDL_MDY_CD,
									N_PRNT_PBCN_NO,
									CLS_YMD
				             FROM (SELECT A.QLTY_VEHL_CD,
							 	  		  A.MDL_MDY_CD,
							              A.LANG_CD,
										  B.DL_EXPD_MDL_MDY_CD,
							              B.N_PRNT_PBCN_NO,
										  B.CLS_YMD,
							              ROWNUM AS ROWNM
				                   FROM T A,
					                    TB_PDI_IV_INFO_DTL B
					               WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
					               AND A.MDL_MDY_CD     = B.MDL_MDY_CD
					               AND A.LANG_CD        = B.LANG_CD
								   AND B.CLS_YMD        = P_CURR_YMD
								   ORDER BY A.QLTY_VEHL_CD, A.LANG_SORT_SN, A.MDL_MDY_CD, PG_COMMON.FU_GET_SORT_PBCN(B.N_PRNT_PBCN_NO), B.DL_EXPD_MDL_MDY_CD
					              )
					         --WHERE ROWNM BETWEEN P_FROM_NUM AND V_END_NUM 
					        ) A,
					        T B,
					        TB_PDI_IV_INFO_DTL C,
					        TB_PDI_WHOT_INFO D
				      WHERE A.QLTY_VEHL_CD     = B.QLTY_VEHL_CD
				      AND A.MDL_MDY_CD         = B.MDL_MDY_CD
				      AND A.LANG_CD            = B.LANG_CD
				      AND A.QLTY_VEHL_CD       = C.QLTY_VEHL_CD
					  AND A.MDL_MDY_CD         = C.MDL_MDY_CD
				      AND A.LANG_CD            = C.LANG_CD
					  AND A.DL_EXPD_MDL_MDY_CD = C.DL_EXPD_MDL_MDY_CD
					  AND A.N_PRNT_PBCN_NO     = C.N_PRNT_PBCN_NO
					  AND A.CLS_YMD            = C.CLS_YMD
				      AND A.QLTY_VEHL_CD       = D.QLTY_VEHL_CD(+)
					  AND A.MDL_MDY_CD         = D.MDL_MDY_CD(+)
				      AND A.LANG_CD            = D.LANG_CD(+)
					  AND A.DL_EXPD_MDL_MDY_CD = D.DL_EXPD_MDL_MDY_CD(+)
					  AND A.N_PRNT_PBCN_NO     = D.N_PRNT_PBCN_NO(+)
					  AND A.CLS_YMD            = D.WHOT_YMD(+)
					  AND D.DL_EXPD_WHOT_ST_CD(+) <> '01' --배치작업에서 출고되는 항목은 제외한다.
					  AND D.DEL_YN(+) = 'N'
					 ) A,
				     TB_CODE_MGMT B,
					 TB_USR_MGMT C
				  WHERE A.CRGR_EENO = C.USER_EENO(+)
				  AND A.EXPD_WHOT_ST_CD = B.DL_EXPD_PRVS_CD(+)
				  AND B.DL_EXPD_G_CD(+) = '0014'
				  ORDER BY QLTY_VEHL_CD, LANG_SORT_SN, MDL_MDY_CD, DL_EXPD_MDL_MDY_CD, PG_COMMON.FU_GET_SORT_PBCN(N_PRNT_PBCN_NO) DESC;
			
	   END SP_GET_PDI_REVICE_INFO;
	   
	   PROCEDURE SP_GET_PDI_REVICE_INFO2(P_MENU_ID    VARCHAR2,
								        P_USER_EENO  VARCHAR2,
								        P_CURR_YMD   VARCHAR2,
								        P_PAC_SCN_CD VARCHAR2,
								        P_VEHL_CD	 VARCHAR2,
								        P_MDL_MDY	 VARCHAR2,
								        P_REGN_CD	 VARCHAR2,
								        P_LANG_CD	 VARCHAR2,
								        P_USF_CD	 VARCHAR2,  -- D: 내수만, E: 수출만 조회,
										--P_FROM_NUM NUMBER,
							 			--P_TO_NUM   NUMBER,
										--P_CNT   OUT NUMBER,
								        RS 		OUT REFCUR)
	   IS
	   	  
		  V_CURR_YMD      VARCHAR2(8);
		  
		  V_FROM_MDL_MDY VARCHAR2(2);
		  V_TO_MDL_MDY   VARCHAR2(2);
		  
		  --V_END_NUM      NUMBER;
		  
	   BEGIN
	   		
			V_CURR_YMD := TO_CHAR(SYSDATE, 'YYYYMMDD');
			
			PG_COMMON.SP_GET_VALID_MDL_MDY4(P_CURR_YMD, '', V_FROM_MDL_MDY, V_TO_MDL_MDY);
			
			--신버전 
			OPEN RS FOR
				WITH T AS (SELECT A.CL_SCN_CD,
			          	 		  C.DATA_SN, 
								  B.DL_EXPD_CO_CD,
			  					  C.QLTY_VEHL_CD,
                                  C.MDL_MDY_CD,
                                  C.LANG_CD,
                                  '(' || C.QLTY_VEHL_CD || '-' || C.MDL_MDY_CD || ')' || B.QLTY_VEHL_NM AS QLTY_VEHL_NM,
								  C.MDL_MDY_CD || 'MY' AS MDL_MDY_NM,
                                  --'(' || C.LANG_CD || ')' || C.LANG_CD_NM AS LANG_CD_NM 
								  CASE WHEN C.A_CODE IS NULL THEN '(' || C.LANG_CD || ')'
				   				  	   ELSE '(' || C.LANG_CD || '-' || C.A_CODE || ')' 
			  					  END || C.LANG_CD_NM AS LANG_CD_NM,
								  C.SORT_SN AS LANG_SORT_SN
                           FROM (SELECT QLTY_VEHL_CD,
                                        MAX(CL_SCN_CD) AS CL_SCN_CD
                                 FROM TB_AUTH_VEHL_MGMT
                                 WHERE MENU_ID = PG_COMMON.FU_RPAD(P_MENU_ID, 10)
                                 AND USER_EENO = PG_COMMON.FU_RPAD(P_USER_EENO, 7)
                                 AND QLTY_VEHL_CD = DECODE(P_VEHL_CD, 'ALL', QLTY_VEHL_CD, P_VEHL_CD)
                                 GROUP BY QLTY_VEHL_CD
                                ) A,
                                TB_VEHL_MGMT B,
                                TB_LANG_MGMT C
                           WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
                           AND A.QLTY_VEHL_CD = C.QLTY_VEHL_CD
                           AND B.MDL_MDY_CD = C.MDL_MDY_CD
                           AND C.MDL_MDY_CD BETWEEN V_FROM_MDL_MDY AND V_TO_MDL_MDY
                           AND C.MDL_MDY_CD = DECODE(P_MDL_MDY , '', C.MDL_MDY_CD, P_MDL_MDY)
                           AND B.DL_EXPD_PAC_SCN_CD = DECODE(P_PAC_SCN_CD, 'ALL', B.DL_EXPD_PAC_SCN_CD, P_PAC_SCN_CD)
						   AND C.DL_EXPD_REGN_CD = DECODE(P_REGN_CD, 'ALL', C.DL_EXPD_REGN_CD, P_REGN_CD)
						   AND C.LANG_CD = DECODE(P_USF_CD, 'D', 'KO', C.LANG_CD)
  				           AND C.LANG_CD <> DECODE(P_USF_CD, 'E', 'KO', 'NULL')
                           AND C.LANG_CD = DECODE(P_LANG_CD, 'ALL', C.LANG_CD, P_LANG_CD)
						   AND B.USE_YN = 'Y'
						   AND C.USE_YN = 'Y'
				          )
				 SELECT A.QLTY_VEHL_NM,
				 		A.MDL_MDY_NM,
				 		A.LANG_CD_NM,
						A.N_PRNT_PBCN_NO,
						NVL(B.DL_EXPD_PRVS_NM, '') AS EXPD_WHOT_ST_NM,
						NVL(CASE WHEN A.EXPD_WHOT_ST_CD = '05' THEN A.IV_QTY - A.EXPD_WHOT_QTY --추가일 경우에는 현재에서 보정수량을 빼주어서 이전재고 수량을 표시한다.
						     ELSE A.IV_QTY + A.EXPD_WHOT_QTY
						END, 0) AS IV_QTY,
						--A.IV_QTY,
						ABS(A.EXPD_WHOT_QTY) AS EXPD_WHOT_QTY,
						NVL(A.IV_QTY, 0) AS FIXED_IV_QTY,
						--0 AS FIXED_IV_QTY,
						A.WHOT_YMD,
						NVL(C.USER_NM, '') AS CRGR_NM,
						A.QLTY_VEHL_CD,
						A.DL_EXPD_MDL_MDY_CD,
						A.LANG_CD,
						A.DTL_SN,
						A.EXPD_WHOT_ST_CD,
						A.CRGR_EENO,
						A.CL_SCN_CD,
                        A.DL_EXPD_CO_CD,
						A.PRTL_IMTR_SBC,
						A.MDL_MDY_CD
				 FROM (SELECT B.DL_EXPD_CO_CD, B.QLTY_VEHL_NM,
				 	  		  B.MDL_MDY_NM,
				 	  		  B.LANG_CD_NM,
							  B.LANG_SORT_SN,
							  A.N_PRNT_PBCN_NO,
							  NVL((CASE WHEN C.IV_QTY IS NULL AND D.DL_EXPD_WHOT_ST_CD IS NULL THEN '05' ELSE D.DL_EXPD_WHOT_ST_CD END), '') AS EXPD_WHOT_ST_CD,
							  C.IV_QTY,
							  NVL(ABS(D.DL_EXPD_WHOT_QTY), 0) AS EXPD_WHOT_QTY, --추가의 경우에는 출고수량이 - 로 표시되는데 화면에서는 무조건 양수로 표현해준다.
							  NVL(TO_CHAR(TO_DATE(D.WHOT_YMD,'YYYYMMDD'),'YYYY-MM-DD'), '') AS WHOT_YMD,
							  NVL(D.CRGR_EENO, '') AS CRGR_EENO,
							  A.QLTY_VEHL_CD,
							  A.DL_EXPD_MDL_MDY_CD,
							  A.LANG_CD,
							  NVL(D.DTL_SN, 0 ) AS DTL_SN,
							  --수정권한이 있는 차종이면서 또한 보정일이 현재일인 경우에만 수정가능하다.
							  CASE WHEN B.CL_SCN_CD = 'U' AND A.CLS_YMD = V_CURR_YMD THEN 'Y' 
							       ELSE 'N' END AS CL_SCN_CD,
							  D.PRTL_IMTR_SBC,
							  B.MDL_MDY_CD
				       FROM (SELECT QLTY_VEHL_CD,
                                MDL_MDY_CD,
                                LANG_CD,
                                DL_EXPD_MDL_MDY_CD,
                                N_PRNT_PBCN_NO,
                                CLS_YMD
                         FROM (SELECT A.QLTY_VEHL_CD,
                                      A.MDL_MDY_CD,
                                      A.LANG_CD,
                                      NVL(B.DL_EXPD_MDL_MDY_CD, (SELECT MAX(DL_EXPD_MDL_MDY_CD) FROM TB_DL_EXPD_MDY_MGMT WHERE QLTY_VEHL_CD = A.QLTY_VEHL_CD AND MDL_MDY_CD = A.MDL_MDY_CD)) DL_EXPD_MDL_MDY_CD,
                                      NVL(B.N_PRNT_PBCN_NO, (SELECT MAX(N_PRNT_PBCN_NO) FROM TB_PDI_IV_INFO_DTL WHERE QLTY_VEHL_CD = A.QLTY_VEHL_CD AND MDL_MDY_CD = A.MDL_MDY_CD AND LANG_CD = A.LANG_CD AND CLS_YMD <= P_CURR_YMD)) N_PRNT_PBCN_NO,
                                      NVL(B.CLS_YMD, P_CURR_YMD) CLS_YMD,
                                      A.DATA_SN,
                                      ROWNUM AS ROWNM
                               FROM T A,
                                    TB_PDI_IV_INFO_DTL B
                                    --,TB_APS_PROD_SUM_INFO C
                               WHERE 1=1
                               --AND A.DATA_SN = C.DATA_SN(+)
                               AND A.QLTY_VEHL_CD = B.QLTY_VEHL_CD(+)
                               AND A.MDL_MDY_CD     = B.MDL_MDY_CD(+)
                               AND A.LANG_CD        = B.LANG_CD(+)
                               --AND C.APL_YMD(+)		= P_CURR_YMD
                               AND B.CLS_YMD(+)     = P_CURR_YMD
--                               AND NVL(C.WEK2_PRDN_PLN_QTY, 0) + NVL(C.TDD_PRDN_QTY3, 0) + NVL(C.TDD_PRDN_PLN_QTY, 0) + NVL(B.SFTY_IV_QTY, 0) > 0
                               ORDER BY A.QLTY_VEHL_CD, A.LANG_SORT_SN, A.MDL_MDY_CD, PG_COMMON.FU_GET_SORT_PBCN(B.N_PRNT_PBCN_NO), B.DL_EXPD_MDL_MDY_CD
                              )
					         --WHERE ROWNM BETWEEN P_FROM_NUM AND V_END_NUM 
                             WHERE N_PRNT_PBCN_NO IS NOT NULL	-- 재고보정시 발간번호가 NULL인 경우는 제외한다.
					        ) A,
					        T B,
					        TB_PDI_IV_INFO_DTL C,
					        TB_PDI_WHOT_INFO D
				      WHERE A.QLTY_VEHL_CD     = B.QLTY_VEHL_CD
				      AND A.MDL_MDY_CD         = B.MDL_MDY_CD
				      AND A.LANG_CD            = B.LANG_CD
				      AND A.QLTY_VEHL_CD       = C.QLTY_VEHL_CD(+)
					  AND A.MDL_MDY_CD         = C.MDL_MDY_CD(+)
				      AND A.LANG_CD            = C.LANG_CD(+)
					  AND A.DL_EXPD_MDL_MDY_CD = C.DL_EXPD_MDL_MDY_CD(+)
					  AND A.N_PRNT_PBCN_NO     = C.N_PRNT_PBCN_NO(+)
					  AND A.CLS_YMD            = C.CLS_YMD(+)
				      AND A.QLTY_VEHL_CD       = D.QLTY_VEHL_CD(+)
					  AND A.MDL_MDY_CD         = D.MDL_MDY_CD(+)
				      AND A.LANG_CD            = D.LANG_CD(+)
					  AND A.DL_EXPD_MDL_MDY_CD = D.DL_EXPD_MDL_MDY_CD(+)
					  AND A.N_PRNT_PBCN_NO     = D.N_PRNT_PBCN_NO(+)
					  AND A.CLS_YMD            = D.WHOT_YMD(+)
					  AND D.DL_EXPD_WHOT_ST_CD(+) <> '01' --배치작업에서 출고되는 항목은 제외한다.
					  AND D.DEL_YN(+) = 'N'
					 ) A,
				     TB_CODE_MGMT B,
					 TB_USR_MGMT C
				  WHERE A.CRGR_EENO = C.USER_EENO(+)
				  AND A.EXPD_WHOT_ST_CD = B.DL_EXPD_PRVS_CD(+)
				  AND B.DL_EXPD_G_CD(+) = '0014'
				  ORDER BY QLTY_VEHL_CD, LANG_SORT_SN, MDL_MDY_CD, DL_EXPD_MDL_MDY_CD, PG_COMMON.FU_GET_SORT_PBCN(N_PRNT_PBCN_NO) DESC;
			
	   END SP_GET_PDI_REVICE_INFO2;
	   
	   --재고보정 데이터 저장 
       PROCEDURE SP_PDI_REVICE_INFO_SAVE(P_VEHL_CD         VARCHAR2,
	   			 				         P_MDL_MDY_CD	   VARCHAR2,
								         P_LANG_CD         VARCHAR2,
										 P_EXPD_MDL_MDY_CD VARCHAR2,
								         P_N_PRNT_PBCN_NO  VARCHAR2,
								         P_DTL_SN          NUMBER,
								         P_EXPD_WHOT_ST_CD VARCHAR2,
								         P_WHOT_QTY		   NUMBER,
								         P_USER_EENO	   VARCHAR2,
										 P_PRTL_IMTR_SBC   VARCHAR2
										-- , P_PRDN_PLNT_CD VARCHAR2
										 )
	   IS
	   	 
		 V_CURR_YMD      VARCHAR2(8);
		 
		 V_WHOT_QTY      NUMBER;
		 V_PREV_WHOT_QTY NUMBER;
		 
		 V_DIFF_WHOT_QTY NUMBER;
		 
	   BEGIN
	   		
			V_CURR_YMD := TO_CHAR(SYSDATE, 'YYYYMMDD');
			
			--추가일 경우에는 출고수량을 - 로 표현해준다.
			IF P_EXPD_WHOT_ST_CD = '05' THEN
			   
			   V_WHOT_QTY := ABS(P_WHOT_QTY) * (-1);
			
			ELSE
			   
			   V_WHOT_QTY := ABS(P_WHOT_QTY);
			   
			END IF;
			
			--이전 출고수량 존재여부 확인 
			SELECT SUM(DL_EXPD_WHOT_QTY)
			INTO V_PREV_WHOT_QTY
			FROM TB_PDI_WHOT_INFO
			WHERE WHOT_YMD = V_CURR_YMD
			AND QLTY_VEHL_CD = P_VEHL_CD
			AND MDL_MDY_CD = P_MDL_MDY_CD
			AND LANG_CD = P_LANG_CD
			AND DL_EXPD_MDL_MDY_CD = P_EXPD_MDL_MDY_CD
			AND N_PRNT_PBCN_NO = P_N_PRNT_PBCN_NO
			AND DTL_SN = P_DTL_SN
			AND DL_EXPD_WHOT_ST_CD = P_EXPD_WHOT_ST_CD
			--AND DEL_YN = 'N' 
			;
			
			--별도요청 출고정보 수정작업을 위해서 이전 요청수량이 없으면 반드시 NULL 이어야 한다. 
			IF V_PREV_WHOT_QTY IS NULL THEN 
			  	 
			    V_DIFF_WHOT_QTY := V_WHOT_QTY;
				
			ELSE
			
			    V_DIFF_WHOT_QTY := V_WHOT_QTY - V_PREV_WHOT_QTY;
				
			END IF;

			--재고데이터 업데이트 작업 수행 
			PG_DATA.SP_PDI_IV_INFO_UPDATE(P_VEHL_CD,
										  P_MDL_MDY_CD,
							      		  P_LANG_CD,
										  P_EXPD_MDL_MDY_CD,
								  		  P_N_PRNT_PBCN_NO,
								  		  V_CURR_YMD,
								  		  V_DIFF_WHOT_QTY,
								  		  'N',
										  'N',
								  		  P_USER_EENO
								  		  , 'N' --P_PRDN_PLNT_CD   -- 광주 임시...호출 하는곳이 없는데...프로그램에서 쓰던건가보다...확인....
								  		  );
			
			
			--출고항목 업데이트 작업 수행 
			UPDATE TB_PDI_WHOT_INFO
		    SET CRGR_EENO = P_USER_EENO,
			    DL_EXPD_WHOT_QTY = V_WHOT_QTY,
			    DEL_YN = 'N',
			    UPDR_EENO = P_USER_EENO,
			    MDFY_DTM = SYSDATE,
				PRTL_IMTR_SBC = P_PRTL_IMTR_SBC
			WHERE WHOT_YMD = V_CURR_YMD
	        AND QLTY_VEHL_CD = P_VEHL_CD
			AND MDL_MDY_CD = P_MDL_MDY_CD
		    AND LANG_CD = P_LANG_CD
			AND DL_EXPD_MDL_MDY_CD = P_EXPD_MDL_MDY_CD
		    AND N_PRNT_PBCN_NO = P_N_PRNT_PBCN_NO
		    AND DTL_SN = P_DTL_SN
			AND DL_EXPD_WHOT_ST_CD = P_EXPD_WHOT_ST_CD
			--AND DEL_YN = 'N' 
			; 
			
			--수정된 항목이 없다면 Insert 해준다. 
		    IF SQL%NOTFOUND THEN
		   	  
			  INSERT INTO TB_PDI_WHOT_INFO
   			  (WHOT_YMD,
			   QLTY_VEHL_CD,
   			   DL_EXPD_MDL_MDY_CD,
   			   LANG_CD,
   			   N_PRNT_PBCN_NO,
   			   DTL_SN,
			   DL_EXPD_WHOT_ST_CD,
			   CRGR_EENO,
			   DL_EXPD_WHOT_QTY,
			   DEL_YN,
			   PPRR_EENO,
   			   FRAM_DTM,
   			   UPDR_EENO,
   			   MDFY_DTM,
			   PRTL_IMTR_SBC,
			   MDL_MDY_CD
   			  )
   			  SELECT V_CURR_YMD,
			  		 P_VEHL_CD,
   			         P_EXPD_MDL_MDY_CD,
   					 P_LANG_CD,
   					 P_N_PRNT_PBCN_NO,
   					 NVL(MAX(DTL_SN), 0) + 1,
   		             P_EXPD_WHOT_ST_CD,
					 P_USER_EENO,
					 V_WHOT_QTY,
					 'N',
					 P_USER_EENO,
					 SYSDATE,
					 P_USER_EENO,
					 SYSDATE,
					 P_PRTL_IMTR_SBC,
					 P_MDL_MDY_CD
   			  FROM TB_PDI_WHOT_INFO
			  WHERE WHOT_YMD = V_CURR_YMD
   			  AND QLTY_VEHL_CD = P_VEHL_CD
   			  AND DL_EXPD_MDL_MDY_CD = P_EXPD_MDL_MDY_CD
   			  AND LANG_CD = P_LANG_CD
   			  AND N_PRNT_PBCN_NO = P_N_PRNT_PBCN_NO;
		  
		   END IF;
		   
		   --반출, 불량일 경우에는 세화재고에 추가해 주는 작업을 수행해 주어야 한다. 
		   IF P_EXPD_WHOT_ST_CD = '08' OR P_EXPD_WHOT_ST_CD = '09' THEN
		   	  
			  PG_SEWHA_IV_INFO.SP_SEWHA_WHOT_INFO_UPDATE2(P_VEHL_CD,
			                                              P_MDL_MDY_CD,
   					 									  P_LANG_CD,
														  P_EXPD_MDL_MDY_CD,
   					 									  P_N_PRNT_PBCN_NO,
														  V_CURR_YMD,
														  V_DIFF_WHOT_QTY * (-1),
														  P_USER_EENO);
														  
		   ELSIF P_EXPD_WHOT_ST_CD = '02' THEN
		   								  
			  --별도 요청정보 업데이트 
			  PG_TOT_IV_INFO.SP_EXTRA_REQ_UPDATE(P_VEHL_CD, 
			   						             P_MDL_MDY_CD, 
									             P_LANG_CD, 
			   						             P_N_PRNT_PBCN_NO,
												 '04',
												 V_WHOT_QTY,
												 V_PREV_WHOT_QTY, -- 이전 요청수량이 없으면 반드시 NULL로 넘겨주어야 한다. 
												 P_USER_EENO
												 , 'N' --P_PRDN_PLNT_CD
												 );
		   END IF;
		   
	   END SP_PDI_REVICE_INFO_SAVE;
	   
	   --재고보정 데이터 저장 (재고 0인 경우 재고보정을 위하여 PG_DATA.SP_PDI_IV_INFO_UPDATE에서 PG_DATA.SP_PDI_IV_INFO_UPDATE3 호출로 수정)
       PROCEDURE SP_PDI_REVICE_INFO_SAVE2(P_VEHL_CD         VARCHAR2,
	   			 				         P_MDL_MDY_CD	   VARCHAR2,
								         P_LANG_CD         VARCHAR2,
										 P_EXPD_MDL_MDY_CD VARCHAR2,
								         P_N_PRNT_PBCN_NO  VARCHAR2,
								         P_DTL_SN          NUMBER,
								         P_EXPD_WHOT_ST_CD VARCHAR2,
								         P_WHOT_QTY		   NUMBER,
								         P_USER_EENO	   VARCHAR2,
										 P_PRTL_IMTR_SBC   VARCHAR2
										-- , P_PRDN_PLNT_CD  VARCHAR2
										 )
	   IS
	   	 
		 V_CURR_YMD      VARCHAR2(8);
		 
		 V_WHOT_QTY      NUMBER;
		 V_PREV_WHOT_QTY NUMBER;
		 
		 V_DIFF_WHOT_QTY NUMBER;
		 
	   BEGIN
	   		
			V_CURR_YMD := TO_CHAR(SYSDATE, 'YYYYMMDD');
			
			--추가일 경우에는 출고수량을 - 로 표현해준다.
			IF P_EXPD_WHOT_ST_CD = '05' THEN
			   
			   V_WHOT_QTY := ABS(P_WHOT_QTY) * (-1);
			
			ELSE
			   
			   V_WHOT_QTY := ABS(P_WHOT_QTY);
			   
			END IF;
			
			--이전 출고수량 존재여부 확인 
			SELECT SUM(DL_EXPD_WHOT_QTY)
			INTO V_PREV_WHOT_QTY
			FROM TB_PDI_WHOT_INFO
			WHERE WHOT_YMD = V_CURR_YMD
			AND QLTY_VEHL_CD = P_VEHL_CD
			AND MDL_MDY_CD = P_MDL_MDY_CD
			AND LANG_CD = P_LANG_CD
			AND DL_EXPD_MDL_MDY_CD = P_EXPD_MDL_MDY_CD
			AND N_PRNT_PBCN_NO = P_N_PRNT_PBCN_NO
			AND DTL_SN = P_DTL_SN
			AND DL_EXPD_WHOT_ST_CD = P_EXPD_WHOT_ST_CD
			--AND DEL_YN = 'N' 
			;
			
			--별도요청 출고정보 수정작업을 위해서 이전 요청수량이 없으면 반드시 NULL 이어야 한다. 
			IF V_PREV_WHOT_QTY IS NULL THEN 
			  	 
			    V_DIFF_WHOT_QTY := V_WHOT_QTY;
				
			ELSE
			
			    V_DIFF_WHOT_QTY := V_WHOT_QTY - V_PREV_WHOT_QTY;
				
			END IF;

			--재고데이터 업데이트 작업 수행 
			PG_DATA.SP_PDI_IV_INFO_UPDATE3(P_VEHL_CD,
										  P_MDL_MDY_CD,
							      		  P_LANG_CD,
										  P_EXPD_MDL_MDY_CD,
								  		  P_N_PRNT_PBCN_NO,
								  		  V_CURR_YMD,
								  		  V_DIFF_WHOT_QTY,
								  		  P_USER_EENO,
										  'N'
										  , 'N' --P_PRDN_PLNT_CD    -- 광주 임시
										  );
			
			
			--출고항목 업데이트 작업 수행 
			UPDATE TB_PDI_WHOT_INFO
		    SET CRGR_EENO = P_USER_EENO,
			    DL_EXPD_WHOT_QTY = V_WHOT_QTY,
			    DEL_YN = 'N',
			    UPDR_EENO = P_USER_EENO,
			    MDFY_DTM = SYSDATE,
				PRTL_IMTR_SBC = P_PRTL_IMTR_SBC
			WHERE WHOT_YMD = V_CURR_YMD
	        AND QLTY_VEHL_CD = P_VEHL_CD
			AND MDL_MDY_CD = P_MDL_MDY_CD
		    AND LANG_CD = P_LANG_CD
			AND DL_EXPD_MDL_MDY_CD = P_EXPD_MDL_MDY_CD
		    AND N_PRNT_PBCN_NO = P_N_PRNT_PBCN_NO
		    AND DTL_SN = P_DTL_SN
			AND DL_EXPD_WHOT_ST_CD = P_EXPD_WHOT_ST_CD
			--AND DEL_YN = 'N' 
			; 
			
			--수정된 항목이 없다면 Insert 해준다. 
		    IF SQL%NOTFOUND THEN
		   	  
			  INSERT INTO TB_PDI_WHOT_INFO
   			  (WHOT_YMD,
			   QLTY_VEHL_CD,
   			   DL_EXPD_MDL_MDY_CD,
   			   LANG_CD,
   			   N_PRNT_PBCN_NO,
   			   DTL_SN,
			   DL_EXPD_WHOT_ST_CD,
			   CRGR_EENO,
			   DL_EXPD_WHOT_QTY,
			   DEL_YN,
			   PPRR_EENO,
   			   FRAM_DTM,
   			   UPDR_EENO,
   			   MDFY_DTM,
			   PRTL_IMTR_SBC,
			   MDL_MDY_CD
   			  )
   			  SELECT V_CURR_YMD,
			  		 P_VEHL_CD,
   			         P_EXPD_MDL_MDY_CD,
   					 P_LANG_CD,
   					 P_N_PRNT_PBCN_NO,
   					 NVL(MAX(DTL_SN), 0) + 1,
   		             P_EXPD_WHOT_ST_CD,
					 P_USER_EENO,
					 V_WHOT_QTY,
					 'N',
					 P_USER_EENO,
					 SYSDATE,
					 P_USER_EENO,
					 SYSDATE,
					 P_PRTL_IMTR_SBC,
					 P_MDL_MDY_CD
   			  FROM TB_PDI_WHOT_INFO
			  WHERE WHOT_YMD = V_CURR_YMD
   			  AND QLTY_VEHL_CD = P_VEHL_CD
   			  AND DL_EXPD_MDL_MDY_CD = P_EXPD_MDL_MDY_CD
   			  AND LANG_CD = P_LANG_CD
   			  AND N_PRNT_PBCN_NO = P_N_PRNT_PBCN_NO;
		  
		   END IF;
		   
		   --반출, 불량일 경우에는 세화재고에 추가해 주는 작업을 수행해 주어야 한다. 
		   IF P_EXPD_WHOT_ST_CD = '08' OR P_EXPD_WHOT_ST_CD = '09' THEN
		   	  
			  PG_SEWHA_IV_INFO.SP_SEWHA_WHOT_INFO_UPDATE2(P_VEHL_CD,
			                                              P_MDL_MDY_CD,
   					 									  P_LANG_CD,
														  P_EXPD_MDL_MDY_CD,
   					 									  P_N_PRNT_PBCN_NO,
														  V_CURR_YMD,
														  V_DIFF_WHOT_QTY * (-1),
														  P_USER_EENO);
														  
		   ELSIF P_EXPD_WHOT_ST_CD = '02' THEN
		   								  
			  --별도 요청정보 업데이트 
			  PG_TOT_IV_INFO.SP_EXTRA_REQ_UPDATE(P_VEHL_CD, 
			   						             P_MDL_MDY_CD, 
									             P_LANG_CD, 
			   						             P_N_PRNT_PBCN_NO,
												 '04',
												 V_WHOT_QTY,
												 V_PREV_WHOT_QTY, -- 이전 요청수량이 없으면 반드시 NULL로 넘겨주어야 한다. 
												 P_USER_EENO
												 , 'N'  --P_PRDN_PLNT_CD
												 );
		   END IF;
		   
	   END SP_PDI_REVICE_INFO_SAVE2;
	   
	   --재고보정 데이터 삭제 
       PROCEDURE SP_PDI_REVICE_INFO_DELETE(P_VEHL_CD         VARCHAR2,
	   			 						   P_MDL_MDY_CD	 	 VARCHAR2,
								           P_LANG_CD         VARCHAR2,
										   P_EXPD_MDL_MDY_CD VARCHAR2,
								           P_N_PRNT_PBCN_NO  VARCHAR2,
								           P_DTL_SN          NUMBER,
								           P_USER_EENO	     VARCHAR2)
	   IS
	   	 
		 V_CURR_YMD      VARCHAR2(8);
		 
--		 V_WHOT_QTY      NUMBER;
--		 V_PREV_WHOT_QTY NUMBER;
		 
		 V_DIFF_WHOT_QTY NUMBER;
		 
		 V_EXPD_WHOT_ST_CD VARCHAR2(4);
		 
	   BEGIN
	   		
			V_CURR_YMD := TO_CHAR(SYSDATE, 'YYYYMMDD');
					
			--이전 출고수량 존재여부 확인 
			SELECT SUM(DL_EXPD_WHOT_QTY),
				   MAX(DL_EXPD_WHOT_ST_CD)
			INTO V_DIFF_WHOT_QTY,
			     V_EXPD_WHOT_ST_CD
			FROM TB_PDI_WHOT_INFO
			WHERE WHOT_YMD = V_CURR_YMD
			AND QLTY_VEHL_CD = P_VEHL_CD
			AND MDL_MDY_CD = P_MDL_MDY_CD
			AND LANG_CD = P_LANG_CD
			AND DL_EXPD_MDL_MDY_CD = P_EXPD_MDL_MDY_CD
			AND N_PRNT_PBCN_NO = P_N_PRNT_PBCN_NO
			AND DTL_SN = P_DTL_SN
			--AND DEL_YN = 'N' 
			;
			
			IF V_DIFF_WHOT_QTY IS NOT NULL THEN 
			  	 
				IF V_EXPD_WHOT_ST_CD = '05' THEN
				 	
				    V_DIFF_WHOT_QTY := ABS(V_DIFF_WHOT_QTY);
					
				ELSE
				 	 
					V_DIFF_WHOT_QTY := ABS(V_DIFF_WHOT_QTY) * (-1);
					 
				END IF;
				 
			    --재고데이터 업데이트 작업 수행 
			    PG_DATA.SP_PDI_IV_INFO_UPDATE(P_VEHL_CD,
											  P_MDL_MDY_CD,
							          		  P_LANG_CD,
											  P_EXPD_MDL_MDY_CD,
								      		  P_N_PRNT_PBCN_NO,
								      		  V_CURR_YMD,
								      		  V_DIFF_WHOT_QTY,
								      		  'N',
											  'N',
								      		  P_USER_EENO
								      		  , null -- 광주 임시
								      		  );
									  
				--출고항목 업데이트 작업 수행 
				UPDATE TB_PDI_WHOT_INFO
		    	SET DEL_YN = 'Y',
			    	UPDR_EENO = P_USER_EENO,
			    	MDFY_DTM = SYSDATE
				WHERE WHOT_YMD = V_CURR_YMD
	            AND QLTY_VEHL_CD = P_VEHL_CD
				AND MDL_MDY_CD = P_MDL_MDY_CD
		        AND LANG_CD = P_LANG_CD
				AND DL_EXPD_MDL_MDY_CD = P_EXPD_MDL_MDY_CD
		        AND N_PRNT_PBCN_NO = P_N_PRNT_PBCN_NO
		        AND DTL_SN = P_DTL_SN
				--AND DEL_YN = 'N' 
				; 
				
				----변경된 항목이 존재치 않으면 작업을 진행하지 않는다. 
				--IF SQL%NOTFOUND THEN
				   
				--   RETURN;
				   
				--END IF;
				
				--반출, 불량일 경우에는 세화재고에서도 빼주는 작업을 수행해야 한다. 
				IF V_EXPD_WHOT_ST_CD = '08' OR V_EXPD_WHOT_ST_CD = '09' THEN
		   	  
			  	   PG_SEWHA_IV_INFO.SP_SEWHA_WHOT_INFO_UPDATE2(P_VEHL_CD,
				   											   P_MDL_MDY_CD,
   					 									       P_LANG_CD,
															   P_EXPD_MDL_MDY_CD,
   					 									       P_N_PRNT_PBCN_NO,
														       V_CURR_YMD,
														       V_DIFF_WHOT_QTY * (-1),
														       P_USER_EENO);
															   
			    ELSIF V_EXPD_WHOT_ST_CD = '02' THEN
		   								  
			  	   --별도 요청정보 업데이트 (별도요청 정보 업데이트 작업을 취소한다.) 
			  	   PG_TOT_IV_INFO.SP_EXTRA_REQ_UPDATE(P_VEHL_CD, 
			   						                  P_MDL_MDY_CD, 
									                  P_LANG_CD, 
			   						                  P_N_PRNT_PBCN_NO,
												      '04',
													  NULL,
												      V_DIFF_WHOT_QTY * (-1),
												      P_USER_EENO
												      , 'N' -- 광주 임시
												      );
		        END IF;
		   
			END IF;
			
	   END SP_PDI_REVICE_INFO_DELETE;				 
	   
	   --PDI 재고정보 일배치 정리작업 수행 
       --반드시 현재일 시작시간에 돌려야 한다. 
	   PROCEDURE SP_PDI_IV_INFO_BATCH
	   IS
	   	 
		 STRT_DATE  DATE;
		 
		 V_CURR_CLS_YMD  VARCHAR2(8) := TO_CHAR(SYSDATE, 'YYYYMMDD');
		 V_PREV_CLS_YMD  VARCHAR2(8) := TO_CHAR(SYSDATE - 1, 'YYYYMMDD');
		 
		 BTCH_USER_EENO  CONSTANT VARCHAR2(7) := PG_DATA.BTCH_USER_EENO; -- 배치작업 담당자 코드 
		 
         V_QTY  NUMBER;
         V_CNT  NUMBER;
         
		 CURSOR PDI_IV_INFO IS SELECT QLTY_VEHL_CD,
		 					  	 	  DL_EXPD_MDL_MDY_CD,
									  LANG_CD,
									  N_PRNT_PBCN_NO,
									  IV_QTY
									  , NVL(PRDN_PLNT_CD,'N') AS PRDN_PLNT_CD  -- 광주 분리
		 					   FROM TB_PDI_IV_INFO
							   WHERE CLS_YMD = V_PREV_CLS_YMD
							   AND IV_QTY > 0;

		 
		 --전일의 재고내역을 기반으로 재고상세 내역을 다시 생성하는 방식 
		 CURSOR PDI_IV_DTL_INFO IS SELECT QLTY_VEHL_CD,
		 						  	 	  LANG_CD
		 						  	 	  , NVL(PRDN_PLNT_CD,'N') AS PRDN_PLNT_CD  -- 광주 분리
		 						   FROM TB_PDI_IV_INFO
								   WHERE CLS_YMD = V_PREV_CLS_YMD
								   AND IV_QTY > 0 
								   GROUP BY QLTY_VEHL_CD, LANG_CD, PRDN_PLNT_CD  -- 광주 분리
								   ORDER BY QLTY_VEHL_CD, LANG_CD;
											 
	   BEGIN
	   		
			STRT_DATE  := SYSDATE;
			
			FOR IV_LIST IN PDI_IV_INFO LOOP
				
                -- 배치 작업이 도는 시점에 입고확인이 이루어 질수 있으므로
                -- 그것을 체크해 주기 위해서 로직이 추가됨
                SELECT COUNT(*)
                INTO V_CNT
                FROM TB_PDI_IV_INFO
                WHERE CLS_YMD = V_CURR_CLS_YMD
                AND QLTY_VEHL_CD = IV_LIST.QLTY_VEHL_CD
                AND DL_EXPD_MDL_MDY_CD = IV_LIST.DL_EXPD_MDL_MDY_CD
                AND LANG_CD = IV_LIST.LANG_CD
                AND N_PRNT_PBCN_NO = IV_LIST.N_PRNT_PBCN_NO
                AND NVL(PRDN_PLNT_CD,'N') = IV_LIST.PRDN_PLNT_CD  -- 광주 분리
                ;
                
                --배치 작업이 도는 시점에 입고된 내역이 없음
                IF V_CNT = 0 THEN
                    
                    INSERT INTO TB_PDI_IV_INFO
                    (CLS_YMD,
                     QLTY_VEHL_CD,
                     DL_EXPD_MDL_MDY_CD,
                     LANG_CD,
                     N_PRNT_PBCN_NO,
                     IV_QTY,
                     CMPL_YN,
                     PPRR_EENO,
                     FRAM_DTM,
                     UPDR_EENO,
                     MDFY_DTM
                     , PRDN_PLNT_CD  -- 광주 분리
                    )
                    VALUES
                    (V_CURR_CLS_YMD,
                     IV_LIST.QLTY_VEHL_CD,
                     IV_LIST.DL_EXPD_MDL_MDY_CD,
                     IV_LIST.LANG_CD,
                     IV_LIST.N_PRNT_PBCN_NO,
                     IV_LIST.IV_QTY,
                     'N',
                     BTCH_USER_EENO,
                     SYSDATE,
                     BTCH_USER_EENO,
                     SYSDATE
                     , IV_LIST.PRDN_PLNT_CD  -- 광주 분리
                    );
                    
                    --전일의 재고내역을 기반으로 재고상세 내역을 다시 생성하는 방식의 경우 
                    --재고상세 테이블에 취급설명서연식과 같은 차종연식으로 데이터를 신규입력하여 준다.
                    --(왜냐하면 연식 연계 관계에서 취급설명서 연식과 연계된 차종 연식에는 
                    -- 취급설명서 연식과 동일한 차종연식은 반드시 있기 때문이다.) 
                    INSERT INTO TB_PDI_IV_INFO_DTL
                    (CLS_YMD,
                     QLTY_VEHL_CD,
                     MDL_MDY_CD,
                     LANG_CD,
                     DL_EXPD_MDL_MDY_CD,
                     N_PRNT_PBCN_NO,
                     IV_QTY,
                     SFTY_IV_QTY,
                     CMPL_YN,
                     PPRR_EENO,
                     FRAM_DTM,
                     UPDR_EENO,
                     MDFY_DTM
                     , PRDN_PLNT_CD  -- 광주 분리
                    )
                    VALUES
                    (V_CURR_CLS_YMD,
                     IV_LIST.QLTY_VEHL_CD,
                     IV_LIST.DL_EXPD_MDL_MDY_CD, --차종연식을 취급설명서 연식과 동일한 값으로 입력 
                     IV_LIST.LANG_CD,
                     IV_LIST.DL_EXPD_MDL_MDY_CD,
                     IV_LIST.N_PRNT_PBCN_NO,
                     IV_LIST.IV_QTY,
                     IV_LIST.IV_QTY,             --안전재고수량 역시 현재의 재고수량과 동일한 값으로 입력한다.(나중에 재고 재계산 시에 다시 계산됨) 
                     'N',
                     BTCH_USER_EENO,
                     SYSDATE,
                     BTCH_USER_EENO,
                     SYSDATE
                     , IV_LIST.PRDN_PLNT_CD  -- 광주 분리
                    );
                    
                ELSE
                    
                    SELECT NVL(SUM(IV_QTY), 0)
                    INTO V_QTY
                    FROM TB_PDI_IV_INFO
                    WHERE CLS_YMD = V_CURR_CLS_YMD
                    AND QLTY_VEHL_CD = IV_LIST.QLTY_VEHL_CD
                    AND DL_EXPD_MDL_MDY_CD = IV_LIST.DL_EXPD_MDL_MDY_CD
                    AND LANG_CD = IV_LIST.LANG_CD
                    AND N_PRNT_PBCN_NO = IV_LIST.N_PRNT_PBCN_NO
                    AND IV_SCN_CD = 'Y' --배치가 도는 시점에 입고된 데이터인지의 여부를 확인 
                    AND NVL(PRDN_PLNT_CD,'N') = IV_LIST.PRDN_PLNT_CD  -- 광주 분리
                    ;
                    
                    IF V_QTY > 0 THEN
                    
                        --배치가 도는 시점에 입고로 잡을 경우를 대비하여 로직 수정함
                        UPDATE TB_PDI_IV_INFO
                        SET IV_QTY = (IV_LIST.IV_QTY + V_QTY),
                            CMPL_YN = 'N',
                            UPDR_EENO = BTCH_USER_EENO,
                            MDFY_DTM = SYSDATE,
                            IV_SCN_CD = NULL
                        WHERE CLS_YMD = V_CURR_CLS_YMD
                        AND QLTY_VEHL_CD = IV_LIST.QLTY_VEHL_CD
                        AND DL_EXPD_MDL_MDY_CD = IV_LIST.DL_EXPD_MDL_MDY_CD
                        AND LANG_CD = IV_LIST.LANG_CD
                        AND N_PRNT_PBCN_NO = IV_LIST.N_PRNT_PBCN_NO
                        AND NVL(PRDN_PLNT_CD,'N') = IV_LIST.PRDN_PLNT_CD  -- 광주 분리
                        ;
                        
                        UPDATE TB_PDI_IV_INFO_DTL
                        SET IV_QTY = (IV_LIST.IV_QTY + V_QTY),
                            SFTY_IV_QTY = (IV_LIST.IV_QTY + V_QTY),
                            CMPL_YN = 'N',
                            UPDR_EENO = BTCH_USER_EENO,
                            MDFY_DTM = SYSDATE
                        WHERE CLS_YMD = V_CURR_CLS_YMD
                        AND QLTY_VEHL_CD = IV_LIST.QLTY_VEHL_CD
                        AND MDL_MDY_CD = IV_LIST.DL_EXPD_MDL_MDY_CD
                        AND LANG_CD = IV_LIST.LANG_CD
                        AND DL_EXPD_MDL_MDY_CD = IV_LIST.DL_EXPD_MDL_MDY_CD
                        AND N_PRNT_PBCN_NO = IV_LIST.N_PRNT_PBCN_NO
                        AND NVL(PRDN_PLNT_CD,'N') = IV_LIST.PRDN_PLNT_CD  -- 광주 분리
                        ;
                    
                    END IF;
                    
                END IF;
                
			END LOOP;
			
			UPDATE TB_PDI_IV_INFO
			SET CMPL_YN = 'Y',
                IV_SCN_CD = NULL
			WHERE CLS_YMD = V_PREV_CLS_YMD;
			
			/*** 
			--전일의 재고상세 내역을 복사하는 방식의 경우 
			
			FOR IV_DTL_LIST IN PDI_IV_DTL_INFO LOOP

				INSERT INTO TB_PDI_IV_INFO_DTL
				(CLS_YMD,
				 QLTY_VEHL_CD,
				 MDL_MDY_CD,
				 LANG_CD,
				 DL_EXPD_MDL_MDY_CD,
				 N_PRNT_PBCN_NO,
				 IV_QTY,
				 SFTY_IV_QTY,
				 CMPL_YN,
				 PPRR_EENO,
				 FRAM_DTM,
				 UPDR_EENO,
				 MDFY_DTM
				)
				VALUES
				(V_CURR_CLS_YMD,
				 IV_DTL_LIST.QLTY_VEHL_CD,
				 IV_DTL_LIST.MDL_MDY_CD,
				 IV_DTL_LIST.LANG_CD,
				 IV_DTL_LIST.DL_EXPD_MDL_MDY_CD,
				 IV_DTL_LIST.N_PRNT_PBCN_NO,
				 IV_DTL_LIST.IV_QTY,
				 IV_DTL_LIST.SFTY_IV_QTY,
				 'N',
				 BTCH_USER_EENO,
				 SYSDATE,
				 BTCH_USER_EENO,
				 SYSDATE
				);
				
			END LOOP;
			***/
			
			--전일의 재고내역을 기반으로 재고상세 내역을 다시 생성하는 방식의 경우 
			FOR IV_DTL_LIST IN PDI_IV_DTL_INFO LOOP
				
				PG_DATA.SP_RECALCULATE_PDI_IV_DTL4(V_CURR_CLS_YMD,
												   IV_DTL_LIST.QLTY_VEHL_CD,
												   IV_DTL_LIST.LANG_CD,
												   BTCH_USER_EENO
												   , IV_DTL_LIST.PRDN_PLNT_CD												   
												   );
			END LOOP;
			
			UPDATE TB_PDI_IV_INFO_DTL
			SET CMPL_YN = 'Y'
			WHERE CLS_YMD = V_PREV_CLS_YMD;
			
			COMMIT;

		 	PG_INTERFACE_APS.WRITE_BATCH_LOG('PDI재고배치작업', STRT_DATE, 'S', '배치처리완료');

		 EXCEPTION
		     WHEN OTHERS THEN
			     ROLLBACK;
				 PG_INTERFACE_APS.WRITE_BATCH_LOG('PDI재고배치작업', STRT_DATE, 'F', '배치처리실패:[' || SQLERRM || ']');
				 
	   END SP_PDI_IV_INFO_BATCH;
	   
	   --글로비스 자동 입고 처리 배치 작업 
	   PROCEDURE SP_GLOVIS_WHSN_INFO_BATCH
	   IS
	   	 CURSOR SEWAH_WHOT_LIST IS SELECT QLTY_VEHL_CD,
	   	 						   		  DL_EXPD_MDL_MDY_CD,
	   									  LANG_CD,
	   									  N_PRNT_PBCN_NO,
	   									  DTL_SN,
	   									  MDL_MDY_CD,
	   									  '01' AS DL_EXPD_WHSN_ST_CD,
	   									  NVL(DL_EXPD_BOX_QTY, 0) AS DL_EXPD_BOX_QTY,
	   									  RQ_QTY AS WHSN_QTY,
	   									  0 AS DEEI1_QTY,
	   									  'SYSTEM' AS USER_EENO
	   									  , PRDN_PLNT_CD  -- 광주분리
								   FROM TB_SEWHA_WHOT_INFO
								   WHERE DL_EXPD_RQ_SCN_CD = '01'
								   AND CMPL_YN = 'N'
								   AND DEL_YN  = 'N'
								   AND LANG_CD = 'KO';
								   
	   BEGIN
	   		
			FOR SEWAH_WHOT_INFO IN SEWAH_WHOT_LIST LOOP
				
				SP_PDI_WHSN_INFO_SAVE(SEWAH_WHOT_INFO.QLTY_VEHL_CD, 
	   			 					  SEWAH_WHOT_INFO.MDL_MDY_CD,
								      SEWAH_WHOT_INFO.LANG_CD,
									  SEWAH_WHOT_INFO.DL_EXPD_MDL_MDY_CD,
								      SEWAH_WHOT_INFO.N_PRNT_PBCN_NO,
								      SEWAH_WHOT_INFO.DTL_SN,
								      SEWAH_WHOT_INFO.DL_EXPD_WHSN_ST_CD,
								      SEWAH_WHOT_INFO.DL_EXPD_BOX_QTY,
								      SEWAH_WHOT_INFO.WHSN_QTY,
								      SEWAH_WHOT_INFO.DEEI1_QTY,
								      SEWAH_WHOT_INFO.USER_EENO
								      , SEWAH_WHOT_INFO.PRDN_PLNT_CD    -- 광주분리 
								      );
									   
			END LOOP;
			
			COMMIT;
			
	   		EXCEPTION
		     WHEN OTHERS THEN
			     ROLLBACK;
				 
	   END SP_GLOVIS_WHSN_INFO_BATCH;
	   
END PG_PDI_IV_INFO;