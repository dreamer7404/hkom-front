CREATE OR REPLACE PACKAGE KOMMS_ADM.PG_PRNT_REQ_INFO AS

	   TYPE REFCUR IS REF CURSOR;

	   --발간번호 리스트 조회
	   PROCEDURE SP_GET_PBCN_LIST(P_VEHL_CD	        VARCHAR2,
	   			                  P_EXPD_MDL_MDY_CD VARCHAR2, --(주의) 취급설명서 연식코드임
				                  P_LANG_CD	        VARCHAR2,
				                  P_PRNT_PBCN_NO    VARCHAR2,
				                  RS OUT REFCUR);

	   --제작의뢰 내역 조회
	   PROCEDURE SP_GET_PRNT_REQ_INFO(P_VEHL_CD	       VARCHAR2,
	   			 	                  P_MDL_MDY_CD     VARCHAR2,
					                  P_LANG_CD	       VARCHAR2,
					                  P_N_PRNT_PBCN_NO VARCHAR2,
					                  RS OUT REFCUR);

	   --체크리스트 정보 조회
	   PROCEDURE SP_GET_CHK_LIST(P_VEHL_CD	        VARCHAR2,
	   			                 P_MDL_MDY_CD       VARCHAR2,
				                 P_LANG_CD	        VARCHAR2,
				                 P_N_PRNT_PBCN_NO   VARCHAR2,
				                 P_OLD_PRNT_PBCN_NO VARCHAR2,
				                 RS OUT REFCUR);

	   --제작의뢰 정보 삭제
	   PROCEDURE SP_PRNT_REQ_INFO_DEL(P_N_PRNT_PBCN_NO VARCHAR2,
	   			 	                  P_USER_EENO      VARCHAR2);

	   --체크리스트 정보 삭제
	   PROCEDURE SP_CHKLIST_DTL_INFO_DEL(P_EXPD_ALTR_NO   VARCHAR2,
	   			 	                     P_VEHL_CD	      VARCHAR2,
                                         P_LANG_CD	      VARCHAR2,
	   			 	                     P_N_PRNT_PBCN_NO VARCHAR2,
	   			 	                     P_USER_EENO      VARCHAR2);

	   --제작의뢰 내역 저장
	   PROCEDURE SP_PRNT_REQ_INFO_SAVE(P_N_PRNT_PBCN_NO      VARCHAR2,
                                       P_QLTY_VEHL_CD        VARCHAR2,
                                       P_MDL_MDY_CD          VARCHAR2,
                                       P_LANG_CD             VARCHAR2,
                                       P_PRNT_PARR_YMD       VARCHAR2,
                                       P_DLVG_PARR_YMD       VARCHAR2,
                                       P_I_WAY_CD            VARCHAR2,
                                       P_PRNT_PARR_QTY       NUMBER,
                                       P_PRNT_WAY_CD         VARCHAR2,
                                       P_DEPQ1_CD            VARCHAR2,
                                       P_OLD_PRNT_PBCN_NO    VARCHAR2,
                                       P_PG_MGN_SBC          VARCHAR2,
                                       P_PG_NL               NUMBER,
                                       P_OORD_EDIT_PG_NL     NUMBER,
                                       P_MDFY_PG_NL          NUMBER,
                                       P_PRTL_IMTR_SBC       VARCHAR2,
                                       P_N1AFP2_ADR          VARCHAR2,
                                       P_N2AFP2_ADR          VARCHAR2,
                                       P_GRN_DOC_NL          NUMBER,
                                       P_DEPC1_YN            VARCHAR2,
				       				   P_CRGR_EENO	         VARCHAR2,
				       				   P_STATE      	     VARCHAR2,
                                       P_USER_EENO           VARCHAR2,
                                       P_PRNT_WAY_CD2        VARCHAR2);

	   --체크리스트 정보 저장
	   PROCEDURE SP_CHKLIST_DTL_INFO_SAVE(P_EXPD_ALTR_NO   VARCHAR2,
	   			 	                      P_VEHL_CD	       VARCHAR2,
                                          P_LANG_CD	       VARCHAR2,
                                          P_N_PRNT_PBCN_NO VARCHAR2,
					      				  P_STATE	       VARCHAR2,
	   			 	      				  P_USER_EENO      VARCHAR2);

	   --제작의뢰 정보 저장시의 상태값 체크
	   FUNCTION FU_CHECK_RDCS_ST_CD(P_N_PRNT_PBCN_NO VARCHAR2,
	   				                P_STATE          VARCHAR2,
					                P_RDCS_ST_CD OUT VARCHAR2)RETURN VARCHAR2;

END PG_PRNT_REQ_INFO;