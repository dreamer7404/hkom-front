CREATE OR REPLACE PACKAGE BODY KOMMS_ADM.PG_INTERFACE_APS AS

/**********************************************************/
	   --기아 APS 인터페이스(외부 호출)
	   PROCEDURE APS_INTERFACE_KMC
       IS
		 STRT_DATE  DATE;
		 CURR_YMD   VARCHAR2(8);
		 V_STATE1   VARCHAR2(1);
		 V_STATE2   VARCHAR2(1);

	   BEGIN

		 STRT_DATE  := SYSDATE;
		 CURR_YMD   := TO_CHAR(SYSDATE, 'YYYYMMDD');

		 V_STATE1 := APS_ODR_INTERFACE_KMC(CURR_YMD);
		 V_STATE2 := APS_PROD_INTERFACE_KMC(CURR_YMD);

		 IF V_STATE1 = 'N' AND V_STATE2 = 'N' THEN
		 	--WRITE_BATCH_EXE_LOG('APS배치작업_KMC', SYSDATE, 'S', 'APS_INTERFACE_KMC : 처리할 데이터가 없음.');
			RETURN;
		 END IF;

		 COMMIT;

		 WRITE_BATCH_LOG('APS배치작업_KMC', STRT_DATE, 'S', '배치처리완료');

		 --미지정 국가 항목 메일 전송
		 SEND_NOAPIM_NATL_INFO_MAIL(EXPD_CO_CD_KMC, '01', CURR_YMD);

		 EXCEPTION
		     WHEN OTHERS THEN ROLLBACK;
			 WRITE_BATCH_LOG('APS배치작업_KMC', STRT_DATE, 'F', '배치처리실패:[' || SQLERRM || ']');

       END APS_INTERFACE_KMC;
/**********************************************************/
/**********************************************************/
	   --기아 날짜가 변경될 경우 데이터 Summary 작업 수행(외부 호출, 오라클 스케쥴링)
	   PROCEDURE APS_INTERFACE_DATE_KMC
	   IS

	   	 STRT_DATE  DATE;
		 CURR_YMD   VARCHAR2(8);

	   BEGIN

		 STRT_DATE  := SYSDATE;

   		 CURR_YMD := TO_CHAR(SYSDATE, 'YYYYMMDD');

   		 --전일의 데이터를 기준으로 취합작업을 수행한다.

   		 --오더정보 취합 작업 수행
   		 GET_APS_ODR_SUM_DTL(CURR_YMD,
		 					 TO_CHAR(TO_DATE(CURR_YMD, 'YYYYMMDD') - 1, 'YYYYMMDD'),
   							 EXPD_CO_CD_KMC);

   		 --생산계획정보 취합 작업 수행
   		 GET_APS_PROD_SUM_DTL(CURR_YMD,
		 					  TO_CHAR(TO_DATE(CURR_YMD, 'YYYYMMDD') - 1, 'YYYYMMDD'),
   							  EXPD_CO_CD_KMC);

   		 COMMIT;

   		 PG_INTERFACE_APS.WRITE_BATCH_LOG('APS일자변경배치작업_KMC', STRT_DATE, 'S', '배치처리완료');

   		 EXCEPTION
   		     WHEN OTHERS THEN
   			     ROLLBACK;
   				 PG_INTERFACE_APS.WRITE_BATCH_LOG('APS일자변경배치작업_KMC', STRT_DATE, 'F', '배치처리실패:[' || SQLERRM || ']');

	   END APS_INTERFACE_DATE_KMC;
/**********************************************************/
/**********************************************************/
	   --KMC 오더정보 배치작업 수행
	   FUNCTION APS_ODR_INTERFACE_KMC(CURR_YMD IN VARCHAR2)RETURN VARCHAR2

	   IS

		 V_APS_STAT VARCHAR2(1);
		 V_FNH_STAT VARCHAR2(1);
		 V_STATE    VARCHAR2(1);

	   BEGIN

         --WRITE_BATCH_EXE_LOG('APS배치작업_KMC', SYSDATE, 'S', 'APS_ODR_INTERFACE_KMC : #1.');
		 V_APS_STAT := 'Y';--GET_APS_ODR_EXIST_YN(CURR_YMD, EXPD_CO_CD_KMC);
         --WRITE_BATCH_EXE_LOG('APS배치작업_KMC', SYSDATE, 'S', 'APS_ODR_INTERFACE_KMC : #2.');
		 V_FNH_STAT := GET_BTCH_ODR_FNH_YN(CURR_YMD, EXPD_CO_CD_KMC);
         --WRITE_BATCH_EXE_LOG('APS배치작업_KMC', SYSDATE, 'S', 'APS_ODR_INTERFACE_KMC : #3.');

		 --APS 데이터가 현재일자의 데이터이며 현재일에 한번도 배치작업을 수행하지 않은 경우라면
		 --배치작업을 수행한다.
		 IF V_APS_STAT = 'Y' AND V_FNH_STAT = 'N' THEN

         --WRITE_BATCH_EXE_LOG('APS배치작업_KMC', SYSDATE, 'S', 'APS_ODR_INTERFACE_KMC : #4.');
		 		LOAD_APS_ODR_INFO_KMC(CURR_YMD);
         --WRITE_BATCH_EXE_LOG('APS배치작업_KMC', SYSDATE, 'S', 'APS_ODR_INTERFACE_KMC : #5.');

				--구버전
				--GET_APS_ODR_SUM(CURR_YMD, EXPD_CO_CD_KMC);

				GET_APS_ODR_SUM2(CURR_YMD, EXPD_CO_CD_KMC);
         --WRITE_BATCH_EXE_LOG('APS배치작업_KMC', SYSDATE, 'S', 'APS_ODR_INTERFACE_KMC : #6.');

				SAVE_ODR_BTCH_FNH_INFO(CURR_YMD, EXPD_CO_CD_KMC);
         --WRITE_BATCH_EXE_LOG('APS배치작업_KMC', SYSDATE, 'S', 'APS_ODR_INTERFACE_KMC : #7.');

				V_STATE := 'Y';

		 ELSE
         --WRITE_BATCH_EXE_LOG('APS배치작업_KMC', SYSDATE, 'S', 'APS_ODR_INTERFACE_KMC : #8.');

				V_STATE := 'N';

		 END IF;

         --WRITE_BATCH_EXE_LOG('APS배치작업_KMC', SYSDATE, 'S', 'APS_ODR_INTERFACE_KMC : #9.');
		 RETURN V_STATE;

	   END APS_ODR_INTERFACE_KMC;
/**********************************************************/
/**********************************************************/
	   --KMC 생산계획 정보 배치작업 수행
	   FUNCTION APS_PROD_INTERFACE_KMC(CURR_YMD IN VARCHAR2)RETURN VARCHAR2
	   IS

		 V_APS_STAT  VARCHAR2(1);
		 V_FNH_STAT  VARCHAR2(1);

		 V_STATE     VARCHAR2(1);

	   BEGIN

		 V_APS_STAT  := GET_APS_PROD_EXIST_YN(CURR_YMD, EXPD_CO_CD_KMC);
		 V_FNH_STAT  := GET_BTCH_PROD_FNH_YN(CURR_YMD, EXPD_CO_CD_KMC);

		 --APS 데이터가 현재일자의 데이터이며 현재일에 한번도 배치작업을 수행하지 않은 경우라면
		 --배치작업을 수행한다.
		 IF V_APS_STAT = 'Y' AND V_FNH_STAT = 'N' THEN

		 	 	LOAD_APS_PROD_INFO_KMC(CURR_YMD);

				--구버전
		        --GET_APS_PROD_SUM(CURR_YMD, EXPD_CO_CD_KMC);

				GET_APS_PROD_SUM2(CURR_YMD, EXPD_CO_CD_KMC);

			    SAVE_PROD_BTCH_FNH_INFO(CURR_YMD, EXPD_CO_CD_KMC);

				V_STATE := 'Y';

		 ELSE

				 V_STATE := 'N';

		 END IF;

		 RETURN V_STATE;

	   END APS_PROD_INTERFACE_KMC;
/**********************************************************/
/**********************************************************/
       PROCEDURE LOAD_APS_ODR_INFO_KMC(CURR_YMD IN VARCHAR2)
	   IS

		 CNT NUMBER;

		 V_APL_FNH_YMD VARCHAR2(8);

		 V_QLTY_VEHL_CD TB_APS_ODR_INFO.QLTY_VEHL_CD%TYPE;
		 V_MDL_MDY_CD	TB_APS_ODR_INFO.MDL_MDY_CD%TYPE;
		 V_EXPD_NAT_CD	TB_APS_ODR_INFO.DL_EXPD_NAT_CD%TYPE;

		 CURSOR APS_ODR_INFO_KMC IS

		        SELECT PM03F_PLNT,
		 			   SUBSTR(PM03F_MODL, 1, 2) AS PM03F_MODL,
			   	       PM03F_USEE,
			   	       PM03F_PACK,
			   	       PM03F_USEE || PM03F_PACK || PM03F_REGN || PM03F_SERL AS PM03F_ORDR,
			   	       PM03F_DIST,
			   	  	   PM03F_REGN,
			   	       MAX(PM03F_BMDL) AS PM03F_BMDL,
			   	       MAX(PM03F_DEST) AS PM03F_DEST,
			   	       SUM(PM03F_ORDQ) AS PM03F_ORDQ,              --오더수량
			   	       SUM(PM03F_ORDQ - PM03F_PT08) AS PM03F_PLAN, --미생산 오더수량(오더수량 - 지금까지의 생산수량)
				       MAX(PM03F_OCNN) AS PM03F_OCNN,
			   	       MAX(PM03F_VERS) AS PM03F_VERS
	   	          FROM SY_PMS03FB_KMC
				 WHERE PM03F_USEE = 'E'      --오더정보는 수출만 가져오도록 한다.
 				   AND PM03F_DEST NOT LIKE '%X_'  --[2008-12.11] 용도차 구분 방식 변경(REGN은 체크하지 않는다.)
                                                  --용도차는 제외한다.(조건추가)
                 --  AND PM03F_REGN <> 'X'
				 GROUP BY PM03F_PLNT, SUBSTR(PM03F_MODL, 1, 2), PM03F_USEE,
						  PM03F_PACK, PM03F_REGN, PM03F_SERL, PM03F_DIST
				 ;

	   BEGIN
			/*****/
			UPDATE TB_APS_ODR_INFO A
			   SET A.APL_FNH_YMD = TO_CHAR(TO_DATE(CURR_YMD, 'YYYYMMDD') - 1, 'YYYYMMDD')
			 WHERE A.APL_STRT_YMD < CURR_YMD
			   AND A.APL_FNH_YMD >= CURR_YMD
			   AND EXISTS (
			               SELECT 'EXIST'
                             FROM TB_VEHL_MGMT
			                WHERE QLTY_VEHL_CD = A.QLTY_VEHL_CD
			                  AND DL_EXPD_CO_CD = EXPD_CO_CD_KMC
		                      AND ROWNUM <= 1
		                  );

			--현재일에 순수하게 입력된 항목은 삭제하도록 한다.
			DELETE FROM TB_APS_ODR_INFO A
			 WHERE A.APL_STRT_YMD = CURR_YMD
			   AND A.APL_FNH_YMD >= CURR_YMD
			   AND EXISTS (
			               SELECT 'EXIST'
                             FROM TB_VEHL_MGMT
			                WHERE QLTY_VEHL_CD = A.QLTY_VEHL_CD
			                  AND DL_EXPD_CO_CD = EXPD_CO_CD_KMC
		                      AND ROWNUM <= 1
		                   );
			/*****/

			FOR ODR_LIST IN APS_ODR_INFO_KMC LOOP

				--차종코드, 월팩, 목적국에 해당하는 품질차종코드, 연식, 취급설명서국가코드를 얻어온다.
				GET_MANUAL_INFO(CURR_YMD,
								EXPD_CO_CD_KMC,
				                ODR_LIST.PM03F_MODL,
								ODR_LIST.PM03F_PACK,
								ODR_LIST.PM03F_DEST,
								ODR_LIST.PM03F_BMDL,
								V_QLTY_VEHL_CD,
								V_MDL_MDY_CD,
								V_EXPD_NAT_CD);

				SELECT MAX(APL_FNH_YMD)
				  INTO V_APL_FNH_YMD
				  FROM TB_APS_ODR_INFO A
				 WHERE A.PRDN_ORD_NO = ODR_LIST.PM03F_ORDR
			       AND A.DYTM_PLN_NAT_CD = ODR_LIST.PM03F_DIST
			       AND A.PRDN_PLNT_CD = ODR_LIST.PM03F_PLNT
				   AND A.DYTM_PLN_VEHL_CD = ODR_LIST.PM03F_MODL
			       AND A.USF_CD = ODR_LIST.PM03F_USEE
			       AND A.MO_PACK_CD = ODR_LIST.PM03F_PACK
				   AND A.DL_EXPD_CO_CD = EXPD_CO_CD_KMC
				   AND A.APL_STRT_YMD <= CURR_YMD;

				IF V_APL_FNH_YMD IS NULL THEN

				   --지금까지 한번도 추가되지 않은 경우(무조건 Insert 해 준다.)

				   INSERT INTO TB_APS_ODR_INFO
   		    	   (PRDN_ORD_NO,
   			 		DYTM_PLN_NAT_CD,
 			        PRDN_PLNT_CD,
   				   	DYTM_PLN_VEHL_CD,
   			 		USF_CD,
   			 		MO_PACK_CD,
 				    DL_EXPD_CO_CD,
 			        APL_STRT_YMD,
 				    APL_FNH_YMD,
   			 		DL_EXPD_REGN_CD,
   			 		BASC_MDL_CD,
   			 		DEST_NAT_CD,
   			 		ORD_QTY,
   			 		PRDN_PLN_QTY,
   			 		PRDN_OCN_CD,
   			 		VER_CD,
   			 		FRAM_DTM,
					QLTY_VEHL_CD,
					MDL_MDY_CD,
					DL_EXPD_NAT_CD
   				   )
   				   VALUES
   				   (ODR_LIST.PM03F_ORDR,
   					ODR_LIST.PM03F_DIST,
 			        ODR_LIST.PM03F_PLNT,
   				   	ODR_LIST.PM03F_MODL,
   					ODR_LIST.PM03F_USEE,
   					ODR_LIST.PM03F_PACK,
 				    EXPD_CO_CD_KMC,
 			        CURR_YMD,
 				    CURR_YMD,  --적용완료일을 현재일로 해준다.
   					ODR_LIST.PM03F_REGN,
   					ODR_LIST.PM03F_BMDL,
   					ODR_LIST.PM03F_DEST,
   					ODR_LIST.PM03F_ORDQ,
   					ODR_LIST.PM03F_PLAN,
   					ODR_LIST.PM03F_OCNN,
   					ODR_LIST.PM03F_VERS,
   					SYSDATE,
					V_QLTY_VEHL_CD,
					V_MDL_MDY_CD,
					V_EXPD_NAT_CD
   				   );

				ELSE

				   --바로이전의 데이터가 변경되지 않은 경우에는 종료일 업데이트만 해준다.
				   --[2009-04-16]변경. 데이터가 같은지 여부 확인하는 로직에 연식도 추가해 준다.
				   --(PK 조건이 같은 경우에도 특별하게 연식을 발부하는 경우가 있기 때문이다.(GET_MDL_MDY_CD_EXTRA 프로시저 참고))

   				   UPDATE TB_APS_ODR_INFO A
   			 	      SET APL_FNH_YMD = CURR_YMD, --적용완료일을 현재일로 해준다.
				          QLTY_VEHL_CD = V_QLTY_VEHL_CD,
/** 배치 재실행 시 배치 오류날 경우 주석해제하고 실행
					      MDL_MDY_CD = V_MDL_MDY_CD,
					      ORD_QTY = ODR_LIST.PM03F_ORDQ,
					      PRDN_PLN_QTY = ODR_LIST.PM03F_PLAN,
*/
					      DL_EXPD_NAT_CD = V_EXPD_NAT_CD
   				    WHERE A.PRDN_ORD_NO = ODR_LIST.PM03F_ORDR
   			          AND A.DYTM_PLN_NAT_CD = ODR_LIST.PM03F_DIST
   				      AND A.PRDN_PLNT_CD = ODR_LIST.PM03F_PLNT
   				      AND A.DYTM_PLN_VEHL_CD = ODR_LIST.PM03F_MODL
   			          AND A.USF_CD = ODR_LIST.PM03F_USEE
   			          AND A.MO_PACK_CD = ODR_LIST.PM03F_PACK
   				      AND A.DL_EXPD_CO_CD = EXPD_CO_CD_KMC
   				      AND A.APL_STRT_YMD <= CURR_YMD
   			          AND A.APL_FNH_YMD = V_APL_FNH_YMD
/** 배치 재실행 시 배치 오류날 경우 주석처리하고 실행 */
   				      AND A.ORD_QTY = ODR_LIST.PM03F_ORDQ
   			          AND A.PRDN_PLN_QTY = ODR_LIST.PM03F_PLAN
				      AND NVL(A.MDL_MDY_CD, 'NULL') = NVL(V_MDL_MDY_CD, 'NULL')
				      ;

   				   --바로이전의 데이터와 현재의 데이터 수량이 다른경우에는 Insert 해 준다.
   				   IF SQL%NOTFOUND THEN

   					  INSERT INTO TB_APS_ODR_INFO
      		    	      (PRDN_ORD_NO,
      			 		   DYTM_PLN_NAT_CD,
    			           PRDN_PLNT_CD,
      				   	   DYTM_PLN_VEHL_CD,
      			 		   USF_CD,
      			 		   MO_PACK_CD,
    				       DL_EXPD_CO_CD,
    			           APL_STRT_YMD,
    				       APL_FNH_YMD,
      			 		   DL_EXPD_REGN_CD,
      			 		   BASC_MDL_CD,
      			 		   DEST_NAT_CD,
      			 		   ORD_QTY,
      			 		   PRDN_PLN_QTY,
      			 		   PRDN_OCN_CD,
      			 		   VER_CD,
      			 		   FRAM_DTM,
						   QLTY_VEHL_CD,
						   MDL_MDY_CD,
						   DL_EXPD_NAT_CD
      				      )
      				      VALUES
      				      (ODR_LIST.PM03F_ORDR,
      					   ODR_LIST.PM03F_DIST,
    			           ODR_LIST.PM03F_PLNT,
      				   	   ODR_LIST.PM03F_MODL,
      					   ODR_LIST.PM03F_USEE,
      					   ODR_LIST.PM03F_PACK,
    				       EXPD_CO_CD_KMC,
    			           CURR_YMD,
    				       CURR_YMD,  --적용완료일을 현재일로 해준다.
      					   ODR_LIST.PM03F_REGN,
      					   ODR_LIST.PM03F_BMDL,
      					   ODR_LIST.PM03F_DEST,
      					   ODR_LIST.PM03F_ORDQ,
      					   ODR_LIST.PM03F_PLAN,
      					   ODR_LIST.PM03F_OCNN,
      					   ODR_LIST.PM03F_VERS,
      					   SYSDATE,
						   V_QLTY_VEHL_CD,
						   V_MDL_MDY_CD,
						   V_EXPD_NAT_CD
      				      );

   				   END IF;

				END IF;

			END LOOP;

	   END LOAD_APS_ODR_INFO_KMC;
/**********************************************************/
/**********************************************************/
	   PROCEDURE LOAD_APS_PROD_INFO_KMC(CURR_YMD IN VARCHAR2)
	   IS

	   	 CNT NUMBER;

		 V_APL_FNH_YMD VARCHAR2(8);

		 V_LAST_YMD VARCHAR2(8) := TO_CHAR(LAST_DAY(TO_DATE(CURR_YMD, 'YYYYMMDD')), 'YYYYMMDD');
		 V_2WEK_YMD VARCHAR2(8) := TO_CHAR(TO_DATE(CURR_YMD, 'YYYYMMDD') + 14, 'YYYYMMDD');

		 --2주후 날짜와 현재월의 마지막날짜중에 큰값을 사용한다.
		 V_TO_YMD   VARCHAR2(8) := CASE WHEN V_LAST_YMD > V_2WEK_YMD THEN V_LAST_YMD ELSE V_2WEK_YMD END;

		 V_QLTY_VEHL_CD TB_APS_PROD_PLAN_INFO.QLTY_VEHL_CD%TYPE;
		 V_MDL_MDY_CD	TB_APS_PROD_PLAN_INFO.MDL_MDY_CD%TYPE;
		 V_EXPD_NAT_CD	TB_APS_PROD_PLAN_INFO.DL_EXPD_NAT_CD%TYPE;

		 CURSOR APS_PROD_INFO_KMC IS SELECT A.PS06A_PLGU,
                                        	A.PS06A_BASE,
                                        	A.PS06A_PLNT,
                                        	A.PS06A_MODL,
                                        	SUBSTR(TO_CHAR(A.PS06A_EDAT), 1, 8) AS PS06A_EDAT,
                                        	A.PS06A_ORDR,
                                        	A.PS06A_DIST,
                                        	A.PS06A_PQTY,
                                        	SUBSTR(A.DCSN_YN, 1, 1) AS DCSN_YN,
                                        	SUBSTR(TO_CHAR(A.DCSN_YMD), 1, 8) AS DCSN_YMD,
                                        	SUBSTR(B.PM03F_DEST, 1, 5) AS PM03F_DEST,
 											B.PM03F_PACK,
 											B.PM03F_REGN,
											B.PM03F_BMDL
                                     FROM (SELECT A.PS06A_PLGU,
                                        	 	  A.PS06A_BASE,
                                        		  A.PS06A_PLNT,
                                        		  A.PS06A_MODL,
                                        		  A.PS06A_EDAT,
                                        		  A.PS06A_ORDR,
                                        		  A.PS06A_DIST,
                                        	   	  SUM(A.PS06A_PQTY) AS PS06A_PQTY,
                                               	  MIN(CASE WHEN (A.PS06A_PDAT <= B.PS07H_CRFD) THEN 'Y' ELSE 'N' END) AS DCSN_YN,
                                               	  MAX(B.PS07H_CRFD) AS DCSN_YMD
                                           FROM SY_PSE06AC_KMC A,
                                                SY_PSE07HB_KMC B
                                           WHERE A.PS06A_PLNT = B.PS07H_PLNT
                                           AND A.PS06A_PLGU = 'A'
                                           AND A.PS06A_BASE = 'S' -- Sign Off 된 데이터만을 가져온다.
										   AND SUBSTR(TO_CHAR(A.PS06A_EDAT), 1, 8) BETWEEN CURR_YMD AND V_TO_YMD
                                           GROUP BY A.PS06A_PLGU,
                                        	  		A.PS06A_BASE,
                                        			A.PS06A_PLNT,
                                        			A.PS06A_MODL,
                                        			A.PS06A_EDAT,
                                        			A.PS06A_ORDR,
                                        			A.PS06A_DIST
                                          ) A,
                                          (SELECT PM03F_PLNT,
                                        		  SUBSTR(PM03F_MODL, 1, 2) AS PM03F_MODL,
                                        		  PM03F_DIST,
 												  PM03F_PACK,
 												  PM03F_REGN,
                                        		  PM03F_USEE || PM03F_PACK || PM03F_REGN || PM03F_SERL AS PM03F_ORDR,
												  --내수인 경우에는 A99VA로 변경해 가져온다.
                                                  DECODE(PM03F_USEE, 'D', EXPD_DOM_NAT_CD, MAX(PM03F_DEST)) AS PM03F_DEST,
												  MAX(PM03F_BMDL) AS PM03F_BMDL
                                           FROM SY_PMS03FB_KMC
										   --[2008-12.11] 용도차 구분 방식 변경(REGN은 체크하지 않는다.)
										   --용도차는 제외한다.(조건추가)
										   WHERE PM03F_DEST NOT LIKE '%X_'
										   --AND PM03F_REGN <> 'X'
                                           GROUP BY PM03F_PLNT,
                                        	        SUBSTR(PM03F_MODL, 1, 2),
                                        			PM03F_USEE,
                                        			PM03F_PACK,
                                        			PM03F_REGN,
                                        			PM03F_SERL,
                                        			PM03F_DIST
                                          ) B
                                     WHERE A.PS06A_PLNT = B.PM03F_PLNT
                                     AND A.PS06A_DIST = B.PM03F_DIST
                                     AND A.PS06A_MODL = B.PM03F_MODL
                                     AND A.PS06A_ORDR = B.PM03F_ORDR;

	   BEGIN

			/*****/
			UPDATE TB_APS_PROD_PLAN_INFO A
			SET A.APL_FNH_YMD = TO_CHAR(TO_DATE(CURR_YMD, 'YYYYMMDD') - 1, 'YYYYMMDD')
			WHERE A.APL_STRT_YMD < CURR_YMD
			AND A.APL_FNH_YMD >= CURR_YMD
			AND EXISTS (SELECT 'EXIST'
                        FROM TB_VEHL_MGMT
			            WHERE QLTY_VEHL_CD = A.QLTY_VEHL_CD
			            AND DL_EXPD_CO_CD = EXPD_CO_CD_KMC
		                AND ROWNUM <= 1
		               );

			--현재일에 순수하게 입력된 항목은 삭제하도록 한다.
			DELETE FROM TB_APS_PROD_PLAN_INFO A
			WHERE A.APL_STRT_YMD = CURR_YMD
			AND A.APL_FNH_YMD >= CURR_YMD
			AND EXISTS (SELECT 'EXIST'
                        FROM TB_VEHL_MGMT
			            WHERE QLTY_VEHL_CD = A.QLTY_VEHL_CD
			            AND DL_EXPD_CO_CD = EXPD_CO_CD_KMC
		                AND ROWNUM <= 1
		               );
			/*****/

			FOR PROD_LIST IN APS_PROD_INFO_KMC LOOP

				--차종코드, 월팩, 목적국에 해당하는 품질차종코드, 연식, 취급설명서국가코드를 얻어온다.
				GET_MANUAL_INFO(CURR_YMD,
								EXPD_CO_CD_KMC,
				                PROD_LIST.PS06A_MODL,
								PROD_LIST.PM03F_PACK,
								PROD_LIST.PM03F_DEST,
								PROD_LIST.PM03F_BMDL,
								V_QLTY_VEHL_CD,
								V_MDL_MDY_CD,
								V_EXPD_NAT_CD);

				SELECT MAX(APL_FNH_YMD)
				INTO V_APL_FNH_YMD
				FROM TB_APS_PROD_PLAN_INFO A
				WHERE A.PRDN_ORD_NO = PROD_LIST.PS06A_ORDR
				AND A.DYTM_PLN_NAT_CD = PROD_LIST.PS06A_DIST
				AND A.PRDN_PLN_SCN_CD = PROD_LIST.PS06A_PLGU
				AND A.APL_CRTN_CD = PROD_LIST.PS06A_BASE
				AND A.PRDN_PLNT_CD = PROD_LIST.PS06A_PLNT
			    AND A.DYTM_PLN_VEHL_CD = PROD_LIST.PS06A_MODL
				AND A.PLN_PARR_YMD = PROD_LIST.PS06A_EDAT
				AND A.DL_EXPD_CO_CD = EXPD_CO_CD_KMC
			    AND A.APL_STRT_YMD <= CURR_YMD;

				IF V_APL_FNH_YMD IS NULL THEN

				   --지금까지 한번도 추가되지 않은 경우(무조건 Insert 해 준다.)

				   INSERT INTO TB_APS_PROD_PLAN_INFO
		    	   (PRDN_ORD_NO,
					DYTM_PLN_NAT_CD,
				    PRDN_PLN_SCN_CD,
					APL_CRTN_CD,
					PRDN_PLNT_CD,
			 		DYTM_PLN_VEHL_CD,
					PLN_PARR_YMD,
					DL_EXPD_CO_CD,
				    APL_STRT_YMD,
					APL_FNH_YMD,
					DEST_NAT_CD,
					MO_PACK_CD,
					DL_EXPD_REGN_CD,
					PRDN_PLN_QTY,
					DCSN_YN,
					DCSN_YMD,
					FRAM_DTM,
					QLTY_VEHL_CD,
					MDL_MDY_CD,
					DL_EXPD_NAT_CD
				   )
				   VALUES
				   (PROD_LIST.PS06A_ORDR,
					PROD_LIST.PS06A_DIST,
				    PROD_LIST.PS06A_PLGU,
				   	PROD_LIST.PS06A_BASE,
					PROD_LIST.PS06A_PLNT,
					PROD_LIST.PS06A_MODL,
					PROD_LIST.PS06A_EDAT,
					EXPD_CO_CD_KMC,
				    CURR_YMD,
					CURR_YMD,  --적용완료일을 현재일로 해준다.
					PROD_LIST.PM03F_DEST,
					PROD_LIST.PM03F_PACK,
					PROD_LIST.PM03F_REGN,
					PROD_LIST.PS06A_PQTY,
					PROD_LIST.DCSN_YN,
					PROD_LIST.DCSN_YMD,
					SYSDATE,
					V_QLTY_VEHL_CD,
					V_MDL_MDY_CD,
					V_EXPD_NAT_CD
				   );

				ELSE

				   --바로이전의 데이터가 변경되지 않은 경우에는 종료일 업데이트만 해준다.
				   --[2009-04-16]변경. 데이터가 같은지 여부 확인하는 로직에 연식도 추가해 준다.
				   --(PK 조건이 같은 경우에도 특별하게 연식을 발부하는 경우가 있기 때문이다.(GET_MDL_MDY_CD_EXTRA 프로시저 참고))

				   UPDATE TB_APS_PROD_PLAN_INFO A
			 	   SET APL_FNH_YMD = CURR_YMD, --적용완료일을 현재일로 해준다.
				       QLTY_VEHL_CD = V_QLTY_VEHL_CD,
/** 배치 재실행 시 오류 날 경우 주석해제하고 실행
					   MDL_MDY_CD = V_MDL_MDY_CD,
					   PRDN_PLN_QTY = PROD_LIST.PS06A_PQTY,
					   DCSN_YN = PROD_LIST.DCSN_YN,
*/
					   DL_EXPD_NAT_CD = V_EXPD_NAT_CD
				   WHERE A.PRDN_ORD_NO = PROD_LIST.PS06A_ORDR
				   AND A.DYTM_PLN_NAT_CD = PROD_LIST.PS06A_DIST
				   AND A.PRDN_PLN_SCN_CD = PROD_LIST.PS06A_PLGU
				   AND A.APL_CRTN_CD = PROD_LIST.PS06A_BASE
				   AND A.PRDN_PLNT_CD = PROD_LIST.PS06A_PLNT
			       AND A.DYTM_PLN_VEHL_CD = PROD_LIST.PS06A_MODL
				   AND A.PLN_PARR_YMD = PROD_LIST.PS06A_EDAT
				   AND A.DL_EXPD_CO_CD = EXPD_CO_CD_KMC
				   AND A.APL_STRT_YMD <= CURR_YMD
				   AND A.APL_FNH_YMD = V_APL_FNH_YMD
/** 배치 재실행 시 오류 날 경우 주석처리하고 실행 */
				   AND A.PRDN_PLN_QTY = PROD_LIST.PS06A_PQTY
				   AND A.DCSN_YN = PROD_LIST.DCSN_YN
				   AND NVL(A.MDL_MDY_CD, 'NULL') = NVL(V_MDL_MDY_CD, 'NULL')
				   ;

				   IF SQL%NOTFOUND THEN

					  INSERT INTO TB_APS_PROD_PLAN_INFO
		    	      (PRDN_ORD_NO,
					   DYTM_PLN_NAT_CD,
				       PRDN_PLN_SCN_CD,
					   APL_CRTN_CD,
					   PRDN_PLNT_CD,
			 		   DYTM_PLN_VEHL_CD,
					   PLN_PARR_YMD,
					   DL_EXPD_CO_CD,
				       APL_STRT_YMD,
					   APL_FNH_YMD,
					   DEST_NAT_CD,
					   MO_PACK_CD,
					   DL_EXPD_REGN_CD,
					   PRDN_PLN_QTY,
					   DCSN_YN,
					   DCSN_YMD,
					   FRAM_DTM,
					   QLTY_VEHL_CD,
					   MDL_MDY_CD,
					   DL_EXPD_NAT_CD
				      )
				      VALUES
				      (PROD_LIST.PS06A_ORDR,
					   PROD_LIST.PS06A_DIST,
				       PROD_LIST.PS06A_PLGU,
				   	   PROD_LIST.PS06A_BASE,
					   PROD_LIST.PS06A_PLNT,
					   PROD_LIST.PS06A_MODL,
					   PROD_LIST.PS06A_EDAT,
					   EXPD_CO_CD_KMC,
				       CURR_YMD,
					   CURR_YMD,  --적용완료일을 현재일로 해준다.
					   PROD_LIST.PM03F_DEST,
					   PROD_LIST.PM03F_PACK,
					   PROD_LIST.PM03F_REGN,
					   PROD_LIST.PS06A_PQTY,
					   PROD_LIST.DCSN_YN,
					   PROD_LIST.DCSN_YMD,
					   SYSDATE,
					   V_QLTY_VEHL_CD,
					   V_MDL_MDY_CD,
					   V_EXPD_NAT_CD
				      );

				   END IF;

				END IF;

			END LOOP;

	   END LOAD_APS_PROD_INFO_KMC;
/**********************************************************/



/**********************************************************/
	   --APS 오더 데이터 존재 여부 조회
	   FUNCTION GET_APS_ODR_EXIST_YN(CURR_YMD IN VARCHAR2,
	                                 EXPD_CO_CD IN VARCHAR2) RETURN VARCHAR2
	   IS

		 V_BTCH_YMD VARCHAR2(8);
		 V_CNT		NUMBER;
         V_STAT VARCHAR2(1);

		 V_CURR_YMD   VARCHAR2(8);
		 V_APL_YMD    VARCHAR2(8);

	   BEGIN

			V_CURR_YMD := TO_CHAR(SYSDATE, 'YYYYMMDD');
			V_APL_YMD  := TO_CHAR(SYSDATE - 12/24, 'YYYYMMDD');

			IF V_CURR_YMD = V_APL_YMD THEN
            -- 오후에 금일 결과 전송여부 확인인 경우 (ET_GUBN_CD:01)
            	V_STAT := PG_INTERFACE_ERP_ET_INFO.GET_ERP_ET_INFO_EXIST_YN(CURR_YMD, EXPD_CO_CD, '01');
            ELSE
	   		-- 오전에 이전일 결과 전송여부 확인인 경우(ET_GUBN_CD:02)
            	V_STAT := PG_INTERFACE_ERP_ET_INFO.GET_ERP_ET_INFO_EXIST_YN(TO_CHAR(TO_DATE(CURR_YMD, 'YYYYMMDD') - 1, 'YYYYMMDD'), EXPD_CO_CD, '02');
			END IF;

            RETURN V_STAT;

	   END GET_APS_ODR_EXIST_YN;
/**********************************************************/
/**********************************************************/
	   /**
	   --오더정보 존재 여부 조회
	   FUNCTION GET_ODR_EXIST_YN(CURR_YMD IN VARCHAR2,
	                             EXPD_CO_CD IN VARCHAR2) RETURN VARCHAR2
	   IS

		 V_STATE   VARCHAR2(1);
		 V_CNT     NUMBER;

	   BEGIN

			--오늘 날짜의 인터페이스 된 데이터가 존재하는지의 여부 확인
			SELECT COUNT(*)
			INTO V_CNT
			FROM TB_APS_ODR_INFO
			WHERE APL_STRT_YMD <= CURR_YMD
			AND APL_FNH_YMD >= CURR_YMD
			AND DL_EXPD_CO_CD = EXPD_CO_CD
			AND ROWNUM <= 1;

			IF V_CNT > 0 THEN

			    RETURN 'Y';

			ELSE

				RETURN 'N';

			END IF;

	   END GET_ODR_EXIST_YN;
	   **/
/**********************************************************/
/**********************************************************/
	   --오더 배치결과 정보 존재 여부 조회
	   FUNCTION GET_BTCH_ODR_FNH_YN(CURR_YMD   IN VARCHAR2,
	                                EXPD_CO_CD IN VARCHAR2)RETURN VARCHAR2
	   IS

		 V_BTCH_YMD VARCHAR2(8);
		 V_STATE    VARCHAR2(1);

	   BEGIN

			SELECT MAX(BTCH_FNH_YMD)
			INTO V_BTCH_YMD
			FROM TB_BATCH_FNH_INFO
			WHERE AFFR_SCN_CD = '01'
			AND DL_EXPD_CO_CD = EXPD_CO_CD
			AND BTCH_FNH_YMD = CURR_YMD;

			IF V_BTCH_YMD IS NULL THEN

			   V_STATE := 'N';

			ELSIF CURR_YMD = V_BTCH_YMD THEN

			   V_STATE := 'Y';

			ELSE

			   V_STATE := 'N';

			END IF;

			RETURN V_STATE;

	   END GET_BTCH_ODR_FNH_YN;
/**********************************************************/



/**********************************************************/
	   --APS 계획 데이터 존재 여부 조회
	   FUNCTION GET_APS_PROD_EXIST_YN(CURR_YMD IN VARCHAR2,
	                                  EXPD_CO_CD IN VARCHAR2) RETURN VARCHAR2
	   IS

		 V_BTCH_YMD VARCHAR2(8);

	   BEGIN

			IF EXPD_CO_CD = '02' THEN

			   SELECT SUBSTR(TO_CHAR(MAX(PS06A_STTM)), 1, 8)
			   INTO V_BTCH_YMD
			   FROM SY_PSE06AC_KMC
			   WHERE ROWNUM <= 1
			   ;

			END IF;

			IF V_BTCH_YMD = CURR_YMD THEN

			   RETURN 'Y';

			ELSE

			   RETURN 'N';

			END IF;

	   END GET_APS_PROD_EXIST_YN;
/**********************************************************/
/**********************************************************/
       /**
	   --계획정보 존재 여부 조회
	   FUNCTION GET_PROD_EXIST_YN(CURR_YMD IN VARCHAR2,
	                              EXPD_CO_CD IN VARCHAR2) RETURN VARCHAR2
	   IS

		 V_STATE   VARCHAR2(1);
		 V_CNT     NUMBER;

	   BEGIN

			--오늘 날짜의 인터페이스 된 데이터가 존재하는지의 여부 확인
			SELECT COUNT(*)
			INTO V_CNT
			FROM TB_APS_PROD_PLAN_INFO
			WHERE APL_STRT_YMD <= CURR_YMD
			AND APL_FNH_YMD >= CURR_YMD
			AND DL_EXPD_CO_CD = EXPD_CO_CD
			AND ROWNUM <= 1;

			IF V_CNT > 0 THEN

			    RETURN 'Y';

			ELSE

				RETURN 'N';

			END IF;

	   END GET_PROD_EXIST_YN;
	   **/
/**********************************************************/
/**********************************************************/
	   --계획 배치결과 정보 존재 여부 조회
	   FUNCTION GET_BTCH_PROD_FNH_YN(CURR_YMD   IN VARCHAR2,
	                                 EXPD_CO_CD IN VARCHAR2)RETURN VARCHAR2
	   IS

		 V_BTCH_YMD VARCHAR2(8);
		 V_STATE    VARCHAR2(1);

	   BEGIN

			SELECT MAX(BTCH_FNH_YMD)
			INTO V_BTCH_YMD
			FROM TB_BATCH_FNH_INFO
			WHERE AFFR_SCN_CD = '02'
			AND DL_EXPD_CO_CD = EXPD_CO_CD
			AND BTCH_FNH_YMD = CURR_YMD;

			IF V_BTCH_YMD IS NULL THEN

			   V_STATE := 'N';

			ELSIF CURR_YMD = V_BTCH_YMD THEN

			   V_STATE := 'Y';

			ELSE

			   V_STATE := 'N';

			END IF;

			RETURN V_STATE;

	   END GET_BTCH_PROD_FNH_YN;
/**********************************************************/



/**********************************************************/
	   --기간별 생산오더 Summary 배치 작업 수행(외부 호출)
	   --[주의] HISTORY형태로 관리되는 데이터이므로 특정날짜의 데이터를 수정하면 특정일 이후의 전날짜에 대하여 수정작업을 진행하여야
	   --       한다.
	   PROCEDURE GET_APS_ODR_SUM_LIST(FROM_YMD   IN VARCHAR2,
	                                  TO_YMD     IN VARCHAR2)
	   IS

	   	 V_FROM_DATE DATE;
		 V_DATE_CNT  NUMBER;

		 V_CURR_DATE DATE;
		 V_CURR_YMD  VARCHAR2(8);

	   BEGIN

			V_FROM_DATE := TO_DATE(FROM_YMD, 'YYYYMMDD');

			V_DATE_CNT  := ROUND(TO_DATE(TO_YMD, 'YYYYMMDD') - V_FROM_DATE);

			FOR NUM IN 0.. V_DATE_CNT LOOP

				V_CURR_DATE := V_FROM_DATE + NUM;
				V_CURR_YMD  := TO_CHAR(V_CURR_DATE, 'YYYYMMDD');

				/**  GET_APS_ODR_SUM2 프로시저내에서 처리하는 것으로 변경

				--과거일에 입력되었으나 데이터가 변경되지 않아서 현재일 이후로 종료일이 설정 되어 있는 경우에는
				--종료일을 하루전으로 설정해 준다.
				UPDATE TB_APS_ODR_SUM_INFO
				SET APL_FNH_YMD = TO_CHAR(V_CURR_DATE - 1, 'YYYYMMDD')
				WHERE APL_STRT_YMD < V_CURR_YMD
				AND APL_FNH_YMD >= V_CURR_YMD;

				--현재일에 순수하게 입력된 항목은 삭제하도록 한다.
				DELETE FROM TB_APS_ODR_SUM_INFO
				WHERE APL_STRT_YMD = V_CURR_YMD
				AND APL_FNH_YMD >= V_CURR_YMD;
				**/

				--APS 차종코드, 월팩, 목적국 코드에 대응하는 품질차종코드, 연식, 국가코드를 매핑하는 작업 수행
				GET_MANUAL_ODR_INFO_DETAIL(V_CURR_YMD);

				--구버전
				--GET_APS_ODR_SUM(V_CURR_YMD, EXPD_CO_CD_KMC);

				GET_APS_ODR_SUM2(V_CURR_YMD, EXPD_CO_CD_KMC);

			END LOOP;

			COMMIT;

			EXCEPTION
		     WHEN OTHERS THEN
			     ROLLBACK;
				 RAISE;

	   END GET_APS_ODR_SUM_LIST;
/**********************************************************/
/**********************************************************/
       --기간별 생산계획 Summary 배치자 작업 수행(외부 호출)
	   --[주의] HISTORY형태로 관리되는 데이터이므로 특정날짜의 데이터를 수정하면 특정일 이후의 전날짜에 대하여 수정작업을 진행하여야
	   --       한다.
	   PROCEDURE GET_APS_PROD_SUM_LIST(FROM_YMD   IN VARCHAR2,
	                                   TO_YMD     IN VARCHAR2)
	   IS

		 V_FROM_DATE DATE;
		 V_DATE_CNT  NUMBER;

		 V_CURR_DATE DATE;
		 V_CURR_YMD  VARCHAR2(8);

	   BEGIN

			V_FROM_DATE := TO_DATE(FROM_YMD, 'YYYYMMDD');

			V_DATE_CNT  := ROUND(TO_DATE(TO_YMD, 'YYYYMMDD') - V_FROM_DATE);

			FOR NUM IN 0.. V_DATE_CNT LOOP

				V_CURR_DATE := V_FROM_DATE + NUM;
				V_CURR_YMD  := TO_CHAR(V_CURR_DATE, 'YYYYMMDD');

				/** GET_APS_PROD_SUM2 프로시저내에서 처리하는 것으로 변경

				--과거일에 입력되었으나 데이터가 변경되지 않아서 현재일 이후로 종료일이 설정 되어 있는 경우에는
				--종료일을 하루전으로 설정해 준다.
				UPDATE TB_APS_PROD_PLAN_SUM_INFO
				SET APL_FNH_YMD = TO_CHAR(V_CURR_DATE  - 1, 'YYYYMMDD')
				WHERE APL_STRT_YMD < V_CURR_YMD
				AND APL_FNH_YMD >= V_CURR_YMD;

				--현재일에 순수하게 입력된 항목은 삭제하도록 한다.
				DELETE FROM TB_APS_PROD_PLAN_SUM_INFO
				WHERE APL_STRT_YMD = V_CURR_YMD
				AND APL_FNH_YMD >= V_CURR_YMD;
				**/

				--APS 차종코드, 월팩, 목적국 코드에 대응하는 품질차종코드, 연식, 국가코드를 매핑하는 작업 수행
				GET_MANUAL_PROD_INFO_DETAIL(V_CURR_YMD);

				--구버전
				--GET_APS_PROD_SUM(V_CURR_YMD, EXPD_CO_CD_KMC);

				GET_APS_PROD_SUM2(V_CURR_YMD, EXPD_CO_CD_KMC);

			END LOOP;

			COMMIT;

			EXCEPTION
		     WHEN OTHERS THEN
			     ROLLBACK;
				 RAISE;

	   END GET_APS_PROD_SUM_LIST;
/**********************************************************/


/**********************************************************/
	   /**
	   --오더계획 테이블 차종코드, 연식, 취급설명서 국가코드 일괄 적용시 사용하는 프로시저
	   --(초기 입력된 값이 없었을때 사용, 현재는 사용할 필요없음)
       PROCEDURE GET_MANUAL_ODR_INFO_LIST(FROM_YMD IN VARCHAR2,
	                                      TO_YMD   IN VARCHAR2)
	   IS

		 V_FROM_DATE DATE;
		 V_DATE_CNT  NUMBER;

		 V_CURR_DATE DATE;
		 V_CURR_YMD  VARCHAR2(8);

	   BEGIN

			V_FROM_DATE := TO_DATE(FROM_YMD, 'YYYYMMDD');

			V_DATE_CNT  := ROUND(TO_DATE(TO_YMD, 'YYYYMMDD') - V_FROM_DATE);

			FOR NUM IN 0.. V_DATE_CNT LOOP

				V_CURR_DATE := V_FROM_DATE + NUM;
				V_CURR_YMD  := TO_CHAR(V_CURR_DATE, 'YYYYMMDD');

				GET_MANUAL_ODR_INFO_DETAIL(V_CURR_YMD);

			END LOOP;

			COMMIT;

			EXCEPTION
		     WHEN OTHERS THEN
			     ROLLBACK;
				 RAISE;

	   END GET_MANUAL_ODR_INFO_LIST;
	   **/
/**********************************************************/
/**********************************************************/
       --오더계획 테이블 차종코드, 연식, 취급설명서 국가코드 적용시 사용하는 프로시저
	   --(GET_APS_ODR_SUM_LIST 프로시저 내에서 사용함)
       PROCEDURE GET_MANUAL_ODR_INFO_DETAIL(CURR_YMD IN VARCHAR2)
	   IS

		 V_QLTY_VEHL_CD TB_APS_ODR_INFO.QLTY_VEHL_CD%TYPE;
		 V_MDL_MDY_CD	TB_APS_ODR_INFO.MDL_MDY_CD%TYPE;
		 V_EXPD_NAT_CD	TB_APS_ODR_INFO.DL_EXPD_NAT_CD%TYPE;

		 CURSOR APS_ODR_INFO IS SELECT DYTM_PLN_VEHL_CD,
									   MO_PACK_CD,
									   DL_EXPD_CO_CD,
									   DEST_NAT_CD,
									   PRDN_ORD_NO,
									   DYTM_PLN_NAT_CD,
									   PRDN_PLNT_CD,
									   USF_CD,
									   APL_STRT_YMD,
									   APL_FNH_YMD,
									   BASC_MDL_CD
		                        FROM TB_APS_ODR_INFO
                                WHERE APL_STRT_YMD <= CURR_YMD
                                AND APL_FNH_YMD >= CURR_YMD;

	   BEGIN

			FOR ODR_LIST IN APS_ODR_INFO LOOP

				GET_MANUAL_INFO(CURR_YMD,
								ODR_LIST.DL_EXPD_CO_CD,
				                ODR_LIST.DYTM_PLN_VEHL_CD,
								ODR_LIST.MO_PACK_CD,
								ODR_LIST.DEST_NAT_CD,
								ODR_LIST.BASC_MDL_CD,
								V_QLTY_VEHL_CD,
								V_MDL_MDY_CD,
								V_EXPD_NAT_CD);

				UPDATE TB_APS_ODR_INFO
				SET QLTY_VEHL_CD = V_QLTY_VEHL_CD,
				    MDL_MDY_CD = V_MDL_MDY_CD,
					DL_EXPD_NAT_CD = V_EXPD_NAT_CD
				WHERE PRDN_ORD_NO = ODR_LIST.PRDN_ORD_NO
				AND DYTM_PLN_NAT_CD = ODR_LIST.DYTM_PLN_NAT_CD
				AND PRDN_PLNT_CD = ODR_LIST.PRDN_PLNT_CD
				AND DYTM_PLN_VEHL_CD = ODR_LIST.DYTM_PLN_VEHL_CD
				AND USF_CD = ODR_LIST.USF_CD
				AND MO_PACK_CD = ODR_LIST.MO_PACK_CD
				AND DL_EXPD_CO_CD = ODR_LIST.DL_EXPD_CO_CD
				AND APL_STRT_YMD = ODR_LIST.APL_STRT_YMD
				AND APL_FNH_YMD = ODR_LIST.APL_FNH_YMD;

			END LOOP;

	   END GET_MANUAL_ODR_INFO_DETAIL;
/**********************************************************/
/**********************************************************/
       /**
       --생산계획 테이블 차종코드, 연식, 취급설명서 국가코드 일괄 적용시 사용하는 프로시저
	   --(초기 입력된 값이 없었을때 사용, 현재는 사용할 필요없음)
       PROCEDURE GET_MANUAL_PROD_INFO_LIST(FROM_YMD IN VARCHAR2,
	                                       TO_YMD   IN VARCHAR2)
	   IS

		 V_FROM_DATE DATE;
		 V_DATE_CNT  NUMBER;

		 V_CURR_DATE DATE;
		 V_CURR_YMD  VARCHAR2(8);

	   BEGIN

			V_FROM_DATE := TO_DATE(FROM_YMD, 'YYYYMMDD');

			V_DATE_CNT  := ROUND(TO_DATE(TO_YMD, 'YYYYMMDD') - V_FROM_DATE);

			FOR NUM IN 0.. V_DATE_CNT LOOP

				V_CURR_DATE := V_FROM_DATE + NUM;
				V_CURR_YMD  := TO_CHAR(V_CURR_DATE, 'YYYYMMDD');

				GET_MANUAL_PROD_INFO_DETAIL(V_CURR_YMD);

			END LOOP;

			COMMIT;

			EXCEPTION
		     WHEN OTHERS THEN
			     ROLLBACK;
				 RAISE;

	   END GET_MANUAL_PROD_INFO_LIST;
	   **/
/**********************************************************/
/**********************************************************/
       --생산계획 테이블 차종코드, 연식, 취급설명서 국가코드 적용시 사용하는 프로시저
	   --(GET_APS_PROD_SUM_LIST 프로시저 내에서 사용함)
       PROCEDURE GET_MANUAL_PROD_INFO_DETAIL(CURR_YMD IN VARCHAR2)
	   IS

		 V_QLTY_VEHL_CD TB_APS_PROD_PLAN_INFO.QLTY_VEHL_CD%TYPE;
		 V_MDL_MDY_CD	TB_APS_PROD_PLAN_INFO.MDL_MDY_CD%TYPE;
		 V_EXPD_NAT_CD	TB_APS_PROD_PLAN_INFO.DL_EXPD_NAT_CD%TYPE;

		 CURSOR APS_PROD_INFO IS SELECT DYTM_PLN_VEHL_CD,
									    MO_PACK_CD,
									    DL_EXPD_CO_CD,
									    DEST_NAT_CD,
									    PRDN_ORD_NO,
									    DYTM_PLN_NAT_CD,
									    PRDN_PLN_SCN_CD,
									    APL_CRTN_CD,
									    PRDN_PLNT_CD,
									    PLN_PARR_YMD,
									    APL_STRT_YMD,
									    APL_FNH_YMD,
										(SELECT BASC_MDL_CD
										 FROM TB_APS_ODR_INFO
										 WHERE PRDN_ORD_NO = A.PRDN_ORD_NO
										 AND DYTM_PLN_NAT_CD = A.DYTM_PLN_NAT_CD
										 AND PRDN_PLNT_CD = A.PRDN_PLNT_CD
										 AND DYTM_PLN_VEHL_CD = A.DYTM_PLN_VEHL_CD
										 AND MO_PACK_CD = A.MO_PACK_CD
										 AND DL_EXPD_CO_CD = A.DL_EXPD_CO_CD
										 AND ROWNUM <= 1
										) AS BASC_MDL_CD
		                         FROM TB_APS_PROD_PLAN_INFO A
                                 WHERE APL_STRT_YMD <= CURR_YMD
                                 AND APL_FNH_YMD >= CURR_YMD;
	   BEGIN

			FOR PROD_LIST IN APS_PROD_INFO LOOP

				GET_MANUAL_INFO(CURR_YMD,
								PROD_LIST.DL_EXPD_CO_CD,
				                PROD_LIST.DYTM_PLN_VEHL_CD,
								PROD_LIST.MO_PACK_CD,
								PROD_LIST.DEST_NAT_CD,
								PROD_LIST.BASC_MDL_CD,
								V_QLTY_VEHL_CD,
								V_MDL_MDY_CD,
								V_EXPD_NAT_CD);

				UPDATE TB_APS_PROD_PLAN_INFO
				SET QLTY_VEHL_CD = V_QLTY_VEHL_CD,
				    MDL_MDY_CD = V_MDL_MDY_CD,
					DL_EXPD_NAT_CD = V_EXPD_NAT_CD
				WHERE PRDN_ORD_NO = PROD_LIST.PRDN_ORD_NO
				AND DYTM_PLN_NAT_CD = PROD_LIST.DYTM_PLN_NAT_CD
				AND PRDN_PLN_SCN_CD = PROD_LIST.PRDN_PLN_SCN_CD
				AND APL_CRTN_CD = PROD_LIST.APL_CRTN_CD
				AND PRDN_PLNT_CD = PROD_LIST.PRDN_PLNT_CD
				AND DYTM_PLN_VEHL_CD = PROD_LIST.DYTM_PLN_VEHL_CD
				AND PLN_PARR_YMD = PROD_LIST.PLN_PARR_YMD
				AND DL_EXPD_CO_CD = PROD_LIST.DL_EXPD_CO_CD
				AND APL_STRT_YMD = PROD_LIST.APL_STRT_YMD
				AND APL_FNH_YMD = PROD_LIST.APL_FNH_YMD;

			END LOOP;

	   END GET_MANUAL_PROD_INFO_DETAIL;
/**********************************************************/
/**********************************************************/
       --APS 차종, 월팩, 목적국 코드에 해당하는 품질차종코드, 연식, 취급설명서 국가코드를 추출
	   PROCEDURE GET_MANUAL_INFO(P_CURR_YMD		IN  VARCHAR2,
	   			 				 P_EXPD_CO_CD   IN  VARCHAR2,
	   			 				 P_PRDN_VEHL_CD IN  VARCHAR2,
	   			 				 P_MO_PACK_CD   IN  VARCHAR2,
								 P_DEST_NAT_CD  IN  VARCHAR2,
								 P_BASC_MDL_CD  IN  VARCHAR2,
								 P_QLTY_VEHL_CD OUT VARCHAR2,
								 P_MDL_MDY_CD   OUT VARCHAR2,
								 P_EXPD_NAT_CD  OUT VARCHAR2)
	   IS

		 V_EXPD_REGN_CD VARCHAR2(4);

	   BEGIN

			IF SUBSTR(P_PRDN_VEHL_CD, 1, 2) = 'H8' THEN

				IF SUBSTR(P_BASC_MDL_CD, 3, 2) = 'W5' THEN
					P_QLTY_VEHL_CD := 'YBC';
				ELSE
					P_QLTY_VEHL_CD := 'YB';
				END IF;

			ELSE

				--품질차종코드 조회
				SELECT MAX(QLTY_VEHL_CD)
				INTO P_QLTY_VEHL_CD
				FROM TB_ALTN_VEHL_MGMT
				WHERE PRDN_VEHL_CD = P_PRDN_VEHL_CD
				AND PRVS_SCN_CD = 'A';
	
			END IF;

			--취급설명서 국가코드 조회
			/*SELECT MAX(DL_EXPD_NAT_CD)
			INTO P_EXPD_NAT_CD
			FROM TB_ALTN_NATL_MGMT
			WHERE DL_EXPD_CO_CD = P_EXPD_CO_CD
			AND DYTM_PLN_NAT_CD = P_DEST_NAT_CD
			AND PRVS_SCN_CD = 'A';*/
			P_EXPD_NAT_CD := GET_NAT_CD(P_DEST_NAT_CD);

			P_MDL_MDY_CD := NULL;

			IF P_QLTY_VEHL_CD IS NOT NULL AND
			   P_EXPD_NAT_CD IS NOT NULL THEN

			   --이전 방식 나중에 주석 처리 요망
			   SELECT MAX(B.MDL_MDY_CD)
			   INTO P_MDL_MDY_CD
			   FROM TB_NATL_VEHL_MGMT A,
			        TB_VEHL_MDY_MGMT B
			   WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
			   AND A.DL_EXPD_REGN_CD = B.DL_EXPD_REGN_CD
			   AND A.DL_EXPD_CO_CD = P_EXPD_CO_CD
			   AND A.DL_EXPD_NAT_CD = P_EXPD_NAT_CD
			   AND A.QLTY_VEHL_CD = P_QLTY_VEHL_CD
			   AND P_MO_PACK_CD >= B.DESMP1_CD
       		   AND P_MO_PACK_CD <= B.DEFMP1_CD;

			   /*** 신규 방식 현재는 주석 처리함(국가/언어코드 관리 화면에서 지역이 입력되어 있어야만 사용 가능)
			   SELECT MAX(DL_EXPD_REGN_CD)
			   INTO V_EXPD_REGN_CD
			   FROM TB_NATL_MGMT
			   WHERE DL_EXPD_CO_CD = P_EXPD_CO_CD
			   AND DL_EXPD_NAT_CD = P_EXPD_NAT_CD;

			   IF V_EXPD_REGN_CD IS NOT NULL THEN

				  SELECT MAX(MDL_MDY_CD)
				  INTO P_MDL_MDY_CD
				  FROM TB_VEHL_MDY_MGMT
       			  WHERE QLTY_VEHL_CD = P_QLTY_VEHL_CD
       			  AND DL_EXPD_REGN_CD = V_EXPD_REGN_CD
				  AND P_MO_PACK_CD >= DESMP1_CD
       			  AND P_MO_PACK_CD <= DEFMP1_CD;

			   END IF;
			   ***/

			   --특수한 경우의 연식변경 작업 수행
			   GET_MDL_MDY_CD_EXTRA(P_CURR_YMD,
			   						P_EXPD_CO_CD,
			   						P_QLTY_VEHL_CD,
									P_EXPD_NAT_CD,
									P_MO_PACK_CD,
									'01',
									P_BASC_MDL_CD,
									P_MDL_MDY_CD);
			END IF;

	   END GET_MANUAL_INFO;
/**********************************************************/

	   -- 국가마스터에서 5자리 OR 3자리 국가코드 반환하는 함수
	   FUNCTION GET_NAT_CD(P_DL_EXPD_NAT_CD IN VARCHAR2) RETURN VARCHAR2
	   IS
	   	NAT_CD VARCHAR2(5);
	   BEGIN
	   
	   	NAT_CD := NULL;
	   
	   	SELECT MAX(DL_EXPD_NAT_CD)
	   	INTO NAT_CD
	   	FROM TB_NATL_MGMT
	   	WHERE DL_EXPD_CO_CD = EXPD_CO_CD_KMC
	   	AND (DL_EXPD_NAT_CD = P_DL_EXPD_NAT_CD OR DL_EXPD_NAT_CD = SUBSTR(P_DL_EXPD_NAT_CD, 1, 3))
	   	;
	   	
	   	RETURN NAT_CD;

		 EXCEPTION
		     WHEN OTHERS THEN
			 PG_INTERFACE_APS.WRITE_BATCH_EXE_LOG('PG_INTERFACE_APS.GET_NAT_CD', SYSDATE, 'F', 'P_DL_EXPD_NAT_CD : ' || P_DL_EXPD_NAT_CD);
			 RETURN NAT_CD;
	   END GET_NAT_CD;

/**********************************************************/
       --미지정 국가명 리턴
	   FUNCTION FU_GET_NOAPIM_NAT_NM(P_EXPD_CO_CD   IN  VARCHAR2,
	                                 P_DEST_NAT_CD  IN  VARCHAR2) RETURN VARCHAR2
	   IS
	   	 V_NAT_NM VARCHAR2(40);

	   BEGIN

			V_NAT_NM := '';

			IF P_EXPD_CO_CD = '02' THEN



			   V_NAT_NM := '';

			   /** 2010.01.06.김동근 기아 호스트 장애 발생되어 주석 처리함
			   SELECT TRIM(MAX(DISTCNN1))
			   INTO V_NAT_NM
			   FROM SY_KSRDIST
			   WHERE DISTHKMC = 'KMC'
			   AND DISTCODE = P_DEST_NAT_CD;
			   **/

			END IF;

	   		RETURN V_NAT_NM;

			EXCEPTION
		     WHEN OTHERS THEN
			     RETURN V_NAT_NM;

	   END FU_GET_NOAPIM_NAT_NM;
/**********************************************************/
/**********************************************************/
       --연식지정관련 별도 작업 프로시저
	   PROCEDURE GET_MDL_MDY_CD_EXTRA(P_CURR_YMD	 IN VARCHAR2,
	   			 					  P_EXPD_CO_CD   IN VARCHAR2,
	   								  P_QLTY_VEHL_CD IN VARCHAR2,
									  P_EXPD_NAT_CD  IN VARCHAR2,
									  P_MO_PACK_CD   IN VARCHAR2,
									  P_MODE		 IN VARCHAR2,
									  P_BASC_MDL_CD  IN VARCHAR2,
									  P_MDL_MDY_CD   IN OUT VARCHAR2)
	   IS
	   BEGIN

			IF P_EXPD_CO_CD = EXPD_CO_CD_KMC THEN

				--JB 차종의 07월 팩 중에서 4DR 인 경우에는 10연식으로 지정해 준다.
				IF P_QLTY_VEHL_CD = 'JB' AND P_MO_PACK_CD = '0907' AND SUBSTR(P_BASC_MDL_CD, 3, 2) = 'S4' THEN

				   IF P_CURR_YMD >= '20090701' THEN

				       P_MDL_MDY_CD := '10';

				   END IF;

				END IF;

			END IF;

	   END GET_MDL_MDY_CD_EXTRA;
/**********************************************************/


/**********************************************************/
	   --날짜 데이터 생성(외부 호출)
	   PROCEDURE CREATE_WK_DATE
	   IS
	   BEGIN

			CREATE_WK_DATE_DTL(TO_CHAR(SYSDATE, 'YYYYMMDD'));

	   END CREATE_WK_DATE;
/**********************************************************/
/**********************************************************/
	   --날짜 데이터 생성 상세(외부 호출)
	   PROCEDURE CREATE_WK_DATE_DTL(CURR_YMD   IN VARCHAR2)
	   IS

		 V_CURR_DATE DATE;

		 V_CURR_YMD  VARCHAR2(8);

		 V_CNT       NUMBER;

		 STRT_DATE   DATE;

		 V_DOW_CD	 CHAR(1);

	   BEGIN

		 STRT_DATE := SYSDATE;

		 V_CURR_DATE := TO_DATE(CURR_YMD, 'YYYYMMDD');

		 FOR NUM IN 1..365 LOOP

			 V_CURR_YMD := TO_CHAR(V_CURR_DATE, 'YYYYMMDD');
			 V_DOW_CD   := TO_CHAR(V_CURR_DATE, 'D');

			 SELECT COUNT(*) INTO V_CNT
			 FROM TB_WRK_DATE_MGMT
			 WHERE WK_YMD = V_CURR_YMD;

			 IF V_CNT = 0 THEN

				INSERT INTO TB_WRK_DATE_MGMT
				(WK_YMD,
				 DOW_CD,
				 HOLI_YN
				)
				VALUES
				(V_CURR_YMD,
				 V_DOW_CD,
				 CASE WHEN V_DOW_CD IN ('1', '7') THEN 'Y' ELSE 'N' END
				);

			 END IF;

			 V_CURR_DATE := V_CURR_DATE + 1;

		 END LOOP;

		 COMMIT;

		 WRITE_BATCH_LOG('날짜정보배치', STRT_DATE, 'S', '배치처리완료');

		 EXCEPTION
		     WHEN OTHERS THEN
			     ROLLBACK;
				 WRITE_BATCH_LOG('날짜정보배치', STRT_DATE, 'F', '배치처리실패:[' || SQLERRM || ']');

	   END CREATE_WK_DATE_DTL;
/**********************************************************/



/**********************************************************/
       --구버전 현재 사용 안함
	   --[주의] 실행을 위한 전제조건은 현재날짜에 해당하는 내역이 존재하지 않아야 한다.
	   PROCEDURE GET_APS_ODR_SUM(CURR_YMD   IN VARCHAR2,
	                             EXPD_CO_CD IN VARCHAR2)
	   IS

		 V_APL_FNH_YMD VARCHAR2(8);

		 V_MDL_MDY_CD  VARCHAR2(2);

		 V_CNT		   NUMBER;

		 --국가코드 조회를 위한 부분(등록되어 있지 않은 데이터만 읽어온다.)
		 /* 연계국가코드 미사용으로 제외
		 CURSOR APS_NATL_INFO IS SELECT A.DEST_NAT_CD
		                         FROM TB_APS_ODR_INFO A,
								 	  TB_ALTN_VEHL_MGMT B
								 WHERE A.DL_EXPD_CO_CD = EXPD_CO_CD
                                 AND A.APL_STRT_YMD <= CURR_YMD
                                 AND A.APL_FNH_YMD >= CURR_YMD
								 AND A.DYTM_PLN_VEHL_CD = B.PRDN_VEHL_CD
								 AND B.PRVS_SCN_CD = 'A'
								 AND NOT EXISTS (SELECT 'EXIST'
												 FROM TB_ALTN_NATL_MGMT
												 WHERE DL_EXPD_CO_CD = EXPD_CO_CD
												 AND DYTM_PLN_NAT_CD = A.DEST_NAT_CD
												 AND PRVS_SCN_CD = 'A'
												)
								 GROUP BY A.DEST_NAT_CD;
		 */

		 --국가미지정 정보를 가져오는 부분
		 CURSOR APS_NOAPIM_ODR_INFO IS SELECT EXPD_NAT_CD,
		 							   		  QLTY_VEHL_CD,
											  MO_PACK_CD,
											  ORD_QTY,
											  PRDN_PLN_QTY
									   FROM (SELECT B.DL_EXPD_NAT_CD,
												    A.DEST_NAT_CD AS EXPD_NAT_CD,
       											    A.QLTY_VEHL_CD,
													A.MO_PACK_CD,
													A.ORD_QTY,
													A.PRDN_PLN_QTY
       									     FROM (--차종코드 테이블에 등록되어 있는 내역만을 조회하도록 한다.
											       SELECT B.QLTY_VEHL_CD,
												   		  A.MO_PACK_CD,
														  A.DEST_NAT_CD,
														  SUM(A.ORD_QTY) AS ORD_QTY,
														  SUM(A.PRDN_PLN_QTY) AS PRDN_PLN_QTY
												   FROM TB_APS_ODR_INFO A,
												        TB_ALTN_VEHL_MGMT B
												   WHERE A.DL_EXPD_CO_CD = EXPD_CO_CD
												   AND A.APL_STRT_YMD <= CURR_YMD
												   AND A.APL_FNH_YMD >= CURR_YMD
												   AND A.DYTM_PLN_VEHL_CD = B.PRDN_VEHL_CD
												   AND B.PRVS_SCN_CD = 'A'
												   GROUP BY B.QLTY_VEHL_CD,
       													    A.MO_PACK_CD,
       													    A.DEST_NAT_CD
       										      ) A,
       										      TB_ALTN_NATL_MGMT B
											 WHERE B.DL_EXPD_CO_CD(+) = EXPD_CO_CD
											 AND A.DEST_NAT_CD = B.DYTM_PLN_NAT_CD(+)
											 AND B.PRVS_SCN_CD(+) = 'A'
									        )
									   WHERE DL_EXPD_NAT_CD IS NULL;


		 							  /**  국가코드가 지정되지 않은 항목만 가져오는 것으로 변경
		 							  SELECT QLTY_VEHL_CD,
		                                      MDL_MDY_CD,
											  EXPD_NAT_CD,
											  MO_PACK_CD,
											  SUM(ORD_QTY) AS ORD_QTY,
											  SUM(PRDN_PLN_QTY) AS PRDN_PLN_QTY
		                               FROM (SELECT B.LANG_CD,
       								                A.MDL_MDY_CD,
       								                A.QLTY_VEHL_CD,
       								                A.MO_PACK_CD,
													A.EXPD_NAT_CD,
       								                A.ORD_QTY,
       								                A.PRDN_PLN_QTY
       							             FROM (SELECT NVL(B.MDL_MDY_CD, 'N/A') AS MDL_MDY_CD,
       									  	              A.EXPD_NAT_CD,
       										              A.QLTY_VEHL_CD,
       										              A.MO_PACK_CD,
       										              A.ORD_QTY,
       										              A.PRDN_PLN_QTY
       								               FROM (SELECT NVL(B.DL_EXPD_REGN_CD, 'N/A') AS EXPD_REGN_CD,
									                            A.EXPD_NAT_CD,
												                A.QLTY_VEHL_CD,
												                A.MO_PACK_CD,
												                A.ORD_QTY,
												                A.PRDN_PLN_QTY
									                     FROM (SELECT NVL(B.DL_EXPD_NAT_CD, A.DEST_NAT_CD) AS EXPD_NAT_CD,
       											                      A.QLTY_VEHL_CD,
       											                      A.MO_PACK_CD,
       											                      A.ORD_QTY,
       											                      A.PRDN_PLN_QTY
       									                       FROM (--차종코드 테이블에 등록되어 있는 내역만을 조회하도록 한다.
												  	                 SELECT B.QLTY_VEHL_CD,
												 		                    A.MO_PACK_CD,
														                    A.DEST_NAT_CD,
														                    SUM(A.ORD_QTY) AS ORD_QTY,
       	                                                                    SUM(A.PRDN_PLN_QTY) AS PRDN_PLN_QTY
												                     FROM TB_APS_ODR_INFO A,
												                          TB_ALTN_VEHL_MGMT B
												                     WHERE A.DL_EXPD_CO_CD = EXPD_CO_CD
                                                                     AND A.APL_STRT_YMD <= CURR_YMD
                                                                     AND A.APL_FNH_YMD >= CURR_YMD
												                     AND A.DYTM_PLN_VEHL_CD = B.PRDN_VEHL_CD
												                     AND B.PRVS_SCN_CD = 'A'
												                     GROUP BY B.QLTY_VEHL_CD,
       													                      A.MO_PACK_CD,
       													                      A.DEST_NAT_CD
       										                        ) A,
       										                        TB_ALTN_NATL_MGMT B
															  WHERE B.DL_EXPD_CO_CD(+) = EXPD_CO_CD
											                  AND A.DEST_NAT_CD = B.DYTM_PLN_NAT_CD(+)
															  AND B.PRVS_SCN_CD(+) = 'A'
									                          ) A,
												              TB_NATL_VEHL_MGMT B
										                 WHERE A.EXPD_NAT_CD = B.DL_EXPD_NAT_CD(+)
										                 AND B.DL_EXPD_CO_CD(+) = EXPD_CO_CD
										                 AND A.QLTY_VEHL_CD = B.QLTY_VEHL_CD(+)
									                    ) A,
										                TB_VEHL_MDY_MGMT B
       								               WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD(+)
       								               AND A.EXPD_REGN_CD = B.DL_EXPD_REGN_CD(+)
       								               AND A.MO_PACK_CD >= B.DESMP1_CD(+)
       								               AND A.MO_PACK_CD <= B.DEFMP1_CD(+)
       							                  ) A,
       								              TB_NATL_LANG_MGMT B
								             WHERE A.EXPD_NAT_CD = B.DL_EXPD_NAT_CD(+)
								             AND B.DL_EXPD_CO_CD(+) = EXPD_CO_CD
								             AND A.QLTY_VEHL_CD = B.QLTY_VEHL_CD(+)
								             AND A.MDL_MDY_CD = B.MDL_MDY_CD(+)
											)
									   WHERE LANG_CD IS NULL
									   GROUP BY QLTY_VEHL_CD, MDL_MDY_CD, EXPD_NAT_CD, MO_PACK_CD;
		 							   **/

									   /**  이전버전
		 							   SELECT B.QLTY_VEHL_CD,
											  A.MO_PACK_CD,
											  A.DEST_NAT_CD,
											  SUM(A.ORD_QTY) AS ORD_QTY,
       	                                      SUM(A.PRDN_PLN_QTY) AS PRDN_PLN_QTY
									   FROM TB_APS_ODR_INFO A,
										    TB_ALTN_VEHL_MGMT B
									   WHERE A.DL_EXPD_CO_CD = EXPD_CO_CD
									   AND A.APL_STRT_YMD <= CURR_YMD
									   AND A.APL_FNH_YMD >= CURR_YMD
									   AND A.DYTM_PLN_VEHL_CD = B.PRDN_VEHL_CD
									   AND B.PRVS_SCN_CD = 'A'
									   AND NOT EXISTS (SELECT 'EXIST'
												       FROM TB_NATL_MGMT
													   WHERE DYTM_PLN_NAT_CD = A.DEST_NAT_CD
													   AND DL_EXPD_CO_CD = EXPD_CO_CD
												      )
									   GROUP BY B.QLTY_VEHL_CD,
									            A.MO_PACK_CD,
       											A.DEST_NAT_CD;
									    **/

		 --오더내역 조회를 위한 부분
	   	 CURSOR APS_ODR_INFO IS SELECT B.LANG_CD,
       								   A.MDL_MDY_CD,
       								   A.QLTY_VEHL_CD,
       								   A.MO_PACK_CD,
       								   SUM(A.ORD_QTY) AS ORD_QTY,
       								   SUM(A.PRDN_PLN_QTY) AS PRDN_PLN_QTY
       							FROM (SELECT B.MDL_MDY_CD AS MDL_MDY_CD,
       									  	 A.EXPD_NAT_CD,
       										 A.QLTY_VEHL_CD,
       										 A.MO_PACK_CD,
       										 A.ORD_QTY,
       										 A.PRDN_PLN_QTY
       								  FROM (SELECT B.DL_EXPD_REGN_CD AS EXPD_REGN_CD,
									               A.EXPD_NAT_CD,
												   A.QLTY_VEHL_CD,
												   A.MO_PACK_CD,
												   A.ORD_QTY,
												   A.PRDN_PLN_QTY
									        FROM (SELECT B.DL_EXPD_NAT_CD AS EXPD_NAT_CD,
       											         A.QLTY_VEHL_CD,
       											         A.MO_PACK_CD,
       											         A.ORD_QTY,
       											         A.PRDN_PLN_QTY
       									          FROM (--차종코드 테이블에 등록되어 있는 내역만을 조회하도록 한다.
												  	    SELECT B.QLTY_VEHL_CD,
												 		       A.MO_PACK_CD,
														       A.DEST_NAT_CD,
														       SUM(A.ORD_QTY) AS ORD_QTY,
       	                                                       SUM(A.PRDN_PLN_QTY) AS PRDN_PLN_QTY
												        FROM TB_APS_ODR_INFO A,
												             TB_ALTN_VEHL_MGMT B
												        WHERE A.DL_EXPD_CO_CD = EXPD_CO_CD
                                                        AND A.APL_STRT_YMD <= CURR_YMD
                                                        AND A.APL_FNH_YMD >= CURR_YMD
												        AND A.DYTM_PLN_VEHL_CD = B.PRDN_VEHL_CD
												        AND B.PRVS_SCN_CD = 'A'
												        GROUP BY B.QLTY_VEHL_CD,
       													         A.MO_PACK_CD,
       													         A.DEST_NAT_CD
       										           ) A,
       										           TB_ALTN_NATL_MGMT B
												  WHERE B.DL_EXPD_CO_CD = EXPD_CO_CD
											      AND A.DEST_NAT_CD = B.DYTM_PLN_NAT_CD
											      AND B.PRVS_SCN_CD = 'A'
									             ) A,
												 TB_NATL_VEHL_MGMT B
										    WHERE A.EXPD_NAT_CD = B.DL_EXPD_NAT_CD
										    AND B.DL_EXPD_CO_CD = EXPD_CO_CD
										    AND A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
									       ) A,
										   TB_VEHL_MDY_MGMT B
       								  WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
       								  AND A.EXPD_REGN_CD = B.DL_EXPD_REGN_CD
       								  AND A.MO_PACK_CD >= B.DESMP1_CD
       								  AND A.MO_PACK_CD <= B.DEFMP1_CD
       							     ) A,
       								 TB_NATL_LANG_MGMT B
								WHERE A.EXPD_NAT_CD = B.DL_EXPD_NAT_CD
								AND B.DL_EXPD_CO_CD = EXPD_CO_CD
								AND A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
								AND A.MDL_MDY_CD = B.MDL_MDY_CD
								GROUP BY B.LANG_CD, A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.MO_PACK_CD;

		 					    /**  이전버전
		 					    SELECT NVL(B.LANG_CD, 'N/A') AS LANG_CD,
       								   A.MDL_MDY_CD,
       								   A.QLTY_VEHL_CD,
       								   A.MO_PACK_CD,
       								   SUM(A.ORD_QTY) AS ORD_QTY,
       								   SUM(A.PRDN_PLN_QTY) AS PRDN_PLN_QTY
       							FROM (SELECT NVL(B.MDL_MDY_CD, 'N/A') AS MDL_MDY_CD,
       									  	 A.EXPD_NAT_CD,
       										 A.QLTY_VEHL_CD,
       										 A.MO_PACK_CD,
       										 A.ORD_QTY,
       										 A.PRDN_PLN_QTY
       								  FROM (SELECT NVL(B.DL_EXPD_REGN_CD, 'N/A') AS EXPD_REGN_CD,
									               A.EXPD_NAT_CD,
												   A.QLTY_VEHL_CD,
												   A.MO_PACK_CD,
												   A.ORD_QTY,
												   A.PRDN_PLN_QTY
									        FROM (SELECT NVL(B.DL_EXPD_NAT_CD, 'N/A') AS EXPD_NAT_CD,
       											         A.QLTY_VEHL_CD,
       											         A.MO_PACK_CD,
       											         A.ORD_QTY,
       											         A.PRDN_PLN_QTY
       									          FROM (--차종코드 테이블에 등록되어 있는 내역만을 조회하도록 한다.
												  	    SELECT B.QLTY_VEHL_CD,
												 		       A.MO_PACK_CD,
														       A.DEST_NAT_CD,
														       SUM(A.ORD_QTY) AS ORD_QTY,
       	                                                       SUM(A.PRDN_PLN_QTY) AS PRDN_PLN_QTY
												        FROM TB_APS_ODR_INFO A,
												             TB_ALTN_VEHL_MGMT B
												        WHERE A.DL_EXPD_CO_CD = EXPD_CO_CD
                                                        AND A.APL_STRT_YMD <= CURR_YMD
                                                        AND A.APL_FNH_YMD >= CURR_YMD
												        AND A.DYTM_PLN_VEHL_CD = B.PRDN_VEHL_CD
												        AND B.PRVS_SCN_CD = 'A'
												        GROUP BY B.QLTY_VEHL_CD,
       													         A.MO_PACK_CD,
       													         A.DEST_NAT_CD
       										           ) A,
       										           TB_ALTN_NATL_MGMT B
											      WHERE A.DEST_NAT_CD = B.DYTM_PLN_NAT_CD(+)
											      AND B.DL_EXPD_CO_CD(+) = EXPD_CO_CD
												  AND B.PRVS_SCN_CD(+) = 'A'
									             ) A,
												 TB_NATL_VEHL_MGMT B
										    WHERE A.EXPD_NAT_CD = B.DL_EXPD_NAT_CD(+)
										    AND B.DL_EXPD_CO_CD(+) = EXPD_CO_CD
										    AND A.QLTY_VEHL_CD = B.QLTY_VEHL_CD(+)
									       ) A,
										   TB_VEHL_MDY_MGMT B
       								  WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD(+)
       								  AND A.EXPD_REGN_CD = B.DL_EXPD_REGN_CD(+)
       								  AND A.MO_PACK_CD >= B.DESMP1_CD(+)
       								  AND A.MO_PACK_CD <= B.DEFMP1_CD(+)
       							     ) A,
       								 TB_NATL_LANG_MGMT B
								WHERE A.EXPD_NAT_CD = B.DL_EXPD_NAT_CD(+)
								AND B.DL_EXPD_CO_CD(+) = EXPD_CO_CD
								AND A.QLTY_VEHL_CD = B.QLTY_VEHL_CD(+)
								AND A.MDL_MDY_CD = B.MDL_MDY_CD(+)
								GROUP BY B.LANG_CD, A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.MO_PACK_CD;
								**/
	   BEGIN

			/* 연계국가코드 미사용으로 제외
			FOR NATL_LIST IN APS_NATL_INFO LOOP

				UPDATE TB_NATL_NOAPIM_MGMT
				SET DYTM_PLN_NAT_CD = NATL_LIST.DEST_NAT_CD,
				    PRDN_MST_NAT_CD = NATL_LIST.DEST_NAT_CD,
				    UPDR_EENO = BTCH_USER_EENO,
				    MDFY_DTM = SYSDATE
				WHERE DL_EXPD_CO_CD = EXPD_CO_CD
				AND DL_EXPD_NAT_CD = NATL_LIST.DEST_NAT_CD;

				IF SQL%NOTFOUND THEN

				    --등록되지 않은 국가코드일 경우에는 국가코드 테이블에 값을 등록한다.
    				INSERT INTO TB_NATL_NOAPIM_MGMT
    				(DL_EXPD_CO_CD,
    				 DL_EXPD_NAT_CD,
    				 DYTM_PLN_NAT_CD,
    				 PRDN_MST_NAT_CD,
    				 PPRR_EENO,
    				 FRAM_DTM,
    				 UPDR_EENO,
    				 MDFY_DTM
    				)
    				VALUES
    				(EXPD_CO_CD,
    				 NATL_LIST.DEST_NAT_CD,
    				 NATL_LIST.DEST_NAT_CD,
    				 NATL_LIST.DEST_NAT_CD,
    				 BTCH_USER_EENO,
    				 SYSDATE,
    				 BTCH_USER_EENO,
    				 SYSDATE
    				);

				END IF;

			END LOOP;
			*/

			--현재일의 미지정내역을 삭제한 뒤 작업을 진행한다.
			--[주의] 회사구분이 존재하지 않으므로 아래와 같이 차종이 회사에 소속된
			--       내역만을 삭제해 주어야 한다.
			DELETE FROM TB_APS_ODR_NOAPIM_INFO A
			WHERE A.APL_YMD = CURR_YMD
			AND EXISTS (SELECT 'EXIST'
                        FROM TB_VEHL_MGMT
			            WHERE QLTY_VEHL_CD = A.QLTY_VEHL_CD
			            AND DL_EXPD_CO_CD = EXPD_CO_CD
		                AND ROWNUM <= 1
		               );

			FOR NOAPIM_LIST IN APS_NOAPIM_ODR_INFO LOOP

				INSERT INTO TB_APS_ODR_NOAPIM_INFO
			    (APL_YMD,
			     MO_PACK_CD,
				 QLTY_VEHL_CD,
				 MDL_MDY_CD,
				 DYTM_PLN_NAT_CD,
				 ORD_QTY,
				 PRDN_PLN_QTY,
				 FRAM_DTM,
				 MDFY_DTM
			    )
				VALUES
				(CURR_YMD,
				 NOAPIM_LIST.MO_PACK_CD,
				 NOAPIM_LIST.QLTY_VEHL_CD,
				 --NOAPIM_LIST.MDL_MDY_CD,
				 'N/A', --연식은 무조건 N/A로 입력한다.
				 NOAPIM_LIST.EXPD_NAT_CD,
				 NOAPIM_LIST.ORD_QTY,
				 NOAPIM_LIST.PRDN_PLN_QTY,
				 SYSDATE,
				 SYSDATE
			    );

			END LOOP;

			FOR ODR_LIST IN APS_ODR_INFO LOOP

			   --변경여부를 검사할 데이터가 존재하는지의 여부를 확인
			   SELECT MAX(APL_FNH_YMD)
			   INTO V_APL_FNH_YMD
			   FROM TB_APS_ODR_SUM_INFO A
			   WHERE A.APL_STRT_YMD <= CURR_YMD
			   AND A.APL_FNH_YMD <= CURR_YMD --현재일 이전의 데이터에서 조회하도록 한다...
			   AND A.MO_PACK_CD = ODR_LIST.MO_PACK_CD
		       AND A.QLTY_VEHL_CD = ODR_LIST.QLTY_VEHL_CD
		       AND A.MDL_MDY_CD = ODR_LIST.MDL_MDY_CD
		       AND A.LANG_CD = ODR_LIST.LANG_CD;

			   IF V_APL_FNH_YMD IS NULL THEN

				  --지금까지 한번도 추가되지 않은 경우(무조건 Insert 해 준다.)
				  INSERT INTO TB_APS_ODR_SUM_INFO
   		    	  (APL_STRT_YMD,
				   APL_FNH_YMD,
				   MO_PACK_CD,
				   DATA_SN,
   				   QLTY_VEHL_CD,
   			 	   MDL_MDY_CD,
   			 	   LANG_CD,
   			 	   ORD_QTY,
   			 	   PRDN_PLN_QTY,
   			 	   PRDN_QTY,
   			 	   FRAM_DTM
   				  )
				  SELECT CURR_YMD,
				         CURR_YMD,
						 ODR_LIST.MO_PACK_CD,
				         A.DATA_SN,
						 ODR_LIST.QLTY_VEHL_CD,
						 ODR_LIST.MDL_MDY_CD,
						 ODR_LIST.LANG_CD,
						 ODR_LIST.ORD_QTY,
						 ODR_LIST.PRDN_PLN_QTY,
						 ODR_LIST.ORD_QTY - ODR_LIST.PRDN_PLN_QTY,
						 SYSDATE
				  FROM TB_LANG_MGMT A
				  WHERE A.QLTY_VEHL_CD = ODR_LIST.QLTY_VEHL_CD
				  AND A.MDL_MDY_CD = ODR_LIST.MDL_MDY_CD
				  AND A.LANG_CD = ODR_LIST.LANG_CD;

			   ELSE

				   --바로이전의 데이터가 변경되지 않은 경우에는 종료일 업데이트만 해준다.
				   UPDATE TB_APS_ODR_SUM_INFO A
		 	   	   SET APL_FNH_YMD = CURR_YMD --적용완료일을 현재일로 해준다.
			   	   WHERE A.APL_STRT_YMD <= CURR_YMD
			   	   AND A.APL_FNH_YMD = V_APL_FNH_YMD
			   	   AND A.MO_PACK_CD = ODR_LIST.MO_PACK_CD
		       	   AND A.QLTY_VEHL_CD = ODR_LIST.QLTY_VEHL_CD
		       	   AND A.MDL_MDY_CD = ODR_LIST.MDL_MDY_CD
		       	   AND A.LANG_CD = ODR_LIST.LANG_CD
				   AND A.ORD_QTY = ODR_LIST.ORD_QTY
				   AND A.PRDN_PLN_QTY = ODR_LIST.PRDN_PLN_QTY;

				   IF SQL%NOTFOUND THEN

					  INSERT INTO TB_APS_ODR_SUM_INFO
     		    	      (APL_STRT_YMD,
 					       APL_FNH_YMD,
 					       MO_PACK_CD,
 					       DATA_SN,
     				       QLTY_VEHL_CD,
     			 	       MDL_MDY_CD,
     			 	       LANG_CD,
     			 	       ORD_QTY,
     			 	       PRDN_PLN_QTY,
     			 	       PRDN_QTY,
     			 	       FRAM_DTM
     				      )
 					      SELECT CURR_YMD,
 					             CURR_YMD,
 							     ODR_LIST.MO_PACK_CD,
 					             A.DATA_SN,
 							     ODR_LIST.QLTY_VEHL_CD,
 							     ODR_LIST.MDL_MDY_CD,
 							     ODR_LIST.LANG_CD,
 							     ODR_LIST.ORD_QTY,
 							     ODR_LIST.PRDN_PLN_QTY,
 							     ODR_LIST.ORD_QTY - ODR_LIST.PRDN_PLN_QTY,
 							     SYSDATE
 					      FROM TB_LANG_MGMT A
 					      WHERE A.QLTY_VEHL_CD = ODR_LIST.QLTY_VEHL_CD
 					      AND A.MDL_MDY_CD = ODR_LIST.MDL_MDY_CD
 					      AND A.LANG_CD = ODR_LIST.LANG_CD;

				   END IF;

			   END IF;

			END LOOP;

			--오더정보 취합 작업 수행
			GET_APS_ODR_SUM_DTL(CURR_YMD,
								CURR_YMD,
								EXPD_CO_CD);

	   END GET_APS_ODR_SUM;
/**********************************************************/
/**********************************************************/
	   --신버전 현재 사용
	   PROCEDURE GET_APS_ODR_SUM2(CURR_YMD   IN VARCHAR2,
	                              EXPD_CO_CD IN VARCHAR2)
	   IS

	   	 V_APL_FNH_YMD VARCHAR2(8);

		 V_MDL_MDY_CD  VARCHAR2(2);

		 V_CNT		   NUMBER;

		 --국가코드 조회를 위한 부분(등록되어 있지 않은 데이터만 읽어온다.)
		 /* 연계국가코드 미사용으로 제외
		 CURSOR APS_NATL_INFO IS SELECT DEST_NAT_CD
		                         FROM TB_APS_ODR_INFO
								 WHERE DL_EXPD_CO_CD = EXPD_CO_CD
                                 AND APL_STRT_YMD <= CURR_YMD
                                 AND APL_FNH_YMD >= CURR_YMD
								 AND QLTY_VEHL_CD IS NOT NULL --현재 사용중인 차종에 대해서만 가져오도록 한다.
								 AND DL_EXPD_NAT_CD IS NULL   --취급설명서국가코드가 등록되지 않은 항목만 가져온다.
								 GROUP BY DEST_NAT_CD;
		 */

		 /**** [2009-04-08] 국가미지정 오더정보는 현시점부터 가져오지 않도록 한다.

		 --국가미지정 정보를 가져오는 부분
		 CURSOR APS_NOAPIM_ODR_INFO IS SELECT DEST_NAT_CD AS EXPD_NAT_CD,
		 							   		  QLTY_VEHL_CD,
		 							   		  MO_PACK_CD,
											  SUM(ORD_QTY) AS ORD_QTY,
											  SUM(PRDN_PLN_QTY) AS PRDN_PLN_QTY
									   FROM TB_APS_ODR_INFO
									   WHERE DL_EXPD_CO_CD = EXPD_CO_CD
									   AND APL_STRT_YMD <= CURR_YMD
									   AND APL_FNH_YMD >= CURR_YMD
									   AND QLTY_VEHL_CD IS NOT NULL --현재 사용중인 차종에 대해서만 가져오도록 한다.
		 							   AND DL_EXPD_NAT_CD IS NULL   --취급설명서국가코드가 등록되지 않은 항목만 가져온다.
									   GROUP BY QLTY_VEHL_CD,
       										    MO_PACK_CD,
       											DEST_NAT_CD;
		 ****/

		 --오더내역 조회를 위한 부분
		 --(PDI 공통차종 오더내역 조회 부분 포함)
	   	 CURSOR APS_ODR_INFO IS WITH T AS (SELECT A.QLTY_VEHL_CD,
									              A.MDL_MDY_CD,
									   			  B.LANG_CD,
									   			  A.MO_PACK_CD,
									   			  SUM(A.ORD_QTY) AS ORD_QTY,
									   			  SUM(A.PRDN_PLN_QTY) AS PRDN_PLN_QTY
		 					               FROM (SELECT QLTY_VEHL_CD,
									 		            MDL_MDY_CD,
											            MO_PACK_CD,
											 			DL_EXPD_NAT_CD AS EXPD_NAT_CD,
											 			SUM(ORD_QTY) AS ORD_QTY,
       	                                     			SUM(PRDN_PLN_QTY) AS PRDN_PLN_QTY
									             FROM TB_APS_ODR_INFO
									  			 WHERE DL_EXPD_CO_CD = EXPD_CO_CD
                                      			 AND APL_STRT_YMD <= CURR_YMD
                                      			 AND APL_FNH_YMD >= CURR_YMD
									  			 AND QLTY_VEHL_CD IS NOT NULL   --현재 사용중인 차종에 대해서만 가져오도록 한다.
									  			 AND MDL_MDY_CD IS NOT NULL     --연식이 지정된 항목만 가져온다.
									  			 AND DL_EXPD_NAT_CD IS NOT NULL --취급설명서국가코드가 등록된 항목만 가져온다.
									  			 GROUP BY QLTY_VEHL_CD,
									  		   	 	      MDL_MDY_CD,
       								           			  MO_PACK_CD,
											   			  DL_EXPD_NAT_CD
								                ) A,
									 			TB_NATL_LANG_MGMT B
								           WHERE A.EXPD_NAT_CD = B.DL_EXPD_NAT_CD
										   AND B.DL_EXPD_CO_CD = EXPD_CO_CD
										   AND A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
										   AND A.MDL_MDY_CD = B.MDL_MDY_CD
										   GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, B.LANG_CD, A.MO_PACK_CD
		 					 		   	  )
                                SELECT QLTY_VEHL_CD,
                                       MDL_MDY_CD,
                                       LANG_CD,
                                       MO_PACK_CD,
                                       SUM(ORD_QTY) ORD_QTY,
                                       SUM(PRDN_PLN_QTY) PRDN_PLN_QTY
                                FROM
                                (
                                    SELECT QLTY_VEHL_CD,
                                           MDL_MDY_CD,
                                           LANG_CD,
                                           MO_PACK_CD,
                                           ORD_QTY,
                                           PRDN_PLN_QTY
                                    FROM T

                                    UNION ALL

                                    SELECT B.DIVS_QLTY_VEHL_CD AS QLTY_VEHL_CD,
                                           B.MDL_MDY_CD,
                                           B.LANG_CD,
                                           A.MO_PACK_CD,
                                           SUM(A.ORD_QTY) AS ORD_QTY,
                                           SUM(A.PRDN_PLN_QTY) AS PRDN_PLN_QTY
                                    FROM T A,
                                         TB_PDI_COM_VEHL_MGMT B
                                    WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
                                    AND A.MDL_MDY_CD = B.MDL_MDY_CD
                                    AND A.LANG_CD = B.LANG_CD
                                    GROUP BY B.DIVS_QLTY_VEHL_CD, B.MDL_MDY_CD, B.LANG_CD, A.MO_PACK_CD
                                )
                                GROUP BY QLTY_VEHL_CD, MDL_MDY_CD, LANG_CD, MO_PACK_CD
                                ;

		 /***
		 --오더내역 조회를 위한 부분
	   	 CURSOR APS_ODR_INFO IS SELECT A.QLTY_VEHL_CD,
									   A.MDL_MDY_CD,
									   B.LANG_CD,
									   A.MO_PACK_CD,
									   SUM(A.ORD_QTY) AS ORD_QTY,
									   SUM(A.PRDN_PLN_QTY) AS PRDN_PLN_QTY
		 					    FROM (SELECT QLTY_VEHL_CD,
									 		 MDL_MDY_CD,
											 MO_PACK_CD,
											 DL_EXPD_NAT_CD AS EXPD_NAT_CD,
											 SUM(ORD_QTY) AS ORD_QTY,
       	                                     SUM(PRDN_PLN_QTY) AS PRDN_PLN_QTY
									  FROM TB_APS_ODR_INFO
									  WHERE DL_EXPD_CO_CD = EXPD_CO_CD
                                      AND APL_STRT_YMD <= CURR_YMD
                                      AND APL_FNH_YMD >= CURR_YMD
									  AND QLTY_VEHL_CD IS NOT NULL   --현재 사용중인 차종에 대해서만 가져오도록 한다.
									  AND MDL_MDY_CD IS NOT NULL     --연식이 지정된 항목만 가져온다.
									  AND DL_EXPD_NAT_CD IS NOT NULL --취급설명서국가코드가 등록된 항목만 가져온다.
									  GROUP BY QLTY_VEHL_CD,
									  		   MDL_MDY_CD,
       								           MO_PACK_CD,
											   DL_EXPD_NAT_CD
								     ) A,
									 TB_NATL_LANG_MGMT B
								WHERE A.EXPD_NAT_CD = B.DL_EXPD_NAT_CD
								AND B.DL_EXPD_CO_CD = EXPD_CO_CD
								AND A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
								AND A.MDL_MDY_CD = B.MDL_MDY_CD
								GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, B.LANG_CD, A.MO_PACK_CD;
		  ***/

		  --[추가] 2010.04.14.김동근 오더정보 현황 - 공장별 내역 조회
		  CURSOR PLNT_ODR_INFO IS WITH T AS (SELECT A.QLTY_VEHL_CD,
									                A.MDL_MDY_CD,
									   			    B.LANG_CD,
									   			    A.MO_PACK_CD,
									   			    SUM(A.ORD_QTY) AS ORD_QTY,
									   			    SUM(A.PRDN_PLN_QTY) AS PRDN_PLN_QTY,
													A.PRDN_PLNT_CD
		 					                 FROM (SELECT A.QLTY_VEHL_CD,
									 		              A.MDL_MDY_CD,
											              A.MO_PACK_CD,
											 			  A.DL_EXPD_NAT_CD AS EXPD_NAT_CD,
											 			  SUM(A.ORD_QTY) AS ORD_QTY,
       	                                     			  SUM(A.PRDN_PLN_QTY) AS PRDN_PLN_QTY,
														  B.PRDN_PLNT_CD
									               FROM TB_APS_ODR_INFO A,
												        TB_PLNT_VEHL_MGMT B
									  			   WHERE A.DL_EXPD_CO_CD = EXPD_CO_CD
                                      			   AND A.APL_STRT_YMD <= CURR_YMD
                                      			   AND A.APL_FNH_YMD >= CURR_YMD
												   AND A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
												   --TB_APS_ODR_INFO테이블의 공장코드에는 빈문자가 포함되어 있을 수 있다.
												   --그래서 TRIM 함수를 사용함
												   AND TRIM(A.PRDN_PLNT_CD) = B.PRDN_PLNT_CD
									  			   AND A.QLTY_VEHL_CD IS NOT NULL   --현재 사용중인 차종에 대해서만 가져오도록 한다.
									  			   AND A.MDL_MDY_CD IS NOT NULL     --연식이 지정된 항목만 가져온다.
									  			   AND A.DL_EXPD_NAT_CD IS NOT NULL --취급설명서국가코드가 등록된 항목만 가져온다.
									  			   GROUP BY A.QLTY_VEHL_CD,
									  		   	 	        A.MDL_MDY_CD,
       								           			    A.MO_PACK_CD,
											   			    A.DL_EXPD_NAT_CD,
															B.PRDN_PLNT_CD
								                  ) A,
									 			  TB_NATL_LANG_MGMT B
								             WHERE A.EXPD_NAT_CD = B.DL_EXPD_NAT_CD
										     AND B.DL_EXPD_CO_CD = EXPD_CO_CD
										     AND A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
										     AND A.MDL_MDY_CD = B.MDL_MDY_CD
										     GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, B.LANG_CD, A.MO_PACK_CD, A.PRDN_PLNT_CD
		 					 		   	    )
								  SELECT QLTY_VEHL_CD,
									     MDL_MDY_CD,
									     LANG_CD,
									     MO_PACK_CD,
									     ORD_QTY,
									     PRDN_PLN_QTY,
										 PRDN_PLNT_CD
								  FROM T

								  UNION ALL

								  SELECT B.DIVS_QLTY_VEHL_CD AS QLTY_VEHL_CD,
								         B.MDL_MDY_CD,
									     B.LANG_CD,
									     A.MO_PACK_CD,
									     SUM(A.ORD_QTY) AS ORD_QTY,
									     SUM(A.PRDN_PLN_QTY) AS PRDN_PLN_QTY,
										 A.PRDN_PLNT_CD
								  FROM T A,
								       TB_PDI_COM_VEHL_MGMT B
							      WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
								  AND A.MDL_MDY_CD = B.MDL_MDY_CD
								  AND A.LANG_CD = B.LANG_CD
								  GROUP BY B.DIVS_QLTY_VEHL_CD, B.MDL_MDY_CD, B.LANG_CD, A.MO_PACK_CD, A.PRDN_PLNT_CD;
	   BEGIN

         --WRITE_BATCH_EXE_LOG('APS배치작업_KMC', SYSDATE, 'S', 'GET_APS_ODR_SUM2 : #1.');
         	/* 연계국가코드 미사용으로 제외
			FOR NATL_LIST IN APS_NATL_INFO LOOP

				SELECT COUNT(*)
				INTO V_CNT
				FROM TB_ALTN_NATL_MGMT
				WHERE DL_EXPD_CO_CD = EXPD_CO_CD
				AND DYTM_PLN_NAT_CD = NATL_LIST.DEST_NAT_CD
				AND PRVS_SCN_CD = 'A';

				IF V_CNT = 0 THEN

				   UPDATE TB_NATL_NOAPIM_MGMT
				   SET DYTM_PLN_NAT_CD = NATL_LIST.DEST_NAT_CD,
				       PRDN_MST_NAT_CD = NATL_LIST.DEST_NAT_CD,
					   NAT_NM = FU_GET_NOAPIM_NAT_NM(EXPD_CO_CD, NATL_LIST.DEST_NAT_CD),
				       UPDR_EENO = BTCH_USER_EENO,
				       MDFY_DTM = SYSDATE
				   WHERE DL_EXPD_CO_CD = EXPD_CO_CD
				   AND DL_EXPD_NAT_CD = NATL_LIST.DEST_NAT_CD;

				   IF SQL%NOTFOUND THEN

				      --등록되지 않은 국가코드일 경우에는 국가코드 테이블에 값을 등록한다.
    				  INSERT INTO TB_NATL_NOAPIM_MGMT
    				  (DL_EXPD_CO_CD,
    				   DL_EXPD_NAT_CD,
    				   DYTM_PLN_NAT_CD,
    				   PRDN_MST_NAT_CD,
					   NAT_NM,
    				   PPRR_EENO,
    				   FRAM_DTM,
    				   UPDR_EENO,
    				   MDFY_DTM
    				  )
    				  VALUES
    				  (EXPD_CO_CD,
    				   NATL_LIST.DEST_NAT_CD,
    				   NATL_LIST.DEST_NAT_CD,
    				   NATL_LIST.DEST_NAT_CD,
					   FU_GET_NOAPIM_NAT_NM(EXPD_CO_CD, NATL_LIST.DEST_NAT_CD),
    				   BTCH_USER_EENO,
    				   SYSDATE,
    				   BTCH_USER_EENO,
    				   SYSDATE
    				  );

				   END IF;

				END IF;

			END LOOP;
			*/

			/**** [2009-04-08] 국가미지정 오더정보는 현시점부터 가져오지 않도록 한다.

			--현재일의 미지정내역을 삭제한 뒤 작업을 진행한다.
			--[주의] 회사구분이 존재하지 않으므로 아래와 같이 차종이 회사에 소속된
			--       내역만을 삭제해 주어야 한다.
			DELETE FROM TB_APS_ODR_NOAPIM_INFO A
			WHERE A.APL_YMD = CURR_YMD
			AND EXISTS (SELECT 'EXIST'
                        FROM TB_VEHL_MGMT
			            WHERE QLTY_VEHL_CD = A.QLTY_VEHL_CD
			            AND DL_EXPD_CO_CD = EXPD_CO_CD
		                AND ROWNUM <= 1
		               );

			FOR NOAPIM_LIST IN APS_NOAPIM_ODR_INFO LOOP

				INSERT INTO TB_APS_ODR_NOAPIM_INFO
			    (APL_YMD,
			     MO_PACK_CD,
				 QLTY_VEHL_CD,
				 MDL_MDY_CD,
				 DYTM_PLN_NAT_CD,
				 ORD_QTY,
				 PRDN_PLN_QTY,
				 FRAM_DTM,
				 MDFY_DTM
			    )
				VALUES
				(CURR_YMD,
				 NOAPIM_LIST.MO_PACK_CD,
				 NOAPIM_LIST.QLTY_VEHL_CD,
				 --NOAPIM_LIST.MDL_MDY_CD,
				 'N/A', --연식은 무조건 N/A로 입력한다.
				 NOAPIM_LIST.EXPD_NAT_CD,
				 NOAPIM_LIST.ORD_QTY,
				 NOAPIM_LIST.PRDN_PLN_QTY,
				 SYSDATE,
				 SYSDATE
			    );

			END LOOP;

			****/

         --WRITE_BATCH_EXE_LOG('APS배치작업_KMC', SYSDATE, 'S', 'GET_APS_ODR_SUM2 : #2.');

			--과거일에 입력되었으나 데이터가 변경되지 않아서 현재일 이후로 종료일이 설정 되어 있는 경우에는
			--종료일을 하루전으로 설정해 준다.
			UPDATE TB_APS_ODR_SUM_INFO A
			SET A.APL_FNH_YMD = TO_CHAR(TO_DATE(CURR_YMD, 'YYYYMMDD') - 1, 'YYYYMMDD')
			WHERE A.APL_STRT_YMD < CURR_YMD
			AND A.APL_FNH_YMD >= CURR_YMD
			AND EXISTS (SELECT 'EXIST'
                        FROM TB_VEHL_MGMT
			            WHERE QLTY_VEHL_CD = A.QLTY_VEHL_CD
			            AND DL_EXPD_CO_CD = EXPD_CO_CD
		                AND ROWNUM <= 1
		               );

         --WRITE_BATCH_EXE_LOG('APS배치작업_KMC', SYSDATE, 'S', 'GET_APS_ODR_SUM2 : #3.');

			--현재일에 순수하게 입력된 항목은 삭제하도록 한다.
			DELETE FROM TB_APS_ODR_SUM_INFO A
			WHERE A.APL_STRT_YMD = CURR_YMD
			AND A.APL_FNH_YMD >= CURR_YMD
			AND EXISTS (SELECT 'EXIST'
                        FROM TB_VEHL_MGMT
			            WHERE QLTY_VEHL_CD = A.QLTY_VEHL_CD
			            AND DL_EXPD_CO_CD = EXPD_CO_CD
		                AND ROWNUM <= 1
		               );

			--[추가] 2010.04.14.김동근 오더정보 현황 - 공장별 내역 삭제 기능 추가
         --WRITE_BATCH_EXE_LOG('APS배치작업_KMC', SYSDATE, 'S', 'GET_APS_ODR_SUM2 : #4.');

			UPDATE TB_PLNT_APS_ODR_SUM_INFO A
			SET A.APL_FNH_YMD = TO_CHAR(TO_DATE(CURR_YMD, 'YYYYMMDD') - 1, 'YYYYMMDD')
			WHERE A.APL_STRT_YMD < CURR_YMD
			AND A.APL_FNH_YMD >= CURR_YMD
			AND EXISTS (SELECT 'EXIST'
                        FROM TB_VEHL_MGMT
			            WHERE QLTY_VEHL_CD = A.QLTY_VEHL_CD
			            AND DL_EXPD_CO_CD = EXPD_CO_CD
		                AND ROWNUM <= 1
		               );

         --WRITE_BATCH_EXE_LOG('APS배치작업_KMC', SYSDATE, 'S', 'GET_APS_ODR_SUM2 : #5.');

			DELETE FROM TB_PLNT_APS_ODR_SUM_INFO A
			WHERE A.APL_STRT_YMD = CURR_YMD
			AND A.APL_FNH_YMD >= CURR_YMD
			AND EXISTS (SELECT 'EXIST'
                        FROM TB_VEHL_MGMT
			            WHERE QLTY_VEHL_CD = A.QLTY_VEHL_CD
			            AND DL_EXPD_CO_CD = EXPD_CO_CD
		                AND ROWNUM <= 1
		               );

         --WRITE_BATCH_EXE_LOG('APS배치작업_KMC', SYSDATE, 'S', 'GET_APS_ODR_SUM2 : #6.');

			FOR ODR_LIST IN APS_ODR_INFO LOOP

			   --변경여부를 검사할 데이터가 존재하는지의 여부를 확인
			   SELECT MAX(APL_FNH_YMD)
			   INTO V_APL_FNH_YMD
			   FROM TB_APS_ODR_SUM_INFO A
			   WHERE A.APL_STRT_YMD <= CURR_YMD
			   AND A.APL_FNH_YMD <= CURR_YMD --현재일 이전의 데이터에서 조회하도록 한다...
			   AND A.MO_PACK_CD = ODR_LIST.MO_PACK_CD
		       AND A.QLTY_VEHL_CD = ODR_LIST.QLTY_VEHL_CD
		       AND A.MDL_MDY_CD = ODR_LIST.MDL_MDY_CD
		       AND A.LANG_CD = ODR_LIST.LANG_CD;

			   IF V_APL_FNH_YMD IS NULL THEN

				  --지금까지 한번도 추가되지 않은 경우(무조건 Insert 해 준다.)
				  INSERT INTO TB_APS_ODR_SUM_INFO
   		    	  (APL_STRT_YMD,
				   APL_FNH_YMD,
				   MO_PACK_CD,
				   DATA_SN,
   				   QLTY_VEHL_CD,
   			 	   MDL_MDY_CD,
   			 	   LANG_CD,
   			 	   ORD_QTY,
   			 	   PRDN_PLN_QTY,
   			 	   PRDN_QTY,
   			 	   FRAM_DTM
   				  )
				  SELECT CURR_YMD,
				         CURR_YMD,
						 ODR_LIST.MO_PACK_CD,
				         A.DATA_SN,
						 ODR_LIST.QLTY_VEHL_CD,
						 ODR_LIST.MDL_MDY_CD,
						 ODR_LIST.LANG_CD,
						 ODR_LIST.ORD_QTY,
						 ODR_LIST.PRDN_PLN_QTY,
						 ODR_LIST.ORD_QTY - ODR_LIST.PRDN_PLN_QTY,
						 SYSDATE
				  FROM TB_LANG_MGMT A
				  WHERE A.QLTY_VEHL_CD = ODR_LIST.QLTY_VEHL_CD
				  AND A.MDL_MDY_CD = ODR_LIST.MDL_MDY_CD
				  AND A.LANG_CD = ODR_LIST.LANG_CD;

			   ELSE

				   --바로이전의 데이터가 변경되지 않은 경우에는 종료일 업데이트만 해준다.
				   UPDATE TB_APS_ODR_SUM_INFO A
		 	   	   SET APL_FNH_YMD = CURR_YMD --적용완료일을 현재일로 해준다.
			   	   WHERE A.APL_STRT_YMD <= CURR_YMD
			   	   AND A.APL_FNH_YMD = V_APL_FNH_YMD
			   	   AND A.MO_PACK_CD = ODR_LIST.MO_PACK_CD
		       	   AND A.QLTY_VEHL_CD = ODR_LIST.QLTY_VEHL_CD
		       	   AND A.MDL_MDY_CD = ODR_LIST.MDL_MDY_CD
		       	   AND A.LANG_CD = ODR_LIST.LANG_CD
				   AND A.ORD_QTY = ODR_LIST.ORD_QTY
				   AND A.PRDN_PLN_QTY = ODR_LIST.PRDN_PLN_QTY;

				   IF SQL%NOTFOUND THEN

					  INSERT INTO TB_APS_ODR_SUM_INFO
     		    	      (APL_STRT_YMD,
 					       APL_FNH_YMD,
 					       MO_PACK_CD,
 					       DATA_SN,
     				       QLTY_VEHL_CD,
     			 	       MDL_MDY_CD,
     			 	       LANG_CD,
     			 	       ORD_QTY,
     			 	       PRDN_PLN_QTY,
     			 	       PRDN_QTY,
     			 	       FRAM_DTM
     				      )
 					      SELECT CURR_YMD,
 					             CURR_YMD,
 							     ODR_LIST.MO_PACK_CD,
 					             A.DATA_SN,
 							     ODR_LIST.QLTY_VEHL_CD,
 							     ODR_LIST.MDL_MDY_CD,
 							     ODR_LIST.LANG_CD,
 							     ODR_LIST.ORD_QTY,
 							     ODR_LIST.PRDN_PLN_QTY,
 							     ODR_LIST.ORD_QTY - ODR_LIST.PRDN_PLN_QTY,
 							     SYSDATE
 					      FROM TB_LANG_MGMT A
 					      WHERE A.QLTY_VEHL_CD = ODR_LIST.QLTY_VEHL_CD
 					      AND A.MDL_MDY_CD = ODR_LIST.MDL_MDY_CD
 					      AND A.LANG_CD = ODR_LIST.LANG_CD;

				   END IF;

			   END IF;

			END LOOP;

         --WRITE_BATCH_EXE_LOG('APS배치작업_KMC', SYSDATE, 'S', 'GET_APS_ODR_SUM2 : #7.');

			--[추가] 2010.04.14.김동근 오더정보 현황 - 공장별 내역 저장
			FOR PLNT_ODR_LIST IN PLNT_ODR_INFO LOOP

			   --변경여부를 검사할 데이터가 존재하는지의 여부를 확인
			   SELECT MAX(APL_FNH_YMD)
			   INTO V_APL_FNH_YMD
			   FROM TB_PLNT_APS_ODR_SUM_INFO A
			   WHERE A.APL_STRT_YMD <= CURR_YMD
			   AND A.APL_FNH_YMD <= CURR_YMD --현재일 이전의 데이터에서 조회하도록 한다...
			   AND A.MO_PACK_CD = PLNT_ODR_LIST.MO_PACK_CD
		       AND A.QLTY_VEHL_CD = PLNT_ODR_LIST.QLTY_VEHL_CD
		       AND A.MDL_MDY_CD = PLNT_ODR_LIST.MDL_MDY_CD
		       AND A.LANG_CD = PLNT_ODR_LIST.LANG_CD
			   AND A.PRDN_PLNT_CD = PLNT_ODR_LIST.PRDN_PLNT_CD;

			   IF V_APL_FNH_YMD IS NULL THEN

				  --지금까지 한번도 추가되지 않은 경우(무조건 Insert 해 준다.)
				  INSERT INTO TB_PLNT_APS_ODR_SUM_INFO
   		    	  (APL_STRT_YMD,
				   APL_FNH_YMD,
				   MO_PACK_CD,
				   DATA_SN,
   				   QLTY_VEHL_CD,
   			 	   MDL_MDY_CD,
   			 	   LANG_CD,
   			 	   ORD_QTY,
   			 	   PRDN_PLN_QTY,
   			 	   PRDN_QTY,
   			 	   FRAM_DTM,
				   PRDN_PLNT_CD
   				  )
				  SELECT CURR_YMD,
				         CURR_YMD,
						 PLNT_ODR_LIST.MO_PACK_CD,
				         A.DATA_SN,
						 PLNT_ODR_LIST.QLTY_VEHL_CD,
						 PLNT_ODR_LIST.MDL_MDY_CD,
						 PLNT_ODR_LIST.LANG_CD,
						 PLNT_ODR_LIST.ORD_QTY,
						 PLNT_ODR_LIST.PRDN_PLN_QTY,
						 PLNT_ODR_LIST.ORD_QTY - PLNT_ODR_LIST.PRDN_PLN_QTY,
						 SYSDATE,
						 PLNT_ODR_LIST.PRDN_PLNT_CD
				  FROM TB_LANG_MGMT A
				  WHERE A.QLTY_VEHL_CD = PLNT_ODR_LIST.QLTY_VEHL_CD
				  AND A.MDL_MDY_CD = PLNT_ODR_LIST.MDL_MDY_CD
				  AND A.LANG_CD = PLNT_ODR_LIST.LANG_CD;

			   ELSE

				   --바로이전의 데이터가 변경되지 않은 경우에는 종료일 업데이트만 해준다.
				   UPDATE TB_PLNT_APS_ODR_SUM_INFO A
		 	   	   SET APL_FNH_YMD = CURR_YMD --적용완료일을 현재일로 해준다.
			   	   WHERE A.APL_STRT_YMD <= CURR_YMD
			   	   AND A.APL_FNH_YMD = V_APL_FNH_YMD
			   	   AND A.MO_PACK_CD = PLNT_ODR_LIST.MO_PACK_CD
		       	   AND A.QLTY_VEHL_CD = PLNT_ODR_LIST.QLTY_VEHL_CD
		       	   AND A.MDL_MDY_CD = PLNT_ODR_LIST.MDL_MDY_CD
		       	   AND A.LANG_CD = PLNT_ODR_LIST.LANG_CD
				   AND A.ORD_QTY = PLNT_ODR_LIST.ORD_QTY
				   AND A.PRDN_PLN_QTY = PLNT_ODR_LIST.PRDN_PLN_QTY
				   AND A.PRDN_PLNT_CD = PLNT_ODR_LIST.PRDN_PLNT_CD;

				   IF SQL%NOTFOUND THEN

					  INSERT INTO TB_PLNT_APS_ODR_SUM_INFO
     		    	      (APL_STRT_YMD,
 					       APL_FNH_YMD,
 					       MO_PACK_CD,
 					       DATA_SN,
     				       QLTY_VEHL_CD,
     			 	       MDL_MDY_CD,
     			 	       LANG_CD,
     			 	       ORD_QTY,
     			 	       PRDN_PLN_QTY,
     			 	       PRDN_QTY,
     			 	       FRAM_DTM,
						   PRDN_PLNT_CD
     				      )
 					      SELECT CURR_YMD,
 					             CURR_YMD,
 							     PLNT_ODR_LIST.MO_PACK_CD,
 					             A.DATA_SN,
 							     PLNT_ODR_LIST.QLTY_VEHL_CD,
 							     PLNT_ODR_LIST.MDL_MDY_CD,
 							     PLNT_ODR_LIST.LANG_CD,
 							     PLNT_ODR_LIST.ORD_QTY,
 							     PLNT_ODR_LIST.PRDN_PLN_QTY,
 							     PLNT_ODR_LIST.ORD_QTY - PLNT_ODR_LIST.PRDN_PLN_QTY,
 							     SYSDATE,
								 PLNT_ODR_LIST.PRDN_PLNT_CD
 					      FROM TB_LANG_MGMT A
 					      WHERE A.QLTY_VEHL_CD = PLNT_ODR_LIST.QLTY_VEHL_CD
 					      AND A.MDL_MDY_CD = PLNT_ODR_LIST.MDL_MDY_CD
 					      AND A.LANG_CD = PLNT_ODR_LIST.LANG_CD;

				   END IF;

			   END IF;

			END LOOP;

			--오더정보 취합 작업 수행
         --WRITE_BATCH_EXE_LOG('APS배치작업_KMC', SYSDATE, 'S', 'GET_APS_ODR_SUM2 : #8.');
			GET_APS_ODR_SUM_DTL(CURR_YMD,
								CURR_YMD,
								EXPD_CO_CD);

         --WRITE_BATCH_EXE_LOG('APS배치작업_KMC', SYSDATE, 'S', 'GET_APS_ODR_SUM2 : #9.');
	   END GET_APS_ODR_SUM2;
/**********************************************************/

/**********************************************************/
	   --화면에 표시되는 데이터의 형태로 오더 정보를 취합하는 작업을 수행
	   PROCEDURE GET_APS_ODR_SUM_DTL(CURR_YMD IN VARCHAR2,
	   			 					 SRCH_YMD IN VARCHAR2,
	                                 EXPD_CO_CD IN VARCHAR2)
	   IS

			V_CURR_DATE	DATE := TO_DATE(CURR_YMD, 'YYYYMMDD');

			V_CURR_PACK	VARCHAR2(4) := TO_CHAR(V_CURR_DATE, 'YYMM');
            V_PREV_PACK	VARCHAR2(4) := TO_CHAR(ADD_MONTHS(V_CURR_DATE, -1), 'YYMM');

	   	 	CURSOR APS_ODR_SUM_INFO IS SELECT MAX(DATA_SN) AS DATA_SN,
									   		  QLTY_VEHL_CD,
											  MDL_MDY_CD,
											  LANG_CD,
									   		  SUM(CURR_ORD_QTY) AS CURR_ORD_QTY,
											  SUM(PREV_ORD_QTY) AS PREV_ORD_QTY
				   					   FROM (SELECT MAX(A.DATA_SN) AS DATA_SN,
									   				A.QLTY_VEHL_CD,
													A.MDL_MDY_CD,
													A.LANG_CD,
									   				SUM(A.ORD_QTY) AS CURR_ORD_QTY,
													0 AS PREV_ORD_QTY
									   		 FROM TB_APS_ODR_SUM_INFO A,
									   		      TB_VEHL_MGMT B
											 WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
											 AND A.MDL_MDY_CD = B.MDL_MDY_CD
											 AND B.DL_EXPD_CO_CD = EXPD_CO_CD
											 AND A.APL_STRT_YMD <= SRCH_YMD
                                 			 AND A.APL_FNH_YMD >= SRCH_YMD
											 AND A.MO_PACK_CD = V_CURR_PACK
											 GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD

											 UNION ALL

											 SELECT MAX(A.DATA_SN) AS DATA_SN,
									   				A.QLTY_VEHL_CD,
													A.MDL_MDY_CD,
													A.LANG_CD,
									   				0 AS CURR_ORD_QTY,
													SUM(PRDN_PLN_QTY) AS PREV_ORD_QTY
									   		 FROM TB_APS_ODR_SUM_INFO A,
									   		      TB_VEHL_MGMT B
											 WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
											 AND A.MDL_MDY_CD = B.MDL_MDY_CD
											 AND B.DL_EXPD_CO_CD = EXPD_CO_CD
											 AND A.APL_STRT_YMD <= SRCH_YMD
                                 			 AND A.APL_FNH_YMD >= SRCH_YMD
											 AND A.MO_PACK_CD <= V_PREV_PACK
											 GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD
											)
									   WHERE CURR_ORD_QTY + PREV_ORD_QTY > 0
									   GROUP BY QLTY_VEHL_CD, MDL_MDY_CD, LANG_CD;

			--[추가] 2010.04.14.김동근 오더정보 현황 - 공장별 Summary 내역 조회
			CURSOR PLNT_ODR_SUM_INFO IS SELECT MAX(DATA_SN) AS DATA_SN,
									   		   QLTY_VEHL_CD,
											   MDL_MDY_CD,
											   LANG_CD,
									   		   SUM(CURR_ORD_QTY) AS CURR_ORD_QTY,
											   SUM(PREV_ORD_QTY) AS PREV_ORD_QTY,
											   PRDN_PLNT_CD
				   					    FROM (SELECT MAX(A.DATA_SN) AS DATA_SN,
									   				 A.QLTY_VEHL_CD,
													 A.MDL_MDY_CD,
													 A.LANG_CD,
									   				 SUM(A.ORD_QTY) AS CURR_ORD_QTY,
													 0 AS PREV_ORD_QTY,
													 A.PRDN_PLNT_CD
									   		  FROM TB_PLNT_APS_ODR_SUM_INFO A,
									   		       TB_VEHL_MGMT B
											  WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
											  AND A.MDL_MDY_CD = B.MDL_MDY_CD
											  AND B.DL_EXPD_CO_CD = EXPD_CO_CD
											  AND A.APL_STRT_YMD <= SRCH_YMD
                                 			  AND A.APL_FNH_YMD >= SRCH_YMD
											  AND A.MO_PACK_CD = V_CURR_PACK
											  GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD, A.PRDN_PLNT_CD

											  UNION ALL

											  SELECT MAX(A.DATA_SN) AS DATA_SN,
									   				 A.QLTY_VEHL_CD,
													 A.MDL_MDY_CD,
													 A.LANG_CD,
									   				 0 AS CURR_ORD_QTY,
													 SUM(PRDN_PLN_QTY) AS PREV_ORD_QTY,
													 A.PRDN_PLNT_CD
									   		  FROM TB_PLNT_APS_ODR_SUM_INFO A,
									   		       TB_VEHL_MGMT B
											  WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
											  AND A.MDL_MDY_CD = B.MDL_MDY_CD
											  AND B.DL_EXPD_CO_CD = EXPD_CO_CD
											  AND A.APL_STRT_YMD <= SRCH_YMD
                                 			  AND A.APL_FNH_YMD >= SRCH_YMD
											  AND A.MO_PACK_CD <= V_PREV_PACK
											  GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD, A.PRDN_PLNT_CD
											 )
									    WHERE CURR_ORD_QTY + PREV_ORD_QTY > 0
									    GROUP BY QLTY_VEHL_CD, MDL_MDY_CD, LANG_CD, PRDN_PLNT_CD;
	   BEGIN

			--이미 입력되었던 항목이 있다면 초기화 해준 후 진행한다.
			--[주의] 회사구분이 존재하지 않으므로 아래와 같이 차종이 회사에 소속된
			--       내역만을 삭제해 주어야 한다.
         --WRITE_BATCH_EXE_LOG('APS배치작업_KMC', SYSDATE, 'S', 'GET_APS_ODR_SUM_DTL : #1.');

			UPDATE TB_APS_PROD_SUM_INFO A
			SET TMM_ORD_QTY = 0,
			    BORD_QTY = 0,
				MDFY_DTM = SYSDATE
			WHERE APL_YMD = CURR_YMD
			AND EXISTS (SELECT 'EXIST'
                        FROM TB_VEHL_MGMT
			            WHERE QLTY_VEHL_CD = A.QLTY_VEHL_CD
			            AND DL_EXPD_CO_CD = EXPD_CO_CD
		                AND ROWNUM <= 1
		               );

         --WRITE_BATCH_EXE_LOG('APS배치작업_KMC', SYSDATE, 'S', 'GET_APS_ODR_SUM_DTL : #2.');
			--[추가] 2010.04.14.김동근 오더정보 현황 - 공장별 Summary 내역 초기화
			UPDATE TB_PLNT_APS_PROD_SUM_INFO A
			SET TMM_ORD_QTY = 0,
			    BORD_QTY = 0,
				MDFY_DTM = SYSDATE
			WHERE APL_YMD = CURR_YMD
			AND EXISTS (SELECT 'EXIST'
                        FROM TB_VEHL_MGMT
			            WHERE QLTY_VEHL_CD = A.QLTY_VEHL_CD
			            AND DL_EXPD_CO_CD = EXPD_CO_CD
		                AND ROWNUM <= 1
		               );

         --WRITE_BATCH_EXE_LOG('APS배치작업_KMC', SYSDATE, 'S', 'GET_APS_ODR_SUM_DTL : #3.');

	   		FOR ODR_SUM_LIST IN APS_ODR_SUM_INFO LOOP

				UPDATE TB_APS_PROD_SUM_INFO
				SET TMM_ORD_QTY = ODR_SUM_LIST.CURR_ORD_QTY,
				    BORD_QTY = ODR_SUM_LIST.PREV_ORD_QTY,
					MDFY_DTM = SYSDATE
				WHERE APL_YMD = CURR_YMD
				AND DATA_SN = ODR_SUM_LIST.DATA_SN;
				
				IF SQL%NOTFOUND THEN

					UPDATE TB_APS_PROD_SUM_INFO
					SET DATA_SN = ODR_SUM_LIST.DATA_SN,
						TMM_ORD_QTY = ODR_SUM_LIST.CURR_ORD_QTY,
					    BORD_QTY = ODR_SUM_LIST.PREV_ORD_QTY,
						MDFY_DTM = SYSDATE
					WHERE APL_YMD = CURR_YMD
						AND QLTY_VEHL_CD = ODR_SUM_LIST.QLTY_VEHL_CD
						AND MDL_MDY_CD = ODR_SUM_LIST.MDL_MDY_CD
						AND LANG_CD = ODR_SUM_LIST.LANG_CD
					;
	
					IF SQL%NOTFOUND THEN
	
					   INSERT INTO TB_APS_PROD_SUM_INFO
					   (APL_YMD,
					    DATA_SN,
						QLTY_VEHL_CD,
						MDL_MDY_CD,
						LANG_CD,
						TMM_ORD_QTY,
						BORD_QTY,
						FRAM_DTM,
						MDFY_DTM
					   )
					   VALUES
					   (CURR_YMD,
					    ODR_SUM_LIST.DATA_SN,
						ODR_SUM_LIST.QLTY_VEHL_CD,
						ODR_SUM_LIST.MDL_MDY_CD,
						ODR_SUM_LIST.LANG_CD,
						ODR_SUM_LIST.CURR_ORD_QTY,
						ODR_SUM_LIST.PREV_ORD_QTY,
						SYSDATE,
						SYSDATE
					   );
	
					END IF;
	
				END IF;

			END LOOP;

         --WRITE_BATCH_EXE_LOG('APS배치작업_KMC', SYSDATE, 'S', 'GET_APS_ODR_SUM_DTL : #4.');

			--[추가] 2010.04.14.김동근 오더정보 현황 - 공장별 Summary 내역 저장 기능 추가
			FOR PLNT_ODR_SUM_LIST IN PLNT_ODR_SUM_INFO LOOP

				UPDATE TB_PLNT_APS_PROD_SUM_INFO
				SET TMM_ORD_QTY = PLNT_ODR_SUM_LIST.CURR_ORD_QTY,
				    BORD_QTY = PLNT_ODR_SUM_LIST.PREV_ORD_QTY,
					MDFY_DTM = SYSDATE
				WHERE APL_YMD = CURR_YMD
				AND DATA_SN = PLNT_ODR_SUM_LIST.DATA_SN
				AND PRDN_PLNT_CD = PLNT_ODR_SUM_LIST.PRDN_PLNT_CD;

				IF SQL%NOTFOUND THEN

				   INSERT INTO TB_PLNT_APS_PROD_SUM_INFO
				   (APL_YMD,
				    DATA_SN,
					QLTY_VEHL_CD,
					MDL_MDY_CD,
					LANG_CD,
					TMM_ORD_QTY,
					BORD_QTY,
					FRAM_DTM,
					MDFY_DTM,
					PRDN_PLNT_CD
				   )
				   VALUES
				   (CURR_YMD,
				    PLNT_ODR_SUM_LIST.DATA_SN,
					PLNT_ODR_SUM_LIST.QLTY_VEHL_CD,
					PLNT_ODR_SUM_LIST.MDL_MDY_CD,
					PLNT_ODR_SUM_LIST.LANG_CD,
					PLNT_ODR_SUM_LIST.CURR_ORD_QTY,
					PLNT_ODR_SUM_LIST.PREV_ORD_QTY,
					SYSDATE,
					SYSDATE,
					PLNT_ODR_SUM_LIST.PRDN_PLNT_CD
				   );

				END IF;

			END LOOP;

         --WRITE_BATCH_EXE_LOG('APS배치작업_KMC', SYSDATE, 'S', 'GET_APS_ODR_SUM_DTL : #5.');

		--EXCEPTION WHEN OTHERS THEN
			--WRITE_BATCH_EXE_LOG('APS배치작업_KMC', SYSDATE, 'S', 'GET_APS_ODR_SUM_DTL : #[' || SQLERRM || ']');
	   END GET_APS_ODR_SUM_DTL;
/**********************************************************/



/**********************************************************/
       --구버전 현재 사용 안함
       --[주의] 실행을 위한 전제조건은 현재날짜에 해당하는 내역이 존재하지 않아야 한다.
	   PROCEDURE GET_APS_PROD_SUM(CURR_YMD   IN VARCHAR2,
	                              EXPD_CO_CD IN VARCHAR2)
	   IS

		 V_APL_FNH_YMD VARCHAR2(8);

		 V_MDL_MDY_CD  VARCHAR2(2);

		 V_CNT		   NUMBER;

		 --국가코드 조회를 위한 부분(등록되어 있지 않은 데이터만 읽어온다.)
		 /* 연계국가코드 미사용으로 제외
		 CURSOR APS_NATL_INFO IS SELECT A.DEST_NAT_CD
		                         FROM TB_APS_PROD_PLAN_INFO A,
								 	  TB_ALTN_VEHL_MGMT B
								 WHERE A.DL_EXPD_CO_CD = EXPD_CO_CD
                                 AND A.APL_STRT_YMD <= CURR_YMD
                                 AND A.APL_FNH_YMD >= CURR_YMD
								 AND A.DYTM_PLN_VEHL_CD = B.PRDN_VEHL_CD
								 AND B.PRVS_SCN_CD = 'A'
								 AND NOT EXISTS (SELECT 'EXIST'
												 FROM TB_ALTN_NATL_MGMT
												 WHERE DL_EXPD_CO_CD = EXPD_CO_CD
												 AND DYTM_PLN_NAT_CD = A.DEST_NAT_CD
												 AND PRVS_SCN_CD = 'A'
												)
								 GROUP BY A.DEST_NAT_CD;
		 */

		 --국가미지정 정보를 가져오는 부분
		 CURSOR APS_NOAPIM_PROD_INFO IS SELECT EXPD_NAT_CD,
											   QLTY_VEHL_CD,
											   PLN_PARR_YMD,
											   PRDN_PLN_QTY
									    FROM (SELECT B.DL_EXPD_NAT_CD,
										             A.DEST_NAT_CD AS EXPD_NAT_CD,
													 A.QLTY_VEHL_CD,
													 A.PLN_PARR_YMD,
													 A.PRDN_PLN_QTY
       									      FROM (--차종코드 테이블에 등록되어 있는 내역만을 조회하도록 한다.
												    SELECT B.QLTY_VEHL_CD,
												  	   	   A.PLN_PARR_YMD,
												 		   A.DEST_NAT_CD,
														   SUM(A.PRDN_PLN_QTY) AS PRDN_PLN_QTY
												    FROM TB_APS_PROD_PLAN_INFO A,
												         TB_ALTN_VEHL_MGMT B
												    WHERE A.DL_EXPD_CO_CD = EXPD_CO_CD
													AND A.APL_STRT_YMD <= CURR_YMD
													AND A.APL_FNH_YMD >= CURR_YMD
													AND A.DYTM_PLN_VEHL_CD = B.PRDN_VEHL_CD
													AND B.PRVS_SCN_CD = 'A'
													GROUP BY B.QLTY_VEHL_CD,
														  	 A.PLN_PARR_YMD,
       													     A.DEST_NAT_CD
       										       ) A,
       										       TB_ALTN_NATL_MGMT B
											  WHERE B.DL_EXPD_CO_CD(+) = EXPD_CO_CD
											  AND A.DEST_NAT_CD = B.DYTM_PLN_NAT_CD(+)
											  AND B.PRVS_SCN_CD(+) = 'A'
									         )
									    WHERE DL_EXPD_NAT_CD IS NULL;


		 							    /**  국가코드가 지정되지 않은 항목만 가져오는 것으로 변경
		 							    SELECT QLTY_VEHL_CD,
		                                       MDL_MDY_CD,
											   EXPD_NAT_CD,
											   PLN_PARR_YMD,
											   SUM(PRDN_PLN_QTY) AS PRDN_PLN_QTY
		                                FROM (SELECT B.LANG_CD,
       								    			 A.MDL_MDY_CD,
       								    			 A.QLTY_VEHL_CD,
       								    			 A.PLN_PARR_YMD,
													 A.EXPD_NAT_CD,
       								    			 A.PRDN_PLN_QTY
       							              FROM (SELECT NVL(B.MDL_MDY_CD, 'N/A') AS MDL_MDY_CD,
       									  	  	  		   A.EXPD_NAT_CD,
       										  			   A.QLTY_VEHL_CD,
       										  			   A.PLN_PARR_YMD,
       										  			   A.PRDN_PLN_QTY
       								                FROM (SELECT NVL(B.DL_EXPD_REGN_CD, 'N/A') AS EXPD_REGN_CD,
									                			 A.EXPD_NAT_CD,
												    			 A.QLTY_VEHL_CD,
												    			 A.PLN_PARR_YMD,
       											    			 A.MO_PACK_CD,
       											    			 A.PRDN_PLN_QTY
									                      FROM (SELECT NVL(B.DL_EXPD_NAT_CD, A.DEST_NAT_CD) AS EXPD_NAT_CD,
       											          	  		   A.QLTY_VEHL_CD,
														  			   A.PLN_PARR_YMD,
       											          			   A.MO_PACK_CD,
       											          			   A.PRDN_PLN_QTY
       									                        FROM (--차종코드 테이블에 등록되어 있는 내역만을 조회하도록 한다.
												   		              SELECT B.QLTY_VEHL_CD,
												  	   		    	 		 A.PLN_PARR_YMD,
												 		        			 A.MO_PACK_CD,
														        			 A.DEST_NAT_CD,
															    			 SUM(A.PRDN_PLN_QTY) AS PRDN_PLN_QTY
												                      FROM TB_APS_PROD_PLAN_INFO A,
												              		 	   TB_ALTN_VEHL_MGMT B
												         			  WHERE A.DL_EXPD_CO_CD = EXPD_CO_CD
                                                         			  AND A.APL_STRT_YMD <= CURR_YMD
                                                         			  AND A.APL_FNH_YMD >= CURR_YMD
												         			  AND A.DYTM_PLN_VEHL_CD = B.PRDN_VEHL_CD
												         			  AND B.PRVS_SCN_CD = 'A'
												         			  GROUP BY B.QLTY_VEHL_CD,
															      	 	   	   A.PLN_PARR_YMD,
       													          			   A.MO_PACK_CD,
       													          			   A.DEST_NAT_CD
       										                         ) A,
       										                         TB_ALTN_NATL_MGMT B
															    WHERE B.DL_EXPD_CO_CD(+) = EXPD_CO_CD
											                    AND A.DEST_NAT_CD = B.DYTM_PLN_NAT_CD(+)
															    AND B.PRVS_SCN_CD(+) = 'A'
									                           ) A,
												               TB_NATL_VEHL_MGMT B
										                  WHERE A.EXPD_NAT_CD = B.DL_EXPD_NAT_CD(+)
										     			  AND B.DL_EXPD_CO_CD(+) = EXPD_CO_CD
										     			  AND A.QLTY_VEHL_CD = B.QLTY_VEHL_CD(+)
									                     ) A,
										                 TB_VEHL_MDY_MGMT B
       								                WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD(+)
       								                AND A.EXPD_REGN_CD = B.DL_EXPD_REGN_CD(+)
       								   			    AND A.MO_PACK_CD >= B.DESMP1_CD(+)
       								   			    AND A.MO_PACK_CD <= B.DEFMP1_CD(+)
       							                   ) A,
       								               TB_NATL_LANG_MGMT B
								              WHERE A.EXPD_NAT_CD = B.DL_EXPD_NAT_CD(+)
								 			  AND B.DL_EXPD_CO_CD(+) = EXPD_CO_CD
								 			  AND A.QLTY_VEHL_CD = B.QLTY_VEHL_CD(+)
								 			  AND A.MDL_MDY_CD = B.MDL_MDY_CD(+)
											 )
									    WHERE LANG_CD IS NULL
										GROUP BY QLTY_VEHL_CD, MDL_MDY_CD, PLN_PARR_YMD, EXPD_NAT_CD;
										**/

		 --생산계획 데이터 조회를 위한 부분
	   	 CURSOR APS_PROD_INFO IS SELECT B.LANG_CD,
       								    A.MDL_MDY_CD,
       								    A.QLTY_VEHL_CD,
       								    A.PLN_PARR_YMD,
       								    SUM(A.PRDN_PLN_QTY) AS PRDN_PLN_QTY,
       									MIN(A.DCSN_YN) AS DCSN_YN,
										MAX(A.DCSN_YMD) AS DCSN_YMD
       							 FROM (SELECT B.MDL_MDY_CD,
       									  	  A.EXPD_NAT_CD,
       										  A.QLTY_VEHL_CD,
       										  A.PLN_PARR_YMD,
       										  A.PRDN_PLN_QTY,
       									      A.DCSN_YN,
										      A.DCSN_YMD
       								   FROM (SELECT B.DL_EXPD_REGN_CD AS EXPD_REGN_CD,
									                A.EXPD_NAT_CD,
												    A.QLTY_VEHL_CD,
												    A.PLN_PARR_YMD,
       											    A.MO_PACK_CD,
       											    A.PRDN_PLN_QTY,
       											    A.DCSN_YN,
												    A.DCSN_YMD
									         FROM (SELECT B.DL_EXPD_NAT_CD AS EXPD_NAT_CD,
       											          A.QLTY_VEHL_CD,
														  A.PLN_PARR_YMD,
       											          A.MO_PACK_CD,
       											          A.PRDN_PLN_QTY,
       											          A.DCSN_YN,
														  A.DCSN_YMD
       									           FROM (--차종코드 테이블에 등록되어 있는 내역만을 조회하도록 한다.
												   		 SELECT B.QLTY_VEHL_CD,
												  	   		    A.PLN_PARR_YMD,
												 		        A.MO_PACK_CD,
														        A.DEST_NAT_CD,
															    SUM(A.PRDN_PLN_QTY) AS PRDN_PLN_QTY,
													            MIN(A.DCSN_YN) AS DCSN_YN,
													            MAX(A.DCSN_YMD) AS DCSN_YMD
												         FROM TB_APS_PROD_PLAN_INFO A,
												              TB_ALTN_VEHL_MGMT B
												         WHERE A.DL_EXPD_CO_CD = EXPD_CO_CD
                                                         AND A.APL_STRT_YMD <= CURR_YMD
                                                         AND A.APL_FNH_YMD >= CURR_YMD
												         AND A.DYTM_PLN_VEHL_CD = B.PRDN_VEHL_CD
												         AND B.PRVS_SCN_CD = 'A'
												         GROUP BY B.QLTY_VEHL_CD,
															      A.PLN_PARR_YMD,
       													          A.MO_PACK_CD,
       													          A.DEST_NAT_CD
       										            ) A,
       										            TB_ALTN_NATL_MGMT B
												   WHERE B.DL_EXPD_CO_CD = EXPD_CO_CD
											       AND A.DEST_NAT_CD = B.DYTM_PLN_NAT_CD
											       AND B.PRVS_SCN_CD = 'A'
									              ) A,
												  TB_NATL_VEHL_MGMT B
										     WHERE A.EXPD_NAT_CD = B.DL_EXPD_NAT_CD
										     AND B.DL_EXPD_CO_CD = EXPD_CO_CD
										     AND A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
									        ) A,
										    TB_VEHL_MDY_MGMT B
       								   WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
       								   AND A.EXPD_REGN_CD = B.DL_EXPD_REGN_CD
       								   AND A.MO_PACK_CD >= B.DESMP1_CD
       								   AND A.MO_PACK_CD <= B.DEFMP1_CD
       							      ) A,
       								  TB_NATL_LANG_MGMT B
								 WHERE A.EXPD_NAT_CD = B.DL_EXPD_NAT_CD
								 AND B.DL_EXPD_CO_CD = EXPD_CO_CD
								 AND A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
								 AND A.MDL_MDY_CD = B.MDL_MDY_CD
								 GROUP BY B.LANG_CD, A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.PLN_PARR_YMD;

		 					  	 /** 이전버전
		 					     SELECT NVL(B.LANG_CD, 'N/A') AS LANG_CD,
       								    A.MDL_MDY_CD,
       								    A.QLTY_VEHL_CD,
       								    A.PLN_PARR_YMD,
       								    SUM(A.PRDN_PLN_QTY) AS PRDN_PLN_QTY,
       									MIN(A.DCSN_YN) AS DCSN_YN,
										MAX(A.DCSN_YMD) AS DCSN_YMD
       							 FROM (SELECT NVL(B.MDL_MDY_CD, 'N/A') AS MDL_MDY_CD,
       									  	  A.EXPD_NAT_CD,
       										  A.QLTY_VEHL_CD,
       										  A.PLN_PARR_YMD,
       										  A.PRDN_PLN_QTY,
       									      A.DCSN_YN,
										      A.DCSN_YMD
       								   FROM (SELECT NVL(B.DL_EXPD_REGN_CD, 'N/A') AS EXPD_REGN_CD,
									                A.EXPD_NAT_CD,
												    A.QLTY_VEHL_CD,
												    A.PLN_PARR_YMD,
       											    A.MO_PACK_CD,
       											    A.PRDN_PLN_QTY,
       											    A.DCSN_YN,
												    A.DCSN_YMD
									         FROM (SELECT NVL(B.DL_EXPD_NAT_CD, 'N/A') AS EXPD_NAT_CD,
       											          A.QLTY_VEHL_CD,
														  A.PLN_PARR_YMD,
       											          A.MO_PACK_CD,
       											          A.PRDN_PLN_QTY,
       											          A.DCSN_YN,
														  A.DCSN_YMD
       									           FROM (--차종코드 테이블에 등록되어 있는 내역만을 조회하도록 한다.
												   		 SELECT B.QLTY_VEHL_CD,
												  	   		    A.PLN_PARR_YMD,
												 		        A.MO_PACK_CD,
														        A.DEST_NAT_CD,
															    SUM(A.PRDN_PLN_QTY) AS PRDN_PLN_QTY,
													            MIN(A.DCSN_YN) AS DCSN_YN,
													            MAX(A.DCSN_YMD) AS DCSN_YMD
												         FROM TB_APS_PROD_PLAN_INFO A,
												              TB_ALTN_VEHL_MGMT B
												         WHERE A.DL_EXPD_CO_CD = EXPD_CO_CD
                                                         AND A.APL_STRT_YMD <= CURR_YMD
                                                         AND A.APL_FNH_YMD >= CURR_YMD
												         AND A.DYTM_PLN_VEHL_CD = B.PRDN_VEHL_CD
												         AND B.PRVS_SCN_CD = 'A'
												         GROUP BY B.QLTY_VEHL_CD,
															      A.PLN_PARR_YMD,
       													          A.MO_PACK_CD,
       													          A.DEST_NAT_CD
       										            ) A,
       										            TB_ALTN_NATL_MGMT B
											       WHERE A.DEST_NAT_CD = B.DYTM_PLN_NAT_CD(+)
											       AND B.DL_EXPD_CO_CD(+) = EXPD_CO_CD
												   AND B.PRVS_SCN_CD(+)= 'A'
									              ) A,
												  TB_NATL_VEHL_MGMT B
										     WHERE A.EXPD_NAT_CD = B.DL_EXPD_NAT_CD(+)
										     AND B.DL_EXPD_CO_CD(+) = EXPD_CO_CD
										     AND A.QLTY_VEHL_CD = B.QLTY_VEHL_CD(+)
									        ) A,
										    TB_VEHL_MDY_MGMT B
       								   WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD(+)
       								   AND A.EXPD_REGN_CD = B.DL_EXPD_REGN_CD(+)
       								   AND A.MO_PACK_CD >= B.DESMP1_CD(+)
       								   AND A.MO_PACK_CD <= B.DEFMP1_CD(+)
       							      ) A,
       								  TB_NATL_LANG_MGMT B
								 WHERE A.EXPD_NAT_CD = B.DL_EXPD_NAT_CD(+)
								 AND B.DL_EXPD_CO_CD(+) = EXPD_CO_CD
								 AND A.QLTY_VEHL_CD = B.QLTY_VEHL_CD(+)
								 AND A.MDL_MDY_CD = B.MDL_MDY_CD(+)
								 GROUP BY B.LANG_CD, A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.PLN_PARR_YMD;
								 **/

	   BEGIN

			/*
			FOR NATL_LIST IN APS_NATL_INFO LOOP

				UPDATE TB_NATL_NOAPIM_MGMT
				SET DYTM_PLN_NAT_CD = NATL_LIST.DEST_NAT_CD,
				    PRDN_MST_NAT_CD = NATL_LIST.DEST_NAT_CD,
				    UPDR_EENO = BTCH_USER_EENO,
				    MDFY_DTM = SYSDATE
				WHERE DL_EXPD_CO_CD = EXPD_CO_CD
				AND DL_EXPD_NAT_CD = NATL_LIST.DEST_NAT_CD;

				IF SQL%NOTFOUND THEN

				    --등록되지 않은 국가코드일 경우에는 국가코드 테이블에 값을 등록한다.
    				INSERT INTO TB_NATL_NOAPIM_MGMT
    				(DL_EXPD_CO_CD,
    				 DL_EXPD_NAT_CD,
    				 DYTM_PLN_NAT_CD,
    				 PRDN_MST_NAT_CD,
    				 PPRR_EENO,
    				 FRAM_DTM,
    				 UPDR_EENO,
    				 MDFY_DTM
    				)
    				VALUES
    				(EXPD_CO_CD,
    				 NATL_LIST.DEST_NAT_CD,
    				 NATL_LIST.DEST_NAT_CD,
    				 NATL_LIST.DEST_NAT_CD,
    				 BTCH_USER_EENO,
    				 SYSDATE,
    				 BTCH_USER_EENO,
    				 SYSDATE
    				);

				END IF;

			END LOOP;
			*/

			--현재일의 미지정내역을 삭제한 뒤 작업을 진행한다.
			--[주의] 회사구분이 존재하지 않으므로 아래와 같이 차종이 회사에 소속된
			--       내역만을 삭제해 주어야 한다.
			DELETE FROM TB_APS_PLAN_NOAPIM_INFO A
			WHERE APL_YMD = CURR_YMD
			AND EXISTS (SELECT 'EXIST'
                        FROM TB_VEHL_MGMT
			            WHERE QLTY_VEHL_CD = A.QLTY_VEHL_CD
			            AND DL_EXPD_CO_CD = EXPD_CO_CD
		                AND ROWNUM <= 1
		               );

			FOR NOAPIM_LIST IN APS_NOAPIM_PROD_INFO LOOP

				INSERT INTO TB_APS_PLAN_NOAPIM_INFO
			    (APL_YMD,
			     PLN_PARR_YMD,
				 QLTY_VEHL_CD,
				 MDL_MDY_CD,
				 DYTM_PLN_NAT_CD,
				 PRDN_PLN_QTY,
				 FRAM_DTM,
				 MDFY_DTM
			    )
				VALUES
				(CURR_YMD,
				 NOAPIM_LIST.PLN_PARR_YMD,
				 NOAPIM_LIST.QLTY_VEHL_CD,
				 --NOAPIM_LIST.MDL_MDY_CD,
				 'N/A', --연식은 무조건 N/A로 입력한다.
				 NOAPIM_LIST.EXPD_NAT_CD,
				 NOAPIM_LIST.PRDN_PLN_QTY,
				 SYSDATE,
				 SYSDATE
			    );

			END LOOP;


			FOR PROD_LIST IN APS_PROD_INFO LOOP

			   --변경여부를 검사할 데이터가 존재하는지의 여부를 확인
			   SELECT MAX(APL_FNH_YMD)
			   INTO V_APL_FNH_YMD
			   FROM TB_APS_PROD_PLAN_SUM_INFO A
			   WHERE A.APL_STRT_YMD <= CURR_YMD
			   AND A.APL_FNH_YMD <= CURR_YMD --현재일 이전의 데이터에서 조회하도록 한다...
			   AND A.PLN_PARR_YMD = PROD_LIST.PLN_PARR_YMD
		       AND A.QLTY_VEHL_CD = PROD_LIST.QLTY_VEHL_CD
		       AND A.MDL_MDY_CD = PROD_LIST.MDL_MDY_CD
		       AND A.LANG_CD = PROD_LIST.LANG_CD;

			   IF V_APL_FNH_YMD IS NULL THEN

				  --지금까지 한번도 추가되지 않은 경우(무조건 Insert 해 준다.)

				  INSERT INTO TB_APS_PROD_PLAN_SUM_INFO
   		    	  (APL_STRT_YMD,
				   APL_FNH_YMD,
				   PLN_PARR_YMD,
				   DATA_SN,
   				   QLTY_VEHL_CD,
   			 	   MDL_MDY_CD,
   			 	   LANG_CD,
   			 	   PRDN_PLN_QTY,
				   DCSN_YN,
				   DCSN_YMD,
   			 	   FRAM_DTM
   				  )
				  SELECT CURR_YMD,
				         CURR_YMD,
						 PROD_LIST.PLN_PARR_YMD,
				         A.DATA_SN,
						 PROD_LIST.QLTY_VEHL_CD,
						 PROD_LIST.MDL_MDY_CD,
						 PROD_LIST.LANG_CD,
						 PROD_LIST.PRDN_PLN_QTY,
						 PROD_LIST.DCSN_YN,
						 PROD_LIST.DCSN_YMD,
						 SYSDATE
				  FROM TB_LANG_MGMT A
				  WHERE A.QLTY_VEHL_CD = PROD_LIST.QLTY_VEHL_CD
				  AND A.MDL_MDY_CD = PROD_LIST.MDL_MDY_CD
				  AND A.LANG_CD = PROD_LIST.LANG_CD;

			   ELSE

				   --바로이전의 데이터가 변경되지 않은 경우에는 종료일 업데이트만 해준다.

			   	   UPDATE TB_APS_PROD_PLAN_SUM_INFO A
		 	   	   SET APL_FNH_YMD = CURR_YMD --적용완료일을 현재일로 해준다.
			   	   WHERE A.APL_STRT_YMD <= CURR_YMD
			   	   AND A.APL_FNH_YMD = V_APL_FNH_YMD
			   	   AND A.PLN_PARR_YMD = PROD_LIST.PLN_PARR_YMD
		       	   AND A.QLTY_VEHL_CD = PROD_LIST.QLTY_VEHL_CD
		       	   AND A.MDL_MDY_CD = PROD_LIST.MDL_MDY_CD
		       	   AND A.LANG_CD = PROD_LIST.LANG_CD
				   AND A.PRDN_PLN_QTY = PROD_LIST.PRDN_PLN_QTY
				   AND A.DCSN_YN = PROD_LIST.DCSN_YN
				   AND A.DCSN_YMD = PROD_LIST.DCSN_YMD;

				   IF SQL%NOTFOUND THEN

					  INSERT INTO TB_APS_PROD_PLAN_SUM_INFO
   		    	  	  (APL_STRT_YMD,
				   	   APL_FNH_YMD,
				   	   PLN_PARR_YMD,
				   	   DATA_SN,
   				   	   QLTY_VEHL_CD,
   			 	   	   MDL_MDY_CD,
   			 	   	   LANG_CD,
   			 	   	   PRDN_PLN_QTY,
				   	   DCSN_YN,
				   	   DCSN_YMD,
   			 	   	   FRAM_DTM
   				  	  )
				  	  SELECT CURR_YMD,
				             CURR_YMD,
						     PROD_LIST.PLN_PARR_YMD,
				             A.DATA_SN,
						     PROD_LIST.QLTY_VEHL_CD,
						     PROD_LIST.MDL_MDY_CD,
						     PROD_LIST.LANG_CD,
						     PROD_LIST.PRDN_PLN_QTY,
						     PROD_LIST.DCSN_YN,
						     PROD_LIST.DCSN_YMD,
						     SYSDATE
				     FROM TB_LANG_MGMT A
				     WHERE A.QLTY_VEHL_CD = PROD_LIST.QLTY_VEHL_CD
				     AND A.MDL_MDY_CD = PROD_LIST.MDL_MDY_CD
				     AND A.LANG_CD = PROD_LIST.LANG_CD;

				   END IF;

			   END IF;

				/**   이전버전
				SELECT SUM(A.PRDN_PLN_QTY),
				       NVL(MIN(A.DCSN_YN), ''),
					   NVL(MAX(A.DCSN_YMD), ''),
					   NVL(MAX(APL_FNH_YMD), '')
				INTO V_PRDN_PLN_QTY,
				     V_DCSN_YN,
					 V_DCSN_YMD,
					 V_FNH_YMD
				FROM TB_APS_PROD_PLAN_SUM_INFO A
			    WHERE A.APL_STRT_YMD <= CURR_YMD
				AND A.APL_FNH_YMD >= CURR_YMD
				AND A.PLN_PARR_YMD = PROD_LIST.PLN_PARR_YMD
			    AND A.QLTY_VEHL_CD = PROD_LIST.QLTY_VEHL_CD
			    AND A.MDL_MDY_CD = PROD_LIST.MDL_MDY_CD
			    AND A.LANG_CD = PROD_LIST.LANG_CD;

				IF(V_PRDN_PLN_QTY <> PROD_LIST.PRDN_PLN_QTY OR
				   V_DCSN_YN <> PROD_LIST.DCSN_YN OR
				   V_DCSN_YMD <> PROD_LIST.DCSN_YMD) THEN


				   UPDATE TB_APS_PROD_PLAN_SUM_INFO A
			 	   SET A.PRDN_PLN_QTY = DECODE(V_FNH_YMD, '99991231', A.PRDN_PLN_QTY, PROD_LIST.PRDN_PLN_QTY),
					   A.DCSN_YN      = DECODE(V_FNH_YMD, '99991231', A.DCSN_YN,      PROD_LIST.DCSN_YN),
					   A.DCSN_YMD     = DECODE(V_FNH_YMD, '99991231', A.DCSN_YMD,     PROD_LIST.DCSN_YMD),
					   A.APL_FNH_YMD  = DECODE(V_FNH_YMD, '99991231', CURR_YMD,       V_FNH_YMD)
				   WHERE A.APL_STRT_YMD <= CURR_YMD
				   AND A.APL_FNH_YMD = V_FNH_YMD
				   AND A.PLN_PARR_YMD = PROD_LIST.PLN_PARR_YMD
			       AND A.QLTY_VEHL_CD = PROD_LIST.QLTY_VEHL_CD
			       AND A.MDL_MDY_CD = PROD_LIST.MDL_MDY_CD
			       AND A.LANG_CD = PROD_LIST.LANG_CD;

				   --업데이트 된 데이터가 없거나 가장 최근의 데이터였다면 신규추가 작업을 해준다.
				   IF SQL%NOTFOUND OR V_FNH_YMD = '99991231' THEN

					  INSERT INTO TB_APS_PROD_PLAN_SUM_INFO
    		    	  (APL_STRT_YMD,
					   APL_FNH_YMD,
					   PLN_PARR_YMD,
					   DATA_SN,
    			 	   QLTY_VEHL_CD,
    			 	   MDL_MDY_CD,
    			 	   LANG_CD,
    			 	   PRDN_PLN_QTY,
    			 	   DCSN_YN,
					   DCSN_YMD,
    			 	   FRAM_DTM
    				  )
					  SELECT CURR_YMD,
							 '99991231',
							 PROD_LIST.PLN_PARR_YMD,
							 A.DATA_SN,
							 PROD_LIST.QLTY_VEHL_CD,
							 PROD_LIST.MDL_MDY_CD,
							 PROD_LIST.LANG_CD,
							 PROD_LIST.PRDN_PLN_QTY,
							 PROD_LIST.DCSN_YN,
							 PROD_LIST.DCSN_YMD,
							 SYSDATE
					  FROM TB_LANG_MGMT A
					  WHERE A.QLTY_VEHL_CD = PROD_LIST.QLTY_VEHL_CD
					  AND A.MDL_MDY_CD = PROD_LIST.MDL_MDY_CD
					  AND A.LANG_CD = PROD_LIST.LANG_CD;

				   END IF;

				END IF;
				**/

			END LOOP;

			--생산계획정보 취합 작업 수행
			GET_APS_PROD_SUM_DTL(CURR_YMD,
			                     CURR_YMD,
								 EXPD_CO_CD);

	   END GET_APS_PROD_SUM;
/**********************************************************/
/**********************************************************/
       --신버전 현재 사용
	   PROCEDURE GET_APS_PROD_SUM2(CURR_YMD   IN VARCHAR2,
	                               EXPD_CO_CD IN VARCHAR2)
	   IS

	   	 V_APL_FNH_YMD VARCHAR2(8);

		 V_MDL_MDY_CD  VARCHAR2(2);

		 V_CNT		   NUMBER;

		 --국가코드 조회를 위한 부분(등록되어 있지 않은 데이터만 읽어온다.)
		 /* 연계국가코드 미사용으로 제외
		 CURSOR APS_NATL_INFO IS SELECT DEST_NAT_CD
		                         FROM TB_APS_PROD_PLAN_INFO
								 WHERE DL_EXPD_CO_CD = EXPD_CO_CD
                                 AND APL_STRT_YMD <= CURR_YMD
                                 AND APL_FNH_YMD >= CURR_YMD
								 AND QLTY_VEHL_CD IS NOT NULL --현재 사용중인 차종에 대해서만 가져오도록 한다.
								 AND DL_EXPD_NAT_CD IS NULL   --취급설명서국가코드가 등록되지 않은 항목만 가져온다.
								 GROUP BY DEST_NAT_CD;
		 */

		 /**** [2009-04-08] 국가미지정 생산 계획정보는 현시점부터 가져오지 않도록 한다.

		 --국가미지정 정보를 가져오는 부분
		 CURSOR APS_NOAPIM_PROD_INFO IS SELECT QLTY_VEHL_CD,
											   PLN_PARR_YMD,
											   DEST_NAT_CD AS EXPD_NAT_CD,
											   SUM(PRDN_PLN_QTY) AS PRDN_PLN_QTY
										FROM TB_APS_PROD_PLAN_INFO
										WHERE DL_EXPD_CO_CD = EXPD_CO_CD
										AND APL_STRT_YMD <= CURR_YMD
										AND APL_FNH_YMD >= CURR_YMD
										AND QLTY_VEHL_CD IS NOT NULL --현재 사용중인 차종에 대해서만 가져오도록 한다.
		 							    AND DL_EXPD_NAT_CD IS NULL   --취급설명서국가코드가 등록되지 않은 항목만 가져온다.
										GROUP BY QLTY_VEHL_CD,
												 PLN_PARR_YMD,
       											 DEST_NAT_CD;
		 ****/

		 --생산계획 데이터 조회를 위한 부분
		 --(PDI 공통차종 오더내역 조회 부분 포함)
	   	 CURSOR APS_PROD_INFO IS WITH T AS (SELECT A.QLTY_VEHL_CD,
		 					  	           		   A.MDL_MDY_CD,
		 					  	 				   B.LANG_CD,
       								    		   A.PLN_PARR_YMD,
       								    		   SUM(A.PRDN_PLN_QTY) AS PRDN_PLN_QTY,
       											   MIN(A.DCSN_YN) AS DCSN_YN,
												   MAX(A.DCSN_YMD) AS DCSN_YMD
		 					  	 			FROM (SELECT QLTY_VEHL_CD,
								 	  		  	 		 MDL_MDY_CD,
											  			 DL_EXPD_NAT_CD AS EXPD_NAT_CD,
											  			 PLN_PARR_YMD,
											  			 SUM(PRDN_PLN_QTY) AS PRDN_PLN_QTY,
											  			 MIN(DCSN_YN) AS DCSN_YN,
											  			 MAX(DCSN_YMD) AS DCSN_YMD
									   			  FROM TB_APS_PROD_PLAN_INFO
									   			  WHERE DL_EXPD_CO_CD = EXPD_CO_CD
                                       			  AND APL_STRT_YMD <= CURR_YMD
                                       			  AND APL_FNH_YMD >= CURR_YMD
									   			  AND QLTY_VEHL_CD IS NOT NULL   --현재 사용중인 차종에 대해서만 가져오도록 한다.
									   			  AND MDL_MDY_CD IS NOT NULL     --연식이 지정된 항목만 가져온다.
									   			  AND DL_EXPD_NAT_CD IS NOT NULL --취급설명서국가코드가 등록된 항목만 가져온다.
									   			  GROUP BY QLTY_VEHL_CD,
									  		      		   MDL_MDY_CD,
														   PLN_PARR_YMD,
       													   DL_EXPD_NAT_CD
								      			 ) A,
									  			 TB_NATL_LANG_MGMT B
								            WHERE A.EXPD_NAT_CD = B.DL_EXPD_NAT_CD
								 			AND B.DL_EXPD_CO_CD = EXPD_CO_CD
								 			AND A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
								 			AND A.MDL_MDY_CD = B.MDL_MDY_CD
								 			GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, B.LANG_CD, A.PLN_PARR_YMD
		 					  	 	  	   )
								 SELECT QLTY_VEHL_CD,
								 		MDL_MDY_CD,
										LANG_CD,
										PLN_PARR_YMD,
										PRDN_PLN_QTY,
										DCSN_YN,
										DCSN_YMD
								 FROM T

								 UNION ALL

								 SELECT B.DIVS_QLTY_VEHL_CD AS QLTY_VEHL_CD,
								        B.MDL_MDY_CD,
									    B.LANG_CD,
									    A.PLN_PARR_YMD,
									   SUM(A.PRDN_PLN_QTY) AS PRDN_PLN_QTY,
									   MIN(A.DCSN_YN) AS DCSN_YN,
									   MAX(A.DCSN_YMD) AS DCSN_YMD
								 FROM T A,
								      TB_PDI_COM_VEHL_MGMT B
							     WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
								 AND A.MDL_MDY_CD = B.MDL_MDY_CD
								 AND A.LANG_CD = B.LANG_CD
								 GROUP BY B.DIVS_QLTY_VEHL_CD, B.MDL_MDY_CD, B.LANG_CD, A.PLN_PARR_YMD;

		 /***

		 --생산계획 데이터 조회를 위한 부분
	   	 CURSOR APS_PROD_INFO IS SELECT A.QLTY_VEHL_CD,
		 					  	        A.MDL_MDY_CD,
		 					  	 		B.LANG_CD,
       								    A.PLN_PARR_YMD,
       								    SUM(A.PRDN_PLN_QTY) AS PRDN_PLN_QTY,
       									MIN(A.DCSN_YN) AS DCSN_YN,
										MAX(A.DCSN_YMD) AS DCSN_YMD
		 					  	 FROM (SELECT QLTY_VEHL_CD,
								 	  		  MDL_MDY_CD,
											  DL_EXPD_NAT_CD AS EXPD_NAT_CD,
											  PLN_PARR_YMD,
											  SUM(PRDN_PLN_QTY) AS PRDN_PLN_QTY,
											  MIN(DCSN_YN) AS DCSN_YN,
											  MAX(DCSN_YMD) AS DCSN_YMD
									   FROM TB_APS_PROD_PLAN_INFO
									   WHERE DL_EXPD_CO_CD = EXPD_CO_CD
                                       AND APL_STRT_YMD <= CURR_YMD
                                       AND APL_FNH_YMD >= CURR_YMD
									   AND QLTY_VEHL_CD IS NOT NULL   --현재 사용중인 차종에 대해서만 가져오도록 한다.
									   AND MDL_MDY_CD IS NOT NULL     --연식이 지정된 항목만 가져온다.
									   AND DL_EXPD_NAT_CD IS NOT NULL --취급설명서국가코드가 등록된 항목만 가져온다.
									   GROUP BY QLTY_VEHL_CD,
									  		    MDL_MDY_CD,
												PLN_PARR_YMD,
       											DL_EXPD_NAT_CD
								      ) A,
									  TB_NATL_LANG_MGMT B
								 WHERE A.EXPD_NAT_CD = B.DL_EXPD_NAT_CD
								 AND B.DL_EXPD_CO_CD = EXPD_CO_CD
								 AND A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
								 AND A.MDL_MDY_CD = B.MDL_MDY_CD
								 GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, B.LANG_CD, A.PLN_PARR_YMD;
		 ***/

		 --[추가] 2010.04.15.김동근 생산계획정보 현황 - 공장별 내역 조회
		 CURSOR PLNT_PROD_INFO IS WITH T AS (SELECT A.QLTY_VEHL_CD,
		 					  	           		    A.MDL_MDY_CD,
		 					  	 				    B.LANG_CD,
       								    		    A.PLN_PARR_YMD,
       								    		    SUM(A.PRDN_PLN_QTY) AS PRDN_PLN_QTY,
       											    MIN(A.DCSN_YN) AS DCSN_YN,
												    MAX(A.DCSN_YMD) AS DCSN_YMD,
													A.PRDN_PLNT_CD
		 					  	 			 FROM (SELECT A.QLTY_VEHL_CD,
								 	  		  	 		  A.MDL_MDY_CD,
											  			  A.DL_EXPD_NAT_CD AS EXPD_NAT_CD,
											  			  A.PLN_PARR_YMD,
											  			  SUM(A.PRDN_PLN_QTY) AS PRDN_PLN_QTY,
											  			  MIN(A.DCSN_YN) AS DCSN_YN,
											  			  MAX(A.DCSN_YMD) AS DCSN_YMD,
														  B.PRDN_PLNT_CD
									   			   FROM TB_APS_PROD_PLAN_INFO A,
												   		TB_PLNT_VEHL_MGMT B
									   			   WHERE A.DL_EXPD_CO_CD = EXPD_CO_CD
                                       			   AND A.APL_STRT_YMD <= CURR_YMD
                                       			   AND A.APL_FNH_YMD >= CURR_YMD
												   AND A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
												   --TB_APS_PROD_PLAN_INFO테이블의 공장코드에는 빈문자가 포함되어 있을 수 있다.
												   --그래서 TRIM 함수를 사용함
												   AND TRIM(A.PRDN_PLNT_CD) = B.PRDN_PLNT_CD
									   			   AND A.QLTY_VEHL_CD IS NOT NULL   --현재 사용중인 차종에 대해서만 가져오도록 한다.
									   			   AND A.MDL_MDY_CD IS NOT NULL     --연식이 지정된 항목만 가져온다.
									   			   AND A.DL_EXPD_NAT_CD IS NOT NULL --취급설명서국가코드가 등록된 항목만 가져온다.
									   			   GROUP BY A.QLTY_VEHL_CD,
									  		      		    A.MDL_MDY_CD,
														    A.PLN_PARR_YMD,
       													    A.DL_EXPD_NAT_CD,
															B.PRDN_PLNT_CD
								      			  ) A,
									  			  TB_NATL_LANG_MGMT B
								             WHERE A.EXPD_NAT_CD = B.DL_EXPD_NAT_CD
								 			 AND B.DL_EXPD_CO_CD = EXPD_CO_CD
								 			 AND A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
								 			 AND A.MDL_MDY_CD = B.MDL_MDY_CD
								 			 GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, B.LANG_CD, A.PLN_PARR_YMD, A.PRDN_PLNT_CD
		 					  	 	  	    )
								  SELECT QLTY_VEHL_CD,
								 		 MDL_MDY_CD,
										 LANG_CD,
										 PLN_PARR_YMD,
										 PRDN_PLN_QTY,
										 DCSN_YN,
										 DCSN_YMD,
										 PRDN_PLNT_CD
								  FROM T

								  UNION ALL

								  SELECT B.DIVS_QLTY_VEHL_CD AS QLTY_VEHL_CD,
								         B.MDL_MDY_CD,
									     B.LANG_CD,
									     A.PLN_PARR_YMD,
									     SUM(A.PRDN_PLN_QTY) AS PRDN_PLN_QTY,
									     MIN(A.DCSN_YN) AS DCSN_YN,
									     MAX(A.DCSN_YMD) AS DCSN_YMD,
										 A.PRDN_PLNT_CD
								  FROM T A,
								       TB_PDI_COM_VEHL_MGMT B
							      WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
								  AND A.MDL_MDY_CD = B.MDL_MDY_CD
								  AND A.LANG_CD = B.LANG_CD
								  GROUP BY B.DIVS_QLTY_VEHL_CD, B.MDL_MDY_CD, B.LANG_CD, A.PLN_PARR_YMD, A.PRDN_PLNT_CD;

	   BEGIN

			/* 연계국가코드 미사용으로 제외
			FOR NATL_LIST IN APS_NATL_INFO LOOP

				SELECT COUNT(*)
				INTO V_CNT
				FROM TB_ALTN_NATL_MGMT
				WHERE DL_EXPD_CO_CD = EXPD_CO_CD
				AND DYTM_PLN_NAT_CD = NATL_LIST.DEST_NAT_CD
				AND PRVS_SCN_CD = 'A';

				IF V_CNT = 0 THEN

				   UPDATE TB_NATL_NOAPIM_MGMT
				   SET DYTM_PLN_NAT_CD = NATL_LIST.DEST_NAT_CD,
				       PRDN_MST_NAT_CD = NATL_LIST.DEST_NAT_CD,
					   NAT_NM = FU_GET_NOAPIM_NAT_NM(EXPD_CO_CD, NATL_LIST.DEST_NAT_CD),
				       UPDR_EENO = BTCH_USER_EENO,
				       MDFY_DTM = SYSDATE
				   WHERE DL_EXPD_CO_CD = EXPD_CO_CD
				   AND DL_EXPD_NAT_CD = NATL_LIST.DEST_NAT_CD;

				   IF SQL%NOTFOUND THEN

				      --등록되지 않은 국가코드일 경우에는 국가코드 테이블에 값을 등록한다.
    				  INSERT INTO TB_NATL_NOAPIM_MGMT
    				  (DL_EXPD_CO_CD,
    				   DL_EXPD_NAT_CD,
    				   DYTM_PLN_NAT_CD,
    				   PRDN_MST_NAT_CD,
					   NAT_NM,
    				   PPRR_EENO,
    				   FRAM_DTM,
    				   UPDR_EENO,
    				   MDFY_DTM
    				  )
    				  VALUES
    				  (EXPD_CO_CD,
    				   NATL_LIST.DEST_NAT_CD,
    				   NATL_LIST.DEST_NAT_CD,
    				   NATL_LIST.DEST_NAT_CD,
					   FU_GET_NOAPIM_NAT_NM(EXPD_CO_CD, NATL_LIST.DEST_NAT_CD),
    				   BTCH_USER_EENO,
    				   SYSDATE,
    				   BTCH_USER_EENO,
    				   SYSDATE
    				  );

				   END IF;

				END IF;

			END LOOP;
			*/

			/**** [2009-04-08] 국가미지정 생산 계획정보는 현시점부터 가져오지 않도록 한다.

			--현재일의 미지정내역을 삭제한 뒤 작업을 진행한다.
			--[주의] 회사구분이 존재하지 않으므로 아래와 같이 차종이 회사에 소속된
			--       내역만을 삭제해 주어야 한다.
			DELETE FROM TB_APS_PLAN_NOAPIM_INFO A
			WHERE APL_YMD = CURR_YMD
			AND EXISTS (SELECT 'EXIST'
                        FROM TB_VEHL_MGMT
			            WHERE QLTY_VEHL_CD = A.QLTY_VEHL_CD
			            AND DL_EXPD_CO_CD = EXPD_CO_CD
		                AND ROWNUM <= 1
		               );

			FOR NOAPIM_LIST IN APS_NOAPIM_PROD_INFO LOOP

				INSERT INTO TB_APS_PLAN_NOAPIM_INFO
			    (APL_YMD,
			     PLN_PARR_YMD,
				 QLTY_VEHL_CD,
				 MDL_MDY_CD,
				 DYTM_PLN_NAT_CD,
				 PRDN_PLN_QTY,
				 FRAM_DTM,
				 MDFY_DTM
			    )
				VALUES
				(CURR_YMD,
				 NOAPIM_LIST.PLN_PARR_YMD,
				 NOAPIM_LIST.QLTY_VEHL_CD,
				 --NOAPIM_LIST.MDL_MDY_CD,
				 'N/A', --연식은 무조건 N/A로 입력한다.
				 NOAPIM_LIST.EXPD_NAT_CD,
				 NOAPIM_LIST.PRDN_PLN_QTY,
				 SYSDATE,
				 SYSDATE
			    );

			END LOOP;

			****/

			--과거일에 입력되었으나 데이터가 변경되지 않아서 현재일 이후로 종료일이 설정 되어 있는 경우에는
			--종료일을 하루전으로 설정해 준다.
			UPDATE TB_APS_PROD_PLAN_SUM_INFO A
			SET A.APL_FNH_YMD = TO_CHAR(TO_DATE(CURR_YMD, 'YYYYMMDD') - 1, 'YYYYMMDD')
			WHERE A.APL_STRT_YMD < CURR_YMD
			AND A.APL_FNH_YMD >= CURR_YMD
			AND EXISTS (SELECT 'EXIST'
                        FROM TB_VEHL_MGMT
			            WHERE QLTY_VEHL_CD = A.QLTY_VEHL_CD
			            AND DL_EXPD_CO_CD = EXPD_CO_CD
		                AND ROWNUM <= 1
		               );

			--현재일에 순수하게 입력된 항목은 삭제하도록 한다.
			DELETE FROM TB_APS_PROD_PLAN_SUM_INFO A
			WHERE A.APL_STRT_YMD = CURR_YMD
			AND A.APL_FNH_YMD >= CURR_YMD
			AND EXISTS (SELECT 'EXIST'
                        FROM TB_VEHL_MGMT
			            WHERE QLTY_VEHL_CD = A.QLTY_VEHL_CD
			            AND DL_EXPD_CO_CD = EXPD_CO_CD
		                AND ROWNUM <= 1
		               );

			--[추가] 2010.04.15.김동근 생산계획정보 현황 - 공장별 내역 삭제 기능 추가

			UPDATE TB_PLNT_APS_PROD_PLAN_SUM_INFO A
			SET A.APL_FNH_YMD = TO_CHAR(TO_DATE(CURR_YMD, 'YYYYMMDD') - 1, 'YYYYMMDD')
			WHERE A.APL_STRT_YMD < CURR_YMD
			AND A.APL_FNH_YMD >= CURR_YMD
			AND EXISTS (SELECT 'EXIST'
                        FROM TB_VEHL_MGMT
			            WHERE QLTY_VEHL_CD = A.QLTY_VEHL_CD
			            AND DL_EXPD_CO_CD = EXPD_CO_CD
		                AND ROWNUM <= 1
		               );

			DELETE FROM TB_PLNT_APS_PROD_PLAN_SUM_INFO A
			WHERE A.APL_STRT_YMD = CURR_YMD
			AND A.APL_FNH_YMD >= CURR_YMD
			AND EXISTS (SELECT 'EXIST'
                        FROM TB_VEHL_MGMT
			            WHERE QLTY_VEHL_CD = A.QLTY_VEHL_CD
			            AND DL_EXPD_CO_CD = EXPD_CO_CD
		                AND ROWNUM <= 1
		               );

			FOR PROD_LIST IN APS_PROD_INFO LOOP

			   --변경여부를 검사할 데이터가 존재하는지의 여부를 확인
			   SELECT MAX(APL_FNH_YMD)
			   INTO V_APL_FNH_YMD
			   FROM TB_APS_PROD_PLAN_SUM_INFO A
			   WHERE A.APL_STRT_YMD <= CURR_YMD
			   AND A.APL_FNH_YMD <= CURR_YMD --현재일 이전의 데이터에서 조회하도록 한다...
			   AND A.PLN_PARR_YMD = PROD_LIST.PLN_PARR_YMD
		       AND A.QLTY_VEHL_CD = PROD_LIST.QLTY_VEHL_CD
		       AND A.MDL_MDY_CD = PROD_LIST.MDL_MDY_CD
		       AND A.LANG_CD = PROD_LIST.LANG_CD;

			   IF V_APL_FNH_YMD IS NULL THEN

				  --지금까지 한번도 추가되지 않은 경우(무조건 Insert 해 준다.)

				  INSERT INTO TB_APS_PROD_PLAN_SUM_INFO
   		    	  (APL_STRT_YMD,
				   APL_FNH_YMD,
				   PLN_PARR_YMD,
				   DATA_SN,
   				   QLTY_VEHL_CD,
   			 	   MDL_MDY_CD,
   			 	   LANG_CD,
   			 	   PRDN_PLN_QTY,
				   DCSN_YN,
				   DCSN_YMD,
   			 	   FRAM_DTM
   				  )
				  SELECT CURR_YMD,
				         CURR_YMD,
						 PROD_LIST.PLN_PARR_YMD,
				         A.DATA_SN,
						 PROD_LIST.QLTY_VEHL_CD,
						 PROD_LIST.MDL_MDY_CD,
						 PROD_LIST.LANG_CD,
						 PROD_LIST.PRDN_PLN_QTY,
						 PROD_LIST.DCSN_YN,
						 PROD_LIST.DCSN_YMD,
						 SYSDATE
				  FROM TB_LANG_MGMT A
				  WHERE A.QLTY_VEHL_CD = PROD_LIST.QLTY_VEHL_CD
				  AND A.MDL_MDY_CD = PROD_LIST.MDL_MDY_CD
				  AND A.LANG_CD = PROD_LIST.LANG_CD;

			   ELSE

				   --바로이전의 데이터가 변경되지 않은 경우에는 종료일 업데이트만 해준다.

			   	   UPDATE TB_APS_PROD_PLAN_SUM_INFO A
		 	   	   SET APL_FNH_YMD = CURR_YMD --적용완료일을 현재일로 해준다.
			   	   WHERE A.APL_STRT_YMD <= CURR_YMD
			   	   AND A.APL_FNH_YMD = V_APL_FNH_YMD
			   	   AND A.PLN_PARR_YMD = PROD_LIST.PLN_PARR_YMD
		       	   AND A.QLTY_VEHL_CD = PROD_LIST.QLTY_VEHL_CD
		       	   AND A.MDL_MDY_CD = PROD_LIST.MDL_MDY_CD
		       	   AND A.LANG_CD = PROD_LIST.LANG_CD
				   AND A.PRDN_PLN_QTY = PROD_LIST.PRDN_PLN_QTY
				   AND A.DCSN_YN = PROD_LIST.DCSN_YN
				   AND A.DCSN_YMD = PROD_LIST.DCSN_YMD;

				   IF SQL%NOTFOUND THEN

					  INSERT INTO TB_APS_PROD_PLAN_SUM_INFO
   		    	  	  (APL_STRT_YMD,
				   	   APL_FNH_YMD,
				   	   PLN_PARR_YMD,
				   	   DATA_SN,
   				   	   QLTY_VEHL_CD,
   			 	   	   MDL_MDY_CD,
   			 	   	   LANG_CD,
   			 	   	   PRDN_PLN_QTY,
				   	   DCSN_YN,
				   	   DCSN_YMD,
   			 	   	   FRAM_DTM
   				  	  )
				  	  SELECT CURR_YMD,
				             CURR_YMD,
						     PROD_LIST.PLN_PARR_YMD,
				             A.DATA_SN,
						     PROD_LIST.QLTY_VEHL_CD,
						     PROD_LIST.MDL_MDY_CD,
						     PROD_LIST.LANG_CD,
						     PROD_LIST.PRDN_PLN_QTY,
						     PROD_LIST.DCSN_YN,
						     PROD_LIST.DCSN_YMD,
						     SYSDATE
				     FROM TB_LANG_MGMT A
				     WHERE A.QLTY_VEHL_CD = PROD_LIST.QLTY_VEHL_CD
				     AND A.MDL_MDY_CD = PROD_LIST.MDL_MDY_CD
				     AND A.LANG_CD = PROD_LIST.LANG_CD;

				   END IF;

			   END IF;

			END LOOP;

			--[추가] 2010.04.15.김동근 생산계획정보 현황 - 공장별 내역 저장
			FOR PLNT_PROD_LIST IN PLNT_PROD_INFO LOOP

			   --변경여부를 검사할 데이터가 존재하는지의 여부를 확인
			   SELECT MAX(APL_FNH_YMD)
			   INTO V_APL_FNH_YMD
			   FROM TB_PLNT_APS_PROD_PLAN_SUM_INFO A
			   WHERE A.APL_STRT_YMD <= CURR_YMD
			   AND A.APL_FNH_YMD <= CURR_YMD --현재일 이전의 데이터에서 조회하도록 한다...
			   AND A.PLN_PARR_YMD = PLNT_PROD_LIST.PLN_PARR_YMD
		       AND A.QLTY_VEHL_CD = PLNT_PROD_LIST.QLTY_VEHL_CD
		       AND A.MDL_MDY_CD = PLNT_PROD_LIST.MDL_MDY_CD
		       AND A.LANG_CD = PLNT_PROD_LIST.LANG_CD
			   AND A.PRDN_PLNT_CD = PLNT_PROD_LIST.PRDN_PLNT_CD;

			   IF V_APL_FNH_YMD IS NULL THEN

				  --지금까지 한번도 추가되지 않은 경우(무조건 Insert 해 준다.)

				  INSERT INTO TB_PLNT_APS_PROD_PLAN_SUM_INFO
   		    	  (APL_STRT_YMD,
				   APL_FNH_YMD,
				   PLN_PARR_YMD,
				   DATA_SN,
   				   QLTY_VEHL_CD,
   			 	   MDL_MDY_CD,
   			 	   LANG_CD,
   			 	   PRDN_PLN_QTY,
				   DCSN_YN,
				   DCSN_YMD,
   			 	   FRAM_DTM,
				   PRDN_PLNT_CD
   				  )
				  SELECT CURR_YMD,
				         CURR_YMD,
						 PLNT_PROD_LIST.PLN_PARR_YMD,
				         A.DATA_SN,
						 PLNT_PROD_LIST.QLTY_VEHL_CD,
						 PLNT_PROD_LIST.MDL_MDY_CD,
						 PLNT_PROD_LIST.LANG_CD,
						 PLNT_PROD_LIST.PRDN_PLN_QTY,
						 PLNT_PROD_LIST.DCSN_YN,
						 PLNT_PROD_LIST.DCSN_YMD,
						 SYSDATE,
						 PLNT_PROD_LIST.PRDN_PLNT_CD
				  FROM TB_LANG_MGMT A
				  WHERE A.QLTY_VEHL_CD = PLNT_PROD_LIST.QLTY_VEHL_CD
				  AND A.MDL_MDY_CD = PLNT_PROD_LIST.MDL_MDY_CD
				  AND A.LANG_CD = PLNT_PROD_LIST.LANG_CD;

			   ELSE

				   --바로이전의 데이터가 변경되지 않은 경우에는 종료일 업데이트만 해준다.

			   	   UPDATE TB_PLNT_APS_PROD_PLAN_SUM_INFO A
		 	   	   SET APL_FNH_YMD = CURR_YMD --적용완료일을 현재일로 해준다.
			   	   WHERE A.APL_STRT_YMD <= CURR_YMD
			   	   AND A.APL_FNH_YMD = V_APL_FNH_YMD
			   	   AND A.PLN_PARR_YMD = PLNT_PROD_LIST.PLN_PARR_YMD
		       	   AND A.QLTY_VEHL_CD = PLNT_PROD_LIST.QLTY_VEHL_CD
		       	   AND A.MDL_MDY_CD = PLNT_PROD_LIST.MDL_MDY_CD
		       	   AND A.LANG_CD = PLNT_PROD_LIST.LANG_CD
				   AND A.PRDN_PLN_QTY = PLNT_PROD_LIST.PRDN_PLN_QTY
				   AND A.DCSN_YN = PLNT_PROD_LIST.DCSN_YN
				   AND A.DCSN_YMD = PLNT_PROD_LIST.DCSN_YMD
				   AND A.PRDN_PLNT_CD = PLNT_PROD_LIST.PRDN_PLNT_CD;

				   IF SQL%NOTFOUND THEN

					  INSERT INTO TB_PLNT_APS_PROD_PLAN_SUM_INFO
   		    	  	  (APL_STRT_YMD,
				   	   APL_FNH_YMD,
				   	   PLN_PARR_YMD,
				   	   DATA_SN,
   				   	   QLTY_VEHL_CD,
   			 	   	   MDL_MDY_CD,
   			 	   	   LANG_CD,
   			 	   	   PRDN_PLN_QTY,
				   	   DCSN_YN,
				   	   DCSN_YMD,
   			 	   	   FRAM_DTM,
					   PRDN_PLNT_CD
   				  	  )
				  	  SELECT CURR_YMD,
				             CURR_YMD,
						     PLNT_PROD_LIST.PLN_PARR_YMD,
				             A.DATA_SN,
						     PLNT_PROD_LIST.QLTY_VEHL_CD,
						     PLNT_PROD_LIST.MDL_MDY_CD,
						     PLNT_PROD_LIST.LANG_CD,
						     PLNT_PROD_LIST.PRDN_PLN_QTY,
						     PLNT_PROD_LIST.DCSN_YN,
						     PLNT_PROD_LIST.DCSN_YMD,
						     SYSDATE,
							 PLNT_PROD_LIST.PRDN_PLNT_CD
				     FROM TB_LANG_MGMT A
				     WHERE A.QLTY_VEHL_CD = PLNT_PROD_LIST.QLTY_VEHL_CD
				     AND A.MDL_MDY_CD = PLNT_PROD_LIST.MDL_MDY_CD
				     AND A.LANG_CD = PLNT_PROD_LIST.LANG_CD;

				   END IF;

			   END IF;

			END LOOP;

			--생산계획정보 취합 작업 수행
			GET_APS_PROD_SUM_DTL(CURR_YMD,
			                     CURR_YMD,
								 EXPD_CO_CD);

			--재고상세 내역 재계산 작업 수행(생산계획정보 정보 취합 후 작업이 수행되어야 한다.)
			--(반드시 세원재고 재계산 작업이 이루어진 후에 PDI 재고 데이터 재계산이 이루어 져야 한다.)
			PG_DATA.SP_RECALCULATE_SEWHA_IV_DTL2(CURR_YMD, BTCH_USER_EENO);
			PG_DATA.SP_RECALCULATE_PDI_IV_DTL2(CURR_YMD, BTCH_USER_EENO);

	   END GET_APS_PROD_SUM2;
/**********************************************************/
/**********************************************************/
	   --화면에 표시되는 데이터의 형태로 생산계획 정보를 취합하는 작업을 수행
	   PROCEDURE GET_APS_PROD_SUM_DTL(CURR_YMD   IN VARCHAR2,
	   			 					  SRCH_YMD   IN VARCHAR2,
	                                  EXPD_CO_CD IN VARCHAR2)
	   IS

		 V_CURR_DATE	DATE := TO_DATE(CURR_YMD, 'YYYYMMDD');

		 V_CURR_FSTD_YMD VARCHAR2(8) := TO_CHAR(V_CURR_DATE, 'YYYYMM') || '01';
		 V_NEXT_2WEK_YMD VARCHAR2(8) := TO_CHAR(V_CURR_DATE + 14, 'YYYYMMDD');
         V_CURR_LAST_YMD VARCHAR2(8) := TO_CHAR(LAST_DAY(V_CURR_DATE), 'YYYYMMDD');

		 --[변경] 영업일 기준(토, 일 제외)으로 3일 뒤 날짜를 얻어오도록 변경함...
		 --V_NEXT_2DAY_YMD VARCHAR2(8) := TO_CHAR(V_CURR_DATE + 2, 'YYYYMMDD');
		 V_NEXT_2DAY_YMD VARCHAR2(8) := PG_COMMON.FU_GET_WRKDATE(CURR_YMD, 2);

		 V_NEXT_4DAY_YMD VARCHAR2(8) := PG_COMMON.FU_GET_WRKDATE(CURR_YMD, 4);

		 V_NEXT_1DAY_YMD VARCHAR2(8) := PG_COMMON.FU_GET_WRKDATE(CURR_YMD, 1);

		 CURSOR APS_PROD_SUM_INFO IS SELECT MAX(DATA_SN) AS DATA_SN,
									   		QLTY_VEHL_CD,
											MDL_MDY_CD,
											LANG_CD,
									   		SUM(TDD_PRDN_PLN_QTY) AS TDD_PRDN_PLN_QTY,
											SUM(WEK2_PRDN_PLN_QTY) AS WEK2_PRDN_PLN_QTY,
											SUM(TMM_PRDN_PLN_QTY) AS TMM_PRDN_PLN_QTY,
											SUM(TDD_PRDN_PLN_QTY2) AS TDD_PRDN_PLN_QTY2,
											SUM(TDD_PRDN_PLN_QTY3) AS TDD_PRDN_PLN_QTY3
				   					 FROM (
									 	   --금일 생산계획 데이터 조회(영업일기준 3일)
									 	   SELECT MAX(A.DATA_SN) AS DATA_SN,
									   			  A.QLTY_VEHL_CD,
												  A.MDL_MDY_CD,
												  A.LANG_CD,
									   			  SUM(A.PRDN_PLN_QTY) AS TDD_PRDN_PLN_QTY,
												  0 AS WEK2_PRDN_PLN_QTY,
												  0 AS TMM_PRDN_PLN_QTY,
												  0 AS TDD_PRDN_PLN_QTY2,
												  0 AS TDD_PRDN_PLN_QTY3
									   	   FROM TB_APS_PROD_PLAN_SUM_INFO A,
									   		    TB_VEHL_MGMT B
										   WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
										   AND A.MDL_MDY_CD = B.MDL_MDY_CD
										   AND B.DL_EXPD_CO_CD = EXPD_CO_CD
										   AND A.APL_STRT_YMD <= SRCH_YMD
                                 		   AND A.APL_FNH_YMD >= SRCH_YMD
										   --현재일부터 2일 뒤까지의 생산계획 데이터를 금일생산계획데이터로 본다.
										   AND A.PLN_PARR_YMD BETWEEN CURR_YMD AND V_NEXT_2DAY_YMD
										   GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD

										   UNION ALL

										   --2주 생산계획 데이터 조회
										   SELECT MAX(A.DATA_SN) AS DATA_SN,
									   			  A.QLTY_VEHL_CD,
												  A.MDL_MDY_CD,
												  A.LANG_CD,
									   			  0 AS TDD_PRDN_PLN_QTY,
												  SUM(A.PRDN_PLN_QTY) AS WEK2_PRDN_PLN_QTY,
												  0 AS TMM_PRDN_PLN_QTY,
												  0 AS TDD_PRDN_PLN_QTY2,
												  0 AS TDD_PRDN_PLN_QTY3
									   	   FROM TB_APS_PROD_PLAN_SUM_INFO A,
									   		    TB_VEHL_MGMT B
										   WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
										   AND A.MDL_MDY_CD = B.MDL_MDY_CD
										   AND B.DL_EXPD_CO_CD = EXPD_CO_CD
										   AND A.APL_STRT_YMD <= SRCH_YMD
                                 		   AND A.APL_FNH_YMD >= SRCH_YMD
										   AND A.PLN_PARR_YMD BETWEEN CURR_YMD AND V_NEXT_2WEK_YMD
										   GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD

										   UNION ALL

										   --금일부터 당월말까지의 예산 계획 데이터 조회
										   SELECT MAX(A.DATA_SN) AS DATA_SN,
									   			  A.QLTY_VEHL_CD,
												  A.MDL_MDY_CD,
												  A.LANG_CD,
									   			  0 AS TDD_PRDN_PLN_QTY,
												  0 AS WEK2_PRDN_PLN_QTY,
												  SUM(A.PRDN_PLN_QTY) AS TMM_PRDN_PLN_QTY,
												  0 AS TDD_PRDN_PLN_QTY2,
												  0 AS TDD_PRDN_PLN_QTY3
									   	   FROM TB_APS_PROD_PLAN_SUM_INFO A,
									   		    TB_VEHL_MGMT B
										   WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
										   AND A.MDL_MDY_CD = B.MDL_MDY_CD
										   AND B.DL_EXPD_CO_CD = EXPD_CO_CD
										   AND A.APL_STRT_YMD <= SRCH_YMD
                                 		   AND A.APL_FNH_YMD >= SRCH_YMD
										   AND A.PLN_PARR_YMD BETWEEN CURR_YMD AND V_CURR_LAST_YMD
										   GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD

										   UNION ALL

										   --금일 생산계획 데이터 조회(영업일기준 5일)
										   SELECT MAX(A.DATA_SN) AS DATA_SN,
									   			  A.QLTY_VEHL_CD,
												  A.MDL_MDY_CD,
												  A.LANG_CD,
									   			  0 AS TDD_PRDN_PLN_QTY2,
												  0 AS WEK2_PRDN_PLN_QTY,
												  0 AS TMM_PRDN_PLN_QTY,
												  SUM(A.PRDN_PLN_QTY) AS TDD_PRDN_PLN_QTY2,
												  0 AS TDD_PRDN_PLN_QTY3
									   	   FROM TB_APS_PROD_PLAN_SUM_INFO A,
									   		    TB_VEHL_MGMT B
										   WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
										   AND A.MDL_MDY_CD = B.MDL_MDY_CD
										   AND B.DL_EXPD_CO_CD = EXPD_CO_CD
										   AND A.APL_STRT_YMD <= SRCH_YMD
                                 		   AND A.APL_FNH_YMD >= SRCH_YMD
										   --현재일부터 4일 뒤까지의 생산계획 데이터를 금일생산계획데이터로 본다.
										   AND A.PLN_PARR_YMD BETWEEN CURR_YMD AND V_NEXT_4DAY_YMD
										   GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD

										   UNION ALL

										   --금일 생산계획 데이터 조회(영업일기준 2일)
										   SELECT MAX(A.DATA_SN) AS DATA_SN,
									   			  A.QLTY_VEHL_CD,
												  A.MDL_MDY_CD,
												  A.LANG_CD,
									   			  0 AS TDD_PRDN_PLN_QTY2,
												  0 AS WEK2_PRDN_PLN_QTY,
												  0 AS TMM_PRDN_PLN_QTY,
												  0 AS TDD_PRDN_PLN_QTY2,
												  SUM(A.PRDN_PLN_QTY) AS TDD_PRDN_PLN_QTY3
									   	   FROM TB_APS_PROD_PLAN_SUM_INFO A,
									   		    TB_VEHL_MGMT B
										   WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
										   AND A.MDL_MDY_CD = B.MDL_MDY_CD
										   AND B.DL_EXPD_CO_CD = EXPD_CO_CD
										   AND A.APL_STRT_YMD <= SRCH_YMD
                                 		   AND A.APL_FNH_YMD >= SRCH_YMD
										   --현재일부터 4일 뒤까지의 생산계획 데이터를 금일생산계획데이터로 본다.
										   AND A.PLN_PARR_YMD BETWEEN CURR_YMD AND V_NEXT_1DAY_YMD
										   GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD

										  ) A
									 WHERE A.TDD_PRDN_PLN_QTY + A.WEK2_PRDN_PLN_QTY + A.TMM_PRDN_PLN_QTY +
									       A.TDD_PRDN_PLN_QTY2 + A.TDD_PRDN_PLN_QTY3 > 0
									 GROUP BY QLTY_VEHL_CD, MDL_MDY_CD, LANG_CD;

		 --[추가] 2010.04.15.김동근 생산계획정보 현황 - 공장별 Summary 내역 조회
		 CURSOR PLNT_PROD_SUM_INFO IS SELECT MAX(DATA_SN) AS DATA_SN,
									   		 QLTY_VEHL_CD,
											 MDL_MDY_CD,
											 LANG_CD,
									   		 SUM(TDD_PRDN_PLN_QTY) AS TDD_PRDN_PLN_QTY,
											 SUM(WEK2_PRDN_PLN_QTY) AS WEK2_PRDN_PLN_QTY,
											 SUM(TMM_PRDN_PLN_QTY) AS TMM_PRDN_PLN_QTY,
											 SUM(TDD_PRDN_PLN_QTY2) AS TDD_PRDN_PLN_QTY2,
											 SUM(TDD_PRDN_PLN_QTY3) AS TDD_PRDN_PLN_QTY3,
											 PRDN_PLNT_CD
				   					  FROM (
									 	    --금일 생산계획 데이터 조회(영업일기준 3일)
									 	    SELECT MAX(A.DATA_SN) AS DATA_SN,
									   			   A.QLTY_VEHL_CD,
												   A.MDL_MDY_CD,
												   A.LANG_CD,
									   			   SUM(A.PRDN_PLN_QTY) AS TDD_PRDN_PLN_QTY,
												   0 AS WEK2_PRDN_PLN_QTY,
												   0 AS TMM_PRDN_PLN_QTY,
												   0 AS TDD_PRDN_PLN_QTY2,
												   0 AS TDD_PRDN_PLN_QTY3,
												   A.PRDN_PLNT_CD
									   	    FROM TB_PLNT_APS_PROD_PLAN_SUM_INFO A,
									   		     TB_VEHL_MGMT B
										    WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
										    AND A.MDL_MDY_CD = B.MDL_MDY_CD
										    AND B.DL_EXPD_CO_CD = EXPD_CO_CD
										    AND A.APL_STRT_YMD <= SRCH_YMD
                                 		    AND A.APL_FNH_YMD >= SRCH_YMD
										    --현재일부터 2일 뒤까지의 생산계획 데이터를 금일생산계획데이터로 본다.
										    AND A.PLN_PARR_YMD BETWEEN CURR_YMD AND V_NEXT_2DAY_YMD
										    GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD, A.PRDN_PLNT_CD

										    UNION ALL

										    --2주 생산계획 데이터 조회
										    SELECT MAX(A.DATA_SN) AS DATA_SN,
									   			   A.QLTY_VEHL_CD,
												   A.MDL_MDY_CD,
												   A.LANG_CD,
									   			   0 AS TDD_PRDN_PLN_QTY,
												   SUM(A.PRDN_PLN_QTY) AS WEK2_PRDN_PLN_QTY,
												   0 AS TMM_PRDN_PLN_QTY,
												   0 AS TDD_PRDN_PLN_QTY2,
												   0 AS TDD_PRDN_PLN_QTY3,
												   A.PRDN_PLNT_CD
									   	    FROM TB_PLNT_APS_PROD_PLAN_SUM_INFO A,
									   		     TB_VEHL_MGMT B
										    WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
										    AND A.MDL_MDY_CD = B.MDL_MDY_CD
										    AND B.DL_EXPD_CO_CD = EXPD_CO_CD
										    AND A.APL_STRT_YMD <= SRCH_YMD
                                 		    AND A.APL_FNH_YMD >= SRCH_YMD
										    AND A.PLN_PARR_YMD BETWEEN CURR_YMD AND V_NEXT_2WEK_YMD
										    GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD, A.PRDN_PLNT_CD

										    UNION ALL

										    --금일부터 당월말까지의 예산 계획 데이터 조회
										    SELECT MAX(A.DATA_SN) AS DATA_SN,
									   			   A.QLTY_VEHL_CD,
												   A.MDL_MDY_CD,
												   A.LANG_CD,
									   			   0 AS TDD_PRDN_PLN_QTY,
												   0 AS WEK2_PRDN_PLN_QTY,
												   SUM(A.PRDN_PLN_QTY) AS TMM_PRDN_PLN_QTY,
												   0 AS TDD_PRDN_PLN_QTY2,
												   0 AS TDD_PRDN_PLN_QTY3,
												   A.PRDN_PLNT_CD
									   	    FROM TB_PLNT_APS_PROD_PLAN_SUM_INFO A,
									   		     TB_VEHL_MGMT B
										    WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
										    AND A.MDL_MDY_CD = B.MDL_MDY_CD
										    AND B.DL_EXPD_CO_CD = EXPD_CO_CD
										    AND A.APL_STRT_YMD <= SRCH_YMD
                                 		    AND A.APL_FNH_YMD >= SRCH_YMD
										    AND A.PLN_PARR_YMD BETWEEN CURR_YMD AND V_CURR_LAST_YMD
										    GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD, A.PRDN_PLNT_CD

										    UNION ALL

										    --금일 생산계획 데이터 조회(영업일기준 5일)
										    SELECT MAX(A.DATA_SN) AS DATA_SN,
									   			   A.QLTY_VEHL_CD,
												   A.MDL_MDY_CD,
												   A.LANG_CD,
									   			   0 AS TDD_PRDN_PLN_QTY2,
												   0 AS WEK2_PRDN_PLN_QTY,
												   0 AS TMM_PRDN_PLN_QTY,
												   SUM(A.PRDN_PLN_QTY) AS TDD_PRDN_PLN_QTY2,
												   0 AS TDD_PRDN_PLN_QTY3,
												   A.PRDN_PLNT_CD
									   	    FROM TB_PLNT_APS_PROD_PLAN_SUM_INFO A,
									   		     TB_VEHL_MGMT B
										    WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
										    AND A.MDL_MDY_CD = B.MDL_MDY_CD
										    AND B.DL_EXPD_CO_CD = EXPD_CO_CD
										    AND A.APL_STRT_YMD <= SRCH_YMD
                                 		    AND A.APL_FNH_YMD >= SRCH_YMD
										    --현재일부터 4일 뒤까지의 생산계획 데이터를 금일생산계획데이터로 본다.
										    AND A.PLN_PARR_YMD BETWEEN CURR_YMD AND V_NEXT_4DAY_YMD
										    GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD, A.PRDN_PLNT_CD

										    UNION ALL

										    --금일 생산계획 데이터 조회(영업일기준 2일)
										    SELECT MAX(A.DATA_SN) AS DATA_SN,
									   			   A.QLTY_VEHL_CD,
												   A.MDL_MDY_CD,
												   A.LANG_CD,
									   			   0 AS TDD_PRDN_PLN_QTY2,
												   0 AS WEK2_PRDN_PLN_QTY,
												   0 AS TMM_PRDN_PLN_QTY,
												   0 AS TDD_PRDN_PLN_QTY2,
												   SUM(A.PRDN_PLN_QTY) AS TDD_PRDN_PLN_QTY3,
												   A.PRDN_PLNT_CD
									   	    FROM TB_PLNT_APS_PROD_PLAN_SUM_INFO A,
									   		     TB_VEHL_MGMT B
										    WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
										    AND A.MDL_MDY_CD = B.MDL_MDY_CD
										    AND B.DL_EXPD_CO_CD = EXPD_CO_CD
										    AND A.APL_STRT_YMD <= SRCH_YMD
                                 		    AND A.APL_FNH_YMD >= SRCH_YMD
										    --현재일부터 4일 뒤까지의 생산계획 데이터를 금일생산계획데이터로 본다.
										    AND A.PLN_PARR_YMD BETWEEN CURR_YMD AND V_NEXT_1DAY_YMD
										    GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD, A.PRDN_PLNT_CD

										   ) A
									  WHERE A.TDD_PRDN_PLN_QTY + A.WEK2_PRDN_PLN_QTY + A.TMM_PRDN_PLN_QTY +
									        A.TDD_PRDN_PLN_QTY2 + A.TDD_PRDN_PLN_QTY3 > 0
									  GROUP BY QLTY_VEHL_CD, MDL_MDY_CD, LANG_CD, PRDN_PLNT_CD;

	   BEGIN

			--이미 입력되었던 항목이 있다면 초기화 해준 후 진행한다.
			--[주의] 회사구분이 존재하지 않으므로 아래와 같이 차종이 회사에 소속된
			--       내역만을 삭제해 주어야 한다.
			UPDATE TB_APS_PROD_SUM_INFO A
			SET TDD_PRDN_PLN_QTY = 0,
				WEK2_PRDN_PLN_QTY = 0,
				TMM_PRDN_PLN_QTY = 0,
				TDD_PRDN_PLN_QTY2 = 0,
				TDD_PRDN_PLN_QTY3 = 0,
				MDFY_DTM = SYSDATE
			WHERE APL_YMD = CURR_YMD
			AND EXISTS (SELECT 'EXIST'
                        FROM TB_VEHL_MGMT
			            WHERE QLTY_VEHL_CD = A.QLTY_VEHL_CD
			            AND DL_EXPD_CO_CD = EXPD_CO_CD
		                AND ROWNUM <= 1
		               );

			--[추가] 2010.04.15.김동근 생산계획정보 현황 - 공장별 Summary 내역 초기화
			UPDATE TB_PLNT_APS_PROD_SUM_INFO A
			SET TDD_PRDN_PLN_QTY = 0,
				WEK2_PRDN_PLN_QTY = 0,
				TMM_PRDN_PLN_QTY = 0,
				TDD_PRDN_PLN_QTY2 = 0,
				TDD_PRDN_PLN_QTY3 = 0,
				MDFY_DTM = SYSDATE
			WHERE APL_YMD = CURR_YMD
			AND EXISTS (SELECT 'EXIST'
                        FROM TB_VEHL_MGMT
			            WHERE QLTY_VEHL_CD = A.QLTY_VEHL_CD
			            AND DL_EXPD_CO_CD = EXPD_CO_CD
		                AND ROWNUM <= 1
		               );

			FOR PROD_SUM_LIST IN APS_PROD_SUM_INFO LOOP

				UPDATE TB_APS_PROD_SUM_INFO
				SET TDD_PRDN_PLN_QTY  = PROD_SUM_LIST.TDD_PRDN_PLN_QTY,
				    WEK2_PRDN_PLN_QTY = PROD_SUM_LIST.WEK2_PRDN_PLN_QTY,
					TMM_PRDN_PLN_QTY  = PROD_SUM_LIST.TMM_PRDN_PLN_QTY,
					TDD_PRDN_PLN_QTY2 = PROD_SUM_LIST.TDD_PRDN_PLN_QTY2,
					TDD_PRDN_PLN_QTY3 = PROD_SUM_LIST.TDD_PRDN_PLN_QTY3,
					MDFY_DTM = SYSDATE
				WHERE APL_YMD = CURR_YMD
				AND DATA_SN = PROD_SUM_LIST.DATA_SN;
				
				IF SQL%NOTFOUND THEN
				
					UPDATE TB_APS_PROD_SUM_INFO
					SET DATA_SN = PROD_SUM_LIST.DATA_SN,
						TDD_PRDN_PLN_QTY  = PROD_SUM_LIST.TDD_PRDN_PLN_QTY,
					    WEK2_PRDN_PLN_QTY = PROD_SUM_LIST.WEK2_PRDN_PLN_QTY,
						TMM_PRDN_PLN_QTY  = PROD_SUM_LIST.TMM_PRDN_PLN_QTY,
						TDD_PRDN_PLN_QTY2 = PROD_SUM_LIST.TDD_PRDN_PLN_QTY2,
						TDD_PRDN_PLN_QTY3 = PROD_SUM_LIST.TDD_PRDN_PLN_QTY3,
						MDFY_DTM = SYSDATE
					WHERE APL_YMD = CURR_YMD
						AND QLTY_VEHL_CD = PROD_SUM_LIST.QLTY_VEHL_CD
						AND MDL_MDY_CD = PROD_SUM_LIST.MDL_MDY_CD
						AND LANG_CD = PROD_SUM_LIST.LANG_CD
					;
	
					IF SQL%NOTFOUND THEN
	
					   INSERT INTO TB_APS_PROD_SUM_INFO
					   (APL_YMD,
					    DATA_SN,
						QLTY_VEHL_CD,
						MDL_MDY_CD,
						LANG_CD,
						TDD_PRDN_PLN_QTY,
						WEK2_PRDN_PLN_QTY,
						TMM_PRDN_PLN_QTY,
						FRAM_DTM,
						MDFY_DTM,
						TDD_PRDN_PLN_QTY2,
						TDD_PRDN_PLN_QTY3
					   )
					   VALUES
					   (CURR_YMD,
					    PROD_SUM_LIST.DATA_SN,
						PROD_SUM_LIST.QLTY_VEHL_CD,
						PROD_SUM_LIST.MDL_MDY_CD,
						PROD_SUM_LIST.LANG_CD,
						PROD_SUM_LIST.TDD_PRDN_PLN_QTY,
						PROD_SUM_LIST.WEK2_PRDN_PLN_QTY,
						PROD_SUM_LIST.TMM_PRDN_PLN_QTY,
						SYSDATE,
						SYSDATE,
						PROD_SUM_LIST.TDD_PRDN_PLN_QTY2,
						PROD_SUM_LIST.TDD_PRDN_PLN_QTY3
					   );
	
					END IF;

				END IF;

			END LOOP;

			--[추가] 2010.04.15.김동근 생산계획정보 현황 - 공장별 Summary 내역 저장 기능 추가
			FOR PLNT_PROD_SUM_LIST IN PLNT_PROD_SUM_INFO LOOP

				UPDATE TB_PLNT_APS_PROD_SUM_INFO
				SET TDD_PRDN_PLN_QTY  = PLNT_PROD_SUM_LIST.TDD_PRDN_PLN_QTY,
				    WEK2_PRDN_PLN_QTY = PLNT_PROD_SUM_LIST.WEK2_PRDN_PLN_QTY,
					TMM_PRDN_PLN_QTY  = PLNT_PROD_SUM_LIST.TMM_PRDN_PLN_QTY,
					TDD_PRDN_PLN_QTY2 = PLNT_PROD_SUM_LIST.TDD_PRDN_PLN_QTY2,
					TDD_PRDN_PLN_QTY3 = PLNT_PROD_SUM_LIST.TDD_PRDN_PLN_QTY3,
					MDFY_DTM = SYSDATE
				WHERE APL_YMD = CURR_YMD
				AND DATA_SN = PLNT_PROD_SUM_LIST.DATA_SN
				AND PRDN_PLNT_CD = PLNT_PROD_SUM_LIST.PRDN_PLNT_CD;

				IF SQL%NOTFOUND THEN

				   INSERT INTO TB_PLNT_APS_PROD_SUM_INFO
				   (APL_YMD,
				    DATA_SN,
					QLTY_VEHL_CD,
					MDL_MDY_CD,
					LANG_CD,
					TDD_PRDN_PLN_QTY,
					WEK2_PRDN_PLN_QTY,
					TMM_PRDN_PLN_QTY,
					FRAM_DTM,
					MDFY_DTM,
					TDD_PRDN_PLN_QTY2,
					TDD_PRDN_PLN_QTY3,
					PRDN_PLNT_CD
				   )
				   VALUES
				   (CURR_YMD,
				    PLNT_PROD_SUM_LIST.DATA_SN,
					PLNT_PROD_SUM_LIST.QLTY_VEHL_CD,
					PLNT_PROD_SUM_LIST.MDL_MDY_CD,
					PLNT_PROD_SUM_LIST.LANG_CD,
					PLNT_PROD_SUM_LIST.TDD_PRDN_PLN_QTY,
					PLNT_PROD_SUM_LIST.WEK2_PRDN_PLN_QTY,
					PLNT_PROD_SUM_LIST.TMM_PRDN_PLN_QTY,
					SYSDATE,
					SYSDATE,
					PLNT_PROD_SUM_LIST.TDD_PRDN_PLN_QTY2,
					PLNT_PROD_SUM_LIST.TDD_PRDN_PLN_QTY3,
					PLNT_PROD_SUM_LIST.PRDN_PLNT_CD
				   );

				END IF;

			END LOOP;

	   END GET_APS_PROD_SUM_DTL;
/**********************************************************/



/**********************************************************/
	   --오더 인터페이스 성공시에 완료일자를 저장
	   PROCEDURE SAVE_ODR_BTCH_FNH_INFO(CURR_YMD   IN VARCHAR2,
	                                    EXPD_CO_CD IN VARCHAR2)
	   IS
	   BEGIN

			INSERT INTO TB_BATCH_FNH_INFO
			(AFFR_SCN_CD,
			 DL_EXPD_CO_CD,
			 BTCH_FNH_YMD,
			 FRAM_DTM
			)
			VALUES
			('01',
			 EXPD_CO_CD,
			 CURR_YMD,
			 SYSDATE
			);

	   END SAVE_ODR_BTCH_FNH_INFO;
/**********************************************************/
/**********************************************************/
	   --계획 인터페이스 성공시에 완료일자를 저장
	   PROCEDURE SAVE_PROD_BTCH_FNH_INFO(CURR_YMD   IN VARCHAR2,
	                                     EXPD_CO_CD IN VARCHAR2)
	   IS
	   BEGIN

			INSERT INTO TB_BATCH_FNH_INFO
			(AFFR_SCN_CD,
			 DL_EXPD_CO_CD,
			 BTCH_FNH_YMD,
			 FRAM_DTM
			)
			VALUES
			('02',
			 EXPD_CO_CD,
			 CURR_YMD,
			 SYSDATE
			);

	   END SAVE_PROD_BTCH_FNH_INFO;
/**********************************************************/
/**********************************************************/
	   PROCEDURE WRITE_BATCH_LOG(BTCH_NM          IN VARCHAR2,
	   			 				 STRT_DATE		  IN DATE,
	   			 				 BTCH_WK_CD       IN VARCHAR2,
								 BTCH_WK_RSLT_SBC IN VARCHAR2)
	   IS

		 PRAGMA AUTONOMOUS_TRANSACTION;

	   BEGIN

			IF BTCH_WK_CD = 'F' THEN

			   SEND_ERROR_MAIL(BTCH_NM, BTCH_WK_RSLT_SBC);

			END IF;

			INSERT INTO TB_BATCH_RSLT_INFO
			(BTCH_NM,
			 BTCH_FIN_STRT_DTM,
			 BTCH_FNH_DTM,
			 BTCH_WK_CD,
			 BTCH_WK_RSLT_SBC
			)
			VALUES
			(BTCH_NM,
			 STRT_DATE,
			 SYSDATE,
			 BTCH_WK_CD,
			 BTCH_WK_RSLT_SBC
			);

			COMMIT;

			EXCEPTION
		     WHEN OTHERS THEN
			     ROLLBACK;

	   END WRITE_BATCH_LOG;
/**********************************************************/
/**********************************************************/
	   PROCEDURE WRITE_BATCH_ERRLOG(BTCH_NM          IN VARCHAR2,
								    BTCH_WK_RSLT_SBC IN VARCHAR2)
	   IS
	   BEGIN

			SEND_ERROR_MAIL(BTCH_NM, BTCH_WK_RSLT_SBC);

			INSERT INTO TB_BATCH_RSLT_INFO
			(BTCH_NM,
			 BTCH_FIN_STRT_DTM,
			 BTCH_FNH_DTM,
			 BTCH_WK_CD,
			 BTCH_WK_RSLT_SBC
			)
			VALUES
			(BTCH_NM,
			 SYSDATE,
			 SYSDATE,
			 'F',
			 BTCH_WK_RSLT_SBC
			);

			COMMIT;

			EXCEPTION
		     WHEN OTHERS THEN
			     ROLLBACK;

	   END WRITE_BATCH_ERRLOG;
/**********************************************************/
/**********************************************************/
	   PROCEDURE WRITE_BATCH_EXE_LOG(BTCH_NM          IN VARCHAR2,
	   			 				 STRT_DATE		  IN DATE,
	   			 				 BTCH_WK_CD       IN VARCHAR2,
								 BTCH_WK_RSLT_SBC IN VARCHAR2)
	   IS

		 PRAGMA AUTONOMOUS_TRANSACTION;

	   BEGIN

			INSERT INTO TB_BATCH_EXE_LOG
			(LOG_SN,
			 BTCH_NM,
			 BTCH_FNH_STRT_DTM,
			 BTCH_FNH_DTM,
			 BTCH_WK_CD,
			 BTCH_WK_RSLT_SBC
			)
			VALUES
			(BATCH_LOG_SQ.NEXTVAL,
			 BTCH_NM,
			 STRT_DATE,
			 SYSDATE,
			 BTCH_WK_CD,
			 BTCH_WK_RSLT_SBC
			);

			COMMIT;

			EXCEPTION
		     WHEN OTHERS THEN
			     ROLLBACK;

	   END WRITE_BATCH_EXE_LOG;
/**********************************************************/
/**********************************************************/
	   --에러발생시 배치관리자에게 메세지를 전송하는 역할 수행
	   PROCEDURE SEND_ERROR_MAIL(BTCH_NM          IN VARCHAR2,
	                             BTCH_WK_RSLT_SBC IN VARCHAR2)
	   IS

		 V_USER_NM      TB_USR_MGMT.USER_NM%TYPE;
		 V_USER_EML_ADR TB_USR_MGMT.USER_EML_ADR%TYPE;

		 V_MAIL_TITLE   VARCHAR2(8000);
		 V_MAIL_CONTENT VARCHAR2(8000);

	   BEGIN

		FOR USR IN (SELECT DL_EXPD_PRVS_NM AS USER_EENO FROM TB_CODE_MGMT WHERE DL_EXPD_G_CD = '0036')
		LOOP

			SELECT NVL(USER_NM, ' '),
			       NVL(USER_EML_ADR, ' ')
			INTO V_USER_NM,
			     V_USER_EML_ADR
			FROM TB_USR_MGMT
--			WHERE USER_EENO = PG_COMMON.FU_RPAD(BTCH_USER_EENO, 7)
			WHERE USER_EENO = PG_COMMON.FU_RPAD(USR.USER_EENO, 7)
			;

			--메일 발송
			V_MAIL_TITLE   := '오너스매뉴얼 ' || BTCH_NM || ' 배치 작업 에러가 발생되었습니다.';
			V_MAIL_CONTENT := '<HTML><BODY>' ||
						      '배치 에러 정보는 다음과 같습니다.<br>' ||
							  '배치명칭: ' || BTCH_NM || '<br>' ||
							  '에러내용: ' || BTCH_WK_RSLT_SBC || '<br>' ||
							  '시간    : ' || TO_CHAR(SYSDATE, 'YYYY-MM-DD HH24:MI:SS') || '<br>' ||
							  '</BODY></HTML>';

			--배치에러 메일 발송
			IF V_USER_EML_ADR <> ' ' THEN

			   SP_CHNL_INSERTSIMPLEEMAIL(V_USER_NM,
				   						 V_USER_EML_ADR,
										 BTCH_USER_EENO,
										 'H',
										 '0',
										 '0',
										 V_MAIL_CONTENT,
                               			 SYSDATE,
										 V_MAIL_TITLE,
										 '0',
										 '0',
										 V_USER_NM,
				   						 V_USER_EML_ADR,
										 BTCH_USER_EENO);

			END IF;
			
		END LOOP;

	   END SEND_ERROR_MAIL;
/**********************************************************/
/**********************************************************/
       --미지정 국가코드 발생 정보 메일 전송하는 역할 수행
	   PROCEDURE SEND_NOAPIM_NATL_INFO_MAIL(P_EXPD_CO_CD  IN VARCHAR2,
	   			 							P_AFFR_SCN_CD IN VARCHAR2,
											P_CURR_YMD    IN VARCHAR2)
	   IS

		 V_CNT NUMBER;

	   BEGIN

			--생산마스터인 경우에는 생산계획 배치가 이미 실행된 이후에만 메일을 전송하도록 한다.
			IF P_AFFR_SCN_CD = '03' THEN

			   SELECT COUNT(*)
			   INTO V_CNT
			   FROM TB_BATCH_FNH_INFO
			   WHERE AFFR_SCN_CD = '01'
			   AND DL_EXPD_CO_CD = P_EXPD_CO_CD
			   AND BTCH_FNH_YMD = P_CURR_YMD;

			ELSE

			   --생산계획인 경우에는 생산마스터 배치가 이미 실행된 이후에만 메일을 전송하도록 한다.
			   SELECT COUNT(*)
			   INTO V_CNT
			   FROM TB_BATCH_FNH_INFO
			   WHERE AFFR_SCN_CD = '03'
			   AND DL_EXPD_CO_CD = P_EXPD_CO_CD
			   AND BTCH_FNH_YMD = P_CURR_YMD;

			END IF;

			IF V_CNT > 0 THEN

			   SEND_NOAPIM_NATL_INFO_MAIL_DTL(P_EXPD_CO_CD);

			END IF;

	   END SEND_NOAPIM_NATL_INFO_MAIL;

	   PROCEDURE SEND_NOAPIM_NATL_INFO_MAIL_DTL(EXPD_CO_CD IN VARCHAR2)
	   IS

		 CURSOR CRGR_USER_LIST_INFO IS SELECT A.USER_EENO AS USER_EENO,
                					   		  NVL(A.USER_NM, ' ') AS USER_NM,
											  A.USER_EML_ADR AS USER_EML_ADR
           							   FROM TB_USR_MGMT A,
		   							   		TB_CODE_MGMT B
									   WHERE B.DL_EXPD_G_CD = '0030'
									   AND A.USER_EENO = PG_COMMON.FU_RPAD(B.DL_EXPD_PRVS_NM, 7)
									   AND B.USE_YN = 'Y'
		   							   AND A.USE_YN = 'Y';

		 CURSOR NOAPIM_NATL_INFO IS SELECT DL_EXPD_NAT_CD,
		                                   NAT_NM
		 						    FROM TB_NATL_NOAPIM_MGMT
									WHERE DL_EXPD_CO_CD = EXPD_CO_CD
									ORDER BY DL_EXPD_NAT_CD;
									
		CURSOR PROD_MST_NOAPIM_INFO IS SELECT
											QLTY_VEHL_CD,
											PRDN_MST_NAT_CD
										FROM TB_PROD_MST_NOAPIM_INFO
										GROUP BY QLTY_VEHL_CD, PRDN_MST_NAT_CD
										ORDER BY QLTY_VEHL_CD, PRDN_MST_NAT_CD;

		 V_MAIL_TITLE   VARCHAR2(8000);
		 V_MAIL_CONTENT VARCHAR2(8000);
		 V_CNT			NUMBER;

	   BEGIN

			V_CNT := 0;

			FOR NATL_LIST IN NOAPIM_NATL_INFO LOOP

				IF V_CNT = 0 THEN
					V_MAIL_CONTENT := V_MAIL_CONTENT || '국가/언어 미지정 리스트<br>';
				END IF;
				V_MAIL_CONTENT := V_MAIL_CONTENT || '&nbsp;&nbsp;' || NATL_LIST.DL_EXPD_NAT_CD || CASE WHEN NATL_LIST.NAT_NM IS NULL THEN ' '
				                                                                                       ELSE ' - ' || NATL_LIST.NAT_NM
																								  END
																							   || '<br>';
																							   
				V_CNT := V_CNT + 1;

			END LOOP;
			
			V_CNT := 0;

			FOR PROD_LIST IN PROD_MST_NOAPIM_INFO LOOP

				IF V_CNT = 0 THEN
					V_MAIL_CONTENT := V_MAIL_CONTENT || '<br><br>년식 미지정 리스트<br>';
				END IF;
				V_MAIL_CONTENT := V_MAIL_CONTENT || '&nbsp;&nbsp;' || PROD_LIST.QLTY_VEHL_CD || '&nbsp;&nbsp;' || PROD_LIST.PRDN_MST_NAT_CD || '<br>';

				V_CNT := V_CNT + 1;
			END LOOP;

			IF V_MAIL_CONTENT IS NOT NULL THEN

			   V_MAIL_TITLE   := '오너스매뉴얼 ' || '기아' || ' 국가/언어코드/년식 미지정 국가 내역 확인 바랍니다.';

			   V_MAIL_CONTENT := '<HTML><BODY>' ||
				                 '기아' || ' 국가/언어코드/년식 미지정 국가 내역입니다.<br>확인 후 조치 바랍니다.<br><br>' ||
						         V_MAIL_CONTENT ||
							     '</BODY></HTML>';

			   FOR USER_LIST IN CRGR_USER_LIST_INFO LOOP

			   	IF USER_LIST.USER_EML_ADR IS NOT NULL THEN

				   SP_CHNL_INSERTSIMPLEEMAIL(USER_LIST.USER_NM,
											 USER_LIST.USER_EML_ADR,
											 USER_LIST.USER_EENO,
											 'H',
											 '0',
											 '0',
											 V_MAIL_CONTENT,
                               				 SYSDATE,
											 V_MAIL_TITLE,
											 '0',
											 '0',
											 USER_LIST.USER_NM,
											 USER_LIST.USER_EML_ADR,
											 USER_LIST.USER_EENO);
				END IF;

			  END LOOP;

			END IF;

EXCEPTION
	WHEN OTHERS THEN
		ROLLBACK;
		WRITE_BATCH_LOG('미지정 국가 메일 발송', SYSDATE, 'F', '배치처리실패:[' || SQLERRM || ']');
		COMMIT;
	   END SEND_NOAPIM_NATL_INFO_MAIL_DTL;
/**********************************************************/

END PG_INTERFACE_APS;