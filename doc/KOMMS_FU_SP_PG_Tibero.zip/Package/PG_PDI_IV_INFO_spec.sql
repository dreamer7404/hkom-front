CREATE OR REPLACE PACKAGE KOMMS_ADM.PG_PDI_IV_INFO AS

   TYPE REFCUR IS REF CURSOR;

   --PDI 배송요청 정보 저장
   PROCEDURE PDI_DLVH_REQ_SAVE(P_VEHL_CD        VARCHAR2,
	   			 			   P_MDL_MDY_CD     VARCHAR2,
							   P_LANG_CD        VARCHAR2,
							   P_RQ_QTY		    NUMBER,
							   P_PWMR_EENO      VARCHAR2,
							   P_USER_EENO      VARCHAR2
							   , P_PRDN_PLNT_CD VARCHAR2  -- 광주분리
							   );

   --PDI재고 조회(PDI, 차종, 연식, 지역, 언어)
   PROCEDURE SP_GET_PDI_IV_INFO(P_MENU_ID 	 VARCHAR2,
								P_USER_EENO  VARCHAR2,
								P_CURR_YMD	 VARCHAR2,
 								P_PDI_CD	 VARCHAR2,
								P_VEHL_CD	 VARCHAR2,
								P_MDL_MDY	 VARCHAR2,
								P_REGN_CD	 VARCHAR2,
								P_LANG_CD	 VARCHAR2,
								P_DLVY_STATE VARCHAR2,
                                RS 		   OUT REFCUR,
                                P_MESSAGE OUT VARCHAR2);

   --PDI재고 조회(승상구분, PDI, 차종, 연식, 지역, 언어)
   PROCEDURE SP_GET_PDI_IV_INFO2(P_MENU_ID 	  VARCHAR2,
								 P_USER_EENO  VARCHAR2,
								 P_CURR_YMD	  VARCHAR2,
								 P_PAC_SCN_CD VARCHAR2,
 								 P_PDI_CD	  VARCHAR2,
								 P_VEHL_CD	  VARCHAR2,
								 P_MDL_MDY	  VARCHAR2,
								 P_REGN_CD	  VARCHAR2,
								 P_LANG_CD	  VARCHAR2,
								 P_DLVY_STATE VARCHAR2,
                                 RS 		OUT REFCUR);

   --입고확인 데이터 조회
   PROCEDURE SP_GET_PDI_WHSN_INFO(P_MENU_ID    VARCHAR2,
								  P_USER_EENO  VARCHAR2,
								  P_FROM_YMD   VARCHAR2,
								  P_TO_YMD     VARCHAR2,
								  P_PDI_CD	   VARCHAR2,
								  P_VEHL_CD	   VARCHAR2,
								  P_MDL_MDY	   VARCHAR2,
								  P_REGN_CD	   VARCHAR2,
								  P_LANG_CD	   VARCHAR2,
								  P_USF_CD	   VARCHAR2,  -- D: 내수만, E: 수출만 조회,
								  --P_FROM_NUM NUMBER,
							 	  --P_TO_NUM   NUMBER,
								  --P_CNT     OUT NUMBER,
								  RS 		OUT REFCUR);

   --입고확인 데이터 조회2
   PROCEDURE SP_GET_PDI_WHSN_INFO2(P_MENU_ID 	  VARCHAR2,
								   P_USER_EENO    VARCHAR2,
			  					   P_DATA_SN_LIST VARCHAR2,
			  					   RS OUT REFCUR);

   --입고확인 데이터 저장
   PROCEDURE SP_PDI_WHSN_INFO_SAVE(P_VEHL_CD         VARCHAR2,
	   			 				   P_MDL_MDY_CD	 	 VARCHAR2,
								   P_LANG_CD         VARCHAR2,
								   P_EXPD_MDL_MDY_CD VARCHAR2,
								   P_N_PRNT_PBCN_NO  VARCHAR2,
								   P_DTL_SN          NUMBER,
								   P_EXPD_WHSN_ST_CD VARCHAR2,
								   P_EXPD_BOX_QTY    NUMBER,
								   P_WHSN_QTY		 NUMBER,
								   P_DEEI1_QTY		 NUMBER,
								   P_USER_EENO		 VARCHAR2
								   , P_PRDN_PLNT_CD VARCHAR2  -- 광주분리
								   );

   --재고보정 데이터 조회
   PROCEDURE SP_GET_PDI_REVICE_INFO(P_MENU_ID    VARCHAR2,
								    P_USER_EENO  VARCHAR2,
								    P_CURR_YMD   VARCHAR2,
								    P_PAC_SCN_CD VARCHAR2,
								    P_VEHL_CD	 VARCHAR2,
								    P_MDL_MDY	 VARCHAR2,
								    P_REGN_CD	 VARCHAR2,
								    P_LANG_CD	 VARCHAR2,
								    P_USF_CD	 VARCHAR2,  -- D: 내수만, E: 수출만 조회,
									--P_FROM_NUM NUMBER,
							 		--P_TO_NUM   NUMBER,
									--P_CNT   OUT NUMBER,
								    RS 		OUT REFCUR);

   --재고보정 데이터 조회 수정 2012.12.11 - 재고가 0인 경우 재고보정이 안되는 경우 발생하여, 생산계획도 함께 참조하도록 수정.
   PROCEDURE SP_GET_PDI_REVICE_INFO2(P_MENU_ID    VARCHAR2,
								    P_USER_EENO  VARCHAR2,
								    P_CURR_YMD   VARCHAR2,
								    P_PAC_SCN_CD VARCHAR2,
								    P_VEHL_CD	 VARCHAR2,
								    P_MDL_MDY	 VARCHAR2,
								    P_REGN_CD	 VARCHAR2,
								    P_LANG_CD	 VARCHAR2,
								    P_USF_CD	 VARCHAR2,  -- D: 내수만, E: 수출만 조회,
									--P_FROM_NUM NUMBER,
							 		--P_TO_NUM   NUMBER,
									--P_CNT   OUT NUMBER,
								    RS 		OUT REFCUR);

   --재고보정 데이터 저장
   PROCEDURE SP_PDI_REVICE_INFO_SAVE(P_VEHL_CD         VARCHAR2,
   			 						 P_MDL_MDY_CD	   VARCHAR2,
								     P_LANG_CD         VARCHAR2,
									 P_EXPD_MDL_MDY_CD VARCHAR2,
								     P_N_PRNT_PBCN_NO  VARCHAR2,
								     P_DTL_SN          NUMBER,
								     P_EXPD_WHOT_ST_CD VARCHAR2,
								     P_WHOT_QTY		   NUMBER,
								     P_USER_EENO	   VARCHAR2,
								     P_PRTL_IMTR_SBC   VARCHAR2);

   --재고보정 데이터 저장 (재고 0인 경우 재고보정을 위하여 PG_DATA.SP_PDI_IV_INFO_UPDATE에서 PG_DATA.SP_PDI_IV_INFO_UPDATE3 호출로 수정)
   PROCEDURE SP_PDI_REVICE_INFO_SAVE2(P_VEHL_CD         VARCHAR2,
   			 						 P_MDL_MDY_CD	   VARCHAR2,
								     P_LANG_CD         VARCHAR2,
									 P_EXPD_MDL_MDY_CD VARCHAR2,
								     P_N_PRNT_PBCN_NO  VARCHAR2,
								     P_DTL_SN          NUMBER,
								     P_EXPD_WHOT_ST_CD VARCHAR2,
								     P_WHOT_QTY		   NUMBER,
								     P_USER_EENO	   VARCHAR2,
								     P_PRTL_IMTR_SBC   VARCHAR2);
   --재고보정 데이터 삭제
   PROCEDURE SP_PDI_REVICE_INFO_DELETE(P_VEHL_CD         VARCHAR2,
	   			 				       P_MDL_MDY_CD	 	 VARCHAR2,
								       P_LANG_CD         VARCHAR2,
									   P_EXPD_MDL_MDY_CD VARCHAR2,
								       P_N_PRNT_PBCN_NO  VARCHAR2,
								       P_DTL_SN          NUMBER,
								       P_USER_EENO	     VARCHAR2);

   --PDI 재고정보 일배치 정리작업 수행
   --반드시 현재일 시작시간에 돌려야 한다.
   PROCEDURE SP_PDI_IV_INFO_BATCH;

   --글로비스 자동 입고 처리 배치 작업
   PROCEDURE SP_GLOVIS_WHSN_INFO_BATCH;


END PG_PDI_IV_INFO;