CREATE -- added during DDL generation.
PACKAGE PG_PRNT_REQ_LST_INFO AS
	   
	   TYPE REFCUR IS REF CURSOR;
	   
	   --제작의뢰 내역 조회 
	   PROCEDURE SP_GET_PRNT_REQ_INFO(P_MENU_ID 	   VARCHAR2,
								      P_USER_EENO      VARCHAR2,
									  P_PAC_SCN_CD	   VARCHAR2,
	   			 					  P_VEHL_CD	       VARCHAR2,
	   			 	                  P_MDL_MDY_CD     VARCHAR2,
									  P_REGN_CD		   VARCHAR2,
					                  P_LANG_CD	       VARCHAR2,
					                  P_N_PRNT_PBCN_NO VARCHAR2,
									  P_FROM_YMD	   VARCHAR2,
									  P_TO_YMD		   VARCHAR2,
									  P_CRGR_EENO      VARCHAR2,
									  P_REQ_STATE	   VARCHAR2,
									  --P_FROM_NUM NUMBER,
							 		  --P_TO_NUM   NUMBER,
									  --P_CNT OUT NUMBER, 
					                  RS    OUT REFCUR);

END PG_PRNT_REQ_LST_INFO;

