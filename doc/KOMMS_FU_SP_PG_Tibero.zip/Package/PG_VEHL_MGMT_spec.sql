CREATE OR REPLACE PACKAGE KOMMS_ADM.PG_VEHL_MGMT AS

	   TYPE REFCUR IS REF CURSOR;
	   
	   /**
	   --차종내역 조회
	   PROCEDURE SP_GET_VEHL_MGMT(RS OUT REFCUR);
	   **/
	   					  
	   PROCEDURE SP_GET_VEHL_MGMT2(P_EXPD_CO_CD VARCHAR,
	                               P_PDI_CD	    VARCHAR,
								   P_VEHL_CD	VARCHAR,
								   P_MDL_MDY_CD VARCHAR,
								   P_CRGR_EENO  VARCHAR,
	                               RS OUT REFCUR);
								   
	   PROCEDURE SP_GET_VEHL_MGMT3(P_MENU_ID 	VARCHAR,
							  	   P_USER_EENO 	VARCHAR,
	   			 				   P_EXPD_CO_CD VARCHAR,
								   P_PAC_SCN_CD VARCHAR,
	                               P_PDI_CD	    VARCHAR,
								   P_VEHL_CD	VARCHAR,
								   P_MDL_MDY_CD VARCHAR,
								   P_CRGR_EENO  VARCHAR,
	                               RS OUT REFCUR);
	   
	   --조회시에 차종코드에 관계된 APS, 생산마스터, BOM 차종을 가져오기 위한 함수 
	   FUNCTION FU_GET_PRDN_VEHL_LIST(P_QLTY_VEHL_CD VARCHAR,
			 						  P_PRVS_SCN_CD  VARCHAR -- A: APS차종, B:생산마스터차종, C:BOM차종 (참고: 코드테이블 '0023')
									 ) RETURN VARCHAR;
       
	   
	   --그룹별 담당자 리스트를 가져오기 위한 함수 
	   FUNCTION FU_GET_CRGR_USER_LIST(P_QLTY_VEHL_CD VARCHAR,
	                                  P_MDL_MDY_CD   VARCHAR,
	                                  P_BLNS_CO_CD   VARCHAR
									 ) RETURN VARCHAR;
									 
	   --그룹별 담당자 아이디 리스트를 얻어오는 함수 
	   FUNCTION FU_GET_CRGR_USER_ID_LIST(P_QLTY_VEHL_CD VARCHAR,
	                                     P_MDL_MDY_CD   VARCHAR,
	                                     P_BLNS_CO_CD   VARCHAR
								        ) RETURN VARCHAR;
									 
	   --차종 연식 관계 코드를 가져오기 위한 함수 								 
	   FUNCTION FU_GET_MDY_REL_CD(P_QLTY_VEHL_CD VARCHAR,
	                              P_MDL_MDY_CD   VARCHAR,
								  P_EXPD_REGN_CD VARCHAR
								 ) RETURN VARCHAR;
								 
	   --차종 연식 관계 명칭을 가져오기 위한 함수 								 
	   FUNCTION FU_GET_MDY_REL_NM(P_QLTY_VEHL_CD VARCHAR,
	                              P_MDL_MDY_CD   VARCHAR,
								  P_EXPD_REGN_CD VARCHAR
								 ) RETURN VARCHAR;
	  							   
	   PROCEDURE SP_GET_EXPD_REGN_LIST(RS OUT REFCUR);
	   
	   --그룹별 담당자 아이디, 이름 리스트를 가져오기 위한 프로시저
	   PROCEDURE GET_CRGR_USER_LIST(P_QLTY_VEHL_CD VARCHAR,
	                                P_MDL_MDY_CD   VARCHAR,
	                                P_BLNS_CO_CD   VARCHAR,
									P_USER_ID_LIST OUT VARCHAR,
									P_USER_NM_LIST OUT VARCHAR
								   );
	   
	   --수정시에 차종코드에 해당하는 정보를 조회 
	   PROCEDURE SP_GET_VEHL_INFO(P_QLTY_VEHL_CD VARCHAR,
	                              P_MDL_MDY_CD   VARCHAR,
								  RS OUT REFCUR);
	   
	   --차종코드 정보 저장 
	   PROCEDURE SP_VEHL_INFO_SAVE(P_QLTY_VEHL_CD       VARCHAR,
	                               P_MDL_MDY_CD         VARCHAR,
								   P_EXPD_CO_CD         VARCHAR,
								   P_PAC_SCN_CD         VARCHAR,
								   P_PDI_CD		        VARCHAR,
								   P_VEHL_NM			VARCHAR,
								   P_JB_MDY_REL_CD      VARCHAR,
								   P_DYTM_PLN_VEHL_LIST VARCHAR,
								   P_PRDN_MST_VEHL_LIST VARCHAR,
								   P_BOM_VEHL_LIST      VARCHAR,
								   P_SALE_VEHL_LIST     VARCHAR,
								   USER_ID_LIST1        VARCHAR,
								   USER_ID_LIST2        VARCHAR,
								   USER_ID_LIST3        VARCHAR,
								   USER_ID_LIST4        VARCHAR,
								   USER_ID_LIST5        VARCHAR,
								   P_USE_YN				VARCHAR,
								   P_USER_EENO			VARCHAR,
								   P_MDY_REL_CD1		VARCHAR,
								   P_MDY_REL_CD2		VARCHAR,
								   P_MDY_REL_CD3		VARCHAR,
								   P_MDY_REL_CD4		VARCHAR,
								   P_MDY_REL_CD5		VARCHAR,
								   P_MDY_REL_CD6		VARCHAR,
								   P_ET_YN				CHAR);
	   
	   --GOMS로 부터 실시간 데이터 연계 위해 호출되는 프로시저 
	   PROCEDURE SP_VEHL_INFO_SAVE_IF(P_QLTY_VEHL_CD       VARCHAR,
	                                  P_MDL_MDY_CD         VARCHAR,
								      P_EXPD_CO_CD         VARCHAR,
								   	  P_PAC_SCN_CD         VARCHAR,
								   	  P_PDI_CD		       VARCHAR,
   								   	  P_VEHL_NM			   VARCHAR,
   								   	  P_JB_MDY_REL_CD      VARCHAR,
   								   	  P_DYTM_PLN_VEHL_LIST VARCHAR,
   								   	  P_PRDN_MST_VEHL_LIST VARCHAR,
   								   	  P_BOM_VEHL_LIST      VARCHAR,
   								   	  P_SALE_VEHL_LIST     VARCHAR,
   								   	  P_USER_ID_LIST1      VARCHAR,
   								   	  P_USER_ID_LIST2      VARCHAR,
   								   	  P_USE_YN			   VARCHAR,
   								   	  P_USER_EENO		   VARCHAR,
   								   	  P_MDY_REL_CD1		   VARCHAR,
   								   	  P_MDY_REL_CD2		   VARCHAR,
   								   	  P_MDY_REL_CD3		   VARCHAR,
   								   	  P_MDY_REL_CD4		   VARCHAR,
   								   	  P_MDY_REL_CD5		   VARCHAR,
   								   	  P_MDY_REL_CD6		   VARCHAR);
								   
	   
	   PROCEDURE SP_MDY_REL_CD_SAVE(P_QLTY_VEHL_CD VARCHAR,
	                                P_MDL_MDY_CD   VARCHAR,
									P_EXPD_REGN_CD VARCHAR,
									P_MDY_REL_CD   VARCHAR,
									P_USER_EENO    VARCHAR);
									
  	   --연식관리 내역 조회 							   
	   PROCEDURE SP_GET_VEHL_MDY_MGMT(P_EXPD_CO_CD   VARCHAR,
	                                  P_PAC_SCN_CD   VARCHAR,
							  		  P_PDI_CD		 VARCHAR,
	                                  P_QLTY_VEHL_CD VARCHAR,
									  P_REGN_CD      VARCHAR,
									  P_FROM_YMD	 VARCHAR,
									  P_TO_YMD		 VARCHAR,
									  RS OUT REFCUR);
	   --연식관리 내역 저장 
	   PROCEDURE SP_VEHL_MDY_MGMT_SAVE(P_VEHL_CD    VARCHAR,
	                                   P_REGN_CD    VARCHAR,
	   			 					   P_MDL_MDY_CD VARCHAR,
									   P_FROM_PACK 	VARCHAR,
									   P_USER_EENO  VARCHAR);
									   
	   --GOMS로 부터 실시간 데이터 연계 위해 호출되는 프로시저 								   
	   PROCEDURE SP_VEHL_MDY_MGMT_SAVE_IF(P_VEHL_CD    VARCHAR,
	                                      P_REGN_CD    VARCHAR,
	   			 					   	  P_MDL_MDY_CD VARCHAR,
									   	  P_FROM_PACK  VARCHAR,
									   	  P_USER_EENO  VARCHAR);
	   								  
	   --연계차종 정보 저장 					   
	   PROCEDURE SP_PRDN_VEHL_LIST_SAVE(P_QLTY_VEHL_CD   VARCHAR,
										P_PRVS_SCN_CD    VARCHAR,
										P_PRDN_VEHL_LIST VARCHAR,
								        P_USER_EENO      VARCHAR);						
	   
	   --차종 담당자 정보 저장 
	   PROCEDURE SP_CRGR_USER_LIST_SAVE(P_QLTY_VEHL_CD VARCHAR,
	                                    P_MDL_MDY_CD   VARCHAR,
	                                    P_BLNS_CO_CD   VARCHAR,
										P_USER_ID_LIST VARCHAR,
								        P_USER_EENO    VARCHAR);
	   				
	   --저장시 언어코드정보와 국가코드정보를 복사하는 작업을 수행(연식 신규추가시에만 호출)  								
	   PROCEDURE SP_VEHL_MDY_COPY(P_VEHL_CD    VARCHAR,
	   							  P_MDL_MDY_CD VARCHAR,
								  P_USER_EENO  VARCHAR);
	   
	   --저장시 직전연식관계 변화에 따른 취급설명서 연식코드 매핑 작업 수행 
	   PROCEDURE SP_VEHL_MDY_REL_CD_UPDATE(P_VEHL_CD      VARCHAR,
	   							           P_MDL_MDY_CD   VARCHAR,
										   P_EXPD_REGN_CD VARCHAR,
								           P_MDY_REL_CD   VARCHAR,
										   P_USER_EENO    VARCHAR);
                                           
       --직전연식관계에 따른 연식 리스트 조회 
       FUNCTION FU_GET_REL_MDL_MDY(P_VEHL_CD      VARCHAR,
	   							   P_MDL_MDY_CD   VARCHAR,
								   P_EXPD_REGN_CD VARCHAR,
                                   P_MODE         VARCHAR,
                                   P_COUNT OUT BINARY_INTEGER) RETURN PG_COMMON.LIST_TYPE;
                                   
       FUNCTION FU_GET_REL_MDL_MDY_SUB(P_VEHL_CD      VARCHAR,
	   							       P_MDL_MDY_CD   VARCHAR,
								       P_EXPD_REGN_CD VARCHAR,
                                       P_MODE         VARCHAR,
                                       P_ISCONTINUE   OUT VARCHAR) RETURN VARCHAR;
                                       
	   
	   --직전연식관계 내역을 저장 					   
       PROCEDURE SP_EXPD_MDY_MGMT_SAVE(P_VEHL_CD         VARCHAR,
	   			 					   P_MDL_MDY_CD      VARCHAR,
									   P_EXPD_REGN_CD    VARCHAR,
									   P_EXPD_MDL_MDY_CD VARCHAR,
									   P_USER_EENO       VARCHAR);
	   
	   
	   --월팩코드에 따른 차종의 연식을 저장							   
	   PROCEDURE SP_VEHL_MDY_PACK_SAVE(P_VEHL_CD    VARCHAR,
	                                   P_REGN_CD    VARCHAR,
	   			 					   P_MDL_MDY_CD VARCHAR,
									   P_FROM_PACK 	VARCHAR,
									   P_USER_EENO  VARCHAR);
       
	   --신규 차종 입력 항목에 대한 관리자 입력 권한 지정 						   
	   /*PROCEDURE SP_UPDATE_VEHL_AUTH(P_VEHL_CD    VARCHAR,
	                                 P_PAC_SCN_CD VARCHAR);*/
									 
	   
	   PROCEDURE SP_LANG_MDY_REL_CD_UPDATE(P_VEHL_CD      VARCHAR,
	   							           P_MDL_MDY_CD   VARCHAR,
										   P_EXPD_REGN_CD VARCHAR,
								           P_MDY_REL_CD   VARCHAR,
										   P_USER_EENO    VARCHAR);
									   
	   PROCEDURE SP_GET_PLNT_LIST(P_VEHL_CD VARCHAR,
	                              RS        OUT REFCUR);

		PROCEDURE SP_UPDATE_NATL_VEHL_MGMT;
									  
END PG_VEHL_MGMT;