CREATE or replace PACKAGE BODY KOMMS_ADM.PG_PRNT_APVL_INFO AS

	   --발간번호 리스트 조회
	   PROCEDURE SP_GET_PBCN_LIST(P_VEHL_CD	     VARCHAR2,
	   			 				  P_MDL_MDY_CD   VARCHAR2,
								  P_LANG_CD	     VARCHAR2,
								  P_PRNT_PBCN_NO VARCHAR2,
							      RS OUT REFCUR)
	   IS
	   BEGIN


			OPEN RS FOR

				 /***

				 --발주승인 화면에서는 연식관계를 고려할 필요없이
				 --현재 선택된 연식으로 작성된 의뢰 리스트 정보만을 표시해 주도록 한다.

				 SELECT A.N_PRNT_PBCN_NO,
				 		A.OLD_PRNT_PBCN_NO,
				 	    A.MDL_MDY_CD,
						A.LANG_CD,
						A.DL_EXPD_RDCS_ST_CD,
						B.QLTY_VEHL_NM,
						A.LANG_CD_NM
				 FROM (SELECT A.N_PRNT_PBCN_NO,
				 	  		  A.QLTY_VEHL_CD,
				 	  		  A.MDL_MDY_CD,
							  A.LANG_CD,
							  A.OLD_PRNT_PBCN_NO,
						      A.DL_EXPD_RDCS_ST_CD,
							  B.LANG_CD_NM
					   FROM TB_PRNT_BKGD_INFO A,
					   		TB_LANG_MGMT B,
					        TB_DL_EXPD_MDY_MGMT C
					   WHERE A.QLTY_VEHL_CD     = B.QLTY_VEHL_CD
					   AND A.MDL_MDY_CD         = B.MDL_MDY_CD
					   AND A.LANG_CD            = B.LANG_CD
					   AND A.QLTY_VEHL_CD       = C.QLTY_VEHL_CD
					   AND A.MDL_MDY_CD         = C.MDL_MDY_CD
--[수정예정] 나중에 주석 제거 요망
					   --AND B.DL_EXPD_REGN_CD    = C.DL_EXPD_REGN_CD
					   AND A.QLTY_VEHL_CD       = P_VEHL_CD
					   --현재의 연식을 취급설명서 연식으로 간주하고 작업을 진행한다.
					   AND C.DL_EXPD_MDL_MDY_CD = P_MDL_MDY_CD
					   AND A.LANG_CD            = P_LANG_CD
					   AND A.N_PRNT_PBCN_NO LIKE P_PRNT_PBCN_NO || '%'
					   AND A.DL_EXPD_RDCS_ST_CD <> '05' --의뢰되지 않고 저장만 된 내역은 보여주지 않는다.
				 	  ) A,
					  TB_VEHL_MGMT B
				 WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
				 AND A.MDL_MDY_CD = B.MDL_MDY_CD
				 ORDER BY A.N_PRNT_PBCN_NO DESC;
				 ***/

				 SELECT A.N_PRNT_PBCN_NO,
				 		A.OLD_PRNT_PBCN_NO,
				 	    A.MDL_MDY_CD,
						A.LANG_CD,
						A.DL_EXPD_RDCS_ST_CD,
						B.QLTY_VEHL_NM,
						C.LANG_CD_NM
				 FROM TB_PRNT_BKGD_INFO A,
				 	  TB_VEHL_MGMT B,
					  TB_LANG_MGMT C
				 WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
				 AND A.MDL_MDY_CD     = B.MDL_MDY_CD
				 AND A.QLTY_VEHL_CD   = C.QLTY_VEHL_CD
				 AND A.MDL_MDY_CD     = C.MDL_MDY_CD
				 AND A.LANG_CD        = C.LANG_CD
				 AND A.QLTY_VEHL_CD   = P_VEHL_CD
				 AND A.MDL_MDY_CD     = P_MDL_MDY_CD
				 AND A.LANG_CD        = P_LANG_CD
				 AND A.N_PRNT_PBCN_NO LIKE P_PRNT_PBCN_NO || '%'
				 AND A.DL_EXPD_RDCS_ST_CD <> '05' --의뢰되지 않고 저장만 된 내역은 보여주지 않는다.
				 ORDER BY A.N_PRNT_PBCN_NO DESC;

	   END SP_GET_PBCN_LIST;

       --제작의뢰 내용 조회
	   PROCEDURE SP_GET_PRNT_APVL_INFO(P_VEHL_CD	    VARCHAR2,
	   			 				       P_MDL_MDY_CD     VARCHAR2,
								       P_LANG_CD	    VARCHAR2,
								       P_N_PRNT_PBCN_NO VARCHAR2,
							           RS OUT REFCUR)
	   IS

		 V_IV_QTY1         NUMBER;
	 	 V_IV_QTY2		   NUMBER;
		 V_ORD_QTY         NUMBER;
		 V_MO_AVG_PRDN_QTY NUMBER;

		 V_CURR_YMD        VARCHAR2(8);

	   BEGIN

			V_CURR_YMD := TO_CHAR(SYSDATE, 'YYYYMMDD');

			--현재의 연식을 취급설명서 연식으로 간주하여 계산해 주도록 한다.
			SELECT NVL(SUM(IV_QTY), 0)
			INTO V_IV_QTY1
			FROM TB_SEWHA_IV_INFO
			WHERE QLTY_VEHL_CD = P_VEHL_CD
			AND DL_EXPD_MDL_MDY_CD = P_MDL_MDY_CD
        	AND LANG_CD = P_LANG_CD
			AND CLS_YMD = V_CURR_YMD;

			--현재의 연식을 취급설명서 연식으로 간주하여 계산해 주도록 한다.
			SELECT NVL(SUM(IV_QTY), 0)
			INTO V_IV_QTY2
			FROM TB_PDI_IV_INFO
			WHERE QLTY_VEHL_CD = P_VEHL_CD
			AND DL_EXPD_MDL_MDY_CD = P_MDL_MDY_CD
        	AND LANG_CD = P_LANG_CD
			AND CLS_YMD = V_CURR_YMD;

			--현재의 연식을 취급설명서 연식으로 간주하여 계산해 주도록 한다.
			--그리고 순수하게 현재 취급서명서 연식의 투입및 오더 수량을 계산해 주도록 한다.
			SELECT NVL(SUM(TMM_ORD_QTY), 0),
			       NVL(SUM(MTH3_MO_AVG_TRWI_QTY), 0)
			INTO V_ORD_QTY,
			     V_MO_AVG_PRDN_QTY
			FROM TB_APS_PROD_SUM_INFO
			WHERE QLTY_VEHL_CD = P_VEHL_CD
			AND MDL_MDY_CD = P_MDL_MDY_CD
			AND LANG_CD = P_LANG_CD
			AND APL_YMD = V_CURR_YMD;

			OPEN RS FOR
				 SELECT A.*,
				        '(' || C.QLTY_VEHL_CD || ')' || C.QLTY_VEHL_NM || '-' || C.MDL_MDY_CD || 'MY' AS QLTY_VEHL_NM,
						'(' || B.LANG_CD || ')' || B.LANG_CD_NM AS LANG_CD_NM,
						NVL(IV_QTY, V_IV_QTY1 + V_IV_QTY2) AS IV_QTY,
						NVL(ORD_QTY, V_ORD_QTY) AS ORD_QTY,
						NVL(MO_AVG_PRDN_QTY, V_MO_AVG_PRDN_QTY) AS MO_AVG_PRDN_QTY,
						D.REM, NVL(D.OLD_PRNT_PBCN_NO, A.OLD_PRNT_PBCN_NO) AS OLD_PRNT_PBCN_NO1
				 FROM TB_PRNT_REQ_INFO A,
				      TB_LANG_MGMT B,
					  TB_VEHL_MGMT C,
					  TB_PRNT_FP_INFO D
				 WHERE A.N_PRNT_PBCN_NO = P_N_PRNT_PBCN_NO
				 AND A.QLTY_VEHL_CD = P_VEHL_CD
				 AND A.MDL_MDY_CD = P_MDL_MDY_CD
				 AND A.LANG_CD = P_LANG_CD
				 AND A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
				 AND A.MDL_MDY_CD = B.MDL_MDY_CD
				 AND A.LANG_CD = B.LANG_CD
				 AND A.QLTY_VEHL_CD = C.QLTY_VEHL_CD
				 AND A.MDL_MDY_CD = C.MDL_MDY_CD
				 AND A.N_PRNT_PBCN_NO = D.N_PRNT_PBCN_NO(+);

	   END SP_GET_PRNT_APVL_INFO;

	   --체크리스트 정보 조회
	   PROCEDURE SP_GET_CHK_LIST(P_VEHL_CD	        VARCHAR2,
	   			 				 P_MDL_MDY_CD       VARCHAR2,
								 P_LANG_CD	        VARCHAR2,
								 P_N_PRNT_PBCN_NO   VARCHAR2,
								 P_OLD_PRNT_PBCN_NO VARCHAR2,
							     RS OUT REFCUR)
	   IS
	   BEGIN

		 OPEN RS FOR
		 	  SELECT A.DL_EXPD_ALTR_NO,
			  		 D.ALTR_YMD,
					 D.RCPM_SHAP_CD,
					 D.DSPP_NM,
					 D.CHGR_EENO,
					 D.CRGR_NM,
					 B.QLTY_VEHL_NM,
                     A.N1AFP2_ADR,
                     A.N1AFP2_ADR1,
					 C.LANG_CD_NM,
					 D.ALTR_SBC,
					 A.N_PRNT_PBCN_NO,
					 D.ATTC_YN
			  FROM (SELECT A.DL_EXPD_ALTR_NO,
			  	   		   A.QLTY_VEHL_CD,
						   A.LANG_CD,
                           B.N1AFP2_ADR,
                           B.N1AFP2_ADR1,
						   NVL(A.N_PRNT_PBCN_NO, '') AS N_PRNT_PBCN_NO,
						   CASE WHEN B.RCPM_SHAP_CD IN ('05', '06', '07') THEN 0
						   		WHEN A.N_PRNT_PBCN_NO IS NULL THEN 1
						        WHEN A.N_PRNT_PBCN_NO = P_N_PRNT_PBCN_NO THEN 2
							    WHEN A.N_PRNT_PBCN_NO = P_OLD_PRNT_PBCN_NO THEN 3
						   END AS IDX
			        FROM TB_CHKLIST_DTL_INFO A,
			             TB_CHKLIST_INFO B
			        WHERE A.DL_EXPD_ALTR_NO = B.DL_EXPD_ALTR_NO
			        AND A.QLTY_VEHL_CD = P_VEHL_CD
			        AND A.LANG_CD = P_LANG_CD
					AND B.DEL_YN = 'N'
					AND (B.RCPM_SHAP_CD IN ('05', '06', '07')  --법규의 경우에는 무조건 표시되도록 한다.
					     OR (A.N_PRNT_PBCN_NO IS NULL OR
			                 A.N_PRNT_PBCN_NO IN (P_N_PRNT_PBCN_NO, P_OLD_PRNT_PBCN_NO)
							)
						)
			       ) A,
				   (SELECT QLTY_VEHL_CD,
				   		   QLTY_VEHL_NM
					FROM TB_VEHL_MGMT
					WHERE QLTY_VEHL_CD = P_VEHL_CD
					AND MDL_MDY_CD = P_MDL_MDY_CD
				   ) B,
				   (SELECT QLTY_VEHL_CD,
				   		   LANG_CD,
				   		   LANG_CD_NM
					FROM TB_LANG_MGMT
					WHERE QLTY_VEHL_CD = P_VEHL_CD
					AND MDL_MDY_CD = P_MDL_MDY_CD
					AND LANG_CD = P_LANG_CD
				   ) C,
				   TB_CHKLIST_INFO D
			  WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
			  AND A.QLTY_VEHL_CD = C.QLTY_VEHL_CD
			  AND A.LANG_CD = C.LANG_CD
			  AND A.DL_EXPD_ALTR_NO = D.DL_EXPD_ALTR_NO
			  ORDER BY A.IDX, A.DL_EXPD_ALTR_NO;

	   END SP_GET_CHK_LIST;

       --반려 내역 조회
	   PROCEDURE SP_PRNT_APVL_SBC_INFO(P_N_PRNT_PBCN_NO VARCHAR2,
	  								   RS 		        OUT REFCUR)
	   IS
	   BEGIN

		   OPEN RS FOR
		   		SELECT PRTL_SBC
				FROM TB_PRNT_BKGD_INFO
				WHERE N_PRNT_PBCN_NO = P_N_PRNT_PBCN_NO;

	   END SP_PRNT_APVL_SBC_INFO;

	   --제작승인 내역 저장
	   PROCEDURE SP_PRNT_APVL_INFO_SAVE(P_QLTY_VEHL_CD    VARCHAR2,
									    P_EXPD_MDL_MDY_CD VARCHAR2,
									    P_LANG_CD         VARCHAR2,
									    P_N_PRNT_PBCN_NO  VARCHAR2,
	   			 						P_PRNT_PARR_QTY   NUMBER,
										P_PRNT_PARR_YMD   VARCHAR2,
									    P_DLVG_PARR_YMD   VARCHAR2,
                                        P_STATE      	  VARCHAR2,
                                        P_USER_EENO       VARCHAR2,
                                        P_PRTL_SBC        VARCHAR2)
	  IS

		V_RDCS_ST_CD VARCHAR2(4);

		V_CURR_YMD   VARCHAR2(8);

		V_I_WAY_CD	 VARCHAR2(4);

		V_QLTY_VEHL_CD    VARCHAR2(4);
		V_MDL_MDY_CD	  VARCHAR2(2);
		V_LANG_CD         VARCHAR2(3);
		V_EXPD_MDL_MDY_CD VARCHAR2(2);

	  BEGIN

		   V_CURR_YMD := TO_CHAR(SYSDATE, 'YYYYMMDD');

		   IF PG_PRNT_REQ_INFO.FU_CHECK_RDCS_ST_CD(P_N_PRNT_PBCN_NO, P_STATE, V_RDCS_ST_CD) = 'Y' THEN

			  UPDATE TB_PRNT_BKGD_INFO
			  SET DL_EXPD_RDCS_ST_CD = V_RDCS_ST_CD,
			      TRTM_YMD = V_CURR_YMD,
				  UPDR_EENO = P_USER_EENO,
				  MDFY_DTM = SYSDATE,
                  PRTL_SBC = P_PRTL_SBC
			  WHERE N_PRNT_PBCN_NO = P_N_PRNT_PBCN_NO;

			  --승인의 경우에는 세화 재고 데이터 Insert 작업 수행
			  IF P_STATE = 'C' THEN

				 --발주의뢰 내역에 승인일, 승인자정보를 표시하여 준다.
				 UPDATE TB_PRNT_REQ_INFO
				 SET ORDN_CSET_CDT = V_CURR_YMD,
				     CSET_CRGR_EENO = P_USER_EENO,
				     UPDR_EENO = P_USER_EENO,
				     MDFY_DTM = SYSDATE
				 WHERE N_PRNT_PBCN_NO = P_N_PRNT_PBCN_NO;

				 --조회조건에 차종, 언어 항목을 임의로 변경 후에 승인 작업 진행시에는
				 --인자로 들어온 차종, 언어 내역이 잘못 들어 오게 된다. 그래서 아래 부분에서 다시 테이블에서 읽어와서 처리하도록 변경함
				 SELECT I_WAY_CD,
				 		QLTY_VEHL_CD,
						MDL_MDY_CD,
						LANG_CD,
						DL_EXPD_MDL_MDY_CD
				 INTO V_I_WAY_CD,
				      V_QLTY_VEHL_CD,
					  V_MDL_MDY_CD,
					  V_LANG_CD,
					  V_EXPD_MDL_MDY_CD
				 FROM TB_PRNT_REQ_INFO
				 WHERE N_PRNT_PBCN_NO = P_N_PRNT_PBCN_NO;

				 --스티커, 리플렛의 경우에는 재고에 추가해 주지 않는다.
				 IF V_I_WAY_CD NOT IN ('04', '05') THEN

					PG_SEWHA_IV_INFO.SP_SEWHA_WHSN_INFO_SAVE(V_CURR_YMD, V_QLTY_VEHL_CD, V_MDL_MDY_CD, V_LANG_CD, V_EXPD_MDL_MDY_CD, P_N_PRNT_PBCN_NO,
				                                             P_PRNT_PARR_QTY, P_USER_EENO, P_PRNT_PARR_YMD, P_DLVG_PARR_YMD, P_USER_EENO);

				 END IF;


			  END IF;

		   ELSE

			   RAISE_APPLICATION_ERROR(-20001, 'Invalid State Code - STATE:[' || P_STATE || '] RDCS_ST_CD:[' || V_RDCS_ST_CD || ']');

		   END IF;

	  END SP_PRNT_APVL_INFO_SAVE;

	  --제작승인 취소 작업 수행
	  PROCEDURE SP_PRNT_APVL_INFO_CANCEL(P_QLTY_VEHL_CD    VARCHAR2,
									     P_EXPD_MDL_MDY_CD VARCHAR2,
									     P_LANG_CD         VARCHAR2,
									     P_N_PRNT_PBCN_NO  VARCHAR2,
										 P_STATE      	   VARCHAR2,
										 P_USER_EENO       VARCHAR2)
	  IS

		V_RDCS_ST_CD VARCHAR2(4);

		V_CSET_YMD   VARCHAR2(8);

		V_PARR_QTY   NUMBER;

		V_I_WAY_CD	 VARCHAR2(4);

		V_QLTY_VEHL_CD    VARCHAR2(4);
		V_MDL_MDY_CD	  VARCHAR2(2);
		V_LANG_CD         VARCHAR2(3);
		V_EXPD_MDL_MDY_CD VARCHAR2(2);

	  BEGIN

		   IF PG_PRNT_REQ_INFO.FU_CHECK_RDCS_ST_CD(P_N_PRNT_PBCN_NO, P_STATE, V_RDCS_ST_CD) = 'Y' THEN

			  UPDATE TB_PRNT_BKGD_INFO
			  SET DL_EXPD_RDCS_ST_CD = V_RDCS_ST_CD,
			      TRTM_YMD = TO_CHAR(SYSDATE, 'YYYYMMDD'),
				  UPDR_EENO = P_USER_EENO,
				  MDFY_DTM = SYSDATE
			  WHERE N_PRNT_PBCN_NO = P_N_PRNT_PBCN_NO;

			  SELECT ORDN_CSET_CDT, PRNT_PARR_QTY
			  INTO V_CSET_YMD, V_PARR_QTY
			  FROM TB_PRNT_REQ_INFO
			  WHERE N_PRNT_PBCN_NO = P_N_PRNT_PBCN_NO;

			  --발주의뢰 내역에 승인일, 승인자정보를 제거한다.
			  UPDATE TB_PRNT_REQ_INFO
			  SET ORDN_CSET_CDT = NULL,
				  CSET_CRGR_EENO = NULL,
				  UPDR_EENO = P_USER_EENO,
				  MDFY_DTM = SYSDATE
			  WHERE N_PRNT_PBCN_NO = P_N_PRNT_PBCN_NO;

			  --조회조건에 차종, 언어 항목을 임의로 변경 후에 취소 작업 진행시에는
			  --인자로 들어온 차종, 언어 내역이 잘못 들어 오게 된다. 그래서 아래 부분에서 다시 테이블에서 읽어와서 처리하도록 변경함
			  SELECT I_WAY_CD,
			         QLTY_VEHL_CD,
					 MDL_MDY_CD,
					 LANG_CD,
					 DL_EXPD_MDL_MDY_CD
			  INTO V_I_WAY_CD,
			       V_QLTY_VEHL_CD,
				   V_MDL_MDY_CD,
				   V_LANG_CD,
				   V_EXPD_MDL_MDY_CD
			  FROM TB_PRNT_REQ_INFO
			  WHERE N_PRNT_PBCN_NO = P_N_PRNT_PBCN_NO;

			  --스티커, 리플렛의 경우에는 재고보정 해 주지 않는다.
			  IF V_I_WAY_CD NOT IN ('04', '05') THEN

				 --세화 재고내역 취소 작업 수행
			  	 PG_SEWHA_IV_INFO.SP_SEWHA_WHSN_INFO_CANCEL(V_CSET_YMD,
			  						       				    V_QLTY_VEHL_CD,
															V_MDL_MDY_CD,
									       				    V_LANG_CD,
															V_EXPD_MDL_MDY_CD,
									       				    P_N_PRNT_PBCN_NO,
									       				    V_PARR_QTY,
									       				    P_USER_EENO);
			  END IF;

		   ELSE

			   RAISE_APPLICATION_ERROR(-20001, 'Invalid State Code - STATE:[' || P_STATE || '] RDCS_ST_CD:[' || V_RDCS_ST_CD || ']');

		   END IF;

		   COMMIT;
		   
			EXCEPTION
				WHEN OTHERS THEN
					ROLLBACK;
					PG_INTERFACE_APS.WRITE_BATCH_EXE_LOG('승인취소 에러', SYSDATE, 'F', 'SP_PRNT_APVL_INFO_CANCEL 배치처리실패 : [' || SQLERRM || ']');
	  END SP_PRNT_APVL_INFO_CANCEL;

	  --발주의뢰서에 전달할 내역 조회
	  PROCEDURE SP_GET_ORDER_REQ_INFO(P_VEHL_CD	       VARCHAR2,
	   			 				      P_MDL_MDY_CD     VARCHAR2,
								      P_LANG_CD	       VARCHAR2,
								      P_N_PRNT_PBCN_NO VARCHAR2,
							          RS OUT REFCUR)
	  IS

		V_DL_EXPD_CO_NM      VARCHAR2(100);  --회사명(현대자동차, 기아자동차)
		V_DL_EXPD_PAC_SCN_NM VARCHAR2(100);  --승용/상용구분(승용, 상용)
		V_QLTY_VEHL_CD 		 VARCHAR2(4);    --차종코드
		V_MDL_MDY_CD		 VARCHAR2(4);    --연식코드(년도)
		V_MUL_TYP_NM		 VARCHAR2(100);  --메뉴얼종류(취급설명서)
		V_PBSH_TYP_NM 		 VARCHAR2(100);  --발간타입(책자인쇄, 스티커인쇄, 리플렛, 기타)
		V_PRNT_TYP_NM        VARCHAR2(100);  --인쇄구분(완판, 보충판, 개정판, 추가판, 기타)
		V_PRNT_WAY_NM        VARCHAR2(100);  --인쇄방식(옵셋인쇄, 디지털인쇄)
		V_PRNT_FREE_QTY		 NUMBER;		 --무상부수
		V_PRNT_NONFREE_QTY   NUMBER;         --유상부수
		V_PRNT_TOT_QTY		 NUMBER;         --총인쇄부수
		V_PRNT_CVR_QTY		 NUMBER;         --표지매수(4로 고정)
		V_PRNT_CVR_DEPQ1_NM  VARCHAR2(100);  --표지지질(아트)
		V_PRNT_CVR_DEGREE	 VARCHAR2(1);	 --표지인쇄도수
		V_PRNT_NL_QTY		 NUMBER;         --내지매수
		V_PRNT_NL_DEPQ1_NM   VARCHAR2(100);  --내지지질(모조, 화인코트지)
		V_PRNT_NL_DEGREE	 VARCHAR2(1);	 --내지인쇄도수
		V_PRNT_REQ_YMD		 VARCHAR2(10);   --발주의뢰일
		V_PRNT_DLVG_YMD		 VARCHAR2(10);   --납품요청일

		V_EXPD_CO_CD		 VARCHAR2(4);
		V_PAC_SCN_CD		 VARCHAR2(4);
		V_LANG_CD_NM		 VARCHAR2(200);

		V_PRNT_PARR_YMD   TB_PRNT_REQ_INFO.PRNT_PARR_YMD%TYPE;
		V_DLVG_PARR_YMD   TB_PRNT_REQ_INFO.DLVG_PARR_YMD%TYPE;
		V_I_WAY_CD        TB_PRNT_REQ_INFO.I_WAY_CD%TYPE;
		V_PRNT_WAY_CD     TB_PRNT_REQ_INFO.PRNT_WAY_CD%TYPE;
		V_DEPQ1_CD        TB_PRNT_REQ_INFO.DEPQ1_CD%TYPE;
		V_PRNT_PARR_QTY   TB_PRNT_REQ_INFO.PRNT_PARR_QTY%TYPE;
		V_PG_NL           TB_PRNT_REQ_INFO.PG_NL%TYPE;
		V_OORD_EDIT_PG_NL TB_PRNT_REQ_INFO.OORD_EDIT_PG_NL%TYPE;
		V_GRN_DOC_NL      TB_PRNT_REQ_INFO.GRN_DOC_NL%TYPE;
		V_MDFY_PG_NL      TB_PRNT_REQ_INFO.MDFY_PG_NL%TYPE;
		V_DEPC1_YN        TB_PRNT_REQ_INFO.DEPC1_YN%TYPE;
		V_PRTL_IMTR_SBC   TB_PRNT_REQ_INFO.PRTL_IMTR_SBC%TYPE;
		V_ORDN_CSET_CDT   TB_PRNT_REQ_INFO.ORDN_CSET_CDT%TYPE;
		V_PRNT_WAY_CD2    TB_PRNT_REQ_INFO.PRNT_WAY_CD2%TYPE;

		V_LANG_CD_NM_TEMP VARCHAR2(200);

	  BEGIN

		   SELECT B.DL_EXPD_CO_CD,
		   		  B.DL_EXPD_PAC_SCN_CD,
				  A.LANG_CD_NM
		   INTO V_EXPD_CO_CD,
		   		V_PAC_SCN_CD,
				V_LANG_CD_NM
		   FROM TB_LANG_MGMT A,
		        TB_VEHL_MGMT B
		   WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
		   AND A.MDL_MDY_CD = B.MDL_MDY_CD
		   AND A.QLTY_VEHL_CD = P_VEHL_CD
		   AND A.MDL_MDY_CD = P_MDL_MDY_CD
		   AND A.LANG_CD = P_LANG_CD;

		   SELECT PRNT_PARR_YMD,  --인쇄예정일
		          DLVG_PARR_YMD,  --납품예정일
				  I_WAY_CD,       --발행방법
				  PRNT_WAY_CD,    --인쇄방법(표지)
				  DEPQ1_CD,       --인쇄지질코드
				  PRNT_PARR_QTY,  --인쇄예정수량
				  PG_NL,          --내지총페이지
				  OORD_EDIT_PG_NL,--외주편집페이지지매수
				  GRN_DOC_NL,     --보증문서매수
				  MDFY_PG_NL,     --수정페이지매수
				  DEPC1_YN,       --인쇄커버유무
				  PRTL_IMTR_SBC,  --특이사항내용
				  ORDN_CSET_CDT,  --승인일자
				  PRNT_WAY_CD2    --인쇄방법(내지)
		   INTO V_PRNT_PARR_YMD,
		        V_DLVG_PARR_YMD,
				V_I_WAY_CD,
				V_PRNT_WAY_CD,
				V_DEPQ1_CD,
				V_PRNT_PARR_QTY,
				V_PG_NL,
				V_OORD_EDIT_PG_NL,
				V_GRN_DOC_NL,
				V_MDFY_PG_NL,
				V_DEPC1_YN,
				V_PRTL_IMTR_SBC,
				V_ORDN_CSET_CDT,
				V_PRNT_WAY_CD2
		   FROM TB_PRNT_REQ_INFO
		   WHERE N_PRNT_PBCN_NO = P_N_PRNT_PBCN_NO;

		   -- 차종 조회
		   IF V_EXPD_CO_CD = '01' THEN

			  V_DL_EXPD_CO_NM := '현대자동차';

		   ELSE

			  V_DL_EXPD_CO_NM := '기아자동차';

		   END IF;

		   IF V_PAC_SCN_CD = '01' THEN

			  V_DL_EXPD_PAC_SCN_NM := '승용';

		   ELSE

			  V_DL_EXPD_PAC_SCN_NM := '상용';

		   END IF;

		   --차명 조회
		   V_QLTY_VEHL_CD := P_VEHL_CD;

		   --연식 조회
		   V_MDL_MDY_CD := TO_CHAR(TO_DATE(P_MDL_MDY_CD, 'YY'), 'YYYY');

		   --메뉴얼 종류 조회
		   V_MUL_TYP_NM := '취급설명서';

		   --발간타입 조회
--		   IF V_I_WAY_CD IN ('01', '02', '03') THEN

--			  V_PBSH_TYP_NM := '책자인쇄';

--		   ELSIF V_I_WAY_CD = '04' THEN

		   IF V_I_WAY_CD = '04' THEN

			  V_PBSH_TYP_NM := '스티커인쇄';

		   ELSIF V_I_WAY_CD = '05' THEN


			  V_PBSH_TYP_NM := '리플렛';

		   ELSE

--			  V_PBSH_TYP_NM := '기타';

              V_PBSH_TYP_NM := '책자인쇄';

		   END IF;

		   --언어 조회
		   V_LANG_CD_NM_TEMP := FU_GET_LANG_CD_NM(P_LANG_CD);

		   IF V_LANG_CD_NM_TEMP IS NOT NULL THEN

			  V_LANG_CD_NM := V_LANG_CD_NM_TEMP;

		   END IF;

		   --인쇄구분 조회
--		   IF V_I_WAY_CD = '01' THEN

--			  V_PRNT_TYP_NM := '완판';

--		   ELSIF V_I_WAY_CD = '02' THEN

--			  V_PRNT_TYP_NM := '개정판';

--		   ELSIF V_I_WAY_CD = '03' THEN

--			  V_PRNT_TYP_NM := '추가판';

--		   ELSE

--			  V_PRNT_TYP_NM := '기타';

--		   END IF;

		   V_PRNT_TYP_NM := '개정판';

		   --내지인쇄지질 조회
		   IF V_DEPQ1_CD = '01' THEN

			  V_PRNT_NL_DEPQ1_NM := '화인코트지';

		   ELSE

			  V_PRNT_NL_DEPQ1_NM := '모조';

		   END IF;

		   IF V_I_WAY_CD = '04' THEN

			  V_PBSH_TYP_NM := '스티커인쇄';

			  V_PRNT_CVR_QTY      := 0;
		      V_PRNT_CVR_DEPQ1_NM := '스티커인쇄';

		   ELSIF V_I_WAY_CD = '05' THEN


			  V_PBSH_TYP_NM := '리플렛';

			  V_PRNT_CVR_QTY      := 0;
		      V_PRNT_CVR_DEPQ1_NM := '리플렛';

		   ELSE

--			  V_PBSH_TYP_NM := '기타';

              V_PBSH_TYP_NM := '책자인쇄';

			  V_PRNT_CVR_QTY      := 4;
		      V_PRNT_CVR_DEPQ1_NM := '아트';

		   END IF;

		   --인쇄방식 조회
		   IF V_PRNT_WAY_CD2 IN ('01', '02', '08') THEN

			  V_PRNT_WAY_NM := '옵셋인쇄';

		   ELSE

			  V_PRNT_WAY_NM := '디지털인쇄';

		   END IF;

		   V_PRNT_FREE_QTY    := V_PRNT_PARR_QTY;
		   V_PRNT_NONFREE_QTY := 0;
		   V_PRNT_TOT_QTY     := V_PRNT_PARR_QTY;

		   /**
		   --인쇄 도수 조회
		   IF V_PRNT_WAY_CD = '01' THEN

			  V_PRNT_CVR_DEGREE := '3';
			  V_PRNT_NL_DEGREE  := '1';

		   ELSIF V_PRNT_WAY_CD = '02' THEN

		      V_PRNT_CVR_DEGREE := '3';
			  V_PRNT_NL_DEGREE  := '2';

		   ELSIF V_PRNT_WAY_CD = '03' THEN

			  V_PRNT_CVR_DEGREE := '5';
			  V_PRNT_NL_DEGREE  := '1';

		   ELSIF V_PRNT_WAY_CD = '04' THEN

		      V_PRNT_CVR_DEGREE := '5';
			  V_PRNT_NL_DEGREE  := '2';

		   ELSIF V_PRNT_WAY_CD = '05' THEN

			  V_PRNT_CVR_DEGREE := '3';
			  V_PRNT_NL_DEGREE  := '1';

		   ELSIF V_PRNT_WAY_CD = '06' THEN

			  V_PRNT_CVR_DEGREE := '5';
			  V_PRNT_NL_DEGREE  := '1';

		   ELSIF V_PRNT_WAY_CD = '07' THEN

			  V_PRNT_CVR_DEGREE := '4';
			  V_PRNT_NL_DEGREE  := '1';

		   ELSIF V_PRNT_WAY_CD = '08' THEN

			  V_PRNT_CVR_DEGREE := '4';
			  V_PRNT_NL_DEGREE  := '2';

		   ELSIF V_PRNT_WAY_CD = '09' THEN

			  V_PRNT_CVR_DEGREE := '4';
			  V_PRNT_NL_DEGREE  := '1';

		   END IF;
		   **/

		   V_PRNT_CVR_DEGREE := TO_CHAR(TO_NUMBER(V_PRNT_WAY_CD) - 1);

		   IF V_PRNT_WAY_CD2 IN ('01', '03', '04', '06') THEN

			  V_PRNT_NL_DEGREE  := '1';

		   ELSIF V_PRNT_WAY_CD2 = '08' THEN

        V_PRNT_NL_DEGREE  := '4';

       ELSE

			  V_PRNT_NL_DEGREE  := '2';

		   END IF;

--		   V_PRNT_CVR_QTY      := 4;
--		   V_PRNT_CVR_DEPQ1_NM := '아트';

		   V_PRNT_NL_QTY       := V_PG_NL + V_GRN_DOC_NL;

		   --의뢰일을 SYSDATE로 해야 할지 고민됨.....
		   V_PRNT_REQ_YMD  := TO_CHAR(TO_DATE(V_ORDN_CSET_CDT, 'YYYYMMDD'), 'YYYY-MM-DD');

		   V_PRNT_DLVG_YMD := TO_CHAR(TO_DATE(V_DLVG_PARR_YMD, 'YYYYMMDD'), 'YYYY.MM.DD');

		   OPEN RS FOR
		   		SELECT P_N_PRNT_PBCN_NO     AS N_PRNT_PBCN_NO,
				       '취급/' || V_QLTY_VEHL_CD || '/' || V_LANG_CD_NM AS N_PRNT_PBCN_NM,
					   V_DL_EXPD_CO_NM      AS DL_EXPD_CO_NM,
					   V_DL_EXPD_PAC_SCN_NM AS DL_EXPD_PAC_SCN_NM,
					   V_QLTY_VEHL_CD       AS QLTY_VEHL_CD,
					   V_MDL_MDY_CD         AS MDL_MDY_CD,
					   V_MUL_TYP_NM         AS MUL_TYP_NM,
					   V_PBSH_TYP_NM        AS PBSH_TYP_NM,
					   V_LANG_CD_NM         AS LANG_CD_NM,
					   V_PRNT_TYP_NM        AS PRNT_TYP_NM,
					   V_PRNT_WAY_NM        AS PRNT_WAY_NM,
					   V_PRNT_FREE_QTY      AS PRNT_FREE_QTY,
					   V_PRNT_NONFREE_QTY   AS PRNT_NONFREE_QTY,
					   V_PRNT_TOT_QTY       AS PRNT_TOT_QTY,
					   V_PRNT_CVR_QTY       AS PRNT_CVR_QTY,
					   V_PRNT_CVR_DEPQ1_NM  AS PRNT_CVR_DEPQ1_NM,
					   V_PRNT_CVR_DEGREE    AS PRNT_CVR_DEGREE,
					   V_PRNT_NL_QTY        AS PRNT_NL_QTY,
					   V_PRNT_NL_DEPQ1_NM   AS PRNT_NL_DEPQ1_NM,
					   V_PRNT_NL_DEGREE     AS PRNT_NL_DEGREE,
					   V_PRNT_REQ_YMD		AS PRNT_REQ_YMD,
					   V_PRNT_DLVG_YMD      AS PRNT_DLVG_YMD,
					   V_PRTL_IMTR_SBC      AS PRNT_IMTR_SBC
				FROM DUAL;

	  END SP_GET_ORDER_REQ_INFO;

	  --언어코드에 해당하는 발주의뢰서 언어명칭 리턴
	  FUNCTION FU_GET_LANG_CD_NM(P_LANG_CD VARCHAR2)RETURN VARCHAR2
	  IS

		V_LANG_CD_NM VARCHAR2(100);

	  BEGIN

		   IF P_LANG_CD = 'AR' THEN

			  V_LANG_CD_NM := '아랍어/중동';

		   ELSIF P_LANG_CD = 'AS' THEN

			  V_LANG_CD_NM := '영어,아랍어/시리아';

		   ELSIF P_LANG_CD = 'CH' THEN

			  V_LANG_CD_NM := '체코어/유럽';

		   ELSIF P_LANG_CD = 'EA' THEN

			  V_LANG_CD_NM := 'RHD영어/유럽,일반';

		   ELSIF P_LANG_CD = 'EC' THEN

			  V_LANG_CD_NM := '영어,불어/캐나다';

		   ELSIF P_LANG_CD = 'EE' THEN

			  V_LANG_CD_NM := '영어/유럽,일반';

		   ELSIF P_LANG_CD = 'EM' THEN

			  V_LANG_CD_NM := '영어/시리아';

		   ELSIF P_LANG_CD = 'EP' THEN

			  V_LANG_CD_NM := '영어/푸에드리코';

		   ELSIF P_LANG_CD = 'EU' THEN

			  V_LANG_CD_NM := '영어/미국';

		   ELSIF P_LANG_CD = 'FE' THEN

			  V_LANG_CD_NM := '불어/유럽,일반';

		   ELSIF P_LANG_CD = 'FG' THEN

			  V_LANG_CD_NM := '불어/일반';

		   ELSIF P_LANG_CD = 'GE' THEN

			  V_LANG_CD_NM := '독어/유럽';

		   ELSIF P_LANG_CD = 'HO' THEN

			  V_LANG_CD_NM := '네덜란드어/유럽';

		   ELSIF P_LANG_CD = 'HU' THEN

			  V_LANG_CD_NM := '헝가리어/유럽';

		   ELSIF P_LANG_CD = 'IT' THEN

			  V_LANG_CD_NM := '이태리어/유럽';

		   ELSIF P_LANG_CD = 'JA' THEN

			  V_LANG_CD_NM := '일본어/일본';

		   ELSIF P_LANG_CD = 'KO' THEN

			  V_LANG_CD_NM := '한글';

		   ELSIF P_LANG_CD = 'NR' THEN

			  V_LANG_CD_NM := '노르웨이어/유럽';

		   ELSIF P_LANG_CD = 'PB' THEN

			  V_LANG_CD_NM := '포르투갈어/브라질';

		   ELSIF P_LANG_CD = 'PE' THEN

			  V_LANG_CD_NM := '포르투갈어/유럽,일반';

		   ELSIF P_LANG_CD = 'PO' THEN

			  V_LANG_CD_NM := '폴란드/유럽';

		   ELSIF P_LANG_CD = 'SE' THEN

			  V_LANG_CD_NM := '스페인어/유럽,일반';

		   ELSIF P_LANG_CD = 'SG' THEN

			  V_LANG_CD_NM := '스페인어/일반';

		   ELSIF P_LANG_CD = 'SM' THEN

			  V_LANG_CD_NM := '스페인어/멕시코';

		   ELSIF P_LANG_CD = 'SW' THEN

			  V_LANG_CD_NM := '스웨덴어/유럽';

		   ELSIF P_LANG_CD = 'UK' THEN

			  V_LANG_CD_NM := '영어/영국';

		   END IF;

		   RETURN V_LANG_CD_NM;

	  END FU_GET_LANG_CD_NM;

	  --판매단가 인터페이스(배치 프로그램에서 호출)
	  PROCEDURE SP_UPDATE_SALE_UNP(P_N_PRNT_PBCN_NO VARCHAR2,
	   			 				   P_SALE_UNP		 NUMBER)
	  IS
	  BEGIN

		   UPDATE TB_PRNT_REQ_INFO
		   SET SALE_UNP = P_SALE_UNP
		   WHERE N_PRNT_PBCN_NO = P_N_PRNT_PBCN_NO;

		   COMMIT;

	  END SP_UPDATE_SALE_UNP;

END PG_PRNT_APVL_INFO;