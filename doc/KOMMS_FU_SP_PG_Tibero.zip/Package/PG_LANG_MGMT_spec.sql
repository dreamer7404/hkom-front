CREATE OR REPLACE PACKAGE KOMMS_ADM.PG_LANG_MGMT AS
  TYPE REFCUR IS REF CURSOR;

   /**
   -- 언어코드 전체검색
   PROCEDURE SP_LC_MGMT_LIST(P_DL_EXPD_PRVS_CD IN VARCHAR2,
                             P_DL_EXPD_PDI_CD  IN VARCHAR2,
                             P_QLTY_VEHL_CD    IN VARCHAR2,
                             P_MDL_MDY_CD      IN VARCHAR2,
                             P_DL_EXPD_REGN_CD IN VARCHAR2,
                             P_LANG_CD         IN VARCHAR2,
                             RS OUT REFCUR);
   **/

   -- 언어코드 전체검색2
   PROCEDURE SP_LC_MGMT_LIST2(P_MENU_ID 	     IN VARCHAR2,
			                  P_USER_EENO 	     IN VARCHAR2,
   			 				  P_DL_EXPD_PRVS_CD  IN VARCHAR2,
                              P_DL_EXPD_PDI_CD   IN VARCHAR2,
                              P_QLTY_VEHL_CD     IN VARCHAR2,
                              P_MDL_MDY_CD       IN VARCHAR2,
                              P_DL_EXPD_REGN_CD  IN VARCHAR2,
                              P_LANG_CD          IN VARCHAR2,
                              RS OUT REFCUR);

   -- 전체 차종코드, 회사코드 조회
   PROCEDURE SP_VEHL_LIST(RS OUT REFCUR);

   -- 언어코드 입력 중복체크
   PROCEDURE SP_CHECK(P_QLTY_VEHL_CD    IN VARCHAR2,
                      P_MDL_MDY_CD      IN VARCHAR2,
                      P_LANG_CD         IN VARCHAR2,
                      P_DL_EXPD_REGN_CD IN VARCHAR2,
                      RS OUT REFCUR);

   -- 언어코드 입력
   PROCEDURE SP_INSERT(VEHL_CD      IN TB_LANG_MGMT.QLTY_VEHL_CD%TYPE,
                       MDY_CD       IN TB_LANG_MGMT.MDL_MDY_CD%TYPE,
                       L_CD         IN TB_LANG_MGMT.LANG_CD%TYPE,
                       EXPD_REGN_CD IN TB_LANG_MGMT.DL_EXPD_REGN_CD%TYPE,
                       L_CD_NM      IN TB_LANG_MGMT.LANG_CD_NM%TYPE,
                       YN           IN TB_LANG_MGMT.USE_YN%TYPE,
                       N_YN         IN TB_LANG_MGMT.NAPC_YN%TYPE,
                       P_SORT       IN TB_LANG_MGMT.SORT_SN%TYPE,
					   P_ACODE      IN TB_LANG_MGMT.A_CODE%TYPE,
					   P_N1_INS_YN  IN TB_LANG_MGMT.N1_INS_YN%TYPE,
					   P_VEHL_LIST  IN VARCHAR2,
					   P_USER_EENO  IN VARCHAR2);

   -- 언어코드 사용여부관리(삭제)
   PROCEDURE SP_DELETE(D_SN        IN TB_LANG_MGMT.DATA_SN%TYPE,
   			 		   P_USER_EENO IN VARCHAR2);

   -- 언어코드 수정할 내용 검색(데이터일련번호 참조)
   PROCEDURE SP_UPDATE_VIEW(D_SN IN TB_LANG_MGMT.DATA_SN%TYPE,
                            RS OUT REFCUR);

   FUNCTION FU_GET_PDI_COM_VEHL_LIST(P_QLTY_VEHL_CD   IN VARCHAR2,
	 	  						     P_MDL_MDY_CD     IN VARCHAR2,
		  						     P_LANG_CD        IN VARCHAR2,
		  						     P_DL_EXPD_PDI_CD IN VARCHAR2
									) RETURN VARCHAR2;

   --현재의 사용자가 수정가능한 차종의 리스트를 조회(팝업화면용)
   PROCEDURE SP_GET_VEHL_LIST(P_DATA_SN IN TB_LANG_MGMT.DATA_SN%TYPE,
    		 				  RS        OUT REFCUR);

   PROCEDURE SP_GET_VEHL_LIST2(P_QLTY_VEHL_CD IN VARCHAR2,
	 	  					   P_MDL_MDY_CD   IN VARCHAR2,
							   P_LANG_CD	  IN VARCHAR2,
							   RS             OUT REFCUR);
   -- 언어코드 수정
   PROCEDURE SP_UPDATE(D_SN         IN TB_LANG_MGMT.DATA_SN%TYPE,
                       L_CD         IN TB_LANG_MGMT.LANG_CD%TYPE,
                       L_CD_NM      IN TB_LANG_MGMT.LANG_CD_NM%TYPE,
                       EXPD_REGN_CD IN TB_LANG_MGMT.DL_EXPD_REGN_CD%TYPE,
                       YN           IN TB_LANG_MGMT.USE_YN%TYPE,
					   P_SORT       IN TB_LANG_MGMT.SORT_SN%TYPE,
					   P_ACODE      IN TB_LANG_MGMT.A_CODE%TYPE,
					   P_N1_INS_YN  IN TB_LANG_MGMT.N1_INS_YN%TYPE,
					   P_VEHL_LIST  IN VARCHAR2,
					   P_USER_EENO  IN VARCHAR2);

  PROCEDURE SP_N1_INS_YN_UPDATE(P_DATA_SN   IN NUMBER,
								P_VEHL_LIST IN VARCHAR2,
  							    P_USER_EENO IN VARCHAR2);

  PROCEDURE SP_N1_INS_YN_UPDATE2(P_DATA_SN   IN NUMBER,
  							     P_USER_EENO IN VARCHAR2);


  PROCEDURE SP_N1_INS_YN_UPD_DTL(P_DIVS_VEHL_CD       IN VARCHAR2,
	 	  						 P_MDL_MDY_CD         IN VARCHAR2,
		  						 P_LANG_CD            IN VARCHAR2,
								 P_DL_EXPD_CO_CD      IN VARCHAR2,
								 P_DL_EXPD_PAC_SCN_CD IN VARCHAR2,
		  						 P_DL_EXPD_PDI_CD     IN VARCHAR2,
								 P_USER_EENO          IN VARCHAR2);

  PROCEDURE SP_N1_INS_YN_MDFY_DTL(P_QLTY_VEHL_CD   IN VARCHAR2,
	 	  						  P_MDL_MDY_CD     IN VARCHAR2,
		  						  P_LANG_CD        IN VARCHAR2,
		  						  P_DL_EXPD_PDI_CD IN VARCHAR2,
								  P_USER_EENO      IN VARCHAR2);

  PROCEDURE SP_N1_INS_YN_UPD_PDI(P_QLTY_VEHL_CD   IN VARCHAR2,
	 	  						 P_MDL_MDY_CD     IN VARCHAR2,
								 P_DL_EXPD_PDI_CD IN VARCHAR2,
								 P_USER_EENO      IN VARCHAR2);


  --언어코드 수정시에 국가-차종의 지역정보를 수정해 준다.
  PROCEDURE SP_NATL_VEHL_REGN_SAVE(VEHL_CD           IN TB_LANG_MGMT.QLTY_VEHL_CD%TYPE,
                                   MDY_CD            IN TB_LANG_MGMT.MDL_MDY_CD%TYPE,
                                   L_CD              IN TB_LANG_MGMT.LANG_CD%TYPE,
                                   PREV_EXPD_REGN_CD IN TB_LANG_MGMT.DL_EXPD_REGN_CD%TYPE,
								   NEW_EXPD_REGN_CD  IN TB_LANG_MGMT.DL_EXPD_REGN_CD%TYPE);

  --이전연식에서 지정된 언어코드 항목 복사하는 기능수행(차종코드 수정/추가 시에 호출됨)
  PROCEDURE SP_LANG_COPY(P_QLTY_VEHL_CD    IN VARCHAR2,
	 	  				 P_MDL_MDY_CD      IN VARCHAR2,
						 P_PREV_MDL_MDY_CD IN VARCHAR2,
						 P_USER_EENO       IN VARCHAR2);


  --직전연식관계 내역을 저장(언어별)
  PROCEDURE SP_LANG_MDY_MGMT_SAVE(P_VEHL_CD         VARCHAR2,
	   			 			      P_LANG_CD		    VARCHAR2,
                                  P_MDL_MDY_CD      VARCHAR2,
                                  P_PREV_REGN_CD    VARCHAR2,
                                  P_EXPD_REGN_CD    VARCHAR2,
                                  P_USER_EENO       VARCHAR2);

	PROCEDURE SP_UPDATE_LANG_MGMT;

END PG_LANG_MGMT;