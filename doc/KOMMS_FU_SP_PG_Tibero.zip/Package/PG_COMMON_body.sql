CREATE OR REPLACE PACKAGE BODY KOMMS_ADM.PG_COMMON
IS
/**********************************************************/

/**********************************************************/

/**********************************************************/
  -- 조회날짜에 따라 유효한 MIN 연식코드, MAX연식코드를 조회
  PROCEDURE SP_GET_VALID_MDL_MDY1(P_SEARCH_DATE IN VARCHAR2,
                                  RS OUT REFCUR)
  AS

	V_SEARCH_DATE DATE;

  BEGIN

	V_SEARCH_DATE := TO_DATE(P_SEARCH_DATE, 'YYYYMMDD');

	--예를 들어 현재날짜가 2008-10-28 이라면 '07' ==> MIN연식, '10' ==> MAX 연식을 가져오게 된다.
	--[변경] 2011.01.03.김동근 이전 년식을 -1년 으로만 해서는 빠지는 항목이 존재함 -2년으로 변경함
    --[변경] 2013.01.07.임용석 NF의 경우 09이후 변경없어 계속 사용으로 빠짐 -36까지에서 -48(개월)로 변경함.
    OPEN RS FOR
		SELECT TO_CHAR(ADD_MONTHS(V_SEARCH_DATE, -48), 'YY') AS MIN_MDY,
               TO_CHAR(ADD_MONTHS(V_SEARCH_DATE, 24), 'YY') AS MAX_MDY
        FROM DUAL;

  END SP_GET_VALID_MDL_MDY1;
/**********************************************************/

/**********************************************************/
  -- 조회날짜(From ~ To)에 따라 유효한 MIN 연식코드, MAX연식코드를 조회
  PROCEDURE SP_GET_VALID_MDL_MDY2(P_FROM_DATE IN VARCHAR2,
                                  P_TO_DATE   IN VARCHAR2,
                                  RS OUT REFCUR)
  IS

	V_FROM_DATE DATE;
	V_TO_DATE   DATE;

  BEGIN

	V_FROM_DATE := TO_DATE(P_FROM_DATE, 'YYYYMMDD');
	V_TO_DATE   := TO_DATE(P_TO_DATE, 'YYYYMMDD');

	--[변경] 2011.01.03.김동근 이전 년식을 -1년 으로만 해서는 빠지는 항목이 존재함 -2년으로 변경함
    --[변경] 2013.01.07.임용석 NF의 경우 09이후 변경없어 계속 사용으로 빠짐 -36까지에서 -48(개월)로 변경함.
	OPEN RS FOR
	   SELECT TO_CHAR(ADD_MONTHS(V_FROM_DATE, -48), 'YY') AS MIN_MDY,
              TO_CHAR(ADD_MONTHS(V_TO_DATE, 24), 'YY') AS MAX_MDY
       FROM DUAL;

  END SP_GET_VALID_MDL_MDY2;
/**********************************************************/

/**********************************************************/
  --조회날짜에 따라 유효한 연식코드의 리스트를 조회
  PROCEDURE SP_GET_VALID_MDL_MDY3(P_SEARCH_DATE IN VARCHAR2,
                                  RS OUT REFCUR)
  AS

	V_SEARCH_DATE DATE;

  BEGIN

	V_SEARCH_DATE := TO_DATE(P_SEARCH_DATE, 'YYYYMMDD');

	--예를 들어 현재날짜가 2008-10-28 이라면 '07' ==> MIN연식, '10' ==> MAX 연식을 가져오게 된다.
	--[변경] 2011.01.03.김동근 이전 년식을 -1년 으로만 해서는 빠지는 항목이 존재함 -2년으로 변경함
    --[변경] 2013.01.07.임용석 NF의 경우 09이후 변경없어 계속 사용으로 빠짐 -36까지에서 -48(개월)로 변경함.
    OPEN RS FOR

        SELECT TO_CHAR(ADD_MONTHS(V_SEARCH_DATE, -48), 'YY') AS MDL_MDY_CD,
               TO_CHAR(ADD_MONTHS(V_SEARCH_DATE, -48), 'YY') || 'MY' AS MDL_MDY_NM
        FROM DUAL

        UNION ALL

        SELECT TO_CHAR(ADD_MONTHS(V_SEARCH_DATE, -36), 'YY') AS MDL_MDY_CD,
               TO_CHAR(ADD_MONTHS(V_SEARCH_DATE, -36), 'YY') || 'MY' AS MDL_MDY_NM
        FROM DUAL

        UNION ALL

		SELECT TO_CHAR(ADD_MONTHS(V_SEARCH_DATE, -24), 'YY') AS MDL_MDY_CD,
               TO_CHAR(ADD_MONTHS(V_SEARCH_DATE, -24), 'YY') || 'MY' AS MDL_MDY_NM
        FROM DUAL

		UNION ALL

		SELECT TO_CHAR(ADD_MONTHS(V_SEARCH_DATE, -12), 'YY') AS MDL_MDY_CD,
               TO_CHAR(ADD_MONTHS(V_SEARCH_DATE, -12), 'YY') || 'MY' AS MDL_MDY_NM
        FROM DUAL

		UNION ALL

		SELECT TO_CHAR(V_SEARCH_DATE, 'YY') AS MDL_MDY_CD,
               TO_CHAR(V_SEARCH_DATE, 'YY') || 'MY' AS MDL_MDY_NM
        FROM DUAL

		UNION ALL

		SELECT TO_CHAR(ADD_MONTHS(V_SEARCH_DATE, 12), 'YY') AS MDL_MDY_CD,
               TO_CHAR(ADD_MONTHS(V_SEARCH_DATE, 12), 'YY') || 'MY' AS MDL_MDY_NM
        FROM DUAL

		UNION ALL

		SELECT TO_CHAR(ADD_MONTHS(V_SEARCH_DATE, 24), 'YY') AS MDL_MDY_CD,
               TO_CHAR(ADD_MONTHS(V_SEARCH_DATE, 24), 'YY') || 'MY' AS MDL_MDY_NM
        FROM DUAL
		;

  END SP_GET_VALID_MDL_MDY3;
/**********************************************************/

/**********************************************************/
  PROCEDURE SP_GET_VALID_MDL_MDY4(P_FROM_DATE     IN VARCHAR2,
   			 					  P_TO_DATE       IN VARCHAR2,
								  P_FROM_MDL_MDY OUT VARCHAR2,
                                  P_TO_MDL_MDY   OUT VARCHAR2)
  IS

	V_FROM_DATE    DATE;
	V_TO_DATE      DATE;

  BEGIN

	   IF P_FROM_DATE IS NULL OR P_FROM_DATE = '' THEN

		  V_FROM_DATE := SYSDATE;

	   ELSE

		  V_FROM_DATE := TO_DATE(P_FROM_DATE, 'YYYYMMDD');

	   END IF;

	   IF P_TO_DATE IS NULL OR P_TO_DATE = '' THEN

		  V_TO_DATE := V_FROM_DATE;

	   ELSE

		  V_TO_DATE  := TO_DATE(P_TO_DATE, 'YYYYMMDD');

	   END IF;

	   --[변경] 2011.01.03.김동근 이전 년식을 -1년 으로만 해서는 빠지는 항목이 존재함 -2년으로 변경함
       --[변경] 2013.01.07.임용석 NF의 경우 09이후 변경없어 계속 사용으로 빠짐 -36까지에서 -48(개월)로 변경함.
	   P_FROM_MDL_MDY := TO_CHAR(ADD_MONTHS(V_FROM_DATE, -48), 'YY');
	   P_TO_MDL_MDY   := TO_CHAR(ADD_MONTHS(V_TO_DATE, 24), 'YY');

  END SP_GET_VALID_MDL_MDY4;
/**********************************************************/

/**********************************************************/
  -- 사용자 권한에 소속된 회사 리스트 조회
   PROCEDURE SP_GET_EXPD_CO_INFO(P_FROM_YMD 	VARCHAR2,
   			 					 P_TO_YMD		VARCHAR2,
                                 P_MENU_ID 	    VARCHAR2,
							     P_USER_EENO    VARCHAR2,
						         P_USF_CD	    VARCHAR2,  -- A : 전체, D: 내수만, E: 수출만 조회, T : 권한구분없이 데이터 조회
							     RS OUT REFCUR)
   IS

	 V_FROM_MDL_MDY VARCHAR(2);
	 V_TO_MDL_MDY   VARCHAR(2);

   BEGIN

	   SP_GET_VALID_MDL_MDY4(P_FROM_YMD, P_TO_YMD, V_FROM_MDL_MDY, V_TO_MDL_MDY);

  	   IF P_USF_CD = 'A' THEN

		   --내수/수출 구분없이 전체 항목에서 조회하는 경우

		   OPEN RS FOR
		   		SELECT A.DL_EXPD_CO_CD,
			           B.DL_EXPD_PRVS_NM AS DL_EXPD_CO_NM
		        FROM (SELECT B.DL_EXPD_CO_CD
                      FROM (SELECT QLTY_VEHL_CD
                            FROM TB_AUTH_VEHL_MGMT
                            WHERE MENU_ID = FU_RPAD(P_MENU_ID, 10)
                            AND USER_EENO = FU_RPAD(P_USER_EENO, 7)
                            GROUP BY QLTY_VEHL_CD
                           ) A,
                           TB_VEHL_MGMT B
                      WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
                      AND B.MDL_MDY_CD BETWEEN V_FROM_MDL_MDY AND V_TO_MDL_MDY
					  AND B.USE_YN = 'Y'
                      GROUP BY B.DL_EXPD_CO_CD
			         ) A,
				     TB_CODE_MGMT B
		        WHERE A.DL_EXPD_CO_CD = B.DL_EXPD_PRVS_CD
		        AND B.DL_EXPD_G_CD = '0003'
		        ORDER BY B.SORT_SN;

	   ELSIF P_USF_CD = 'M' THEN

		  --내수/수출 구분없이 전체 항목에서 조회하는 경우(사용하지 않는 내역도 표시되어야 하는 경우)

		  OPEN RS FOR
		   		SELECT A.DL_EXPD_CO_CD,
			           B.DL_EXPD_PRVS_NM AS DL_EXPD_CO_NM
		        FROM (SELECT B.DL_EXPD_CO_CD
                      FROM (SELECT QLTY_VEHL_CD
                            FROM TB_AUTH_VEHL_MGMT
                            WHERE MENU_ID = FU_RPAD(P_MENU_ID, 10)
                            AND USER_EENO = FU_RPAD(P_USER_EENO, 7)
                            GROUP BY QLTY_VEHL_CD
                           ) A,
                           TB_VEHL_MGMT B
                      WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
                      AND B.MDL_MDY_CD BETWEEN V_FROM_MDL_MDY AND V_TO_MDL_MDY
                      GROUP BY B.DL_EXPD_CO_CD
			         ) A,
				     TB_CODE_MGMT B
		        WHERE A.DL_EXPD_CO_CD = B.DL_EXPD_PRVS_CD
		        AND B.DL_EXPD_G_CD = '0003'
		        ORDER BY B.SORT_SN;

	   ELSIF P_USF_CD = 'T' THEN

		   --권한구분없이 데이터 조회하는 경우

		   OPEN RS FOR
		   		SELECT DL_EXPD_PRVS_CD AS DL_EXPD_CO_CD,
					   DL_EXPD_PRVS_NM AS DL_EXPD_CO_NM
				FROM TB_CODE_MGMT
				WHERE DL_EXPD_G_CD = '0003'
				ORDER BY SORT_SN;

	   ELSE
	   	   --내수/수출 구분하여 조회하는 경우

  	       OPEN RS FOR
  		     	SELECT A.DL_EXPD_CO_CD,
  		               B.DL_EXPD_PRVS_NM AS DL_EXPD_CO_NM
  	            FROM (SELECT B.DL_EXPD_CO_CD
                      FROM (SELECT QLTY_VEHL_CD
                            FROM TB_AUTH_VEHL_MGMT
                            WHERE MENU_ID = FU_RPAD(P_MENU_ID, 10)
                            AND USER_EENO = FU_RPAD(P_USER_EENO, 7)
                            GROUP BY QLTY_VEHL_CD
                           ) A,
                           TB_VEHL_MGMT B,
  						   TB_LANG_MGMT C
                      WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
					  AND A.QLTY_VEHL_CD = C.QLTY_VEHL_CD
				      AND B.MDL_MDY_CD = C.MDL_MDY_CD
                      AND B.MDL_MDY_CD BETWEEN V_FROM_MDL_MDY AND V_TO_MDL_MDY
					  AND B.USE_YN = 'Y'
					  AND C.USE_YN = 'Y'
  				      AND C.LANG_CD = DECODE(P_USF_CD, 'D', 'KO', C.LANG_CD)
  				      AND C.LANG_CD <> DECODE(P_USF_CD, 'E', 'KO', 'NULL')
                      GROUP BY B.DL_EXPD_CO_CD
  		             ) A,
  			         TB_CODE_MGMT B
  	            WHERE A.DL_EXPD_CO_CD = B.DL_EXPD_PRVS_CD
  	            AND B.DL_EXPD_G_CD = '0003'
  	            ORDER BY B.SORT_SN;

	   END IF;

   END SP_GET_EXPD_CO_INFO;
/**********************************************************/

/**********************************************************/
   -- 사용자 권한에 소속된 승상구분 리스트 조회
   PROCEDURE SP_GET_PAC_SCN_INFO(P_FROM_YMD 	VARCHAR2,
   			 					 P_TO_YMD		VARCHAR2,
                                 P_MENU_ID 	    VARCHAR2,
							     P_USER_EENO 	VARCHAR2,
								 P_EXPD_CO_CD   VARCHAR2,
								 P_USF_CD		VARCHAR2,  -- A : 전체, D: 내수만, E: 수출만 조회, T : 권한구분없이 데이터 조회
							     RS OUT REFCUR)
   IS

	 V_FROM_MDL_MDY VARCHAR(2);
	 V_TO_MDL_MDY   VARCHAR(2);

   BEGIN

		SP_GET_VALID_MDL_MDY4(P_FROM_YMD, P_TO_YMD, V_FROM_MDL_MDY, V_TO_MDL_MDY);

		IF P_USF_CD = 'A' THEN

		   --내수/수출 구분없이 전체 항목에서 조회하는 경우

		   OPEN RS FOR
		   		SELECT A.DL_EXPD_PAC_SCN_CD,
			           B.DL_EXPD_PRVS_NM AS DL_EXPD_PAC_SCN_NM
			    FROM (SELECT B.DL_EXPD_PAC_SCN_CD
                      FROM (SELECT QLTY_VEHL_CD
                            FROM TB_AUTH_VEHL_MGMT
                            WHERE MENU_ID = FU_RPAD(P_MENU_ID, 10)
                            AND USER_EENO = FU_RPAD(P_USER_EENO, 7)
                            GROUP BY QLTY_VEHL_CD
                           ) A,
                           TB_VEHL_MGMT B
                      WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
                      AND B.MDL_MDY_CD BETWEEN V_FROM_MDL_MDY AND V_TO_MDL_MDY
					  AND B.USE_YN = 'Y'
					  AND B.DL_EXPD_CO_CD = DECODE(P_EXPD_CO_CD, 'ALL', B.DL_EXPD_CO_CD, P_EXPD_CO_CD)
                      GROUP BY B.DL_EXPD_PAC_SCN_CD
			         ) A,
				     TB_CODE_MGMT B
		        WHERE A.DL_EXPD_PAC_SCN_CD = B.DL_EXPD_PRVS_CD
		        AND B.DL_EXPD_G_CD = '0004'
			    ORDER BY B.SORT_SN;

	  ELSIF P_USF_CD = 'M' THEN

		   --내수/수출 구분없이 전체 항목에서 조회하는 경우(사용하지 않는 내역도 표시되어야 하는 경우)

		   OPEN RS FOR
		   		SELECT A.DL_EXPD_PAC_SCN_CD,
			           B.DL_EXPD_PRVS_NM AS DL_EXPD_PAC_SCN_NM
			    FROM (SELECT B.DL_EXPD_PAC_SCN_CD
                      FROM (SELECT QLTY_VEHL_CD
                            FROM TB_AUTH_VEHL_MGMT
                            WHERE MENU_ID = FU_RPAD(P_MENU_ID, 10)
                            AND USER_EENO = FU_RPAD(P_USER_EENO, 7)
                            GROUP BY QLTY_VEHL_CD
                           ) A,
                           TB_VEHL_MGMT B
                      WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
                      AND B.MDL_MDY_CD BETWEEN V_FROM_MDL_MDY AND V_TO_MDL_MDY
					  AND B.DL_EXPD_CO_CD = DECODE(P_EXPD_CO_CD, 'ALL', B.DL_EXPD_CO_CD, P_EXPD_CO_CD)
                      GROUP BY B.DL_EXPD_PAC_SCN_CD
			         ) A,
				     TB_CODE_MGMT B
		        WHERE A.DL_EXPD_PAC_SCN_CD = B.DL_EXPD_PRVS_CD
		        AND B.DL_EXPD_G_CD = '0004'
			    ORDER BY B.SORT_SN;

	  ELSIF P_USF_CD = 'T' THEN

		   --권한구분없이 데이터 조회하는 경우

		   OPEN RS FOR
		   		SELECT A.DL_EXPD_PAC_SCN_CD,
				       B.DL_EXPD_PRVS_NM AS DL_EXPD_PAC_SCN_NM
				FROM (SELECT DL_EXPD_PAC_SCN_CD
				      FROM TB_VEHL_MGMT
                      WHERE MDL_MDY_CD BETWEEN V_FROM_MDL_MDY AND V_TO_MDL_MDY
					  AND DL_EXPD_CO_CD = DECODE(P_EXPD_CO_CD, 'ALL', DL_EXPD_CO_CD, P_EXPD_CO_CD)
					  AND USE_YN = 'Y'
                      GROUP BY DL_EXPD_PAC_SCN_CD
					 ) A,
				     TB_CODE_MGMT B
				WHERE A.DL_EXPD_PAC_SCN_CD = B.DL_EXPD_PRVS_CD
				AND B.DL_EXPD_G_CD = '0004'
				ORDER BY B.SORT_SN;

	   ELSE
	   	   --내수/수출 구분하여 조회하는 경우

		    OPEN RS FOR
		   		 SELECT A.DL_EXPD_PAC_SCN_CD,
			            B.DL_EXPD_PRVS_NM AS DL_EXPD_PAC_SCN_NM
			     FROM (SELECT B.DL_EXPD_PAC_SCN_CD
                       FROM (SELECT QLTY_VEHL_CD
                             FROM TB_AUTH_VEHL_MGMT
                             WHERE MENU_ID = FU_RPAD(P_MENU_ID, 10)
                             AND USER_EENO = FU_RPAD(P_USER_EENO, 7)
                             GROUP BY QLTY_VEHL_CD
                            ) A,
                            TB_VEHL_MGMT B,
					        TB_LANG_MGMT C
                       WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
				       AND A.QLTY_VEHL_CD = C.QLTY_VEHL_CD
				       AND B.MDL_MDY_CD = C.MDL_MDY_CD
                       AND B.MDL_MDY_CD BETWEEN V_FROM_MDL_MDY AND V_TO_MDL_MDY
					   AND B.DL_EXPD_CO_CD = DECODE(P_EXPD_CO_CD, 'ALL', B.DL_EXPD_CO_CD, P_EXPD_CO_CD)
					   AND B.USE_YN = 'Y'
					   AND C.USE_YN = 'Y'
				       AND C.LANG_CD = DECODE(P_USF_CD, 'D', 'KO', C.LANG_CD)
					   AND C.LANG_CD <> DECODE(P_USF_CD, 'E', 'KO', 'NULL')
                       GROUP BY B.DL_EXPD_PAC_SCN_CD
			          ) A,
				      TB_CODE_MGMT B
		         WHERE A.DL_EXPD_PAC_SCN_CD = B.DL_EXPD_PRVS_CD
		         AND B.DL_EXPD_G_CD = '0004'
			     ORDER BY B.SORT_SN;

	   END IF;

   END SP_GET_PAC_SCN_INFO;
/**********************************************************/

/**********************************************************/
   -- 사용자권한에 소속된 PDI 리스트 조회
   PROCEDURE SP_GET_PDI_INFO(P_FROM_YMD 	VARCHAR2,
   			 				 P_TO_YMD		VARCHAR2,
                             P_MENU_ID 	    VARCHAR2,
							 P_USER_EENO 	VARCHAR2,
							 P_EXPD_CO_CD   VARCHAR2,
						     P_PAC_SCN_CD   VARCHAR2,
						     P_USF_CD		VARCHAR2,  -- A : 전체, D: 내수만, E: 수출만 조회, T : 권한구분없이 데이터 조회
							 RS OUT REFCUR)
   IS

	 V_FROM_MDL_MDY VARCHAR(2);
	 V_TO_MDL_MDY   VARCHAR(2);

   BEGIN

		SP_GET_VALID_MDL_MDY4(P_FROM_YMD, P_TO_YMD, V_FROM_MDL_MDY, V_TO_MDL_MDY);

		IF P_USF_CD = 'A' THEN

		   --내수/수출 구분없이 전체 항목에서 조회하는 경우

		   OPEN RS FOR
		   		SELECT A.DL_EXPD_PDI_CD,
			           B.DL_EXPD_PRVS_NM AS DL_EXPD_PDI_NM
			    FROM (SELECT B.DL_EXPD_PDI_CD
                      FROM (SELECT QLTY_VEHL_CD
                            FROM TB_AUTH_VEHL_MGMT
                            WHERE MENU_ID = FU_RPAD(P_MENU_ID, 10)
                            AND USER_EENO = FU_RPAD(P_USER_EENO, 7)
                            GROUP BY QLTY_VEHL_CD
                           ) A,
                           TB_VEHL_MGMT B
                      WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
                      AND B.MDL_MDY_CD BETWEEN V_FROM_MDL_MDY AND V_TO_MDL_MDY
					  AND B.DL_EXPD_CO_CD = DECODE(P_EXPD_CO_CD, 'ALL', B.DL_EXPD_CO_CD, P_EXPD_CO_CD)
					  AND B.DL_EXPD_PAC_SCN_CD = DECODE(P_PAC_SCN_CD, 'ALL', B.DL_EXPD_PAC_SCN_CD, P_PAC_SCN_CD)
					  AND B.USE_YN = 'Y'
                      GROUP BY B.DL_EXPD_PDI_CD
			         ) A,
				     TB_CODE_MGMT B
		        WHERE A.DL_EXPD_PDI_CD = B.DL_EXPD_PRVS_CD
		        AND B.DL_EXPD_G_CD = '0005'
			    ORDER BY B.SORT_SN;

	   ELSIF P_USF_CD = 'M' THEN

		  --내수/수출 구분없이 전체 항목에서 조회하는 경우(사용하지 않는 내역도 표시되어야 하는 경우)

		   OPEN RS FOR
		   		SELECT A.DL_EXPD_PDI_CD,
			           B.DL_EXPD_PRVS_NM AS DL_EXPD_PDI_NM
			    FROM (SELECT B.DL_EXPD_PDI_CD
                      FROM (SELECT QLTY_VEHL_CD
                            FROM TB_AUTH_VEHL_MGMT
                            WHERE MENU_ID = FU_RPAD(P_MENU_ID, 10)
                            AND USER_EENO = FU_RPAD(P_USER_EENO, 7)
                            GROUP BY QLTY_VEHL_CD
                           ) A,
                           TB_VEHL_MGMT B
                      WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
                      AND B.MDL_MDY_CD BETWEEN V_FROM_MDL_MDY AND V_TO_MDL_MDY
					  AND B.DL_EXPD_CO_CD = DECODE(P_EXPD_CO_CD, 'ALL', B.DL_EXPD_CO_CD, P_EXPD_CO_CD)
					  AND B.DL_EXPD_PAC_SCN_CD = DECODE(P_PAC_SCN_CD, 'ALL', B.DL_EXPD_PAC_SCN_CD, P_PAC_SCN_CD)
                      GROUP BY B.DL_EXPD_PDI_CD
			         ) A,
				     TB_CODE_MGMT B
		        WHERE A.DL_EXPD_PDI_CD = B.DL_EXPD_PRVS_CD
		        AND B.DL_EXPD_G_CD = '0005'
			    ORDER BY B.SORT_SN;

	   ELSIF P_USF_CD = 'T' THEN

		   --권한구분없이 데이터 조회하는 경우

		   OPEN RS FOR
		   		SELECT A.DL_EXPD_PDI_CD,
			           B.DL_EXPD_PRVS_NM AS DL_EXPD_PDI_NM
				FROM (SELECT DL_EXPD_PDI_CD
				      FROM TB_VEHL_MGMT
                      WHERE MDL_MDY_CD BETWEEN V_FROM_MDL_MDY AND V_TO_MDL_MDY
					  AND DL_EXPD_CO_CD = DECODE(P_EXPD_CO_CD, 'ALL', DL_EXPD_CO_CD, P_EXPD_CO_CD)
					  AND DL_EXPD_PAC_SCN_CD = DECODE(P_PAC_SCN_CD, 'ALL', DL_EXPD_PAC_SCN_CD, P_PAC_SCN_CD)
					  AND USE_YN = 'Y'
                      GROUP BY DL_EXPD_PDI_CD
					 ) A,
				     TB_CODE_MGMT B
				WHERE A.DL_EXPD_PDI_CD = B.DL_EXPD_PRVS_CD
				AND B.DL_EXPD_G_CD = '0005'
				ORDER BY B.SORT_SN;

	   ELSE
	   	   --내수/수출 구분하여 조회하는 경우

		    OPEN RS FOR
		   		 SELECT A.DL_EXPD_PDI_CD,
			            B.DL_EXPD_PRVS_NM AS DL_EXPD_PDI_NM
			     FROM (SELECT B.DL_EXPD_PDI_CD
                       FROM (SELECT QLTY_VEHL_CD
                             FROM TB_AUTH_VEHL_MGMT
                             WHERE MENU_ID = FU_RPAD(P_MENU_ID, 10)
                             AND USER_EENO = FU_RPAD(P_USER_EENO, 7)
                             GROUP BY QLTY_VEHL_CD
                            ) A,
                            TB_VEHL_MGMT B,
					        TB_LANG_MGMT C
                       WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
				       AND A.QLTY_VEHL_CD = C.QLTY_VEHL_CD
				       AND B.MDL_MDY_CD = C.MDL_MDY_CD
                       AND B.MDL_MDY_CD BETWEEN V_FROM_MDL_MDY AND V_TO_MDL_MDY
					   AND B.DL_EXPD_CO_CD = DECODE(P_EXPD_CO_CD, 'ALL', B.DL_EXPD_CO_CD, P_EXPD_CO_CD)
					   AND B.DL_EXPD_PAC_SCN_CD = DECODE(P_PAC_SCN_CD, 'ALL', B.DL_EXPD_PAC_SCN_CD, P_PAC_SCN_CD)
					   AND B.USE_YN = 'Y'
					   AND C.USE_YN = 'Y'
				       AND C.LANG_CD = DECODE(P_USF_CD, 'D', 'KO', C.LANG_CD)
					   AND C.LANG_CD <> DECODE(P_USF_CD, 'E', 'KO', 'NULL')
                       GROUP BY B.DL_EXPD_PDI_CD
			          ) A,
				      TB_CODE_MGMT B
		        WHERE A.DL_EXPD_PDI_CD = B.DL_EXPD_PRVS_CD
		        AND B.DL_EXPD_G_CD = '0005'
		        ORDER BY B.SORT_SN;

	   END IF;

   END SP_GET_PDI_INFO;
/**********************************************************/

/**********************************************************/
   -- 사용자권한에 소속된 차종 리스트 조회
   PROCEDURE SP_GET_VEHL_INFO(P_FROM_YMD 	 VARCHAR2,
   			 				  P_TO_YMD		 VARCHAR2,
                              P_MENU_ID 	 VARCHAR2,
							  P_USER_EENO 	 VARCHAR2,
							  P_EXPD_CO_CD   VARCHAR2,
						      P_PAC_SCN_CD   VARCHAR2,
							  P_PDI_CD		 VARCHAR2,
							  P_USF_CD		 VARCHAR2,  -- A : 전체, D: 내수만, E: 수출만 조회, T : 권한구분없이 데이터 조회
							  RS OUT REFCUR)
   IS

	 V_FROM_MDL_MDY VARCHAR(2);
	 V_TO_MDL_MDY   VARCHAR(2);

   BEGIN

		SP_GET_VALID_MDL_MDY4(P_FROM_YMD, P_TO_YMD, V_FROM_MDL_MDY, V_TO_MDL_MDY);

		IF P_USF_CD = 'A' THEN

		   --내수/수출 구분없이 전체 항목에서 조회하는 경우

		   OPEN RS FOR
		        SELECT A.QLTY_VEHL_CD,
					   A.QLTY_VEHL_NM,
					   A.CL_SCN_CD,
					   A.EXPD_CO_CD,
					   B.DL_EXPD_PRVS_NM AS EXPD_CO_NM,
					   A.EXPD_PAC_SCN_CD,
					   C.DL_EXPD_PRVS_NM AS EXPD_PAC_SCN_NM,
					   A.EXPD_PDI_CD,
					   D.DL_EXPD_PRVS_NM AS EXPD_PDI_NM
				FROM (SELECT B.QLTY_VEHL_CD,
				             B.QLTY_VEHL_CD || '(' || MAX(B.QLTY_VEHL_NM) || ')' AS QLTY_VEHL_NM,
				             MAX(A.CL_SCN_CD) AS CL_SCN_CD,
							 MAX(DL_EXPD_CO_CD) AS EXPD_CO_CD,
							 MAX(DL_EXPD_PAC_SCN_CD) AS EXPD_PAC_SCN_CD,
							 MAX(DL_EXPD_PDI_CD) AS EXPD_PDI_CD
                      FROM (SELECT QLTY_VEHL_CD,
				                   MAX(CL_SCN_CD) AS CL_SCN_CD
                            FROM TB_AUTH_VEHL_MGMT
                            WHERE MENU_ID = FU_RPAD(P_MENU_ID, 10)
                            AND USER_EENO = FU_RPAD(P_USER_EENO, 7)
                            GROUP BY QLTY_VEHL_CD
                           ) A,
                           TB_VEHL_MGMT B
                      WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
                      AND B.MDL_MDY_CD BETWEEN V_FROM_MDL_MDY AND V_TO_MDL_MDY
					  AND B.DL_EXPD_CO_CD = DECODE(P_EXPD_CO_CD, 'ALL', B.DL_EXPD_CO_CD, P_EXPD_CO_CD)
					  AND B.DL_EXPD_PAC_SCN_CD = DECODE(P_PAC_SCN_CD, 'ALL', B.DL_EXPD_PAC_SCN_CD, P_PAC_SCN_CD)
		              AND B.DL_EXPD_PDI_CD = DECODE(P_PDI_CD, 'ALL', B.DL_EXPD_PDI_CD, P_PDI_CD)
					  AND B.USE_YN = 'Y'
                      GROUP BY B.QLTY_VEHL_CD
		             ) A,
					 TB_CODE_MGMT B,
					 TB_CODE_MGMT C,
					 TB_CODE_MGMT D
			    WHERE A.EXPD_CO_CD = B.DL_EXPD_PRVS_CD
				AND B.DL_EXPD_G_CD = '0003'
				AND A.EXPD_PAC_SCN_CD = C.DL_EXPD_PRVS_CD
				AND C.DL_EXPD_G_CD = '0004'
				AND A.EXPD_PDI_CD = D.DL_EXPD_PRVS_CD
				AND D.DL_EXPD_G_CD = '0005'
				ORDER BY A.QLTY_VEHL_CD;

	   ELSIF P_USF_CD = 'M' THEN

		   --내수/수출 구분없이 전체 항목에서 조회하는 경우(사용하지 않는 내역도 표시되어야 하는 경우)

		   OPEN RS FOR
		        SELECT A.QLTY_VEHL_CD,
					   A.QLTY_VEHL_NM,
					   A.CL_SCN_CD,
					   A.EXPD_CO_CD,
					   B.DL_EXPD_PRVS_NM AS EXPD_CO_NM,
					   A.EXPD_PAC_SCN_CD,
					   C.DL_EXPD_PRVS_NM AS EXPD_PAC_SCN_NM,
					   A.EXPD_PDI_CD,
					   D.DL_EXPD_PRVS_NM AS EXPD_PDI_NM
				FROM (SELECT B.QLTY_VEHL_CD,
				             B.QLTY_VEHL_CD || '(' || MAX(B.QLTY_VEHL_NM) || ')' AS QLTY_VEHL_NM,
				             MAX(A.CL_SCN_CD) AS CL_SCN_CD,
							 MAX(DL_EXPD_CO_CD) AS EXPD_CO_CD,
							 MAX(DL_EXPD_PAC_SCN_CD) AS EXPD_PAC_SCN_CD,
							 MAX(DL_EXPD_PDI_CD) AS EXPD_PDI_CD
                      FROM (SELECT QLTY_VEHL_CD,
				                   MAX(CL_SCN_CD) AS CL_SCN_CD
                            FROM TB_AUTH_VEHL_MGMT
                            WHERE MENU_ID = FU_RPAD(P_MENU_ID, 10)
                            AND USER_EENO = FU_RPAD(P_USER_EENO, 7)
                            GROUP BY QLTY_VEHL_CD
                           ) A,
                           TB_VEHL_MGMT B
                      WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
                      AND B.MDL_MDY_CD BETWEEN V_FROM_MDL_MDY AND V_TO_MDL_MDY
					  AND B.DL_EXPD_CO_CD = DECODE(P_EXPD_CO_CD, 'ALL', B.DL_EXPD_CO_CD, P_EXPD_CO_CD)
					  AND B.DL_EXPD_PAC_SCN_CD = DECODE(P_PAC_SCN_CD, 'ALL', B.DL_EXPD_PAC_SCN_CD, P_PAC_SCN_CD)
		              AND B.DL_EXPD_PDI_CD = DECODE(P_PDI_CD, 'ALL', B.DL_EXPD_PDI_CD, P_PDI_CD)
                      GROUP BY B.QLTY_VEHL_CD
		             ) A,
					 TB_CODE_MGMT B,
					 TB_CODE_MGMT C,
					 TB_CODE_MGMT D
			    WHERE A.EXPD_CO_CD = B.DL_EXPD_PRVS_CD
				AND B.DL_EXPD_G_CD = '0003'
				AND A.EXPD_PAC_SCN_CD = C.DL_EXPD_PRVS_CD
				AND C.DL_EXPD_G_CD = '0004'
				AND A.EXPD_PDI_CD = D.DL_EXPD_PRVS_CD
				AND D.DL_EXPD_G_CD = '0005'
				ORDER BY A.QLTY_VEHL_CD;

	   ELSIF P_USF_CD = 'T' THEN

		   --권한구분없이 데이터 조회하는 경우

		   OPEN RS FOR
		   		SELECT A.QLTY_VEHL_CD,
					   A.QLTY_VEHL_NM,
					   'U' AS CL_SCN_CD,
					   A.EXPD_CO_CD,
					   B.DL_EXPD_PRVS_NM AS EXPD_CO_NM,
					   A.EXPD_PAC_SCN_CD,
					   C.DL_EXPD_PRVS_NM AS EXPD_PAC_SCN_NM,
					   A.EXPD_PDI_CD,
					   D.DL_EXPD_PRVS_NM AS EXPD_PDI_NM
				FROM (SELECT QLTY_VEHL_CD,
				             QLTY_VEHL_CD || '(' || MAX(QLTY_VEHL_NM) || ')' AS QLTY_VEHL_NM,
							 MAX(DL_EXPD_CO_CD) AS EXPD_CO_CD,
							 MAX(DL_EXPD_PAC_SCN_CD) AS EXPD_PAC_SCN_CD,
							 MAX(DL_EXPD_PDI_CD) AS EXPD_PDI_CD
				      FROM TB_VEHL_MGMT
                      WHERE MDL_MDY_CD BETWEEN V_FROM_MDL_MDY AND V_TO_MDL_MDY
					  AND DL_EXPD_CO_CD = DECODE(P_EXPD_CO_CD, 'ALL', DL_EXPD_CO_CD, P_EXPD_CO_CD)
					  AND DL_EXPD_PAC_SCN_CD = DECODE(P_PAC_SCN_CD, 'ALL', DL_EXPD_PAC_SCN_CD, P_PAC_SCN_CD)
					  AND DL_EXPD_PDI_CD = DECODE(P_PDI_CD, 'ALL', DL_EXPD_PDI_CD, P_PDI_CD)
					  AND USE_YN = 'Y'
                      GROUP BY QLTY_VEHL_CD
					 ) A,
				     TB_CODE_MGMT B,
					 TB_CODE_MGMT C,
					 TB_CODE_MGMT D
			    WHERE A.EXPD_CO_CD = B.DL_EXPD_PRVS_CD
				AND B.DL_EXPD_G_CD = '0003'
				AND A.EXPD_PAC_SCN_CD = C.DL_EXPD_PRVS_CD
				AND C.DL_EXPD_G_CD = '0004'
				AND A.EXPD_PDI_CD = D.DL_EXPD_PRVS_CD
				AND D.DL_EXPD_G_CD = '0005'
				ORDER BY A.QLTY_VEHL_CD;

	   ELSE
	   	   --내수/수출 구분하여 조회하는 경우

		    OPEN RS FOR
		   		 SELECT A.QLTY_VEHL_CD,
					    A.QLTY_VEHL_NM,
					    A.CL_SCN_CD,
					    A.EXPD_CO_CD,
					    B.DL_EXPD_PRVS_NM AS EXPD_CO_NM,
					    A.EXPD_PAC_SCN_CD,
					    C.DL_EXPD_PRVS_NM AS EXPD_PAC_SCN_NM,
					    A.EXPD_PDI_CD,
					    D.DL_EXPD_PRVS_NM AS EXPD_PDI_NM
				 FROM (SELECT B.QLTY_VEHL_CD,
				 	  		  B.QLTY_VEHL_CD || '(' || MAX(B.QLTY_VEHL_NM) || ')' AS QLTY_VEHL_NM,
				              MAX(A.CL_SCN_CD) AS CL_SCN_CD,
							  MAX(DL_EXPD_CO_CD) AS EXPD_CO_CD,
							  MAX(DL_EXPD_PAC_SCN_CD) AS EXPD_PAC_SCN_CD,
							  MAX(DL_EXPD_PDI_CD) AS EXPD_PDI_CD
                       FROM (SELECT QLTY_VEHL_CD,
				                    MAX(CL_SCN_CD) AS CL_SCN_CD
                             FROM TB_AUTH_VEHL_MGMT
                             WHERE MENU_ID = FU_RPAD(P_MENU_ID, 10)
                             AND USER_EENO = FU_RPAD(P_USER_EENO, 7)
                             GROUP BY QLTY_VEHL_CD
                            ) A,
                            TB_VEHL_MGMT B,
							TB_LANG_MGMT C
                       WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
					   AND A.QLTY_VEHL_CD = C.QLTY_VEHL_CD
				       AND B.MDL_MDY_CD = C.MDL_MDY_CD
                       AND B.MDL_MDY_CD BETWEEN V_FROM_MDL_MDY AND V_TO_MDL_MDY
					   AND B.DL_EXPD_CO_CD = DECODE(P_EXPD_CO_CD, 'ALL', B.DL_EXPD_CO_CD, P_EXPD_CO_CD)
					   AND B.DL_EXPD_PAC_SCN_CD = DECODE(P_PAC_SCN_CD, 'ALL', B.DL_EXPD_PAC_SCN_CD, P_PAC_SCN_CD)
		               AND B.DL_EXPD_PDI_CD = DECODE(P_PDI_CD, 'ALL', B.DL_EXPD_PDI_CD, P_PDI_CD)
					   AND B.USE_YN = 'Y'
					   AND C.USE_YN = 'Y'
					   AND C.LANG_CD = DECODE(P_USF_CD, 'D', 'KO', C.LANG_CD)
					   AND C.LANG_CD <> DECODE(P_USF_CD, 'E', 'KO', 'NULL')
                       GROUP BY B.QLTY_VEHL_CD
		              ) A,
					  TB_CODE_MGMT B,
					  TB_CODE_MGMT C,
					  TB_CODE_MGMT D
			     WHERE A.EXPD_CO_CD = B.DL_EXPD_PRVS_CD
				 AND B.DL_EXPD_G_CD = '0003'
				 AND A.EXPD_PAC_SCN_CD = C.DL_EXPD_PRVS_CD
				 AND C.DL_EXPD_G_CD = '0004'
				 AND A.EXPD_PDI_CD = D.DL_EXPD_PRVS_CD
				 AND D.DL_EXPD_G_CD = '0005'
				 ORDER BY A.QLTY_VEHL_CD;

	   END IF;

   END SP_GET_VEHL_INFO;
/**********************************************************/

/**********************************************************/
   -- 사용자권한에 소속된 연식 리스트 조회
   PROCEDURE SP_GET_MDL_MDY_INFO(P_FROM_YMD 	VARCHAR2,
   			 					 P_TO_YMD		VARCHAR2,
                                 P_MENU_ID 	    VARCHAR2,
							     P_USER_EENO 	VARCHAR2,
								 P_EXPD_CO_CD   VARCHAR2,
						         P_PAC_SCN_CD   VARCHAR2,
							     P_PDI_CD		VARCHAR2,
							     P_VEHL_CD		VARCHAR2,
							     P_USF_CD		VARCHAR2,  -- A : 전체, D: 내수만, E: 수출만 조회, T : 권한구분없이 데이터 조회
							     RS OUT REFCUR)
   IS

	 V_FROM_MDL_MDY VARCHAR(2);
	 V_TO_MDL_MDY   VARCHAR(2);

   BEGIN

		SP_GET_VALID_MDL_MDY4(P_FROM_YMD, P_TO_YMD, V_FROM_MDL_MDY, V_TO_MDL_MDY);

		IF P_USF_CD = 'A' THEN

		   --내수/수출 구분없이 전체 항목에서 조회하는 경우

		   OPEN RS FOR
		   		SELECT B.MDL_MDY_CD,
				       B.MDL_MDY_CD || 'MY' AS MDL_MDY_NM
                FROM (SELECT QLTY_VEHL_CD
                      FROM TB_AUTH_VEHL_MGMT
                      WHERE MENU_ID = FU_RPAD(P_MENU_ID, 10)
                      AND USER_EENO = FU_RPAD(P_USER_EENO, 7)
			          AND QLTY_VEHL_CD = DECODE(P_VEHL_CD, 'ALL', QLTY_VEHL_CD, P_VEHL_CD)
                      GROUP BY QLTY_VEHL_CD
                     ) A,
                     TB_VEHL_MGMT B
                WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
                AND B.MDL_MDY_CD BETWEEN V_FROM_MDL_MDY AND V_TO_MDL_MDY
				AND B.DL_EXPD_CO_CD = DECODE(P_EXPD_CO_CD, 'ALL', B.DL_EXPD_CO_CD, P_EXPD_CO_CD)
			    AND B.DL_EXPD_PAC_SCN_CD = DECODE(P_PAC_SCN_CD, 'ALL', B.DL_EXPD_PAC_SCN_CD, P_PAC_SCN_CD)
		        AND B.DL_EXPD_PDI_CD = DECODE(P_PDI_CD, 'ALL', B.DL_EXPD_PDI_CD, P_PDI_CD)
				AND B.USE_YN = 'Y'
                GROUP BY B.MDL_MDY_CD
			    ORDER BY B.MDL_MDY_CD;

	   ELSIF P_USF_CD = 'M' THEN

		   --내수/수출 구분없이 전체 항목에서 조회하는 경우(사용하지 않는 내역도 표시되어야 하는 경우)

		   OPEN RS FOR
		   		SELECT B.MDL_MDY_CD,
				       B.MDL_MDY_CD || 'MY' AS MDL_MDY_NM
                FROM (SELECT QLTY_VEHL_CD
                      FROM TB_AUTH_VEHL_MGMT
                      WHERE MENU_ID = FU_RPAD(P_MENU_ID, 10)
                      AND USER_EENO = FU_RPAD(P_USER_EENO, 7)
			          AND QLTY_VEHL_CD = DECODE(P_VEHL_CD, 'ALL', QLTY_VEHL_CD, P_VEHL_CD)
                      GROUP BY QLTY_VEHL_CD
                     ) A,
                     TB_VEHL_MGMT B
                WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
                AND B.MDL_MDY_CD BETWEEN V_FROM_MDL_MDY AND V_TO_MDL_MDY
				AND B.DL_EXPD_CO_CD = DECODE(P_EXPD_CO_CD, 'ALL', B.DL_EXPD_CO_CD, P_EXPD_CO_CD)
			    AND B.DL_EXPD_PAC_SCN_CD = DECODE(P_PAC_SCN_CD, 'ALL', B.DL_EXPD_PAC_SCN_CD, P_PAC_SCN_CD)
		        AND B.DL_EXPD_PDI_CD = DECODE(P_PDI_CD, 'ALL', B.DL_EXPD_PDI_CD, P_PDI_CD)
                GROUP BY B.MDL_MDY_CD
			    ORDER BY B.MDL_MDY_CD;

	   ELSIF P_USF_CD = 'T' THEN

		   --권한구분없이 데이터 조회하는 경우

		   OPEN RS FOR
		   		SELECT MDL_MDY_CD,
				       MDL_MDY_CD || 'MY' AS MDL_MDY_NM
				FROM TB_VEHL_MGMT
                WHERE MDL_MDY_CD BETWEEN V_FROM_MDL_MDY AND V_TO_MDL_MDY
				AND QLTY_VEHL_CD = DECODE(P_VEHL_CD, 'ALL', QLTY_VEHL_CD, P_VEHL_CD)
				AND DL_EXPD_CO_CD = DECODE(P_EXPD_CO_CD, 'ALL', DL_EXPD_CO_CD, P_EXPD_CO_CD)
				AND DL_EXPD_PAC_SCN_CD = DECODE(P_PAC_SCN_CD, 'ALL', DL_EXPD_PAC_SCN_CD, P_PAC_SCN_CD)
				AND DL_EXPD_PDI_CD = DECODE(P_PDI_CD, 'ALL', DL_EXPD_PDI_CD, P_PDI_CD)
				AND USE_YN = 'Y'
                GROUP BY MDL_MDY_CD
				ORDER BY MDL_MDY_CD;

	   ELSE
	   	   --내수/수출 구분하여 조회하는 경우

		    OPEN RS FOR
		   		 SELECT B.MDL_MDY_CD,
				        B.MDL_MDY_CD || 'MY' AS MDL_MDY_NM
                 FROM (SELECT QLTY_VEHL_CD
                       FROM TB_AUTH_VEHL_MGMT
                       WHERE MENU_ID = FU_RPAD(P_MENU_ID, 10)
                       AND USER_EENO = FU_RPAD(P_USER_EENO, 7)
				       AND QLTY_VEHL_CD = DECODE(P_VEHL_CD, 'ALL', QLTY_VEHL_CD, P_VEHL_CD)
                       GROUP BY QLTY_VEHL_CD
                      ) A,
                      TB_VEHL_MGMT B,
			          TB_LANG_MGMT C
		         WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
			     AND A.QLTY_VEHL_CD = C.QLTY_VEHL_CD
			     AND B.MDL_MDY_CD = C.MDL_MDY_CD
                 AND B.MDL_MDY_CD BETWEEN V_FROM_MDL_MDY AND V_TO_MDL_MDY
				 AND B.DL_EXPD_CO_CD = DECODE(P_EXPD_CO_CD, 'ALL', B.DL_EXPD_CO_CD, P_EXPD_CO_CD)
			     AND B.DL_EXPD_PAC_SCN_CD = DECODE(P_PAC_SCN_CD, 'ALL', B.DL_EXPD_PAC_SCN_CD, P_PAC_SCN_CD)
			     AND B.DL_EXPD_PDI_CD = DECODE(P_PDI_CD, 'ALL', B.DL_EXPD_PDI_CD, P_PDI_CD)
				 AND B.USE_YN = 'Y'
				 AND C.USE_YN = 'Y'
			     AND C.LANG_CD = DECODE(P_USF_CD, 'D', 'KO', C.LANG_CD)
				 AND C.LANG_CD <> DECODE(P_USF_CD, 'E', 'KO', 'NULL')
                 GROUP BY B.MDL_MDY_CD
		         ORDER BY B.MDL_MDY_CD;

	   END IF;

   END SP_GET_MDL_MDY_INFO;
/**********************************************************/

/**********************************************************/
   -- 사용자권한에 소속된 지역 리스트 조회
   /**
   PROCEDURE SP_GET_REGN_INFO(P_FROM_YMD 	 VARCHAR2,
   			 				  P_TO_YMD		 VARCHAR2,
                              P_MENU_ID 	 VARCHAR2,
				              P_USER_EENO 	 VARCHAR2,
							  P_EXPD_CO_CD   VARCHAR2,
						      P_PAC_SCN_CD   VARCHAR2,
				              P_PDI_CD		 VARCHAR2,
						      P_VEHL_CD	     VARCHAR2,
						      P_USF_CD		 VARCHAR2,  -- A : 전체, D: 내수만, E: 수출만 조회
				              RS OUT REFCUR)
   IS

	 V_FROM_MDL_MDY VARCHAR(2);
	 V_TO_MDL_MDY   VARCHAR(2);

   BEGIN

		SP_GET_VALID_MDL_MDY4(P_FROM_YMD, P_TO_YMD, V_FROM_MDL_MDY, V_TO_MDL_MDY);

		IF P_USF_CD = 'A' THEN

		   --내수/수출 구분없이 전체 항목에서 조회하는 경우

		   OPEN RS FOR
		   		SELECT A.DL_EXPD_REGN_CD,
			           B.DL_EXPD_PRVS_NM AS DL_EXPD_REGN_NM
			    FROM (SELECT C.DL_EXPD_REGN_CD
                      FROM (SELECT QLTY_VEHL_CD
                            FROM TB_AUTH_VEHL_MGMT
                            WHERE MENU_ID = FU_RPAD(P_MENU_ID, 10)
                            AND USER_EENO = FU_RPAD(P_USER_EENO, 7)
						    AND QLTY_VEHL_CD = DECODE(P_VEHL_CD, 'ALL', QLTY_VEHL_CD, P_VEHL_CD)
                            GROUP BY QLTY_VEHL_CD
                           ) A,
                           TB_VEHL_MGMT B,
					       TB_LANG_MGMT C
                      WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
				      AND A.QLTY_VEHL_CD = C.QLTY_VEHL_CD
				      AND B.MDL_MDY_CD = C.MDL_MDY_CD
                      AND B.MDL_MDY_CD BETWEEN V_FROM_MDL_MDY AND V_TO_MDL_MDY
					  AND B.DL_EXPD_CO_CD = DECODE(P_EXPD_CO_CD, 'ALL', B.DL_EXPD_CO_CD, P_EXPD_CO_CD)
			          AND B.DL_EXPD_PAC_SCN_CD = DECODE(P_PAC_SCN_CD, 'ALL', B.DL_EXPD_PAC_SCN_CD, P_PAC_SCN_CD)
				      AND B.DL_EXPD_PDI_CD = DECODE(P_PDI_CD, 'ALL', B.DL_EXPD_PDI_CD, P_PDI_CD)
				      GROUP BY C.DL_EXPD_REGN_CD
				     ) A,
				     TB_CODE_MGMT B
			   WHERE A.DL_EXPD_REGN_CD = B.DL_EXPD_PRVS_CD
		       AND B.DL_EXPD_G_CD = '0008'
			   ORDER BY B.SORT_SN;

	   ELSE
	   	   --내수/수출 구분하여 조회하는 경우

		    OPEN RS FOR
		   		 SELECT A.DL_EXPD_REGN_CD,
			            B.DL_EXPD_PRVS_NM AS DL_EXPD_REGN_NM
			     FROM (SELECT C.DL_EXPD_REGN_CD
                       FROM (SELECT QLTY_VEHL_CD
                             FROM TB_AUTH_VEHL_MGMT
                             WHERE MENU_ID = FU_RPAD(P_MENU_ID, 10)
                             AND USER_EENO = FU_RPAD(P_USER_EENO, 7)
						     AND QLTY_VEHL_CD = DECODE(P_VEHL_CD, 'ALL', QLTY_VEHL_CD, P_VEHL_CD)
                             GROUP BY QLTY_VEHL_CD
                            ) A,
                  	        TB_VEHL_MGMT B,
					        TB_LANG_MGMT C
                       WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
				       AND A.QLTY_VEHL_CD = C.QLTY_VEHL_CD
				       AND B.MDL_MDY_CD = C.MDL_MDY_CD
                       AND B.MDL_MDY_CD BETWEEN V_FROM_MDL_MDY AND V_TO_MDL_MDY
					   AND B.DL_EXPD_CO_CD = DECODE(P_EXPD_CO_CD, 'ALL', B.DL_EXPD_CO_CD, P_EXPD_CO_CD)
			           AND B.DL_EXPD_PAC_SCN_CD = DECODE(P_PAC_SCN_CD, 'ALL', B.DL_EXPD_PAC_SCN_CD, P_PAC_SCN_CD)
				       AND B.DL_EXPD_PDI_CD = DECODE(P_PDI_CD, 'ALL', B.DL_EXPD_PDI_CD, P_PDI_CD)
				       AND C.LANG_CD = DECODE(P_USF_CD, 'D', 'KO', C.LANG_CD)
					   AND C.LANG_CD <> DECODE(P_USF_CD, 'E', 'KO', 'NULL')
				       GROUP BY C.DL_EXPD_REGN_CD
				      ) A,
			          TB_CODE_MGMT B
			     WHERE A.DL_EXPD_REGN_CD = B.DL_EXPD_PRVS_CD
		         AND B.DL_EXPD_G_CD = '0008'
			     ORDER BY B.SORT_SN;

	   END IF;

   END SP_GET_REGN_INFO;
   **/
   PROCEDURE SP_GET_REGN_INFO(P_FROM_YMD 	 VARCHAR2,
   			 				  P_TO_YMD		 VARCHAR2,
                              P_MENU_ID 	 VARCHAR2,
				              P_USER_EENO 	 VARCHAR2,
							  P_EXPD_CO_CD   VARCHAR2,
						      P_PAC_SCN_CD   VARCHAR2,
				              P_PDI_CD		 VARCHAR2,
						      P_VEHL_CD	     VARCHAR2,
						      P_MDL_MDY_CD   VARCHAR2,
						      P_USF_CD		 VARCHAR2,  -- A : 전체, D: 내수만, E: 수출만 조회, T : 권한구분없이 데이터 조회
				              RS OUT REFCUR)
   IS

	 V_FROM_MDL_MDY VARCHAR(2);
	 V_TO_MDL_MDY   VARCHAR(2);

   BEGIN

		SP_GET_VALID_MDL_MDY4(P_FROM_YMD, P_TO_YMD, V_FROM_MDL_MDY, V_TO_MDL_MDY);

		IF P_USF_CD = 'A' THEN

		   --내수/수출 구분없이 전체 항목에서 조회하는 경우

		   OPEN RS FOR
		   		SELECT A.DL_EXPD_REGN_CD,
			           B.DL_EXPD_PRVS_NM AS DL_EXPD_REGN_NM
			    FROM (SELECT C.DL_EXPD_REGN_CD
                      FROM (SELECT QLTY_VEHL_CD
                            FROM TB_AUTH_VEHL_MGMT
                            WHERE MENU_ID = FU_RPAD(P_MENU_ID, 10)
                            AND USER_EENO = FU_RPAD(P_USER_EENO, 7)
						    AND QLTY_VEHL_CD = DECODE(P_VEHL_CD, 'ALL', QLTY_VEHL_CD, P_VEHL_CD)
                            GROUP BY QLTY_VEHL_CD
                           ) A,
                           TB_VEHL_MGMT B,
					       TB_LANG_MGMT C
                      WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
				      AND A.QLTY_VEHL_CD = C.QLTY_VEHL_CD
				      AND B.MDL_MDY_CD = C.MDL_MDY_CD
                      AND B.MDL_MDY_CD BETWEEN V_FROM_MDL_MDY AND V_TO_MDL_MDY
					  AND B.DL_EXPD_CO_CD = DECODE(P_EXPD_CO_CD, 'ALL', B.DL_EXPD_CO_CD, P_EXPD_CO_CD)
			          AND B.DL_EXPD_PAC_SCN_CD = DECODE(P_PAC_SCN_CD, 'ALL', B.DL_EXPD_PAC_SCN_CD, P_PAC_SCN_CD)
				      AND B.DL_EXPD_PDI_CD = DECODE(P_PDI_CD, 'ALL', B.DL_EXPD_PDI_CD, P_PDI_CD)
				      AND B.MDL_MDY_CD = DECODE(P_MDL_MDY_CD, '', B.MDL_MDY_CD, P_MDL_MDY_CD)
					  AND B.USE_YN = 'Y'
					  AND C.USE_YN = 'Y'
				      GROUP BY C.DL_EXPD_REGN_CD
				     ) A,
				     TB_CODE_MGMT B
			   WHERE A.DL_EXPD_REGN_CD = B.DL_EXPD_PRVS_CD
		       AND B.DL_EXPD_G_CD = '0008'
			   ORDER BY B.SORT_SN;

	   ELSIF P_USF_CD = 'M' THEN

		   --내수/수출 구분없이 전체 항목에서 조회하는 경우(사용하지 않는 내역도 표시되어야 하는 경우)

		   OPEN RS FOR
		   		SELECT A.DL_EXPD_REGN_CD,
			           B.DL_EXPD_PRVS_NM AS DL_EXPD_REGN_NM
			    FROM (SELECT C.DL_EXPD_REGN_CD
                      FROM (SELECT QLTY_VEHL_CD
                            FROM TB_AUTH_VEHL_MGMT
                            WHERE MENU_ID = FU_RPAD(P_MENU_ID, 10)
                            AND USER_EENO = FU_RPAD(P_USER_EENO, 7)
						    AND QLTY_VEHL_CD = DECODE(P_VEHL_CD, 'ALL', QLTY_VEHL_CD, P_VEHL_CD)
                            GROUP BY QLTY_VEHL_CD
                           ) A,
                           TB_VEHL_MGMT B,
					       TB_LANG_MGMT C
                      WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
				      AND A.QLTY_VEHL_CD = C.QLTY_VEHL_CD
				      AND B.MDL_MDY_CD = C.MDL_MDY_CD
                      AND B.MDL_MDY_CD BETWEEN V_FROM_MDL_MDY AND V_TO_MDL_MDY
					  AND B.DL_EXPD_CO_CD = DECODE(P_EXPD_CO_CD, 'ALL', B.DL_EXPD_CO_CD, P_EXPD_CO_CD)
			          AND B.DL_EXPD_PAC_SCN_CD = DECODE(P_PAC_SCN_CD, 'ALL', B.DL_EXPD_PAC_SCN_CD, P_PAC_SCN_CD)
				      AND B.DL_EXPD_PDI_CD = DECODE(P_PDI_CD, 'ALL', B.DL_EXPD_PDI_CD, P_PDI_CD)
				      AND B.MDL_MDY_CD = DECODE(P_MDL_MDY_CD, '', B.MDL_MDY_CD, P_MDL_MDY_CD)
				      GROUP BY C.DL_EXPD_REGN_CD
				     ) A,
				     TB_CODE_MGMT B
			   WHERE A.DL_EXPD_REGN_CD = B.DL_EXPD_PRVS_CD
		       AND B.DL_EXPD_G_CD = '0008'
			   ORDER BY B.SORT_SN;

	   ELSIF P_USF_CD = 'T' THEN

		   --권한구분없이 데이터 조회하는 경우

		   OPEN RS FOR
		   		SELECT A.DL_EXPD_REGN_CD,
			           B.DL_EXPD_PRVS_NM AS DL_EXPD_REGN_NM
			    FROM (SELECT B.DL_EXPD_REGN_CD
                      FROM TB_VEHL_MGMT A,
					       TB_LANG_MGMT B
                      WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
				      AND A.MDL_MDY_CD = B.MDL_MDY_CD
                      AND A.MDL_MDY_CD BETWEEN V_FROM_MDL_MDY AND V_TO_MDL_MDY
					  AND A.DL_EXPD_CO_CD = DECODE(P_EXPD_CO_CD, 'ALL', A.DL_EXPD_CO_CD, P_EXPD_CO_CD)
			          AND A.DL_EXPD_PAC_SCN_CD = DECODE(P_PAC_SCN_CD, 'ALL', A.DL_EXPD_PAC_SCN_CD, P_PAC_SCN_CD)
				      AND A.DL_EXPD_PDI_CD = DECODE(P_PDI_CD, 'ALL', A.DL_EXPD_PDI_CD, P_PDI_CD)
				      AND A.MDL_MDY_CD = DECODE(P_MDL_MDY_CD, '', A.MDL_MDY_CD, P_MDL_MDY_CD)
					  AND A.USE_YN = 'Y'
					  AND B.USE_YN = 'Y'
				      GROUP BY B.DL_EXPD_REGN_CD
				     ) A,
				     TB_CODE_MGMT B
			   WHERE A.DL_EXPD_REGN_CD = B.DL_EXPD_PRVS_CD
		       AND B.DL_EXPD_G_CD = '0008'
			   ORDER BY B.SORT_SN;

	   ELSE
	   	   --내수/수출 구분하여 조회하는 경우

		    OPEN RS FOR
		   		 SELECT A.DL_EXPD_REGN_CD,
			            B.DL_EXPD_PRVS_NM AS DL_EXPD_REGN_NM
			     FROM (SELECT C.DL_EXPD_REGN_CD
                       FROM (SELECT QLTY_VEHL_CD
                             FROM TB_AUTH_VEHL_MGMT
                             WHERE MENU_ID = FU_RPAD(P_MENU_ID, 10)
                             AND USER_EENO = FU_RPAD(P_USER_EENO, 7)
						     AND QLTY_VEHL_CD = DECODE(P_VEHL_CD, 'ALL', QLTY_VEHL_CD, P_VEHL_CD)
                             GROUP BY QLTY_VEHL_CD
                            ) A,
                  	        TB_VEHL_MGMT B,
					        TB_LANG_MGMT C
                       WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
				       AND A.QLTY_VEHL_CD = C.QLTY_VEHL_CD
				       AND B.MDL_MDY_CD = C.MDL_MDY_CD
                       AND B.MDL_MDY_CD BETWEEN V_FROM_MDL_MDY AND V_TO_MDL_MDY
					   AND B.DL_EXPD_CO_CD = DECODE(P_EXPD_CO_CD, 'ALL', B.DL_EXPD_CO_CD, P_EXPD_CO_CD)
			           AND B.DL_EXPD_PAC_SCN_CD = DECODE(P_PAC_SCN_CD, 'ALL', B.DL_EXPD_PAC_SCN_CD, P_PAC_SCN_CD)
				       AND B.DL_EXPD_PDI_CD = DECODE(P_PDI_CD, 'ALL', B.DL_EXPD_PDI_CD, P_PDI_CD)
				       AND B.MDL_MDY_CD = DECODE(P_MDL_MDY_CD, '', B.MDL_MDY_CD, P_MDL_MDY_CD)
					   AND B.USE_YN = 'Y'
					   AND C.USE_YN = 'Y'
				       AND C.LANG_CD = DECODE(P_USF_CD, 'D', 'KO', C.LANG_CD)
					   AND C.LANG_CD <> DECODE(P_USF_CD, 'E', 'KO', 'NULL')
				       GROUP BY C.DL_EXPD_REGN_CD
				      ) A,
			          TB_CODE_MGMT B
			     WHERE A.DL_EXPD_REGN_CD = B.DL_EXPD_PRVS_CD
		         AND B.DL_EXPD_G_CD = '0008'
			     ORDER BY B.SORT_SN;

	   END IF;

   END SP_GET_REGN_INFO;
/**********************************************************/

/**********************************************************/
   -- 사용자권한에 소속된 언어 리스트 조회
   /**
   PROCEDURE SP_GET_LANG_INFO(P_FROM_YMD 	 VARCHAR2,
   			 				  P_TO_YMD		 VARCHAR2,
                              P_MENU_ID 	 VARCHAR2,
							  P_USER_EENO 	 VARCHAR2,
							  P_EXPD_CO_CD   VARCHAR2,
						      P_PAC_SCN_CD   VARCHAR2,
							  P_PDI_CD		 VARCHAR2,
							  P_VEHL_CD	     VARCHAR2,
							  P_REGN_CD	     VARCHAR2,
							  P_USF_CD		 VARCHAR2,  -- A : 전체, D: 내수만, E: 수출만 조회
							  RS OUT REFCUR)
   IS

	 V_FROM_MDL_MDY VARCHAR(2);
	 V_TO_MDL_MDY   VARCHAR(2);

   BEGIN

		SP_GET_VALID_MDL_MDY4(P_FROM_YMD, P_TO_YMD, V_FROM_MDL_MDY, V_TO_MDL_MDY);

		IF P_USF_CD = 'A' THEN

		   --내수/수출 구분없이 전체 항목에서 조회하는 경우

		   OPEN RS FOR
		   		SELECT C.LANG_CD,
				       MAX(C.LANG_CD_NM) AS LANG_CD_NM
                FROM (SELECT QLTY_VEHL_CD
                      FROM TB_AUTH_VEHL_MGMT
                      WHERE MENU_ID = FU_RPAD(P_MENU_ID, 10)
                      AND USER_EENO = FU_RPAD(P_USER_EENO, 7)
				      AND QLTY_VEHL_CD = DECODE(P_VEHL_CD, 'ALL', QLTY_VEHL_CD, P_VEHL_CD)
                      GROUP BY QLTY_VEHL_CD
                     ) A,
                     TB_VEHL_MGMT B,
			         TB_LANG_MGMT C
                WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
		        AND A.QLTY_VEHL_CD = C.QLTY_VEHL_CD
			    AND B.MDL_MDY_CD = C.MDL_MDY_CD
                AND B.MDL_MDY_CD BETWEEN V_FROM_MDL_MDY AND V_TO_MDL_MDY
				AND B.DL_EXPD_CO_CD = DECODE(P_EXPD_CO_CD, 'ALL', B.DL_EXPD_CO_CD, P_EXPD_CO_CD)
			    AND B.DL_EXPD_PAC_SCN_CD = DECODE(P_PAC_SCN_CD, 'ALL', B.DL_EXPD_PAC_SCN_CD, P_PAC_SCN_CD)
			    AND B.DL_EXPD_PDI_CD = DECODE(P_PDI_CD, 'ALL', B.DL_EXPD_PDI_CD, P_PDI_CD)
			    AND C.DL_EXPD_REGN_CD = DECODE(P_REGN_CD, 'ALL', C.DL_EXPD_REGN_CD, P_REGN_CD)
                GROUP BY C.LANG_CD
			    ORDER BY C.LANG_CD;

	   ELSE
	   	   --내수/수출 구분하여 조회하는 경우

		    OPEN RS FOR
		   		 SELECT C.LANG_CD,
				        MAX(C.LANG_CD_NM) AS LANG_CD_NM
                 FROM (SELECT QLTY_VEHL_CD
                       FROM TB_AUTH_VEHL_MGMT
                       WHERE MENU_ID = FU_RPAD(P_MENU_ID, 10)
                       AND USER_EENO = FU_RPAD(P_USER_EENO, 7)
				       AND QLTY_VEHL_CD = DECODE(P_VEHL_CD, 'ALL', QLTY_VEHL_CD, P_VEHL_CD)
                       GROUP BY QLTY_VEHL_CD
                      ) A,
                      TB_VEHL_MGMT B,
				      TB_LANG_MGMT C
                 WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
		         AND A.QLTY_VEHL_CD = C.QLTY_VEHL_CD
			     AND B.MDL_MDY_CD = C.MDL_MDY_CD
                 AND B.MDL_MDY_CD BETWEEN V_FROM_MDL_MDY AND V_TO_MDL_MDY
				 AND B.DL_EXPD_CO_CD = DECODE(P_EXPD_CO_CD, 'ALL', B.DL_EXPD_CO_CD, P_EXPD_CO_CD)
			     AND B.DL_EXPD_PAC_SCN_CD = DECODE(P_PAC_SCN_CD, 'ALL', B.DL_EXPD_PAC_SCN_CD, P_PAC_SCN_CD)
			     AND B.DL_EXPD_PDI_CD = DECODE(P_PDI_CD, 'ALL', B.DL_EXPD_PDI_CD, P_PDI_CD)
			     AND C.DL_EXPD_REGN_CD = DECODE(P_REGN_CD, 'ALL', C.DL_EXPD_REGN_CD, P_REGN_CD)
			     AND C.LANG_CD = DECODE(P_USF_CD, 'D', 'KO', C.LANG_CD)
			     AND C.LANG_CD <> DECODE(P_USF_CD, 'E', 'KO', 'NULL')
                 GROUP BY C.LANG_CD
		         ORDER BY C.LANG_CD;

	   END IF;

   END SP_GET_LANG_INFO;
   **/
   PROCEDURE SP_GET_LANG_INFO(P_FROM_YMD 	 VARCHAR2,
   			 				  P_TO_YMD		 VARCHAR2,
                              P_MENU_ID 	 VARCHAR2,
							  P_USER_EENO 	 VARCHAR2,
							  P_EXPD_CO_CD   VARCHAR2,
						      P_PAC_SCN_CD   VARCHAR2,
							  P_PDI_CD		 VARCHAR2,
							  P_VEHL_CD	     VARCHAR2,
							  P_MDL_MDY_CD   VARCHAR2,
							  P_REGN_CD	     VARCHAR2,
							  P_USF_CD		 VARCHAR2,  -- A : 전체, D: 내수만, E: 수출만 조회, T : 권한구분없이 데이터 조회
							  RS OUT REFCUR)
   IS

	 V_FROM_MDL_MDY VARCHAR(2);
	 V_TO_MDL_MDY   VARCHAR(2);

   BEGIN

		SP_GET_VALID_MDL_MDY4(P_FROM_YMD, P_TO_YMD, V_FROM_MDL_MDY, V_TO_MDL_MDY);

		IF P_USF_CD = 'A' THEN

		   --내수/수출 구분없이 전체 항목에서 조회하는 경우

		   OPEN RS FOR
		   		SELECT C.LANG_CD,
				       C.LANG_CD || '(' || MAX(C.LANG_CD_NM) || ')' AS LANG_CD_NM
                FROM (SELECT QLTY_VEHL_CD
                      FROM TB_AUTH_VEHL_MGMT
                      WHERE MENU_ID = FU_RPAD(P_MENU_ID, 10)
                      AND USER_EENO = FU_RPAD(P_USER_EENO, 7)
				      AND QLTY_VEHL_CD = DECODE(P_VEHL_CD, 'ALL', QLTY_VEHL_CD, P_VEHL_CD)
                      GROUP BY QLTY_VEHL_CD
                     ) A,
                     TB_VEHL_MGMT B,
			         TB_LANG_MGMT C
                WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
		        AND A.QLTY_VEHL_CD = C.QLTY_VEHL_CD
			    AND B.MDL_MDY_CD = C.MDL_MDY_CD
                AND B.MDL_MDY_CD BETWEEN V_FROM_MDL_MDY AND V_TO_MDL_MDY
				AND B.DL_EXPD_CO_CD = DECODE(P_EXPD_CO_CD, 'ALL', B.DL_EXPD_CO_CD, P_EXPD_CO_CD)
			    AND B.DL_EXPD_PAC_SCN_CD = DECODE(P_PAC_SCN_CD, 'ALL', B.DL_EXPD_PAC_SCN_CD, P_PAC_SCN_CD)
			    AND B.DL_EXPD_PDI_CD = DECODE(P_PDI_CD, 'ALL', B.DL_EXPD_PDI_CD, P_PDI_CD)
			    AND B.MDL_MDY_CD = DECODE(P_MDL_MDY_CD, '', B.MDL_MDY_CD, P_MDL_MDY_CD)
			    AND C.DL_EXPD_REGN_CD = DECODE(P_REGN_CD, 'ALL', C.DL_EXPD_REGN_CD, P_REGN_CD)
				AND B.USE_YN = 'Y'
				AND C.USE_YN = 'Y'
                GROUP BY C.LANG_CD
			    ORDER BY C.LANG_CD;

	   ELSIF P_USF_CD = 'M' THEN

		   --내수/수출 구분없이 전체 항목에서 조회하는 경우(사용하지 않는 내역도 표시되어야 하는 경우)

		   OPEN RS FOR
		   		SELECT C.LANG_CD,
				       C.LANG_CD || '(' || MAX(C.LANG_CD_NM) || ')' AS LANG_CD_NM
                FROM (SELECT QLTY_VEHL_CD
                      FROM TB_AUTH_VEHL_MGMT
                      WHERE MENU_ID = FU_RPAD(P_MENU_ID, 10)
                      AND USER_EENO = FU_RPAD(P_USER_EENO, 7)
				      AND QLTY_VEHL_CD = DECODE(P_VEHL_CD, 'ALL', QLTY_VEHL_CD, P_VEHL_CD)
                      GROUP BY QLTY_VEHL_CD
                     ) A,
                     TB_VEHL_MGMT B,
			         TB_LANG_MGMT C
                WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
		        AND A.QLTY_VEHL_CD = C.QLTY_VEHL_CD
			    AND B.MDL_MDY_CD = C.MDL_MDY_CD
                AND B.MDL_MDY_CD BETWEEN V_FROM_MDL_MDY AND V_TO_MDL_MDY
				AND B.DL_EXPD_CO_CD = DECODE(P_EXPD_CO_CD, 'ALL', B.DL_EXPD_CO_CD, P_EXPD_CO_CD)
			    AND B.DL_EXPD_PAC_SCN_CD = DECODE(P_PAC_SCN_CD, 'ALL', B.DL_EXPD_PAC_SCN_CD, P_PAC_SCN_CD)
			    AND B.DL_EXPD_PDI_CD = DECODE(P_PDI_CD, 'ALL', B.DL_EXPD_PDI_CD, P_PDI_CD)
			    AND B.MDL_MDY_CD = DECODE(P_MDL_MDY_CD, '', B.MDL_MDY_CD, P_MDL_MDY_CD)
			    AND C.DL_EXPD_REGN_CD = DECODE(P_REGN_CD, 'ALL', C.DL_EXPD_REGN_CD, P_REGN_CD)
                GROUP BY C.LANG_CD
			    ORDER BY C.LANG_CD;

	   ELSIF P_USF_CD = 'T' THEN

		   --권한구분없이 데이터 조회하는 경우

		   OPEN RS FOR
		   		SELECT B.LANG_CD,
					   B.LANG_CD || '(' || MAX(B.LANG_CD_NM) || ')' AS LANG_CD_NM
                FROM TB_VEHL_MGMT A,
					 TB_LANG_MGMT B
                WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
				AND A.MDL_MDY_CD = B.MDL_MDY_CD
                AND A.MDL_MDY_CD BETWEEN V_FROM_MDL_MDY AND V_TO_MDL_MDY
				AND A.DL_EXPD_CO_CD = DECODE(P_EXPD_CO_CD, 'ALL', A.DL_EXPD_CO_CD, P_EXPD_CO_CD)
			    AND A.DL_EXPD_PAC_SCN_CD = DECODE(P_PAC_SCN_CD, 'ALL', A.DL_EXPD_PAC_SCN_CD, P_PAC_SCN_CD)
				AND A.DL_EXPD_PDI_CD = DECODE(P_PDI_CD, 'ALL', A.DL_EXPD_PDI_CD, P_PDI_CD)
				AND A.MDL_MDY_CD = DECODE(P_MDL_MDY_CD, '', A.MDL_MDY_CD, P_MDL_MDY_CD)
				AND A.USE_YN = 'Y'
				AND B.USE_YN = 'Y'
				GROUP BY B.LANG_CD
				ORDER BY B.LANG_CD;

	   ELSE
	   	   --내수/수출 구분하여 조회하는 경우

		    OPEN RS FOR
		   		 SELECT C.LANG_CD,
				        C.LANG_CD || '(' || MAX(C.LANG_CD_NM) || ')' AS LANG_CD_NM
                 FROM (SELECT QLTY_VEHL_CD
                       FROM TB_AUTH_VEHL_MGMT
                       WHERE MENU_ID = FU_RPAD(P_MENU_ID, 10)
                       AND USER_EENO = FU_RPAD(P_USER_EENO, 7)
				       AND QLTY_VEHL_CD = DECODE(P_VEHL_CD, 'ALL', QLTY_VEHL_CD, P_VEHL_CD)
                       GROUP BY QLTY_VEHL_CD
                      ) A,
                      TB_VEHL_MGMT B,
				      TB_LANG_MGMT C
                 WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
		         AND A.QLTY_VEHL_CD = C.QLTY_VEHL_CD
			     AND B.MDL_MDY_CD = C.MDL_MDY_CD
                 AND B.MDL_MDY_CD BETWEEN V_FROM_MDL_MDY AND V_TO_MDL_MDY
				 AND B.DL_EXPD_CO_CD = DECODE(P_EXPD_CO_CD, 'ALL', B.DL_EXPD_CO_CD, P_EXPD_CO_CD)
			     AND B.DL_EXPD_PAC_SCN_CD = DECODE(P_PAC_SCN_CD, 'ALL', B.DL_EXPD_PAC_SCN_CD, P_PAC_SCN_CD)
			     AND B.DL_EXPD_PDI_CD = DECODE(P_PDI_CD, 'ALL', B.DL_EXPD_PDI_CD, P_PDI_CD)
		         AND B.MDL_MDY_CD = DECODE(P_MDL_MDY_CD, '', B.MDL_MDY_CD, P_MDL_MDY_CD)
			     AND C.DL_EXPD_REGN_CD = DECODE(P_REGN_CD, 'ALL', C.DL_EXPD_REGN_CD, P_REGN_CD)
				 AND B.USE_YN = 'Y'
				 AND C.USE_YN = 'Y'
			     AND C.LANG_CD = DECODE(P_USF_CD, 'D', 'KO', C.LANG_CD)
			     AND C.LANG_CD <> DECODE(P_USF_CD, 'E', 'KO', 'NULL')
                 GROUP BY C.LANG_CD
		         ORDER BY C.LANG_CD;

	   END IF;

   END SP_GET_LANG_INFO;
/**********************************************************/

/**********************************************************/
  --해당 프로그램에 수정권한 차종이 존재하는지의 여부를 확인
  PROCEDURE SP_GET_AUTHORITY_YN(P_MENU_ID 	   VARCHAR2,
							    P_USER_EENO    VARCHAR2,
								P_CHECK_YN OUT VARCHAR2)
  IS

	V_CNT    NUMBER;

	V_SCN_CD CHAR(1);

  BEGIN

	   SELECT NVL(MAX(INP_SCN_CD), 'A')
	   INTO V_SCN_CD
	   FROM TB_PGM_MGMT
	   WHERE MENU_ID = FU_RPAD(P_MENU_ID, 10);

	   IF V_SCN_CD = 'B' THEN

		  --MENU_AUTH_CD 는 'R'만 존재하기 때문에 아래의 쿼리가 가능하다.
		  SELECT COUNT(*)
		  INTO V_CNT
		  FROM TB_AUTH_AFFR_MGMT
		  WHERE MENU_ID = FU_RPAD(P_MENU_ID, 10)
       	  AND USER_EENO = FU_RPAD(P_USER_EENO, 7);

	   ELSE

		  SELECT COUNT(*)
	   	  INTO V_CNT
	   	  FROM TB_AUTH_VEHL_MGMT
       	  WHERE MENU_ID = FU_RPAD(P_MENU_ID, 10)
       	  AND USER_EENO = FU_RPAD(P_USER_EENO, 7)
	   	  AND CL_SCN_CD = 'U'
       	  AND ROWNUM <= 1;

	   END IF;

	   IF V_CNT = 0 THEN

		  P_CHECK_YN := 'N';

	   ELSE

		  P_CHECK_YN := 'Y';

	   END IF;

  END SP_GET_AUTHORITY_YN;
/**********************************************************/

/**********************************************************/
  --코드그룹 리스트를 가져온다.
  PROCEDURE SP_GET_CODE_GRP_LIST(RS OUT REFCUR)
  IS
  BEGIN
  	   OPEN RS FOR
	   		SELECT DL_EXPD_G_CD,
				   DL_EXPD_G_NM
			FROM TB_CODE_GRP_MGMT
			ORDER BY DL_EXPD_G_NM;

  END SP_GET_CODE_GRP_LIST;
/**********************************************************/

/**********************************************************/
 --그룹코드에 해당하는 코드항목의 리스트를 가져온다.(ALL 제외)
  PROCEDURE SP_GET_CODE_LIST(P_EXPD_G_CD IN TB_CODE_MGMT.DL_EXPD_G_CD%TYPE,
                             RS OUT REFCUR)
  IS
  BEGIN

	   OPEN RS FOR
           SELECT DL_EXPD_PRVS_CD,
                  DL_EXPD_PRVS_NM
           FROM TB_CODE_MGMT
           WHERE DL_EXPD_G_CD = P_EXPD_G_CD
		   AND USE_YN = 'Y'
		   ORDER BY SORT_SN;

  END SP_GET_CODE_LIST;
/**********************************************************/

/**********************************************************/
 --사용자 정보 조회
 PROCEDURE SP_GET_USR_LIST(RS OUT REFCUR)
 IS
 BEGIN

	   OPEN RS FOR
           SELECT TRIM(USER_EENO) AS USER_EENO,
                  USER_NM,
				  USER_EML_ADR
           FROM TB_USR_MGMT
           WHERE USE_YN = 'Y'
		   ORDER BY USER_NM;

 END SP_GET_USR_LIST;
/**********************************************************/

/**********************************************************/
 --사용자 정보 조회2
 PROCEDURE SP_GET_USR_LIST2(P_BLNS_CO_CD TB_USR_MGMT.BLNS_CO_CD%TYPE,
                            RS OUT REFCUR)
 IS
 BEGIN

	   OPEN RS FOR
           SELECT TRIM(USER_EENO) AS USER_EENO,
                  USER_NM,
				  USER_EML_ADR
           FROM TB_USR_MGMT
           WHERE USE_YN = 'Y'
           AND BLNS_CO_CD = DECODE(P_BLNS_CO_CD,'',BLNS_CO_CD, P_BLNS_CO_CD)
		   ORDER BY USER_NM;

 END SP_GET_USR_LIST2;
/**********************************************************/

/**********************************************************/
 --차종 담당자 정보 조회
  PROCEDURE SP_GET_VEHL_USR_LIST(P_VEHL_CD    VARCHAR2,
  								 P_MDL_MDY_CD VARCHAR2,
								 P_BLNS_CO_CD VARCHAR2, --코드테이블의 그룹코드가 '0021' 인 항목 참고
								 RS OUT REFCUR)
 IS
 BEGIN

	   OPEN RS FOR
           SELECT TRIM(A.USER_EENO) AS USER_EENO,
                  MAX(A.USER_NM) AS USER_NM,
				  MAX(A.USER_EML_ADR) AS USER_EML_ADR
           FROM TB_USR_MGMT A,
		   		TB_VEHL_CRGR_MGMT B
		   WHERE A.USER_EENO = B.CRGR_EENO
		   AND B.QLTY_VEHL_CD = DECODE(P_VEHL_CD, 'ALL', B.QLTY_VEHL_CD, P_VEHL_CD)
		   AND B.MDL_MDY_CD = DECODE(P_MDL_MDY_CD, '', B.MDL_MDY_CD, P_MDL_MDY_CD)
		   AND B.BLNS_CO_CD = P_BLNS_CO_CD
           AND B.USE_YN = 'Y'
		   AND A.USE_YN = 'Y'
		   GROUP BY A.USER_EENO
		   ORDER BY MAX(A.USER_NM);

 END SP_GET_VEHL_USR_LIST;
/**********************************************************/

/**********************************************************/
 --차종 담당자 정보 조회(언어에 따른 PDI 또는 글로비스 차종담당자 리스트 조회)
 PROCEDURE SP_GET_VEHL_USR_LIST2(P_VEHL_CD    VARCHAR2,
  								 P_MDL_MDY_CD VARCHAR2,
								 P_LANG_CD    VARCHAR2,
								 RS OUT REFCUR)
 IS

   V_BLNS_CO_CD VARCHAR2(4);

 BEGIN

	  IF P_LANG_CD = 'KO' THEN

		 V_BLNS_CO_CD := '05';

	  ELSE

	     V_BLNS_CO_CD := '04';

	  END IF;

 	  OPEN RS FOR
           SELECT TRIM(A.USER_EENO) AS USER_EENO,
                  MAX(A.USER_NM) AS USER_NM,
				  MAX(A.USER_EML_ADR) AS USER_EML_ADR
           FROM TB_USR_MGMT A,
		   		TB_VEHL_CRGR_MGMT B
		   WHERE A.USER_EENO = B.CRGR_EENO
		   AND B.QLTY_VEHL_CD = DECODE(P_VEHL_CD, 'ALL', B.QLTY_VEHL_CD, P_VEHL_CD)
		   AND B.MDL_MDY_CD = DECODE(P_MDL_MDY_CD, '', B.MDL_MDY_CD, P_MDL_MDY_CD)
		   AND B.BLNS_CO_CD = V_BLNS_CO_CD
           AND B.USE_YN = 'Y'
		   AND A.USE_YN = 'Y'
		   GROUP BY A.USER_EENO
		   ORDER BY MAX(A.USER_NM);

 END SP_GET_VEHL_USR_LIST2;
/**********************************************************/
 --조회시에 차종코드에 관계된 APS, 생산마스터, BOM 차종을 가져오기 위한 함수
 PROCEDURE SP_GET_PRDN_VEHL_LIST(P_QLTY_VEHL_CD VARCHAR2,
			 					 P_PRVS_SCN_CD  VARCHAR2, -- A: APS차종, B:생산마스터차종, C:BOM차종 (참고: 코드테이블 '0023')
								 P_VEHL_LIST	OUT VARCHAR2
								)
 IS

  CURSOR VEHL_MGMT_LIST IS SELECT PRDN_VEHL_CD
                           FROM TB_ALTN_VEHL_MGMT
					       WHERE QLTY_VEHL_CD  = P_QLTY_VEHL_CD
					       AND PRVS_SCN_CD = P_PRVS_SCN_CD
					       ORDER BY PRDN_VEHL_CD;

 BEGIN

    P_VEHL_LIST := '';

    FOR VEHL_LIST IN VEHL_MGMT_LIST LOOP

    	P_VEHL_LIST := P_VEHL_LIST || '''' || VEHL_LIST.PRDN_VEHL_CD || ''',';

    END LOOP;

    IF LENGTH(P_VEHL_LIST) > 0 THEN

       P_VEHL_LIST := SUBSTR(P_VEHL_LIST, 1, LENGTH(P_VEHL_LIST) - 1);

    END IF;

 END SP_GET_PRDN_VEHL_LIST;

 --조회시에 승상구분, PDI, 차종에 관계된 APS, 생산마스터, BOM 차종을 가져오기 위한 함수
 PROCEDURE SP_GET_PRDN_VEHL_LIST2(P_PAC_SCN_CD   VARCHAR2,
							      P_PDI_CD	     VARCHAR2,
   			 					  P_QLTY_VEHL_CD VARCHAR2,
			 					  P_PRVS_SCN_CD  VARCHAR2, -- A: APS차종, B:생산마스터차종, C:BOM차종 (참고: 코드테이블 '0023')
								  P_VEHL_LIST	 OUT VARCHAR2
								 )
 IS

   CURSOR VEHL_MGMT_LIST IS SELECT PRDN_VEHL_CD
                            FROM (SELECT QLTY_VEHL_CD
							      FROM TB_VEHL_MGMT
								  WHERE DL_EXPD_PAC_SCN_CD = DECODE(P_PAC_SCN_CD, 'ALL', DL_EXPD_PAC_SCN_CD, P_PAC_SCN_CD)
								  AND DL_EXPD_PDI_CD = DECODE(P_PDI_CD, 'ALL', DL_EXPD_PDI_CD, P_PDI_CD)
								  AND QLTY_VEHL_CD = DECODE(P_QLTY_VEHL_CD, 'ALL', QLTY_VEHL_CD, P_QLTY_VEHL_CD)
								  GROUP BY QLTY_VEHL_CD
								 ) A,
							     TB_ALTN_VEHL_MGMT B
							WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
					        AND B.PRVS_SCN_CD = P_PRVS_SCN_CD
					        ORDER BY PRDN_VEHL_CD;

   V_VEHL_LIST VARCHAR2(8000);

 BEGIN

	  V_VEHL_LIST := '';

      FOR VEHL_LIST IN VEHL_MGMT_LIST LOOP

    	  V_VEHL_LIST := V_VEHL_LIST || '''' || VEHL_LIST.PRDN_VEHL_CD || ''',';

      END LOOP;

      IF LENGTH(V_VEHL_LIST) > 0 THEN

          V_VEHL_LIST := SUBSTR(V_VEHL_LIST, 1, LENGTH(V_VEHL_LIST) - 1);

      END IF;

	  P_VEHL_LIST := V_VEHL_LIST;

 END SP_GET_PRDN_VEHL_LIST2;

 PROCEDURE SP_GET_VEHL_CD_BY_PRDN(P_PRDN_VEHL_CD VARCHAR2,
                                  P_PRVS_SCN_CD  VARCHAR2, -- A: APS차종, B:생산마스터차종, C:BOM차종 (참고: 코드테이블 '0023')
								  P_VEHL_CD	     OUT VARCHAR2
                                 )
 IS
 BEGIN

	  --생산차종코드가 3자리로 되어 있는 경우를 대비하여
	  --먼저 3자리값을 비교해 보도록 한다.
	  SELECT MAX(QLTY_VEHL_CD)
	  INTO P_VEHL_CD
	  FROM TB_ALTN_VEHL_MGMT
	  WHERE PRDN_VEHL_CD = SUBSTR(P_PRDN_VEHL_CD, 1, 3)
	  AND PRVS_SCN_CD = P_PRVS_SCN_CD;

	  IF P_VEHL_CD IS NULL THEN

		 SELECT NVL(MAX(QLTY_VEHL_CD), '')
	  	 INTO P_VEHL_CD
	  	 FROM TB_ALTN_VEHL_MGMT
	  	 WHERE PRDN_VEHL_CD = SUBSTR(P_PRDN_VEHL_CD, 1, 2)
	  	 AND PRVS_SCN_CD = P_PRVS_SCN_CD;

	  END IF;

 END SP_GET_VEHL_CD_BY_PRDN;

 --품질차종이 아닌 다른 차종의 품질 차종 정보를 얻어오는 프로시저(생산마스터 I/F 전용)
 PROCEDURE SP_GET_VEHL_CD_BY_PRDN2(P_PRDN_VEHL_CD  VARCHAR2,
                                   P_PRVS_SCN_CD   VARCHAR2, -- A: APS차종, B:생산마스터차종, C:BOM차종 (참고: 코드테이블 '0023')
								   P_VEHL_CD	   OUT VARCHAR2,
								   P_PRDN2_VEHL_CD OUT VARCHAR2
                                  )
 IS
 BEGIN

	  --생산차종코드가 3자리로 되어 있는 경우를 대비하여
	  --먼저 3자리값을 비교해 보도록 한다.
	  P_PRDN2_VEHL_CD := SUBSTR(P_PRDN_VEHL_CD, 1, 3);

	  SELECT MAX(QLTY_VEHL_CD)
	  INTO P_VEHL_CD
	  FROM TB_ALTN_VEHL_MGMT
	  WHERE PRDN_VEHL_CD = P_PRDN2_VEHL_CD
	  AND PRVS_SCN_CD = P_PRVS_SCN_CD;

	  IF P_VEHL_CD IS NULL THEN

		 P_PRDN2_VEHL_CD := SUBSTR(P_PRDN_VEHL_CD, 1, 2);

		 SELECT MAX(QLTY_VEHL_CD)
	  	 INTO P_VEHL_CD
	  	 FROM TB_ALTN_VEHL_MGMT
	  	 WHERE PRDN_VEHL_CD = P_PRDN2_VEHL_CD
	  	 AND PRVS_SCN_CD = P_PRVS_SCN_CD;

		 IF P_VEHL_CD IS NULL THEN

			--현재 품질차종코드가 존재하지 않는 경우에는 빈공백을 없앤 차종코드를 그대로 사용하도록 한다.
			P_PRDN2_VEHL_CD := TRIM(P_PRDN_VEHL_CD);

            IF P_PRDN2_VEHL_CD IS NULL THEN

                P_PRDN2_VEHL_CD := ' ';

            END IF;

		 END IF;

	  END IF;

 END SP_GET_VEHL_CD_BY_PRDN2;

/**********************************************************/
 --현재 SYSTEM 날짜를 조회
 PROCEDURE SP_GET_SYSDATE(P_SYSDATE OUT VARCHAR2)
 IS
 BEGIN

	  SELECT TO_CHAR(SYSDATE, 'YYYYMMDD') INTO P_SYSDATE
	  FROM DUAL;

 END SP_GET_SYSDATE;
/**********************************************************/

/**********************************************************/
 --현재날짜와 1주전 날짜를 리턴
 PROCEDURE SP_GET_SYSDATE2(P_SYSDATE  OUT VARCHAR2,
   			 			   P_PREVDATE OUT VARCHAR2)
 IS
 BEGIN

	  SELECT TO_CHAR(SYSDATE, 'YYYYMMDD'), TO_CHAR(SYSDATE - 7, 'YYYYMMDD')
	  INTO P_SYSDATE, P_PREVDATE
	  FROM DUAL;

 END SP_GET_SYSDATE2;
 /**********************************************************/

 /**********************************************************/
 --현재날짜와 1주후 날짜를 리턴
 PROCEDURE SP_GET_SYSDATE3(P_SYSDATE  OUT VARCHAR2,
                           P_NEXTDATE OUT VARCHAR2)
 IS
 BEGIN

	  SELECT TO_CHAR(SYSDATE, 'YYYYMMDD'), TO_CHAR(SYSDATE + 7, 'YYYYMMDD')
	  INTO P_SYSDATE, P_NEXTDATE
	  FROM DUAL;

 END SP_GET_SYSDATE3;
 /**********************************************************/

 /**********************************************************/

 --현재날짜와 기간 달 수만큼 경과한 날짜를 리턴
 PROCEDURE SP_GET_SYSDATE4(P_DAY_CNT  IN NUMBER,
    		 			   P_PREVDATE OUT VARCHAR2,
                           P_NEXTDATE OUT VARCHAR2)
 IS

   V_SYST_YMD VARCHAR2(8);
   V_NEXT_YMD VARCHAR2(8);

 BEGIN

	  V_SYST_YMD := TO_CHAR(SYSDATE, 'YYYYMMDD');
	  V_NEXT_YMD := TO_CHAR(ADD_MONTHS(SYSDATE, P_DAY_CNT), 'YYYYMMDD');

	  IF V_SYST_YMD < V_NEXT_YMD THEN

		 P_PREVDATE := V_SYST_YMD;
		 P_NEXTDATE := V_NEXT_YMD;

	  ELSE

		 P_PREVDATE := V_NEXT_YMD;
		 P_NEXTDATE := V_SYST_YMD;

	  END IF;

 END SP_GET_SYSDATE4;
 /**********************************************************/

 /**********************************************************/
 PROCEDURE SP_GET_DATEDIFF(P_FROM_MTH VARCHAR2,
   			 			   P_TO_MTH   VARCHAR2,
						   P_DIFFCNT  OUT VARCHAR2)
 IS

   V_FROM_DATE DATE;
   V_TO_DATE   DATE;

 BEGIN

	  V_FROM_DATE := TO_DATE(P_FROM_MTH || '01', 'YYYYMMDD');
	  V_TO_DATE   := LAST_DAY(TO_DATE(P_TO_MTH || '01', 'YYYYMMDD'));

	  P_DIFFCNT := ROUND(MONTHS_BETWEEN(V_TO_DATE, V_FROM_DATE));

 END SP_GET_DATEDIFF;

 /**********************************************************/

 PROCEDURE SP_GET_DATELIST(P_FROM_MTH VARCHAR2,
   			 			   P_TO_MTH   VARCHAR2,
						   RS OUT REFCUR)
 IS

   V_FROM_YMD VARCHAR2(8);
   V_TO_YMD   VARCHAR2(8);

 BEGIN

	  V_FROM_YMD := P_FROM_MTH || '01';
	  V_TO_YMD   := TO_CHAR(LAST_DAY(TO_DATE(P_TO_MTH || '01', 'YYYYMMDD')), 'YYYYMMDD');

 	  OPEN RS FOR
	  	   SELECT TO_CHAR(TO_DATE(YMD || '01', 'YYYYMMDD'), 'YY.MM') AS YMD
		   FROM (SELECT SUBSTR(WK_YMD, 1, 6) AS YMD
		         FROM TB_WRK_DATE_MGMT
				 WHERE WK_YMD BETWEEN V_FROM_YMD AND V_TO_YMD
				 GROUP BY SUBSTR(WK_YMD, 1, 6)
				)
		   ORDER BY YMD;

 END SP_GET_DATELIST;

/**********************************************************/
 --사용자가 해당 메뉴 ID에서 가지는 권한 정보를 조회
 PROCEDURE SP_GET_AUTH_AFFR(P_MENU_ID   VARCHAR2,
							P_USER_EENO VARCHAR2,
						    P_AUTH_CD	OUT VARCHAR2)
 IS
 BEGIN

	  SELECT MAX(MENU_AUTH_CD)
	  INTO P_AUTH_CD
      FROM TB_AUTH_AFFR_MGMT
      WHERE MENU_ID = FU_RPAD(P_MENU_ID, 10)
      AND USER_EENO = FU_RPAD(P_USER_EENO, 7);

	  IF P_AUTH_CD IS NULL THEN

		 P_AUTH_CD := '';

	  END IF;

 END SP_GET_AUTH_AFFR;

/**********************************************************/
 --Split 함수
  FUNCTION FU_SPLIT(P_LIST  VARCHAR2,
                    P_COUNT OUT BINARY_INTEGER) RETURN LIST_TYPE
  IS

	--Split 구분자
  	V_DEL VARCHAR2(1) := ',';

    V_LIST     VARCHAR2(32767):= P_LIST;
	V_CURR_IDX PLS_INTEGER;

    V_LIST_TYPE LIST_TYPE;
    V_NUM       BINARY_INTEGER;

  BEGIN

	   V_NUM := 0;

       LOOP

	   	   V_NUM := V_NUM + 1;

           V_CURR_IDX := INSTR(V_LIST, V_DEL);

           IF V_CURR_IDX > 0 THEN

           	  V_LIST_TYPE(V_NUM) := SUBSTR(V_LIST, 1, V_CURR_IDX - 1);

              V_LIST := SUBSTR(V_LIST, V_CURR_IDX + LENGTH(V_DEL));

           ELSE

              V_LIST_TYPE(V_NUM) := V_LIST;

              EXIT;

           END IF;

        END LOOP;

    	P_COUNT := V_NUM;

    	RETURN V_LIST_TYPE;

  END FU_SPLIT;
/**********************************************************/

/**********************************************************/
  --RPAD 함수
  FUNCTION FU_RPAD(P_VALUE VARCHAR2,
   				   P_LENGTH NUMBER) RETURN VARCHAR2
  IS
  BEGIN

  	   RETURN RPAD(P_VALUE, P_LENGTH, ' ');

  END FU_RPAD;
/**********************************************************/

  FUNCTION FU_GET_VARCHAR_LIST(P_LIST VARCHAR2) RETURN VARCHAR2
  IS

	V_LIST LIST_TYPE;
	V_CNT  BINARY_INTEGER;

	V_VALUE VARCHAR2(8000);

  BEGIN

	   V_VALUE := '';

	   V_LIST := FU_SPLIT(P_LIST, V_CNT);

	   FOR NUM IN 1..V_CNT LOOP

		   V_VALUE := V_VALUE || '''' || V_LIST(NUM) || ''',';

	   END LOOP;

	   IF LENGTH(V_VALUE) > 0 THEN

		  V_VALUE := SUBSTR(V_VALUE, 1, LENGTH(V_VALUE) - 1);

	   END IF;

	   RETURN V_VALUE;

  END FU_GET_VARCHAR_LIST;

  --P_CURR_YMD 날짜에서 P_CNT 갯수만큼 경과한 영업기준 일자를 리턴해 준다.
  --(최대 이전, 이후로 5일까지만 가능함)
   FUNCTION FU_GET_WRKDATE(P_CURR_YMD VARCHAR2,
   						   P_CNT	  NUMBER) RETURN VARCHAR2
   IS

	 V_CUR_DATE DATE;
	 V_WRK_YMD  VARCHAR2(8);

   BEGIN

		IF P_CNT > 5 OR P_CNT < -5 THEN

		   RAISE_APPLICATION_ERROR(-20001, 'Invalid Date Duration(from -5 to 5 is valid)');

		END IF;

		V_CUR_DATE := TO_DATE(P_CURR_YMD, 'YYYYMMDD');

		IF P_CNT > 0 THEN

		   SELECT MAX(WK_YMD)
		   INTO V_WRK_YMD
		   FROM (SELECT WK_YMD,
		   				ROWNUM AS ROWNM
				 FROM (SELECT WK_YMD
				 	   FROM TB_WRK_DATE_MGMT
					   WHERE WK_YMD > P_CURR_YMD
					   -- 최대 5일 까지만 조회하므로 토,일요일을 감안하여 7일까지만 조회하여 내역을 확인한다.
					   AND WK_YMD <= TO_CHAR(V_CUR_DATE + 7, 'YYYYMMDD')
					   AND HOLI_YN = 'N'
					   ORDER BY WK_YMD
                      )
				)
		   WHERE ROWNM = P_CNT;

		ELSE

		   SELECT MAX(WK_YMD)
		   INTO V_WRK_YMD
		   FROM (SELECT WK_YMD,
		   				ROWNUM AS ROWNM
				 FROM (SELECT WK_YMD
				 	   FROM TB_WRK_DATE_MGMT
					   WHERE WK_YMD < P_CURR_YMD
					   -- 최대 5일 까지만 조회하므로 토,일요일을 감안하여 7일까지만 조회하여 내역을 확인한다.
					   AND WK_YMD >= TO_CHAR(V_CUR_DATE - 7, 'YYYYMMDD')
					   AND HOLI_YN = 'N'
					   ORDER BY WK_YMD DESC
                      )
				)
		   WHERE ROWNM = ABS(P_CNT);

		END IF;

		IF V_WRK_YMD IS NULL THEN

		   V_WRK_YMD := TO_CHAR(V_CUR_DATE + P_CNT, 'YYYYMMDD');

		END IF;

		RETURN V_WRK_YMD;

   END FU_GET_WRKDATE;

   --Date날짜를 한글 형태로 변경하여 리턴
   FUNCTION FU_TO_LOCAL_DATE_CHAR(P_CURR_DATE DATE) RETURN VARCHAR2
   IS

	 V_LOCAL_CHAR VARCHAR2(30);

   BEGIN


		V_LOCAL_CHAR := --TO_CHAR(P_CURR_DATE, 'YYYY') || '-' ||
		                TO_CHAR(P_CURR_DATE, 'MM')   || '월' ||
						TO_CHAR(P_CURR_DATE, 'DD')   || '일' || '(' ||
						TO_CHAR(P_CURR_DATE, 'HH24') || '시' ||
					    TO_CHAR(P_CURR_DATE, 'MI')   || '분' || ')';

		RETURN V_LOCAL_CHAR;

		--RETURN TO_CHAR(P_CURR_DATE, 'YYYY-MM-DD HH24:MI');

   END FU_TO_LOCAL_DATE_CHAR;

   --신인쇄발간번호를 이용하여 정렬처리 위한 문자열 생성
   FUNCTION FU_GET_SORT_PBCN(P_N_PRNT_PBCN_NO IN VARCHAR2) RETURN VARCHAR2
   IS

	 V_N_PRNT_PBCN_NO VARCHAR2(100);

	 V_YEAR  CHAR(1);
	 V_MONTH CHAR(1);
	 V_EXTEN CHAR(1);

   BEGIN

		IF LENGTH(P_N_PRNT_PBCN_NO) >= 10 THEN

		   V_N_PRNT_PBCN_NO := SUBSTR(P_N_PRNT_PBCN_NO, 1, 7);

		   V_YEAR  := SUBSTR(P_N_PRNT_PBCN_NO, 8, 1);
		   V_MONTH := SUBSTR(P_N_PRNT_PBCN_NO, 9, 1);
		   V_EXTEN := SUBSTR(P_N_PRNT_PBCN_NO, 10, 1);

		   IF V_YEAR = '1' THEN
		   	  V_N_PRNT_PBCN_NO := V_N_PRNT_PBCN_NO || '11';
		   ELSIF V_YEAR = '2' THEN
			  V_N_PRNT_PBCN_NO := V_N_PRNT_PBCN_NO || '12';
		   ELSIF V_YEAR = '3' THEN
			  V_N_PRNT_PBCN_NO := V_N_PRNT_PBCN_NO || '13';
		   ELSIF V_YEAR = '4' THEN
			  V_N_PRNT_PBCN_NO := V_N_PRNT_PBCN_NO || '14';
		   ELSIF V_YEAR = '5' THEN
			  V_N_PRNT_PBCN_NO := V_N_PRNT_PBCN_NO || '15';
		   ELSIF V_YEAR = '6' THEN
			  V_N_PRNT_PBCN_NO := V_N_PRNT_PBCN_NO || '16';
		   ELSIF V_YEAR = '7' THEN
			  V_N_PRNT_PBCN_NO := V_N_PRNT_PBCN_NO || '17';
		   ELSIF V_YEAR = '8' THEN
			  V_N_PRNT_PBCN_NO := V_N_PRNT_PBCN_NO || '08';
		   ELSIF V_YEAR = '9' THEN
			  V_N_PRNT_PBCN_NO := V_N_PRNT_PBCN_NO || '09';
		   ELSIF V_YEAR = '0' THEN
			  V_N_PRNT_PBCN_NO := V_N_PRNT_PBCN_NO || '10';
		   ELSE
		      V_N_PRNT_PBCN_NO := V_N_PRNT_PBCN_NO || V_YEAR;
		   END IF;

		   IF V_MONTH = '1' THEN
		   	  V_N_PRNT_PBCN_NO := V_N_PRNT_PBCN_NO || '01';
		   ELSIF V_MONTH = '2' THEN
			  V_N_PRNT_PBCN_NO := V_N_PRNT_PBCN_NO || '02';
		   ELSIF V_MONTH = '3' THEN
			  V_N_PRNT_PBCN_NO := V_N_PRNT_PBCN_NO || '03';
		   ELSIF V_MONTH = '4' THEN
			  V_N_PRNT_PBCN_NO := V_N_PRNT_PBCN_NO || '04';
		   ELSIF V_MONTH = '5' THEN
			  V_N_PRNT_PBCN_NO := V_N_PRNT_PBCN_NO || '05';
		   ELSIF V_MONTH = '6' THEN
			  V_N_PRNT_PBCN_NO := V_N_PRNT_PBCN_NO || '06';
		   ELSIF V_MONTH = '7' THEN
			  V_N_PRNT_PBCN_NO := V_N_PRNT_PBCN_NO || '07';
		   ELSIF V_MONTH = '8' THEN
			  V_N_PRNT_PBCN_NO := V_N_PRNT_PBCN_NO || '08';
		   ELSIF V_MONTH = '9' THEN
			  V_N_PRNT_PBCN_NO := V_N_PRNT_PBCN_NO || '09';
		   ELSIF V_MONTH = 'O' THEN
			  V_N_PRNT_PBCN_NO := V_N_PRNT_PBCN_NO || '10';
		   ELSIF V_MONTH = 'N' THEN
		      V_N_PRNT_PBCN_NO := V_N_PRNT_PBCN_NO || '11';
		   ELSIF V_MONTH = 'D' THEN
		   	  V_N_PRNT_PBCN_NO := V_N_PRNT_PBCN_NO || '12';
		   ELSE
		      V_N_PRNT_PBCN_NO := V_N_PRNT_PBCN_NO || V_MONTH;
		   END IF;

		   IF V_EXTEN = 'A' THEN
			  V_N_PRNT_PBCN_NO := V_N_PRNT_PBCN_NO || 'Z';
		   ELSE
			  V_N_PRNT_PBCN_NO := V_N_PRNT_PBCN_NO || V_EXTEN;
		   END IF;

		ELSE

			V_N_PRNT_PBCN_NO := P_N_PRNT_PBCN_NO;

		END IF;

		RETURN V_N_PRNT_PBCN_NO;

   END FU_GET_SORT_PBCN;

END ;