CREATE OR REPLACE PACKAGE KOMMS_ADM.PG_MAKE_DATA AS
	   
	   TYPE REFCUR IS REF CURSOR;
	   
      /************************************************************
	   시스템 운영 중 현업 요청 사항에 대응하기 위한 프로시저/함수 
	  ************************************************************/
									   
       --사원번호 변경(기존에 이미 입력되어 있던 사원번호를 새로운 사원번호로 변경) 								   
	   PROCEDURE SP_CHANGE_USER_EENO(P_PREV_USER_EENO VARCHAR2,
	                                 P_NEW_USER_EENO  VARCHAR2);
       
	   --차종코드 변경(기존의 차종코드를 새로운 차종코드로 변경)  									
	   PROCEDURE SP_UPDATE_VEHL_CD1(P_PREV_VEHL_CD VARCHAR2,
	                                P_NEW_VEHL_CD  VARCHAR2);
									
	   --차종코드에 해당하는 언어코드 변경(기존의 언어코드를 새로운 언어코드로 변경)  									
	   PROCEDURE SP_UPDATE_LANG_CD1(P_VEHL_CD	   VARCHAR2,
	   			 					P_PREV_LANG_CD VARCHAR2,
	                                P_NEW_LANG_CD  VARCHAR2);
       
	   --템플릿 차종코드, 연식에 해당하는 항목으로 차종코드, 연식의 언어 및 국가/언어 항목을 추가 
	   PROCEDURE SP_UPDATE_VEHL_LANG_CD(P_TEMPLATE_VEHL_CD VARCHAR2,
	   			 						P_TEMPLATE_MDY_CD  VARCHAR2,
										P_VEHL_CD		   VARCHAR2,
										P_MDL_MDY_CD	   VARCHAR2);
	   
	   --[주의] GOMS와의 인터페이스 처리로 인하여... GOMS에서 한꺼번에 처리해 주면 됨 
	   --이전 연식에 해당하는 차종정보를 기반으로 신규 차종, 언어, 국가/언어 항목 추가
	   --이미 현재 연식으로 지정되어 있는 항목은 신규생성 대상에서 제외함 
	   PROCEDURE SP_CREATE_NEW_VEHL_INFO(P_PREV_MDL_MDY_CD   VARCHAR2,
	                                     P_EXCLUDE_VEHL_LIST VARCHAR2);
	   
	   /** 2010.12.09.김동근 PG_VEHL_MGMT 패키지로 이동 
	   --그룹별 담당자 아이디 리스트를 얻어오는 함수 
	   FUNCTION GET_CRGR_USER_LIST(P_QLTY_VEHL_CD VARCHAR2,
	                               P_MDL_MDY_CD   VARCHAR2,
	                               P_BLNS_CO_CD   VARCHAR2
								   ) RETURN VARCHAR2; 
	   **/
	   
	   --차종코드 전체의 직전연식관계 정보를 재 설정 											   
	   PROCEDURE SP_UPDATE_VEHL_MDY_REL_CD;
	   
	   --해당날짜의 세화 재고 데이터 이전날짜의 데이터로 초기화 하는 작업 수행 
--	   PROCEDURE SP_RESET_SEWHA_IV_INFO;
	   
	   --국가별 신규 차종, 언어 등록(EXCEL 자료 이용) 
	   PROCEDURE SP_UPDATE_NEW_NATL_LANG_INFO;
	   
	   --제작준비과정에서 차종코드, 언어코드 오입력시에 수정하는 작업 수행
	   --만일 승인완료된 경우 승인취소가 된 뒤에 작업이 이루어져야 함 
	   PROCEDURE SP_CHANGE_PRNT_VEHL_INFO(P_PRNT_PBCN_NO VARCHAR2,
	                                      P_VEHL_CD      VARCHAR2,
										  P_MDL_MDY_CD	 VARCHAR2,
										  P_LANG_CD		 VARCHAR2);
										  
	   
	   --ABLE_ADM 위한 배치 로그 생성 작업(임시) 
	   PROCEDURE SP_CREATE_BATCH_LOG_TEMP;
	   PROCEDURE SP_CREATE_BATCH_LOG_TEMP2(P_FROM_YMD VARCHAR2,
	   			 						   P_TO_YMD   VARCHAR2);
	   
	   --랜덤 시간 정보 임시 생성 프로시저1 
	   PROCEDURE SP_GET_RANDOM_NUM(P_STRT_CHAR OUT VARCHAR2,
	                               P_FNH_CHAR  OUT VARCHAR2);
       
	   --랜덤 시간 정보 임시 생성 프로시저2								   							   
	   FUNCTION GET_RANDOM_NUM(P_MODE     CHAR,
	   						   P_SEED_NUM NUMBER,
	   						   P_DIV_NUM  NUMBER)RETURN VARCHAR2;
	   
	   --생산마스터진행정보 테이블의 데이터 삭제 
	   PROCEDURE SP_RESET_PROD_PROG_INFO(P_USF_CD VARCHAR2);
	   
	   --생산계획 데이터 일자별 임시 생성 - 2010.08.18.김동근 양희주 과장 요청으로 특정 오더번호에 해당하는 생산계획 데이터 임시 생성
	   PROCEDURE GET_APS_PROD_SUM2(CURR_YMD   IN VARCHAR2,
	                               EXPD_CO_CD IN VARCHAR2);
								   
	   /**********************************************************************************
	    [사용보류] 검증되지 않았음
		
	   --연식재지정시(배치가 실행된 직후에 연식을 임의로 변경한 경우)에 이미 배치돌았던 작업을 원복하는 프로시저 
	   PROCEDURE SP_RESET_IF_VEHL_IV_INFO(P_VEHL_CD VARCHAR2,
	                                      P_CURR_YMD VARCHAR2);
	   
	   --세원 출고정보 오입력 대비 PDI(글로비스) 입고 내역 취소 작업 수행 프로시저 
	   PROCEDURE SP_RESET_SEWHA_IN_OUT_IV_INFO(P_LANG_CD VARCHAR2,
	   			 							   P_WHSN_YMD VARCHAR2);
	  
       **********************************************************************************/ 
	   	   
       --자바 ADO 패키지 작성용 테스트 프로시저 	   									  							  
	   PROCEDURE SP_SELECT_TEST(RS OUT REFCUR);
	   
	   FUNCTION FU_DATA_EXIST(P_VAL  VARCHAR2,
	   						  P_LIST VARCHAR2)RETURN VARCHAR2;
	   
	   /***************************************************************************** 
	   시스템 개발 후 OPEN 초기 이전 데이터를 처리 하기위해서 사용했던 프로시저/함수 
	    *****************************************************************************
		
	   --차종코드 등록 
	   PROCEDURE SP_MAKE_VEHL_INFO(P_QLTY_VEHL_CD       VARCHAR2,
	   			 				   P_MDL_MDY_CD         VARCHAR2,
								   P_DL_EXPD_CO_CD      VARCHAR2,
								   P_QLTY_VEHL_NM       VARCHAR2,
								   P_DL_EXPD_PAC_SCN_CD VARCHAR2,
								   P_DL_EXPD_PDI_CD		VARCHAR2,
								   P_JB_MDY_REL_CD      VARCHAR2,
								   P_DYTM_PLN_VEHL_CD   VARCHAR2,
								   P_PRDN_MST_VEHL_CD	VARCHAR2,
								   P_BOM_VEHL_CD        VARCHAR2);
       
	   --연계차종코드 등록 								   
	   PROCEDURE SP_MAKE_ALTN_VEHL_INFO(P_QLTY_VEHL_CD VARCHAR2,
	   			 						P_PRDN_VEHL_CD VARCHAR2,
			 						    P_PRVS_SCN_CD  VARCHAR2);
	                               
	  --국가코드 리스트 등록 
	  PROCEDURE SP_MAKE_NATL_LIST;
	  
	  --국가코드 등록 					   
	  PROCEDURE SP_MAKE_NATL_INFO(P_DL_EXPD_CO_CD   VARCHAR2,
	  							  P_DL_EXPD_NAT_CD  VARCHAR2,
								  P_NAT_NM			VARCHAR2); 
	  
	  --국가/언어 리스트 등록 
	  PROCEDURE SP_MAKE_NATL_NALG_LIST(P_DL_EXPD_CO_CD     VARCHAR2,
	  							       P_DL_EXPD_NAT_LIST  VARCHAR2,
									   P_QLTY_VEHL_LIST	   VARCHAR2,
								       P_LANG_CD           VARCHAR2); 
	  
	  --기아 국가/언어 코드 등록						   
	  PROCEDURE SP_MAKE_NATL_NALG_LIST_KMC;
	  
	  --현대 승용 국가/언어 코드 등록							   
	  PROCEDURE SP_MAKE_NATL_NALG_LIST_HMC1;
	  
	  --국가/언어 코드 등록
	  PROCEDURE SP_MAKE_NATL_LANG_INFO(P_DL_EXPD_CO_CD   VARCHAR2,
	  							       P_DL_EXPD_NAT_CD  VARCHAR2,
									   P_QLTY_VEHL_CD	 VARCHAR2,
									   P_MDL_MDY_CD		 VARCHAR2,
								       P_LANG_CD         VARCHAR2);
	  
	  --국가/차종/언어 수정(이미 입력된 값을 수정하는 작업을 수행하는 것임) 
	  PROCEDURE SP_SAVE_NATL_VEHL_LANG_INFO(P_DL_EXPD_CO_CD   VARCHAR2,
	  							            P_DL_EXPD_NAT_CD  VARCHAR2,
									        P_QLTY_VEHL_CD	  VARCHAR2,
											P_MDL_MDY_CD	  VARCHAR2,
											P_LANG_CD         VARCHAR2);
	  
	  PROCEDURE SP_TEMP_COPY_AUTH(P_USER_EENO VARCHAR2);
	  
	  
	  --사용자 권한정보 임시 복사하는 함수 
	  PROCEDURE SP_COPY_AUTH_VEHL_INFO(P_USER_EENO VARCHAR2,
	                                   P_MENU_ID   VARCHAR2);
	  
	  --체크리스트변경 정보 저장 
	  PROCEDURE SP_CHKLIST_INFO_SAVE;
	  
	  --체크리스트변경 정보 저장2  
	  PROCEDURE SP_CHKLIST_INFO_SAVE2;
	  
	  --체크리스트변경 상세정보 저장 
	  PROCEDURE SP_CHKLIST_DTL_INFO_SAVE;
	  
	  --체크리스트변경 상세정보 저장2 
	  PROCEDURE SP_CHKLIST_DTL_INFO_SAVE2;
	  
	  PROCEDURE SP_CHKLIST_DTL_INFO_SAVE3;
	  
	  PROCEDURE SP_CHKLIST_DTL_INFO_SAVE4;
	  
	  --체크리스트 변경정보 임시 저장 
	  PROCEDURE SP_INSERT_CHKLIST_TEMP(P_NO           TB_CHKLIST_INFO_TEMP.NO%TYPE,
	  								   P_ALTR_YMD     TB_CHKLIST_INFO_TEMP.ALTR_YMD%TYPE,
									   P_RCPM_SHAP_CD TB_CHKLIST_INFO_TEMP.RCPM_SHAP_CD%TYPE,
									   P_DSPP_NM      TB_CHKLIST_INFO_TEMP.DSPP_NM%TYPE,
									   P_CRGR_NM      TB_CHKLIST_INFO_TEMP.CRGR_NM%TYPE,
									   P_VEHL_CD      TB_CHKLIST_INFO_TEMP.VEHL_CD%TYPE,
									   P_ALTR_SBC     TB_CHKLIST_INFO_TEMP.ALTR_SBC%TYPE);

      --체크리스트 상세정보 임시 저장 									   
      PROCEDURE SP_INSERT_CHKDTL_LIST_TEMP(P_NO       NUMBER,
                                           P_VEHL_CD  VARCHAR2,
                                           P_COL_AR   VARCHAR2,
                                           P_COL_AS   VARCHAR2,
                                           P_COL_CH   VARCHAR2,
                                           P_COL_CN   VARCHAR2,
                                           P_COL_CZ   VARCHAR2,
                                           P_COL_DE   VARCHAR2,
                                           P_COL_EA   VARCHAR2,
                                           P_COL_EC   VARCHAR2,
                                           P_COL_EE   VARCHAR2,
                                           P_COL_EG   VARCHAR2,
                                           P_COL_EM   VARCHAR2,
                                           P_COL_EP   VARCHAR2,
                                           P_COL_EU   VARCHAR2,
                                           P_COL_FE   VARCHAR2,
                                           P_COL_FG   VARCHAR2,
                                           P_COL_GE   VARCHAR2,
                                           P_COL_HO   VARCHAR2,
                                           P_COL_HU   VARCHAR2,
                                           P_COL_IT   VARCHAR2,
                                           P_COL_JA   VARCHAR2,
                                           P_COL_KO   VARCHAR2,
                                           P_COL_NR   VARCHAR2,
                                           P_COL_PB   VARCHAR2,
                                           P_COL_PE   VARCHAR2,
                                           P_COL_PO   VARCHAR2,
                                           P_COL_RU   VARCHAR2,
                                           P_COL_LY   VARCHAR2,
                                           P_COL_SE   VARCHAR2,
                                           P_COL_SG   VARCHAR2,
                                           P_COL_SM   VARCHAR2,
                                           P_COL_SV   VARCHAR2,
                                           P_COL_SW   VARCHAR2,
                                           P_COL_TW   VARCHAR2,
                                           P_COL_UK   VARCHAR2); 
	  						   
      --12월2일 기준 재고 데이터 입력 										   
	  PROCEDURE SP_MAKE_IV_INFO;
	  
	  PROCEDURE SP_ROLLBACK_IV_INFO(P_CURR_YMD VARCHAR2);
	  
	  PROCEDURE SP_MAKEWHSN_IV_INFO(P_CURR_YMD VARCHAR2);
	  
	  PROCEDURE SP_MAKE_NATL_VEHL_MDY;
	  
	  PROCEDURE SP_NATL_VEHL_SAVE_TEMP(P_EXPD_CO_CD   VARCHAR2,
	   							       P_EXPD_NAT_CD  VARCHAR2,
								       P_QLTY_VEHL_CD VARCHAR2,
								       P_MDL_MDY_CD	  VARCHAR2,
								       P_LANG_CD      VARCHAR2); 
									   
	  *********************************************************/ 
	  
	  --메일서버 변경 관련 테스트 
	  PROCEDURE MAIL_TEST;
	  					   
END PG_MAKE_DATA;