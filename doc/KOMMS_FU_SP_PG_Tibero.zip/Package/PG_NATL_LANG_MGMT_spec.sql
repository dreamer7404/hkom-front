CREATE OR REPLACE PACKAGE KOMMS_ADM.PG_NATL_LANG_MGMT AS

	   TYPE REFCUR IS REF CURSOR;

	   /**
	   --차종 내역 조회(컬럼 헤더 구성용/ 신규작성시에 차종내역 구성용)
	   PROCEDURE SP_GET_VEHL_LIST(P_MENU_ID    VARCHAR2,
							      P_USER_EENO  VARCHAR2,
	   			 				  P_EXPD_CO_CD VARCHAR2,
	   			 				  P_MDL_MDY_CD VARCHAR2,
								  RS OUT REFCUR);
	   **/

	   --차종 내역 조회2(컬럼 헤더 구성용/ 신규작성시에 차종내역 구성용)
	   PROCEDURE SP_GET_VEHL_LIST2(P_MENU_ID    VARCHAR2,
							       P_USER_EENO  VARCHAR2,
	   			 				   P_EXPD_CO_CD VARCHAR2,
								   P_PDI_CD		VARCHAR2,
								   P_VEHL_CD	VARCHAR2,
	   			 				   P_MDL_MDY_CD VARCHAR2,
								   RS OUT REFCUR);

	   --회사에 소속된 국가리스트 조회
	   PROCEDURE SP_GET_NATL_LIST(P_EXPD_CO_CD VARCHAR2,
	   			 				  RS OUT REFCUR);

	   --차종에 적용가능한 언어내역 조회
	   PROCEDURE SP_GET_LANG_LIST(P_QLTY_VEHL_CD VARCHAR2,
	                              P_MDL_MDY_CD   VARCHAR2,
								  RS OUT REFCUR);

	   /**
	   --국가/언어코드 내역 조회
	   PROCEDURE SP_GET_NATL_LANT_MGMT(P_MENU_ID     VARCHAR2,
							      	   P_USER_EENO   VARCHAR2,
									   P_EXPD_CO_CD  TB_NATL_MGMT.DL_EXPD_CO_CD%TYPE,
									   P_EXPD_NAT_CD TB_NATL_MGMT.DL_EXPD_NAT_CD%TYPE,
									   P_MDL_MDY_CD	 VARCHAR2,
									   P_FROM_NUM    NUMBER,
									   P_TO_NUM      NUMBER,
									   P_CNT     OUT NUMBER,
	   								   RS OUT REFCUR);
	   **/

	   --국가/언어코드 내역 조회2
	   PROCEDURE SP_GET_NATL_LANT_MGMT2(P_MENU_ID     VARCHAR2,
							      	    P_USER_EENO   VARCHAR2,
									    P_EXPD_CO_CD  TB_NATL_MGMT.DL_EXPD_CO_CD%TYPE,
									    P_EXPD_NAT_CD TB_NATL_MGMT.DL_EXPD_NAT_CD%TYPE,
                                        P_EXPD_NAT_NM VARCHAR2,
										P_PDI_CD	  VARCHAR2,
								   		P_VEHL_CD	  VARCHAR2,
										P_MDL_MDY_CD  VARCHAR2,
										P_REGN_CD	  VARCHAR2,
										P_LANG_CD	  VARCHAR2,
									    P_FROM_NUM    NUMBER,
									    P_TO_NUM      NUMBER,
									    P_CNT     OUT NUMBER,
	   								    RS OUT REFCUR);

	   --국가/언어코드 내역 조회(엑셀전용)
	   PROCEDURE SP_GET_NATL_LANT_MGMT_EXCEL(P_MENU_ID     VARCHAR2,
							      	         P_USER_EENO   VARCHAR2,
									         P_EXPD_CO_CD  TB_NATL_MGMT.DL_EXPD_CO_CD%TYPE,
									         P_EXPD_NAT_CD TB_NATL_MGMT.DL_EXPD_NAT_CD%TYPE,
											 P_PDI_CD	   VARCHAR2,
								   			 P_VEHL_CD	   VARCHAR2,
									         P_MDL_MDY_CD  VARCHAR2,
											 P_REGN_CD	   VARCHAR2,
											 P_LANG_CD	   VARCHAR2,
									    	 RS OUT REFCUR);

	   --취급설명서 국가코드에 해당하는 APS국가코드 내역 리턴
	   FUNCTION FU_GET_DYTM_NATL_LIST(P_EXPD_CO_CD   TB_NATL_MGMT.DL_EXPD_CO_CD%TYPE,
	   								  P_EXPD_NAT_CD  TB_NATL_MGMT.DL_EXPD_NAT_CD%TYPE) RETURN VARCHAR2;
       /**
	   FUNCTION FU_GET_VEL_LANG_LIST(P_MENU_ID     VARCHAR2,
							      	 P_USER_EENO   VARCHAR2,
	   								 P_EXPD_CO_CD  TB_NATL_MGMT.DL_EXPD_CO_CD%TYPE,
	   								 P_EXPD_NAT_CD TB_NATL_MGMT.DL_EXPD_NAT_CD%TYPE,
									 P_MDL_MDY_CD  VARCHAR2) RETURN VARCHAR2;
	   **/

	   --취급설명서 국가코드, 차종, 연식에 해당하는 언어코드 내역 리턴
	   FUNCTION FU_GET_LANG_LIST(P_EXPD_CO_CD   TB_NATL_MGMT.DL_EXPD_CO_CD%TYPE,
	   							 P_EXPD_NAT_CD  TB_NATL_MGMT.DL_EXPD_NAT_CD%TYPE,
								 P_QLTY_VEHL_CD TB_NATL_LANG_MGMT.QLTY_VEHL_CD%TYPE,
								 P_MDL_MDY_CD	TB_NATL_LANG_MGMT.MDL_MDY_CD%TYPE) RETURN VARCHAR2;


	   --수정시에 해당국가정보에 해당하는 정보를 조회
	   PROCEDURE SP_GET_NATL_INFO(P_EXPD_CO_CD  VARCHAR2,
								  P_EXPD_NAT_CD TB_NATL_MGMT.DL_EXPD_NAT_CD%TYPE,
								  RS OUT REFCUR);

	   --수정시에 현재 선택된 국가에 대한 차종-언어정보를 조회
	   PROCEDURE SP_GET_VEHL_LANG_LIST(P_MENU_ID     VARCHAR2,
							           P_USER_EENO   VARCHAR2,
	   			 				       P_EXPD_CO_CD  VARCHAR2,
									   P_EXPD_NAT_CD TB_NATL_MGMT.DL_EXPD_NAT_CD%TYPE,
	   			 				       P_MDL_MDY_CD  VARCHAR2,
								       RS OUT REFCUR);

	   --국가정보 수정
	   PROCEDURE SP_NATL_INFO_SAVE(P_EXPD_CO_CD        TB_NATL_MGMT.DL_EXPD_CO_CD%TYPE,
                                   P_EXPD_NAT_CD       TB_NATL_MGMT.DL_EXPD_NAT_CD%TYPE,
								   P_NEW_EXPD_NAT_CD   TB_NATL_MGMT.DL_EXPD_NAT_CD%TYPE,
								   P_NAT_NM            VARCHAR2,
								   P_DYTM_PLN_NAT_LIST VARCHAR2,
								   P_USER_EENO         VARCHAR2,
								   P_REGION			   VARCHAR2
								   );

	   --국가정보 신규 입력
	   PROCEDURE SP_NATL_INFO_INSERT(P_EXPD_CO_CD        TB_NATL_MGMT.DL_EXPD_CO_CD%TYPE,
                                     P_EXPD_NAT_CD       TB_NATL_MGMT.DL_EXPD_NAT_CD%TYPE,
								     P_NAT_NM            VARCHAR2,
								     P_DYTM_PLN_NAT_LIST VARCHAR2,
								     P_USER_EENO         VARCHAR2,
									 P_REGION			 VARCHAR2
								    );


	   --취급설명서 국가코드에 해당하는 APS 국가코드 리스트 저장
	   PROCEDURE SP_DYTM_NATL_INFO_SAVE(P_EXPD_CO_CD        TB_NATL_MGMT.DL_EXPD_CO_CD%TYPE,
	                                    P_EXPD_NAT_CD       TB_NATL_MGMT.DL_EXPD_NAT_CD%TYPE,
								        P_DYTM_PLN_NAT_LIST VARCHAR2,
										P_UPDATE_MODE		VARCHAR2,
								        P_USER_EENO         VARCHAR2);


	   --취급설명서 국가코드에 해당하는 APS 국가코드 리스트 신규 입력
	   PROCEDURE SP_DYTM_NATL_INFO_INSERT(P_EXPD_CO_CD        TB_NATL_MGMT.DL_EXPD_CO_CD%TYPE,
	                                      P_EXPD_NAT_CD       TB_NATL_MGMT.DL_EXPD_NAT_CD%TYPE,
								          P_DYTM_PLN_NAT_LIST VARCHAR2,
										  P_USER_EENO         VARCHAR2);

	   --미지정 국가 코드 내역 삭제
	   PROCEDURE SP_NOAPIM_DYTM_NATL_INFO_DEL(P_EXPD_CO_CD    VARCHAR2,
	                                          P_EXPD_NAT_CD   VARCHAR2);

	   --국가별 차종-언어 정보 저장
	   PROCEDURE SP_VEHL_LANG_INFO_SAVE(P_EXPD_CO_CD      TB_NATL_MGMT.DL_EXPD_CO_CD%TYPE,
	                                    P_EXPD_NAT_CD     TB_NATL_MGMT.DL_EXPD_NAT_CD%TYPE,
										P_NEW_EXPD_NAT_CD TB_NATL_MGMT.DL_EXPD_NAT_CD%TYPE,
										P_MDL_MDY_CD      VARCHAR2,
										P_QLTY_VEHL_CD    VARCHAR2,
										P_LANG_LIST       VARCHAR2,
										P_USER_EENO       VARCHAR2);

	   --국가별 차종-언어 정보 신규입력
	   PROCEDURE SP_VEHL_LANG_INFO_INSERT(P_EXPD_CO_CD      TB_NATL_MGMT.DL_EXPD_CO_CD%TYPE,
	                                      P_EXPD_NAT_CD     TB_NATL_MGMT.DL_EXPD_NAT_CD%TYPE,
										  P_MDL_MDY_CD      VARCHAR2,
										  P_QLTY_VEHL_CD    VARCHAR2,
										  P_LANG_LIST       VARCHAR2,
										  P_USER_EENO       VARCHAR2);

	   --국가에 언어코드 등록시에 국가/차종/지역 을 매핑하는 작업을 수행하는 프로시저
	   --저장시 반드시 같이 호출되어야 함
	   PROCEDURE SP_NATL_VEHL_SAVE(P_EXPD_CO_CD   VARCHAR2,
	   							   P_EXPD_NAT_CD  VARCHAR2,
								   P_QLTY_VEHL_CD VARCHAR2,
								   P_MDL_MDY_CD	  VARCHAR2,
								   P_LANG_CD      VARCHAR2,
								   P_USER_EENO	  VARCHAR2);

END PG_NATL_LANG_MGMT;