CREATE OR REPLACE PACKAGE BODY KOMMS_ADM.PG_VEHL_MGMT AS
	   
	   /**
	   --차종내역 조회(나중에 수정요망) 
	   PROCEDURE SP_GET_VEHL_MGMT(RS OUT REFCUR)
	   IS 
	   BEGIN 
	   		
			OPEN RS FOR
				 SELECT *
				 FROM (SELECT QLTY_VEHL_CD,
				 	  		  MDL_MDY_CD,
							  DL_EXPD_CO_CD,
							  B.DL_EXPD_PRVS_NM AS DL_EXPD_CO_NM,
							  QLTY_VEHL_NM,
							  DL_EXPD_PAC_SCN_CD,
							  C.DL_EXPD_PRVS_NM AS DL_EXPD_PAC_SCN_NM,
							  DL_EXPD_PDI_CD,
							  D.DL_EXPD_PRVS_NM AS DL_EXPD_PDI_NM,
							  JB_MDY_REL_CD,
							  E.DL_EXPD_PRVS_NM AS JB_MDY_REL_NM,
							  FU_GET_PRDN_VEHL_LIST(QLTY_VEHL_CD, 'A') AS DYTM_PLN_VEHL_LIST,
							  FU_GET_PRDN_VEHL_LIST(QLTY_VEHL_CD, 'B') AS PRDN_MST_VEHL_LIST,
							  FU_GET_PRDN_VEHL_LIST(QLTY_VEHL_CD, 'C') AS BOM_VEHL_LIST,
							  FU_GET_CRGR_USER_LIST(QLTY_VEHL_CD, MDL_MDY_CD, '01') AS USER_LIST1,
							  FU_GET_CRGR_USER_LIST(QLTY_VEHL_CD, MDL_MDY_CD, '02') AS USER_LIST2,
							  A.USE_YN
				       FROM TB_VEHL_MGMT A,
					        TB_CODE_MGMT B,
	 						TB_CODE_MGMT C,
	 						TB_CODE_MGMT D,
							TB_CODE_MGMT E
					   WHERE A.DL_EXPD_CO_CD = B.DL_EXPD_PRVS_CD 
					   AND B.DL_EXPD_G_CD = '0003'
					   AND A.DL_EXPD_PAC_SCN_CD = C.DL_EXPD_PRVS_CD 
					   AND C.DL_EXPD_G_CD = '0004'
					   AND A.DL_EXPD_PDI_CD = D.DL_EXPD_PRVS_CD 
					   AND D.DL_EXPD_G_CD = '0005'
					   AND A.JB_MDY_REL_CD = E.DL_EXPD_PRVS_CD 
					   AND E.DL_EXPD_G_CD = '0007'
					  ); 
				 	  
	   END SP_GET_VEHL_MGMT;
	   **/
	   
	   PROCEDURE SP_GET_VEHL_MGMT2(P_EXPD_CO_CD VARCHAR2,
	                               P_PDI_CD	    VARCHAR2,
								   P_VEHL_CD	VARCHAR2,
								   P_MDL_MDY_CD VARCHAR2,
								   P_CRGR_EENO  VARCHAR2,
	                               RS OUT REFCUR)
	   IS
	   BEGIN
	   		
			IF P_CRGR_EENO IS NULL OR P_CRGR_EENO = '' THEN
			   
			   OPEN RS FOR
				 SELECT *
				 FROM (SELECT QLTY_VEHL_CD,
				 	  		  MDL_MDY_CD,
							  DL_EXPD_CO_CD,
							  B.DL_EXPD_PRVS_NM AS DL_EXPD_CO_NM,
							  QLTY_VEHL_NM,
							  DL_EXPD_PAC_SCN_CD,
							  C.DL_EXPD_PRVS_NM AS DL_EXPD_PAC_SCN_NM,
							  DL_EXPD_PDI_CD,
							  D.DL_EXPD_PRVS_NM AS DL_EXPD_PDI_NM,
							  JB_MDY_REL_CD,
							  E.DL_EXPD_PRVS_NM AS JB_MDY_REL_NM,
							  FU_GET_PRDN_VEHL_LIST(QLTY_VEHL_CD, 'A') AS DYTM_PLN_VEHL_LIST,
							  FU_GET_PRDN_VEHL_LIST(QLTY_VEHL_CD, 'B') AS PRDN_MST_VEHL_LIST,
							  FU_GET_PRDN_VEHL_LIST(QLTY_VEHL_CD, 'C') AS BOM_VEHL_LIST,
							  FU_GET_PRDN_VEHL_LIST(QLTY_VEHL_CD, 'D') AS SALE_VEHL_LIST,
							  FU_GET_CRGR_USER_LIST(QLTY_VEHL_CD, MDL_MDY_CD, '01') AS USER_LIST1,
							  FU_GET_CRGR_USER_LIST(QLTY_VEHL_CD, MDL_MDY_CD, '02') AS USER_LIST2,
							  FU_GET_CRGR_USER_LIST(QLTY_VEHL_CD, MDL_MDY_CD, '03') AS USER_LIST3,
							  FU_GET_CRGR_USER_LIST(QLTY_VEHL_CD, MDL_MDY_CD, '04') AS USER_LIST4,
							  FU_GET_CRGR_USER_LIST(QLTY_VEHL_CD, MDL_MDY_CD, '05') AS USER_LIST5,
							  A.USE_YN
				       FROM TB_VEHL_MGMT A,
					        TB_CODE_MGMT B,
	 						TB_CODE_MGMT C,
	 						TB_CODE_MGMT D,
							TB_CODE_MGMT E
					   WHERE A.DL_EXPD_CO_CD = B.DL_EXPD_PRVS_CD
					   AND B.DL_EXPD_G_CD = '0003'
					   AND A.DL_EXPD_PAC_SCN_CD = C.DL_EXPD_PRVS_CD
					   AND C.DL_EXPD_G_CD = '0004'
					   AND A.DL_EXPD_PDI_CD = D.DL_EXPD_PRVS_CD
					   AND D.DL_EXPD_G_CD = '0005'
					   AND A.JB_MDY_REL_CD = E.DL_EXPD_PRVS_CD
					   AND E.DL_EXPD_G_CD = '0007'
					   AND A.DL_EXPD_CO_CD = DECODE(P_EXPD_CO_CD, 'ALL', A.DL_EXPD_CO_CD, P_EXPD_CO_CD)
					   AND A.DL_EXPD_PDI_CD = DECODE(P_PDI_CD, 'ALL', A.DL_EXPD_PDI_CD, P_PDI_CD)
					   AND A.QLTY_VEHL_CD = DECODE(P_VEHL_CD, 'ALL', A.QLTY_VEHL_CD, P_VEHL_CD)
					   AND A.MDL_MDY_CD = P_MDL_MDY_CD
					  );
			
			ELSE
			
				OPEN RS FOR
				 SELECT *
				 FROM (SELECT A.QLTY_VEHL_CD,
				 	  		  A.MDL_MDY_CD,
							  A.DL_EXPD_CO_CD,
							  B.DL_EXPD_PRVS_NM AS DL_EXPD_CO_NM,
							  A.QLTY_VEHL_NM,
							  A.DL_EXPD_PAC_SCN_CD,
							  C.DL_EXPD_PRVS_NM AS DL_EXPD_PAC_SCN_NM,
							  A.DL_EXPD_PDI_CD,
							  D.DL_EXPD_PRVS_NM AS DL_EXPD_PDI_NM,
							  A.JB_MDY_REL_CD,
							  E.DL_EXPD_PRVS_NM AS JB_MDY_REL_NM,
							  FU_GET_PRDN_VEHL_LIST(A.QLTY_VEHL_CD, 'A') AS DYTM_PLN_VEHL_LIST,
							  FU_GET_PRDN_VEHL_LIST(A.QLTY_VEHL_CD, 'B') AS PRDN_MST_VEHL_LIST,
							  FU_GET_PRDN_VEHL_LIST(A.QLTY_VEHL_CD, 'C') AS BOM_VEHL_LIST,
							  FU_GET_PRDN_VEHL_LIST(A.QLTY_VEHL_CD, 'D') AS SALE_VEHL_LIST,
							  FU_GET_CRGR_USER_LIST(A.QLTY_VEHL_CD, A.MDL_MDY_CD, '01') AS USER_LIST1,
							  FU_GET_CRGR_USER_LIST(A.QLTY_VEHL_CD, A.MDL_MDY_CD, '02') AS USER_LIST2,
							  FU_GET_CRGR_USER_LIST(A.QLTY_VEHL_CD, A.MDL_MDY_CD, '03') AS USER_LIST3,
							  FU_GET_CRGR_USER_LIST(A.QLTY_VEHL_CD, A.MDL_MDY_CD, '04') AS USER_LIST4,
							  FU_GET_CRGR_USER_LIST(A.QLTY_VEHL_CD, A.MDL_MDY_CD, '05') AS USER_LIST5,
							  A.USE_YN
				       FROM TB_VEHL_MGMT A,
					        TB_CODE_MGMT B,
	 						TB_CODE_MGMT C,
	 						TB_CODE_MGMT D,
							TB_CODE_MGMT E,
							TB_VEHL_CRGR_MGMT F
					   WHERE A.DL_EXPD_CO_CD = B.DL_EXPD_PRVS_CD
					   AND B.DL_EXPD_G_CD = '0003'
					   AND A.DL_EXPD_PAC_SCN_CD = C.DL_EXPD_PRVS_CD
					   AND C.DL_EXPD_G_CD = '0004'
					   AND A.DL_EXPD_PDI_CD = D.DL_EXPD_PRVS_CD
					   AND D.DL_EXPD_G_CD = '0005'
					   AND A.JB_MDY_REL_CD = E.DL_EXPD_PRVS_CD
					   AND E.DL_EXPD_G_CD = '0007'
					   AND A.DL_EXPD_CO_CD = DECODE(P_EXPD_CO_CD, 'ALL', A.DL_EXPD_CO_CD, P_EXPD_CO_CD)
					   AND A.DL_EXPD_PDI_CD = DECODE(P_PDI_CD, 'ALL', A.DL_EXPD_PDI_CD, P_PDI_CD)
					   AND A.QLTY_VEHL_CD = DECODE(P_VEHL_CD, 'ALL', A.QLTY_VEHL_CD, P_VEHL_CD)
					   AND A.MDL_MDY_CD = P_MDL_MDY_CD
					   AND A.QLTY_VEHL_CD = F.QLTY_VEHL_CD
					   AND A.MDL_MDY_CD = F.MDL_MDY_CD
					   AND F.BLNS_CO_CD = '01'
					   AND F.CRGR_EENO = P_CRGR_EENO
					  );
					  
			END IF;
			  
	   END SP_GET_VEHL_MGMT2;
	   
	   PROCEDURE SP_GET_VEHL_MGMT3(P_MENU_ID 	VARCHAR2,
							  	   P_USER_EENO 	VARCHAR2,
	   			 				   P_EXPD_CO_CD VARCHAR2,
								   P_PAC_SCN_CD VARCHAR2,
	                               P_PDI_CD	    VARCHAR2,
								   P_VEHL_CD	VARCHAR2,
								   P_MDL_MDY_CD VARCHAR2,
								   P_CRGR_EENO  VARCHAR2,
	                               RS OUT REFCUR)
	   IS
	   	 
		 --V_FROM_MDL_MDY VARCHAR(2);
	 	 --V_TO_MDL_MDY   VARCHAR(2);
	 
	   BEGIN
	   		
			--PG_COMMON.SP_GET_VALID_MDL_MDY4(TO_CHAR(SYSDATE, 'YYYYMMDD'), '', V_FROM_MDL_MDY, V_TO_MDL_MDY);
			
			IF P_CRGR_EENO IS NULL OR P_CRGR_EENO = '' THEN
			   
			   OPEN RS FOR
				 SELECT A.*,
				 		FU_GET_MDY_REL_NM(A.QLTY_VEHL_CD, A.MDL_MDY_CD, B.EXPD_REGN_CD1) AS MDY_REL_NM1,
						FU_GET_MDY_REL_NM(A.QLTY_VEHL_CD, A.MDL_MDY_CD, B.EXPD_REGN_CD2) AS MDY_REL_NM2,
						FU_GET_MDY_REL_NM(A.QLTY_VEHL_CD, A.MDL_MDY_CD, B.EXPD_REGN_CD3) AS MDY_REL_NM3,
						FU_GET_MDY_REL_NM(A.QLTY_VEHL_CD, A.MDL_MDY_CD, B.EXPD_REGN_CD4) AS MDY_REL_NM4,
						FU_GET_MDY_REL_NM(A.QLTY_VEHL_CD, A.MDL_MDY_CD, B.EXPD_REGN_CD5) AS MDY_REL_NM5,
						FU_GET_MDY_REL_NM(A.QLTY_VEHL_CD, A.MDL_MDY_CD, B.EXPD_REGN_CD6) AS MDY_REL_NM6
				 FROM (SELECT A.QLTY_VEHL_CD,
				 	  		  A.MDL_MDY_CD,
							  A.DL_EXPD_CO_CD,
							  B.DL_EXPD_PRVS_NM AS DL_EXPD_CO_NM,
							  A.QLTY_VEHL_NM,
							  A.DL_EXPD_PAC_SCN_CD,
							  C.DL_EXPD_PRVS_NM AS DL_EXPD_PAC_SCN_NM,
							  A.DL_EXPD_PDI_CD,
							  D.DL_EXPD_PRVS_NM AS DL_EXPD_PDI_NM,
							  --A.JB_MDY_REL_CD,
							  --E.DL_EXPD_PRVS_NM AS JB_MDY_REL_NM,
							  NULL AS JB_MDY_REL_CD,
							  NULL AS JB_MDY_REL_NM,
							  FU_GET_PRDN_VEHL_LIST(A.QLTY_VEHL_CD, 'A') AS DYTM_PLN_VEHL_LIST,
							  FU_GET_PRDN_VEHL_LIST(A.QLTY_VEHL_CD, 'B') AS PRDN_MST_VEHL_LIST,
							  FU_GET_PRDN_VEHL_LIST(A.QLTY_VEHL_CD, 'C') AS BOM_VEHL_LIST,
							  FU_GET_PRDN_VEHL_LIST(A.QLTY_VEHL_CD, 'D') AS SALE_VEHL_LIST,
							  FU_GET_CRGR_USER_LIST(A.QLTY_VEHL_CD, MDL_MDY_CD, '01') AS USER_LIST1,
							  FU_GET_CRGR_USER_LIST(A.QLTY_VEHL_CD, MDL_MDY_CD, '02') AS USER_LIST2,
							  FU_GET_CRGR_USER_LIST(A.QLTY_VEHL_CD, MDL_MDY_CD, '03') AS USER_LIST3,
							  FU_GET_CRGR_USER_LIST(A.QLTY_VEHL_CD, MDL_MDY_CD, '04') AS USER_LIST4,
							  FU_GET_CRGR_USER_LIST(A.QLTY_VEHL_CD, MDL_MDY_CD, '05') AS USER_LIST5,
							  A.USE_YN
				       FROM TB_VEHL_MGMT A,
					        TB_CODE_MGMT B,
	 						TB_CODE_MGMT C,
	 						TB_CODE_MGMT D,
							--TB_CODE_MGMT E,
							(SELECT QLTY_VEHL_CD
                 			 FROM TB_AUTH_VEHL_MGMT
                 			 WHERE MENU_ID = PG_COMMON.FU_RPAD(P_MENU_ID, 10)
                 			 AND USER_EENO = PG_COMMON.FU_RPAD(P_USER_EENO, 7)
                 			 GROUP BY QLTY_VEHL_CD
                            ) F
					   WHERE A.DL_EXPD_CO_CD = B.DL_EXPD_PRVS_CD
					   AND B.DL_EXPD_G_CD = '0003'
					   AND A.DL_EXPD_PAC_SCN_CD = C.DL_EXPD_PRVS_CD
					   AND C.DL_EXPD_G_CD = '0004'
					   AND A.DL_EXPD_PDI_CD = D.DL_EXPD_PRVS_CD
					   AND D.DL_EXPD_G_CD = '0005'
					   --AND A.JB_MDY_REL_CD = E.DL_EXPD_PRVS_CD
					   --AND E.DL_EXPD_G_CD = '0007'
					   AND A.DL_EXPD_CO_CD = DECODE(P_EXPD_CO_CD, 'ALL', A.DL_EXPD_CO_CD, P_EXPD_CO_CD)
					   AND A.DL_EXPD_PAC_SCN_CD = DECODE(P_PAC_SCN_CD, 'ALL', A.DL_EXPD_PAC_SCN_CD, P_PAC_SCN_CD)
					   AND A.DL_EXPD_PDI_CD = DECODE(P_PDI_CD, 'ALL', A.DL_EXPD_PDI_CD, P_PDI_CD)
					   AND A.QLTY_VEHL_CD = DECODE(P_VEHL_CD, 'ALL', A.QLTY_VEHL_CD, P_VEHL_CD)
					   AND A.MDL_MDY_CD = P_MDL_MDY_CD
					   AND A.QLTY_VEHL_CD = F.QLTY_VEHL_CD
					   --AND A.MDL_MDY_CD BETWEEN V_FROM_MDL_MDY AND V_TO_MDL_MDY
					  ) A,
					  VW_EXPD_REGN_CD_VIEW B;
			
			ELSE
			
				OPEN RS FOR
				 SELECT A.*,
				        FU_GET_MDY_REL_NM(A.QLTY_VEHL_CD, A.MDL_MDY_CD, B.EXPD_REGN_CD1) AS MDY_REL_NM1,
						FU_GET_MDY_REL_NM(A.QLTY_VEHL_CD, A.MDL_MDY_CD, B.EXPD_REGN_CD2) AS MDY_REL_NM2,
						FU_GET_MDY_REL_NM(A.QLTY_VEHL_CD, A.MDL_MDY_CD, B.EXPD_REGN_CD3) AS MDY_REL_NM3,
						FU_GET_MDY_REL_NM(A.QLTY_VEHL_CD, A.MDL_MDY_CD, B.EXPD_REGN_CD4) AS MDY_REL_NM4,
						FU_GET_MDY_REL_NM(A.QLTY_VEHL_CD, A.MDL_MDY_CD, B.EXPD_REGN_CD5) AS MDY_REL_NM5,
						FU_GET_MDY_REL_NM(A.QLTY_VEHL_CD, A.MDL_MDY_CD, B.EXPD_REGN_CD6) AS MDY_REL_NM6
				 FROM (SELECT A.QLTY_VEHL_CD,
				 	  		  A.MDL_MDY_CD,
							  A.DL_EXPD_CO_CD,
							  B.DL_EXPD_PRVS_NM AS DL_EXPD_CO_NM,
							  A.QLTY_VEHL_NM,
							  A.DL_EXPD_PAC_SCN_CD,
							  C.DL_EXPD_PRVS_NM AS DL_EXPD_PAC_SCN_NM,
							  A.DL_EXPD_PDI_CD,
							  D.DL_EXPD_PRVS_NM AS DL_EXPD_PDI_NM,
							  --A.JB_MDY_REL_CD,
							  --E.DL_EXPD_PRVS_NM AS JB_MDY_REL_NM,
							  NULL AS JB_MDY_REL_CD,
							  NULL AS JB_MDY_REL_NM,
							  FU_GET_PRDN_VEHL_LIST(A.QLTY_VEHL_CD, 'A') AS DYTM_PLN_VEHL_LIST,
							  FU_GET_PRDN_VEHL_LIST(A.QLTY_VEHL_CD, 'B') AS PRDN_MST_VEHL_LIST,
							  FU_GET_PRDN_VEHL_LIST(A.QLTY_VEHL_CD, 'C') AS BOM_VEHL_LIST,
							  FU_GET_PRDN_VEHL_LIST(A.QLTY_VEHL_CD, 'D') AS SALE_VEHL_LIST,
							  FU_GET_CRGR_USER_LIST(A.QLTY_VEHL_CD, A.MDL_MDY_CD, '01') AS USER_LIST1,
							  FU_GET_CRGR_USER_LIST(A.QLTY_VEHL_CD, A.MDL_MDY_CD, '02') AS USER_LIST2,
							  FU_GET_CRGR_USER_LIST(A.QLTY_VEHL_CD, A.MDL_MDY_CD, '03') AS USER_LIST3,
							  FU_GET_CRGR_USER_LIST(A.QLTY_VEHL_CD, A.MDL_MDY_CD, '04') AS USER_LIST4,
							  FU_GET_CRGR_USER_LIST(A.QLTY_VEHL_CD, A.MDL_MDY_CD, '05') AS USER_LIST5,
							  A.USE_YN
				       FROM TB_VEHL_MGMT A,
					        TB_CODE_MGMT B,
	 						TB_CODE_MGMT C,
	 						TB_CODE_MGMT D,
							TB_CODE_MGMT E,
							TB_VEHL_CRGR_MGMT F,
							(SELECT QLTY_VEHL_CD
                 			 FROM TB_AUTH_VEHL_MGMT
                 			 WHERE MENU_ID = PG_COMMON.FU_RPAD(P_MENU_ID, 10)
                 			 AND USER_EENO = PG_COMMON.FU_RPAD(P_USER_EENO, 7)
                 			 GROUP BY QLTY_VEHL_CD
                            ) G
					   WHERE A.DL_EXPD_CO_CD = B.DL_EXPD_PRVS_CD
					   AND B.DL_EXPD_G_CD = '0003'
					   AND A.DL_EXPD_PAC_SCN_CD = C.DL_EXPD_PRVS_CD
					   AND C.DL_EXPD_G_CD = '0004'
					   AND A.DL_EXPD_PDI_CD = D.DL_EXPD_PRVS_CD
					   AND D.DL_EXPD_G_CD = '0005'
					   AND A.JB_MDY_REL_CD = E.DL_EXPD_PRVS_CD
					   AND E.DL_EXPD_G_CD = '0007'
					   AND A.DL_EXPD_CO_CD = DECODE(P_EXPD_CO_CD, 'ALL', A.DL_EXPD_CO_CD, P_EXPD_CO_CD)
					   AND A.DL_EXPD_PAC_SCN_CD = DECODE(P_PAC_SCN_CD, 'ALL', A.DL_EXPD_PAC_SCN_CD, P_PAC_SCN_CD)
					   AND A.DL_EXPD_PDI_CD = DECODE(P_PDI_CD, 'ALL', A.DL_EXPD_PDI_CD, P_PDI_CD)
					   AND A.QLTY_VEHL_CD = DECODE(P_VEHL_CD, 'ALL', A.QLTY_VEHL_CD, P_VEHL_CD)
					   AND A.MDL_MDY_CD = P_MDL_MDY_CD
					   AND A.QLTY_VEHL_CD = F.QLTY_VEHL_CD
					   AND A.MDL_MDY_CD = F.MDL_MDY_CD
					   AND F.BLNS_CO_CD = '01'
					   AND F.CRGR_EENO = P_CRGR_EENO
					   AND A.QLTY_VEHL_CD = G.QLTY_VEHL_CD
					   --AND A.MDL_MDY_CD BETWEEN V_FROM_MDL_MDY AND V_TO_MDL_MDY
					  ) A,
					  VW_EXPD_REGN_CD_VIEW B;
					  
			END IF;
			
	   END SP_GET_VEHL_MGMT3;
	   
	   --조회시에 차종코드에 관계된 APS, 생산마스터, BOM 차종을 가져오기 위한 함수 
	   FUNCTION FU_GET_PRDN_VEHL_LIST(P_QLTY_VEHL_CD VARCHAR2,
			 						  P_PRVS_SCN_CD  VARCHAR2 -- A: APS차종, B:생산마스터차종, C:BOM차종 (참고: 코드테이블 '0023')
									 ) RETURN VARCHAR2
	   IS
	   	 V_VEHL_LIST VARCHAR2(8000);
		
		 CURSOR VEHL_MGMT_LIST IS SELECT PRDN_VEHL_CD
	   	                          FROM TB_ALTN_VEHL_MGMT
							      WHERE QLTY_VEHL_CD  = P_QLTY_VEHL_CD
							      AND PRVS_SCN_CD = P_PRVS_SCN_CD
							      ORDER BY PRDN_VEHL_CD;
											 
	  BEGIN
	  	
		V_VEHL_LIST := '';
		
		FOR VEHL_LIST IN VEHL_MGMT_LIST LOOP
			
			V_VEHL_LIST := V_VEHL_LIST || VEHL_LIST.PRDN_VEHL_CD || ',';
			
		END LOOP;
		
		IF LENGTH(V_VEHL_LIST) > 0 THEN
		   
		   V_VEHL_LIST := SUBSTR(V_VEHL_LIST, 1, LENGTH(V_VEHL_LIST) - 1);
		   
		END IF;

		RETURN V_VEHL_LIST;
	   
	   END FU_GET_PRDN_VEHL_LIST;
	   
	   FUNCTION FU_GET_CRGR_USER_LIST(P_QLTY_VEHL_CD VARCHAR2,
	                                  P_MDL_MDY_CD   VARCHAR2,
	                                  P_BLNS_CO_CD   VARCHAR2
									 ) RETURN VARCHAR2
	   IS
	   	 V_USER_LIST VARCHAR2(8000);
		
		 CURSOR USER_MGMT_LIST IS SELECT B.USER_NM
	   	                          FROM TB_VEHL_CRGR_MGMT A,
								  	   TB_USR_MGMT B
							      WHERE A.QLTY_VEHL_CD  = P_QLTY_VEHL_CD
								  AND A.MDL_MDY_CD = P_MDL_MDY_CD
							      AND A.BLNS_CO_CD = P_BLNS_CO_CD
								  AND A.CRGR_EENO = B.USER_EENO
							      ORDER BY A.CRGR_EENO;
											 
	  BEGIN
	  	
		V_USER_LIST := '';
		
		FOR USER_LIST IN USER_MGMT_LIST LOOP
			
			V_USER_LIST := V_USER_LIST || USER_LIST.USER_NM || ',';
			
		END LOOP;
		
		IF LENGTH(V_USER_LIST) > 0 THEN
		   
		   V_USER_LIST := SUBSTR(V_USER_LIST, 1, LENGTH(V_USER_LIST) - 1);
		   
		END IF;

		RETURN V_USER_LIST;
	   
	   END FU_GET_CRGR_USER_LIST;
	   
	   --그룹별 담당자 아이디 리스트를 얻어오는 함수 
	   FUNCTION FU_GET_CRGR_USER_ID_LIST(P_QLTY_VEHL_CD VARCHAR2,
	                                     P_MDL_MDY_CD   VARCHAR2,
	                                     P_BLNS_CO_CD   VARCHAR2
								        ) RETURN VARCHAR2
	   IS
	   	 
		 V_USER_ID_LIST VARCHAR2(8000);
	   
	   	 CURSOR USER_MGMT_LIST IS SELECT A.CRGR_EENO
	   	                          FROM TB_VEHL_CRGR_MGMT A
							      WHERE A.QLTY_VEHL_CD  = P_QLTY_VEHL_CD
								  AND A.MDL_MDY_CD = P_MDL_MDY_CD
							      AND A.BLNS_CO_CD = P_BLNS_CO_CD
							      ORDER BY A.CRGR_EENO;
	   BEGIN
	   		
			V_USER_ID_LIST := '';
		
			FOR USER_LIST IN USER_MGMT_LIST LOOP
			
				V_USER_ID_LIST := V_USER_ID_LIST || USER_LIST.CRGR_EENO || ',';
			
			END LOOP;
		
			IF LENGTH(V_USER_ID_LIST) > 0 THEN
		   
		   	   V_USER_ID_LIST := SUBSTR(V_USER_ID_LIST, 1, LENGTH(V_USER_ID_LIST) - 1);
		   
		    END IF;
		
			RETURN V_USER_ID_LIST;
	   		
			
	   END FU_GET_CRGR_USER_ID_LIST;
	   
	   --차종 연식 관계 정보를 가져오기 위한 함수 								 
	   FUNCTION FU_GET_MDY_REL_CD(P_QLTY_VEHL_CD VARCHAR2,
	                              P_MDL_MDY_CD   VARCHAR2,
								  P_EXPD_REGN_CD VARCHAR2
								 ) RETURN VARCHAR2
	   IS
	   	 
		 V_MDY_REL_CD VARCHAR2(4);
		 
	   BEGIN
	     
	   	 SELECT MAX(JB_MDY_REL_CD)
		 INTO V_MDY_REL_CD
		 FROM TB_VEHL_MDY_REL_MGMT
		 WHERE QLTY_VEHL_CD = P_QLTY_VEHL_CD
		 AND MDL_MDY_CD = P_MDL_MDY_CD
		 AND DL_EXPD_REGN_CD = P_EXPD_REGN_CD;
		 
		 RETURN V_MDY_REL_CD;
		 
	   END FU_GET_MDY_REL_CD;
	   
	   --차종 연식 관계 명칭을 가져오기 위한 함수 								 
	   FUNCTION FU_GET_MDY_REL_NM(P_QLTY_VEHL_CD VARCHAR2,
	                              P_MDL_MDY_CD   VARCHAR2,
								  P_EXPD_REGN_CD VARCHAR2
								 ) RETURN VARCHAR2
	   IS
	   	 
		 V_MDL_REL_NM VARCHAR2(200);
		 
	   BEGIN
	     
		 SELECT MAX(B.DL_EXPD_PRVS_NM)
		 INTO V_MDL_REL_NM
		 FROM TB_VEHL_MDY_REL_MGMT A,
		 	  TB_CODE_MGMT B
		 WHERE QLTY_VEHL_CD = P_QLTY_VEHL_CD
		 AND MDL_MDY_CD = P_MDL_MDY_CD
		 AND DL_EXPD_REGN_CD = P_EXPD_REGN_CD
		 AND A.JB_MDY_REL_CD = B.DL_EXPD_PRVS_CD
		 AND B.DL_EXPD_G_CD = '0007';
		 
		 RETURN V_MDL_REL_NM;
		 
	   END FU_GET_MDY_REL_NM;
	   
	   PROCEDURE SP_GET_EXPD_REGN_LIST(RS OUT REFCUR)
	   IS
	   BEGIN
	   		
			OPEN RS FOR
				 SELECT *
				 FROM VW_EXPD_REGN_NM_VIEW;
				 
	   END SP_GET_EXPD_REGN_LIST;
	   
	   --그룹별 담당자 아이디, 이름 리스트를 가져오기 위한 프로시저
	   PROCEDURE GET_CRGR_USER_LIST(P_QLTY_VEHL_CD VARCHAR2,
	                                P_MDL_MDY_CD   VARCHAR2,
	                                P_BLNS_CO_CD   VARCHAR2,
									P_USER_ID_LIST OUT VARCHAR2,
									P_USER_NM_LIST OUT VARCHAR2
								   )
	   IS
	   	 
		 CURSOR USER_MGMT_LIST IS SELECT A.CRGR_EENO, B.USER_NM
	   	                          FROM TB_VEHL_CRGR_MGMT A,
								  	   TB_USR_MGMT B
							      WHERE A.QLTY_VEHL_CD  = P_QLTY_VEHL_CD
								  AND A.MDL_MDY_CD = P_MDL_MDY_CD
							      AND A.BLNS_CO_CD = P_BLNS_CO_CD
								  AND A.CRGR_EENO = B.USER_EENO
							      ORDER BY A.CRGR_EENO;
											 
	  BEGIN
	  	
		P_USER_ID_LIST := '';
		P_USER_NM_LIST := '';
		
		FOR USER_LIST IN USER_MGMT_LIST LOOP
			
			P_USER_ID_LIST := P_USER_ID_LIST || USER_LIST.CRGR_EENO || ',';
			P_USER_NM_LIST := P_USER_NM_LIST || USER_LIST.USER_NM || ',';
			
		END LOOP;
		
		IF LENGTH(P_USER_ID_LIST) > 0 THEN
		   
		   P_USER_ID_LIST := SUBSTR(P_USER_ID_LIST, 1, LENGTH(P_USER_ID_LIST) - 1);
		   
		END IF;
		
		IF LENGTH(P_USER_NM_LIST) > 0 THEN
		   
		   P_USER_NM_LIST := SUBSTR(P_USER_NM_LIST, 1, LENGTH(P_USER_NM_LIST) - 1);
		   
		END IF;
		
	   END GET_CRGR_USER_LIST;
	   
	   --수정시에 차종코드에 해당하는 정보를 조회 
	   PROCEDURE SP_GET_VEHL_INFO(P_QLTY_VEHL_CD VARCHAR2,
	                              P_MDL_MDY_CD   VARCHAR2,
								  RS OUT REFCUR)
	   IS
	   	 V_USER_ID_LIST1 VARCHAR2(8000);
		 V_USER_NM_LIST1 VARCHAR2(8000);
		 V_USER_ID_LIST2 VARCHAR2(8000);
		 V_USER_NM_LIST2 VARCHAR2(8000);
		 V_USER_ID_LIST3 VARCHAR2(8000);
		 V_USER_NM_LIST3 VARCHAR2(8000);
		 V_USER_ID_LIST4 VARCHAR2(8000);
		 V_USER_NM_LIST4 VARCHAR2(8000);
		 V_USER_ID_LIST5 VARCHAR2(8000);
		 V_USER_NM_LIST5 VARCHAR2(8000);
		 
	   BEGIN
	   		
			GET_CRGR_USER_LIST(P_QLTY_VEHL_CD, P_MDL_MDY_CD, '01', V_USER_ID_LIST1, V_USER_NM_LIST1);
			GET_CRGR_USER_LIST(P_QLTY_VEHL_CD, P_MDL_MDY_CD, '02', V_USER_ID_LIST2, V_USER_NM_LIST2);
			GET_CRGR_USER_LIST(P_QLTY_VEHL_CD, P_MDL_MDY_CD, '03', V_USER_ID_LIST3, V_USER_NM_LIST3);
			GET_CRGR_USER_LIST(P_QLTY_VEHL_CD, P_MDL_MDY_CD, '04', V_USER_ID_LIST4, V_USER_NM_LIST4);
			GET_CRGR_USER_LIST(P_QLTY_VEHL_CD, P_MDL_MDY_CD, '05', V_USER_ID_LIST5, V_USER_NM_LIST5);
			
			OPEN RS FOR
	   			 SELECT A.*,
				 		FU_GET_MDY_REL_CD(A.QLTY_VEHL_CD, A.MDL_MDY_CD, B.EXPD_REGN_CD1) AS MDY_REL_CD1,
						FU_GET_MDY_REL_CD(A.QLTY_VEHL_CD, A.MDL_MDY_CD, B.EXPD_REGN_CD2) AS MDY_REL_CD2,
						FU_GET_MDY_REL_CD(A.QLTY_VEHL_CD, A.MDL_MDY_CD, B.EXPD_REGN_CD3) AS MDY_REL_CD3,
						FU_GET_MDY_REL_CD(A.QLTY_VEHL_CD, A.MDL_MDY_CD, B.EXPD_REGN_CD4) AS MDY_REL_CD4,
						FU_GET_MDY_REL_CD(A.QLTY_VEHL_CD, A.MDL_MDY_CD, B.EXPD_REGN_CD5) AS MDY_REL_CD5,
						FU_GET_MDY_REL_CD(A.QLTY_VEHL_CD, A.MDL_MDY_CD, B.EXPD_REGN_CD6) AS MDY_REL_CD6
				 FROM (SELECT A.QLTY_VEHL_CD,
				   		      A.MDL_MDY_CD,
				  		      A.DL_EXPD_CO_CD,
					    	  B.DL_EXPD_PRVS_NM AS DL_EXPD_CO_NM,
					    	  A.QLTY_VEHL_NM,
							  A.DL_EXPD_PAC_SCN_CD,
							  C.DL_EXPD_PRVS_NM AS DL_EXPD_PAC_SCN_NM,
							  A.DL_EXPD_PDI_CD,
							  D.DL_EXPD_PRVS_NM AS DL_EXPD_PDI_NM,
							  --A.JB_MDY_REL_CD,
							  --E.DL_EXPD_PRVS_NM AS JB_MDY_REL_NM,
							  NULL AS JB_MDY_REL_CD,
							  NULL AS JB_MDY_REL_NM,
							  FU_GET_PRDN_VEHL_LIST(A.QLTY_VEHL_CD, 'A') AS DYTM_PLN_VEHL_LIST,
							  FU_GET_PRDN_VEHL_LIST(A.QLTY_VEHL_CD, 'B') AS PRDN_MST_VEHL_LIST,
							  FU_GET_PRDN_VEHL_LIST(A.QLTY_VEHL_CD, 'C') AS BOM_VEHL_LIST,
							  FU_GET_PRDN_VEHL_LIST(A.QLTY_VEHL_CD, 'D') AS SALE_VEHL_LIST,
							  V_USER_ID_LIST1 AS USER_ID_LIST1,
							  V_USER_NM_LIST1 AS USER_NM_LIST1,
							  V_USER_ID_LIST2 AS USER_ID_LIST2,
							  V_USER_NM_LIST2 AS USER_NM_LIST2,
							  V_USER_ID_LIST3 AS USER_ID_LIST3,
							  V_USER_NM_LIST3 AS USER_NM_LIST3,
							  V_USER_ID_LIST4 AS USER_ID_LIST4,
							  V_USER_NM_LIST4 AS USER_NM_LIST4,
							  V_USER_ID_LIST5 AS USER_ID_LIST5,
							  V_USER_NM_LIST5 AS USER_NM_LIST5,
							  A.USE_YN
				       FROM TB_VEHL_MGMT A,
					        TB_CODE_MGMT B,
	 				        TB_CODE_MGMT C,
							--TB_CODE_MGMT E,
	 				        TB_CODE_MGMT D 
				       WHERE A.DL_EXPD_CO_CD = B.DL_EXPD_PRVS_CD
				 	   AND B.DL_EXPD_G_CD = '0003'
				 	   AND A.DL_EXPD_PAC_SCN_CD = C.DL_EXPD_PRVS_CD
				 	   AND C.DL_EXPD_G_CD = '0004'
				 	   AND A.DL_EXPD_PDI_CD = D.DL_EXPD_PRVS_CD
				 	   AND D.DL_EXPD_G_CD = '0005'
				 	   --AND A.JB_MDY_REL_CD = E.DL_EXPD_PRVS_CD
				 	   --AND E.DL_EXPD_G_CD = '0007' 
				 	   AND A.QLTY_VEHL_CD = P_QLTY_VEHL_CD
				 	   AND A.MDL_MDY_CD = P_MDL_MDY_CD
					  ) A,
					  VW_EXPD_REGN_CD_VIEW B;
	   
	   END SP_GET_VEHL_INFO;
	   
	   --차종코드 정보 저장 
	   PROCEDURE SP_VEHL_INFO_SAVE(P_QLTY_VEHL_CD       VARCHAR2,
	                               P_MDL_MDY_CD         VARCHAR2,
								   P_EXPD_CO_CD         VARCHAR2,
								   P_PAC_SCN_CD         VARCHAR2,
								   P_PDI_CD		        VARCHAR2,
								   P_VEHL_NM			VARCHAR2,
								   P_JB_MDY_REL_CD      VARCHAR2,
								   P_DYTM_PLN_VEHL_LIST VARCHAR2,
								   P_PRDN_MST_VEHL_LIST VARCHAR2,
								   P_BOM_VEHL_LIST      VARCHAR2,
								   P_SALE_VEHL_LIST     VARCHAR2,
								   USER_ID_LIST1        VARCHAR2,
								   USER_ID_LIST2        VARCHAR2,
								   USER_ID_LIST3        VARCHAR2,
								   USER_ID_LIST4        VARCHAR2,
								   USER_ID_LIST5        VARCHAR2,
								   P_USE_YN				VARCHAR2,
								   P_USER_EENO			VARCHAR2,
								   P_MDY_REL_CD1		VARCHAR2,
								   P_MDY_REL_CD2		VARCHAR2,
								   P_MDY_REL_CD3		VARCHAR2,
								   P_MDY_REL_CD4		VARCHAR2,
								   P_MDY_REL_CD5		VARCHAR2,
								   P_MDY_REL_CD6		VARCHAR2,
								   P_ET_YN				CHAR)
	   IS
	   
	   	 V_CNT         NUMBER;
--		 V_PREV_PDI_CD VARCHAR2(4);
		 
--		 --이전연식 
--		 V_PREV_MDL_MDY_CD VARCHAR2(2);
--		 V_PREV_MDY_REL_CD VARCHAR2(4);
		 
--		 --이후연식 
--		 V_NEXT_MDL_MDY_CD VARCHAR2(2);
--		 V_NEXT_MDY_REL_CD VARCHAR2(4);
		 
		 V_EXPD_REGN_CD1 VARCHAR2(4);
		 V_EXPD_REGN_CD2 VARCHAR2(4);
		 V_EXPD_REGN_CD3 VARCHAR2(4);
		 V_EXPD_REGN_CD4 VARCHAR2(4);
		 V_EXPD_REGN_CD5 VARCHAR2(4);
		 V_EXPD_REGN_CD6 VARCHAR2(4);
		 
	   BEGIN
	   		
			--차종이 같은 코드가 다른 승상구분에 존재한 다면 저장하지 않고 에러를 발생시킨다. 
			SELECT COUNT(*)
			INTO V_CNT
			FROM TB_VEHL_MGMT
			WHERE QLTY_VEHL_CD = P_QLTY_VEHL_CD
			AND DL_EXPD_PAC_SCN_CD = (CASE WHEN P_PAC_SCN_CD = '01' THEN '02' ELSE '01' END);
			
			IF V_CNT > 0 THEN
			   
			   RAISE_APPLICATION_ERROR(-20001, 'Invalid vehl information. existing vehl code - vehl:[' || P_QLTY_VEHL_CD || '] year:[' || P_MDL_MDY_CD || '] pacscn:[' || P_PAC_SCN_CD || ']');
			   
			END IF;
			
			SELECT EXPD_REGN_CD1,
				   EXPD_REGN_CD2,
				   EXPD_REGN_CD3,
				   EXPD_REGN_CD4,
				   EXPD_REGN_CD5,
				   EXPD_REGN_CD6
			INTO V_EXPD_REGN_CD1,
				 V_EXPD_REGN_CD2,
				 V_EXPD_REGN_CD3,
				 V_EXPD_REGN_CD4,
				 V_EXPD_REGN_CD5,
				 V_EXPD_REGN_CD6
			FROM VW_EXPD_REGN_CD_VIEW;
				 
			--차종명칭은 해당 차종코드를 사용하는 모든 내역이 변경되도록 처리해 준다. 
			UPDATE TB_VEHL_MGMT
			SET QLTY_VEHL_NM = P_VEHL_NM
			WHERE QLTY_VEHL_CD = P_QLTY_VEHL_CD;
			
--			--업데이트 이전에 이미 입력되어 있는 PDI정보를 조회한다. 
--			SELECT NVL(MAX(DL_EXPD_PDI_CD), '')
--			INTO V_PREV_PDI_CD
--			FROM TB_VEHL_MGMT
--			WHERE QLTY_VEHL_CD = P_QLTY_VEHL_CD
--			AND MDL_MDY_CD = P_MDL_MDY_CD;
			
			UPDATE TB_VEHL_MGMT
			SET DL_EXPD_CO_CD      = P_EXPD_CO_CD,
			    QLTY_VEHL_NM       = P_VEHL_NM,
				DL_EXPD_PAC_SCN_CD = P_PAC_SCN_CD,
				DL_EXPD_PDI_CD     = P_PDI_CD,
				JB_MDY_REL_CD      = P_JB_MDY_REL_CD,
				USE_YN             = P_USE_YN,
				UPDR_EENO          = P_USER_EENO,
				MDFY_DTM           = SYSDATE,
				ET_YN              = P_ET_YN
			WHERE QLTY_VEHL_CD = P_QLTY_VEHL_CD
			AND MDL_MDY_CD     = P_MDL_MDY_CD;
			
			IF SQL%NOTFOUND THEN
			   
			   SELECT COUNT(*)
			   INTO V_CNT
			   FROM TB_VEHL_MGMT
			   WHERE QLTY_VEHL_CD = P_QLTY_VEHL_CD
			   AND ROWNUM <= 1;
			   
			   --아직 한번도 저장된 적이 없는 차종인 경우에는 입력권한관리자에 입력권한을 지정하여 준다. 
			   --IF V_CNT = 0 THEN
			   	  
				--  SP_UPDATE_VEHL_AUTH(P_QLTY_VEHL_CD, P_PAC_SCN_CD);
									 
			   --END IF;
			   
			   INSERT INTO TB_VEHL_MGMT
			   (QLTY_VEHL_CD,
			    MDL_MDY_CD,
				DL_EXPD_CO_CD,
				QLTY_VEHL_NM,
				DL_EXPD_PAC_SCN_CD,
				DL_EXPD_PDI_CD,
				JB_MDY_REL_CD,
				USE_YN,
				PPRR_EENO,
				FRAM_DTM,
				UPDR_EENO,
				MDFY_DTM,
				ET_YN
			   )
			   VALUES
			   (P_QLTY_VEHL_CD,
			    P_MDL_MDY_CD,
				P_EXPD_CO_CD,
				P_VEHL_NM,
				P_PAC_SCN_CD,
				P_PDI_CD,
				P_JB_MDY_REL_CD,
				P_USE_YN,
				P_USER_EENO,
				SYSDATE,
				P_USER_EENO,
				SYSDATE,
				P_ET_YN
			   );
			   
			   --언어코드정보와 국가코드정보를 복사
			   SP_VEHL_MDY_COPY(P_QLTY_VEHL_CD,
	   							P_MDL_MDY_CD,
								P_USER_EENO);
								
--			   IF V_PREV_PDI_CD <> P_PDI_CD THEN 
			   
			   	  --신규 등록되는 차종의 경우 PDI 공통차종이 지정되어 있다면 그것에 같이 묶어준다. 
			   	  PG_LANG_MGMT.SP_N1_INS_YN_UPD_PDI(P_QLTY_VEHL_CD, 
											     	P_MDL_MDY_CD, 
											     	P_PDI_CD, 
											     	P_USER_EENO);
											  
--			   END IF;
								
			END IF;
			
			SP_PRDN_VEHL_LIST_SAVE(P_QLTY_VEHL_CD, 'A', P_DYTM_PLN_VEHL_LIST, P_USER_EENO);
			SP_PRDN_VEHL_LIST_SAVE(P_QLTY_VEHL_CD, 'B', P_PRDN_MST_VEHL_LIST, P_USER_EENO);
			SP_PRDN_VEHL_LIST_SAVE(P_QLTY_VEHL_CD, 'C', P_BOM_VEHL_LIST,      P_USER_EENO);
			SP_PRDN_VEHL_LIST_SAVE(P_QLTY_VEHL_CD, 'D', P_SALE_VEHL_LIST,     P_USER_EENO);
			
			SP_CRGR_USER_LIST_SAVE(P_QLTY_VEHL_CD, P_MDL_MDY_CD, '01', USER_ID_LIST1, P_USER_EENO);
			SP_CRGR_USER_LIST_SAVE(P_QLTY_VEHL_CD, P_MDL_MDY_CD, '02', USER_ID_LIST2, P_USER_EENO);
			SP_CRGR_USER_LIST_SAVE(P_QLTY_VEHL_CD, P_MDL_MDY_CD, '03', USER_ID_LIST3, P_USER_EENO);
			SP_CRGR_USER_LIST_SAVE(P_QLTY_VEHL_CD, P_MDL_MDY_CD, '04', USER_ID_LIST4, P_USER_EENO);
			SP_CRGR_USER_LIST_SAVE(P_QLTY_VEHL_CD, P_MDL_MDY_CD, '05', USER_ID_LIST5, P_USER_EENO);
			
			SP_MDY_REL_CD_SAVE(P_QLTY_VEHL_CD, P_MDL_MDY_CD, V_EXPD_REGN_CD1, P_MDY_REL_CD1, P_USER_EENO);
			SP_MDY_REL_CD_SAVE(P_QLTY_VEHL_CD, P_MDL_MDY_CD, V_EXPD_REGN_CD2, P_MDY_REL_CD2, P_USER_EENO);
			SP_MDY_REL_CD_SAVE(P_QLTY_VEHL_CD, P_MDL_MDY_CD, V_EXPD_REGN_CD3, P_MDY_REL_CD3, P_USER_EENO);
			SP_MDY_REL_CD_SAVE(P_QLTY_VEHL_CD, P_MDL_MDY_CD, V_EXPD_REGN_CD4, P_MDY_REL_CD4, P_USER_EENO);
			SP_MDY_REL_CD_SAVE(P_QLTY_VEHL_CD, P_MDL_MDY_CD, V_EXPD_REGN_CD5, P_MDY_REL_CD5, P_USER_EENO);
			SP_MDY_REL_CD_SAVE(P_QLTY_VEHL_CD, P_MDL_MDY_CD, V_EXPD_REGN_CD6, P_MDY_REL_CD6, P_USER_EENO);
			
			/***********
			--이전연식 계산 
			SELECT MAX(MDL_MDY_CD)
			INTO V_PREV_MDL_MDY_CD
			FROM TB_VEHL_MGMT
			WHERE QLTY_VEHL_CD = P_QLTY_VEHL_CD
			AND MDL_MDY_CD < P_MDL_MDY_CD;
			
			IF V_PREV_MDL_MDY_CD IS NOT NULL THEN
			   
			   SELECT MAX(JB_MDY_REL_CD)
			   INTO V_PREV_MDY_REL_CD
			   FROM TB_VEHL_MGMT
			   WHERE QLTY_VEHL_CD = P_QLTY_VEHL_CD
			   AND MDL_MDY_CD = V_PREV_MDL_MDY_CD;
			   
--			   --이전연식의 진전연식통합관계가 완전통합, 전방통합일 경우에만 작업 수행 
--			   IF V_PREV_MDY_REL_CD IN ('01', '02') THEN
--			   	  
--				  SP_VEHL_MDY_REL_CD_UPDATE(P_QLTY_VEHL_CD,
--	   							            V_PREV_MDL_MDY_CD,
--									        V_PREV_MDY_REL_CD,
--								            P_USER_EENO);
--									  
--			   END IF;
			   
			   SP_VEHL_MDY_REL_CD_UPDATE(P_QLTY_VEHL_CD,
	   							         V_PREV_MDL_MDY_CD,
									     V_PREV_MDY_REL_CD,
								         P_USER_EENO);		
			END IF;
			
			--이후연식 계산 
			SELECT MIN(MDL_MDY_CD)
			INTO V_NEXT_MDL_MDY_CD
			FROM TB_VEHL_MGMT
			WHERE QLTY_VEHL_CD = P_QLTY_VEHL_CD
			AND MDL_MDY_CD > P_MDL_MDY_CD;
			
			IF V_PREV_MDL_MDY_CD IS NOT NULL THEN
			   
			   SELECT MAX(JB_MDY_REL_CD)
			   INTO V_NEXT_MDY_REL_CD
			   FROM TB_VEHL_MGMT
			   WHERE QLTY_VEHL_CD = P_QLTY_VEHL_CD
			   AND MDL_MDY_CD = V_NEXT_MDL_MDY_CD;
			   
--			   --이후연식의 진전연식통합관계가 완전통합, 후방통합일 경우에만 작업 수행 
--			   IF V_NEXT_MDY_REL_CD IN ('01', '03') THEN 
--			   	  
--				  SP_VEHL_MDY_REL_CD_UPDATE(P_QLTY_VEHL_CD,
--	   							            V_NEXT_MDL_MDY_CD,
--									        V_NEXT_MDY_REL_CD,
--								            P_USER_EENO);
--									  
--			   END IF;
			   
			   SP_VEHL_MDY_REL_CD_UPDATE(P_QLTY_VEHL_CD,
	   							         V_NEXT_MDL_MDY_CD,
									     V_NEXT_MDY_REL_CD,
								         P_USER_EENO);					
			END IF;
			***********/ 
			
			--직전연식관계 변화에 따른 취급설명서 연식코드 매핑 작업 수행 
			SP_VEHL_MDY_REL_CD_UPDATE(P_QLTY_VEHL_CD, P_MDL_MDY_CD, V_EXPD_REGN_CD1, P_MDY_REL_CD1, P_USER_EENO);
			SP_VEHL_MDY_REL_CD_UPDATE(P_QLTY_VEHL_CD, P_MDL_MDY_CD, V_EXPD_REGN_CD2, P_MDY_REL_CD2, P_USER_EENO);
			SP_VEHL_MDY_REL_CD_UPDATE(P_QLTY_VEHL_CD, P_MDL_MDY_CD, V_EXPD_REGN_CD3, P_MDY_REL_CD3, P_USER_EENO);
			SP_VEHL_MDY_REL_CD_UPDATE(P_QLTY_VEHL_CD, P_MDL_MDY_CD, V_EXPD_REGN_CD4, P_MDY_REL_CD4, P_USER_EENO);
			SP_VEHL_MDY_REL_CD_UPDATE(P_QLTY_VEHL_CD, P_MDL_MDY_CD, V_EXPD_REGN_CD5, P_MDY_REL_CD5, P_USER_EENO);
			SP_VEHL_MDY_REL_CD_UPDATE(P_QLTY_VEHL_CD, P_MDL_MDY_CD, V_EXPD_REGN_CD6, P_MDY_REL_CD6, P_USER_EENO);
			
	   END SP_VEHL_INFO_SAVE;
	   
	   --GOMS로 부터 실시간 데이터 연계 위해 호출되는 프로시저 
	   PROCEDURE SP_VEHL_INFO_SAVE_IF(P_QLTY_VEHL_CD       VARCHAR2,
	                                  P_MDL_MDY_CD         VARCHAR2,
								      P_EXPD_CO_CD         VARCHAR2,
								   	  P_PAC_SCN_CD         VARCHAR2,
								   	  P_PDI_CD		       VARCHAR2,
   								   	  P_VEHL_NM			   VARCHAR2,
   								   	  P_JB_MDY_REL_CD      VARCHAR2,
   								   	  P_DYTM_PLN_VEHL_LIST VARCHAR2,
   								   	  P_PRDN_MST_VEHL_LIST VARCHAR2,
   								   	  P_BOM_VEHL_LIST      VARCHAR2,
   								   	  P_SALE_VEHL_LIST     VARCHAR2,
   								   	  P_USER_ID_LIST1      VARCHAR2,
   								   	  P_USER_ID_LIST2      VARCHAR2,
   								   	  P_USE_YN			   VARCHAR2,
   								   	  P_USER_EENO		   VARCHAR2,
   								   	  P_MDY_REL_CD1		   VARCHAR2,
   								   	  P_MDY_REL_CD2		   VARCHAR2,
   								   	  P_MDY_REL_CD3		   VARCHAR2,
   								   	  P_MDY_REL_CD4		   VARCHAR2,
   								   	  P_MDY_REL_CD5		   VARCHAR2,
   								   	  P_MDY_REL_CD6		   VARCHAR2)
       IS
	   BEGIN
	   		
			SP_VEHL_INFO_SAVE(P_QLTY_VEHL_CD,
							  P_MDL_MDY_CD,
							  P_EXPD_CO_CD,
							  P_PAC_SCN_CD,
							  P_PDI_CD,
							  P_VEHL_NM,
							  P_JB_MDY_REL_CD,
							  P_DYTM_PLN_VEHL_LIST,
							  P_PRDN_MST_VEHL_LIST,
							  P_BOM_VEHL_LIST,
							  P_SALE_VEHL_LIST,
							  P_USER_ID_LIST1,
							  P_USER_ID_LIST2,
							  --세원, PDI, 글로비스의 사용자는 IF 하지 않는다.
							  'INTERFACE',
							  'INTERFACE',
							  'INTERFACE',
							  P_USE_YN,
							  P_USER_EENO,
							  P_MDY_REL_CD1,
							  P_MDY_REL_CD2,
							  P_MDY_REL_CD3,
							  P_MDY_REL_CD4,
							  P_MDY_REL_CD5,
							  P_MDY_REL_CD6,
							  'Y');
			
			COMMIT;
			
	   END SP_VEHL_INFO_SAVE_IF;
	   
	   PROCEDURE SP_MDY_REL_CD_SAVE(P_QLTY_VEHL_CD VARCHAR2,
	                                P_MDL_MDY_CD   VARCHAR2,
									P_EXPD_REGN_CD VARCHAR2,
									P_MDY_REL_CD   VARCHAR2,
									P_USER_EENO	   VARCHAR2)
	   IS
	   BEGIN
	   		
			UPDATE TB_VEHL_MDY_REL_MGMT
			SET JB_MDY_REL_CD = P_MDY_REL_CD,
			    UPDR_EENO = P_USER_EENO,
				MDFY_DTM = SYSDATE
			WHERE QLTY_VEHL_CD = P_QLTY_VEHL_CD
			AND MDL_MDY_CD = P_MDL_MDY_CD
			AND DL_EXPD_REGN_CD = P_EXPD_REGN_CD;
			
			IF SQL%NOTFOUND THEN
			   
			   INSERT INTO TB_VEHL_MDY_REL_MGMT
			   (QLTY_VEHL_CD,
			    MDL_MDY_CD,
				DL_EXPD_REGN_CD,
				JB_MDY_REL_CD,
				PPRR_EENO,
				FRAM_DTM,
				UPDR_EENO,
				MDFY_DTM
			   )
			   VALUES
			   (P_QLTY_VEHL_CD,
			    P_MDL_MDY_CD,
				P_EXPD_REGN_CD,
				P_MDY_REL_CD,
				P_USER_EENO,
				SYSDATE,
				P_USER_EENO,
				SYSDATE
			   );
			   
			END IF;
			
	   END SP_MDY_REL_CD_SAVE;
	   
	   --연식관리 내역 조회 							   
	   PROCEDURE SP_GET_VEHL_MDY_MGMT(P_EXPD_CO_CD   VARCHAR2,
	   			 					  P_PAC_SCN_CD   VARCHAR2,
							  		  P_PDI_CD		 VARCHAR2,
	                                  P_QLTY_VEHL_CD VARCHAR2,
									  P_REGN_CD      VARCHAR2,
									  P_FROM_YMD	 VARCHAR2,
									  P_TO_YMD		 VARCHAR2,
									  RS OUT REFCUR)
	   IS
	   BEGIN
	   		
			OPEN RS FOR
				 SELECT B.QLTY_VEHL_CD, 
				        B.QLTY_VEHL_NM,
						A.DL_EXPD_REGN_CD,
						C.DL_EXPD_PRVS_NM AS DL_EXPD_REGN_NM,
						A.DESMP1_CD,
						--DECODE(A.DEFMP1_CD, '9999', '', A.DEFMP1_CD) AS DEFMP1_CD,
						A.DEFMP1_CD,
						A.MDL_MDY_CD
				 FROM TB_VEHL_MDY_MGMT A,
				 	  TB_VEHL_MGMT B,
					  TB_CODE_MGMT C
				 WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
				 AND A.MDL_MDY_CD = B.MDL_MDY_CD
				 AND A.DL_EXPD_REGN_CD = C.DL_EXPD_PRVS_CD
				 AND C.DL_EXPD_G_CD = '0008'
				 AND B.QLTY_VEHL_CD = DECODE(P_QLTY_VEHL_CD, 'ALL', B.QLTY_VEHL_CD, P_QLTY_VEHL_CD)
				 AND B.DL_EXPD_CO_CD = DECODE(P_EXPD_CO_CD, 'ALL', B.DL_EXPD_CO_CD, P_EXPD_CO_CD)
				 AND B.DL_EXPD_PAC_SCN_CD = DECODE(P_PAC_SCN_CD, 'ALL', B.DL_EXPD_PAC_SCN_CD, P_PAC_SCN_CD)
				 AND B.DL_EXPD_PDI_CD = DECODE(P_PDI_CD, 'ALL', B.DL_EXPD_PDI_CD, P_PDI_CD)
				 AND A.DL_EXPD_REGN_CD = DECODE(P_REGN_CD, 'ALL', A.DL_EXPD_REGN_CD, P_REGN_CD)
				 --[변경] 2009.07.23. 현재월 이후 월팩정보를 가지고 연식을 지정한 경우 현재월 기준 조회시 
				 --화면에 나타나지 않아 불편한 문제가 있어서 현재월 이후의 월팩중 가장 최근 정보는 보여질 수 있도록 변경함 
				 AND ((A.DESMP1_CD BETWEEN P_FROM_YMD AND P_TO_YMD) OR (A.DEFMP1_CD = '9999')) 
				 ORDER BY B.QLTY_VEHL_CD, C.SORT_SN, A.DESMP1_CD DESC;
				 
	   END SP_GET_VEHL_MDY_MGMT;
	   
	   --연식관리 내역 저장 
	   PROCEDURE SP_VEHL_MDY_MGMT_SAVE(P_VEHL_CD    VARCHAR2,
	                                   P_REGN_CD    VARCHAR2,
	   			 					   P_MDL_MDY_CD VARCHAR2,
									   P_FROM_PACK 	VARCHAR2,
									   P_USER_EENO  VARCHAR2)
	   IS
	   BEGIN
	   		
			SP_VEHL_MDY_PACK_SAVE(P_VEHL_CD,
			                      P_REGN_CD,
								  P_MDL_MDY_CD,
								  P_FROM_PACK,
								  P_USER_EENO);
								  
	   END SP_VEHL_MDY_MGMT_SAVE;
	   
	   --GOMS로 부터 실시간 데이터 연계 위해 호출되는 프로시저 								   
	   PROCEDURE SP_VEHL_MDY_MGMT_SAVE_IF(P_VEHL_CD    VARCHAR2,
	                                      P_REGN_CD    VARCHAR2,
	   			 					   	  P_MDL_MDY_CD VARCHAR2,
									   	  P_FROM_PACK  VARCHAR2,
									   	  P_USER_EENO  VARCHAR2)
	   IS
	   BEGIN
	   		
			SP_VEHL_MDY_MGMT_SAVE(P_VEHL_CD,
	                              P_REGN_CD,
	   			 				  P_MDL_MDY_CD,
								  P_FROM_PACK,
								  P_USER_EENO);
								  
			COMMIT;
									   
	   END SP_VEHL_MDY_MGMT_SAVE_IF;
	   
	   --연계차종 정보 저장 					   
	   PROCEDURE SP_PRDN_VEHL_LIST_SAVE(P_QLTY_VEHL_CD   VARCHAR2,
										P_PRVS_SCN_CD    VARCHAR2,
										P_PRDN_VEHL_LIST VARCHAR2,
								        P_USER_EENO      VARCHAR2)
	   IS
	   	 
		 V_VEHL_LIST    PG_COMMON.LIST_TYPE;
		 V_VEHL_CNT     BINARY_INTEGER;
		 
		 V_CNT		    NUMBER;
		 
		 V_PRDN_VEHL_CD VARCHAR2(4);
		 
	   BEGIN
	   
			/**
			IF P_PRDN_VEHL_LIST IS NULL OR P_PRDN_VEHL_LIST = '' THEN
			   
			   RETURN;
			   
			END IF;
			**/
			
			V_VEHL_LIST := PG_COMMON.FU_SPLIT(P_PRDN_VEHL_LIST, V_VEHL_CNT);
			
			--우선 이미 저장되었던 항목들을 삭제한다. 
			DELETE FROM TB_ALTN_VEHL_MGMT
			WHERE QLTY_VEHL_CD  = P_QLTY_VEHL_CD
			AND PRVS_SCN_CD = P_PRVS_SCN_CD;
			
			FOR VEHL_NUM IN 1..V_VEHL_CNT LOOP
		   	   
			   IF V_VEHL_LIST(VEHL_NUM) IS NOT NULL THEN
			   	  
				  V_PRDN_VEHL_CD := TRIM(V_VEHL_LIST(VEHL_NUM));
				  
				  --이미 다른 차종의 연계 차종으로 등록되어 있는 경우라면 에러를 발생시킨다.
				  SELECT COUNT(*)
				  INTO V_CNT
				  FROM TB_ALTN_VEHL_MGMT
				  WHERE PRDN_VEHL_CD = V_PRDN_VEHL_CD
				  AND PRVS_SCN_CD = P_PRVS_SCN_CD;
				  
				  IF V_CNT > 0 THEN
				  	 
					 RAISE_APPLICATION_ERROR(-20001, 'Invalid prdn vehl information. existing prdn vehl code - prdn_vehl:[' || V_PRDN_VEHL_CD || '] scn_cd:[' || P_PRVS_SCN_CD || ']');
					 
				  END IF;
				  
				  INSERT INTO TB_ALTN_VEHL_MGMT
   		          (QLTY_VEHL_CD,
			       PRDN_VEHL_CD,
				   PRVS_SCN_CD,
   		           PPRR_EENO,
   		           FRAM_DTM,
   		           UPDR_EENO,
   		           MDFY_DTM
   		          )
   		          VALUES
   		          (P_QLTY_VEHL_CD,
   		           V_PRDN_VEHL_CD,
				   P_PRVS_SCN_CD,
   		           P_USER_EENO,
   		           SYSDATE,
   		           P_USER_EENO,
   		           SYSDATE
   		          );
			   			   
			   END IF;
  
		   END LOOP;
		   
	   END SP_PRDN_VEHL_LIST_SAVE;							
	   
	   --차종 담당자 정보 저장 
	   PROCEDURE SP_CRGR_USER_LIST_SAVE(P_QLTY_VEHL_CD VARCHAR2,
	                                    P_MDL_MDY_CD   VARCHAR2,
	                                    P_BLNS_CO_CD   VARCHAR2,
										P_USER_ID_LIST VARCHAR2,
								        P_USER_EENO    VARCHAR2)
	   IS
	   	 
		 V_USER_LIST PG_COMMON.LIST_TYPE;
		 V_USER_CNT  BINARY_INTEGER;
		 
		 V_PREV_MDL_MDY_CD VARCHAR2(2);
		 V_USER_ID_LIST    VARCHAR2(8000);
		 
	   BEGIN
	   		
			--세원, PDI, 글로비스 담당자의 경우 GOMS I/F 시에 가장 최근의 담당자 정보로 세팅하여 준다.
			IF P_USER_ID_LIST = 'INTERFACE' THEN
			   
			   V_USER_ID_LIST := FU_GET_CRGR_USER_ID_LIST(P_QLTY_VEHL_CD,
	                                                      P_MDL_MDY_CD,
	                                                      P_BLNS_CO_CD
														 );									 
			   IF V_USER_ID_LIST IS NULL THEN
			   	  
				  --이전 연식 조회 
				  SELECT MAX(MDL_MDY_CD)
			   	  INTO V_PREV_MDL_MDY_CD
			   	  FROM TB_VEHL_MGMT
			   	  WHERE QLTY_VEHL_CD = P_QLTY_VEHL_CD
			   	  AND MDL_MDY_CD < P_MDL_MDY_CD
				  AND USE_YN = 'Y';
				  
				  IF V_PREV_MDL_MDY_CD IS NULL THEN
				  	 
					 RETURN;
					 
				  END IF;
			   	  
				  V_USER_ID_LIST := FU_GET_CRGR_USER_ID_LIST(P_QLTY_VEHL_CD,
	                                                         V_PREV_MDL_MDY_CD,
	                                                         P_BLNS_CO_CD
														    );
			   ELSE
			      
				  --이미 데이터가 들어 있으므로 처리하여 주지 않는다. 
				  RETURN;
				   
			   END IF;

			ELSE
			   
			   V_USER_ID_LIST := P_USER_ID_LIST;
			   
			END IF;
			
			V_USER_LIST := PG_COMMON.FU_SPLIT(V_USER_ID_LIST, V_USER_CNT);
			
			--우선 이미 저장되었던 항목들을 삭제한다. 
			DELETE FROM TB_VEHL_CRGR_MGMT
			WHERE QLTY_VEHL_CD  = P_QLTY_VEHL_CD
			AND MDL_MDY_CD = P_MDL_MDY_CD
			AND BLNS_CO_CD = P_BLNS_CO_CD;
			
			FOR USER_NUM IN 1..V_USER_CNT LOOP
		   	   
			   IF V_USER_LIST(USER_NUM) IS NOT NULL THEN
			   	  
				  --현재 차종에 대하여 다른 소속 사용자로 등록된 경우에는 해당 내역을 우선 삭제해 준다.
				  DELETE FROM TB_VEHL_CRGR_MGMT
				  WHERE QLTY_VEHL_CD  = P_QLTY_VEHL_CD
				  AND MDL_MDY_CD = P_MDL_MDY_CD
				  AND CRGR_EENO = PG_COMMON.FU_RPAD(V_USER_LIST(USER_NUM), 7);
				  
				  INSERT INTO TB_VEHL_CRGR_MGMT
   		          (QLTY_VEHL_CD,
			       MDL_MDY_CD,
				   CRGR_EENO,
				   BLNS_CO_CD,
				   USE_YN,
   		           PPRR_EENO,
   		           FRAM_DTM,
   		           UPDR_EENO,
   		           MDFY_DTM
   		          )
   		          VALUES
   		          (P_QLTY_VEHL_CD,
			       P_MDL_MDY_CD,
   		           V_USER_LIST(USER_NUM),
				   P_BLNS_CO_CD,
				   'Y',
   		           P_USER_EENO,
   		           SYSDATE,
   		           P_USER_EENO,
   		           SYSDATE
   		          );
			   
			   END IF;

		   END LOOP;
			
	   END SP_CRGR_USER_LIST_SAVE;							
																		 
	   --저장시 언어코드정보와 국가코드정보를 복사하는 작업을 수행(연식 신규추가시에만 호출)  			
	   PROCEDURE SP_VEHL_MDY_COPY(P_VEHL_CD    VARCHAR2,
	   							  P_MDL_MDY_CD VARCHAR2,
								  P_USER_EENO  VARCHAR2)
	   IS
	   	 
		 V_PREV_MDL_MDY_CD VARCHAR2(2);
		 
	   BEGIN
	   
	   		SELECT MAX(MDL_MDY_CD)
			INTO V_PREV_MDL_MDY_CD
			FROM TB_VEHL_MGMT
			WHERE QLTY_VEHL_CD = P_VEHL_CD
			AND MDL_MDY_CD < P_MDL_MDY_CD;
			
			--연식추가에 의해 차종정보가 Insert된 경우에만 실행함 
			--언어코드, 국가/언어코드 테이블 내역 복사 작업 수행
			--국가/차종코드 테이블(TB_NATL_VEHL_MGMT) 은 연식과 연관된 것이 아니므로 처리해 줄 필요가 없다.
			IF V_PREV_MDL_MDY_CD IS NOT NULL THEN
			   
			   /**** [변경] 2009.11.24.김동근 언어코드 항목에 여러개의 데이터가 존재하는 경우 아래의 입력 쿼리는 에러가 발생되어 함수호출 하는 것으로 변경 
			   
			   --언어코드 테이블에 데이터 추가 
			   INSERT INTO TB_LANG_MGMT
			   (DATA_SN,
			    QLTY_VEHL_CD,
				MDL_MDY_CD,
				LANG_CD,
				DL_EXPD_REGN_CD,
				LANG_CD_NM,
				USE_YN,
				NAPC_YN,
				PPRR_EENO,
				FRAM_DTM,
				UPDR_EENO,
				MDFY_DTM,
				SORT_SN,
				A_CODE,
				N1_INS_YN
			   )
			   SELECT (SELECT NVL(MAX(DATA_SN), 0) + 1
			           FROM TB_LANG_MGMT
					  ),
			   		  P_VEHL_CD,
			          P_MDL_MDY_CD,
					  LANG_CD,
					  DL_EXPD_REGN_CD,
					  LANG_CD_NM,
					  USE_YN,
					  NAPC_YN,
					  P_USER_EENO,
					  SYSDATE,
					  P_USER_EENO,
					  SYSDATE,
					  SORT_SN,
					  A_CODE,
					  N1_INS_YN
				FROM TB_LANG_MGMT
				WHERE QLTY_VEHL_CD = P_VEHL_CD
				AND MDL_MDY_CD = V_PREV_MDL_MDY_CD
				AND USE_YN = 'Y';
			    ****/
				
				PG_LANG_MGMT.SP_LANG_COPY(P_VEHL_CD, P_MDL_MDY_CD, V_PREV_MDL_MDY_CD, P_USER_EENO);
				
				
				--국가/언어코드 테이블 데이터 추가 
				INSERT INTO TB_NATL_LANG_MGMT
				(DL_EXPD_CO_CD,
				 DL_EXPD_NAT_CD,
				 QLTY_VEHL_CD,
				 MDL_MDY_CD,
				 LANG_CD,
				 USE_YN,
				 NAPC_YN,
				 PPRR_EENO,
				 FRAM_DTM,
				 UPDR_EENO,
				 MDFY_DTM
				)
				SELECT DL_EXPD_CO_CD,
					   DL_EXPD_NAT_CD,
					   P_VEHL_CD,
					   P_MDL_MDY_CD,
					   LANG_CD,
					   USE_YN,
					   NAPC_YN,
					   P_USER_EENO,
					   SYSDATE,
					   P_USER_EENO,
					   SYSDATE
				FROM TB_NATL_LANG_MGMT
				WHERE QLTY_VEHL_CD = P_VEHL_CD
				AND MDL_MDY_CD = V_PREV_MDL_MDY_CD
				AND USE_YN = 'Y';
				  
			END IF;
	   		
	   END SP_VEHL_MDY_COPY;
	   
	   						 
	   --저장시 직전연식관계 변화에 따른 취급설명서 연식코드 매핑 작업 수행 
	   PROCEDURE SP_VEHL_MDY_REL_CD_UPDATE(P_VEHL_CD      VARCHAR2,
	   							           P_MDL_MDY_CD   VARCHAR2,
										   P_EXPD_REGN_CD VARCHAR2,
								           P_MDY_REL_CD   VARCHAR2,
										   P_USER_EENO    VARCHAR2)
	   IS
	   	 
--		 --이전연식 
--		 V_PREV_MDL_MDY_CD VARCHAR2(2);
		 
--		 --이후연식 
--		 V_NEXT_MDL_MDY_CD VARCHAR2(2);
		 
		 V_SYST_YMD		   VARCHAR2(8);
         
         V_MDL_MDY_LIST    PG_COMMON.LIST_TYPE;
         V_COUNT           BINARY_INTEGER;
		 
	   BEGIN
	   		
			--현재반영되어 있는 내역을 삭제한다,
			DELETE FROM TB_DL_EXPD_MDY_MGMT 
			WHERE QLTY_VEHL_CD = P_VEHL_CD
			AND DL_EXPD_REGN_CD = P_EXPD_REGN_CD
			AND MDL_MDY_CD = P_MDL_MDY_CD;
			
--			--이전연식 계산 
--			SELECT MAX(MDL_MDY_CD)
--			INTO V_PREV_MDL_MDY_CD
--			FROM TB_VEHL_MGMT
--			WHERE QLTY_VEHL_CD = P_VEHL_CD
--			AND MDL_MDY_CD < P_MDL_MDY_CD
--			AND USE_YN = 'Y';
			
			/**
			IF V_PREV_MDL_MDY_CD IS NULL THEN 
			   
			   V_PREV_MDL_MDY_CD := TO_CHAR(ADD_MONTHS(TO_DATE(P_MDL_MDY_CD || '0101', 'YYMMDD'), -12), 'YY');
			   
			END IF; 
			**/
			
--			--이후연식 계산 
--			SELECT MIN(MDL_MDY_CD)
--			INTO V_NEXT_MDL_MDY_CD
--			FROM TB_VEHL_MGMT
--			WHERE QLTY_VEHL_CD = P_VEHL_CD
--			AND MDL_MDY_CD > P_MDL_MDY_CD
--			AND USE_YN = 'Y';
			
			/**
			IF V_NEXT_MDL_MDY_CD IS NULL THEN
			   
			   V_NEXT_MDL_MDY_CD := TO_CHAR(ADD_MONTHS(TO_DATE(P_MDL_MDY_CD || '0101', 'YYMMDD'), 12), 'YY');
			   
			END IF;
			**/
			
			--완전통합의 경우 
			IF P_MDY_REL_CD = '01' THEN

/**			   
			   IF V_PREV_MDL_MDY_CD IS NOT NULL THEN
			   	  
				  SP_EXPD_MDY_MGMT_SAVE(P_VEHL_CD, P_MDL_MDY_CD, P_EXPD_REGN_CD, V_PREV_MDL_MDY_CD, P_USER_EENO);
				  
			   END IF;
			   
			   SP_EXPD_MDY_MGMT_SAVE(P_VEHL_CD, P_MDL_MDY_CD, P_EXPD_REGN_CD, P_MDL_MDY_CD, P_USER_EENO);
			   
			   IF V_NEXT_MDL_MDY_CD IS NOT NULL THEN
			   	  
				  SP_EXPD_MDY_MGMT_SAVE(P_VEHL_CD, P_MDL_MDY_CD, P_EXPD_REGN_CD, V_NEXT_MDL_MDY_CD, P_USER_EENO);
				  
			   END IF;
**/            
               V_MDL_MDY_LIST := FU_GET_REL_MDL_MDY(P_VEHL_CD, P_MDL_MDY_CD, P_EXPD_REGN_CD, 'PREV', V_COUNT);
               
               FOR NUM1 IN 1..V_COUNT LOOP
                
                SP_EXPD_MDY_MGMT_SAVE(P_VEHL_CD, P_MDL_MDY_CD, P_EXPD_REGN_CD, V_MDL_MDY_LIST(NUM1), P_USER_EENO);
                
               END LOOP;
               
               SP_EXPD_MDY_MGMT_SAVE(P_VEHL_CD, P_MDL_MDY_CD, P_EXPD_REGN_CD, P_MDL_MDY_CD, P_USER_EENO);
               
               V_MDL_MDY_LIST := FU_GET_REL_MDL_MDY(P_VEHL_CD, P_MDL_MDY_CD, P_EXPD_REGN_CD, 'NEXT', V_COUNT);
               
               FOR NUM1 IN 1..V_COUNT LOOP
                
                SP_EXPD_MDY_MGMT_SAVE(P_VEHL_CD, P_MDL_MDY_CD, P_EXPD_REGN_CD, V_MDL_MDY_LIST(NUM1), P_USER_EENO);
                
               END LOOP;
			   
			--전방통합의 경우   
			ELSIF P_MDY_REL_CD = '02' THEN
/**			   
			   SP_EXPD_MDY_MGMT_SAVE(P_VEHL_CD, P_MDL_MDY_CD, P_EXPD_REGN_CD, P_MDL_MDY_CD, P_USER_EENO);
			   
			   IF V_NEXT_MDL_MDY_CD IS NOT NULL THEN
			   	  
				  SP_EXPD_MDY_MGMT_SAVE(P_VEHL_CD, P_MDL_MDY_CD, P_EXPD_REGN_CD, V_NEXT_MDL_MDY_CD, P_USER_EENO);
				  
			   END IF;
**/               
			   SP_EXPD_MDY_MGMT_SAVE(P_VEHL_CD, P_MDL_MDY_CD, P_EXPD_REGN_CD, P_MDL_MDY_CD, P_USER_EENO);
               
               V_MDL_MDY_LIST := FU_GET_REL_MDL_MDY(P_VEHL_CD, P_MDL_MDY_CD, P_EXPD_REGN_CD, 'NEXT', V_COUNT);
               
               FOR NUM1 IN 1..V_COUNT LOOP
                
                SP_EXPD_MDY_MGMT_SAVE(P_VEHL_CD, P_MDL_MDY_CD, P_EXPD_REGN_CD, V_MDL_MDY_LIST(NUM1), P_USER_EENO);
                
               END LOOP;
               
			--후방통합의 경우    
			ELSIF P_MDY_REL_CD = '03' THEN
			   
/**
			   IF V_PREV_MDL_MDY_CD IS NOT NULL THEN
			   	  
				  SP_EXPD_MDY_MGMT_SAVE(P_VEHL_CD, P_MDL_MDY_CD, P_EXPD_REGN_CD, V_PREV_MDL_MDY_CD, P_USER_EENO);
				  
			   END IF;
			   
			   SP_EXPD_MDY_MGMT_SAVE(P_VEHL_CD, P_MDL_MDY_CD, P_EXPD_REGN_CD, P_MDL_MDY_CD, P_USER_EENO);
**/
               V_MDL_MDY_LIST := FU_GET_REL_MDL_MDY(P_VEHL_CD, P_MDL_MDY_CD, P_EXPD_REGN_CD, 'PREV', V_COUNT);
               
               FOR NUM1 IN 1..V_COUNT LOOP
                
                SP_EXPD_MDY_MGMT_SAVE(P_VEHL_CD, P_MDL_MDY_CD, P_EXPD_REGN_CD, V_MDL_MDY_LIST(NUM1), P_USER_EENO);
                
               END LOOP;
               
               SP_EXPD_MDY_MGMT_SAVE(P_VEHL_CD, P_MDL_MDY_CD, P_EXPD_REGN_CD, P_MDL_MDY_CD, P_USER_EENO);
               			   
			--완전분리의 경우 
			ELSE
				
				--현재연식은 현재의 취급설명서 연식만을 사용한다. 
			   	SP_EXPD_MDY_MGMT_SAVE(P_VEHL_CD, P_MDL_MDY_CD, P_EXPD_REGN_CD, P_MDL_MDY_CD, P_USER_EENO);
			   
			END IF;
			
			--언어별 직전연식 관계 재 계산 
			SP_LANG_MDY_REL_CD_UPDATE(P_VEHL_CD, P_MDL_MDY_CD, P_EXPD_REGN_CD, P_MDY_REL_CD, P_USER_EENO);
			
			--연식관계 변경에 따른 재고 재계산 작업 수행 
			
			V_SYST_YMD := TO_CHAR(SYSDATE, 'YYYYMMDD');
			
			
			
			--[고려] 2010.04.06.김동근 PU 차종의 경우 언어별로 이전연식이 달리 처리되어야 한다. 
			--나중에 아래의 부분과 생산 재고 계산하는 부분을 TB_DL_LANG_MDY_MGMT 테이블로 변경하는 것을 고려해 볼것 
			
			PG_DATA.SP_RECALCULATE_SEWHA_IV_DTL3(V_SYST_YMD, P_VEHL_CD, P_USER_EENO);
			PG_DATA.SP_RECALCULATE_PDI_IV_DTL3(V_SYST_YMD, P_VEHL_CD, P_USER_EENO);
			
			
			
			
			
			/** 이전방식 현재는 사용 안함 **/ 
			/***********
			--이전연식 계산 
			V_PREV_MDL_MDY_CD := TO_CHAR(ADD_MONTHS(TO_DATE(P_MDL_MDY_CD || '0101', 'YYMMDD'), -12), 'YY');
			
			--현재반영되어 있는 내역을 삭제한다,
			DELETE FROM TB_DL_EXPD_MDY_MGMT 
			WHERE QLTY_VEHL_CD = P_VEHL_CD
			AND MDL_MDY_CD IN (V_PREV_MDL_MDY_CD, P_MDL_MDY_CD)
			AND DL_EXPD_MDL_MDY_CD IN (V_PREV_MDL_MDY_CD, P_MDL_MDY_CD); --취급설명서 연식도 현재와 이전의 연식에 해당하는 것만 삭제한다.
			
			--완전통합의 경우 
			IF P_MDY_REL_CD = '01' THEN

			   --이전연식은 이전과 현재의 의 취급설명서 연식을 모두 사용한다. 
			   SP_EXPD_MDY_MGMT_SAVE(P_VEHL_CD, V_PREV_MDL_MDY_CD, V_PREV_MDL_MDY_CD, P_USER_EENO);
			   SP_EXPD_MDY_MGMT_SAVE(P_VEHL_CD, V_PREV_MDL_MDY_CD, P_MDL_MDY_CD, P_USER_EENO);
			   
			   --현재연식은 이전과 현재의 취급설명서 연식을 모두 사용한다. 
			   SP_EXPD_MDY_MGMT_SAVE(P_VEHL_CD, P_MDL_MDY_CD, V_PREV_MDL_MDY_CD, P_USER_EENO);
			   SP_EXPD_MDY_MGMT_SAVE(P_VEHL_CD, P_MDL_MDY_CD, P_MDL_MDY_CD, P_USER_EENO);
			   
			--전방통합의 경우   
			ELSIF P_MDY_REL_CD = '02' THEN

			   --이전연식은 이전과 현재의 의 취급설명서 연식을 모두 사용한다. 
			   SP_EXPD_MDY_MGMT_SAVE(P_VEHL_CD, V_PREV_MDL_MDY_CD, V_PREV_MDL_MDY_CD, P_USER_EENO);
			   SP_EXPD_MDY_MGMT_SAVE(P_VEHL_CD, V_PREV_MDL_MDY_CD, P_MDL_MDY_CD, P_USER_EENO);
			   
			   --현재연식은 현재의 취급설명서 연식만을 사용한다. 
			   SP_EXPD_MDY_MGMT_SAVE(P_VEHL_CD, P_MDL_MDY_CD, P_MDL_MDY_CD, P_USER_EENO);
			
			--후방통합의 경우    
			ELSIF P_MDY_REL_CD = '03' THEN

			   --이전연식은 이전의 취급설명서 연식만을 사용한다. 
			   SP_EXPD_MDY_MGMT_SAVE(P_VEHL_CD, V_PREV_MDL_MDY_CD, V_PREV_MDL_MDY_CD, P_USER_EENO);
			   
			   --현재연식은 이전과 현재의 취급설명서 연식을 모두 사용한다. 
			   SP_EXPD_MDY_MGMT_SAVE(P_VEHL_CD, P_MDL_MDY_CD, V_PREV_MDL_MDY_CD, P_USER_EENO);
			   SP_EXPD_MDY_MGMT_SAVE(P_VEHL_CD, P_MDL_MDY_CD, P_MDL_MDY_CD, P_USER_EENO);
			
			--완전분리의 경우 
			ELSE

			   --이전연식은 이전의 취급설명서 연식만을 사용한다. 
			   SP_EXPD_MDY_MGMT_SAVE(P_VEHL_CD, V_PREV_MDL_MDY_CD, V_PREV_MDL_MDY_CD, P_USER_EENO);
			   
			   --현재연식은 현재의 취급설명서 연식만을 사용한다. 
			   SP_EXPD_MDY_MGMT_SAVE(P_VEHL_CD, P_MDL_MDY_CD, P_MDL_MDY_CD, P_USER_EENO);

			END IF;
			***********/
			
	   END SP_VEHL_MDY_REL_CD_UPDATE;
       
       --직전연식관계에 따른 연식 리스트 조회 
       FUNCTION FU_GET_REL_MDL_MDY(P_VEHL_CD      VARCHAR2,
	   							   P_MDL_MDY_CD   VARCHAR2,
								   P_EXPD_REGN_CD VARCHAR2,
                                   P_MODE         VARCHAR2,
                                   P_COUNT OUT BINARY_INTEGER) RETURN PG_COMMON.LIST_TYPE
       IS
        
        V_LIST_TYPE PG_COMMON.LIST_TYPE;
        V_NUM       BINARY_INTEGER;
        
        V_MDL_MDY_CD VARCHAR2(2);
        V_ISCONTINUE VARCHAR2(1);
        
       BEGIN
        
        V_NUM        := 0;
        V_MDL_MDY_CD := P_MDL_MDY_CD;
        
        LOOP
            
            V_ISCONTINUE := 'N';
            
            V_MDL_MDY_CD := FU_GET_REL_MDL_MDY_SUB(P_VEHL_CD,
	   							                   V_MDL_MDY_CD,
								                   P_EXPD_REGN_CD,
                                                   P_MODE,
                                                   V_ISCONTINUE
                                                  );                                      
            IF V_MDL_MDY_CD IS NOT NULL THEN
            
                V_NUM := V_NUM + 1;
        
                V_LIST_TYPE(V_NUM) := V_MDL_MDY_CD;
            
            END IF;
            
            EXIT WHEN V_ISCONTINUE <> 'Y';
            
        END LOOP;
           
        P_COUNT := V_NUM;

    	RETURN V_LIST_TYPE;
        
       END FU_GET_REL_MDL_MDY;
       
       FUNCTION FU_GET_REL_MDL_MDY_SUB(P_VEHL_CD      VARCHAR2,
	   							       P_MDL_MDY_CD   VARCHAR2,
								       P_EXPD_REGN_CD VARCHAR2,
                                       P_MODE         VARCHAR2,
                                       P_ISCONTINUE   OUT VARCHAR2) RETURN VARCHAR2
       IS
        
        V_MDL_MDY_CD VARCHAR2(2);
        V_MDY_REL_CD VARCHAR2(4);
        
       BEGIN
        
        IF P_MODE = 'NEXT' THEN
            
            SELECT MIN(A.MDL_MDY_CD), MIN(C.JB_MDY_REL_CD)
            INTO V_MDL_MDY_CD, V_MDY_REL_CD
            FROM TB_VEHL_MDY_MGMT A,
                 TB_VEHL_MGMT B,
                 TB_VEHL_MDY_REL_MGMT C
            WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
            AND A.MDL_MDY_CD = B.MDL_MDY_CD
            AND A.QLTY_VEHL_CD = C.QLTY_VEHL_CD
            AND A.MDL_MDY_CD = C.MDL_MDY_CD
            AND A.DL_EXPD_REGN_CD = C.DL_EXPD_REGN_CD   
            AND A.QLTY_VEHL_CD = P_VEHL_CD
            AND A.MDL_MDY_CD > P_MDL_MDY_CD
            AND A.DL_EXPD_REGN_CD = P_EXPD_REGN_CD
            --AND C.JB_MDY_REL_CD IN ('01', '02') -- 완전통합, 전방통합인 경우에만 조회
            AND B.USE_YN = 'Y'
            ;
            
            IF V_MDY_REL_CD IN ('01', '02') THEN
                
                P_ISCONTINUE := 'Y';
                
            ELSE
                
                P_ISCONTINUE := 'N';
                
            END IF;
            
        ELSE
            
            SELECT MAX(A.MDL_MDY_CD), MIN(C.JB_MDY_REL_CD)
            INTO V_MDL_MDY_CD, V_MDY_REL_CD
            FROM TB_VEHL_MDY_MGMT A,
                 TB_VEHL_MGMT B,
                 TB_VEHL_MDY_REL_MGMT C
            WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
            AND A.MDL_MDY_CD = B.MDL_MDY_CD
            AND A.QLTY_VEHL_CD = C.QLTY_VEHL_CD
            AND A.MDL_MDY_CD = C.MDL_MDY_CD
            AND A.DL_EXPD_REGN_CD = C.DL_EXPD_REGN_CD   
            AND A.QLTY_VEHL_CD = P_VEHL_CD
            AND A.MDL_MDY_CD < P_MDL_MDY_CD
            AND A.DL_EXPD_REGN_CD = P_EXPD_REGN_CD
            --AND C.JB_MDY_REL_CD IN ('01', '03') -- 완전통합, 후방통합인 경우에만 조회 
            AND B.USE_YN = 'Y'
            ;
            
            IF V_MDY_REL_CD IN ('01', '03') THEN
                
                P_ISCONTINUE := 'Y';
                
            ELSE
                
                P_ISCONTINUE := 'N';
                
            END IF;
            
        END IF;
       
        RETURN V_MDL_MDY_CD;
        
       END FU_GET_REL_MDL_MDY_SUB;

	   --직전연식관계 내역을 저장
	   PROCEDURE SP_EXPD_MDY_MGMT_SAVE(P_VEHL_CD         VARCHAR2,
	   			 					   P_MDL_MDY_CD      VARCHAR2,
									   P_EXPD_REGN_CD    VARCHAR2,
									   P_EXPD_MDL_MDY_CD VARCHAR2,
									   P_USER_EENO       VARCHAR2)
	   IS
	   	 
		 V_CNT NUMBER;
		 
	   BEGIN
	   		
			SELECT COUNT(*)
			INTO V_CNT
			FROM TB_VEHL_MGMT
			WHERE QLTY_VEHL_CD = P_VEHL_CD
			AND MDL_MDY_CD = P_MDL_MDY_CD;
			
			IF V_CNT = 0 THEN
			   
			   RETURN;
			   
			END IF;
			
			INSERT INTO TB_DL_EXPD_MDY_MGMT
			(QLTY_VEHL_CD,
			 MDL_MDY_CD,
			 DL_EXPD_REGN_CD,
			 DL_EXPD_MDL_MDY_CD,
			 PPRR_EENO,
			 FRAM_DTM,
			 UPDR_EENO,
			 MDFY_DTM
			)
			VALUES
			(P_VEHL_CD,
			 P_MDL_MDY_CD,
			 P_EXPD_REGN_CD,
			 P_EXPD_MDL_MDY_CD,
			 P_USER_EENO,
			 SYSDATE,
			 P_USER_EENO,
			 SYSDATE
			);
			
	   END SP_EXPD_MDY_MGMT_SAVE;
	   
	   --월팩코드에 따른 차종의 연식을 저장							   
	   PROCEDURE SP_VEHL_MDY_PACK_SAVE(P_VEHL_CD    VARCHAR2,
	                                   P_REGN_CD    VARCHAR2,
	   			 					   P_MDL_MDY_CD VARCHAR2,
									   P_FROM_PACK 	VARCHAR2,
									   P_USER_EENO  VARCHAR2)
	   IS
	   	 
		 V_PREV_MDL_MDY_CD  VARCHAR2(2);
		 V_PREV_MDL_MDY_CD2 VARCHAR2(2);
		 V_PREV_STRT_PACK   VARCHAR2(4); --이전월팩 
		 V_PREV_STRT_PACK2  VARCHAR2(4);
		 V_PREV_FNH_PACK    VARCHAR2(4); --이전종료월팩 
		 V_PREV_FNH_PACK2   VARCHAR2(4);
		 
		 V_FNH_FLAG        VARCHAR2(1); --나중에 완료일 설정을 대비한 임시변수 (완료일 설정 작업: 2, 보통의 작업: 1) 
		 V_MODE			   VARCHAR2(1); --모드 구분(F: 완료일 설정, U: 업데이트, I: Insert) 
		 
         V_MDY_REL_CD      VARCHAR2(4);
         
	   BEGIN
	   		
			V_FNH_FLAG := '1'; --나중에 완료일 설정을 대비한 임시변수 (완료일 설정 작업: 2, 보통의 작업: 1) 
			
			--가장 최근의 시작월팩, 연식정보를 얻어온다. 
			SELECT MAX(DESMP1_CD), 
				   MAX(MDL_MDY_CD)
			INTO V_PREV_STRT_PACK,
			     V_PREV_MDL_MDY_CD
			FROM TB_VEHL_MDY_MGMT
			WHERE QLTY_VEHL_CD = P_VEHL_CD
			AND DL_EXPD_REGN_CD = P_REGN_CD
			AND DEFMP1_CD = '9999';
			
			--현재 차종, 지역으로 연식지정한 최근 월팩 정보가 존재하는 경우 
			IF V_PREV_STRT_PACK IS NOT NULL THEN
			   
			   --완료일 설정 작업인 경우 
			   IF V_FNH_FLAG = '2' THEN
			   	  
				  IF V_PREV_STRT_PACK > P_FROM_PACK THEN
						   	  
				      RAISE_APPLICATION_ERROR(-20001, '[Finish]Pack is more than ' || V_PREV_STRT_PACK /*** TO_CHAR(ADD_MONTHS(TO_DATE(V_PREV_STRT_PACK, 'YYMM'), + 1), 'YYMM') ***/ );
				  
				  END IF;		  
				  
				  V_MODE := 'F';
				  
			   ELSE
			   	  
				  --연식이 같은 경우에는 시작월팩의 업데이트 작업이다. 
				  IF V_PREV_MDL_MDY_CD = P_MDL_MDY_CD THEN
				     
					 --가장 최근의 시작월팩과 현재 수정하고자 하는 시작월팩이 다른 경우에만 작업을 수행한다. 
					 IF V_PREV_STRT_PACK <> P_FROM_PACK THEN
					 	
						--가장 최근 정보 바로 이전의 정보가 있는지를 확인한다. 
						SELECT MAX(DEFMP1_CD)
					    INTO V_PREV_FNH_PACK
					 	FROM TB_VEHL_MDY_MGMT
					 	WHERE QLTY_VEHL_CD = P_VEHL_CD
					 	AND DL_EXPD_REGN_CD = P_REGN_CD
					 	AND DEFMP1_CD <> '9999';
						
						--최근 바로 이전 연식 지정 월팩 정보가 존재하지 않는 경우에는 무조건 수정작업을 진행하면 된다. 
						IF V_PREV_FNH_PACK IS NULL THEN
						   
						   V_MODE := 'U';
						
						ELSE
						   
						   SELECT MAX(DESMP1_CD),
						   		  MAX(MDL_MDY_CD)
					       INTO V_PREV_STRT_PACK2,
						        V_PREV_MDL_MDY_CD2
					 	   FROM TB_VEHL_MDY_MGMT
					 	   WHERE QLTY_VEHL_CD = P_VEHL_CD
					 	   AND DL_EXPD_REGN_CD = P_REGN_CD
					 	   AND DEFMP1_CD = V_PREV_FNH_PACK;
						   
						   --최근 바로 이전에 지정된 종료 월팩 보다 현재 수정하고자 하는 시작월팩이 더 작으면 에러를 발생 시킨다.
						   IF V_PREV_STRT_PACK2 >= P_FROM_PACK THEN
						   	  
							  RAISE_APPLICATION_ERROR(-20001, '[Update]Pack is more than ' || TO_CHAR(ADD_MONTHS(TO_DATE(V_PREV_STRT_PACK2, 'YYMM'), + 1), 'YYMM'));
						   
						   ELSIF V_PREV_STRT_PACK2 < P_FROM_PACK THEN
						   		 
			   	  	  			 --최근 바로 이전연식에 대한 종료월팩정보 설정 
			   	  	  			 UPDATE TB_VEHL_MDY_MGMT
			   	  	  			 SET DEFMP1_CD = TO_CHAR(ADD_MONTHS(TO_DATE(P_FROM_PACK, 'YYMM'), -1), 'YYMM'),
								     UPDR_EENO = P_USER_EENO,
				   	      			 MDFY_DTM = SYSDATE
			   	  	  			 WHERE QLTY_VEHL_CD = P_VEHL_CD
			   	  	  			 AND DL_EXPD_REGN_CD = P_REGN_CD
			   	  	  			 AND DESMP1_CD = V_PREV_STRT_PACK2 
			   	  	  			 AND MDL_MDY_CD = V_PREV_MDL_MDY_CD2;
					  
						   END IF;
						
						   V_MODE := 'U'; 
						   
						END IF; --가장 최근 정보 바로 이전의 정보가 있는지의 여부 비교 조건의 END IF       

					 END IF; --가장 최근의 시작월팩과 현재 수정하고자 하는 시작월팩이 다른지의 비교 조건의 END IF 
					 
				  --연식이 다른 경우에는 신규 지정 작업 이다. 
			   	  ELSE
			   	  
				  	  --시작월팩이 이전월팩보다 최소한 한달은 커야 한다. 
			   	  	  IF V_PREV_STRT_PACK >= P_FROM_PACK THEN
			   	  
				  	  	 RAISE_APPLICATION_ERROR(-20001, '[Insert]Pack is more than ' || TO_CHAR(ADD_MONTHS(TO_DATE(V_PREV_STRT_PACK, 'YYMM'), +1), 'YYMM'));
				  
			   	  	  END IF;
			   
			   	  	  --이전종료월팩 계산 
			   	  	  V_PREV_FNH_PACK:= TO_CHAR(ADD_MONTHS(TO_DATE(P_FROM_PACK, 'YYMM'), -1), 'YYMM');
			   
			   	  	  --이전연식에 대한 종료월팩정보 설정 
			   	  	  UPDATE TB_VEHL_MDY_MGMT
			   	  	  SET DEFMP1_CD = V_PREV_FNH_PACK,
					      UPDR_EENO = P_USER_EENO,
				   	      MDFY_DTM = SYSDATE
			   	  	  WHERE QLTY_VEHL_CD = P_VEHL_CD
			   	  	  AND DL_EXPD_REGN_CD = P_REGN_CD
			   	  	  AND DESMP1_CD = V_PREV_STRT_PACK
			   	  	  AND MDL_MDY_CD = V_PREV_MDL_MDY_CD;
			          
					  V_MODE := 'I'; 
					  
			      END IF; --연식이 같은지 여부 비교 조건의 END IF 
			   
			   END IF; --완료일 설정 작업 여부 비교 조건의 END IF 

			ELSE
				
			   --완료일 설정 작업인 경우 
			   IF V_FNH_FLAG = '2' THEN
			   	  
				  --완료일 지정할 항목이 없으므로.... 에러를 발생시킨 후 종료한다. 
				  RAISE_APPLICATION_ERROR(-20001, '[Finish2]There is no Pack to set finish date');
				  
			   ELSE
			   	  
				  --가장 최근의 취급설명서 종료월팩코드를 찾는다. 
			      SELECT MAX(DEFMP1_CD)
			      INTO V_PREV_FNH_PACK
			      FROM TB_VEHL_MDY_MGMT
			      WHERE QLTY_VEHL_CD = P_VEHL_CD
			   	  AND DL_EXPD_REGN_CD = P_REGN_CD;
				  
				  --이전에 지정된 월팩 정보가 없다면 그냥 Insert 해 주면 된다. 
				  IF V_PREV_FNH_PACK IS NULL THEN
				  	 
					  V_MODE := 'I'; 
					  
				  ELSE
				      
					  --가장 최근의 종료월팩에 해당하는 시작월팩, 연식정보를 얻어온다. 
				   	  SELECT MAX(DESMP1_CD), 
				   		  	 MAX(MDL_MDY_CD)
				      INTO V_PREV_STRT_PACK,
			       		   V_PREV_MDL_MDY_CD
			          FROM TB_VEHL_MDY_MGMT
				   	  WHERE QLTY_VEHL_CD = P_VEHL_CD
				   	  AND DL_EXPD_REGN_CD = P_REGN_CD
				   	  AND DEFMP1_CD = V_PREV_FNH_PACK;
				   	  
					  --연식이 같은 경우에는 시작월팩의 업데이트 작업이다. 
				  	  IF V_PREV_MDL_MDY_CD = P_MDL_MDY_CD THEN
				     
					      --가장 최근의 시작월팩과 현재 수정하고자 하는 시작월팩이 다른 경우에만 작업을 수행한다. 
					      IF V_PREV_STRT_PACK <> P_FROM_PACK THEN
					 	
						     --가장 최근 정보 바로 이전의 정보가 있는지를 확인한다. 
						     SELECT MAX(DEFMP1_CD)
					         INTO V_PREV_FNH_PACK2
					 	     FROM TB_VEHL_MDY_MGMT
					 	     WHERE QLTY_VEHL_CD = P_VEHL_CD
					 	     AND DL_EXPD_REGN_CD = P_REGN_CD
					 	     AND DEFMP1_CD <> V_PREV_FNH_PACK;
						
						     --최근 바로 이전 연식 지정 월팩 정보가 존재하지 않는 경우에는 무조건 수정작업을 진행하면 된다. 
						     IF V_PREV_FNH_PACK2 IS NULL THEN
						   
						         V_MODE := 'U';
						
						     ELSE
						   	 	 
								 SELECT MAX(DESMP1_CD),
								 		MAX(MDL_MDY_CD)
					       		 INTO V_PREV_STRT_PACK2,
								      V_PREV_MDL_MDY_CD2
					 	   		 FROM TB_VEHL_MDY_MGMT
					 	   		 WHERE QLTY_VEHL_CD = P_VEHL_CD
					 	   		 AND DL_EXPD_REGN_CD = P_REGN_CD
					 	   		 AND DEFMP1_CD = V_PREV_FNH_PACK2;
						   
						         --최근 바로 이전에 지정된 종료 월팩 보다 현재 수정하고자 하는 시작월팩이 더 작으면 에러를 발생 시킨다.
						         IF V_PREV_STRT_PACK2 >= P_FROM_PACK THEN
						   	  
							         RAISE_APPLICATION_ERROR(-20001, '[Update2]Pack is more than ' || TO_CHAR(ADD_MONTHS(TO_DATE(V_PREV_STRT_PACK2, 'YYMM'), + 1), 'YYMM'));
						   
						         ELSIF V_PREV_STRT_PACK2 < P_FROM_PACK THEN
						   		 
			   	  	  			     --최근 바로 이전연식에 대한 종료월팩정보 설정 
			   	  	  			     UPDATE TB_VEHL_MDY_MGMT
			   	  	  			     SET DEFMP1_CD = TO_CHAR(ADD_MONTHS(TO_DATE(P_FROM_PACK, 'YYMM'), -1), 'YYMM'),
								         UPDR_EENO = P_USER_EENO,
				   	      			     MDFY_DTM = SYSDATE
			   	  	  			     WHERE QLTY_VEHL_CD = P_VEHL_CD
			   	  	  			     AND DL_EXPD_REGN_CD = P_REGN_CD
			   	  	  			     AND DESMP1_CD = V_PREV_FNH_PACK2
			   	  	  			     AND MDL_MDY_CD = V_PREV_MDL_MDY_CD2;
					  
						         END IF;
						
						         V_MODE := 'U'; 
						   
						     END IF; --가장 최근 정보 바로 이전의 정보가 있는지의 여부 비교 조건의 END IF       
						  
						  ELSE
						     --시작월팩이 같더라도 종료월팩을 '9999'로 세팅해 주어야 한다.
							 V_MODE := 'U';
							 
					      END IF; --가장 최근의 시작월팩과 현재 수정하고자 하는 시작월팩이 다른지의 비교 조건의 END IF 
					 
				      --연식이 다른 경우에는 신규 지정 작업 이다. 
			   	      ELSE
			   	  
				  	      --시작월팩이 이전종료월팩보다 최소한 한달은 커야 한다. 
			   	  	      IF V_PREV_FNH_PACK >= P_FROM_PACK THEN
			   	  
				  	  	     RAISE_APPLICATION_ERROR(-20001, '[Insert2]Pack is more than ' || TO_CHAR(ADD_MONTHS(TO_DATE(V_PREV_FNH_PACK, 'YYMM'), +1), 'YYMM'));
				  
			   	  	      END IF;
			   			  
						  /****  이전월팩의 정보는 이미 종료 처리한 것이기 때문에 변경해 주지 않고 그냥 둔다. 
						  
			   	  	      --이전종료월팩 계산 
			   	  	      V_PREV_FNH_PACK:= TO_CHAR(ADD_MONTHS(TO_DATE(P_FROM_PACK, 'YYMM'), -1), 'YYMM');
			   
			   	  	      --이전연식에 대한 종료월팩정보 설정 
			   	  	      UPDATE TB_VEHL_MDY_MGMT
			   	  	      SET DEFMP1_CD = V_PREV_FNH_PACK,
					          UPDR_EENO = P_USER_EENO,
				   	          MDFY_DTM = SYSDATE
			   	  	      WHERE QLTY_VEHL_CD = P_VEHL_CD
			   	  	      AND DL_EXPD_REGN_CD = P_REGN_CD
			   	  	      AND DESMP1_CD = V_PREV_STRT_PACK
			   	  	      AND MDL_MDY_CD = V_PREV_MDL_MDY_CD;
			              ****/
						  
					      V_MODE := 'I'; 
					  
			          END IF; --연식이 같은지 여부 비교 조건의 END IF 
					  
				  END IF;

			   END IF; --완료일 설정 작업 여부 비교 조건의 END IF 
			   
			END IF; --이전 연식 월팩 정보 지정 여부 비교 조건의 END IF 
			
			IF V_MODE = 'I' THEN
			   
			   INSERT INTO TB_VEHL_MDY_MGMT
			   (QLTY_VEHL_CD,
			 	DL_EXPD_REGN_CD,
			 	DESMP1_CD,
			 	DEFMP1_CD,
			 	MDL_MDY_CD,
			 	PPRR_EENO,
			 	FRAM_DTM,
			 	UPDR_EENO,
			 	MDFY_DTM
			   )
			   VALUES
			   (P_VEHL_CD,
			    P_REGN_CD,
				P_FROM_PACK,
				'9999',
				P_MDL_MDY_CD,
				P_USER_EENO,
				SYSDATE,
				P_USER_EENO,
				SYSDATE 
			   );
		    
			ELSIF V_MODE = 'U' THEN
			
			   UPDATE TB_VEHL_MDY_MGMT
			   SET DESMP1_CD = P_FROM_PACK,
			       DEFMP1_CD = '9999',
				   UPDR_EENO = P_USER_EENO,
				   MDFY_DTM = SYSDATE
			   WHERE QLTY_VEHL_CD = P_VEHL_CD
			   AND DL_EXPD_REGN_CD = P_REGN_CD
			   AND DESMP1_CD = V_PREV_STRT_PACK
			   AND MDL_MDY_CD = V_PREV_MDL_MDY_CD;
		    
			ELSIF V_MODE = 'F' THEN
			
			   UPDATE TB_VEHL_MDY_MGMT
			   SET DEFMP1_CD = P_FROM_PACK,
				   UPDR_EENO = P_USER_EENO,
				   MDFY_DTM = SYSDATE
			   WHERE QLTY_VEHL_CD = P_VEHL_CD
			   AND DL_EXPD_REGN_CD = P_REGN_CD
			   AND DESMP1_CD = V_PREV_STRT_PACK
			   AND MDL_MDY_CD = V_PREV_MDL_MDY_CD;
					  	  
			END IF;
            
            SELECT MAX(JB_MDY_REL_CD)
            INTO V_MDY_REL_CD
            FROM TB_VEHL_MDY_REL_MGMT
            WHERE QLTY_VEHL_CD = P_VEHL_CD
            AND MDL_MDY_CD = P_MDL_MDY_CD
            AND DL_EXPD_REGN_CD = P_REGN_CD;
            
            IF V_MDY_REL_CD IS NOT NULL THEN
            
                --직전연식관계 변화에 따른 취급설명서 연식코드 매핑 작업 수행 
			    SP_VEHL_MDY_REL_CD_UPDATE(P_VEHL_CD, P_MDL_MDY_CD, P_REGN_CD, V_MDY_REL_CD, P_USER_EENO);
            
            END IF;
            
	   END SP_VEHL_MDY_PACK_SAVE;
	   
	   --신규 차종 입력 항목에 대한 관리자 입력 권한 지정 						   
	   /*PROCEDURE SP_UPDATE_VEHL_AUTH(P_VEHL_CD    VARCHAR2,
	                                 P_PAC_SCN_CD VARCHAR2)
	   IS
	   
	   	 CURSOR CRGR_USER_LIST_INFO IS SELECT DL_EXPD_PRVS_NM AS USER_EENO
           							   FROM TB_CODE_MGMT
									   WHERE DL_EXPD_G_CD = CASE WHEN P_PAC_SCN_CD = '01' THEN '0031'
									                             ELSE '0032'
														    END 
									   AND USE_YN = 'Y';
	   BEGIN
	   		
			FOR USER_LIST IN CRGR_USER_LIST_INFO LOOP
				
				PG_USR_MGMT.SP_UPDATE_VEHL_AUTH_BY_USR(P_VEHL_CD, USER_LIST.USER_EENO);
				
			END LOOP;
			
	   END SP_UPDATE_VEHL_AUTH;*/
	   
	   PROCEDURE SP_LANG_MDY_REL_CD_UPDATE(P_VEHL_CD      VARCHAR2,
	   							           P_MDL_MDY_CD   VARCHAR2,
										   P_EXPD_REGN_CD VARCHAR2,
								           P_MDY_REL_CD   VARCHAR2,
										   P_USER_EENO    VARCHAR2)
	   IS
	   	 
		 CURSOR LANG_LIST_INFO IS SELECT LANG_CD
		 					   	  FROM TB_LANG_MGMT
								  WHERE QLTY_VEHL_CD = P_VEHL_CD
								  AND MDL_MDY_CD = P_MDL_MDY_CD
								  AND DL_EXPD_REGN_CD = P_EXPD_REGN_CD
								  AND USE_YN = 'Y';
/**								  
		 --이전연식 
		 V_PREV_MDL_MDY_CD VARCHAR2(2);
		 
		 --이후연식 
		 V_NEXT_MDL_MDY_CD VARCHAR2(2);
**/		 
	   BEGIN
	   		
			FOR LANG_LIST IN LANG_LIST_INFO LOOP
				
                PG_LANG_MGMT.SP_LANG_MDY_MGMT_SAVE(P_VEHL_CD, LANG_LIST.LANG_CD, P_MDL_MDY_CD, P_EXPD_REGN_CD, P_EXPD_REGN_CD, P_USER_EENO);

/**			
				--이전연식 계산 
				SELECT MAX(MDL_MDY_CD)
				INTO V_PREV_MDL_MDY_CD
				FROM TB_LANG_MGMT
				WHERE QLTY_VEHL_CD = P_VEHL_CD
				AND MDL_MDY_CD < P_MDL_MDY_CD
				AND LANG_CD = LANG_LIST.LANG_CD
				AND DL_EXPD_REGN_CD = P_EXPD_REGN_CD
				AND USE_YN = 'Y';
				
				--이후연식 계산 
				SELECT MIN(MDL_MDY_CD)
				INTO V_NEXT_MDL_MDY_CD
				FROM TB_LANG_MGMT
				WHERE QLTY_VEHL_CD = P_VEHL_CD
				AND MDL_MDY_CD > P_MDL_MDY_CD
				AND LANG_CD = LANG_LIST.LANG_CD
				AND DL_EXPD_REGN_CD = P_EXPD_REGN_CD
				AND USE_YN = 'Y';
				
				--완전통합의 경우 
				IF P_MDY_REL_CD = '01' THEN
			   
			   	   IF V_PREV_MDL_MDY_CD IS NOT NULL THEN
			   	  
				   	  SP_LANG_MDY_MGMT_SAVE(P_VEHL_CD, LANG_LIST.LANG_CD, P_MDL_MDY_CD, P_EXPD_REGN_CD, V_PREV_MDL_MDY_CD, P_USER_EENO);
				  
			   	   END IF;
			   
			   	   SP_LANG_MDY_MGMT_SAVE(P_VEHL_CD, LANG_LIST.LANG_CD, P_MDL_MDY_CD, P_EXPD_REGN_CD, P_MDL_MDY_CD, P_USER_EENO);
			   
			   	   IF V_NEXT_MDL_MDY_CD IS NOT NULL THEN
			   	  
				   	  SP_LANG_MDY_MGMT_SAVE(P_VEHL_CD, LANG_LIST.LANG_CD, P_MDL_MDY_CD, P_EXPD_REGN_CD, V_NEXT_MDL_MDY_CD, P_USER_EENO);
				  
			   	   END IF;
			   
			   --전방통합의 경우   
			   ELSIF P_MDY_REL_CD = '02' THEN
			   
			   	   SP_LANG_MDY_MGMT_SAVE(P_VEHL_CD, LANG_LIST.LANG_CD, P_MDL_MDY_CD, P_EXPD_REGN_CD, P_MDL_MDY_CD, P_USER_EENO);
			   
			   	   IF V_NEXT_MDL_MDY_CD IS NOT NULL THEN
			   	  
				   	  SP_LANG_MDY_MGMT_SAVE(P_VEHL_CD, LANG_LIST.LANG_CD, P_MDL_MDY_CD, P_EXPD_REGN_CD, V_NEXT_MDL_MDY_CD, P_USER_EENO);
				  
			   	   END IF;
			   
			   --후방통합의 경우    
			   ELSIF P_MDY_REL_CD = '03' THEN
			   
			   	   IF V_PREV_MDL_MDY_CD IS NOT NULL THEN
			   	  
				  	  SP_LANG_MDY_MGMT_SAVE(P_VEHL_CD, LANG_LIST.LANG_CD, P_MDL_MDY_CD, P_EXPD_REGN_CD, V_PREV_MDL_MDY_CD, P_USER_EENO);
				  
			       END IF;
			   
			   	   SP_LANG_MDY_MGMT_SAVE(P_VEHL_CD, LANG_LIST.LANG_CD, P_MDL_MDY_CD, P_EXPD_REGN_CD, P_MDL_MDY_CD, P_USER_EENO);
			   
			   --완전분리의 경우 
			   ELSE
				
				   --현재연식은 현재의 취급설명서 연식만을 사용한다. 
			   	   SP_LANG_MDY_MGMT_SAVE(P_VEHL_CD, LANG_LIST.LANG_CD, P_MDL_MDY_CD, P_EXPD_REGN_CD, P_MDL_MDY_CD, P_USER_EENO);
			   
			   END IF;
**/
			
			END LOOP;
			
	   END SP_LANG_MDY_REL_CD_UPDATE;
	   				
	   
	   PROCEDURE SP_GET_PLNT_LIST(P_VEHL_CD VARCHAR2,
	                              RS        OUT REFCUR)
	   IS
	   BEGIN
	   
	   	 OPEN RS FOR
		 	  SELECT PRDN_PLNT_CD, PLNT_NM
			  FROM TB_PLNT_VEHL_MGMT
			  WHERE QLTY_VEHL_CD = P_VEHL_CD
			  ORDER BY SORT_SN;
			  
	   END SP_GET_PLNT_LIST;

		PROCEDURE SP_UPDATE_NATL_VEHL_MGMT
		IS
		BEGIN

			-- 국가별 언어코드에는 추가되어있으나, 국가별 차종코드에는 추가되지 않은 경우 처리
			INSERT INTO TB_NATL_VEHL_MGMT
			SELECT
				DISTINCT
				  A.DL_EXPD_CO_CD
				, A.DL_EXPD_NAT_CD
				, A.QLTY_VEHL_CD
				, C.DL_EXPD_REGN_CD
				, 'SYSTEM'
				, SYSDATE
				, 'SYSTEM'
				, SYSDATE
			FROM TB_NATL_LANG_MGMT A
			LEFT OUTER JOIN TB_NATL_VEHL_MGMT B
				ON A.QLTY_VEHL_CD = B.QLTY_VEHL_CD AND A.DL_EXPD_NAT_CD = B.DL_EXPD_NAT_CD
			INNER JOIN TB_NATL_MGMT C
				ON A.DL_EXPD_CO_CD = C.DL_EXPD_CO_CD AND A.DL_EXPD_NAT_CD = C.DL_EXPD_NAT_CD
			WHERE B.QLTY_VEHL_CD IS NULL
			--	AND A.MDL_MDY_CD = '17'
			;
			
			COMMIT;
			
		END SP_UPDATE_NATL_VEHL_MGMT;

END PG_VEHL_MGMT;