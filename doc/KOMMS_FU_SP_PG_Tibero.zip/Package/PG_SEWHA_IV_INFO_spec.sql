CREATE OR REPLACE PACKAGE KOMMS_ADM.PG_SEWHA_IV_INFO AS

   TYPE REFCUR IS REF CURSOR;

   --세화재고 조회(PDI, 차종, 연식, 지역, 언어)
   PROCEDURE SP_GET_SEWHA_IV_INFO(P_MENU_ID 	 VARCHAR2,
								  P_USER_EENO    VARCHAR2,
								  P_CURR_YMD	 VARCHAR2,
 								  P_PDI_CD	     VARCHAR2,
								  P_VEHL_CD	     VARCHAR2,
								  P_MDL_MDY	     VARCHAR2,
								  P_REGN_CD	     VARCHAR2,
								  P_LANG_CD	     VARCHAR2,
								  P_DLVY_STATE   VARCHAR2,
								  P_IV_STATE     VARCHAR2,
                                  RS 		     OUT REFCUR,
                                  P_MESSAGE      OUT VARCHAR2);

   --세화재고 조회(승상구분, PDI, 차종, 연식, 지역, 언어)
   PROCEDURE SP_GET_SEWHA_IV_INFO2(P_MENU_ID 	  VARCHAR2,
								   P_USER_EENO 	  VARCHAR2,
								   P_CURR_YMD	  VARCHAR2,
								   P_PAC_SCN_CD	  VARCHAR2,
 								   P_PDI_CD		  VARCHAR2,
								   P_VEHL_CD	  VARCHAR2,
								   P_MDL_MDY	  VARCHAR2,
								   P_REGN_CD	  VARCHAR2,
								   P_LANG_CD	  VARCHAR2,
								   P_DLVY_STATE   VARCHAR2,
								   P_IV_STATE     VARCHAR2,
                                   RS 		      OUT REFCUR);

	--세화출고 현황 조회
	PROCEDURE SP_GET_SEWHA_WHOT_INFO(P_MENU_ID 	    VARCHAR2,
								     P_USER_EENO    VARCHAR2,
			  						 P_DATA_SN_LIST VARCHAR2,
			  						 P_CURR_YMD     VARCHAR2,
			  						 RS OUT REFCUR);

	--세화출고 현황 조회(EXCEL 전용)
	PROCEDURE SP_GET_SEWHA_WHOT_INFO_EXCEL(P_MENU_ID 	         VARCHAR2,
								           P_USER_EENO           VARCHAR2,
			  						       P_DATA_SN_LIST        VARCHAR2,
										   P_N_PRNT_PBCN_NO_LIST VARCHAR2,
			  						       P_CURR_YMD            VARCHAR2,
			  						       RS OUT REFCUR);

	--세화출고 현황 조회2
	PROCEDURE SP_GET_SEWHA_WHOT_INFO2(P_MENU_ID 	 VARCHAR2,
								      P_USER_EENO    VARCHAR2,
									  P_CURR_YMD     VARCHAR2,
			  						  P_PDI_CD       VARCHAR2,
									  P_VEHL_CD		 VARCHAR2,
									  P_MDL_MDY		 VARCHAR2,
									  P_REGN_CD	     VARCHAR2,
								      P_LANG_CD	     VARCHAR2,
			  						  RS OUT REFCUR);

	--세화출고 현황 저장
	PROCEDURE SP_SEWHA_WHOT_INFO_SAVE(P_VEHL_CD         VARCHAR2,
			  						  P_MDL_MDY_CD		VARCHAR2,
									  P_LANG_CD         VARCHAR2,
									  P_EXPD_MDL_MDY_CD VARCHAR2,
									  P_N_PRNT_PBCN_NO  VARCHAR2,
									  P_DTL_SN          NUMBER,
									  P_EXPD_RQ_SCN_CD  VARCHAR2,
									  P_RQ_QTY          NUMBER,
									  P_EXPD_BOX_QTY    NUMBER,
									  P_DLVG_PARR_YMD   VARCHAR2,
									  P_DLVG_PARR_HHMM  VARCHAR2,
									  P_PWTI_EENO       VARCHAR2,
									  P_PRTL_IMTR_SBC   VARCHAR2,
									  P_CLS_YMD		    VARCHAR2, --현재 날짜를 Parameter에서 빼고 SYSTEM 날짜로 해도 되지 않을까?
									  P_USER_EENO       VARCHAR2
									  , P_PRDN_PLNT_CD  VARCHAR2
									  );

	--입고확인시에 세화 출고내역에서 입고확인상태로 변경하는 작업 수행
	PROCEDURE SP_SEWHA_WHOT_INFO_UPDATE(P_VEHL_CD         VARCHAR2,
	   			 					    P_MDL_MDY_CD	  VARCHAR2,
									    P_LANG_CD         VARCHAR2,
										P_EXPD_MDL_MDY_CD VARCHAR2,
									    P_N_PRNT_PBCN_NO  VARCHAR2,
										P_DTL_SN		  NUMBER,
										P_WHSN_YMD		  VARCHAR2,
										P_RQ_QTY		  NUMBER,
										P_USER_EENO		  VARCHAR2);

	--세화 출고 정보 삭제
	PROCEDURE SP_SEWHA_WHOT_INFO_DELETE(P_VEHL_CD         VARCHAR2,
			  							P_MDL_MDY_CD	  VARCHAR2,
									    P_LANG_CD         VARCHAR2,
										P_EXPD_MDL_MDY_CD VARCHAR2,
									    P_N_PRNT_PBCN_NO  VARCHAR2,
									    P_DTL_SN          NUMBER,
										P_USER_EENO       VARCHAR2);

	--세화 입고정보/재고정보 Insert
	PROCEDURE SP_SEWHA_WHSN_INFO_SAVE(P_WHSN_YMD        VARCHAR2,
			  						  P_QLTY_VEHL_CD    VARCHAR2,
									  P_MDL_MDY_CD		VARCHAR2,
									  P_LANG_CD         VARCHAR2,
									  P_EXPD_MDL_MDY_CD VARCHAR2,
									  P_N_PRNT_PBCN_NO  VARCHAR2,
									  P_WHSN_QTY        NUMBER,
									  P_CRGR_EENO       VARCHAR2,
									  P_PRNT_PARR_YMD   VARCHAR2,
									  P_DLVG_PARR_YMD   VARCHAR2,
									  P_USER_EENO       VARCHAR2);

	--세화 입고정보 취소 수행
	PROCEDURE SP_SEWHA_WHSN_INFO_CANCEL(P_WHSN_YMD        VARCHAR2,
			  						    P_QLTY_VEHL_CD    VARCHAR2,
										P_MDL_MDY_CD	  VARCHAR2,
									    P_LANG_CD         VARCHAR2,
										P_EXPD_MDL_MDY_CD VARCHAR2,
									    P_N_PRNT_PBCN_NO  VARCHAR2,
									    P_WHSN_QTY        NUMBER,
									    P_USER_EENO       VARCHAR2);

	--PDI재고 보정시에 반출, 불량 항목에 대한 세화 업데이트 작업을 수행
	PROCEDURE SP_SEWHA_WHOT_INFO_UPDATE2(P_VEHL_CD         VARCHAR2,
			  							 P_MDL_MDY_CD	   VARCHAR2,
									     P_LANG_CD         VARCHAR2,
										 P_EXPD_MDL_MDY_CD VARCHAR2,
									     P_N_PRNT_PBCN_NO  VARCHAR2,
										 P_WHOT_YMD		   VARCHAR2,
										 P_RQ_QTY		   NUMBER,
										 P_USER_EENO	   VARCHAR2);
	--세화 납품예정일 변경
	PROCEDURE SP_SEWHA_DLVG_PARR_YMD_UPDATE(P_WHSN_YMD        VARCHAR2,
			  								P_VEHL_CD         VARCHAR2,
	   			 					        P_MDL_MDY_CD 	  VARCHAR2,
									        P_LANG_CD         VARCHAR2,
											P_EXPD_MDL_MDY_CD VARCHAR2,
									        P_N_PRNT_PBCN_NO  VARCHAR2,
											P_DLVG_PARR_YMD   VARCHAR2,
										    P_USER_EENO       VARCHAR2);

	--세화 재고정보 일배치 정리작업 수행
	--반드시 현재일 시작시간에 돌려야 한다.
	PROCEDURE SP_SEWHA_IV_INFO_BATCH;

END PG_SEWHA_IV_INFO;