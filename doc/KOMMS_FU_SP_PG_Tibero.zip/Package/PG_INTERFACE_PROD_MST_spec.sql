CREATE OR REPLACE PACKAGE KOMMS_ADM.PG_INTERFACE_PROD_MST AS

	   EXPD_CO_CD_HMC  CONSTANT VARCHAR2(4) := PG_DATA.EXPD_CO_CD_HMC;   -- HMC
	   EXPD_CO_CD_KMC  CONSTANT VARCHAR2(4) := '02';   -- KMC
	   EXPD_DOM_NAT_CD CONSTANT VARCHAR2(5) := 'A99VA';  -- 내수 국가코드
	   BTCH_USER_EENO  CONSTANT VARCHAR2(7) := '5900513';   -- 배치작업 담당자 코드

	   HMC_CLOSE_TIME  CONSTANT VARCHAR2(4) := PG_DATA.HMC_CLOSE_TIME;   -- 현재 I/F 마감기준시간
	   KMC_CLOSE_TIME  CONSTANT VARCHAR2(4) := '0530';   -- 기아 I/F 마감기준시간

	   DATE_DIFF_CNT   CONSTANT NUMBER      := 7;						 -- 조회기간

/**********************************************************/
/** KMC 인터페이스 **/

	   --기아 생산마스터 인터페이스(외부 호출)
	   PROCEDURE PROD_MST_INTERFACE_KMC;
	   PROCEDURE PROD_MST_INTERFACE_KMC2(P_CURR_YMD VARCHAR2
       									,P_ET_GUBN_CD VARCHAR2);

	   --기아 날짜가 변경될 경우 데이터 Summary 작업 수행(외부 호출, 오라클 스케쥴링)
	   PROCEDURE PROD_MST_INTERFACE_DATE_KMC;

/**********************************************************/

/**********************************************************/
	   --용도차가 아닌지의 여부를 확인
	   FUNCTION CHECK_VALID_DATA(P_PRDN_ORD_NO VARCHAR2,
	                             P_DEST_NAT_CD VARCHAR2)RETURN VARCHAR2;

	   --생산마스터의 연식을 오너스매뉴얼 연식으로 변환하는 함수
	   FUNCTION GET_MDY_CD(MDL_MDY_CD IN VARCHAR2) RETURN VARCHAR2;
	   
	   -- 국가마스터에서 5자리 OR 3자리 국가코드 반환하는 함수
	   FUNCTION GET_NAT_CD(P_DL_EXPD_NAT_CD IN VARCHAR2) RETURN VARCHAR2;

       --[변경] 2011-08-05.김동근 KMC ERP 적용으로 프로그램 수정
	   --[추가] 2010-08-11.김동근 ERP 공정위치 코드를 01 ~ 16 사이의 공정위치 코드로 변환하는 함수
	   FUNCTION GET_POW_LOC_CD_ERP(P_POW_LOC_CD IN CHAR,
                                   P_EXPD_CO_CD IN VARCHAR2) RETURN VARCHAR2;
       FUNCTION GET_POW_LOC_CD_ERP2(P_TH1_POW_STRT_YMDHM CHAR,
                                    P_TH2_POW_STRT_YMDHM CHAR,
                                    P_TH3_POW_STRT_YMDHM CHAR,
                                    P_TH4_POW_STRT_YMDHM CHAR,
                                    P_TH5_POW_STRT_YMDHM CHAR,
                                    P_TH6_POW_STRT_YMDHM CHAR,
                                    P_TH7_POW_STRT_YMDHM CHAR,
                                    P_TH8_POW_STRT_YMDHM CHAR,
                                    P_TH9_POW_STRT_YMDHM CHAR,
                                    P_T10PS1_YMDHM       CHAR,
                                    P_T11PS1_YMDHM       CHAR) RETURN VARCHAR2;

       --[변경] 2011-08-05.김동근 KMC ERP 적용으로 프로그램 수정
	   --[추가] 2010-08-11.김동근 ERP 공장코드를 APS 의 공장코드로 변환하는 함수
	   FUNCTION GET_PRDN_PLNT_CD_ERP(P_PLNT_CD IN CHAR,
                                     P_EXPD_CO_CD IN VARCHAR2)RETURN VARCHAR2;

	   --인터페이스 시에 현재 년월일시분 정보를 기반으로 마감기준일자를 리턴
	   FUNCTION GET_CLOSING_YMD(CURR_YMDHM   IN VARCHAR2,
	                            P_EXPD_CO_CD IN VARCHAR2) RETURN VARCHAR2;

	   --[PPMS전용] 시간에 해당하는 날짜 리턴
	   FUNCTION GET_CLOSING_YMD2(CURR_YMDHM   IN VARCHAR2,
	   							 CURR_YMD	  IN VARCHAR2,
	                             P_EXPD_CO_CD IN VARCHAR2) RETURN VARCHAR2;

	   --[내수전용] VIN에 해당하는 출고일 리턴(GSW 데이터 조회)
	   FUNCTION GET_DOM_SALE_YMD(P_EXPD_CO_CD VARCHAR2,
	   							 P_VIN        CHAR)RETURN VARCHAR2;

	   --생산마스터 테이블 차종코드, 연식, 취급설명서 국가코드 일괄 적용시 사용하는 프로시저
	   --(GET_APS_PROD_SUM_LIST 프로시저 내에서 사용함)
	   PROCEDURE GET_MANUAL_PROD_INFO_LIST(FROM_YMD IN VARCHAR2,
	                                       TO_YMD   IN VARCHAR2);

	   --생산마스터 테이블 차종코드, 연식, 취급설명서 국가코드 적용시 사용하는 프로시저
	   PROCEDURE GET_MANUAL_PROD_INFO_DETAIL(CURR_YMD IN VARCHAR2);

       --APS 차종, 월팩, 목적국 코드에 해당하는 품질차종코드, 연식, 취급설명서 국가코드를 추출
	   --생산마스터 차종이 일정하지 않으므로(2자리 또는 3자리) 이곳에서 해당 차종코드값을 얻어오는 작업도 병행한다.
	   PROCEDURE GET_MANUAL_INFO(P_APL_YMD		 IN  VARCHAR2,
	   			 				 P_EXPD_CO_CD    IN  VARCHAR2,
	   			 				 P_PRDN_VEHL_CD  IN  VARCHAR2,
	   			 				 P_MO_PACK_CD    IN  VARCHAR2,
								 P_DEST_NAT_CD   IN  VARCHAR2,
								 P_BASC_MDL_CD   IN  VARCHAR2,
								 P_QLTY_VEHL_CD  OUT VARCHAR2,
								 P_MDL_MDY_CD    OUT VARCHAR2,
								 P_EXPD_NAT_CD   OUT VARCHAR2,
								 P_PRDN2_VEHL_CD OUT VARCHAR2);

/**********************************************************/

/**********************************************************/
	   --인터페이스 데이터 Summary 작업 수행(외부 호출)
	   PROCEDURE GET_PROD_MST_SUM_LIST(FROM_YMD   IN VARCHAR2,
	                                   TO_YMD     IN VARCHAR2);

/**********************************************************/

/**********************************************************/

       PROCEDURE LOAD_PROD_MST_INFO(P_CURR_YMD   IN VARCHAR2,
	                                P_EXPD_CO_CD IN VARCHAR2,
       								P_ET_GUBN_CD VARCHAR2);

	   --[추가] 2010-08-11.김동근 현대 ERP로 부터 생산실적 로드
--	   PROCEDURE LOAD_PROD_MST_ERP_HMC(P_CURR_YMD   IN VARCHAR2,
--	                                   P_EXPD_CO_CD IN VARCHAR2);

       --[추가] 2011-08-05.김동근 기아 ERP로 부터 생산실적 로드
	   PROCEDURE LOAD_PROD_MST_ERP_KMC(P_CURR_YMD   IN VARCHAR2,
	   								   P_APL_YMD    IN VARCHAR2,
	                                   P_EXPD_CO_CD IN VARCHAR2,
	                                   P_ET_GUBN_CD IN VARCHAR2
	                                   );

	   --평택 공장 전용 PDI IN 시간 얻어오는 프로시저
--	   PROCEDURE GET_PDI_IN_YMD(P_VIN          IN  VARCHAR2,
--	   			 				P_TRWI_YMD	   IN  VARCHAR2,
--								P_EXPD_CO_CD   IN  VARCHAR2,
--	   			 				P_T10PS1_YMDHM OUT VARCHAR2,
--		 						P_T10PS1_YMD   OUT VARCHAR2);
--
--	   --평택 공장 전용 PDI IN 시간 정보 로드 프로시저
--	   PROCEDURE LOAD_PDI_IN_YMD(FROM_YMD     IN VARCHAR2,
--	                             TO_YMD       IN VARCHAR2,
--	                             P_EXPD_CO_CD IN VARCHAR2);

	   PROCEDURE SP_UPDATE_PROD_MST_PROG_INFO(P_PRDN_MST_VEHL_CD IN VARCHAR2,
	    				   					  P_BN_SN            IN VARCHAR2,
											  P_EXPD_CO_CD       IN VARCHAR2,
	   			 							  P_APL_YMD          IN VARCHAR2,
                                              P_VIN              IN VARCHAR2
                                              , P_PLNT_CD        IN VARCHAR2
                                              );

	   FUNCTION GET_PROD_MST_PROG_MAX_DTL_SN(P_PRDN_MST_VEHL_CD IN VARCHAR2,
	    				   					 P_BN_SN            IN VARCHAR2,
											 P_EXPD_CO_CD       IN VARCHAR2,
											 P_APL_STRT_YMD     IN VARCHAR2,
											 P_APL_FNH_YMD      IN VARCHAR2,
                                             P_VIN              IN VARCHAR2
                                             ) RETURN NUMBER;
	   --구버전(사용안함)
	   PROCEDURE GET_PROD_MST_SUM(FROM_YMD   IN VARCHAR2,
	                              TO_YMD     IN VARCHAR2,
								  EXPD_CO_CD IN VARCHAR2);


	   --신버전
	   PROCEDURE GET_PROD_MST_SUM2(FROM_YMD   IN VARCHAR2,
	                               TO_YMD     IN VARCHAR2,
	                               P_APL_YMD  IN VARCHAR2,
								   EXPD_CO_CD IN VARCHAR2);

	   PROCEDURE GET_PROD_MST_PROG_SUM(CURR_YMD IN VARCHAR2,
	                                   EXPD_CO_CD IN VARCHAR2);

	   --화면에 표시되는 데이터의 형태로 생산마스터 정보를 취합하는 작업을 수행
	   PROCEDURE GET_PROD_MST_SUM_DTL(CURR_YMD   IN VARCHAR2,
	   			 					  SRCH_YMD	 IN VARCHAR2,
	                                  EXPD_CO_CD IN VARCHAR2);

/**********************************************************/

/**********************************************************/
	   --배치결과 정보 존재 여부 조회
	   FUNCTION GET_BTCH_FNH_YN(CURR_YMD   IN VARCHAR2,
	                            EXPD_CO_CD IN VARCHAR2,
	                            P_ET_GUBN_CD IN VARCHAR2)RETURN VARCHAR2;

	   --인터페이스 성공시에 완료일자를 저장
	   PROCEDURE SAVE_PROD_MST_BTCH_FNH_INFO(CURR_YMD   IN VARCHAR2,
	                                         EXPD_CO_CD IN VARCHAR2,
	                                         P_ET_GUBN_CD IN VARCHAR2);
/**********************************************************/

/**********************************************************/

	   --ALC 마스터 데이터 인터페이스 수행
	   PROCEDURE ALC_MST_INTERFACE;

	   --ALC 마스터 데이터 시간단위 인터페이스 수행
	   PROCEDURE ALC_MST_INTERFACE_BY_TIME(EXPD_CO_CD IN VARCHAR2);

--	   PROCEDURE ALC_MST_INTERFACE_DETAIL(P_FROM_DATE IN DATE,
--	   			 						  P_TO_DATE   IN DATE,
--										  EXPD_CO_CD  IN VARCHAR2);

	   --ALC 데이터에서의 PDI IN/OUT 시간을 얻어오는 프로시저
	   PROCEDURE GET_ALC_PDI_IN_OUT_YMDHM(P_PRDN_VEHL_CD       VARCHAR2,
	                                      P_BN_SN		  	   CHAR,
									      P_EXPD_CO_CD	  	   VARCHAR2,
									      P_VIN			  	   CHAR,
									      P_PDI_CD         	   VARCHAR2,
									      P_TRWI_YMD		   VARCHAR2,
										  P_TMP_TRWI_YMDHM OUT VARCHAR2,
		 								  P_TMP_TRWI_YMD   OUT VARCHAR2);

	   --ALC PDI IN 시간 정보 로드 프로시저
	   PROCEDURE LOAD_ALC_PDI_IN_YMD(FROM_YMD     IN VARCHAR2,
	                                 TO_YMD       IN VARCHAR2,
	                                 P_EXPD_CO_CD IN VARCHAR2);

	   --내수 출고일 정보 로드 프로시저
	   PROCEDURE LOAD_DOM_SALE_YMD;

	   /**
	   --ALC PDI OUT 시간 정보 로드 프로시저
	   PROCEDURE LOAD_ALC_PDI_OUT_YMD(FROM_YMD     IN VARCHAR2,
	                                  TO_YMD       IN VARCHAR2,
	                                  P_EXPD_CO_CD IN VARCHAR2);
	   **/

/**********************************************************/

	   --투입일 추가로 인한 투입일 계산 프로시저
	   --(현재 사용할 수 없음, 2009-01-19 이전 데이터의 경우 사용시 마감기준 일자를 얻어올 수 있는 방법이 없어서 데이터가 잘못될 수 있음)
	   /**
	   PROCEDURE SP_UPDATE_TRWI_YMD;
	   **/

	   /**
	   PROCEDURE LOAD_PROD_MST_INFO_HMC_TEMP;
	   **/

END PG_INTERFACE_PROD_MST;