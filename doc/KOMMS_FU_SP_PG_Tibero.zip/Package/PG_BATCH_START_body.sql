CREATE OR REPLACE PACKAGE BODY KOMMS_ADM.PG_BATCH_START AS

/**********************************************************/
/** 오전 생산실적 처리(02)                               **/
       PROCEDURE SP_BATCH_WORK02

       IS
            V_CHK_KMC     VARCHAR2(1);
            V_T_CHK       VARCHAR2(1);
       BEGIN
       
       		-- 배치 처리 전에 국가별 차종코드나 언어 코드 관리에 설정이 없는 경우 체크하여 업데이트 한다.
       		PG_VEHL_MGMT.SP_UPDATE_NATL_VEHL_MGMT;
       		PG_LANG_MGMT.SP_UPDATE_LANG_MGMT;

            PG_INTERFACE_PROD_MST.PROD_MST_INTERFACE_KMC2(TO_CHAR(SYSDATE,'YYYYMMDD'),'02');  -- 생산정보 처리(전일 기준)

            PG_INTERFACE_APS.APS_INTERFACE_KMC;   -- 오더/생산계획 정보 처리

            SELECT DECODE(COUNT(*),3,'Y','N')
              INTO V_CHK_KMC
              FROM TB_BATCH_FNH_INFO
             WHERE AFFR_SCN_CD in ('01','02','03')
               AND DL_EXPD_CO_CD = '02'
               AND BTCH_FNH_YMD = TO_CHAR(SYSDATE,'YYYYMMDD');

            IF V_CHK_KMC = 'Y' THEN
            -- JOB NEXT TIME SET
                DBMS_JOB.NEXT_DATE(11, ((TO_DATE(TO_CHAR(SYSDATE + 1, 'YYYY-MM-DD')) + INTERVAL '5' HOUR) + INTERVAL '30' MINUTE) );
                -- 긴급인쇄 리스트 이메일 발송
                SEND_URGENT_PRINT_MAIL ();
            ELSE
                V_T_CHK := GET_TIME_CHK('01');

                IF V_T_CHK = 'Y' THEN
                    -- JOB 10MIN DELAY
                    DBMS_JOB.NEXT_DATE(11, (SYSDATE + INTERVAL '10' MINUTE) );
                ELSE
                    -- 작업 실패 로그 저장 후 TIME SET
                    PG_INTERFACE_APS.WRITE_BATCH_LOG('생산마스터배치작업_KMC2', SYSDATE, 'F', 'PROD_MST_INTERFACE_KMC2(02) :: ERP 배치 미실행 확인');
                    DBMS_JOB.NEXT_DATE(11, ((TO_DATE(TO_CHAR(SYSDATE + 1, 'YYYY-MM-DD')) + INTERVAL '5' HOUR) + INTERVAL '30' MINUTE) );
                END IF;
            END IF;

       END SP_BATCH_WORK02;

/**********************************************************/
/** 오후 생산실적 처리(01)                               **/
       PROCEDURE SP_BATCH_WORK01

       IS
            V_CHK_KMC     VARCHAR2(1);
            V_T_CHK       VARCHAR2(1);
       BEGIN

       		-- 배치 처리 전에 국가별 차종코드나 언어 코드 관리에 설정이 없는 경우 체크하여 업데이트 한다.
       		PG_VEHL_MGMT.SP_UPDATE_NATL_VEHL_MGMT;
       		PG_LANG_MGMT.SP_UPDATE_LANG_MGMT;

            PG_INTERFACE_PROD_MST.PROD_MST_INTERFACE_KMC2(TO_CHAR(SYSDATE,'YYYYMMDD'),'01');  -- 생산정보 처리(당일 기준)

            SELECT DECODE(COUNT(*),0,'N','Y')
              INTO V_CHK_KMC
              FROM TB_BATCH_FNH_INFO
             WHERE AFFR_SCN_CD = '04'
               AND DL_EXPD_CO_CD = '02'
               AND BTCH_FNH_YMD = TO_CHAR(SYSDATE,'YYYYMMDD');

            IF V_CHK_KMC = 'Y' THEN
                -- 기준시간 이전이면 JOB NEXT_DATE 10분 후 SET
                DBMS_JOB.NEXT_DATE(10, ((TO_DATE(TO_CHAR(SYSDATE + 1, 'YYYY-MM-DD')) + INTERVAL '14' HOUR) + INTERVAL '40' MINUTE) );
                
                -- 긴급인쇄 리스트 이메일 발송
                SEND_URGENT_PRINT_MAIL ();
            ELSE
                V_T_CHK := GET_TIME_CHK('01');

                IF V_T_CHK = 'Y' THEN
                    -- JOB 10MIN DELAY
                    DBMS_JOB.NEXT_DATE(10, (SYSDATE + INTERVAL '10' MINUTE) );
                ELSE
                    -- 작업 실패 로그 저장 후 다음 날 NEXT_DATE SET
                    PG_INTERFACE_APS.WRITE_BATCH_LOG('생산마스터배치작업_KMC2', SYSDATE, 'F', 'PROD_MST_INTERFACE_KMC2(01) :: ERP 배치 미실행 확인');
                    DBMS_JOB.NEXT_DATE(10, ((TO_DATE(TO_CHAR(SYSDATE + 1, 'YYYY-MM-DD')) + INTERVAL '14' HOUR) + INTERVAL '40' MINUTE) );
                END IF;
            END IF;

       END SP_BATCH_WORK01;

/**********************************************************/
       FUNCTION GET_TIME_CHK(ET_GUBN_CD IN VARCHAR2) RETURN VARCHAR2

       IS
         T_CHK VARCHAR2(1);

       BEGIN

            IF ET_GUBN_CD = '02' THEN
                  -- 오후 2시까지 Try
                SELECT CASE WHEN SYSDATE < (TO_DATE(TO_CHAR(SYSDATE, 'YYYY-MM-DD')) + INTERVAL '14' HOUR) THEN 'Y'
                            ELSE 'N'
                       END CHK
                  INTO T_CHK
                  FROM DUAL;

            ELSE
                 -- 오후 10시까지 Try
                SELECT CASE WHEN SYSDATE < (TO_DATE(TO_CHAR(SYSDATE, 'YYYY-MM-DD')) + INTERVAL '22' HOUR) THEN 'Y'
                            ELSE 'N'
                       END CHK
                  INTO T_CHK
                  FROM DUAL;

            END IF;

            RETURN T_CHK;

       END GET_TIME_CHK;

/**********************************************************/

END PG_BATCH_START;