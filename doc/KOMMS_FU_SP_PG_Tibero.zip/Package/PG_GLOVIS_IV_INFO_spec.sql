CREATE OR REPLACE PACKAGE KOMMS_ADM.PG_GLOVIS_IV_INFO AS

	   TYPE REFCUR IS REF CURSOR;

	   --글로비스재고 조회(PDI, 차종, 연식, 지역, 언어)
   	   PROCEDURE SP_GET_GLOVIS_IV_INFO(P_MENU_ID 	VARCHAR2,
								       P_USER_EENO  VARCHAR2,
								       P_CURR_YMD	VARCHAR2,
									   P_EXPD_CO_CD VARCHAR2,
 								       P_PDI_CD	    VARCHAR2,
								       P_VEHL_CD	VARCHAR2,
								       P_MDL_MDY	VARCHAR2,
								       P_REGN_CD	VARCHAR2,
								       P_LANG_CD	VARCHAR2,
								       P_DLVY_STATE VARCHAR2,
                                       RS 		  OUT REFCUR,
                                       P_MESSAGE OUT VARCHAR2);

	   --글로비스재고 조회(승상구분, PDI, 차종, 연식, 지역, 언어)
   	   PROCEDURE SP_GET_GLOVIS_IV_INFO2(P_MENU_ID 	 VARCHAR2,
								        P_USER_EENO  VARCHAR2,
								        P_CURR_YMD	 VARCHAR2,
										P_EXPD_CO_CD VARCHAR2,
								        P_PAC_SCN_CD VARCHAR2,
 								        P_PDI_CD	 VARCHAR2,
								        P_VEHL_CD	 VARCHAR2,
								        P_MDL_MDY	 VARCHAR2,
								        P_REGN_CD	 VARCHAR2,
								        P_LANG_CD	 VARCHAR2,
								        P_DLVY_STATE VARCHAR2,
                                        RS 		OUT REFCUR);

	   --글로비스 배송요청 정보 조회
	   PROCEDURE SP_GET_GLOVIS_DLVH_REQ_INFO(P_MENU_ID 	    VARCHAR2,
								             P_USER_EENO    VARCHAR2,
	   			 						     P_DATA_SN_LIST VARCHAR2,
											 P_CURR_YMD     VARCHAR2,
			  						    	 RS OUT REFCUR);
       --글로비스 배송요청 정보 저장
	   PROCEDURE SP_GLOVIS_DLVH_REQ_SAVE(P_VEHL_CD        VARCHAR2,
	   			 			             P_MDL_MDY_CD     VARCHAR2,
							             P_LANG_CD        VARCHAR2,
										 P_DTL_SN		  NUMBER,
										 P_RQ_SCN_CD	  VARCHAR2,
							             P_RQ_QTY		  NUMBER,
										 P_IMTR_SBC		  VARCHAR2,
							             P_PWMR_EENO      VARCHAR2,
							             P_USER_EENO      VARCHAR2);

	   --글로비스 배송요청 정보 삭제
	   PROCEDURE SP_GLOVIS_DLVH_REQ_DELETE(P_VEHL_CD    VARCHAR2,
	   			 			               P_MDL_MDY_CD VARCHAR2,
							               P_LANG_CD    VARCHAR2,
										   P_DTL_SN		NUMBER,
										   P_USER_EENO  VARCHAR2);

END PG_GLOVIS_IV_INFO;