CREATE OR REPLACE PACKAGE BODY KOMMS_ADM.PG_SEWHA_IV_INFO AS

   --세화재고 조회(PDI, 차종, 연식, 지역, 언어) 
   PROCEDURE SP_GET_SEWHA_IV_INFO(P_MENU_ID 	 VARCHAR2,
								  P_USER_EENO    VARCHAR2,
								  P_CURR_YMD	 VARCHAR2,
 								  P_PDI_CD	     VARCHAR2,
								  P_VEHL_CD	     VARCHAR2,
								  P_MDL_MDY	     VARCHAR2,
								  P_REGN_CD	     VARCHAR2,
								  P_LANG_CD	     VARCHAR2,
								  P_DLVY_STATE   VARCHAR2,
								  P_IV_STATE     VARCHAR2,
                                  RS 		     OUT REFCUR,
                                  P_MESSAGE      OUT VARCHAR2)
    IS
	  	V_MESSAGE VARCHAR2(8000);
	BEGIN			
			PG_TOT_IV_INFO.SP_GET_MESSAGE(P_CURR_YMD, V_MESSAGE);
			
			P_MESSAGE := V_MESSAGE;
			
			SP_GET_SEWHA_IV_INFO2(P_MENU_ID,
								  P_USER_EENO,
								  P_CURR_YMD,
								  'ALL',
								  P_PDI_CD,
								  P_VEHL_CD,
								  P_MDL_MDY,
								  P_REGN_CD,
								  P_LANG_CD,
								  P_DLVY_STATE,
								  P_IV_STATE,
								  RS);
								  
	END SP_GET_SEWHA_IV_INFO;
	   
	--세화재고 조회(승상구분, PDI, 차종, 연식, 지역, 언어) 						  
    PROCEDURE SP_GET_SEWHA_IV_INFO2(P_MENU_ID 	   VARCHAR2,
								    P_USER_EENO    VARCHAR2,
								    P_CURR_YMD	   VARCHAR2,
								    P_PAC_SCN_CD   VARCHAR2,
 								    P_PDI_CD	   VARCHAR2,
								    P_VEHL_CD	   VARCHAR2,
								    P_MDL_MDY	   VARCHAR2,
								    P_REGN_CD	   VARCHAR2,
								    P_LANG_CD	   VARCHAR2,
								    P_DLVY_STATE   VARCHAR2,
								    P_IV_STATE     VARCHAR2,
                                    RS 		       OUT REFCUR)
	   IS
	   	  
		  V_FROM_MDL_MDY VARCHAR2(2);
		  V_TO_MDL_MDY   VARCHAR2(2);
		  
--	   	  V_CURR_DATE	DATE;

--          --V_CURR_PACK	VARCHAR2(4);
--          --V_PREV_PACK	VARCHAR2(4);

--		  V_PREV_YEAR_YMD VARCHAR2(8);  --1년전 현재월 1일 날짜
--		  --V_PREV_3MTH_YMD VARCHAR2(8);  --3개월전 1일 날짜
--		  V_PREV_1MTH_YMD VARCHAR2(8);  --1개월전 마지막 날짜
--		  V_PREV_1DAY_YMD VARCHAR2(8);  --어제 날짜
--		  V_CURR_FSTD_YMD VARCHAR2(8);  --현재월 1일 날짜
--		  V_NEXT_2WEK_YMD VARCHAR2(8);  --2주 후 날짜

	   BEGIN
	   	  
		  PG_COMMON.SP_GET_VALID_MDL_MDY4(P_CURR_YMD, '', V_FROM_MDL_MDY, V_TO_MDL_MDY);
		  
--		  V_CURR_DATE := TO_DATE(P_CURR_YMD, 'YYYYMMDD');

--		  --V_CURR_PACK := TO_CHAR(V_CURR_DATE, 'YYMM');
--		  --V_PREV_PACK := TO_CHAR(ADD_MONTHS(V_CURR_DATE, -1), 'YYMM');

--		  V_PREV_YEAR_YMD := TO_CHAR(ADD_MONTHS(V_CURR_DATE, -12), 'YYYYMM') || '01';
--		  --V_PREV_3MTH_YMD := TO_CHAR(ADD_MONTHS(V_CURR_DATE, -3), 'YYYYMM') || '01';
--		  V_PREV_1MTH_YMD := TO_CHAR(LAST_DAY(ADD_MONTHS(V_CURR_DATE, -1)), 'YYYYMMDD');
--		  V_PREV_1DAY_YMD := TO_CHAR(V_CURR_DATE - 1, 'YYYYMMDD');
--		  V_CURR_FSTD_YMD := TO_CHAR(V_CURR_DATE, 'YYYYMM') || '01';
--		  V_NEXT_2WEK_YMD := TO_CHAR(V_CURR_DATE + 13, 'YYYYMMDD');
		  
		  
		  IF P_DLVY_STATE = 'ALL' THEN
		  	 
			 OPEN RS FOR
			 	  WITH T AS (SELECT A.CL_SCN_CD,
			          	 		    C.DATA_SN,
			  					    C.QLTY_VEHL_CD,
                                    C.MDL_MDY_CD,
                                    C.LANG_CD,
                                    --'(' || C.QLTY_VEHL_CD || ')' || B.QLTY_VEHL_NM || '-' || C.MDL_MDY_CD || 'MY' AS QLTY_VEHL_NM,
									C.QLTY_VEHL_CD || '-' || C.MDL_MDY_CD AS QLTY_VEHL_NM,
                                    --C.LANG_CD_NM,
									'(' || C.LANG_CD || ')' || C.LANG_CD_NM AS LANG_CD_NM,
                                    C.DL_EXPD_REGN_CD,
									C.SORT_SN AS LANG_SORT_SN
                             FROM (SELECT QLTY_VEHL_CD,
                                          MAX(CL_SCN_CD) AS CL_SCN_CD
                                   FROM TB_AUTH_VEHL_MGMT
                                   WHERE MENU_ID = PG_COMMON.FU_RPAD(P_MENU_ID, 10)
                                   AND USER_EENO = PG_COMMON.FU_RPAD(P_USER_EENO, 7)
                                   AND QLTY_VEHL_CD = DECODE(P_VEHL_CD, 'ALL', QLTY_VEHL_CD, P_VEHL_CD)
                                   GROUP BY QLTY_VEHL_CD
                                  ) A,
                                  TB_VEHL_MGMT B,
                                  TB_LANG_MGMT C
                             WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
                             AND A.QLTY_VEHL_CD = C.QLTY_VEHL_CD
                             AND B.MDL_MDY_CD = C.MDL_MDY_CD
                             AND B.MDL_MDY_CD BETWEEN V_FROM_MDL_MDY AND V_TO_MDL_MDY
                             AND B.MDL_MDY_CD = DECODE(P_MDL_MDY , '', B.MDL_MDY_CD, P_MDL_MDY)
						     AND B.DL_EXPD_PAC_SCN_CD = DECODE(P_PAC_SCN_CD, 'ALL', B.DL_EXPD_PAC_SCN_CD, P_PAC_SCN_CD)
                             AND B.DL_EXPD_PDI_CD = DECODE(P_PDI_CD, 'ALL', B.DL_EXPD_PDI_CD, P_PDI_CD)
						     AND C.DL_EXPD_REGN_CD = DECODE(P_REGN_CD, 'ALL', C.DL_EXPD_REGN_CD, P_REGN_CD)
                             AND C.LANG_CD = DECODE(P_LANG_CD, 'ALL', C.LANG_CD, P_LANG_CD)
							 AND B.USE_YN = 'Y'
							 AND C.USE_YN = 'Y'
                            )
			      SELECT A.CL_SCN_CD,
			   		     A.DATA_SN,
					     A.QLTY_VEHL_CD,
					     A.MDL_MDY_CD,
					     A.LANG_CD,
					     A.DL_EXPD_REGN_CD,
					     A.QLTY_VEHL_NM,
					     A.LANG_CD_NM,
					     A.DL_EXPD_REGN_NM,
					     A.WEK2_PLAN_QTY,
					     A.DAY3_PLAN_QTY,
					     A.CURR_MTH_TRWI_QTY,
					     A.PREV_1DAY_TRWI_QTY,
					     A.SEWHA_IV_QTY,
					     A.SEWHA_PRNT_YN, --세화 인쇄중 데이터 존재여부 확인 
					     A.SEWHA_DLVY_QTY,
					     A.PDI_DEEI1_QTY,
						 A.EXPD_WHSN_ST_NM,
						 A.PDI_IV_QTY,
					     A.DSID3_QTY,
						 A.DAY3_AFTR_IV_QTY,
						 A.WEK2_AFTR_IV_QTY,
						 A.PRNT_STATE,
						 B.DL_EXPD_PRVS_NM AS PRNT_STATE_NM,
						 PLNT_DAY3_QTY_TEXT,
					     PLNT_WEK2_QTY_TEXT,
					     PLNT_YN
			      FROM (SELECT A.CL_SCN_CD,
			   		           A.DATA_SN,
					           A.QLTY_VEHL_CD,
					           A.MDL_MDY_CD,
					           A.LANG_CD,
					           A.DL_EXPD_REGN_CD,
					           A.QLTY_VEHL_NM,
					           A.LANG_CD_NM,
					           B.DL_EXPD_PRVS_NM AS DL_EXPD_REGN_NM,
					           A.WEK2_PLAN_QTY,
					           A.DAY3_PLAN_QTY,
					           A.CURR_MTH_TRWI_QTY,
					           A.PREV_1DAY_TRWI_QTY,
					           A.SEWHA_IV_QTY,
					           A.SEWHA_PRNT_YN, --세화 인쇄중 데이터 존재여부 확인 
							   A.SEWHA_DLVY_QTY,
							   A.PDI_DEEI1_QTY,
							   A.EXPD_WHSN_ST_NM,
							   A.PDI_IV_QTY,
					           A.DSID3_QTY,
							   (A.PDI_IV_QTY - A.DAY3_PLAN_QTY) AS DAY3_AFTR_IV_QTY,
					           (A.PDI_IV_QTY - A.WEK2_PLAN_QTY) AS WEK2_AFTR_IV_QTY,
							   CASE WHEN A.DSID3_QTY * 1.5 <= A.PDI_IV_QTY - A.DAY3_PLAN_QTY THEN '01'
							     WHEN A.DSID3_QTY <= A.PDI_IV_QTY - A.DAY3_PLAN_QTY THEN '02'
								 WHEN A.DSID3_QTY > A.PDI_IV_QTY - A.DAY3_PLAN_QTY AND
								      A.DAY2_PLAN_QTY <= A.PDI_IV_QTY - A.DAY3_PLAN_QTY THEN '03'
								 ELSE '04' END AS PRNT_STATE,
							   PLNT_DAY3_QTY_TEXT,
							   PLNT_WEK2_QTY_TEXT,
							   PLNT_YN 
			         FROM (SELECT A.CL_SCN_CD,
			   				      A.DATA_SN,
							      A.QLTY_VEHL_CD,
							      A.MDL_MDY_CD,
							      A.LANG_CD,
							      A.DL_EXPD_REGN_CD,
							      A.QLTY_VEHL_NM,
							      A.LANG_CD_NM,
								  A.LANG_SORT_SN,
			   				      NVL(B.WEK2_PLAN_QTY, 0) AS WEK2_PLAN_QTY,
							      --CASE WHEN NVL(B.DAY3_PLAN_QTY1, 0) > NVL(B.DAY3_PLAN_QTY2, 0) THEN NVL(B.DAY3_PLAN_QTY1, 0)
     							  --     ELSE NVL(B.DAY3_PLAN_QTY2, 0)
								  --END AS DAY3_PLAN_QTY,
								  NVL(B.DAY3_PLAN_QTY1, 0) AS DAY3_PLAN_QTY,
							      NVL(B.CURR_MTH_TRWI_QTY, 0) AS CURR_MTH_TRWI_QTY,
							      NVL(B.PREV_1DAY_TRWI_QTY, 0) AS PREV_1DAY_TRWI_QTY,
							      NVL(C.SEWHA_IV_QTY, 0) AS SEWHA_IV_QTY,
							      NVL(C.SEWHA_PRNT_YN, 'N') AS SEWHA_PRNT_YN,
								  NVL(D.SEWHA_DLVY_QTY, 0) AS SEWHA_DLVY_QTY,
								  NVL(E.PDI_DEEI1_QTY, 0) AS PDI_DEEI1_QTY,
								  NVL(E.EXPD_WHSN_ST_NM, '') AS EXPD_WHSN_ST_NM,
							      NVL(F.PDI_IV_QTY, 0) AS PDI_IV_QTY,
							      NVL(B.DSID3_QTY, 0) AS DSID3_QTY,
								  NVL(B.DAY2_PLAN_QTY, 0) AS DAY2_PLAN_QTY,
								  NVL(G.PLNT_DAY3_QTY_TEXT, ' ') AS PLNT_DAY3_QTY_TEXT,
								  NVL(G.PLNT_WEK2_QTY_TEXT, ' ') AS PLNT_WEK2_QTY_TEXT,
								  NVL(G.PLNT_YN, 'N') AS PLNT_YN
					       FROM T A,
						   		(SELECT A.QLTY_VEHL_CD, 
										A.MDL_MDY_CD, 
										A.LANG_CD,
							      		NVL(B.WEK2_PRDN_PLN_QTY, 0) + NVL(B.TDD_PRDN_QTY3, 0) AS WEK2_PLAN_QTY,
								  		NVL(B.TDD_PRDN_PLN_QTY, 0) + NVL(B.TDD_PRDN_QTY3, 0) AS DAY3_PLAN_QTY1,
										--NVL(B.TDD_PRDN_QTY, 0) AS DAY3_PLAN_QTY2,
								  		NVL(B.TMM_TRWI_QTY, 0) AS CURR_MTH_TRWI_QTY,
								  		NVL(B.BOD_TRWI_QTY, 0) AS PREV_1DAY_TRWI_QTY,
										CASE WHEN A.LANG_CD = 'EU' THEN NVL(B.TDD_PRDN_PLN_QTY, 0) + NVL(B.TDD_PRDN_QTY2, 0)
										     ELSE NVL(B.TDD_PRDN_PLN_QTY2, 0) + NVL(B.TDD_PRDN_QTY2, 0)
									    END AS DSID3_QTY,
										NVL(B.TDD_PRDN_PLN_QTY3, 0) + NVL(B.TDD_PRDN_QTY2, 0) AS DAY2_PLAN_QTY
								 FROM T A,
						         	  TB_APS_PROD_SUM_INFO B
						         WHERE A.DATA_SN = B.DATA_SN
						   		 AND B.APL_YMD = P_CURR_YMD
								) B,
						        --세화재고
        				        (SELECT A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD, SUM(B.SFTY_IV_QTY) AS SEWHA_IV_QTY,
						                --인쇄중 데이터 존재 여부 확인 ==> DL_EXPD_TMP_IV_QTY 값은 인쇄중 이전인 경우에는 NULL, 인쇄중인경우에는 인쇄 수량, 납품이후에는 0으로 설정되어 있음 
						  		        CASE WHEN SUM(B.DL_EXPD_TMP_IV_QTY) > 0 THEN 'Y' ELSE 'N'END AS SEWHA_PRNT_YN
         				         FROM T A,
              				          TB_SEWHA_IV_INFO_DTL B
         				         WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
         				         AND A.MDL_MDY_CD = B.MDL_MDY_CD
         				         AND A.LANG_CD = B.LANG_CD
         				         AND B.CLS_YMD = P_CURR_YMD
								 AND B.SFTY_IV_QTY > 0 --안전재고수량이 없는 것은 가져오지 않는다. 
						         GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD 
								
								 /***
								 SELECT A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD, SUM(IV_QTY) AS SEWHA_IV_QTY,
						                --인쇄중 데이터 존재 여부 확인 ==> DL_EXPD_TMP_IV_QTY 값은 인쇄중 이전인 경우에는 NULL, 인쇄중인경우에는 인쇄 수량, 납품이후에는 0으로 설정되어 있음 
						  		        CASE WHEN SUM(DL_EXPD_TMP_IV_QTY) > 0 THEN 'Y' ELSE 'N'END AS SEWHA_PRNT_YN
         				         FROM T A,
              		   		          TB_DL_EXPD_MDY_MGMT B,
              				          TB_SEWHA_IV_INFO C 
         				         WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
         				         AND A.MDL_MDY_CD = B.MDL_MDY_CD 
								 AND A.DL_EXPD_REGN_CD = B.DL_EXPD_REGN_CD 
         				         AND A.QLTY_VEHL_CD = C.QLTY_VEHL_CD
         				         AND B.DL_EXPD_MDL_MDY_CD = C.DL_EXPD_MDL_MDY_CD
         				         AND A.LANG_CD = C.LANG_CD
         				         AND C.CLS_YMD = P_CURR_YMD
						         GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD 
								 ***/
								 
                                ) C,
								--배송중 데이터 조회
								(SELECT A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD, SUM(B.RQ_QTY) AS SEWHA_DLVY_QTY
								 FROM T A,
									  TB_SEWHA_WHOT_INFO B
								 WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
         				         AND A.MDL_MDY_CD = B.MDL_MDY_CD							 
								 AND A.LANG_CD = B.LANG_CD
								 AND B.WHSN_YMD > P_CURR_YMD
								 AND B.WHOT_YMD <= P_CURR_YMD
								 AND B.DEL_YN = 'N'
								 GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD 
								
								 /***
								 SELECT A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD, SUM(RQ_QTY) AS SEWHA_DLVY_QTY
								 FROM T A,
								      TB_DL_EXPD_MDY_MGMT B,
									  TB_SEWHA_WHOT_INFO C
								 WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
         				         AND A.MDL_MDY_CD = B.MDL_MDY_CD							 
								 AND A.DL_EXPD_REGN_CD = B.DL_EXPD_REGN_CD 
         				         AND A.QLTY_VEHL_CD = C.QLTY_VEHL_CD
         				         AND B.DL_EXPD_MDL_MDY_CD = C.DL_EXPD_MDL_MDY_CD
								 AND A.LANG_CD = C.LANG_CD
								 AND A.MDL_MDY_CD = C.MDL_MDY_CD
								 AND C.WHSN_YMD > P_CURR_YMD
								 AND C.WHOT_YMD <= P_CURR_YMD
								 AND C.DEL_YN = 'N'
								 GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD 
								 ***/
								 
								) D,
								--입고확인 데이터 조회 
								(SELECT A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD, 
										SUM(B.DEEI1_QTY) AS PDI_DEEI1_QTY,
										MAX(C.DL_EXPD_PRVS_NM) AS EXPD_WHSN_ST_NM
								 FROM T A,
									  TB_PDI_WHSN_INFO B,
									  TB_CODE_MGMT C
								 WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
         				         AND A.MDL_MDY_CD = B.MDL_MDY_CD								 
								 AND A.LANG_CD = B.LANG_CD
								 AND B.WHSN_YMD = P_CURR_YMD
								 AND B.DL_EXPD_WHSN_ST_CD = C.DL_EXPD_PRVS_CD(+)
						         AND C.DL_EXPD_G_CD(+) = '0013'
								 GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD
								 
								 /***
								 SELECT A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD, 
										SUM(DEEI1_QTY) AS PDI_DEEI1_QTY,
										MAX(D.DL_EXPD_PRVS_NM) AS EXPD_WHSN_ST_NM
								 FROM T A,
								      TB_DL_EXPD_MDY_MGMT B,
									  TB_PDI_WHSN_INFO C,
									  TB_CODE_MGMT D
								 WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
         				         AND A.MDL_MDY_CD = B.MDL_MDY_CD								 
								 AND A.DL_EXPD_REGN_CD = B.DL_EXPD_REGN_CD 
         				         AND A.QLTY_VEHL_CD = C.QLTY_VEHL_CD
         				         AND B.DL_EXPD_MDL_MDY_CD = C.DL_EXPD_MDL_MDY_CD
								 AND A.LANG_CD = C.LANG_CD
								 AND A.MDL_MDY_CD = C.MDL_MDY_CD 
								 AND C.WHSN_YMD = P_CURR_YMD
								 AND C.DL_EXPD_WHSN_ST_CD = D.DL_EXPD_PRVS_CD(+)
						         AND D.DL_EXPD_G_CD(+) = '0013'
								 GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD 
								 ***/
								 
								) E,
                                --PDI재고
                                (SELECT A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD, SUM(B.SFTY_IV_QTY) AS PDI_IV_QTY
                                 FROM T A,
                                      TB_PDI_IV_INFO_DTL B
                                 WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
                                 AND A.MDL_MDY_CD = B.MDL_MDY_CD
                                 AND A.LANG_CD = B.LANG_CD
                                 AND B.CLS_YMD = P_CURR_YMD
								 AND B.SFTY_IV_QTY > 0 --안전재고수량이 없는 것은 가져오지 않는다. 
						         GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD
								 
								 /***
								 SELECT A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD, SUM(IV_QTY) AS PDI_IV_QTY
                                 FROM T A,
                                      TB_DL_EXPD_MDY_MGMT B,
                                      TB_PDI_IV_INFO C
                                 WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD 
                                 AND A.MDL_MDY_CD = B.MDL_MDY_CD 
								 AND A.DL_EXPD_REGN_CD = B.DL_EXPD_REGN_CD 
                                 AND A.QLTY_VEHL_CD = C.QLTY_VEHL_CD
                                 AND B.DL_EXPD_MDL_MDY_CD = C.DL_EXPD_MDL_MDY_CD
                                 AND A.LANG_CD = C.LANG_CD
                                 AND C.CLS_YMD = P_CURR_YMD
						         GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD 
								 ***/
								 
                                ) F,
								(SELECT A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD,
										PG_TOT_IV_INFO.FU_GET_PLNT_DAY3_PLAN_QTY(P_CURR_YMD, A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD) AS PLNT_DAY3_QTY_TEXT,
										PG_TOT_IV_INFO.FU_GET_PLNT_WEK2_PLAN_QTY(P_CURR_YMD, A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD) AS PLNT_WEK2_QTY_TEXT,
										'Y' AS PLNT_YN
                                 FROM T A,
                                      TB_PLNT_APS_PROD_SUM_INFO B
                                 WHERE A.DATA_SN = B.DATA_SN
                                 AND B.APL_YMD = P_CURR_YMD
						         GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD
								) G
					 	   WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD(+)
                           AND A.MDL_MDY_CD = B.MDL_MDY_CD(+)
                           AND A.LANG_CD = B.LANG_CD(+)
                           AND A.QLTY_VEHL_CD = C.QLTY_VEHL_CD(+)
                           AND A.MDL_MDY_CD = C.MDL_MDY_CD(+)
                           AND A.LANG_CD = C.LANG_CD(+)
                           AND A.QLTY_VEHL_CD = D.QLTY_VEHL_CD(+)
                           AND A.MDL_MDY_CD = D.MDL_MDY_CD(+)
                           AND A.LANG_CD = D.LANG_CD(+)
                           AND A.QLTY_VEHL_CD = E.QLTY_VEHL_CD(+)
                           AND A.MDL_MDY_CD = E.MDL_MDY_CD(+)
                           AND A.LANG_CD = E.LANG_CD(+)
                           AND A.QLTY_VEHL_CD = F.QLTY_VEHL_CD(+)
                           AND A.MDL_MDY_CD = F.MDL_MDY_CD(+)
                           AND A.LANG_CD = F.LANG_CD(+)
 						   AND A.QLTY_VEHL_CD = G.QLTY_VEHL_CD(+)
						   AND A.MDL_MDY_CD = G.MDL_MDY_CD(+)
						   AND A.LANG_CD = G.LANG_CD(+)
						   
					 	   /****  속도 개선을 위한 쿼리 변경 
					 	   SELECT A.CL_SCN_CD,
			   				      A.DATA_SN,
							      A.QLTY_VEHL_CD,
							      A.MDL_MDY_CD,
							      A.LANG_CD,
							      A.DL_EXPD_REGN_CD,
							      A.QLTY_VEHL_NM,
							      A.LANG_CD_NM,
			   				      NVL(B.WEK2_PLAN_QTY, 0) AS WEK2_PLAN_QTY,
							      NVL(C.DAY3_PLAN_QTY, 0) AS DAY3_PLAN_QTY,
							      NVL(D.CURR_MTH_TRWI_QTY, 0) AS CURR_MTH_TRWI_QTY,
							      NVL(E.PREV_1DAY_TRWI_QTY, 0) AS PREV_1DAY_TRWI_QTY,
							      NVL(F.SEWHA_IV_QTY, 0) AS SEWHA_IV_QTY,
							      NVL(F.SEWHA_PRNT_YN, 'N') AS SEWHA_PRNT_YN,
								  NVL(G.SEWHA_DLVY_QTY, 0) AS SEWHA_DLVY_QTY,
								  NVL(H.PDI_DEEI1_QTY, 0) AS PDI_DEEI1_QTY,
								  NVL(H.EXPD_WHSN_ST_NM, '') AS EXPD_WHSN_ST_NM,
							      NVL(I.PDI_IV_QTY, 0) AS PDI_IV_QTY,
							      NVL(J.DSID3_QTY, 0) AS DSID3_QTY
			   		       FROM T A,
                                --생산계획(2주)
								(SELECT A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD, SUM(PRDN_PLN_QTY) AS WEK2_PLAN_QTY
                                 FROM T A,
                                      TB_APS_PROD_PLAN_SUM_INFO B
                                 WHERE A.DATA_SN = B.DATA_SN
      				             AND B.APL_STRT_YMD <= P_CURR_YMD
                                 AND B.APL_FNH_YMD >= P_CURR_YMD
      				             AND B.PLN_PARR_YMD BETWEEN P_CURR_YMD AND V_NEXT_2WEK_YMD
      				             GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD
                                ) B,
                                --단기계획(3일)
                                (SELECT A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD, SUM(NVL(B.PRDN_PLN_QTY, 0) + NVL(C.PRDN_QTY, 0)) AS DAY3_PLAN_QTY
                                 FROM T A,
                                      TB_APS_PROD_PLAN_SUM_INFO B,
                                      TB_PROD_MST_SUM_INFO C
                                 WHERE A.DATA_SN = B.DATA_SN(+)
                                 AND A.DATA_SN = C.DATA_SN(+)
                                 AND B.APL_STRT_YMD(+) <= P_CURR_YMD
                                 AND B.APL_FNH_YMD(+) >= P_CURR_YMD
                                 AND B.PLN_PARR_YMD(+) = P_CURR_YMD
                                 AND C.APL_YMD(+) = P_CURR_YMD
                                 GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD
                                ) C,
        				        --당월투입
        				        (SELECT A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD, SUM(PRDN_TRWI_QTY) AS CURR_MTH_TRWI_QTY
         				         FROM T A,
              		                  TB_PROD_MST_SUM_INFO B
         				         WHERE A.DATA_SN = B.DATA_SN
      				             AND B.APL_YMD BETWEEN V_CURR_FSTD_YMD AND P_CURR_YMD
      				             GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD
        				        ) D,
      				            --전일투입
      				            (SELECT A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD, SUM(PRDN_TRWI_QTY) AS PREV_1DAY_TRWI_QTY
         				         FROM T A,
              		                  TB_PROD_MST_SUM_INFO B
         				         WHERE A.DATA_SN = B.DATA_SN
      				             AND B.APL_YMD = V_PREV_1DAY_YMD
      				             GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD
        				        ) E,
        				        --세화재고
        				        (SELECT A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD, SUM(IV_QTY) AS SEWHA_IV_QTY,
						                --인쇄중 데이터 존재 여부 확인 ==> DL_EXPD_TMP_IV_QTY 값은 인쇄중 이전인 경우에는 NULL, 인쇄중인경우에는 인쇄 수량, 납품이후에는 0으로 설정되어 있음 
						  		        CASE WHEN SUM(DL_EXPD_TMP_IV_QTY) > 0 THEN 'Y' ELSE 'N'END AS SEWHA_PRNT_YN
         				         FROM T A,
              		   		          TB_DL_EXPD_MDY_MGMT B,
              				          TB_SEWHA_IV_INFO C
         				         WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
         				         AND A.MDL_MDY_CD = B.MDL_MDY_CD
         				         AND A.QLTY_VEHL_CD = C.QLTY_VEHL_CD
         				         AND B.DL_EXPD_MDL_MDY_CD = C.DL_EXPD_MDL_MDY_CD
         				         AND A.LANG_CD = C.LANG_CD
         				         AND C.CLS_YMD = P_CURR_YMD
						         GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD
                                ) F,
								--배송중 데이터 조회
								(SELECT A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD, SUM(RQ_QTY) AS SEWHA_DLVY_QTY
								 FROM T A,
								      TB_DL_EXPD_MDY_MGMT B,
									  TB_SEWHA_WHOT_INFO C
								 WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
         				         AND A.MDL_MDY_CD = B.MDL_MDY_CD
         				         AND A.QLTY_VEHL_CD = C.QLTY_VEHL_CD
         				         AND B.DL_EXPD_MDL_MDY_CD = C.DL_EXPD_MDL_MDY_CD
								 AND C.WHSN_YMD > P_CURR_YMD
								 GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD
								) G,
								--입고확인 데이터 조회 
								(SELECT A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD, 
										SUM(DEEI1_QTY) AS PDI_DEEI1_QTY,
										MAX(D.DL_EXPD_PRVS_NM) AS EXPD_WHSN_ST_NM
								 FROM T A,
								      TB_DL_EXPD_MDY_MGMT B,
									  TB_PDI_WHSN_INFO C,
									  TB_CODE_MGMT D
								 WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
         				         AND A.MDL_MDY_CD = B.MDL_MDY_CD
         				         AND A.QLTY_VEHL_CD = C.QLTY_VEHL_CD
         				         AND B.DL_EXPD_MDL_MDY_CD = C.DL_EXPD_MDL_MDY_CD
								 AND C.WHSN_YMD = P_CURR_YMD
								 AND C.DL_EXPD_WHSN_ST_CD = D.DL_EXPD_PRVS_CD(+)
						         AND D.DL_EXPD_G_CD(+) = '0013'
								 GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD
								) H,
                                --PDI재고
                                (SELECT A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD, SUM(IV_QTY) AS PDI_IV_QTY
                                 FROM T A,
                                      TB_DL_EXPD_MDY_MGMT B,
                                      TB_PDI_IV_INFO C
                                 WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
                                 AND A.MDL_MDY_CD = B.MDL_MDY_CD
                                 AND A.QLTY_VEHL_CD = C.QLTY_VEHL_CD
                                 AND B.DL_EXPD_MDL_MDY_CD = C.DL_EXPD_MDL_MDY_CD
                                 AND A.LANG_CD = C.LANG_CD
                                 AND C.CLS_YMD = P_CURR_YMD
						         GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD
                                ) I,
						        --안전재고 조회
						        (SELECT A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD,
						                CASE WHEN B.DSID31_QTY IS NULL THEN (SELECT NVL(ROUND((SUM(PRDN_TRWI_QTY) / 365 + 1.96 + STDDEV(PRDN_TRWI_QTY)) * 3), 0)
								  	   					  	 	  	          FROM TB_PROD_MST_SUM_INFO C
																	          WHERE C.DATA_SN = A.DATA_SN
																	          AND C.APL_YMD BETWEEN V_PREV_YEAR_YMD AND V_PREV_1MTH_YMD)
								             ELSE B.DSID31_QTY END AS DSID3_QTY 
						         FROM T A,
						   		      TB_SFTY_IV_MGMT B 
						         WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD(+)
                                 AND A.MDL_MDY_CD = B.MDL_MDY_CD(+)
                                 AND A.QLTY_VEHL_CD = B.QLTY_VEHL_CD(+)
						        ) J
                           WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD(+)
                           AND A.MDL_MDY_CD = B.MDL_MDY_CD(+)
                           AND A.LANG_CD = B.LANG_CD(+)
                           AND A.QLTY_VEHL_CD = C.QLTY_VEHL_CD(+)
                           AND A.MDL_MDY_CD = C.MDL_MDY_CD(+)
                           AND A.LANG_CD = C.LANG_CD(+)
                           AND A.QLTY_VEHL_CD = D.QLTY_VEHL_CD(+)
                           AND A.MDL_MDY_CD = D.MDL_MDY_CD(+)
                           AND A.LANG_CD = D.LANG_CD(+)
                           AND A.QLTY_VEHL_CD = E.QLTY_VEHL_CD(+)
                           AND A.MDL_MDY_CD = E.MDL_MDY_CD(+)
                           AND A.LANG_CD = E.LANG_CD(+)
                           AND A.QLTY_VEHL_CD = F.QLTY_VEHL_CD(+)
                           AND A.MDL_MDY_CD = F.MDL_MDY_CD(+)
                           AND A.LANG_CD = F.LANG_CD(+)
                           AND A.QLTY_VEHL_CD = G.QLTY_VEHL_CD(+)
                           AND A.MDL_MDY_CD = G.MDL_MDY_CD(+)
                           AND A.LANG_CD = G.LANG_CD(+)
                           AND A.QLTY_VEHL_CD = H.QLTY_VEHL_CD(+)
                           AND A.MDL_MDY_CD = H.MDL_MDY_CD(+)
                           AND A.LANG_CD = H.LANG_CD(+)
						   AND A.QLTY_VEHL_CD = I.QLTY_VEHL_CD(+)
                           AND A.MDL_MDY_CD = I.MDL_MDY_CD(+)
                           AND A.LANG_CD = I.LANG_CD(+)
						   AND A.QLTY_VEHL_CD = J.QLTY_VEHL_CD(+)
                           AND A.MDL_MDY_CD = J.MDL_MDY_CD(+)
                           AND A.LANG_CD = J.LANG_CD(+) 
						   ****/
						   
			             ) A,
				         TB_CODE_MGMT B
			         WHERE A.DL_EXPD_REGN_CD = B.DL_EXPD_PRVS_CD
			         AND B.DL_EXPD_G_CD = '0008'
			         AND WEK2_PLAN_QTY + DAY3_PLAN_QTY + CURR_MTH_TRWI_QTY +
			   	         PREV_1DAY_TRWI_QTY + SEWHA_IV_QTY + SEWHA_DLVY_QTY + PDI_DEEI1_QTY + PDI_IV_QTY > 0
			         --ORDER BY QLTY_VEHL_NM, B.SORT_SN, LANG_CD_NM 
					 --ORDER BY QLTY_VEHL_CD, B.SORT_SN, LANG_CD, MDL_MDY_CD
					 ORDER BY QLTY_VEHL_CD, LANG_SORT_SN, MDL_MDY_CD
					) A,
					TB_CODE_MGMT B
			    WHERE A.PRNT_STATE = B.DL_EXPD_PRVS_CD
				AND B.DL_EXPD_G_CD = '0016'
				AND PRNT_STATE = DECODE(P_IV_STATE, 'ALL', PRNT_STATE, P_IV_STATE);
		  
		  --배송중인 데이터 조회인 경우 		
		  ELSIF P_DLVY_STATE = '01' THEN
		  		
		  		OPEN RS FOR
			 	  WITH T AS (SELECT A.CL_SCN_CD,
			          	 		    C.DATA_SN,
			  					    C.QLTY_VEHL_CD,
                                    C.MDL_MDY_CD,
                                    C.LANG_CD,
                                    --'(' || C.QLTY_VEHL_CD || ')' || B.QLTY_VEHL_NM || '-' || C.MDL_MDY_CD || 'MY' AS QLTY_VEHL_NM,
									C.QLTY_VEHL_CD || '-' || C.MDL_MDY_CD AS QLTY_VEHL_NM,
                                    --C.LANG_CD_NM,
									'(' || C.LANG_CD || ')' || C.LANG_CD_NM AS LANG_CD_NM,
                                    C.DL_EXPD_REGN_CD,
									C.SORT_SN AS LANG_SORT_SN
                             FROM (SELECT QLTY_VEHL_CD,
                                          MAX(CL_SCN_CD) AS CL_SCN_CD
                                   FROM TB_AUTH_VEHL_MGMT
                                   WHERE MENU_ID = PG_COMMON.FU_RPAD(P_MENU_ID, 10)
                                   AND USER_EENO = PG_COMMON.FU_RPAD(P_USER_EENO, 7)
                                   AND QLTY_VEHL_CD = DECODE(P_VEHL_CD, 'ALL', QLTY_VEHL_CD, P_VEHL_CD)
                                   GROUP BY QLTY_VEHL_CD
                                  ) A,
                                  TB_VEHL_MGMT B,
                                  TB_LANG_MGMT C
                             WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
                             AND A.QLTY_VEHL_CD = C.QLTY_VEHL_CD
                             AND B.MDL_MDY_CD = C.MDL_MDY_CD
                             AND B.MDL_MDY_CD BETWEEN V_FROM_MDL_MDY AND V_TO_MDL_MDY
                             AND B.MDL_MDY_CD = DECODE(P_MDL_MDY , '', B.MDL_MDY_CD, P_MDL_MDY)
						     AND B.DL_EXPD_PAC_SCN_CD = DECODE(P_PAC_SCN_CD, 'ALL', B.DL_EXPD_PAC_SCN_CD, P_PAC_SCN_CD)
                             AND B.DL_EXPD_PDI_CD = DECODE(P_PDI_CD, 'ALL', B.DL_EXPD_PDI_CD, P_PDI_CD)
						     AND C.DL_EXPD_REGN_CD = DECODE(P_REGN_CD, 'ALL', C.DL_EXPD_REGN_CD, P_REGN_CD)
                             AND C.LANG_CD = DECODE(P_LANG_CD, 'ALL', C.LANG_CD, P_LANG_CD)
							 AND B.USE_YN = 'Y'
							 AND C.USE_YN = 'Y'
                            )
			      SELECT A.CL_SCN_CD,
			   		     A.DATA_SN,
					     A.QLTY_VEHL_CD,
					     A.MDL_MDY_CD,
					     A.LANG_CD,
					     A.DL_EXPD_REGN_CD,
					     A.QLTY_VEHL_NM,
					     A.LANG_CD_NM,
					     A.DL_EXPD_REGN_NM,
					     A.WEK2_PLAN_QTY,
					     A.DAY3_PLAN_QTY,
					     A.CURR_MTH_TRWI_QTY,
					     A.PREV_1DAY_TRWI_QTY,
					     A.SEWHA_IV_QTY,
					     A.SEWHA_PRNT_YN, --세화 인쇄중 데이터 존재여부 확인 
					     A.SEWHA_DLVY_QTY,
					     A.PDI_DEEI1_QTY,
						 A.EXPD_WHSN_ST_NM,
						 A.PDI_IV_QTY,
					     A.DSID3_QTY,
						 A.DAY3_AFTR_IV_QTY,
						 A.WEK2_AFTR_IV_QTY,
						 A.PRNT_STATE,
						 B.DL_EXPD_PRVS_NM AS PRNT_STATE_NM,
						 PLNT_DAY3_QTY_TEXT,
						 PLNT_WEK2_QTY_TEXT,
						 PLNT_YN
			      FROM (SELECT A.CL_SCN_CD,
			   		           A.DATA_SN,
					           A.QLTY_VEHL_CD,
					           A.MDL_MDY_CD,
					           A.LANG_CD,
					           A.DL_EXPD_REGN_CD,
					           A.QLTY_VEHL_NM,
					           A.LANG_CD_NM,
					           B.DL_EXPD_PRVS_NM AS DL_EXPD_REGN_NM,
					           A.WEK2_PLAN_QTY,
					           A.DAY3_PLAN_QTY,
					           A.CURR_MTH_TRWI_QTY,
					           A.PREV_1DAY_TRWI_QTY,
					           A.SEWHA_IV_QTY,
					           A.SEWHA_PRNT_YN, --세화 인쇄중 데이터 존재여부 확인 
							   A.SEWHA_DLVY_QTY,
							    0 AS PDI_DEEI1_QTY,
							   '' AS EXPD_WHSN_ST_NM,
							   A.PDI_IV_QTY,
					           A.DSID3_QTY,
							   (A.PDI_IV_QTY - A.DAY3_PLAN_QTY) AS DAY3_AFTR_IV_QTY,
					           (A.PDI_IV_QTY - A.WEK2_PLAN_QTY) AS WEK2_AFTR_IV_QTY,
							   CASE WHEN A.DSID3_QTY * 1.5 <= A.PDI_IV_QTY - A.DAY3_PLAN_QTY THEN '01'
							        WHEN A.DSID3_QTY <= A.PDI_IV_QTY - A.DAY3_PLAN_QTY THEN '02'
								    WHEN A.DSID3_QTY > A.PDI_IV_QTY - A.DAY3_PLAN_QTY AND
								         A.DAY2_PLAN_QTY <= A.PDI_IV_QTY - A.DAY3_PLAN_QTY THEN '03'
							   ELSE '04' END AS PRNT_STATE,
							   PLNT_DAY3_QTY_TEXT,
							   PLNT_WEK2_QTY_TEXT,
							   PLNT_YN
			         FROM (SELECT A.CL_SCN_CD,
			   				      A.DATA_SN,
							      A.QLTY_VEHL_CD,
							      A.MDL_MDY_CD,
							      A.LANG_CD,
							      A.DL_EXPD_REGN_CD,
							      A.QLTY_VEHL_NM,
							      A.LANG_CD_NM,
								  A.LANG_SORT_SN,
			   				      NVL(B.WEK2_PLAN_QTY, 0) AS WEK2_PLAN_QTY,
								  --CASE WHEN NVL(B.DAY3_PLAN_QTY1, 0) > NVL(B.DAY3_PLAN_QTY2, 0) THEN NVL(B.DAY3_PLAN_QTY1, 0)
     							  --     ELSE NVL(B.DAY3_PLAN_QTY2, 0)
								  --END AS DAY3_PLAN_QTY,
								  NVL(B.DAY3_PLAN_QTY1, 0) AS DAY3_PLAN_QTY,
							      NVL(B.CURR_MTH_TRWI_QTY, 0) AS CURR_MTH_TRWI_QTY,
							      NVL(B.PREV_1DAY_TRWI_QTY, 0) AS PREV_1DAY_TRWI_QTY,
							      NVL(C.SEWHA_IV_QTY, 0) AS SEWHA_IV_QTY,
							      NVL(C.SEWHA_PRNT_YN, 'N') AS SEWHA_PRNT_YN,
								  NVL(D.SEWHA_DLVY_QTY, 0) AS SEWHA_DLVY_QTY,
							      NVL(E.PDI_IV_QTY, 0) AS PDI_IV_QTY,
							      NVL(B.DSID3_QTY, 0) AS DSID3_QTY,
								  NVL(B.DAY2_PLAN_QTY, 0) AS DAY2_PLAN_QTY,
								  NVL(F.PLNT_DAY3_QTY_TEXT, ' ') AS PLNT_DAY3_QTY_TEXT,
								  NVL(F.PLNT_WEK2_QTY_TEXT, ' ') AS PLNT_WEK2_QTY_TEXT,
								  NVL(F.PLNT_YN, 'N') AS PLNT_YN
						   FROM T A,
							     (SELECT A.QLTY_VEHL_CD, 
										A.MDL_MDY_CD, 
										A.LANG_CD,
										NVL(B.WEK2_PRDN_PLN_QTY, 0) + NVL(B.TDD_PRDN_QTY3, 0) AS WEK2_PLAN_QTY,
										NVL(B.TDD_PRDN_PLN_QTY, 0) + NVL(B.TDD_PRDN_QTY3, 0) AS DAY3_PLAN_QTY1,
										--NVL(B.TDD_PRDN_QTY, 0) AS DAY3_PLAN_QTY2,
										NVL(B.TMM_TRWI_QTY, 0) AS CURR_MTH_TRWI_QTY,
								  		NVL(B.BOD_TRWI_QTY, 0) AS PREV_1DAY_TRWI_QTY,
										CASE WHEN A.LANG_CD = 'EU' THEN NVL(B.TDD_PRDN_PLN_QTY, 0) + NVL(B.TDD_PRDN_QTY2, 0)
										     ELSE NVL(B.TDD_PRDN_PLN_QTY2, 0) + NVL(B.TDD_PRDN_QTY2, 0)
									    END AS DSID3_QTY,
										NVL(B.TDD_PRDN_PLN_QTY3, 0) + NVL(B.TDD_PRDN_QTY2, 0) AS DAY2_PLAN_QTY
								 FROM T A,
						         	  TB_APS_PROD_SUM_INFO B
						         WHERE A.DATA_SN = B.DATA_SN
						   		 AND B.APL_YMD = P_CURR_YMD
								) B,
								--세화재고
        				        (SELECT A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD, SUM(B.SFTY_IV_QTY) AS SEWHA_IV_QTY,
						                --인쇄중 데이터 존재 여부 확인 ==> DL_EXPD_TMP_IV_QTY 값은 인쇄중 이전인 경우에는 NULL, 인쇄중인경우에는 인쇄 수량, 납품이후에는 0으로 설정되어 있음 
						  		        CASE WHEN SUM(B.DL_EXPD_TMP_IV_QTY) > 0 THEN 'Y' ELSE 'N'END AS SEWHA_PRNT_YN
         				         FROM T A,
              				          TB_SEWHA_IV_INFO_DTL B
         				         WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
         				         AND A.MDL_MDY_CD = B.MDL_MDY_CD
         				         AND A.LANG_CD = B.LANG_CD
         				         AND B.CLS_YMD = P_CURR_YMD
								 AND B.SFTY_IV_QTY > 0 --안전재고수량이 없는 것은 가져오지 않는다. 
						         GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD 
								
								 /***
								 SELECT A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD, SUM(IV_QTY) AS SEWHA_IV_QTY,
						                --인쇄중 데이터 존재 여부 확인 ==> DL_EXPD_TMP_IV_QTY 값은 인쇄중 이전인 경우에는 NULL, 인쇄중인경우에는 인쇄 수량, 납품이후에는 0으로 설정되어 있음 
						  		        CASE WHEN SUM(DL_EXPD_TMP_IV_QTY) > 0 THEN 'Y' ELSE 'N'END AS SEWHA_PRNT_YN
         				         FROM T A,
              		   		          TB_DL_EXPD_MDY_MGMT B,
              				          TB_SEWHA_IV_INFO C
         				         WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
         				         AND A.MDL_MDY_CD = B.MDL_MDY_CD
         				         AND A.QLTY_VEHL_CD = C.QLTY_VEHL_CD
         				         AND B.DL_EXPD_MDL_MDY_CD = C.DL_EXPD_MDL_MDY_CD
         				         AND A.LANG_CD = C.LANG_CD
         				         AND C.CLS_YMD = P_CURR_YMD
						         GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD 
								 ***/
								 
                                ) C,
								--배송중 데이터 조회
								(SELECT A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD, SUM(B.RQ_QTY) AS SEWHA_DLVY_QTY
								 FROM T A,
									  TB_SEWHA_WHOT_INFO B
								 WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
         				         AND A.MDL_MDY_CD = B.MDL_MDY_CD
								 AND A.LANG_CD = B.LANG_CD
								 AND B.WHSN_YMD > P_CURR_YMD
								 AND B.WHOT_YMD <= P_CURR_YMD
								 AND B.DEL_YN = 'N'
								 GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD 
								 
								 /***
								 SELECT A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD, SUM(RQ_QTY) AS SEWHA_DLVY_QTY
								 FROM T A,
								      TB_DL_EXPD_MDY_MGMT B,
									  TB_SEWHA_WHOT_INFO C
								 WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
         				         AND A.MDL_MDY_CD = B.MDL_MDY_CD
--[수정예정] 나중에 주석 제거 요망 (지역, 연식) 								 
								 --AND A.DL_EXPD_REGN_CD = B.DL_EXPD_REGN_CD 								 
         				         AND A.QLTY_VEHL_CD = C.QLTY_VEHL_CD
         				         AND B.DL_EXPD_MDL_MDY_CD = C.DL_EXPD_MDL_MDY_CD
								 AND A.LANG_CD = C.LANG_CD
								 AND A.MDL_MDY_CD = C.MDL_MDY_CD 
								 AND C.WHSN_YMD > P_CURR_YMD
								 AND C.WHOT_YMD <= P_CURR_YMD
								 AND C.DEL_YN = 'N'
								 GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD 
								  ***/
								  
								) D,
                                --PDI재고
                                (SELECT A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD, SUM(B.SFTY_IV_QTY) AS PDI_IV_QTY
                                 FROM T A,
                                      TB_PDI_IV_INFO_DTL B
                                 WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
                                 AND A.MDL_MDY_CD = B.MDL_MDY_CD
                                 AND A.LANG_CD = B.LANG_CD
                                 AND B.CLS_YMD = P_CURR_YMD
								 AND B.SFTY_IV_QTY > 0 --안전재고수량이 없는 것은 가져오지 않는다. 
						         GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD 
								 
								 /*** 
								 SELECT A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD, SUM(IV_QTY) AS PDI_IV_QTY
                                 FROM T A,
                                      TB_DL_EXPD_MDY_MGMT B,
                                      TB_PDI_IV_INFO C
                                 WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
                                 AND A.MDL_MDY_CD = B.MDL_MDY_CD
                                 AND A.QLTY_VEHL_CD = C.QLTY_VEHL_CD
                                 AND B.DL_EXPD_MDL_MDY_CD = C.DL_EXPD_MDL_MDY_CD
                                 AND A.LANG_CD = C.LANG_CD
                                 AND C.CLS_YMD = P_CURR_YMD
						         GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD 
								 ***/
								 
                                ) E,
								(SELECT A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD,
										PG_TOT_IV_INFO.FU_GET_PLNT_DAY3_PLAN_QTY(P_CURR_YMD, A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD) AS PLNT_DAY3_QTY_TEXT,
										PG_TOT_IV_INFO.FU_GET_PLNT_WEK2_PLAN_QTY(P_CURR_YMD, A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD) AS PLNT_WEK2_QTY_TEXT,
										'Y' AS PLNT_YN
                                 FROM T A,
                                      TB_PLNT_APS_PROD_SUM_INFO B
                                 WHERE A.DATA_SN = B.DATA_SN
                                 AND B.APL_YMD = P_CURR_YMD
						         GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD
								) F 
					       WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD(+)
                           AND A.MDL_MDY_CD = B.MDL_MDY_CD(+)
                           AND A.LANG_CD = B.LANG_CD(+)
                           AND A.QLTY_VEHL_CD = C.QLTY_VEHL_CD(+)
                           AND A.MDL_MDY_CD = C.MDL_MDY_CD(+)
                           AND A.LANG_CD = C.LANG_CD(+)
						   --배송중인 데이터만을 표시해 주기 위해서 OUTER JOIN을 빼준다..
                           AND A.QLTY_VEHL_CD = D.QLTY_VEHL_CD
                           AND A.MDL_MDY_CD = D.MDL_MDY_CD
                           AND A.LANG_CD = D.LANG_CD
                           AND A.QLTY_VEHL_CD = E.QLTY_VEHL_CD(+)
                           AND A.MDL_MDY_CD = E.MDL_MDY_CD(+)
                           AND A.LANG_CD = E.LANG_CD(+)
						   AND A.QLTY_VEHL_CD = F.QLTY_VEHL_CD(+)
						   AND A.MDL_MDY_CD = F.MDL_MDY_CD(+)
						   AND A.LANG_CD = F.LANG_CD(+)
						   
					 	   /*** 속도 개선을 위한 쿼리 변경 
						   SELECT A.CL_SCN_CD,
			   				      A.DATA_SN,
							      A.QLTY_VEHL_CD,
							      A.MDL_MDY_CD,
							      A.LANG_CD,
							      A.DL_EXPD_REGN_CD,
							      A.QLTY_VEHL_NM,
							      A.LANG_CD_NM,
			   				      NVL(B.WEK2_PLAN_QTY, 0) AS WEK2_PLAN_QTY,
							      NVL(C.DAY3_PLAN_QTY, 0) AS DAY3_PLAN_QTY,
							      NVL(D.CURR_MTH_TRWI_QTY, 0) AS CURR_MTH_TRWI_QTY,
							      NVL(E.PREV_1DAY_TRWI_QTY, 0) AS PREV_1DAY_TRWI_QTY,
							      NVL(F.SEWHA_IV_QTY, 0) AS SEWHA_IV_QTY,
							      NVL(F.SEWHA_PRNT_YN, 'N') AS SEWHA_PRNT_YN,
								  NVL(G.SEWHA_DLVY_QTY, 0) AS SEWHA_DLVY_QTY,
							      NVL(H.PDI_IV_QTY, 0) AS PDI_IV_QTY,
							      NVL(I.DSID3_QTY, 0) AS DSID3_QTY
			   		       FROM T A,
                                --생산계획(2주)
                                (SELECT A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD, SUM(PRDN_PLN_QTY) AS WEK2_PLAN_QTY
                                 FROM T A,
                                      TB_APS_PROD_PLAN_SUM_INFO B
                                 WHERE A.DATA_SN = B.DATA_SN
      				             AND B.APL_STRT_YMD <= P_CURR_YMD
                                 AND B.APL_FNH_YMD >= P_CURR_YMD
      				             AND B.PLN_PARR_YMD BETWEEN P_CURR_YMD AND V_NEXT_2WEK_YMD
      				             GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD
                                ) B,
                                --단기계획(3일)
                                (SELECT A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD, SUM(NVL(B.PRDN_PLN_QTY, 0) + NVL(C.PRDN_QTY, 0)) AS DAY3_PLAN_QTY
                                 FROM T A,
                                      TB_APS_PROD_PLAN_SUM_INFO B,
                                      TB_PROD_MST_SUM_INFO C
                                 WHERE A.DATA_SN = B.DATA_SN(+)
                                 AND A.DATA_SN = C.DATA_SN(+)
                                 AND B.APL_STRT_YMD(+) <= P_CURR_YMD
                                 AND B.APL_FNH_YMD(+) >= P_CURR_YMD
                                 AND B.PLN_PARR_YMD(+) = P_CURR_YMD
                                 AND C.APL_YMD(+) = P_CURR_YMD
                                 GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD
                                ) C,
        				        --당월투입
        				        (SELECT A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD, SUM(PRDN_TRWI_QTY) AS CURR_MTH_TRWI_QTY
         				         FROM T A,
              		                  TB_PROD_MST_SUM_INFO B
         				         WHERE A.DATA_SN = B.DATA_SN
      				             AND B.APL_YMD BETWEEN V_CURR_FSTD_YMD AND P_CURR_YMD
      				             GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD
        				        ) D,
      				            --전일투입
      				            (SELECT A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD, SUM(PRDN_TRWI_QTY) AS PREV_1DAY_TRWI_QTY
         				         FROM T A,
              		                  TB_PROD_MST_SUM_INFO B
         				         WHERE A.DATA_SN = B.DATA_SN
      				             AND B.APL_YMD = V_PREV_1DAY_YMD
      				             GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD
        				        ) E,
        				        --세화재고
        				        (SELECT A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD, SUM(IV_QTY) AS SEWHA_IV_QTY,
						                --인쇄중 데이터 존재 여부 확인 ==> DL_EXPD_TMP_IV_QTY 값은 인쇄중 이전인 경우에는 NULL, 인쇄중인경우에는 인쇄 수량, 납품이후에는 0으로 설정되어 있음 
						  		        CASE WHEN SUM(DL_EXPD_TMP_IV_QTY) > 0 THEN 'Y' ELSE 'N'END AS SEWHA_PRNT_YN
         				         FROM T A,
              		   		          TB_DL_EXPD_MDY_MGMT B,
              				          TB_SEWHA_IV_INFO C
         				         WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
         				         AND A.MDL_MDY_CD = B.MDL_MDY_CD
         				         AND A.QLTY_VEHL_CD = C.QLTY_VEHL_CD
         				         AND B.DL_EXPD_MDL_MDY_CD = C.DL_EXPD_MDL_MDY_CD
         				         AND A.LANG_CD = C.LANG_CD
         				         AND C.CLS_YMD = P_CURR_YMD
						         GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD
                                ) F,
								--배송중 데이터 조회
								(SELECT A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD, SUM(RQ_QTY) AS SEWHA_DLVY_QTY
								 FROM T A,
								      TB_DL_EXPD_MDY_MGMT B,
									  TB_SEWHA_WHOT_INFO C
								 WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
         				         AND A.MDL_MDY_CD = B.MDL_MDY_CD
         				         AND A.QLTY_VEHL_CD = C.QLTY_VEHL_CD
         				         AND B.DL_EXPD_MDL_MDY_CD = C.DL_EXPD_MDL_MDY_CD
								 AND C.WHSN_YMD > P_CURR_YMD
								 GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD
								) G,
                                --PDI재고
                                (SELECT A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD, SUM(IV_QTY) AS PDI_IV_QTY
                                 FROM T A,
                                      TB_DL_EXPD_MDY_MGMT B,
                                      TB_PDI_IV_INFO C
                                 WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
                                 AND A.MDL_MDY_CD = B.MDL_MDY_CD
                                 AND A.QLTY_VEHL_CD = C.QLTY_VEHL_CD
                                 AND B.DL_EXPD_MDL_MDY_CD = C.DL_EXPD_MDL_MDY_CD
                                 AND A.LANG_CD = C.LANG_CD
                                 AND C.CLS_YMD = P_CURR_YMD
						         GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD
                                ) H,
						        --안전재고 조회
						        (SELECT A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD,
						                CASE WHEN B.DSID31_QTY IS NULL THEN (SELECT NVL(ROUND((SUM(PRDN_TRWI_QTY) / 365 + 1.96 + STDDEV(PRDN_TRWI_QTY)) * 3), 0)
								  	   					  	 	  	          FROM TB_PROD_MST_SUM_INFO C
																	          WHERE C.DATA_SN = A.DATA_SN
																	          AND C.APL_YMD BETWEEN V_PREV_YEAR_YMD AND V_PREV_1MTH_YMD)
								             ELSE B.DSID31_QTY END AS DSID3_QTY
						         FROM T A,
						   		      TB_SFTY_IV_MGMT B
						         WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD(+)
                                 AND A.MDL_MDY_CD = B.MDL_MDY_CD(+)
                                 AND A.QLTY_VEHL_CD = B.QLTY_VEHL_CD(+)
						        ) I
                           WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD(+)
                           AND A.MDL_MDY_CD = B.MDL_MDY_CD(+)
                           AND A.LANG_CD = B.LANG_CD(+)
                           AND A.QLTY_VEHL_CD = C.QLTY_VEHL_CD(+)
                           AND A.MDL_MDY_CD = C.MDL_MDY_CD(+)
                           AND A.LANG_CD = C.LANG_CD(+)
                           AND A.QLTY_VEHL_CD = D.QLTY_VEHL_CD(+)
                           AND A.MDL_MDY_CD = D.MDL_MDY_CD(+)
                           AND A.LANG_CD = D.LANG_CD(+)
                           AND A.QLTY_VEHL_CD = E.QLTY_VEHL_CD(+)
                           AND A.MDL_MDY_CD = E.MDL_MDY_CD(+)
                           AND A.LANG_CD = E.LANG_CD(+)
                           AND A.QLTY_VEHL_CD = F.QLTY_VEHL_CD(+)
                           AND A.MDL_MDY_CD = F.MDL_MDY_CD(+)
                           AND A.LANG_CD = F.LANG_CD(+)
                           AND A.QLTY_VEHL_CD = G.QLTY_VEHL_CD(+)
                           AND A.MDL_MDY_CD = G.MDL_MDY_CD(+)
                           AND A.LANG_CD = G.LANG_CD(+)
                           AND A.QLTY_VEHL_CD = H.QLTY_VEHL_CD(+)
                           AND A.MDL_MDY_CD = H.MDL_MDY_CD(+)
                           AND A.LANG_CD = H.LANG_CD(+)
						   AND A.QLTY_VEHL_CD = I.QLTY_VEHL_CD(+)
                           AND A.MDL_MDY_CD = I.MDL_MDY_CD(+)
                           AND A.LANG_CD = I.LANG_CD(+) 
						   ***/
						   
			             ) A,
				         TB_CODE_MGMT B
			         WHERE A.DL_EXPD_REGN_CD = B.DL_EXPD_PRVS_CD
			         AND B.DL_EXPD_G_CD = '0008'
			         AND WEK2_PLAN_QTY + DAY3_PLAN_QTY + CURR_MTH_TRWI_QTY +
			   	         PREV_1DAY_TRWI_QTY + SEWHA_IV_QTY + SEWHA_DLVY_QTY + PDI_IV_QTY > 0
			         --ORDER BY QLTY_VEHL_NM, B.SORT_SN, LANG_CD_NM
					 ORDER BY QLTY_VEHL_CD, LANG_SORT_SN, MDL_MDY_CD
					) A,
					TB_CODE_MGMT B
			    WHERE A.PRNT_STATE = B.DL_EXPD_PRVS_CD
				AND B.DL_EXPD_G_CD = '0016'
				AND PRNT_STATE = DECODE(P_IV_STATE, 'ALL', PRNT_STATE, P_IV_STATE);
		  
		  ELSE
		  	  
			  --배송완료된 데이터 조회인 경우
			  	
		  	  OPEN RS FOR
			 	  WITH T AS (SELECT A.CL_SCN_CD,
			          	 		    C.DATA_SN,
			  					    C.QLTY_VEHL_CD,
                                    C.MDL_MDY_CD,
                                    C.LANG_CD,
                                    --'(' || C.QLTY_VEHL_CD || ')' || B.QLTY_VEHL_NM || '-' || C.MDL_MDY_CD || 'MY' AS QLTY_VEHL_NM,
									C.QLTY_VEHL_CD || '-' || C.MDL_MDY_CD AS QLTY_VEHL_NM,
                                    --C.LANG_CD_NM,
									'(' || C.LANG_CD || ')' || C.LANG_CD_NM AS LANG_CD_NM,
                                    C.DL_EXPD_REGN_CD,
									C.SORT_SN AS LANG_SORT_SN
                             FROM (SELECT QLTY_VEHL_CD,
                                          MAX(CL_SCN_CD) AS CL_SCN_CD
                                   FROM TB_AUTH_VEHL_MGMT
                                   WHERE MENU_ID = PG_COMMON.FU_RPAD(P_MENU_ID, 10)
                                   AND USER_EENO = PG_COMMON.FU_RPAD(P_USER_EENO, 7)
                                   AND QLTY_VEHL_CD = DECODE(P_VEHL_CD, 'ALL', QLTY_VEHL_CD, P_VEHL_CD)
                                   GROUP BY QLTY_VEHL_CD
                                  ) A,
                                  TB_VEHL_MGMT B,
                                  TB_LANG_MGMT C
                             WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
                             AND A.QLTY_VEHL_CD = C.QLTY_VEHL_CD
                             AND B.MDL_MDY_CD = C.MDL_MDY_CD
                             AND B.MDL_MDY_CD BETWEEN V_FROM_MDL_MDY AND V_TO_MDL_MDY
                             AND B.MDL_MDY_CD = DECODE(P_MDL_MDY, '', B.MDL_MDY_CD, P_MDL_MDY)
						     AND B.DL_EXPD_PAC_SCN_CD = DECODE(P_PAC_SCN_CD, 'ALL', B.DL_EXPD_PAC_SCN_CD, P_PAC_SCN_CD)
                             AND B.DL_EXPD_PDI_CD = DECODE(P_PDI_CD, 'ALL', B.DL_EXPD_PDI_CD, P_PDI_CD)
						     AND C.DL_EXPD_REGN_CD = DECODE(P_REGN_CD, 'ALL', C.DL_EXPD_REGN_CD, P_REGN_CD)
                             AND C.LANG_CD = DECODE(P_LANG_CD, 'ALL', C.LANG_CD, P_LANG_CD)
							 AND B.USE_YN = 'Y'
							 AND C.USE_YN = 'Y'
                            )
			      SELECT A.CL_SCN_CD,
			   		     A.DATA_SN,
					     A.QLTY_VEHL_CD,
					     A.MDL_MDY_CD,
					     A.LANG_CD,
					     A.DL_EXPD_REGN_CD,
					     A.QLTY_VEHL_NM,
					     A.LANG_CD_NM,
					     A.DL_EXPD_REGN_NM,
					     A.WEK2_PLAN_QTY,
					     A.DAY3_PLAN_QTY,
					     A.CURR_MTH_TRWI_QTY,
					     A.PREV_1DAY_TRWI_QTY,
					     A.SEWHA_IV_QTY,
					     A.SEWHA_PRNT_YN, --세화 인쇄중 데이터 존재여부 확인 
					     A.SEWHA_DLVY_QTY,
					     A.PDI_DEEI1_QTY,
						 A.EXPD_WHSN_ST_NM,
						 A.PDI_IV_QTY,
					     A.DSID3_QTY,
						 A.DAY3_AFTR_IV_QTY,
						 A.WEK2_AFTR_IV_QTY,
						 A.PRNT_STATE,
						 B.DL_EXPD_PRVS_NM AS PRNT_STATE_NM,
						 PLNT_DAY3_QTY_TEXT,
						 PLNT_WEK2_QTY_TEXT,
						 PLNT_YN
			      FROM (SELECT A.CL_SCN_CD,
			   		           A.DATA_SN,
					           A.QLTY_VEHL_CD,
					           A.MDL_MDY_CD,
					           A.LANG_CD,
					           A.DL_EXPD_REGN_CD,
					           A.QLTY_VEHL_NM,
					           A.LANG_CD_NM,
					           B.DL_EXPD_PRVS_NM AS DL_EXPD_REGN_NM,
					           A.WEK2_PLAN_QTY,
					           A.DAY3_PLAN_QTY,
					           A.CURR_MTH_TRWI_QTY,
					           A.PREV_1DAY_TRWI_QTY,
					           A.SEWHA_IV_QTY,
					           A.SEWHA_PRNT_YN, --세화 인쇄중 데이터 존재여부 확인 
							   0 AS SEWHA_DLVY_QTY,
							   A.PDI_DEEI1_QTY,
							   A.EXPD_WHSN_ST_NM,
							   A.PDI_IV_QTY,
					           A.DSID3_QTY,
							   (A.PDI_IV_QTY - A.DAY3_PLAN_QTY) AS DAY3_AFTR_IV_QTY,
					           (A.PDI_IV_QTY - A.WEK2_PLAN_QTY) AS WEK2_AFTR_IV_QTY,
							   CASE WHEN A.DSID3_QTY * 1.5 <= A.PDI_IV_QTY - A.DAY3_PLAN_QTY THEN '01'
							        WHEN A.DSID3_QTY <= A.PDI_IV_QTY - A.DAY3_PLAN_QTY THEN '02'
								    WHEN A.DSID3_QTY > A.PDI_IV_QTY - A.DAY3_PLAN_QTY AND
								         A.DAY2_PLAN_QTY <= A.PDI_IV_QTY - A.DAY3_PLAN_QTY THEN '03'
								    ELSE '04' 
							   END AS PRNT_STATE,
							   PLNT_DAY3_QTY_TEXT,
							   PLNT_WEK2_QTY_TEXT,
							   PLNT_YN
			         FROM (SELECT A.CL_SCN_CD,
			   				      A.DATA_SN,
							      A.QLTY_VEHL_CD,
							      A.MDL_MDY_CD,
							      A.LANG_CD,
							      A.DL_EXPD_REGN_CD,
							      A.QLTY_VEHL_NM,
							      A.LANG_CD_NM,
								  A.LANG_SORT_SN,
			   				      NVL(B.WEK2_PLAN_QTY, 0) AS WEK2_PLAN_QTY,
								  --CASE WHEN NVL(B.DAY3_PLAN_QTY1, 0) > NVL(B.DAY3_PLAN_QTY2, 0) THEN NVL(B.DAY3_PLAN_QTY1, 0)
     							  --     ELSE NVL(B.DAY3_PLAN_QTY2, 0)
								  --END AS DAY3_PLAN_QTY,
								  NVL(B.DAY3_PLAN_QTY1, 0) AS DAY3_PLAN_QTY,
							      NVL(B.CURR_MTH_TRWI_QTY, 0) AS CURR_MTH_TRWI_QTY,
							      NVL(B.PREV_1DAY_TRWI_QTY, 0) AS PREV_1DAY_TRWI_QTY,
							      NVL(C.SEWHA_IV_QTY, 0) AS SEWHA_IV_QTY,
							      NVL(C.SEWHA_PRNT_YN, 'N') AS SEWHA_PRNT_YN,
								  NVL(D.PDI_DEEI1_QTY, 0) AS PDI_DEEI1_QTY,
								  NVL(D.EXPD_WHSN_ST_NM, '') AS EXPD_WHSN_ST_NM,
							      NVL(E.PDI_IV_QTY, 0) AS PDI_IV_QTY,
							      NVL(B.DSID3_QTY, 0) AS DSID3_QTY,
								  NVL(B.DAY2_PLAN_QTY, 0) AS DAY2_PLAN_QTY,
								  NVL(F.PLNT_DAY3_QTY_TEXT, ' ') AS PLNT_DAY3_QTY_TEXT,
								  NVL(F.PLNT_WEK2_QTY_TEXT, ' ') AS PLNT_WEK2_QTY_TEXT,
								  NVL(F.PLNT_YN, 'N') AS PLNT_YN
						   FROM T A,
						        (SELECT A.QLTY_VEHL_CD, 
										A.MDL_MDY_CD, 
										A.LANG_CD,
										NVL(B.WEK2_PRDN_PLN_QTY, 0) + NVL(B.TDD_PRDN_QTY3, 0) AS WEK2_PLAN_QTY,
										NVL(B.TDD_PRDN_PLN_QTY, 0) + NVL(B.TDD_PRDN_QTY3, 0) AS DAY3_PLAN_QTY1,
										--NVL(B.TDD_PRDN_QTY, 0) AS DAY3_PLAN_QTY2,
										NVL(B.TMM_TRWI_QTY, 0) AS CURR_MTH_TRWI_QTY,
								  		NVL(B.BOD_TRWI_QTY, 0) AS PREV_1DAY_TRWI_QTY,
										CASE WHEN A.LANG_CD = 'EU' THEN NVL(B.TDD_PRDN_PLN_QTY, 0) + NVL(B.TDD_PRDN_QTY2, 0)
										     ELSE NVL(B.TDD_PRDN_PLN_QTY2, 0) + NVL(B.TDD_PRDN_QTY2, 0)
									    END AS DSID3_QTY,
										NVL(B.TDD_PRDN_PLN_QTY3, 0) + NVL(B.TDD_PRDN_QTY2, 0) AS DAY2_PLAN_QTY
								 FROM T A,
						         	  TB_APS_PROD_SUM_INFO B
						         WHERE A.DATA_SN = B.DATA_SN
						   		 AND B.APL_YMD = P_CURR_YMD
								) B,
								--세화재고
        				        (SELECT A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD, SUM(B.SFTY_IV_QTY) AS SEWHA_IV_QTY,
						                --인쇄중 데이터 존재 여부 확인 ==> DL_EXPD_TMP_IV_QTY 값은 인쇄중 이전인 경우에는 NULL, 인쇄중인경우에는 인쇄 수량, 납품이후에는 0으로 설정되어 있음 
						  		        CASE WHEN SUM(B.DL_EXPD_TMP_IV_QTY) > 0 THEN 'Y' ELSE 'N'END AS SEWHA_PRNT_YN
         				         FROM T A,
              				          TB_SEWHA_IV_INFO_DTL B
         				         WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
         				         AND A.MDL_MDY_CD = B.MDL_MDY_CD
         				         AND A.LANG_CD = B.LANG_CD
         				         AND B.CLS_YMD = P_CURR_YMD
								 AND B.SFTY_IV_QTY > 0 --안전재고수량이 없는 것은 가져오지 않는다. 
						         GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD
								 
								 /***
								 SELECT A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD, SUM(IV_QTY) AS SEWHA_IV_QTY,
						                --인쇄중 데이터 존재 여부 확인 ==> DL_EXPD_TMP_IV_QTY 값은 인쇄중 이전인 경우에는 NULL, 인쇄중인경우에는 인쇄 수량, 납품이후에는 0으로 설정되어 있음 
						  		        CASE WHEN SUM(DL_EXPD_TMP_IV_QTY) > 0 THEN 'Y' ELSE 'N'END AS SEWHA_PRNT_YN
         				         FROM T A,
              		   		          TB_DL_EXPD_MDY_MGMT B,
              				          TB_SEWHA_IV_INFO C
         				         WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
         				         AND A.MDL_MDY_CD = B.MDL_MDY_CD
         				         AND A.QLTY_VEHL_CD = C.QLTY_VEHL_CD
         				         AND B.DL_EXPD_MDL_MDY_CD = C.DL_EXPD_MDL_MDY_CD
         				         AND A.LANG_CD = C.LANG_CD
         				         AND C.CLS_YMD = P_CURR_YMD
						         GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD
								 ***/
								 
                                ) C,
								--입고확인 데이터 조회 
								(SELECT A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD, 
										SUM(B.DEEI1_QTY) AS PDI_DEEI1_QTY,
										MAX(C.DL_EXPD_PRVS_NM) AS EXPD_WHSN_ST_NM
								 FROM T A,
									  TB_PDI_WHSN_INFO B,
									  TB_CODE_MGMT C
								 WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
         				         AND A.MDL_MDY_CD = B.MDL_MDY_CD
							 	 AND A.LANG_CD = B.LANG_CD
								 AND B.WHSN_YMD = P_CURR_YMD
								 AND B.DL_EXPD_WHSN_ST_CD = C.DL_EXPD_PRVS_CD(+)
						         AND C.DL_EXPD_G_CD(+) = '0013'
								 GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD 
								 
								 /***
								 SELECT A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD, 
										SUM(DEEI1_QTY) AS PDI_DEEI1_QTY,
										MAX(D.DL_EXPD_PRVS_NM) AS EXPD_WHSN_ST_NM
								 FROM T A,
								      TB_DL_EXPD_MDY_MGMT B,
									  TB_PDI_WHSN_INFO C,
									  TB_CODE_MGMT D
								 WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
         				         AND A.MDL_MDY_CD = B.MDL_MDY_CD
--[수정예정] 나중에 주석 제거 요망 (지역, 연식) 								 
								 --AND A.DL_EXPD_REGN_CD = B.DL_EXPD_REGN_CD 									 
         				         AND A.QLTY_VEHL_CD = C.QLTY_VEHL_CD
         				         AND B.DL_EXPD_MDL_MDY_CD = C.DL_EXPD_MDL_MDY_CD
								 AND A.LANG_CD = C.LANG_CD
								 --AND A.MDL_MDY_CD = C.MDL_MDY_CD
								 AND C.WHSN_YMD = P_CURR_YMD
								 AND C.DL_EXPD_WHSN_ST_CD = D.DL_EXPD_PRVS_CD(+)
						         AND D.DL_EXPD_G_CD(+) = '0013'
								 GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD 
								 ***/
								 
								) D,
                                --PDI재고
                                (SELECT A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD, SUM(B.SFTY_IV_QTY) AS PDI_IV_QTY
                                 FROM T A,
                                      TB_PDI_IV_INFO_DTL B
                                 WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
                                 AND A.MDL_MDY_CD = B.MDL_MDY_CD
                                 AND A.LANG_CD = B.LANG_CD
                                 AND B.CLS_YMD = P_CURR_YMD
								 AND B.SFTY_IV_QTY > 0 --안전재고수량이 없는 것은 가져오지 않는다. 
						         GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD
								 
								 /***
								 SELECT A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD, SUM(IV_QTY) AS PDI_IV_QTY
                                 FROM T A,
                                      TB_DL_EXPD_MDY_MGMT B,
                                      TB_PDI_IV_INFO C
                                 WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
                                 AND A.MDL_MDY_CD = B.MDL_MDY_CD
                                 AND A.QLTY_VEHL_CD = C.QLTY_VEHL_CD
                                 AND B.DL_EXPD_MDL_MDY_CD = C.DL_EXPD_MDL_MDY_CD
                                 AND A.LANG_CD = C.LANG_CD
                                 AND C.CLS_YMD = P_CURR_YMD
						         GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD
								 ***/
								 
                                ) E,
								(SELECT A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD,
										PG_TOT_IV_INFO.FU_GET_PLNT_DAY3_PLAN_QTY(P_CURR_YMD, A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD) AS PLNT_DAY3_QTY_TEXT,
										PG_TOT_IV_INFO.FU_GET_PLNT_WEK2_PLAN_QTY(P_CURR_YMD, A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD) AS PLNT_WEK2_QTY_TEXT,
										'Y' AS PLNT_YN
                                 FROM T A,
                                      TB_PLNT_APS_PROD_SUM_INFO B
                                 WHERE A.DATA_SN = B.DATA_SN
                                 AND B.APL_YMD = P_CURR_YMD
						         GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD
								) F 
						   WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD(+)
                           AND A.MDL_MDY_CD = B.MDL_MDY_CD(+)
                           AND A.LANG_CD = B.LANG_CD(+)
                           AND A.QLTY_VEHL_CD = C.QLTY_VEHL_CD(+)
                           AND A.MDL_MDY_CD = C.MDL_MDY_CD(+)
                           AND A.LANG_CD = C.LANG_CD(+)
						   --입고확인된 데이터만을 표시해 주기 위해서 OUTER JOIN을 빼준다..
                           AND A.QLTY_VEHL_CD = D.QLTY_VEHL_CD
                           AND A.MDL_MDY_CD = D.MDL_MDY_CD
                           AND A.LANG_CD = D.LANG_CD
                           AND A.QLTY_VEHL_CD = E.QLTY_VEHL_CD(+)
                           AND A.MDL_MDY_CD = E.MDL_MDY_CD(+)
                           AND A.LANG_CD = E.LANG_CD(+)
                           AND A.QLTY_VEHL_CD = F.QLTY_VEHL_CD(+)
						   AND A.MDL_MDY_CD = F.MDL_MDY_CD(+)
						   AND A.LANG_CD = F.LANG_CD(+)
						   
					       /*** 속도 개선을 위한 쿼리 변경 
					 	   SELECT A.CL_SCN_CD,
			   				      A.DATA_SN,
							      A.QLTY_VEHL_CD,
							      A.MDL_MDY_CD,
							      A.LANG_CD,
							      A.DL_EXPD_REGN_CD,
							      A.QLTY_VEHL_NM,
							      A.LANG_CD_NM,
			   				      NVL(B.WEK2_PLAN_QTY, 0) AS WEK2_PLAN_QTY,
							      NVL(C.DAY3_PLAN_QTY, 0) AS DAY3_PLAN_QTY,
							      NVL(D.CURR_MTH_TRWI_QTY, 0) AS CURR_MTH_TRWI_QTY,
							      NVL(E.PREV_1DAY_TRWI_QTY, 0) AS PREV_1DAY_TRWI_QTY,
							      NVL(F.SEWHA_IV_QTY, 0) AS SEWHA_IV_QTY,
							      NVL(F.SEWHA_PRNT_YN, 'N') AS SEWHA_PRNT_YN,
								  NVL(G.PDI_DEEI1_QTY, 0) AS PDI_DEEI1_QTY,
								  NVL(G.EXPD_WHSN_ST_NM, '') AS EXPD_WHSN_ST_NM,
							      NVL(H.PDI_IV_QTY, 0) AS PDI_IV_QTY,
							      NVL(I.DSID3_QTY, 0) AS DSID3_QTY
			   		       FROM T A,
                                --생산계획(2주)
                                (SELECT A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD, SUM(PRDN_PLN_QTY) AS WEK2_PLAN_QTY
                                 FROM T A,
                                      TB_APS_PROD_PLAN_SUM_INFO B
                                 WHERE A.DATA_SN = B.DATA_SN
      				             AND B.APL_STRT_YMD <= P_CURR_YMD
                                 AND B.APL_FNH_YMD >= P_CURR_YMD
      				             AND B.PLN_PARR_YMD BETWEEN P_CURR_YMD AND V_NEXT_2WEK_YMD
      				             GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD
                                ) B,
                                --단기계획(3일)
                                (SELECT A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD, SUM(NVL(B.PRDN_PLN_QTY, 0) + NVL(C.PRDN_QTY, 0)) AS DAY3_PLAN_QTY
                                 FROM T A,
                                      TB_APS_PROD_PLAN_SUM_INFO B,
                                      TB_PROD_MST_SUM_INFO C
                                 WHERE A.DATA_SN = B.DATA_SN(+)
                                 AND A.DATA_SN = C.DATA_SN(+)
                                 AND B.APL_STRT_YMD(+) <= P_CURR_YMD
                                 AND B.APL_FNH_YMD(+) >= P_CURR_YMD
                                 AND B.PLN_PARR_YMD(+) = P_CURR_YMD
                                 AND C.APL_YMD(+) = P_CURR_YMD
                                 GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD
                                ) C,
        				        --당월투입
        				        (SELECT A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD, SUM(PRDN_TRWI_QTY) AS CURR_MTH_TRWI_QTY
         				         FROM T A,
              		                  TB_PROD_MST_SUM_INFO B
         				         WHERE A.DATA_SN = B.DATA_SN
      				             AND B.APL_YMD BETWEEN V_CURR_FSTD_YMD AND P_CURR_YMD
      				             GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD
        				        ) D,
      				            --전일투입
      				            (SELECT A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD, SUM(PRDN_TRWI_QTY) AS PREV_1DAY_TRWI_QTY
         				         FROM T A,
              		                  TB_PROD_MST_SUM_INFO B
         				         WHERE A.DATA_SN = B.DATA_SN
      				             AND B.APL_YMD = V_PREV_1DAY_YMD
      				             GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD
        				        ) E,
        				        --세화재고
        				        (SELECT A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD, SUM(IV_QTY) AS SEWHA_IV_QTY,
						                --인쇄중 데이터 존재 여부 확인 ==> DL_EXPD_TMP_IV_QTY 값은 인쇄중 이전인 경우에는 NULL, 인쇄중인경우에는 인쇄 수량, 납품이후에는 0으로 설정되어 있음 
						  		        CASE WHEN SUM(DL_EXPD_TMP_IV_QTY) > 0 THEN 'Y' ELSE 'N'END AS SEWHA_PRNT_YN
         				         FROM T A,
              		   		          TB_DL_EXPD_MDY_MGMT B,
              				          TB_SEWHA_IV_INFO C
         				         WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
         				         AND A.MDL_MDY_CD = B.MDL_MDY_CD
         				         AND A.QLTY_VEHL_CD = C.QLTY_VEHL_CD
         				         AND B.DL_EXPD_MDL_MDY_CD = C.DL_EXPD_MDL_MDY_CD
         				         AND A.LANG_CD = C.LANG_CD
         				         AND C.CLS_YMD = P_CURR_YMD
						         GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD
                                ) F,
								--입고확인 데이터 조회 
								(SELECT A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD, 
										SUM(DEEI1_QTY) AS PDI_DEEI1_QTY,
										MAX(D.DL_EXPD_PRVS_NM) AS EXPD_WHSN_ST_NM
								 FROM T A,
								      TB_DL_EXPD_MDY_MGMT B,
									  TB_PDI_WHSN_INFO C,
									  TB_CODE_MGMT D
								 WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
         				         AND A.MDL_MDY_CD = B.MDL_MDY_CD
         				         AND A.QLTY_VEHL_CD = C.QLTY_VEHL_CD
         				         AND B.DL_EXPD_MDL_MDY_CD = C.DL_EXPD_MDL_MDY_CD
								 AND C.WHSN_YMD = P_CURR_YMD
								 AND C.DL_EXPD_WHSN_ST_CD = D.DL_EXPD_PRVS_CD(+)
						         AND D.DL_EXPD_G_CD(+) = '0013'
								 GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD
								) G,
                                --PDI재고
                                (SELECT A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD, SUM(IV_QTY) AS PDI_IV_QTY
                                 FROM T A,
                                      TB_DL_EXPD_MDY_MGMT B,
                                      TB_PDI_IV_INFO C
                                 WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
                                 AND A.MDL_MDY_CD = B.MDL_MDY_CD
                                 AND A.QLTY_VEHL_CD = C.QLTY_VEHL_CD
                                 AND B.DL_EXPD_MDL_MDY_CD = C.DL_EXPD_MDL_MDY_CD
                                 AND A.LANG_CD = C.LANG_CD
                                 AND C.CLS_YMD = P_CURR_YMD
						         GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD
                                ) H,
						        --안전재고 조회
						        (SELECT A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD,
						                CASE WHEN B.DSID31_QTY IS NULL THEN (SELECT NVL(ROUND((SUM(PRDN_TRWI_QTY) / 365 + 1.96 + STDDEV(PRDN_TRWI_QTY)) * 3), 0)
								  	   					  	 	  	          FROM TB_PROD_MST_SUM_INFO C
																	          WHERE C.DATA_SN = A.DATA_SN
																	          AND C.APL_YMD BETWEEN V_PREV_YEAR_YMD AND V_PREV_1MTH_YMD)
								             ELSE B.DSID31_QTY END AS DSID3_QTY
						         FROM T A,
						   		      TB_SFTY_IV_MGMT B
						         WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD(+)
                                 AND A.MDL_MDY_CD = B.MDL_MDY_CD(+)
                                 AND A.QLTY_VEHL_CD = B.QLTY_VEHL_CD(+)
						        ) I
                           WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD(+)
                           AND A.MDL_MDY_CD = B.MDL_MDY_CD(+)
                           AND A.LANG_CD = B.LANG_CD(+)
                           AND A.QLTY_VEHL_CD = C.QLTY_VEHL_CD(+)
                           AND A.MDL_MDY_CD = C.MDL_MDY_CD(+)
                           AND A.LANG_CD = C.LANG_CD(+)
                           AND A.QLTY_VEHL_CD = D.QLTY_VEHL_CD(+)
                           AND A.MDL_MDY_CD = D.MDL_MDY_CD(+)
                           AND A.LANG_CD = D.LANG_CD(+)
                           AND A.QLTY_VEHL_CD = E.QLTY_VEHL_CD(+)
                           AND A.MDL_MDY_CD = E.MDL_MDY_CD(+)
                           AND A.LANG_CD = E.LANG_CD(+)
                           AND A.QLTY_VEHL_CD = F.QLTY_VEHL_CD(+)
                           AND A.MDL_MDY_CD = F.MDL_MDY_CD(+)
                           AND A.LANG_CD = F.LANG_CD(+)
                           AND A.QLTY_VEHL_CD = G.QLTY_VEHL_CD(+)
                           AND A.MDL_MDY_CD = G.MDL_MDY_CD(+)
                           AND A.LANG_CD = G.LANG_CD(+)
                           AND A.QLTY_VEHL_CD = H.QLTY_VEHL_CD(+)
                           AND A.MDL_MDY_CD = H.MDL_MDY_CD(+)
                           AND A.LANG_CD = H.LANG_CD(+)
						   AND A.QLTY_VEHL_CD = I.QLTY_VEHL_CD(+)
                           AND A.MDL_MDY_CD = I.MDL_MDY_CD(+)
                           AND A.LANG_CD = I.LANG_CD(+)
						   ***/
						   
			             ) A,
				         TB_CODE_MGMT B
			         WHERE A.DL_EXPD_REGN_CD = B.DL_EXPD_PRVS_CD
			         AND B.DL_EXPD_G_CD = '0008'
			         AND WEK2_PLAN_QTY + DAY3_PLAN_QTY + CURR_MTH_TRWI_QTY +
			   	         PREV_1DAY_TRWI_QTY + SEWHA_IV_QTY + PDI_DEEI1_QTY + PDI_IV_QTY > 0
			         --ORDER BY QLTY_VEHL_NM, B.SORT_SN, LANG_CD_NM
					 ORDER BY QLTY_VEHL_CD, LANG_SORT_SN, MDL_MDY_CD
					) A,
					TB_CODE_MGMT B
			    WHERE A.PRNT_STATE = B.DL_EXPD_PRVS_CD
				AND B.DL_EXPD_G_CD = '0016'
				AND PRNT_STATE = DECODE(P_IV_STATE, 'ALL', PRNT_STATE, P_IV_STATE);
		  
		  END IF;
		  
	   END SP_GET_SEWHA_IV_INFO2;
	   
	   --세화출고 현황 조회 			   
	   PROCEDURE SP_GET_SEWHA_WHOT_INFO(P_MENU_ID 	   VARCHAR2,
								        P_USER_EENO    VARCHAR2,
	   			 						P_DATA_SN_LIST VARCHAR2,
			  						    P_CURR_YMD     VARCHAR2,
			  						    RS OUT REFCUR)
	   IS
	   	 
		 V_CURR_YMD VARCHAR2(8);
		 
		 V_QUERY    VARCHAR2(8000);
		 
	   BEGIN
	   	 
		 V_CURR_YMD := TO_CHAR(SYSDATE, 'YYYYMMDD');
		 
		 --이전 날짜에 재고 데이터가 소진된 항목에 대해서 재고 데이터 새로이 생성
		 PG_DATA.SP_REMAKE_SEWHA_IV_INFO(P_DATA_SN_LIST, P_CURR_YMD, V_CURR_YMD, P_USER_EENO, NULL);  -- 광주로 인해 일단 NULL 근데 프로그램용...??
		 
		 /****  수정권한 체크로직 없는 버전  ****/
		 /**
		 V_QUERY := 'SELECT * ' || 
			        'FROM (SELECT A.EXPD_CO_NM,' ||
			  	   		         'NVL(C.DL_EXPD_PRVS_NM, '''') AS EXPD_RQ_SCN_NM,' || --요청구분
						         'A.QLTY_VEHL_NM,'||
						         'A.LANG_CD_NM,' ||
						         'A.N_PRNT_PBCN_NO,' ||
						         'A.IV_QTY,' ||
						         'A.RQ_QTY,' ||
						         'A.EXPD_BOX_QTY,' ||
						         'A.DLVG_PARR_YMD,' ||
						         'A.DLVG_PARR_HHMM,' ||
						         'NVL(B.USER_NM, '''') AS PWTI_NM,' ||                --인수자성명 
						         'NVL(B.USER_TN, '''') AS PWTI_TN,' ||                --인수자전화번호
						  		 'A.PRTL_IMTR_SBC,' ||
						  		 'A.QLTY_VEHL_CD,' ||
								 'A.MDL_MDY_CD,' ||
						  		 'A.DL_EXPD_MDL_MDY_CD,' ||
						  		 'A.LANG_CD,' ||
						  		 'A.DTL_SN,' ||                                       --출고요청일련번호 
						  		 'A.EXPD_RQ_SCN_CD,' ||                               --요청구분코드 
						  		 'A.PWTI_EENO,' ||                                    --인수자사원번호 
								 'A.CLS_YMD ' ||
			              'FROM (SELECT A.CLS_YMD,' ||
			  	   		               'A.QLTY_VEHL_CD,' ||
									   'A.MDL_MDY_CD,' ||
						               'A.DL_EXPD_MDL_MDY_CD,' ||
						               'A.LANG_CD,' ||
						               'A.N_PRNT_PBCN_NO,' ||
						               'A.IV_QTY,' ||
						               'A.EXPD_CO_CD,' ||
						               'A.EXPD_REGN_CD,' ||
						               'A.QLTY_VEHL_NM,' ||
						               'A.LANG_CD_NM,' ||
						               'A.EXPD_CO_NM,' ||
						               'NVL(B.RQ_QTY, 0) AS RQ_QTY,' ||
						               'NVL(B.DL_EXPD_BOX_QTY, 0) AS EXPD_BOX_QTY,' ||
						               'NVL(TO_CHAR(TO_DATE(B.DLVG_PARR_YMD, ''YYYYMMDD''), ''YYYY-MM-DD''), '''') AS DLVG_PARR_YMD,' ||
						               'NVL(TO_CHAR(TO_DATE(B.DLVG_PARR_HHMM, ''HH24MI''), ''HH24:MI''), '''') AS DLVG_PARR_HHMM,' ||
						               'NVL(B.PWTI_EENO, '''') AS PWTI_EENO,' ||
						               'NVL(B.PRTL_IMTR_SBC, '''') AS PRTL_IMTR_SBC,' ||
								       'NVL(B.DL_EXPD_RQ_SCN_CD, '''') AS EXPD_RQ_SCN_CD,' ||
								       'NVL(B.DTL_SN, 0) AS DTL_SN ' ||
			                     'FROM (SELECT B.CLS_YMD,' ||
			  	   		                      'A.QLTY_VEHL_CD,' ||
											  'A.MDL_MDY_CD,' ||
						                      'A.DL_EXPD_MDL_MDY_CD,' ||
						                      'A.LANG_CD,' ||
						                      'B.N_PRNT_PBCN_NO,' ||
						                      'B.IV_QTY,' ||
						                      'A.EXPD_CO_CD,' ||
						                      'A.EXPD_REGN_CD,' ||
						                      'A.QLTY_VEHL_NM,' ||
						                      'A.LANG_CD_NM,' ||
						                      'A.EXPD_CO_NM ' ||
			                            'FROM (SELECT A.QLTY_VEHL_CD,' ||
			  	   		                             'A.LANG_CD,' ||
													 'A.MDL_MDY_CD,' ||
						                             'C.DL_EXPD_MDL_MDY_CD,' ||
						                             'B.DL_EXPD_CO_CD AS EXPD_CO_CD,' ||
						                             'A.DL_EXPD_REGN_CD AS EXPD_REGN_CD,' ||
						                           '''('' || B.QLTY_VEHL_CD || '')'' || B.QLTY_VEHL_NM || ''-'' || B.MDL_MDY_CD || ''MY'' AS QLTY_VEHL_NM,' ||
						                             'E.DL_EXPD_PRVS_NM || ''-'' || ''('' || A.LANG_CD || '')'' || A.LANG_CD_NM AS LANG_CD_NM,' ||
						                             'D.DL_EXPD_PRVS_NM AS EXPD_CO_NM ' ||
			                                  'FROM TB_LANG_MGMT A,' ||
			  	                                   'TB_VEHL_MGMT B,' ||
			  	                                   'TB_DL_EXPD_MDY_MGMT C,' ||
						                           'TB_CODE_MGMT D,' ||
						                           'TB_CODE_MGMT E ' ||
				                              'WHERE A.DATA_SN IN (' || P_DATA_SN_LIST || ') ' ||
					                          'AND A.QLTY_VEHL_CD = B.QLTY_VEHL_CD ' ||
					                          'AND A.MDL_MDY_CD = B.MDL_MDY_CD ' ||
					                          'AND A.QLTY_VEHL_CD = C.QLTY_VEHL_CD ' ||
					                          'AND A.MDL_MDY_CD = C.MDL_MDY_CD ' ||
					                          'AND B.DL_EXPD_CO_CD = D.DL_EXPD_PRVS_CD ' ||
			                                  'AND D.DL_EXPD_G_CD = ''0003'' ' ||
					                          'AND A.DL_EXPD_REGN_CD = E.DL_EXPD_PRVS_CD ' ||
			                                  'AND E.DL_EXPD_G_CD = ''0008'' ' ||
				                             ') A,' ||
				                            'TB_SEWHA_IV_INFO B ' ||
					                     'WHERE B.CLS_YMD = ''' || P_CURR_YMD || '''' ||
					                     'AND A.QLTY_VEHL_CD = B.QLTY_VEHL_CD ' ||
					                     'AND A.DL_EXPD_MDL_MDY_CD = B.DL_EXPD_MDL_MDY_CD ' ||
					                     'AND A.LANG_CD = B.LANG_CD ' ||
					                     'AND B.DL_EXPD_TMP_IV_QTY = 0 ' || --인쇄가 끝난것만을 가져온다.
				                        ') A,' ||
					                    'TB_SEWHA_WHOT_INFO B ' ||
					             'WHERE A.CLS_YMD = B.WHOT_YMD(+) ' ||
					             'AND A.QLTY_VEHL_CD = B.QLTY_VEHL_CD(+) ' ||
					             'AND A.DL_EXPD_MDL_MDY_CD = B.DL_EXPD_MDL_MDY_CD(+) ' ||
					             'AND A.LANG_CD = B.LANG_CD(+) ' ||
					             'AND A.N_PRNT_PBCN_NO = B.N_PRNT_PBCN_NO(+) ' ||
					             'AND B.CMPL_YN = ''N'' ' ||   --입고확인이 되지 않은 데이터만을 가져온다.
				                ') A,' ||
				               'TB_USR_MGMT B,' ||
				               'TB_CODE_MGMT C ' ||
			              'WHERE A.PWTI_EENO = B.USER_EENO(+) ' ||
					      'AND A.EXPD_RQ_SCN_CD = C.DL_EXPD_PRVS_CD(+) ' ||
					      'AND C.DL_EXPD_G_CD(+) = ''0012'' ' ||
				         ')';
		   **/				 
		  
		  /****  수정권한 체크로직 있는 버전  ****/
		  --해당 차종, 언어에 대하여 하루에 한번만 출고 되도록 한다. (DTL_SN을 넘겨주는 이유임....)
		  
		  V_QUERY := 'SELECT * ' ||
			         'FROM (SELECT A.EXPD_CO_NM,' ||
			  	   		          'NVL(C.DL_EXPD_PRVS_NM, '''') AS EXPD_RQ_SCN_NM,' || --요청구분
						          'A.QLTY_VEHL_NM,'||
						          'A.LANG_CD_NM,' ||
						          'A.N_PRNT_PBCN_NO,' ||
						          'A.IV_QTY,' ||
						          'A.RQ_QTY,' ||
						          'A.EXPD_BOX_QTY,' ||
						          'NVL(A.DLVG_PARR_YMD, TO_CHAR(SYSDATE, ''YYYY-MM-DD'')) AS DLVG_PARR_YMD,' ||
						          'NVL(A.DLVG_PARR_HHMM,TO_CHAR(SYSDATE, ''HH24:MI'')) AS DLVG_PARR_HHMM,' ||
						          --'NVL(B.USER_NM, '''') AS PWTI_NM,' ||                --인수자성명 
								  'PWTI_NM,' ||
						          --'NVL(B.USER_TN, '''') AS PWTI_TN,' ||                --인수자전화번호
								  ''''' AS PWTI_TN,' ||
						  		  'A.PRTL_IMTR_SBC,' ||
						  		  'A.QLTY_VEHL_CD,' ||
								  'A.MDL_MDY_CD,' ||
								  'A.DL_EXPD_MDL_MDY_CD,' ||
						  		  'A.LANG_CD,' ||
						  		  'A.DTL_SN,' ||                                       --출고요청일련번호 
						  		  'A.EXPD_RQ_SCN_CD,' ||                               --요청구분코드 
						  		  'A.PWTI_EENO,' ||                                    --인수자사원번호 
								  'A.CL_SCN_CD ' ||
			              'FROM (SELECT A.QLTY_VEHL_CD,' ||
									   'A.MDL_MDY_CD,' ||
						               'A.LANG_CD,' ||
									   'A.DL_EXPD_MDL_MDY_CD,' ||
						               'A.N_PRNT_PBCN_NO,' ||
						               'A.IV_QTY,' ||
						               'A.EXPD_CO_CD,' ||
						               'A.EXPD_REGN_CD,' ||
						               'A.QLTY_VEHL_NM,' ||
						               'A.LANG_CD_NM,' ||
						               'A.EXPD_CO_NM,' ||
									   'A.LANG_SORT_SN,' ||
						               'NVL(B.RQ_QTY, 0) AS RQ_QTY,' ||
						               'NVL(B.DL_EXPD_BOX_QTY, 0) AS EXPD_BOX_QTY,' ||
						               'TO_CHAR(TO_DATE(B.DLVG_PARR_YMD, ''YYYYMMDD''), ''YYYY-MM-DD'') AS DLVG_PARR_YMD,' ||
						               'TO_CHAR(TO_DATE(B.DLVG_PARR_HHMM,''HH24MI''), ''HH24:MI'') AS DLVG_PARR_HHMM,' ||
						               'NVL(B.PWTI_EENO, '''') AS PWTI_EENO,' ||
									   'NVL(B.PWTI_NM, '''') AS PWTI_NM,' ||
						               'NVL(B.PRTL_IMTR_SBC, '''') AS PRTL_IMTR_SBC,' ||
								       'NVL(B.DL_EXPD_RQ_SCN_CD, '''') AS EXPD_RQ_SCN_CD,' ||
								       'NVL(B.DTL_SN, 0) AS DTL_SN,' ||
									   --'CASE WHEN A.CL_SCN_CD = ''U'' AND A.CLS_YMD = ''' || V_CURR_YMD || ''' THEN ''Y'' ' || 
							           --     'ELSE ''N'' END AS CL_SCN_CD ' ||   
									   --[변경] 입고확인이 되지 않은 데이터는 수정권한이 있으면 계속 수정할 수 있다.
									   --(삭제 기능 추가로 인하여 아래와 같이 수정한 것임) 
									   'CASE WHEN A.CL_SCN_CD = ''U'' THEN ''Y'' ' || 
							                'ELSE ''N'' END AS CL_SCN_CD ' ||  
			                     'FROM (SELECT B.CLS_YMD,' ||
			  	   		                      'A.QLTY_VEHL_CD,' ||
											  'A.MDL_MDY_CD,' ||
						                      'A.LANG_CD,' ||
											  'B.DL_EXPD_MDL_MDY_CD,' ||
						                      'B.N_PRNT_PBCN_NO,' ||
						                      'B.IV_QTY,' ||
						                      'A.EXPD_CO_CD,' ||
						                      'A.EXPD_REGN_CD,' ||
						                      'A.QLTY_VEHL_NM,' ||
						                      'A.LANG_CD_NM,' ||
						                      'A.EXPD_CO_NM, ' ||
											  'A.CL_SCN_CD, ' ||
											  'A.LANG_SORT_SN ' ||
			                            'FROM (SELECT A.QLTY_VEHL_CD,' ||
			  	   		                             'A.LANG_CD,' ||
													 'A.MDL_MDY_CD,' ||
						                             'B.DL_EXPD_CO_CD AS EXPD_CO_CD,' ||
						                             'A.DL_EXPD_REGN_CD AS EXPD_REGN_CD,' ||
						                           --'''('' || B.QLTY_VEHL_CD || '')'' || B.QLTY_VEHL_NM || ''-'' || B.MDL_MDY_CD || ''MY'' AS QLTY_VEHL_NM,' || 
												   '''('' || B.QLTY_VEHL_CD || ''-'' || B.MDL_MDY_CD || '')'' || B.QLTY_VEHL_NM AS QLTY_VEHL_NM,' ||
						                             --'D.DL_EXPD_PRVS_NM || ''-'' || ''('' || A.LANG_CD || '')'' || A.LANG_CD_NM AS LANG_CD_NM,' ||
						                             'CASE WHEN A.A_CODE IS NULL THEN ''('' || A.LANG_CD || '')'' ' ||
									                      'ELSE ''('' || A.LANG_CD || ''-'' || A.A_CODE || '')'' ' || 
								    			     'END || A.LANG_CD_NM AS LANG_CD_NM,' ||												   
													 'C.DL_EXPD_PRVS_NM AS EXPD_CO_NM,' ||
													 'A.LANG_SORT_SN,' ||
													 'A.CL_SCN_CD ' ||
			                                  'FROM (SELECT A.QLTY_VEHL_CD,' ||
									 	  		           'A.MDL_MDY_CD,' ||
												           'A.LANG_CD,' ||
												           'MAX(A.LANG_CD_NM) AS LANG_CD_NM,' ||
												           'MAX(A.DL_EXPD_REGN_CD) AS DL_EXPD_REGN_CD,' ||
														   'MAX(A.A_CODE) AS A_CODE,' ||
														   'MAX(A.SORT_SN) AS LANG_SORT_SN,' ||
												           'MAX(B.CL_SCN_CD) AS CL_SCN_CD ' ||
									                 'FROM TB_LANG_MGMT A,' ||
										                  'TB_AUTH_VEHL_MGMT B ' ||
										             'WHERE A.DATA_SN IN (' || P_DATA_SN_LIST || ') ' ||
										             'AND A.QLTY_VEHL_CD = B.QLTY_VEHL_CD ' ||
										             'AND B.MENU_ID = PG_COMMON.FU_RPAD(''' || P_MENU_ID || ''', 10) ' ||
                                   		             'AND B.USER_EENO = PG_COMMON.FU_RPAD(''' || P_USER_EENO || ''', 7) ' ||
										             'GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD ' ||
										            ') A,' ||
			  	                                   'TB_VEHL_MGMT B,' ||
						                           'TB_CODE_MGMT C,' ||
						                           'TB_CODE_MGMT D ' ||
					                          'WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD ' ||
					                          'AND A.MDL_MDY_CD = B.MDL_MDY_CD ' ||
					                          'AND B.DL_EXPD_CO_CD = C.DL_EXPD_PRVS_CD ' ||
			                                  'AND C.DL_EXPD_G_CD = ''0003'' ' ||
					                          'AND A.DL_EXPD_REGN_CD = D.DL_EXPD_PRVS_CD ' ||
			                                  'AND D.DL_EXPD_G_CD = ''0008'' ' ||
				                             ') A,' ||
				                            'TB_SEWHA_IV_INFO_DTL B ' ||
					                     'WHERE B.CLS_YMD = ''' || P_CURR_YMD || '''' ||
					                     'AND A.QLTY_VEHL_CD = B.QLTY_VEHL_CD ' ||
					                     'AND A.MDL_MDY_CD = B.MDL_MDY_CD ' ||
					                     'AND A.LANG_CD = B.LANG_CD ' ||
										 --'AND B.IV_QTY > 0 ' ||             -- 재고수량이 존재하는 데이터만을 조회한다. 
					                     'AND B.DL_EXPD_TMP_IV_QTY = 0 ' ||   --인쇄가 끝난것만을 가져온다.
				                        ') A,' ||
					                    'TB_SEWHA_WHOT_INFO B ' ||
					             'WHERE A.CLS_YMD = B.WHOT_YMD(+) ' ||
					             'AND A.QLTY_VEHL_CD = B.QLTY_VEHL_CD(+) ' ||
								 'AND A.MDL_MDY_CD = B.MDL_MDY_CD(+) ' || 
					             'AND A.LANG_CD = B.LANG_CD(+) ' ||
								 'AND A.DL_EXPD_MDL_MDY_CD = B.DL_EXPD_MDL_MDY_CD(+) ' ||
					             'AND A.N_PRNT_PBCN_NO = B.N_PRNT_PBCN_NO(+) ' ||
								 'AND B.DEL_YN(+) = ''N'' ' ||              --삭제되지 않은 내역만을 표시해 준다. 
								 'AND B.CMPL_YN(+) = ''N'' ' ||             --입고확인이 되지 않은 내역만을 표시해 준다.
				                ') A,' ||
				               --'TB_USR_MGMT B,' ||
				               'TB_CODE_MGMT C ' ||
					      'WHERE A.EXPD_RQ_SCN_CD = C.DL_EXPD_PRVS_CD(+) ' ||
					      'AND C.DL_EXPD_G_CD(+) = ''0012'' ' ||
						  --'AND A.PWTI_EENO = B.USER_EENO(+) ' ||
						  --'ORDER BY QLTY_VEHL_CD, LANG_CD, DL_EXPD_MDL_MDY_CD, N_PRNT_PBCN_NO ' || 
						  'ORDER BY QLTY_VEHL_CD, LANG_SORT_SN, MDL_MDY_CD, N_PRNT_PBCN_NO, DL_EXPD_MDL_MDY_CD ' ||
				         ')';
		 
		  OPEN RS FOR V_QUERY;
		 
		 /***  쿼리작성용 참고 쿼리
		 OPEN RS FOR
		 	  SELECT *
			  FROM (SELECT A.EXPD_CO_NM,
			  	   		   NVL(C.DL_EXPD_PRVS_NM, '') AS EXPD_RQ_SCN_NM, --요청구분
						   A.QLTY_VEHL_NM,
						   A.LANG_CD_NM,
						   A.N_PRNT_PBCN_NO,
						   A.IV_QTY,
						   A.RQ_QTY,
						   A.EXPD_BOX_QTY,
						   A.DLVG_PARR_YMD,
						   A.DLVG_PARR_HHMM,
						   NVL(B.USER_NM, '') AS PWTI_NM, --인수자성명
						   NVL(B.USER_TN, '') AS PWTI_TN, --인수자전화번호
						   A.PRTL_IMTR_SBC,
						   A.QLTY_VEHL_CD,
						   A.MDL_MDY_CD,
						   A.DL_EXPD_MDL_MDY_CD,
						   A.LANG_CD,
						   A.DTL_SN,         --출고요청일련번호 
						   A.EXPD_RQ_SCN_CD, --요청구분코드 
						   A.PWTI_EENO,      --인수자사원번호
						   A.CL_SCN_CD
			        FROM (SELECT A.QLTY_VEHL_CD,
								 A.MDL_MDY_CD,
						         A.DL_EXPD_MDL_MDY_CD,
						         A.LANG_CD,
						         A.N_PRNT_PBCN_NO,
						         A.IV_QTY,
						         A.EXPD_CO_CD,
						         A.EXPD_REGN_CD,
						         A.QLTY_VEHL_NM,
						         A.LANG_CD_NM,
						         A.EXPD_CO_NM,
						         NVL(B.RQ_QTY, 0) AS RQ_QTY,
						         NVL(B.DL_EXPD_BOX_QTY, 0) AS EXPD_BOX_QTY,
						         NVL(TO_CHAR(TO_DATE(B.DLVG_PARR_YMD, 'YYYYMMDD'), 'YYYY-MM-DD'), '') AS DLVG_PARR_YMD,
						         NVL(TO_CHAR(TO_DATE(B.DLVG_PARR_HHMM, 'HH24MI'), 'HH24:MI'), '') AS DLVG_PARR_HHMM,
						         NVL(B.PWTI_EENO, '') AS PWTI_EENO,
						         NVL(B.PRTL_IMTR_SBC, '') AS PRTL_IMTR_SBC,
								 NVL(B.DL_EXPD_RQ_SCN_CD, '') AS EXPD_RQ_SCN_CD,
								 NVL(B.DTL_SN, 0) AS DTL_SN,
								 --수정권한이 있는 차종이면서 또한 출고요청일이 현재일인 경우에만 수정할 수 있다.
						   		 CASE WHEN A.CL_SCN_CD = 'U' AND A.CLS_YMD = V_CURR_YMD THEN 'Y' 
							          ELSE 'N' END AS CL_SCN_CD
			             FROM (SELECT B.CLS_YMD,
			  	   		              A.QLTY_VEHL_CD,
									  A.MDL_MDY_CD,
						              A.DL_EXPD_MDL_MDY_CD,
						              A.LANG_CD,
						              B.N_PRNT_PBCN_NO,
						              B.IV_QTY,
						              A.EXPD_CO_CD,
						              A.EXPD_REGN_CD,
						              A.QLTY_VEHL_NM,
						              A.LANG_CD_NM,
						              A.EXPD_CO_NM,
									  A.CL_SCN_CD 
			                   FROM (SELECT A.QLTY_VEHL_CD,
			  	   		                    A.LANG_CD,
											A.MDL_MDY_CD,
						                    C.DL_EXPD_MDL_MDY_CD,
						                    B.DL_EXPD_CO_CD AS EXPD_CO_CD,
						                    A.DL_EXPD_REGN_CD AS EXPD_REGN_CD,
						                    '(' || B.QLTY_VEHL_CD || ')' || B.QLTY_VEHL_NM || '-' || B.MDL_MDY_CD || 'MY' AS QLTY_VEHL_NM,
						                    E.DL_EXPD_PRVS_NM || '-' || '(' || A.LANG_CD || ')' || A.LANG_CD_NM AS LANG_CD_NM,
						                    D.DL_EXPD_PRVS_NM AS EXPD_CO_NM,
											A.CL_SCN_CD
			                         FROM (SELECT A.QLTY_VEHL_CD,
									 	  		  A.MDL_MDY_CD,
												  A.LANG_CD,
												  MAX(A.LANG_CD_NM) AS LANG_CD_NM,
												  MAX(A.DL_EXPD_REGN_CD) AS DL_EXPD_REGN_CD,
												  MAX(B.CL_SCN_CD) AS CL_SCN_CD
									       FROM TB_LANG_MGMT A,
										        TB_AUTH_VEHL_MGMT B
										   WHERE A.DATA_SN IN (P_DATA_SN_LIST)
										   AND A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
										   AND B.MENU_ID = PG_COMMON.FU_RPAD(P_MENU_ID, 10)
                                   		   AND B.USER_EENO = PG_COMMON.FU_RPAD(P_USER_EENO, 7)
										   GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD
										  ) A,
			  	                          TB_VEHL_MGMT B,
			  	                          TB_DL_EXPD_MDY_MGMT C,
						                  TB_CODE_MGMT D,
						                  TB_CODE_MGMT E
				                     WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
					                 AND A.MDL_MDY_CD = B.MDL_MDY_CD
					                 AND A.QLTY_VEHL_CD = C.QLTY_VEHL_CD
					                 AND A.MDL_MDY_CD = C.MDL_MDY_CD
					                 AND B.DL_EXPD_CO_CD = D.DL_EXPD_PRVS_CD
			                         AND D.DL_EXPD_G_CD = '0003'
					                 AND A.DL_EXPD_REGN_CD = E.DL_EXPD_PRVS_CD
			                         AND E.DL_EXPD_G_CD = '0008'
				                    ) A,
				                    TB_SEWHA_IV_INFO B
					          WHERE B.CLS_YMD = P_CURR_YMD
					          AND A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
					          AND A.DL_EXPD_MDL_MDY_CD = B.DL_EXPD_MDL_MDY_CD
					          AND A.LANG_CD = B.LANG_CD
							  AND B.IV_QTY > 0 -- 재고수량이 존재하는 데이터만을 조회한다. 
					          AND B.DL_EXPD_TMP_IV_QTY = 0 --인쇄가 끝난것만을 가져온다.
				             ) A,
					         TB_SEWHA_WHOT_INFO B
					     WHERE A.CLS_YMD = B.WHOT_YMD(+)
					     AND A.QLTY_VEHL_CD = B.QLTY_VEHL_CD(+)
					     AND A.DL_EXPD_MDL_MDY_CD = B.DL_EXPD_MDL_MDY_CD(+)
					     AND A.LANG_CD = B.LANG_CD(+)
					     AND A.N_PRNT_PBCN_NO = B.N_PRNT_PBCN_NO(+)
						 AND B.DEL_YN(+) = 'N'   --삭제되지 않은 내역만을 표시해 준다.
						 AND B.CMPL_YN(+) = 'N'  --입고확인이 되지 않은 내역만을 표시해 준다.
				        ) A,
				        TB_USR_MGMT B,
				        TB_CODE_MGMT C
			        WHERE A.PWTI_EENO = B.USER_EENO(+)
					AND A.EXPD_RQ_SCN_CD = C.DL_EXPD_PRVS_CD(+)
					AND C.DL_EXPD_G_CD(+) = '0012'
				   );
			**/

	   END SP_GET_SEWHA_WHOT_INFO;
	   
	   --세화출고 현황 조회(EXCEL 전용)	   
	   PROCEDURE SP_GET_SEWHA_WHOT_INFO_EXCEL(P_MENU_ID 	        VARCHAR2,
								              P_USER_EENO           VARCHAR2,
			  						          P_DATA_SN_LIST        VARCHAR2,
										      P_N_PRNT_PBCN_NO_LIST VARCHAR2,
			  						          P_CURR_YMD            VARCHAR2,
			  						          RS OUT REFCUR)
	   IS
	     
		 V_CURR_YMD VARCHAR2(8);
		 
		 V_QUERY    VARCHAR2(8000);
		 
	   BEGIN
	   	 
		 	V_CURR_YMD := TO_CHAR(SYSDATE, 'YYYYMMDD');
			
			V_QUERY := 'SELECT * ' ||
			           'FROM (SELECT A.EXPD_CO_NM,' ||
			  	   		            'NVL(C.DL_EXPD_PRVS_NM, '''') AS EXPD_RQ_SCN_NM,' || --요청구분
						            'A.QLTY_VEHL_NM,'||
						            'A.LANG_CD_NM,' ||
						            'A.N_PRNT_PBCN_NO,' ||
						            'A.IV_QTY,' ||
						            'A.RQ_QTY,' ||
						            'A.EXPD_BOX_QTY,' ||
						            'A.DLVG_PARR_YMD,' ||
						            'A.DLVG_PARR_HHMM,' ||
						            --'B.USER_NM AS PWTI_NM,' ||                           --인수자성명 
									'A.PWTI_NM,' ||
						            --'B.USER_TN AS PWTI_TN,' ||                           --인수자전화번호
									''''' AS PWTI_TN,' ||
						  		    'A.PRTL_IMTR_SBC,' ||
						  		    'A.QLTY_VEHL_CD,' ||
								    'A.MDL_MDY_CD,' ||
						  		    'A.DL_EXPD_MDL_MDY_CD,' ||
						  		    'A.LANG_CD,' ||
						  		    'A.DTL_SN,' ||                                       --출고요청일련번호 
						  		    'A.EXPD_RQ_SCN_CD,' ||                               --요청구분코드 
						  		    'A.PWTI_EENO,' ||                                    --인수자사원번호 
								    'A.CL_SCN_CD ' ||
			                'FROM (SELECT A.QLTY_VEHL_CD,' ||
									     'A.MDL_MDY_CD,' ||
						                 'A.LANG_CD,' ||
										 'A.DL_EXPD_MDL_MDY_CD,' ||
						                 'A.N_PRNT_PBCN_NO,' ||
						                 'A.IV_QTY,' ||
						                 'A.EXPD_CO_CD,' ||
						                 'A.EXPD_REGN_CD,' ||
						                 'A.QLTY_VEHL_NM,' ||
						                 'A.LANG_CD_NM,' ||
						                 'A.EXPD_CO_NM,' ||
										 'A.LANG_SORT_SN,' ||
						                 'B.RQ_QTY,' ||
						                 'B.DL_EXPD_BOX_QTY AS EXPD_BOX_QTY,' ||
						                 'TO_CHAR(TO_DATE(B.DLVG_PARR_YMD, ''YYYYMMDD''), ''YYYY-MM-DD'') AS DLVG_PARR_YMD,' ||
						                 'TO_CHAR(TO_DATE(B.DLVG_PARR_HHMM, ''HH24MI''), ''HH24:MI'') AS DLVG_PARR_HHMM,' ||
						                 'B.PWTI_EENO,' ||
										 'B.PWTI_NM,' ||
						                 'B.PRTL_IMTR_SBC,' ||
								         'B.DL_EXPD_RQ_SCN_CD AS EXPD_RQ_SCN_CD,' ||
								         'B.DTL_SN,' ||
									     --'CASE WHEN A.CL_SCN_CD = ''U'' AND A.CLS_YMD = ''' || V_CURR_YMD || ''' THEN ''Y'' ' || 
							             --     'ELSE ''N'' END AS CL_SCN_CD ' ||  
										 --[변경] 입고확인이 되지 않은 데이터는 수정권한이 있으면 계속 수정할 수 있다.
										 --(삭제 기능 추가로 인하여 아래와 같이 수정한 것임) 
										 'CASE WHEN A.CL_SCN_CD = ''U'' THEN ''Y'' ' || 
							                  'ELSE ''N'' END AS CL_SCN_CD ' ||
			                      'FROM (SELECT B.CLS_YMD,' ||
			  	   		                       'A.QLTY_VEHL_CD,' ||
											   'A.MDL_MDY_CD,' ||
						                       'A.LANG_CD,' ||
											   'B.DL_EXPD_MDL_MDY_CD,' ||
						                       'B.N_PRNT_PBCN_NO,' ||
						                       'B.IV_QTY,' ||
						                       'A.EXPD_CO_CD,' ||
						                       'A.EXPD_REGN_CD,' ||
						                       'A.QLTY_VEHL_NM,' ||
						                       'A.LANG_CD_NM,' ||
						                       'A.EXPD_CO_NM, ' ||
											   'A.CL_SCN_CD,' ||
											   'A.LANG_SORT_SN ' ||
			                             'FROM (SELECT A.QLTY_VEHL_CD,' ||
			  	   		                              'A.LANG_CD,' ||
													  'A.MDL_MDY_CD,' ||
						                              'B.DL_EXPD_CO_CD AS EXPD_CO_CD,' ||
						                              'A.DL_EXPD_REGN_CD AS EXPD_REGN_CD,' ||
						                            --'''('' || B.QLTY_VEHL_CD || '')'' || B.QLTY_VEHL_NM || ''-'' || B.MDL_MDY_CD || ''MY'' AS QLTY_VEHL_NM,' ||
													'''('' || B.QLTY_VEHL_CD || ''-'' || B.MDL_MDY_CD || '')'' || B.QLTY_VEHL_NM AS QLTY_VEHL_NM,' ||
						                              --'D.DL_EXPD_PRVS_NM || ''-'' || ''('' || A.LANG_CD || '')'' || A.LANG_CD_NM AS LANG_CD_NM,' ||
													  'CASE WHEN A.A_CODE IS NULL THEN ''('' || A.LANG_CD || '')'' ' ||
									                       'ELSE ''('' || A.LANG_CD || ''-'' || A.A_CODE || '')'' ' || 
								    			      'END || A.LANG_CD_NM AS LANG_CD_NM,' ||	
						                              'C.DL_EXPD_PRVS_NM AS EXPD_CO_NM, ' ||
													  'A.LANG_SORT_SN,' ||
													  'A.CL_SCN_CD ' ||
			                                   'FROM (SELECT A.QLTY_VEHL_CD,' ||
									 	  		            'A.MDL_MDY_CD,' ||
												            'A.LANG_CD,' ||
												            'MAX(A.LANG_CD_NM) AS LANG_CD_NM,' ||
												            'MAX(A.DL_EXPD_REGN_CD) AS DL_EXPD_REGN_CD,' ||
															'MAX(A.A_CODE) AS A_CODE,' ||
															'MAX(A.SORT_SN) AS LANG_SORT_SN,' ||
												            'MAX(B.CL_SCN_CD) AS CL_SCN_CD ' ||
									                 'FROM TB_LANG_MGMT A,' ||
										                  'TB_AUTH_VEHL_MGMT B ' ||
										             'WHERE A.DATA_SN IN (' || P_DATA_SN_LIST || ') ' ||
										             'AND A.QLTY_VEHL_CD = B.QLTY_VEHL_CD ' ||
										             'AND B.MENU_ID = PG_COMMON.FU_RPAD(''' || P_MENU_ID || ''', 10) ' ||
                                   		             'AND B.USER_EENO = PG_COMMON.FU_RPAD(''' || P_USER_EENO || ''', 7) ' ||
										             'GROUP BY A.QLTY_VEHL_CD, A.MDL_MDY_CD, A.LANG_CD ' ||
										            ') A,' ||
			  	                                    'TB_VEHL_MGMT B,' ||
						                            'TB_CODE_MGMT C,' ||
						                            'TB_CODE_MGMT D ' ||
					                           'WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD ' ||
					                           'AND A.MDL_MDY_CD = B.MDL_MDY_CD ' ||
					                           'AND B.DL_EXPD_CO_CD = C.DL_EXPD_PRVS_CD ' ||
			                                   'AND C.DL_EXPD_G_CD = ''0003'' ' ||
					                           'AND A.DL_EXPD_REGN_CD = D.DL_EXPD_PRVS_CD ' ||
			                                   'AND D.DL_EXPD_G_CD = ''0008'' ' ||
				                              ') A,' ||
				                              'TB_SEWHA_IV_INFO_DTL B ' ||
					                      'WHERE B.CLS_YMD = ''' || P_CURR_YMD || '''' ||
					                      'AND A.QLTY_VEHL_CD = B.QLTY_VEHL_CD ' ||
					                      'AND A.MDL_MDY_CD = B.MDL_MDY_CD ' ||
					                      'AND A.LANG_CD = B.LANG_CD ' ||
										  'AND B.N_PRNT_PBCN_NO IN (' || P_N_PRNT_PBCN_NO_LIST || ') ' ||
										  --'AND B.IV_QTY > 0 ' ||              -- 재고수량이 존재하는 데이터만을 조회한다. 
					                      'AND B.DL_EXPD_TMP_IV_QTY = 0 ' ||  --인쇄가 끝난것만을 가져온다.
				                         ') A,' ||
					                     'TB_SEWHA_WHOT_INFO B ' ||
					              'WHERE A.CLS_YMD = B.WHOT_YMD ' ||
					              'AND A.QLTY_VEHL_CD = B.QLTY_VEHL_CD ' ||
								  'AND A.MDL_MDY_CD = B.MDL_MDY_CD ' ||
					              'AND A.LANG_CD = B.LANG_CD ' ||
								  'AND A.DL_EXPD_MDL_MDY_CD = B.DL_EXPD_MDL_MDY_CD ' ||
					              'AND A.N_PRNT_PBCN_NO = B.N_PRNT_PBCN_NO ' ||
								  'AND B.DEL_YN = ''N'' ' ||                   --삭제되지 않은 내역만을 조회한다. 
								  'AND B.CMPL_YN = ''N'' ' ||                  --입고확인이 되지 않은 내역만을 조회한다.
				                 ') A,' ||
				                 --'TB_USR_MGMT B,' ||
				                 'TB_CODE_MGMT C ' ||
					       'WHERE A.EXPD_RQ_SCN_CD = C.DL_EXPD_PRVS_CD ' ||
					       'AND C.DL_EXPD_G_CD = ''0012'' ' ||
						   --'AND A.PWTI_EENO = B.USER_EENO ' ||
						   --'ORDER BY QLTY_VEHL_CD, LANG_CD, DL_EXPD_MDL_MDY_CD, N_PRNT_PBCN_NO ' || 
						   'ORDER BY QLTY_VEHL_CD, LANG_SORT_SN, MDL_MDY_CD, N_PRNT_PBCN_NO, DL_EXPD_MDL_MDY_CD ' ||
				          ')';
		 
		  OPEN RS FOR V_QUERY;
	   
	   END SP_GET_SEWHA_WHOT_INFO_EXCEL;
	   
	   --세화출고 현황 조회2								   
	   PROCEDURE SP_GET_SEWHA_WHOT_INFO2(P_MENU_ID 	 VARCHAR2,
								         P_USER_EENO VARCHAR2,
									     P_CURR_YMD  VARCHAR2,
			  						     P_PDI_CD    VARCHAR2,
									     P_VEHL_CD   VARCHAR2,
									     P_MDL_MDY	 VARCHAR2,
									     P_REGN_CD	 VARCHAR2,
								         P_LANG_CD	 VARCHAR2,
			  						     RS OUT REFCUR)
	   IS
	   	 
		 V_FROM_MDL_MDY VARCHAR2(2);
		 V_TO_MDL_MDY   VARCHAR2(2);
		 
		 V_CURR_YMD     VARCHAR2(8);
		 
	   BEGIN
	   		
			V_CURR_YMD := TO_CHAR(SYSDATE, 'YYYYMMDD');
			
			PG_COMMON.SP_GET_VALID_MDL_MDY4(P_CURR_YMD, '', V_FROM_MDL_MDY, V_TO_MDL_MDY);
			
			OPEN RS FOR
				 WITH T AS (SELECT A.QLTY_VEHL_CD,
			  	   		           A.LANG_CD,
								   A.MDL_MDY_CD,
						           A.DL_EXPD_CO_CD AS EXPD_CO_CD,
						           A.DL_EXPD_REGN_CD AS EXPD_REGN_CD,
						           '(' || A.QLTY_VEHL_CD || '-' || A.MDL_MDY_CD || ')' || A.QLTY_VEHL_NM AS QLTY_VEHL_NM,
						           --C.DL_EXPD_PRVS_NM || '-' || '(' || A.LANG_CD || ')' || A.LANG_CD_NM AS LANG_CD_NM,
								   CASE WHEN A.A_CODE IS NULL THEN '(' || A.LANG_CD || ')'
									    ELSE '(' || A.LANG_CD || '-' || A.A_CODE || ')' 
								   END || A.LANG_CD_NM AS LANG_CD_NM,
						           B.DL_EXPD_PRVS_NM AS EXPD_CO_NM,
								   A.LANG_SORT_SN,
								   A.CL_SCN_CD
			                FROM (SELECT C.QLTY_VEHL_CD,
									 	 C.MDL_MDY_CD,
										 C.LANG_CD,
									     C.LANG_CD_NM,
										 C.A_CODE,
										 C.SORT_SN AS LANG_SORT_SN,
										 C.DL_EXPD_REGN_CD,
										 B.DL_EXPD_CO_CD,
										 B.QLTY_VEHL_NM,
										 A.CL_SCN_CD
								  FROM (SELECT QLTY_VEHL_CD,
                                               MAX(CL_SCN_CD) AS CL_SCN_CD
                                        FROM TB_AUTH_VEHL_MGMT
                                        WHERE MENU_ID = PG_COMMON.FU_RPAD(P_MENU_ID, 10)
                                        AND USER_EENO = PG_COMMON.FU_RPAD(P_USER_EENO, 7)
                                        AND QLTY_VEHL_CD = DECODE(P_VEHL_CD, 'ALL', QLTY_VEHL_CD, P_VEHL_CD)
                                        GROUP BY QLTY_VEHL_CD
                                       ) A,
									   TB_VEHL_MGMT B,
                                  	   TB_LANG_MGMT C
								  WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
								  AND A.QLTY_VEHL_CD = C.QLTY_VEHL_CD
								  AND B.MDL_MDY_CD = C.MDL_MDY_CD
								  AND B.MDL_MDY_CD BETWEEN V_FROM_MDL_MDY AND V_TO_MDL_MDY
								  AND B.MDL_MDY_CD = DECODE(P_MDL_MDY , '', B.MDL_MDY_CD, P_MDL_MDY)
								  --AND B.DL_EXPD_PAC_SCN_CD = DECODE(P_PAC_SCN_CD, 'ALL', B.DL_EXPD_PAC_SCN_CD, P_PAC_SCN_CD) 
								  AND B.DL_EXPD_PDI_CD = DECODE(P_PDI_CD, 'ALL', B.DL_EXPD_PDI_CD, P_PDI_CD)
								  AND C.DL_EXPD_REGN_CD = DECODE(P_REGN_CD, 'ALL', C.DL_EXPD_REGN_CD, P_REGN_CD)
								  AND C.LANG_CD = DECODE(P_LANG_CD, 'ALL', C.LANG_CD, P_LANG_CD)
								  AND B.USE_YN = 'Y'
								  AND C.USE_YN = 'Y'
							     ) A,
						         TB_CODE_MGMT B,
						         TB_CODE_MGMT C
							WHERE A.DL_EXPD_CO_CD = B.DL_EXPD_PRVS_CD
							AND B.DL_EXPD_G_CD = '0003'
							AND A.DL_EXPD_REGN_CD = C.DL_EXPD_PRVS_CD
							AND C.DL_EXPD_G_CD = '0008'
                           )
				 SELECT *
			  	 FROM (SELECT A.EXPD_CO_NM,
			  	   		   	  NVL(C.DL_EXPD_PRVS_NM, '') AS EXPD_RQ_SCN_NM, --요청구분
						      A.QLTY_VEHL_NM,
						      A.LANG_CD_NM,
						      A.N_PRNT_PBCN_NO,
						      A.IV_QTY,
						      A.RQ_QTY,
						      A.EXPD_BOX_QTY,
						      A.DLVG_PARR_YMD,
						      A.DLVG_PARR_HHMM,
						      --NVL(B.USER_NM, '') AS PWTI_NM, --인수자성명
							  NVL(A.PWTI_NM, '') AS PWTI_NM,
						      --NVL(B.USER_TN, '') AS PWTI_TN, --인수자전화번호
							  '' AS PWTI_TN,
						      A.PRTL_IMTR_SBC,
						      A.QLTY_VEHL_CD,
						      A.MDL_MDY_CD,
						      A.DL_EXPD_MDL_MDY_CD,
						      A.LANG_CD,
						      A.DTL_SN,         --출고요청일련번호 
						      A.EXPD_RQ_SCN_CD, --요청구분코드 
						      A.PWTI_EENO,      --인수자사원번호
						      A.CL_SCN_CD
			           FROM (SELECT A.QLTY_VEHL_CD,
								    A.MDL_MDY_CD,
						            A.DL_EXPD_MDL_MDY_CD,
						            A.LANG_CD,
						            A.N_PRNT_PBCN_NO,
						            B.IV_QTY,
						            A.EXPD_CO_CD,
						            A.EXPD_REGN_CD,
						            A.QLTY_VEHL_NM,
						            A.LANG_CD_NM,
						            A.EXPD_CO_NM,
									A.LANG_SORT_SN,
						            A.RQ_QTY,
						            A.EXPD_BOX_QTY,
						            A.DLVG_PARR_YMD,
						            A.DLVG_PARR_HHMM,
						         	A.PWTI_EENO,
									A.PWTI_NM,
						         	A.PRTL_IMTR_SBC,
								    A.EXPD_RQ_SCN_CD,
								 	A.DTL_SN,
								    --수정권한이 있는 차종이면서 또한 출고요청일이 현재일인 경우에만 수정할 수 있다.
						   		    --CASE WHEN A.CL_SCN_CD = 'U' AND B.CLS_YMD = V_CURR_YMD THEN 'Y' 
							        --     ELSE 'N' 
								    --END AS CL_SCN_CD  
									--[변경] 입고확인이 되지 않은 데이터는 수정권한이 있으면 계속 수정할 수 있다.
									--(삭제 기능 추가로 인하여 아래와 같이 수정한 것임) 
									CASE WHEN A.CL_SCN_CD = 'U' AND A.CMPL_YN = 'N' THEN 'Y' 
							             ELSE 'N' 
								    END AS CL_SCN_CD
					   		 FROM (SELECT B.WHOT_YMD,
			  	   		                  A.QLTY_VEHL_CD,
									      A.MDL_MDY_CD,
						                  B.DL_EXPD_MDL_MDY_CD,
						                  A.LANG_CD,
						                  B.N_PRNT_PBCN_NO,
						                  B.RQ_QTY,
										  B.DL_EXPD_BOX_QTY AS EXPD_BOX_QTY,
						            	  TO_CHAR(TO_DATE(B.DLVG_PARR_YMD, 'YYYYMMDD'), 'YYYY-MM-DD') AS DLVG_PARR_YMD,
						            	  TO_CHAR(TO_DATE(B.DLVG_PARR_HHMM, 'HH24MI'), 'HH24:MI') AS DLVG_PARR_HHMM,
						         		  B.PWTI_EENO,
										  B.PWTI_NM,
						         		  B.PRTL_IMTR_SBC,
								    	  B.DL_EXPD_RQ_SCN_CD AS EXPD_RQ_SCN_CD,
								 		  B.DTL_SN,
						                  A.EXPD_CO_CD,
						                  A.EXPD_REGN_CD,
						                  A.QLTY_VEHL_NM,
						                  A.LANG_CD_NM,
						                  A.EXPD_CO_NM,
									      A.LANG_SORT_SN,
									      A.CL_SCN_CD,
										  B.CMPL_YN 
							       FROM T A,
								   		TB_SEWHA_WHOT_INFO B
								   WHERE B.WHOT_YMD = P_CURR_YMD
								   AND A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
					               AND A.MDL_MDY_CD = B.MDL_MDY_CD
					               AND A.LANG_CD = B.LANG_CD
								   AND B.DEL_YN = 'N' --삭제가 되지 않은 항목만을 표시해 준다. 
							 	  ) A,
								  TB_SEWHA_IV_INFO_DTL B
							 WHERE A.WHOT_YMD = B.CLS_YMD
					         AND A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
					         AND A.MDL_MDY_CD = B.MDL_MDY_CD
					         AND A.LANG_CD = B.LANG_CD
							 AND A.DL_EXPD_MDL_MDY_CD = B.DL_EXPD_MDL_MDY_CD
							 AND A.N_PRNT_PBCN_NO = B.N_PRNT_PBCN_NO
							 --AND B.IV_QTY > 0 	       -- 재고수량이 존재하는 데이터만을 조회한다. 
					         AND B.DL_EXPD_TMP_IV_QTY = 0 --인쇄가 끝난것만을 가져온다.
							 
					         /***  테이블 조회 순서 변경 
							 SELECT A.QLTY_VEHL_CD,
								    A.MDL_MDY_CD,
						            A.DL_EXPD_MDL_MDY_CD,
						            A.LANG_CD,
						            A.N_PRNT_PBCN_NO,
						            A.IV_QTY,
						            A.EXPD_CO_CD,
						            A.EXPD_REGN_CD,
						            A.QLTY_VEHL_NM,
						            A.LANG_CD_NM,
						            A.EXPD_CO_NM,
									A.LANG_SORT_SN,
						            B.RQ_QTY,
						            B.DL_EXPD_BOX_QTY AS EXPD_BOX_QTY,
						            TO_CHAR(TO_DATE(B.DLVG_PARR_YMD, 'YYYYMMDD'), 'YYYY-MM-DD') AS DLVG_PARR_YMD,
						            TO_CHAR(TO_DATE(B.DLVG_PARR_HHMM, 'HH24MI'), 'HH24:MI') AS DLVG_PARR_HHMM,
						         	B.PWTI_EENO,
									B.PWTI_NM,
						         	B.PRTL_IMTR_SBC,
								    B.DL_EXPD_RQ_SCN_CD AS EXPD_RQ_SCN_CD,
								 	B.DTL_SN,
								    --수정권한이 있는 차종이면서 또한 출고요청일이 현재일인 경우에만 수정할 수 있다.
						   		    --CASE WHEN A.CL_SCN_CD = 'U' AND A.CLS_YMD = V_CURR_YMD THEN 'Y' 
							        --     ELSE 'N' 
								    --END AS CL_SCN_CD  
									--[변경] 입고확인이 되지 않은 데이터는 수정권한이 있으면 계속 수정할 수 있다.
									--(삭제 기능 추가로 인하여 아래와 같이 수정한 것임) 
									CASE WHEN A.CL_SCN_CD = 'U' AND B.CMPL_YN = 'N' THEN 'Y' 
							             ELSE 'N' 
								    END AS CL_SCN_CD
			                 FROM (SELECT B.CLS_YMD,
			  	   		                  A.QLTY_VEHL_CD,
									      A.MDL_MDY_CD,
						                  B.DL_EXPD_MDL_MDY_CD,
						                  A.LANG_CD,
						                  B.N_PRNT_PBCN_NO,
						                  B.IV_QTY,
						                  A.EXPD_CO_CD,
						                  A.EXPD_REGN_CD,
						                  A.QLTY_VEHL_NM,
						                  A.LANG_CD_NM,
						                  A.EXPD_CO_NM,
									      A.LANG_SORT_SN,
									      A.CL_SCN_CD 
			                       FROM T A,
				                        TB_SEWHA_IV_INFO_DTL B
					               WHERE B.CLS_YMD = P_CURR_YMD
					               AND A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
					               AND A.MDL_MDY_CD = B.MDL_MDY_CD
					               AND A.LANG_CD = B.LANG_CD
							       --AND B.IV_QTY > 0 	       -- 재고수량이 존재하는 데이터만을 조회한다. 
					               AND B.DL_EXPD_TMP_IV_QTY = 0 --인쇄가 끝난것만을 가져온다.
				                  ) A,
					              TB_SEWHA_WHOT_INFO B
					         WHERE A.CLS_YMD = B.WHOT_YMD
					         AND A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
					         AND A.DL_EXPD_MDL_MDY_CD = B.DL_EXPD_MDL_MDY_CD
					         AND A.LANG_CD = B.LANG_CD
					         AND A.N_PRNT_PBCN_NO = B.N_PRNT_PBCN_NO
						     AND A.MDL_MDY_CD = B.MDL_MDY_CD					 
						     AND B.DEL_YN = 'N' --삭제가 되지 않은 항목만을 표시해 준다. 
							 ***/
							 
				            ) A,
				            --TB_USR_MGMT B,
				            TB_CODE_MGMT C
					   WHERE A.EXPD_RQ_SCN_CD = C.DL_EXPD_PRVS_CD(+)
					   AND C.DL_EXPD_G_CD(+) = '0012'
					   --AND A.PWTI_EENO = B.USER_EENO(+)
					   --ORDER BY QLTY_VEHL_CD, LANG_CD, DL_EXPD_MDL_MDY_CD, N_PRNT_PBCN_NO
					   ORDER BY QLTY_VEHL_CD, LANG_SORT_SN, DL_EXPD_MDL_MDY_CD, N_PRNT_PBCN_NO
				      );
				 
	   END SP_GET_SEWHA_WHOT_INFO2;
									  							   
	   --세화출고 현황 저장 
	   PROCEDURE SP_SEWHA_WHOT_INFO_SAVE(P_VEHL_CD         VARCHAR2,
	   			 						 P_MDL_MDY_CD	   VARCHAR2,
										 P_LANG_CD         VARCHAR2,
										 P_EXPD_MDL_MDY_CD VARCHAR2,
										 P_N_PRNT_PBCN_NO  VARCHAR2,
										 P_DTL_SN          NUMBER,
										 P_EXPD_RQ_SCN_CD  VARCHAR2,
										 P_RQ_QTY          NUMBER,
										 P_EXPD_BOX_QTY    NUMBER,
										 P_DLVG_PARR_YMD   VARCHAR2,
										 P_DLVG_PARR_HHMM  VARCHAR2,
										 P_PWTI_EENO       VARCHAR2,
										 P_PRTL_IMTR_SBC   VARCHAR2,
										 P_CLS_YMD		   VARCHAR2, 
										 P_USER_EENO       VARCHAR2
										 ,P_PRDN_PLNT_CD   VARCHAR2
										 )
	   IS
	   	 
		 V_CURR_YMD VARCHAR2(8);
		 
		 V_DTL_SN	NUMBER;
		  
		 V_PREV_RQ_QTY NUMBER;
		 V_DIFF_RQ_QTY NUMBER;
		 
--		 V_CMPL_YN  VARCHAR2(1);
		 
		 V_PREV_WHOT_YMD VARCHAR2(8);

	   BEGIN
	   		
			--V_CURR_YMD := TO_CHAR(SYSDATE, 'YYYYMMDD');
			V_CURR_YMD := P_CLS_YMD;
			
			V_DTL_SN   := P_DTL_SN;
			
			/**
			--현재 입력일이 SYSTEMDATE 가 아니라면 입력하지 못하도록 한다. 
			IF V_CURR_YMD <> P_CLS_YMD THEN
			   	
				RETURN;
				
			END IF;
			**/
			
			--별도요청의 경우에는 바로 재고에서 빼주도록 한다.
			IF P_EXPD_RQ_SCN_CD = '02' THEN
			   
			   --출고요청된 항목에 대한 수정인 경우 
			   SELECT SUM(RQ_QTY)
		   	   INTO V_PREV_RQ_QTY
		   	   FROM TB_SEWHA_WHOT_INFO
			   WHERE QLTY_VEHL_CD = P_VEHL_CD
			   AND MDL_MDY_CD = P_MDL_MDY_CD
		       AND LANG_CD = P_LANG_CD
			   AND DL_EXPD_MDL_MDY_CD = P_EXPD_MDL_MDY_CD
		       AND N_PRNT_PBCN_NO = P_N_PRNT_PBCN_NO
		       AND DTL_SN = V_DTL_SN
			   AND DL_EXPD_RQ_SCN_CD = P_EXPD_RQ_SCN_CD; --원래 별도요청이었는지의 여부도 같이 확인하여 준다. 
		   	   
			   --별도요청 출고정보 수정작업을 위해서 이전 요청수량이 없으면 반드시 NULL 이어야 한다. 
			   IF V_PREV_RQ_QTY IS NULL THEN 
			  	 
				  V_DIFF_RQ_QTY := P_RQ_QTY;
				  
			   ELSE
			      
				  V_DIFF_RQ_QTY := P_RQ_QTY - V_PREV_RQ_QTY;
				  
			   END IF;
			   
			   PG_DATA.SP_SEWHA_IV_INFO_UPDATE(P_VEHL_CD,
			                                   P_MDL_MDY_CD,  
									           P_LANG_CD, 
											   P_EXPD_MDL_MDY_CD,
			   						           P_N_PRNT_PBCN_NO, 
									           V_CURR_YMD, 
									   		   V_DIFF_RQ_QTY, 
									   		   P_USER_EENO,
									   		   'N'
									   		   , NULL    -- 광주분리 일단, 프로그램
									   		   );  
			   
			   --별도 요청정보 업데이트 
			   PG_TOT_IV_INFO.SP_EXTRA_REQ_UPDATE(P_VEHL_CD, 
			   						              P_MDL_MDY_CD, 
									              P_LANG_CD, 
			   						              P_N_PRNT_PBCN_NO,
												  '03',
												  P_RQ_QTY,
												  V_PREV_RQ_QTY, -- 이전 요청수량이 없으면 반드시 NULL로 넘겨주어야 한다. 
												  P_USER_EENO
												  ,P_PRDN_PLNT_CD
												  );
												  
			ELSE
				
				SELECT MAX(WHOT_YMD)
				INTO V_PREV_WHOT_YMD
		    	FROM TB_SEWHA_WHOT_INFO
				WHERE QLTY_VEHL_CD = P_VEHL_CD
				AND MDL_MDY_CD = P_MDL_MDY_CD
		    	AND LANG_CD = P_LANG_CD
				AND DL_EXPD_MDL_MDY_CD = P_EXPD_MDL_MDY_CD
		    	AND N_PRNT_PBCN_NO = P_N_PRNT_PBCN_NO
		    	AND DTL_SN = V_DTL_SN;
				
				--이전의 요청일자와 현재의 요청일자가 다른 경우에는 
				--신규입력되도록 처리한다. 
				IF V_PREV_WHOT_YMD IS NOT NULL AND
				   V_CURR_YMD <> V_PREV_WHOT_YMD THEN
				   	
					V_DTL_SN := NULL;
					
				END IF;
				
			END IF;
			
			UPDATE TB_SEWHA_WHOT_INFO
		    SET WHOT_YMD = V_CURR_YMD,
			    DL_EXPD_RQ_SCN_CD = P_EXPD_RQ_SCN_CD,
			    DLVG_PARR_YMD = P_DLVG_PARR_YMD,
			    DLVG_PARR_HHMM = P_DLVG_PARR_HHMM,
			    RQ_QTY = P_RQ_QTY,
			    PWTI_NM = P_PWTI_EENO,
			    PRTL_IMTR_SBC = P_PRTL_IMTR_SBC,
			    CRGR_EENO = P_USER_EENO,
			    DL_EXPD_BOX_QTY = P_EXPD_BOX_QTY,
			    --별도출고일 경우에는 바로 입고확인된 것으로 처리해 준다.
			    CMPL_YN = CASE WHEN P_EXPD_RQ_SCN_CD = '02' THEN 'Y' ELSE 'N' END,
			    WHSN_YMD = CASE WHEN P_EXPD_RQ_SCN_CD = '02' THEN V_CURR_YMD ELSE '99991231' END,
			    UPDR_EENO = P_USER_EENO,
			    MDFY_DTM = SYSDATE,
				DEL_YN = 'N'
	        WHERE QLTY_VEHL_CD = P_VEHL_CD
			AND MDL_MDY_CD = P_MDL_MDY_CD
		    AND LANG_CD = P_LANG_CD
			AND DL_EXPD_MDL_MDY_CD = P_EXPD_MDL_MDY_CD
		    AND N_PRNT_PBCN_NO = P_N_PRNT_PBCN_NO
		    AND DTL_SN = V_DTL_SN
		    --입고확인 처리되지 않은 항목만을 업데이트 해준다. 
		    --별도요청의 경우에는 무조건 해당 항목을 업데이트 해준다.
		    AND CMPL_YN = CASE WHEN (DL_EXPD_RQ_SCN_CD = '02' AND P_EXPD_RQ_SCN_CD = '02') THEN CMPL_YN ELSE 'N' END; 
			
			--수정된 항목이 없다면 Insert 해준다. 
		    IF SQL%NOTFOUND THEN
		   	  
			  INSERT INTO TB_SEWHA_WHOT_INFO
   			  (QLTY_VEHL_CD,
   			   DL_EXPD_MDL_MDY_CD,
   			   LANG_CD,
   			   N_PRNT_PBCN_NO,
   			   DTL_SN,
   			   WHOT_YMD,
   			   DL_EXPD_RQ_SCN_CD,
   			   DLVG_PARR_YMD,
   			   DLVG_PARR_HHMM,
   			   RQ_QTY,
   			   PWTI_NM,
   			   PRTL_IMTR_SBC,
   			   CRGR_EENO,
   			   DL_EXPD_BOX_QTY,
   			   CMPL_YN,
   			   WHSN_YMD,
   			   PPRR_EENO,
   			   FRAM_DTM,
   			   UPDR_EENO,
   			   MDFY_DTM,
			   DEL_YN,
			   MDL_MDY_CD
   			  )
   			  SELECT P_VEHL_CD,
   			         P_EXPD_MDL_MDY_CD,
   					 P_LANG_CD,
   					 P_N_PRNT_PBCN_NO,
   					 NVL(MAX(DTL_SN), 0) + 1,
   		             V_CURR_YMD,
   					 P_EXPD_RQ_SCN_CD,
   					 P_DLVG_PARR_YMD,
   					 P_DLVG_PARR_HHMM,
   					 P_RQ_QTY,
   					 P_PWTI_EENO,
   					 P_PRTL_IMTR_SBC,
   					 P_USER_EENO,
   					 P_EXPD_BOX_QTY,
   					 --별도출고일 경우에는 바로 입고확인된 것으로 처리해 준다.
   					 CASE WHEN P_EXPD_RQ_SCN_CD = '02' THEN 'Y' ELSE 'N' END,
   					 CASE WHEN P_EXPD_RQ_SCN_CD = '02' THEN V_CURR_YMD ELSE '99991231' END,
   					 P_USER_EENO,
   					 SYSDATE,
   					 P_USER_EENO,
   					 SYSDATE,
					 'N',
					 P_MDL_MDY_CD
   			  FROM TB_SEWHA_WHOT_INFO
   			  WHERE QLTY_VEHL_CD = P_VEHL_CD
   			  AND DL_EXPD_MDL_MDY_CD = P_EXPD_MDL_MDY_CD
   			  AND LANG_CD = P_LANG_CD
   			  AND N_PRNT_PBCN_NO = P_N_PRNT_PBCN_NO;
		  
		   END IF;

	   END SP_SEWHA_WHOT_INFO_SAVE;
	   
	   		  
	   --입고확인시에 세화 출고내역에서 입고확인상태로 변경하는 작업 수행
	   PROCEDURE SP_SEWHA_WHOT_INFO_UPDATE(P_VEHL_CD         VARCHAR2,
	                                       P_MDL_MDY_CD	     VARCHAR2,
									       P_LANG_CD         VARCHAR2,
										   P_EXPD_MDL_MDY_CD VARCHAR2,
									       P_N_PRNT_PBCN_NO  VARCHAR2,
										   P_DTL_SN		     NUMBER,
										   P_WHSN_YMD		 VARCHAR2,
										   P_RQ_QTY			 NUMBER,
										   P_USER_EENO		 VARCHAR2)
	   IS
	   BEGIN
	   		
	   		UPDATE TB_SEWHA_WHOT_INFO
			SET RQ_QTY = P_RQ_QTY,
				CMPL_YN = 'Y',
				WHSN_YMD = P_WHSN_YMD,
				UPDR_EENO = P_USER_EENO,
				MDFY_DTM = SYSDATE
		    WHERE QLTY_VEHL_CD = P_VEHL_CD
			AND MDL_MDY_CD = P_MDL_MDY_CD
			AND LANG_CD = P_LANG_CD
			AND DL_EXPD_MDL_MDY_CD = P_EXPD_MDL_MDY_CD
			AND N_PRNT_PBCN_NO = P_N_PRNT_PBCN_NO
			AND DTL_SN = P_DTL_SN;
			
			IF SQL%NOTFOUND THEN
			   
			   RAISE_APPLICATION_ERROR(-20001, 'Invalid input value ' || 
			   								   'date:' || TO_CHAR(TO_DATE(P_WHSN_YMD, 'YYYYMMDD'), 'YYYY-MM-DD') || ',' ||
											   'vehl:' || P_VEHL_CD || ',' || 
											   'mkyr:' || P_EXPD_MDL_MDY_CD || ',' || 
											   'lang:' || P_LANG_CD || ',' || P_N_PRNT_PBCN_NO ||
											   'sn:'   || TO_CHAR(P_DTL_SN));
			   
			END IF;
			
			--재고정보 업데이트 작업 수행 
			PG_DATA.SP_SEWHA_IV_INFO_UPDATE(P_VEHL_CD,
											P_MDL_MDY_CD, 
											P_LANG_CD,
											P_EXPD_MDL_MDY_CD,  
											P_N_PRNT_PBCN_NO, 
											P_WHSN_YMD, 
											P_RQ_QTY, 
											P_USER_EENO,
											'Y'
											, NULL   -- 광주, 프로그램??
											);
			
	   END SP_SEWHA_WHOT_INFO_UPDATE;
	   								 
	   --세화 출고 정보 삭제 
	   PROCEDURE SP_SEWHA_WHOT_INFO_DELETE(P_VEHL_CD         VARCHAR2,
	   			 						   P_MDL_MDY_CD		 VARCHAR2,
									       P_LANG_CD         VARCHAR2,
										   P_EXPD_MDL_MDY_CD VARCHAR2,
									       P_N_PRNT_PBCN_NO  VARCHAR2,
									       P_DTL_SN          NUMBER,
										   P_USER_EENO       VARCHAR2)
	   IS
	   	 
		 V_CMPL_YN VARCHAR2(1);
		 
	   BEGIN
	   		
			SELECT MAX(CMPL_YN)
			INTO V_CMPL_YN
			FROM TB_SEWHA_WHOT_INFO
			WHERE QLTY_VEHL_CD = P_VEHL_CD
			AND MDL_MDY_CD = P_MDL_MDY_CD
			AND LANG_CD = P_LANG_CD
			AND DL_EXPD_MDL_MDY_CD = P_EXPD_MDL_MDY_CD
			AND N_PRNT_PBCN_NO = P_N_PRNT_PBCN_NO
			AND DTL_SN = P_DTL_SN;
			
			IF V_CMPL_YN IS NOT NULL AND
			   V_CMPL_YN = 'N' THEN
			   
			   UPDATE TB_SEWHA_WHOT_INFO
			   SET DEL_YN = 'Y',
				   UPDR_EENO = P_USER_EENO,
				   MDFY_DTM = SYSDATE
		       WHERE QLTY_VEHL_CD = P_VEHL_CD
			   AND MDL_MDY_CD = P_MDL_MDY_CD
			   AND LANG_CD = P_LANG_CD
			   AND DL_EXPD_MDL_MDY_CD = P_EXPD_MDL_MDY_CD
			   AND N_PRNT_PBCN_NO = P_N_PRNT_PBCN_NO
			   AND DTL_SN = P_DTL_SN;
			
			END IF;

	   END SP_SEWHA_WHOT_INFO_DELETE;
										
	   --세화 입고정보/재고정보 Insert 		
	   PROCEDURE SP_SEWHA_WHSN_INFO_SAVE(P_WHSN_YMD        VARCHAR2,
			  						     P_QLTY_VEHL_CD    VARCHAR2,
										 P_MDL_MDY_CD	   VARCHAR2,
									     P_LANG_CD         VARCHAR2,
										 P_EXPD_MDL_MDY_CD VARCHAR2,
									     P_N_PRNT_PBCN_NO  VARCHAR2,
									     P_WHSN_QTY        NUMBER,
									     P_CRGR_EENO       VARCHAR2,
									     P_PRNT_PARR_YMD   VARCHAR2,
									     P_DLVG_PARR_YMD   VARCHAR2,
									     P_USER_EENO       VARCHAR2)
	   IS
	   
	   V_PRDN_PLNT_CD  VARCHAR2(1);
	      
	   	 
	   BEGIN
	        
	        
			IF P_QLTY_VEHL_CD = 'AM' OR P_QLTY_VEHL_CD = 'PS' OR P_QLTY_VEHL_CD = 'SK3' THEN
				V_PRDN_PLNT_CD := '7';
		    ELSE 
   		    	V_PRDN_PLNT_CD := 'N';
		    END IF;
	        
			--입고정보 테이블에 데이터 Insert 
	   		INSERT INTO TB_SEWHA_WHSN_INFO
			(WHSN_YMD,
			 QLTY_VEHL_CD,
			 DL_EXPD_MDL_MDY_CD,
			 LANG_CD,
			 N_PRNT_PBCN_NO,
			 WHSN_QTY,
			 CRGR_EENO,
			 PRNT_PARR_YMD,
			 DLVG_PARR_YMD,
			 PPRR_EENO,
			 FRAM_DTM,
			 UPDR_EENO,
			 MDFY_DTM,
			 MDL_MDY_CD
			 , PRDN_PLNT_CD
			)
			VALUES
			(P_WHSN_YMD,
			 P_QLTY_VEHL_CD,
			 P_EXPD_MDL_MDY_CD,
			 P_LANG_CD,
			 P_N_PRNT_PBCN_NO,
			 P_WHSN_QTY,
			 P_CRGR_EENO,
			 P_PRNT_PARR_YMD,
			 P_DLVG_PARR_YMD,
			 P_USER_EENO,
			 SYSDATE,
			 P_USER_EENO,
			 SYSDATE,
			 P_MDL_MDY_CD
			 , V_PRDN_PLNT_CD
			);

			PG_DATA.SP_SEWHA_IV_INFO_SAVE_BY_WHSN(P_WHSN_YMD,
			  						     		  P_QLTY_VEHL_CD,
												  P_MDL_MDY_CD,
									     		  P_LANG_CD,
												  P_EXPD_MDL_MDY_CD,
									     		  P_N_PRNT_PBCN_NO,
									     		  P_WHSN_QTY,
									     		  --P_CRGR_EENO,
									     		  --P_PRNT_PARR_YMD,
									     		  P_DLVG_PARR_YMD,
									     		  P_USER_EENO
									     		  , V_PRDN_PLNT_CD   -- 광주
									     		  );
								     		  
	   END SP_SEWHA_WHSN_INFO_SAVE;
	   
	   --세화 입고정보 취소 수행 						  
	   PROCEDURE SP_SEWHA_WHSN_INFO_CANCEL(P_WHSN_YMD        VARCHAR2,
			  						       P_QLTY_VEHL_CD    VARCHAR2,
									       P_MDL_MDY_CD	     VARCHAR2,
									       P_LANG_CD         VARCHAR2,
										   P_EXPD_MDL_MDY_CD VARCHAR2,
									       P_N_PRNT_PBCN_NO  VARCHAR2,
									       P_WHSN_QTY        NUMBER,
									       P_USER_EENO       VARCHAR2)
	  IS
	  	
		V_QTY NUMBER;
        V_PRDN_PLNT_CD VARCHAR2(1);

	   BEGIN

          IF P_QLTY_VEHL_CD = 'AM' OR P_QLTY_VEHL_CD = 'PS' OR P_QLTY_VEHL_CD = 'SK3' THEN
				V_PRDN_PLNT_CD := '7';   --  세화재고는 광주 7로 통일
		  ELSE
		  		V_PRDN_PLNT_CD := 'N';
          END IF;
	  	   
		   --현재날짜의 재고수량을 확인해 본다. 
		   SELECT NVL(SUM(IV_QTY), 0)
		   INTO V_QTY
		   FROM TB_SEWHA_IV_INFO
		   WHERE CLS_YMD = TO_CHAR(SYSDATE, 'YYYYMMDD')
		   AND QLTY_VEHL_CD = P_QLTY_VEHL_CD
		   AND DL_EXPD_MDL_MDY_CD = P_EXPD_MDL_MDY_CD
		   AND LANG_CD = P_LANG_CD
		   AND N_PRNT_PBCN_NO = P_N_PRNT_PBCN_NO
		   AND CMPL_YN = 'N';
		   
		   IF V_QTY <> P_WHSN_QTY THEN
		   	  
			  RAISE_APPLICATION_ERROR(-20001, 'Sewon inventory quantity is already used ' || 
			   								  'date:' || TO_CHAR(TO_DATE(P_WHSN_YMD, 'YYYYMMDD'), 'YYYY-MM-DD') || ',' ||
											  'vehl:' || P_QLTY_VEHL_CD || ',' || 
											  'mkyr:' || P_EXPD_MDL_MDY_CD || ',' || 
											  'lang:' || P_LANG_CD || ',' || P_N_PRNT_PBCN_NO);
		   
		   ELSE
		   	   
			   --1.입고된 내역 삭제 
			   --입고된 내역에서 입고일 상관없이 관련 신인쇄발간번호에 대해 모두 삭제처리되어야 함.
			   DELETE FROM TB_SEWHA_WHSN_INFO
			   --WHERE WHSN_YMD = P_WHSN_YMD
			   --AND QLTY_VEHL_CD = P_QLTY_VEHL_CD
			   WHERE QLTY_VEHL_CD = P_QLTY_VEHL_CD
			   AND MDL_MDY_CD = P_MDL_MDY_CD
			   AND LANG_CD = P_LANG_CD
			   AND DL_EXPD_MDL_MDY_CD = P_EXPD_MDL_MDY_CD
			   AND N_PRNT_PBCN_NO = P_N_PRNT_PBCN_NO;
			   
			   --2.재고정보 삭제 
			   PG_DATA.SP_SEWHA_IV_INFO_CANCL_BY_WHSN(P_WHSN_YMD,
			  						       	  	      P_QLTY_VEHL_CD,
													  P_MDL_MDY_CD,
									       	  	      P_LANG_CD,
													  P_EXPD_MDL_MDY_CD,
									       	  	      P_N_PRNT_PBCN_NO,
									       	  	      --P_WHSN_QTY,
									       	  	      P_USER_EENO
									       	  	      , V_PRDN_PLNT_CD   -- 광주때문, 
									       	  	      );
		   END IF;
	  
			EXCEPTION
				WHEN OTHERS THEN
					ROLLBACK;
					PG_INTERFACE_APS.WRITE_BATCH_EXE_LOG('승인취소 에러', SYSDATE, 'F', 'SP_SEWHA_WHSN_INFO_CANCEL 배치처리실패 : [' || SQLERRM || ']');
	  END SP_SEWHA_WHSN_INFO_CANCEL;
	  
--[수정예정] 연식코드 추가요망 ~~~~~	  
	   --PDI재고 보정시에 반출, 불량 항목에 대한 세화 업데이트 작업을 수행 							
	   PROCEDURE SP_SEWHA_WHOT_INFO_UPDATE2(P_VEHL_CD         VARCHAR2,
	                                        P_MDL_MDY_CD	  VARCHAR2,
									        P_LANG_CD         VARCHAR2,
											P_EXPD_MDL_MDY_CD VARCHAR2,
									        P_N_PRNT_PBCN_NO  VARCHAR2,
										    P_WHOT_YMD		  VARCHAR2,
										    P_RQ_QTY		  NUMBER,
										    P_USER_EENO	      VARCHAR2)
	   IS
	   BEGIN
	   		
			INSERT INTO TB_SEWHA_WHOT_INFO
   			(QLTY_VEHL_CD,
   			 DL_EXPD_MDL_MDY_CD,
   			 LANG_CD,
   			 N_PRNT_PBCN_NO,
   			 DTL_SN,
   			 WHOT_YMD,
   			 DL_EXPD_RQ_SCN_CD,
   			 DLVG_PARR_YMD,
   			 DLVG_PARR_HHMM,
   			 RQ_QTY,
   			 PWTI_EENO,
   			 PRTL_IMTR_SBC,
   			 CRGR_EENO,
   			 DL_EXPD_BOX_QTY,
   			 CMPL_YN,
   			 WHSN_YMD,
   			 PPRR_EENO,
   			 FRAM_DTM,
   			 UPDR_EENO,
   			 MDFY_DTM,
			 DEL_YN,
			 MDL_MDY_CD
   			)
   			SELECT P_VEHL_CD,
   			       P_EXPD_MDL_MDY_CD,
   				   P_LANG_CD,
   				   P_N_PRNT_PBCN_NO,
   				   NVL(MAX(DTL_SN), 0) + 1,
   		           P_WHOT_YMD,
   				   '01',
   				   P_WHOT_YMD,
   				   TO_CHAR(SYSDATE, 'HH24MI'),
   				   P_RQ_QTY,
   				   P_USER_EENO,
   				   '',
   				   P_USER_EENO,
   				   1,
				   'Y',
				   P_WHOT_YMD,
   				   P_USER_EENO,
   				   SYSDATE,
   				   P_USER_EENO,
   				   SYSDATE,
				   'N',
				   P_MDL_MDY_CD
   			FROM TB_SEWHA_WHOT_INFO
   			WHERE QLTY_VEHL_CD = P_VEHL_CD
			AND MDL_MDY_CD = P_MDL_MDY_CD
   			AND LANG_CD = P_LANG_CD
			AND DL_EXPD_MDL_MDY_CD = P_EXPD_MDL_MDY_CD
   			AND N_PRNT_PBCN_NO = P_N_PRNT_PBCN_NO;
			
			--재고정보 업데이트 작업 수행 
			PG_DATA.SP_SEWHA_IV_INFO_UPDATE2(P_VEHL_CD,
											 P_MDL_MDY_CD,  
									         P_LANG_CD, 
											 P_EXPD_MDL_MDY_CD,
									         P_N_PRNT_PBCN_NO, 
									 		 P_WHOT_YMD, 
									 		 P_RQ_QTY,
									 		 'N', 
									 		 P_USER_EENO
									 		 , NULL   -- 광주, 프로그램??
									 		 );
			
			RETURN;
			
	   END SP_SEWHA_WHOT_INFO_UPDATE2;
	   								 
	   --세화 납품예정일 변경 
	   PROCEDURE SP_SEWHA_DLVG_PARR_YMD_UPDATE(P_WHSN_YMD        VARCHAR2,
			  								   P_VEHL_CD         VARCHAR2,
											   P_MDL_MDY_CD 	 VARCHAR2,
									           P_LANG_CD         VARCHAR2,
											   P_EXPD_MDL_MDY_CD VARCHAR2,
									           P_N_PRNT_PBCN_NO  VARCHAR2,
											   P_DLVG_PARR_YMD   VARCHAR2,
										       P_USER_EENO       VARCHAR2)
	   IS
	   BEGIN
	   		
			UPDATE TB_SEWHA_WHSN_INFO
			SET DLVG_PARR_YMD = P_DLVG_PARR_YMD,
			UPDR_EENO = P_USER_EENO,
			MDFY_DTM = SYSDATE
			WHERE WHSN_YMD = P_WHSN_YMD
			AND QLTY_VEHL_CD = P_VEHL_CD
			AND MDL_MDY_CD = P_MDL_MDY_CD
			AND LANG_CD = P_LANG_CD
			AND DL_EXPD_MDL_MDY_CD = P_EXPD_MDL_MDY_CD
			AND N_PRNT_PBCN_NO = P_N_PRNT_PBCN_NO;
			
			PG_DATA.SP_SEWHA_DLVG_PARR_YMD_UPDATE(P_WHSN_YMD,
			  								      P_VEHL_CD,
												  P_MDL_MDY_CD,
									              P_LANG_CD,
												  P_EXPD_MDL_MDY_CD,
									              P_N_PRNT_PBCN_NO,
											      P_DLVG_PARR_YMD,
										          P_USER_EENO
										          , NULL   -- 광주, 프로그램??
										          );
	   END SP_SEWHA_DLVG_PARR_YMD_UPDATE;
	   
	   --세화 재고정보 일배치 정리작업 수행 
	   --반드시 현재일 시작시간에 돌려야 한다.
	   PROCEDURE SP_SEWHA_IV_INFO_BATCH
	   IS
	   	 
		 STRT_DATE  DATE;
		 
		 V_CURR_CLS_YMD  VARCHAR2(8) := TO_CHAR(SYSDATE, 'YYYYMMDD');
		 V_PREV_CLS_YMD  VARCHAR2(8) := TO_CHAR(SYSDATE - 1, 'YYYYMMDD'); 
		 		 
		 V_DLVG_PARR_YMD VARCHAR2(8);
		 
		 V_TMP_IV_QTY    NUMBER;
		 
		 BTCH_USER_EENO  CONSTANT VARCHAR2(7) := PG_DATA.BTCH_USER_EENO; -- 배치작업 담당자 코드 
		 
		 CURSOR SEWHA_IV_INFO IS 
		 
				SELECT   QLTY_VEHL_CD
				       , DL_EXPD_MDL_MDY_CD
				       , LANG_CD
				       , N_PRNT_PBCN_NO
				       , IV_QTY
				       , CASE WHEN DLVG_PARR_YMD > V_PREV_CLS_YMD AND DL_EXPD_TMP_IV_QTY <>  0 THEN DL_EXPD_TMP_IV_QTY
				              ELSE TMP_IV_QTY
				         END TMP_IV_QTY
				       , PRDN_PLNT_CD
				       , DLVG_PARR_YMD
				  FROM (
						SELECT   B.DLVG_PARR_YMD
						       , A.QLTY_VEHL_CD
						       , A.DL_EXPD_MDL_MDY_CD
						       , A.LANG_CD
						       , A.N_PRNT_PBCN_NO
						       , A.IV_QTY
						       , A.DL_EXPD_TMP_IV_QTY
						       , A.PRDN_PLNT_CD
						       , 0 AS TMP_IV_QTY
						  FROM (
								SELECT  QLTY_VEHL_CD,
										DL_EXPD_MDL_MDY_CD,
										LANG_CD,
										N_PRNT_PBCN_NO,
										IV_QTY,
										DL_EXPD_TMP_IV_QTY
										, NVL(TRIM(PRDN_PLNT_CD),'N') AS PRDN_PLNT_CD   --  광주, 프로그램??
								   FROM TB_SEWHA_IV_INFO
								  WHERE CLS_YMD = V_PREV_CLS_YMD
							 	    AND QLTY_VEHL_CD IN (SELECT QLTY_VEHL_CD FROM TB_VEHL_MGMT WHERE DL_EXPD_CO_CD = '02' AND USE_YN = 'Y')
								    AND IV_QTY > 0
						       ) A
						       , TB_SEWHA_WHSN_INFO B
						 WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD(+)
						   AND A.DL_EXPD_MDL_MDY_CD = B.DL_EXPD_MDL_MDY_CD(+)
						   AND A.LANG_CD = B.LANG_CD(+)
						   AND A.N_PRNT_PBCN_NO = B.N_PRNT_PBCN_NO(+)
				       );
		 /**
				 SELECT QLTY_VEHL_CD,
			  	 		DL_EXPD_MDL_MDY_CD,
					    LANG_CD,
					    N_PRNT_PBCN_NO,
					    IV_QTY,
						DL_EXPD_TMP_IV_QTY
						, NVL(TRIM(PRDN_PLNT_CD),'N') AS PRDN_PLNT_CD   --  광주, 프로그램??
			  	   FROM TB_SEWHA_IV_INFO
			      WHERE CLS_YMD = V_PREV_CLS_YMD
			        AND QLTY_VEHL_CD IN (SELECT QLTY_VEHL_CD FROM TB_VEHL_MGMT WHERE DL_EXPD_CO_CD = '02' AND USE_YN = 'Y')
			        AND IV_QTY > 0;
		 **/
		 
		 
		  
		 --전일의 재고내역을 기반으로 재고상세 내역을 다시 생성하는 방식 
		 CURSOR SEWHA_IV_DTL_INFO IS 
		 
				 SELECT QLTY_VEHL_CD,
			  	 		LANG_CD
			  	 	    , NVL(TRIM(PRDN_PLNT_CD),'N') AS PRDN_PLNT_CD     -- 광주분리 
				   FROM TB_SEWHA_IV_INFO
				  WHERE CLS_YMD = V_PREV_CLS_YMD
				    AND IV_QTY > 0
				    AND QLTY_VEHL_CD IN (SELECT QLTY_VEHL_CD FROM TB_VEHL_MGMT WHERE DL_EXPD_CO_CD = '02' AND USE_YN = 'Y')
				  GROUP BY QLTY_VEHL_CD, LANG_CD , NVL(TRIM(PRDN_PLNT_CD),'N')    -- 광주분리
				  ORDER BY QLTY_VEHL_CD, LANG_CD;
									  
									  
									  
									  
									  
									  
	   BEGIN
			STRT_DATE  := SYSDATE;

			FOR IV_LIST IN SEWHA_IV_INFO LOOP
			
					-- V_TMP_IV_QTY := 0;
					
					V_TMP_IV_QTY := IV_LIST.TMP_IV_QTY;
					
					
					/**	 
					IF IV_LIST.DL_EXPD_TMP_IV_QTY <> 0 THEN
					   
					   SELECT C.DLVG_PARR_YMD
					     INTO V_DLVG_PARR_YMD
					     FROM TB_LANG_MGMT A,
				 	   		  TB_DL_EXPD_MDY_MGMT B,
				 	 		  TB_SEWHA_WHSN_INFO C
					    WHERE A.QLTY_VEHL_CD = B.QLTY_VEHL_CD
					      AND A.MDL_MDY_CD = B.MDL_MDY_CD
				          AND A.DL_EXPD_REGN_CD = B.DL_EXPD_REGN_CD 
					      AND A.QLTY_VEHL_CD = C.QLTY_VEHL_CD
					      AND A.MDL_MDY_CD = C.MDL_MDY_CD
					      AND A.LANG_CD = C.LANG_CD
					      AND B.DL_EXPD_MDL_MDY_CD = C.DL_EXPD_MDL_MDY_CD
					      AND C.QLTY_VEHL_CD = IV_LIST.QLTY_VEHL_CD
					      AND C.DL_EXPD_MDL_MDY_CD = IV_LIST.DL_EXPD_MDL_MDY_CD
					      AND C.LANG_CD = IV_LIST.LANG_CD
					      AND C.N_PRNT_PBCN_NO = IV_LIST.N_PRNT_PBCN_NO
					  --    AND NVL(TRIM(C.PRDN_PLNT_CD),'N') = IV_LIST.PRDN_PLNT_CD   -- 광주분리
					   ;
					   
					   IF V_DLVG_PARR_YMD > V_CURR_CLS_YMD THEN
					   	  
						  V_TMP_IV_QTY := IV_LIST.DL_EXPD_TMP_IV_QTY;
					   
					   END IF;
					   
					END IF;
					**/
					INSERT INTO TB_SEWHA_IV_INFO
					(
					 CLS_YMD,
					 QLTY_VEHL_CD,
					 DL_EXPD_MDL_MDY_CD,
					 LANG_CD,
					 N_PRNT_PBCN_NO,
					 IV_QTY,
					 DL_EXPD_TMP_IV_QTY,
					 CMPL_YN,
					 PPRR_EENO,
					 FRAM_DTM,
					 UPDR_EENO,
					 MDFY_DTM
					 , PRDN_PLNT_CD    -- 광주분리
					)
					VALUES
					(
					 V_CURR_CLS_YMD,
					 IV_LIST.QLTY_VEHL_CD,
					 IV_LIST.DL_EXPD_MDL_MDY_CD,
					 IV_LIST.LANG_CD,
					 IV_LIST.N_PRNT_PBCN_NO,
					 IV_LIST.IV_QTY,
					 V_TMP_IV_QTY,
					 'N',
					 BTCH_USER_EENO,
					 SYSDATE,
					 BTCH_USER_EENO,
					 SYSDATE
					 , IV_LIST.PRDN_PLNT_CD    -- 광주분리
					);
					
					--전일의 재고내역을 기반으로 재고상세 내역을 다시 생성하는 방식의 경우 
					--재고상세 테이블에 취급설명서연식과 같은 차종연식으로 데이터를 신규입력하여 준다.
					--(왜냐하면 연식 연계 관계에서 취급설명서 연식과 연계된 차종 연식에는 
					-- 취급설명서 연식과 동일한 차종연식은 반드시 있기 때문이다.) 
					INSERT INTO TB_SEWHA_IV_INFO_DTL
					(CLS_YMD,
					 QLTY_VEHL_CD,
					 MDL_MDY_CD,
					 LANG_CD,
					 DL_EXPD_MDL_MDY_CD,
					 N_PRNT_PBCN_NO,
					 IV_QTY,
					 SFTY_IV_QTY,
					 DL_EXPD_TMP_IV_QTY,
					 CMPL_YN,
					 PPRR_EENO,
					 FRAM_DTM,
					 UPDR_EENO,
					 MDFY_DTM
					 , PRDN_PLNT_CD    -- 광주분리
					)
					VALUES
					(V_CURR_CLS_YMD,
					 IV_LIST.QLTY_VEHL_CD,
					 IV_LIST.DL_EXPD_MDL_MDY_CD, --차종연식을 취급설명서 연식과 동일한 값으로 입력 
					 IV_LIST.LANG_CD,
					 IV_LIST.DL_EXPD_MDL_MDY_CD,
					 IV_LIST.N_PRNT_PBCN_NO,
					 IV_LIST.IV_QTY,
					 IV_LIST.IV_QTY,             --안전재고수량 역시 현재의 재고수량과 동일한 값으로 입력한다.(나중에 재고 재계산 시에 다시 계산됨) 
					 V_TMP_IV_QTY,
					 'N',
					 BTCH_USER_EENO,
					 SYSDATE,
					 BTCH_USER_EENO,
					 SYSDATE
					 , IV_LIST.PRDN_PLNT_CD    -- 광주분리
					);
	
			END LOOP;

			UPDATE TB_SEWHA_IV_INFO
			   SET CMPL_YN = 'Y'
			 WHERE CLS_YMD = V_PREV_CLS_YMD;
			
			/*** 
			--전일의 재고상세 내역을 복사하는 방식의 경우 
			 
			FOR IV_DTL_LIST IN SEWHA_IV_DTL_INFO LOOP
				
				V_TMP_IV_QTY := 0;
				 
				IF IV_DTL_LIST.DL_EXPD_TMP_IV_QTY <> 0 THEN
				   
				   SELECT DLVG_PARR_YMD
				   INTO V_DLVG_PARR_YMD
				   FROM TB_SEWHA_WHSN_INFO
				   WHERE QLTY_VEHL_CD = IV_DTL_LIST.QLTY_VEHL_CD
				   AND MDL_MDY_CD = IV_DTL_LIST.MDL_MDY_CD
				   AND LANG_CD = IV_DTL_LIST.LANG_CD
				   AND DL_EXPD_MDL_MDY_CD = IV_DTL_LIST.DL_EXPD_MDL_MDY_CD
				   AND N_PRNT_PBCN_NO = IV_DTL_LIST.N_PRNT_PBCN_NO;
				   
				   IF V_DLVG_PARR_YMD > V_CURR_CLS_YMD THEN
				   	  
					  V_TMP_IV_QTY := IV_DTL_LIST.DL_EXPD_TMP_IV_QTY;
				   
				   END IF;
				   
				END IF;
				
				INSERT INTO TB_SEWHA_IV_INFO_DTL
				(CLS_YMD,
				 QLTY_VEHL_CD,
				 MDL_MDY_CD,
				 LANG_CD,
				 DL_EXPD_MDL_MDY_CD,
				 N_PRNT_PBCN_NO,
				 IV_QTY,
				 SFTY_IV_QTY,
				 DL_EXPD_TMP_IV_QTY,
				 CMPL_YN,
				 PPRR_EENO,
				 FRAM_DTM,
				 UPDR_EENO,
				 MDFY_DTM
				)
				VALUES
				(V_CURR_CLS_YMD,
				 IV_DTL_LIST.QLTY_VEHL_CD,
				 IV_DTL_LIST.MDL_MDY_CD,
				 IV_DTL_LIST.LANG_CD,
				 IV_DTL_LIST.DL_EXPD_MDL_MDY_CD,
				 IV_DTL_LIST.N_PRNT_PBCN_NO,
				 IV_DTL_LIST.IV_QTY,
				 IV_DTL_LIST.SFTY_IV_QTY,
				 V_TMP_IV_QTY,
				 'N',
				 BTCH_USER_EENO,
				 SYSDATE,
				 BTCH_USER_EENO,
				 SYSDATE
				);
				
			END LOOP;
			***/ 
			
			FOR IV_DTL_LIST IN SEWHA_IV_DTL_INFO LOOP
				
				PG_DATA.SP_RECALCULATE_SEWHA_IV_DTL4(V_CURR_CLS_YMD,
												     IV_DTL_LIST.QLTY_VEHL_CD,
												     IV_DTL_LIST.LANG_CD,
												     BTCH_USER_EENO
												     , IV_DTL_LIST.PRDN_PLNT_CD
												     );
			END LOOP;
			
			UPDATE TB_SEWHA_IV_INFO_DTL
			   SET CMPL_YN = 'Y'
			 WHERE CLS_YMD = V_PREV_CLS_YMD;

			COMMIT;

		 	PG_INTERFACE_APS.WRITE_BATCH_LOG('세화재고배치작업', STRT_DATE, 'S', '배치처리완료');

		 EXCEPTION
		     WHEN OTHERS THEN
			     ROLLBACK;
				 PG_INTERFACE_APS.WRITE_BATCH_LOG('세화재고배치작업', STRT_DATE, 'F', '배치처리실패:[' || SQLERRM || ']');
				 
	   END SP_SEWHA_IV_INFO_BATCH;
	   
END PG_SEWHA_IV_INFO;