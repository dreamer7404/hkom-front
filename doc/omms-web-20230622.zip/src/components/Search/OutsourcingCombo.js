import React from 'react';
import { Form, SelectPicker } from 'rsuite';

//--------------  서버데이터용 필수 -------------------------------
import { useQuery} from 'react-query';
import { getData } from '../../utils/async';
import { API, CONSTANTS } from '../../utils/constants';
import useStore from '../../utils/store';
import { useState, useEffect } from 'react';
//--------------// 서버데이터용 필수 -------------------------------


const OutsourcingCombo = ({title, updatedValue, parentCompSetValue}) => {

    const [selectedValue, setSelectedValue] = useState('06')

    const onChangeValue = val => {
        setSelectedValue(val);
        parentCompSetValue(val, '0011')
    };

    useEffect(() => {
        if(updatedValue !== '' ){
            setSelectedValue(updatedValue)
        }
    }, [updatedValue])

    // subCd API가져오기
    const param = {
        mainCd: '0011'
    };
    const outsourcingCombo = useQuery([API.outsourcingCombo, param], () => getData(API.outsourcingCombo, param), {
            select: data => [{label: '없음', value: null}].concat(
                data.map((item) => ({ label: item.label+'['+item.value+']', value: item.value }))
                )
    });

    useEffect(() => {
        if(outsourcingCombo.isSuccess){
            setSelectedValue(outsourcingCombo.data[1].value)
        }
    }, [outsourcingCombo.status])

    return (
        <>
            {
                title ?
                <Form.ControlLabel column="sm" >{title}</Form.ControlLabel>
                : null
            }
            <SelectPicker size="sm"
                value={selectedValue} 
                data={outsourcingCombo && outsourcingCombo.data ? outsourcingCombo.data : []} 
                onChange={onChangeValue}
                cleanable={false}
                searchable={false}
                block={true}
            />
        </>
    )
}
export default OutsourcingCombo;