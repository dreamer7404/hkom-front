import React, {useState, useRef}  from 'react';
import { Row, Col } from 'react-bootstrap';
import { Form ,SelectPicker,CheckPicker,Checkbox, Button } from 'rsuite';
import { escapeCharChange} from '../../utils/commUtils';

//--------------  서버데이터용 필수 -------------------------------
import { useQuery} from 'react-query';
import { getData  } from '../../utils/async';
import { API, CONSTANTS } from '../../utils/constants';
import useStore from '../../utils/store';
import { useEffect } from 'react';
//--------------// 서버데이터용 필수 -------------------------------

const LangMultiByVehl = ({qltyVehlCd, qltyVehlNm, langCdByVehlList, setSelectedLangCdByVehl, formErrorStatus, firstRender}) => {

    // langCombo API가져오기
    const langParams = {qltyVehlCd: qltyVehlCd};
    const langCombo = useQuery([API.mriClcmLangCdInfos, langParams], () => getData(API.mriClcmLangCdInfos, langParams), {
        select: data => data.map((item) => ({ label: escapeCharChange(item.langCdNm), value: item.langCd }))
    }); 

    const allValue = langCombo && langCombo.data ? langCombo.data.map(item => item.value) : [];
    const picker = useRef();

    
    const [value, setValue] = useState(langCdByVehlList.map((item) => (item.langCd)));
    
    const handleKeyword = () => {
        setSelectedLangCdByVehl(
            value.map(item => ({qltyVehlCd : qltyVehlCd, qltyVehlNm: qltyVehlCd+'('+qltyVehlNm+')', langCd: item, langCdNm: setLangCdNm(item)}))
        )
    }

    const setLangCdNm = (langCd) => {
        return langCd+'('+langCombo.data.filter(item => {return item.value === langCd})[0].label+')'
    }

    const handleChange = (value, prop) => {
        setValue(value);
    };

    const handleCheckAll = (value, checked) => {
        setValue(checked ? allValue : []);
    };

    const footerStyles = {
        padding: '2px 2px',
        borderTop: '1px solid #e5e5e5'
      };
    return (
        <>
                
                    <CheckPicker
                        size="sm"
                        // data={data}
                        data={langCombo && langCombo.data ? langCombo.data : []}  
                        placeholder="전체"
                        ref={picker}
                        style={{ width: 450 }}
                        /*width 해지시 다중선택하면 길이가 늘어남.. */
                        value={value}
                        searchable={false}
                        onChange={handleChange}
                        onClose={handleKeyword}
                        cleanable={false}
                        error={formErrorStatus}
                        renderExtraFooter={() => (
                        <div style={footerStyles}>
                            <Checkbox
                                indeterminate={value.length > 0 && value.length < allValue.length}
                                checked={value.length === allValue.length}
                                onChange={handleCheckAll}
                            >
                            전체 선택
                            </Checkbox>
                        </div>
                        )}
                    />
                    <Form.ErrorMessage show={firstRender && formErrorStatus} >
                        {formErrorStatus}
                    </Form.ErrorMessage>
                    {/* {JSON.stringify(value)} */}
        </>
    );

};
export default LangMultiByVehl;