// react
import React, {useState, useMemo, useEffect} from 'react';
import { AgGridReact } from 'ag-grid-react';

import {Button, Table} from 'react-bootstrap';
import { escapeCharChangeForGrid, escapeCharChange, unescapeHtml} from '../../../../utils/commUtils';
import { useLocation } from 'react-router';
import { useNavigate  } from 'react-router-dom';
//--------------  서버데이터용 필수 -------------------------------
import { useQuery} from 'react-query';
import { getData } from '../../../../utils/async';
import { API, CONSTANTS } from '../../../../utils/constants';
import useStore from '../../../../utils/store';
//--------------// 서버데이터용 필수 -------------------------------
import { DEXT5Editor } from 'dext5editor-react';
import { DEXT5Upload } from 'dext5upload-react';
import qs from 'qs';

const ClcmDetail = () => {
    const navigate = useNavigate();
    const location = useLocation();
    const [param, setParam] = useState(
        qs.parse(location.state, { ignoreQueryPrefix: true })
    )
    const queryResult = useQuery([API.mriClcmInfo, param], () => getData(API.mriClcmInfo, param));

    const [files, setFiles] = useState(null)

    const [langCdByVehlList, setLangCdByVehlList]= useState([]);

    useEffect(() => {
        if(queryResult.isSuccess){
            setLangCdByVehlList(queryResult.data.langCdByVehlList);
            setFiles(queryResult.data.fileList);
        }
    }, [queryResult.status])



    const columnDefs = [
        {
          headerName: '차종',
          field: 'qltyVehlNm',
          cellRenderer:"escapeCharChangeForGrid"
        },
        {
          headerName: '언어',
          field: 'langCdNm',
          cellRenderer:"escapeCharChangeForGrid"
        },
        {
          headerName: '적용 발간번호',
          field: 'newPrntPbcnNo',
        },
    ]

    const [rowData2] = useState([
            {userPart: "현대자동차", userName: "홍길동"},
            {userPart: "현대자동차", userName: "김삼순"},
            {userPart: "현대자동차", userName: "김삼순"},
            {userPart: "현대자동차", userName: "김삼순"},
    ]);

    const columnDefs2 = [
        {
          headerName: '소속',
          field: 'userPart',
        },
        {
          headerName: '이름',
          field: 'userName',
        },
    ]

    const defaultColDef = useMemo(() => {
        return {
            initialWidth: 90,
            sortable: true,
        };
    }, []);


    const onFirstDataRendered = (params) => {
        params.api.sizeColumnsToFit();
    };

    const updateButton = () => {
        navigate('/clcm/update',{ state: queryResult.data });
    }

    const listButton = () => {
        // window.location.href="./ClcmList"
        window.location.href="."
    }

     // 기존업로드된 파일리스트 (수정화면에서 사용)
     const onCreationComplete = e => {
        console.log('files', files)
        if(files){
            console.log('files2', files)
            for(let i=0; i<files.length; i++){
                console.log(''+(i+1), escapeCharChange(files[i].fileNm), '', files[i].fileSize, files[i].attcSn)
                DEXT5UPLOAD.AddUploadedFile(''+(i+1), escapeCharChange(files[i].fileNm), '', files[i].fileSize, files[i].attcSn, 'dext5upload1');
            }
        }
    }

    if(!queryResult.isFetched) return;

    return (
        <>
            <div className="grid-wrap">
                <Table className="tbl-hor" bordered>
                    <colgroup>
                        <col style={{width:'15%'}}></col>
                        <col style={{width:'35%'}}></col>
                        <col style={{width:'15%'}}></col>
                        <col style={{width:'35%'}}></col>
                    </colgroup>
                    <tbody>
                        <tr>
                            <th>수신형태</th>
                            <td>
                                {queryResult && queryResult.data && queryResult.data.rcpmShapNm}
                            </td>
                            <th>등록자</th>
                            <td>
                                {queryResult && queryResult.data && queryResult.data.pprrEenoNm}
                            </td>
                        </tr>
                        <tr>
                            <th>발신처</th>
                            <td>
                                {queryResult && queryResult.data && queryResult.data.dsppNm}
                            </td>
                            <th>담당자</th>
                            <td>
                                {queryResult && queryResult.data && queryResult.data.crgrNm}
                            </td>
                        </tr>
                        
                        <tr>
                            <th>적용 차종 및 언어</th>
                            <td>
                                <div className="ag-theme-alpine" style={{height: 130, transition:'all ease .3s'}}>
                                    <AgGridReact
                                        rowData={langCdByVehlList}
                                        columnDefs={columnDefs}
                                        defaultColDef={defaultColDef}
                                        onFirstDataRendered={onFirstDataRendered}
                                        suppressSizeToFit={true}    
                                        onGridSizeChanged={onFirstDataRendered}
                                        frameworkComponents={{escapeCharChangeForGrid}}
                                        >
                                    </AgGridReact>
                                </div>
                            </td>
                            <th>송부인</th>
                            <td>
                                <div className="ag-theme-alpine" style={{height: 130, transition:'all ease .3s'}}>
                                    <AgGridReact
                                        rowData={rowData2}
                                        columnDefs={columnDefs2}
                                        defaultColDef={defaultColDef}
                                        rowSelection={'multiple'}
                                        suppressRowClickSelection= {true} 
                                        onFirstDataRendered={onFirstDataRendered}
                                        suppressSizeToFit={true}    
                                        onGridSizeChanged={onFirstDataRendered}    
                                        >
                                    </AgGridReact>
                                </div>
                            </td>
                        </tr>
                        <tr>
                            <th>제목</th>
                            <td colSpan="3">
                                {queryResult && queryResult.data && queryResult.data.altrTitl}
                            </td>
                        </tr>
                        <tr>
                            <th>내용</th>
                            <td colSpan="3">
                                {/* {queryResult && queryResult.data && escapeCharChange(escapeCharChange(queryResult.data.altrSbc))} */}
                                <div dangerouslySetInnerHTML={{__html: unescapeHtml(queryResult.data.altrSbc)}} />
                            </td>
                        </tr>
                        <tr>
                            <th>첨부파일</th>
                            {/* {
                            queryResult && queryResult.data && queryResult.data.attcYn === 'N'
                            ? <td colSpan="3">첨부파일이 없습니다.</td>
                            : <td colSpan="3">첨부파일 있음 처리 필요</td>
                            } */}
                            <td  colSpan="3">
                                {files && files.length > 0 && <DEXT5Upload
                                        onCreationComplete={onCreationComplete}
                                        // onTransferComplete={onTransferComplete}
                                        // onBeforeAddItem={onBeforeAddItem}
                                        debug={false}
                                        id="dext5upload1"
                                        // mode='edit' 
                                        mode='view'  // view Mode
                                        runtimes='html5'
                                        componentUrl="/dext5upload/js/dext5upload.js"
                                        config={{MaxTotalFileSize:'100MB', MaxOneFileSize:'30MB', DevelopLangage:'NONE',
                                        // ButtonBarEdit: "add,remove,remove_all",
                                        ButtonBarView: 'download,download_all', // view Mode
                                        Width:'100%'}}
                                        
                                    />}
                                
                            </td>
                        </tr>
                    </tbody>
                </Table>
                <div className="btn-wrap">
                    <div className="left-align">
                        <Button variant="light" onClick={listButton}>목록</Button>{' '}
                    </div>
                    <div className="right-align">
                        <Button variant="outline-danger" onClick={listButton}>삭제</Button>{' '}
                        <Button className="" variant="primary" size="md" onClick={updateButton}>수정</Button>
                    </div>
                </div>
            </div>
        </>
    )
};
export default ClcmDetail;