// react
import React, {useState, useEffect, useCallback} from 'react';
import { Button, Collapse} from 'react-bootstrap';
import {Grid, Row, Col , Form, SelectPicker, Input,Notification, toaster } from 'rsuite';
import SearchIcon from '@rsuite/icons/Search';

//--------------  서버데이터용 필수 -------------------------------
import { useQuery, useMutation} from 'react-query';
import { API, CONSTANTS } from '../../../../utils/constants';
import { getData, getDataArray, postData } from '../../../../utils/async';
import useStore from '../../../../utils/store';
import VehlType from '../../../Search/VehlType';
import LangMulti from '../../../Search/LangMulti';
import IWayCdCombo from '../../../Search/IWayCdCombo';
import PersonSearch from '../../../Search/PersonSearch';
import SeDate from '../../../Search/SeDate';
//--------------// 서버데이터용 필수 -------------------------------
import { useNavigate, Link  } from 'react-router-dom';
import GridPrintOrderList from '../_Grid/GridPrintOrderList';
import Paging from '../../../Common/Paging';
import { CustomInputGroup } from '../../../Common/CustomInputGroup';
import { utcToLocalDate } from '../../../../utils/commUtils';
import { confirmAlert } from 'react-confirm-alert'; // Import
import ConfirmAlert from '../../../Common/ConfirmAlert';

const PrintOrderList = () => {
    
    //------------------- 필수 공통 ------------------------------
    const [open, setOpen] = useState(true); // 조건창 열기/닫기
    const {keyword } = useStore();  // 조회키워드 가져오기

    const [activePage, setActivePage] = useState(1);    // 페이지번호
    const [limit, setLimit] = useState(50);             // 페이지행수
    const [filterValue, setFilterValue] = useState(''); // 필터값
    const navigate = useNavigate();
    const onChangePage = val => {
        setActivePage(val);
    };
    const onChangeLimit = val => {
        setLimit(val);
    };
    useEffect(()=>{
        onChangePage(1); // 페이지번호 리셋
    },[keyword]);

    // 필터
    const onFilterTextBoxChanged = useCallback((e) => {
        setFilterValue(e.target.value);
    }, []);

    // 검색창 열기/닫기 > 페이지네이션 여부에 따라 +-20px
    const [gridHeight, setGridHeight] = useState(575);
    const gridExpand = () =>{
        setOpen(!open);
        if(open){
            setTimeout(() => setGridHeight(650), 250);
        }else{
            setGridHeight(575)
        }
    }
    //-------------------// 필수 공통 ------------------------------

    
    const param = {
        ssDate: keyword.sDate,
        eeDate: keyword.eDate,
        dlExpdPdiCd: keyword.dlExpdPdiCd,
        qltyVehlCd: keyword.qltyVehlCd,
        mdlMdyCd: keyword.mdlMdyCd,
        dlExpdRegnCd: keyword.dlExpdRegnCd,
        langCds: keyword.langCds,
        iiWayCd: keyword.iWayCd,
        subCd: keyword.subCd,
        newPrntPbcnNo : 'ALL',
        crgrEeno: 'ALL'
    }
    //  requestState 조회
    // const queryResult = useQuery(["PrintOrderList"], () => {return rowData});
    // const queryResult = useQuery([API.printOrderInfos, param], () => getData(API.printOrderInfos, param), {
    //     //enabled:false
    // });

    const queryResult = useMutation([API.printOrderInfos, param], () => postData(API.printOrderInfos, param, 'select'))
    
    // 셀 클릭
    const onCellClicked = e => {
        if(e.column.colId === 'newPrntPbcnNo'){
            detailButton(e)
        }
    };

    const [langCds, setLangCds] = useState();
    useEffect(() => {
        //queryResult.refetch()
        queryResult.mutate(param)
    }, [keyword.langCds])

    const onChangeNewPrntPbcnNo = e => {
        param.newPrntPbcnNo =  e
    }

    const onChangeCrgrEeno = value => {
        param.crgrEeno =  value
    }

    const detailButton = (data) => {
        let param = {
            bDate: utcToLocalDate(new Date()),
            dlExpdPdiCd: data.data.dlExpdPdiCd,
            qltyVehlCd: data.data.qltyVehlCd,
            mdlMdyCd: data.data.mdlMdyCd,
            dlExpdRegnCd: data.data.dlExpdRegnCd,
            langCd: data.data.langCd,
            subCd: 'ALL',
            newPrntPbcnNo: data.data.newPrntPbcnNo, 
            trtmRst: data.data.trtmRst,     //발주상태명
            trtmRstCd: data.data.trtmRstCd  //발주상태코드
        }
        navigate('/printOrder/detail',{ state: param }); 
        // navigate('/printState/detail',{ state: param }); 
    }
    
    // 그리드 내에서 체크된 rows by Woong
    const [checkedRows, setCheckedRows] = useState([]);    
    const checkRow = e => {
        setCheckedRows(e)
    };

    const addButton = () => {
        if(checkedRows.length > 1){
            confirmAlert({
                closeOnClickOutside: false,
                customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}  title={"알림"} msg={'하나만 선택해주세요.'}  />
            })
        } else {
            navigate('/printOrder/add',{ state: checkedRows[0] }); 
        }
    }
    // 조회버튼
    const onSearch = () => {
        queryResult.mutate(param)
    };


    // 발주취소
    const deleteResult = useMutation((params => postData(API.printOrderInfoDelete, params, CONSTANTS.delete)),{
        onSuccess: res => {
		    if(res > 0){
                toaster.push(
                    <Notification type='success' header='요청성공' closable >발주취소가 완료되었습니다.</Notification>
                );
                // window.location.href="./ClcmDetail"
                setTimeout(() => onSearch(), 500)
            }else{
                toaster.push(
                    <Notification type='error' header='요청실패' closable >발주취소를 실패했습니다.</Notification>
                );
            }
        }
    });
    const cancelButton = () => {

        let checkTrtmRstCd = false
        checkedRows.forEach(item => {
            item.trtmRstCd !== '02'? checkTrtmRstCd=true : checkTrtmRstCd=false
        })
        if(checkTrtmRstCd) {
            confirmAlert({
                closeOnClickOutside: false,
                customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}  title={"알림"} msg={'발주완료된 항목만 취소 가능합니다.'}  />
            })
            return false
        }

        let checkDlvgParrYmd = false
        checkedRows.forEach(item => {
            Number(item.dlvgParrYmd.replace(/-/g, '')) < Number(utcToLocalDate(new Date()).replace(/-/g, '')) ? checkDlvgParrYmd=true : checkDlvgParrYmd=false
        })
        if(checkDlvgParrYmd) {
            confirmAlert({
                closeOnClickOutside: false,
                customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}  title={"알림"} msg={'납품일이 지난 항목은 취소가 불가합니다.'}  />
            })
            return false
        }
        
        if(!checkTrtmRstCd && !checkDlvgParrYmd){
            // alert(checkTrtmRstCd && checkDlvgParrYmd)
            setTimeout(deleteResult.mutate(checkedRows), 500)
        }
        
    }

    return (
        <>
            <div className="search-area">
                <Collapse in={open}>
                    <div className="form" id="example-collapse-text">
                        <div className="search-group">
                            <div className="row">
                                <Grid fluid>
                                    <Row className="show-grid">
                                        <Col sm={5} className=""> 
                                            <SeDate />
                                        </Col>
                                        <Col sm={7} className="" >
                                            <VehlType  />
                                        </Col>
                                        <Col sm={6} className="" >
                                            <LangMulti  />
                                        </Col>
                                        <Col sm={2} className="" >
                                            <IWayCdCombo  />
                                        </Col>
                                        <Col sm={4} className="" >
                                            <Form.ControlLabel column="sm" >발간번호</Form.ControlLabel>
                                            <Input size="sm" type="text" onChange={onChangeNewPrntPbcnNo}/>
                                        </Col>
                                        <Col sm={4} className="" >
                                            {/* <Form.ControlLabel column="sm" >발주자</Form.ControlLabel>
                                            <Input size="sm" type="text" onChange={onChangeCrgrEeno} /> */}
                                            <PersonSearch label={'발주자'} rmCheck={true} onChangeCrgrEeno={onChangeCrgrEeno} />
                                        </Col>
                                    </Row>
                                </Grid>
                            </div>
                            <div className="search-btn-wrap">
                                <Button className="btn-search" variant="outline-primary" size="sm" onClick={onSearch}><SearchIcon />조회</Button>
                            </div>
                        </div>
                    </div>
                </Collapse>
                <Button size="sm" variant="outline-dark" className="search-control" aria-controls="example-collapse-text" 
                    aria-expanded={open} onClick={gridExpand}>
                    <span className={open === true ? "search-area-close" : "search-area-open"}>{open === true ? CONSTANTS.closeSearch : CONSTANTS.openSearch}</span>
                </Button>
            </div>
            
            <div className="grid-wrap">
                <div className="grid-btn-wrap">
                    <div className="left-align">
                        {/*--------- 필터 -----------*/}
                        <CustomInputGroup size="sm"   onInput={onFilterTextBoxChanged} />
                    </div>
                    <div className="right-align">
                        <Button variant="outline-secondary" size="sm" onClick={addButton} >O/M발주</Button>{' '}
                        <Button variant="outline-secondary" size="sm" onClick={cancelButton}>발주취소</Button>{' '}
                        <Button variant="outline-success" size="sm"><span className="excel-down"></span>{CONSTANTS.excelDownload}</Button>{' '}
                        <Button variant="outline-dark" size="sm"><span className="print"></span>{CONSTANTS.print}</Button>{' '}
                    </div>
                </div>
                {/*--------- Grid -----------*/}
                <GridPrintOrderList 
                    gridHeight={gridHeight}
                    filterValue={filterValue}
                    queryResult={queryResult}
                    limit={limit}
                    activePage={activePage}
                    onCellClicked={onCellClicked}
                    checkRow={checkRow}
                    />

                {/*--------- 페이징 -----------*/}
                <Paging 
                    total={queryResult && queryResult.data && queryResult.data.length}
                    limit={limit}
                    activePage={activePage}
                    onChangePage={onChangePage}
                    onChangeLimit={onChangeLimit}
                />
            </div>
        </>
    )
};
export default PrintOrderList;