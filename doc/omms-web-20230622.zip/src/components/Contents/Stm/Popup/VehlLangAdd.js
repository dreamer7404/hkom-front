import React, {useState, useRef} from 'react';
import {Button, Modal, Table, Row, Col} from 'react-bootstrap';
import {Form, SelectPicker,Schema} from 'rsuite';
import { API, CONSTANTS } from '../../../../utils/constants';
import { useQuery,useMutation} from 'react-query';
import { getData,postData } from '../../../../utils/async';
import { escapeCharChange} from '../../../../utils/commUtils';
import { confirmAlert } from 'react-confirm-alert'; // Import
import ConfirmAlert from '../../../Common/ConfirmAlert';
import CustomModal from '../../../Common/CustomModal';
const { StringType} = Schema.Types;
const model = Schema.Model({
    // qltyVehlCd: StringType().isRequired('차종코드를 선택해 주세요.'),
    mdlMdyCd: StringType().isRequired('연식을 선택해 주세요.'),
    dlExpdRegnCd: StringType().isRequired('지역을 선택해주세요.'),
    langCd: StringType().isRequired('언어를 선택해주세요.'),
    useYn: StringType().isRequired('사용유무를 선택해 주세요.')
});
const VehlLangAdd = ({show, onHide}) => {
 const containerRef = useRef();
    
    const formRef = useRef();
    const [dlExpdRegnCd, setDlExpdRegnCd] = useState();
    const [formError, setFormError] = useState({});
    const [formValue, setFormValue] = useState({
        qltyVehlCd: '',             // 차종코드
        mdlMdyCd:'',
        aaCode : '',
        dlExpdRegnCd : '',
        langCd : '',
        useYn:'',                   // 사용유무
        sortSn : '',
        multiGbn : 'ONE',
    });  


    const onChangeRegnCombo = val =>{
        setDlExpdRegnCd(val);
    }

    const vehlCombo = useQuery([API.vehlCombo, {}], () => getData(API.vehlCombo, {}), {
        select: data => [{label: CONSTANTS.labelAll, value: CONSTANTS.valueAll}]
            .concat(data.map((item) => ({ label: escapeCharChange(item.qltyVehlNm), value: item.qltyVehlCd })))
    }); 
    const mdyCombo = useQuery([API.mdyCombo], () => getData(API.mdyCombo), {
        select: data => data.map((item) => ({ label: item, value: item }))
    });
    const paramsCo = {dlExpdGCd: CONSTANTS.grpCdRegn};
    
    const regnCombo = useQuery([API.codeCombo,paramsCo], () => getData(API.codeCombo,paramsCo)) 


    const langParam = {dlExpdRegnCd: dlExpdRegnCd};
    const langCombo = useQuery([API.langCombo, langParam], () => getData(API.langCombo, langParam), {
        select: data => data.map((item) => ({ label: escapeCharChange(item.langCdNm), value: item.langCd }))
    }); 
            
            
        
    
    
 
const handleSubmit = () => {
        if (!formRef.current.check()) { //validation chk
            return;
        }
        
        
        confirmAlert({
            closeOnClickOutside: false,
            customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}   title={"알림"}
            msg={"입력하신 내용으로 저장하시겠습니까?"} 
            
            onOk={onOk}  />
            
        });
        
        
    };
    const vehlLangSave = useMutation((params => postData(API.langMgmt, params, CONSTANTS.insert)),{
        onSuccess: res => {
           if(res>0){
                confirmAlert({
                    closeOnClickOutside: false,
                    customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}   title={"알림"}
                    msg={"저장이 완료되었습니다."}   />
                    
                });
           }else{
            confirmAlert({
                closeOnClickOutside: false,
                customUI: ({ onClose }) => <ConfirmAlert onClose={onClose}   title={"알림"}
                msg={"에러가 발생했습니다 관리자에게 문의해주세요."}   />
                
            });
           }
           onHide();
        }
    });


    const onOk = () => {
        vehlLangSave.mutate(formValue);
    }


    
    return (
        <>
       <Form
                ref={formRef}
                checkTrigger="change"
                onChange={setFormValue}
                onCheck={setFormError}
                formValue={formValue}
                model={model}>
                    <CustomModal open={show} 
                        title={'차종별 언어등록(개별)'}
                        size='md'
                        // handleOk={handleSubmit}
                        handleCancel={onHide} 
                        
                        >
                
                            <Table className="tbl-hor" bordered>
                                <colgroup>
                                    <col style={{width:'30%'}}></col>
                                    <col style={{width:''}}></col>
                                </colgroup>
                                <tbody>
                                    <tr>
                                        <th className="essen">차종코드</th>
                                        <td>
                                            <Row className="select-wrap">
                                                <Col sm={8}>
                                                
                                                <Form.Control container={()=> containerRef.current}  name="qltyVehlCd" size="sm" style={{zIndex: 0}} 
                                                           placeholder={'선택'}
                                                           defaultValue={''}
                                                           accepter={SelectPicker} 
                                                           searchable={false}
                                                           cleanable={false}
                                                            data={vehlCombo && vehlCombo.data ? vehlCombo.data : []}  
                                                    ></Form.Control>
                                                </Col>
                                                <Col sm={4}>
                                               
                                                    <Form.Control container={()=> containerRef.current}  name="mdlMdyCd" size="sm" style={{zIndex: 0}} 
                                                           placeholder={'선택'}
                                                           defaultValue={''}
                                                           accepter={SelectPicker} 
                                                           searchable={false}
                                                           cleanable={false}
                                                            data={mdyCombo && mdyCombo.data ? mdyCombo.data : []}  
                                                    ></Form.Control>
                                                </Col>
                                            </Row>
                                        </td>
                                    </tr>
                                    <tr>
                                        <th className="essen">언어코드</th>
                                        <td>
                                            <Row className="select-wrap">
                                                <Col sm={4}>
                                                {regnCombo.isSuccess &&
                                                    <Form.Control container={()=> containerRef.current}  name="dlExpdRegnCd" size="sm" style={{zIndex: 0}} 
                                                        value={dlExpdRegnCd}
                                                        placeholder={'선택'}
                                                        defaultValue={''}
                                                        accepter={SelectPicker} 
                                                        searchable={false}
                                                        cleanable={false}
                                                        data={regnCombo.isFetched && regnCombo.data}
                                                        onChange={onChangeRegnCombo}
                                                    ></Form.Control>
                                                }
                                                </Col>
                                              
                                                <Col sm={8}>
                                                <Form.Control container={()=> containerRef.current}  name="langCd" size="sm" style={{zIndex: 0}} 
                                                        
                                                        placeholder={'선택'}
                                                        defaultValue={''}
                                                        accepter={SelectPicker} 
                                                        searchable={false}
                                                        cleanable={false}
                                                        data={langCombo && langCombo.data ? langCombo.data : []}  
                                                        
                                                    ></Form.Control>
                                                        </Col>
                                            </Row>
                                        </td>
                                    </tr>
                                    <tr>
                                    <th className="">A코드</th>
                                        <td>
                                            <Form.Control size="sm" type="text" name='aaCode'/> 
                                        </td>
                                    </tr>
                                    <tr>
                                        <th className="">정렬순서</th>
                                        <td>
                                            <Form.Control size="sm" type="text" name='sortSn'/> 
                                        </td>
                                    </tr>
                                    <tr>
                                        <th className="">사용여부</th>
                                        <td>
                                        <Form.Control name="useYn" size="sm"   
                                                    container={()=> containerRef.current}
                                                    placeholder={'선택'}
                                                    defaultValue={''}
                                                    accepter={SelectPicker} 
                                                    searchable={false}
                                                    cleanable={false}
                                                    data={[
                                                        {label: '사용', value: 'Y'},
                                                        {label: '미사용', value: 'N'},
                                                    ]}
                                            ></Form.Control>
                                        </td>
                                    </tr>
                                </tbody>
                            </Table>
                            <div className='modal-footer'>
                                <Button variant="light" size="md" onClick={onHide}>취소</Button>
                                <Button variant="primary" size="md" onClick={handleSubmit} >저장</Button>
                            </div>
                </CustomModal>
            </Form>

        </>
    );

};
export default VehlLangAdd;