import React, {useState, useMemo} from 'react';
import {Button, Modal, Table} from 'react-bootstrap';
import { AgGridReact } from 'ag-grid-react';
import { useQuery} from 'react-query';
import { API, CONSTANTS } from '../../../../utils/constants';
import { getData } from '../../../../utils/async';
import CustomModal from '../../../Common/CustomModal';
const NatCodeSearch = ({addCodeParam,show, onHide}) => {

    const defaultColDef = useMemo(() => {
        return {
            initialWidth: 90,
            resizable:true,
            sortable:true,
        };
    }, []);

 


    const param = {}
    const queryResult = useQuery([API.natlMgmtPop, param], () => getData(API.natlMgmtPop, param),{
        staleTime: 0,
        
    });

    const columnDefs = [
        {
            headerName: '국가코드',
            field: 'dlExpdNatCd',
            spanHeaderHeight: true,
            maxWidth:'100',
            sortable:true,
            filter: 'agTextColumnFilter',
            floatingFilter: true,
            suppressMenu: true,
            filterParams: {
                filterOptions: ['contains'],
            },
             cellStyle: () => ({textDecoration: 'underline', cursor: 'pointer', color:'#2589f5'}) 
        },
        {
            headerName: '국가명',
            field: 'natNm',
            spanHeaderHeight: true,
            sortable:true,
            filter: 'agTextColumnFilter',
            floatingFilter: true,
            suppressMenu: true,
            filterParams: {
                filterOptions: ['contains'],
            },
            cellStyle: () => ({textDecoration: 'underline', cursor: 'pointer', color:'#2589f5'}) 
        },
        {
            headerName: '지역',
            field: 'regnNm',
            spanHeaderHeight: true,
            maxWidth:'100',
        },
    ]

    const onFirstDataRendered = (params) => {
        params.api.sizeColumnsToFit();
    };
    const onCellClicked = e => {
        let param = {
            dlExpdNatCd : e.data.dlExpdNatCd,
            natNm : e.data.natNm,
            dlExpdRegnCd : e.data.dlExpdRegnCd,
            regnNm : e.data.regnNm,
        }
        if(e.column.colId === 'dlExpdNatCd'){
            addCodeParam(param)
        }else if(e.column.colId === 'natNm'){
            addCodeParam(param)
        }
        onHide()
    };
    return (
        <>
            
                    <CustomModal open={show} 
                        title={'국가코드 검색'}
                        size='md'
                        handleCancel={onHide} 
                    >
                          <div className="ag-theme-alpine" style={{height:300}}>
                                <AgGridReact
                                    rowData={queryResult && queryResult.data}
                                    columnDefs={columnDefs}
                                    defaultColDef={defaultColDef}
                                    
                                    rowSelection={'multiple'}
                                    suppressRowClickSelection= {true} 
                                    onCellClicked={onCellClicked}
                                    onFirstDataRendered={onFirstDataRendered}
                                    suppressSizeToFit={true}    
                                    onGridSizeChanged={onFirstDataRendered}     
                                    >
                                </AgGridReact>
                            </div>
                    </CustomModal>
            
        </>
    );

};
export default NatCodeSearch;